#!/bin/bash
set -e
taskset -pc 8-23 $$
cd /workspaces/repository
O=/var/tmp/kprog-tmp/S17
c++ -std=c++20 -O2 -fPIC -I"$O/credential-source/include" -Ikprog/libnativeloader/src -Irunner/build-llvmbpf/vendor/libbpf/prefix/include -Ivendor/libbpf/include -Ivendor/libbpf/include/uapi -Imicro/programs/build-x86 -I/artifacts/kernel -c "$O/credential-source/src/native_loader.cpp" -o "$O/credentials/native_loader.o"
c++ -std=c++20 -O2 -I"$O/loader/kprog/libnativeloader/include" -Irunner/build-llvmbpf/vendor/libbpf/prefix/include "$O/loader/kprog/trusted_loader.cpp" "$O/credentials/native_loader.o" runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -ldl -pthread -o "$O/credentials/real-loader"
sed "s@export KPROG_REAL_LOADER=.*@export KPROG_REAL_LOADER=/mnt/credentials/real-loader@;s@run/credentials@run/credentials-socket@" "$O/guest-credentials.sh" > "$O/guest-credentials-socket.sh"
sed "s@guest-credentials.sh@guest-credentials-socket.sh@;s@credentials-vng@credentials-socket-vng@g" "$O/run-credentials.sh" > "$O/run-credentials-socket.sh"
sed -i 's@/mnt/credentials/real-loader@/mnt/credentials/real-loader@' "$O/guest-credentials-socket.sh"
# Capability transition occurs after descriptor acquisition, at BPF_PROG_LOAD.
ln -sf real-loader "$O/credentials/trusted-native-loader"
bash "$O/run-credentials-socket.sh"
