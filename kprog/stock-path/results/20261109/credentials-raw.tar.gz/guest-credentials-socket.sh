#!/bin/bash
OUT=/mnt/run/credentials-socket-final
. /workspaces/repository/kprog/stock-path/guest/common.sh
export KPROG_REAL_LOADER=/mnt/credentials/real-loader
for cap in 1 0; do
    KPROG_CAP_PERFMON=$cap python3 /mnt/credentials.py "$OUT/perfmon-$cap" > "$OUT/perfmon-$cap.log" 2>&1
    echo $? > "$OUT/perfmon-$cap.exit"
done
dmesg > "$OUT/dmesg"
