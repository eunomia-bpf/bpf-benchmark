from pathlib import Path
import importlib.util,sys,shutil
p=Path('/workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py')
s=importlib.util.spec_from_file_location('suite',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.BUILD=Path('/mnt/input');m.OUT=Path(sys.argv[1]);m.OUT.mkdir(parents=True,exist_ok=True);shutil.copy2('/mnt/input/cases.json',m.OUT/'cases.json');m.loader_build=lambda:Path('/mnt/credentials');m.check()
