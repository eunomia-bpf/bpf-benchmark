#!/bin/bash
taskset -pc 8-23 $$
cd /workspaces/repository
vng --run /var/tmp/kprog-tmp/CK/build/arch/x86/boot/bzImage --cpus 2 --memory 2G --rwdir=/mnt=/var/tmp/kprog-tmp/S17 --exec 'bash /mnt/guest-credentials-socket.sh' --qemu-opts='-cpu host,+smap' > /var/tmp/kprog-tmp/S17/run/credentials-socket-vng.log 2>&1
echo $? > /var/tmp/kprog-tmp/S17/run/credentials-socket-vng.exit
