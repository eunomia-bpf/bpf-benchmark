#!/bin/bash
set -e
R=/workspaces/repository
export KPROG_STOCK_NATIVE_LINK=/mnt/previous/native-link KPROG_STOCK_LOADER=/mnt/previous/loader-once/build KPROG_STOCK_MODULE=/mnt/previous/mod/kprog_stock.ko
OUT=/mnt/run/x86-tail-frame
. "$R/kprog/stock-path/guest/common.sh"
start_service
set +e
/mnt/previous/frameprobe/client /mnt/previous/tail/tail.bpf.o /mnt/previous/tail/tail.native.o /mnt/previous/native-link "$OUT/native.bin" /mnt/frameprobe/build/tail_frame_probe.ko > "$OUT/client.out" 2> "$OUT/client.err"
result=$?
printf '%s\n' "$result" > "$OUT/client.exit"
stop_service
exit "$result"
