#!/bin/bash
set -e
export TMPDIR=/var/tmp/kprog-tmp/S18
O=$TMPDIR
mkdir -p "$O/frameprobe/build"
make -C /var/tmp/kprog-tmp/S17/x86-build M=/workspaces/repository/kprog/stock-path/fixtures/tail-frame MO="$O/frameprobe/build" -j4 modules
objdump -dr "$O/frameprobe/build/tail_frame_probe.o" > "$O/frameprobe/disassembly.txt"
printf '0\n' > "$O/build-frame.exit"
