#!/bin/bash
export KPROG_STOCK_NATIVE_LINK=/mnt/native-link
OUT=/mnt/run/tail
. /workspaces/repository/kprog/stock-path/guest/common.sh
start_service
/mnt/tail/client /mnt/tail/tail.bpf.o /mnt/tail/tail.native.o /mnt/native-link "$OUT/native.bin" > "$OUT/client.out" 2> "$OUT/client.err"
echo $? > "$OUT/client.exit"
stop_service
rmmod kprog_stock
bash /workspaces/repository/kprog/stock-path/guest/small.sh
rmmod kprog_stock
bash /workspaces/repository/kprog/stock-path/guest/null_btf.sh
rmmod kprog_stock
OUT=/mnt/run/x86-final
. /workspaces/repository/kprog/stock-path/guest/common.sh
python3 /workspaces/repository/kprog/stock-path/run_safety.py check --out "$OUT" --inputs /mnt/x86-input --cases /mnt/x86-input/cases.json > "$OUT/suite.log" 2>&1
echo $? > "$OUT/suite.exit"
dmesg > "$OUT/dmesg"
