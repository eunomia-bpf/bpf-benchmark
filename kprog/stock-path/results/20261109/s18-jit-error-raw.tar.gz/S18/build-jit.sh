#!/bin/bash
set -e
O=/var/tmp/kprog-tmp/S18
P=/var/tmp/kprog-tmp/S17
cd /workspaces/repository
export TMPDIR=$O
INC="-I$P/loader-once/kprog/libnativeloader/include -I$P/loader-once/kprog/libnativeloader/src -Imicro/programs/build-x86 -Irunner/build-llvmbpf/vendor/libbpf/prefix/include -Ivendor/libbpf/include -Ivendor/libbpf/include/uapi"
g++ -std=c++20 -O2 -fPIC $INC -c "$O/jit-fixture/kprog/libnativeloader/src/native_loader.cpp" -o "$O/jit-error-x86/native_loader.o"
g++ -std=c++20 -O2 $INC "$P/loader-once/kprog/trusted_loader.cpp" "$O/jit-error-x86/native_loader.o" runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -lzstd -ldl -pthread -o "$O/jit-error-x86/trusted-native-loader"
printf '0\n' > "$O/build-jit.exit"
