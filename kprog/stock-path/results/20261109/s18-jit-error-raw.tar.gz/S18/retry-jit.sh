#!/bin/bash
set -e
O=/var/tmp/kprog-tmp/S18
bash "$O/build-jit.sh"
python3 "$O/run-guest.py" jit
