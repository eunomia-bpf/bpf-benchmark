from pathlib import Path
import subprocess,os,sys,json,hashlib
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S18');P=Path('/var/tmp/kprog-tmp/S17')
os.unshare(os.CLONE_NEWNS)
subprocess.run(['mount','--make-rprivate','/'],check=True)
pins={}
for q in sorted((O/'source').rglob('*')):
 if q.is_file():
  rel=q.relative_to(O/'source');p=R/rel
  subprocess.run(['mount','--bind',str(q),str(p)],check=True)
  pins[str(rel)]=hashlib.sha256(q.read_bytes()).hexdigest()
(O/'previous').mkdir(exist_ok=True)
subprocess.run(['mount','--bind',str(P),str(O/'previous')],check=True)
label=sys.argv[1]
(O/'run').mkdir(exist_ok=True)
(O/'run'/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
args=['vng','--run',str(P/'x86-build/arch/x86/boot/bzImage'),'--cpus','2','--memory','2G','--rwdir=/mnt='+str(O),'--exec','bash /mnt/guest-'+label+'.sh','--qemu-opts=-cpu host,+smap']
(O/'run'/(label+'-command.json')).write_text(json.dumps(args)+'\n')
with (O/'run'/(label+'-console.log')).open('w') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
(O/'run'/(label+'-guest.exit')).write_text(str(result.returncode)+'\n')
