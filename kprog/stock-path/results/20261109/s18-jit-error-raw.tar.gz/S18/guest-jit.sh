#!/bin/bash
set -e
R=/workspaces/repository
export KPROG_STOCK_NATIVE_LINK=/mnt/previous/native-link KPROG_STOCK_LOADER=/mnt/previous/loader-once/build KPROG_STOCK_MODULE=/mnt/previous/mod/kprog_stock.ko
T=/sys/kernel/tracing
mountpoint -q $T || mount -t tracefs tracefs $T
echo 'r:s18_relocate bpf_native_relocate ret=$retval:s32' > $T/kprobe_events
echo 'r:s18_prog_load bpf_prog_load ret=$retval:s32' >> $T/kprobe_events
echo 'p:s18_load_entry bpf_prog_load type=+0(%di):u32 insns=+4(%di):u32 log_size=+28(%di):u32 name=+48(%di):string' >> $T/kprobe_events
echo 'p:s18_arm bpf_native_image_arm image=%di:x64' >> $T/kprobe_events
echo 'p:s18_test_run bpf_prog_test_run_xdp' >> $T/kprobe_events
echo 1 > $T/events/kprobes/enable

run_case() {
  OUT=$1; LOADER_DIR=$2
  . "$R/kprog/stock-path/guest/common.sh"
  LOADER=$LOADER_DIR
  echo > $T/trace
  start_service
  set +e
  /mnt/previous/loader-once/build/trusted-service-client "$R/kprog/libnativeloader/build/trusted-native.o" > "$OUT/client.out" 2> "$OUT/client.err"
  result=$?
  set -e
  printf '%s\n' "$result" > "$OUT/client.exit"
  stop_service
  cat $T/trace > "$OUT/kprobe-trace"
  rmmod kprog_stock
}

# Same guest, same probes: the unmodified loader first, then the injected one.
run_case /mnt/run/x86-jit-error-control /mnt/previous/loader-once/build
run_case /mnt/run/x86-jit-error /mnt/jit-error-x86
echo 0 > $T/events/kprobes/enable

python3 - <<'PY'
from pathlib import Path
import json,re,tarfile
run=Path('/mnt/run');p=run/'x86-jit-error';c=run/'x86-jit-error-control'
def loader_events(d):
    lines=[l for l in (d/'kprobe-trace').read_text().splitlines() if not l.startswith('#')]
    loader=[l for l in lines if 'trusted-native' in l]
    arms=[i for i,l in enumerate(loader) if 's18_arm:' in l and 'image=0x0' not in l]
    assert len(arms)==1,arms
    tail=loader[arms[0]+1:]
    return dict(
      before=[l for l in loader[:arms[0]] if 's18_prog_load:' in l],
      before_entry=[l for l in loader[:arms[0]] if 's18_load_entry:' in l],
      after=[l for l in tail if 's18_prog_load:' in l],
      after_entry=[l for l in tail if 's18_load_entry:' in l],
      relocate=[l for l in lines if 's18_relocate:' in l],
      test=[l for l in lines if 's18_test_run:' in l])
def show(tag,e):
    for k,v in e.items():
        for l in v: print(tag,k,l.strip()[:190])
e=loader_events(c);show('control',e)
assert int((c/'client.exit').read_text())==0
assert json.loads((c/'client.out').read_text())['retval']==2
assert len(e['relocate'])==1 and 'ret=0' in e['relocate'][0]
assert len(e['after'])==1 and re.search(r'ret=[1-9]',e['after'][0])
assert len(e['after_entry'])==1 and 'log_size=16777216' in e['after_entry'][0]
assert len(e['test'])==1

rows=[json.loads(x) for x in (p/'requests/requests.jsonl').read_text().splitlines()]
assert len(rows)==1 and rows[0]['status']<0 and 'prog_id' not in rows[0]
with tarfile.open(p/'requests'/Path(rows[0]['failure_archive']).name) as t:log=t.extractfile('request/load.stderr').read().decode()
assert log.count('stock-armed-load-attempt=1')==1
assert 'processed ' in log and 'Unknown error 524' in log
assert int((p/'client.exit').read_text())==1
assert (p/'client.out').read_text()==''
assert 'trusted specializer refused native program' in (p/'client.err').read_text()
assert not list(p.glob('jited-*'))
e=loader_events(p);show('injected',e)
assert len(e['relocate'])==1 and 'ret=-34' in e['relocate'][0]
assert len(e['after'])==1 and 'ret=-524' in e['after'][0]
assert len(e['after_entry'])==1 and 'log_size=16777216' in e['after_entry'][0]
assert e['test']==[]
(p/'fixture.exit').write_text('0\n')
print('x86 JIT-error fixture: relocate -34, one armed raw load -524, verifier completed, TEST_RUN 0')
PY
