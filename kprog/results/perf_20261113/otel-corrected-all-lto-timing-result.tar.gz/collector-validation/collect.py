from pathlib import Path
import sys,json,re,subprocess,time,runpy,collections,datetime
r=Path(__file__).resolve().parent;root=Path('/workspaces/repository');tools=root/'kprog/perf/may29-image'
sys.argv=['ratio.py'];ratios=runpy.run_path(str(tools/'ratio.py'));reports=[]
def run(argv,out):
 p=subprocess.run(list(map(str,argv)),capture_output=True,text=True)
 (r/out).write_text(p.stdout);(r/(out+'.stderr')).write_text(p.stderr)
 with (r/'collection-commands.jsonl').open('a') as f:f.write(json.dumps(dict(argv=list(map(str,argv)),exit=p.returncode,out=out))+chr(10))
 p.check_returncode()
for stats in (1,0):
 while not (r/f'stats{stats}.exit').exists():
  if (r/'finished').exists():break
  time.sleep(5)
 try:
  capture=root/f'corpus/results/perf-combined-codegen-timing-20261114/stats{stats}';text=(capture/'guest.log').read_text();names=re.findall(r'x86_kvm_corpus_[0-9_]+',text);candidates=[root/'corpus/results'/n for n in names if (root/'corpus/results'/n/'details/result.json').exists()];path=candidates[-1]
  app,appfile=ratios['ne'].load_app(str(path));thr,e,n,pairs,errors=ratios['thr'](str(path))
  report=dict(recorded=datetime.datetime.now(datetime.timezone.utc).isoformat(),stats=stats,run=str(path),make_exit=int((r/f'stats{stats}.exit').read_text()),app_status=app.get('status'),app_error=app.get('error'),throughput_ratio=thr,throughput_samples=dict(baseline=e,native=n,pairs=pairs,errors=errors),scope='Collector validation against retained OLD directP combined run, not the new candidate. Stats0throughput is frozen primary; stats1throughput auxiliary. No automatic equivalence/acceptance inference.')
  if stats:
   a,b=ratios['ns'](str(path));report.update(aggregate_baseline=a,aggregate_native=b,per_call_ratio=a[0]/b[0])
  for name in ('equal-work.py','stubs.py'):
   run(['python3',tools/name,path],f'stats{stats}-{name}.txt')
  if stats:run(['python3',tools/'perprog.py',path],f'stats{stats}-perprog.txt')
  obsname=f'stats{stats}-observation.json';run(['python3',tools/'otel-observation.py',capture,path],obsname);obs=json.load(open(r/obsname));selected=[];args=[]
  for phase in ('baseline','post_rejit'):
   groups=collections.defaultdict(list)
   for point in obs['snapshots']:
    if any(owner['owner']['phase']==phase and any(m['phase']==phase and m['relation']=='inside' for m in owner['measurement_matches']) for owner in point['owners']):groups[point['map_id']].append(point)
   eligible=[sorted(g,key=lambda x:x['clock']['start']['monotonic_ns']) for g in groups.values() if len(g)>=2]
   if not eligible:
    selected.append(dict(phase=phase,error='No two retained same-generation points fully inside own measurement; full observations retained.'));continue
   points=max(eligible,key=lambda g:g[-1]['clock']['end']['monotonic_ns']-g[0]['clock']['start']['monotonic_ns']);first,last=points[0],points[-1];selected.append(dict(phase=phase,first=first,last=last,candidate_generations={str(k):len(v) for k,v in groups.items()}));args += ['--pair',first['snapshot'],last['snapshot']]
  (r/f'stats{stats}-own-window-selection.json').write_text(json.dumps(selected,indent=2)+chr(10))
  if args:
   snapshots=[p[k]['snapshot'] for p in selected if 'first' in p for k in ('first','last')];decoded=f'stats{stats}-decoded.json';run(['python3',tools/'eqcodex-analyze.py',capture,*[v for name in snapshots for v in ('--snapshot',name)]],decoded);chosen={p[k]['snapshot']:p[k] for p in selected if 'first' in p for k in ('first','last')};records=json.load(open(r/decoded))
   for record in records:
    point=chosen[Path(record['snapshot']).name];record['metrics_map_id']=point['map_id'];record['metrics']=point['metrics'];record['time']=point['clock']['start']['wall_time'];record['metrics_query_clock']=point['clock'];record['selection_scope']='Explicit owner/mapID fully inside own measurement, query clocks retained. Collector clocks are separate.'
   (r/decoded).write_text(json.dumps(records,indent=2)+chr(10));windows=f'stats{stats}-windows.json';run(['python3',tools/'counter-windows.py',r/decoded,*args],windows);run(['python3',tools/'counter-mix.py',r/windows],f'stats{stats}-mix.json')
  reports.append(report)
 except Exception as error:reports.append(dict(stats=stats,collection_error=repr(error),scope='Not zero/missing success; raw retained for manual collection.'))
 (r/'collected-results.json').write_text(json.dumps(reports,indent=2)+chr(10));print(reports[-1],flush=True)
(r/'collection-finished').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
