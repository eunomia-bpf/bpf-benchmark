; ModuleID = '/var/tmp/kprog-tmp/perf/socket-context/upstream-sock.bc'
source_filename = "/workspaces/repository/vendor/repos/cilium/bpf/bpf_sock.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

%union.macaddr = type { i64 }
%union.v4addr = type { i32 }
%union.v6addr = type { %struct.anon.0 }
%struct.anon.0 = type { i64, i64 }
%struct.anon.1 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.2 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.3 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.4 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.5 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.6 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.7 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.8 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.9 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.10 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.11 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.12 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.13 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.14 = type { ptr, ptr, ptr, ptr, ptr, ptr, [0 x ptr] }
%struct.anon.15 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.16 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.17 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.18 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.19 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.20 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.21 = type { ptr, ptr, ptr, ptr, ptr, ptr, [0 x ptr] }
%struct.anon.22 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.23 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.24 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.25 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.26 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.27 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.28 = type { ptr, ptr, ptr, ptr }
%struct.lb4_affinity_key = type { %union.lb4_affinity_client_id, i16, i8, i8, i32 }
%union.lb4_affinity_client_id = type { i64 }
%struct.lb_affinity_val = type { i64, i32, i32 }
%struct.lb_affinity_match = type { i32, i16, i16 }
%struct.ipcache_key = type { %struct.bpf_lpm_trie_key, i16, i8, i8, %union.anon.31 }
%struct.bpf_lpm_trie_key = type { i32, [0 x i8] }
%union.anon.31 = type { %union.v6addr }
%struct.ipv4_revnat_entry = type { i32, i16, i16 }
%struct.ipv4_revnat_tuple = type { i64, i32, i16, i16 }
%struct.skip_lb4_key = type { i64, i32, i16, i16 }
%struct.metrics_value = type { i64, i64 }
%struct.metrics_key = type { i8, i8, i16, i8, [3 x i8] }
%struct.lb4_key = type { i32, i16, i16, i8, i8, [2 x i8] }
%struct.bpf_sock_addr = type { i32, i32, [4 x i32], i32, i32, i32, i32, i32, [4 x i32], %union.anon.29 }
%union.anon.29 = type { ptr }
%struct.lb4_service = type { %union.anon.30, i16, i16, i8, i8, i16 }
%union.anon.30 = type { i32 }
%struct.lb4_backend = type { i32, i16, i8, i8, i16, i8, i8 }
%struct.lb6_affinity_key = type { %union.lb6_affinity_client_id, i16, i8, i8, i32 }
%union.lb6_affinity_client_id = type { %union.v6addr }
%struct.ipv6_revnat_entry = type <{ %union.v6addr, i16, i16 }>
%struct.ipv6_revnat_tuple = type { i64, %union.v6addr, i16, i16 }
%struct.skip_lb6_key = type { i64, %union.v6addr, i32, i16, i16 }
%struct.lb6_key = type { %union.v6addr, i16, i16, i8, i8, [2 x i8] }
%struct.anon = type { i32, i32, i32, i32 }
%struct.lb6_service = type { %union.anon.32, i16, i16, i8, i8, i16 }
%union.anon.32 = type { i32 }
%struct.lb6_backend = type { %union.v6addr, i16, i8, i8, i16, i8, i8 }
%struct.bpf_sock = type { i32, i32, i32, i32, i32, i32, i32, [4 x i32], i32, i16, i16, i32, [4 x i32], i32, i32 }

@__config_cluster_id_bits = dso_local constant i32 8, section ".rodata.config", align 4, !dbg !0
@____license = dso_local global [13 x i8] c"Dual BSD/GPL\00", section "license", align 1, !dbg !109
@__config_cilium_net_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !114
@__config_cilium_net_mac = dso_local constant %union.macaddr zeroinitializer, section ".rodata.config", align 8, !dbg !120
@__config_cilium_host_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !134
@__config_cilium_host_mac = dso_local constant %union.macaddr zeroinitializer, section ".rodata.config", align 8, !dbg !138
@__config_service_loopback_ipv4 = dso_local constant %union.v4addr zeroinitializer, section ".rodata.config", align 4, !dbg !142
@__config_service_loopback_ipv6 = dso_local constant %union.v6addr zeroinitializer, section ".rodata.config", align 1, !dbg !156
@__config_router_ipv6 = dso_local constant %union.v6addr zeroinitializer, section ".rodata.config", align 1, !dbg !181
@__config_trace_payload_len = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !185
@__config_trace_payload_len_overlay = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !189
@__config_direct_routing_dev_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !193
@__config_supports_fib_lookup_skip_neigh = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !197
@__config_supports_fib_lookup_src = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !201
@__config_enable_nodeport_source_lookup = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !205
@__config_tracing_ip_option_type = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !209
@__config_policy_deny_response_enabled = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !215
@__config_cluster_id = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !219
@__config_enable_conntrack_accounting = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !223
@__config_debug_lb = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !227
@__config_nodeport_port_min = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !231
@__config_nodeport_port_max = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !237
@__config_hash_init4_seed = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !241
@__config_hash_init6_seed = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !245
@__config_nat_46x64_prefix = dso_local constant %union.v4addr zeroinitializer, section ".rodata.config", align 4, !dbg !249
@__config_enable_tproxy = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !253
@__config_events_map_rate_limit = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !257
@__config_events_map_burst_limit = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !261
@__config_enable_endpoint_routes = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !265
@__config_enable_identity_mark = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !269
@__config_enable_no_service_endpoints_routable = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !273
@__config_tunnel_protocol = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !279
@__config_tunnel_port = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !284
@__config_enable_jiffies = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !288
@__config_kernel_hz = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !293
@cilium_metrics = dso_local global %struct.anon.1 zeroinitializer, section ".maps", align 8, !dbg !297
@cilium_ipv4_frag_datagrams = dso_local global %struct.anon.2 zeroinitializer, section ".maps", align 8, !dbg !338
@__config_enable_ipv4_fragments = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !374
@cilium_ipv6_frag_datagrams = dso_local global %struct.anon.3 zeroinitializer, section ".maps", align 8, !dbg !378
@__config_enable_ipv6_fragments = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !402
@__config_enable_extended_ip_protocols = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !406
@cilium_lxc = dso_local global %struct.anon.4 zeroinitializer, section ".maps", align 8, !dbg !411
@cilium_ipcache_v2 = dso_local global %struct.anon.5 zeroinitializer, section ".maps", align 8, !dbg !454
@cilium_ratelimit = dso_local global %struct.anon.6 zeroinitializer, section ".maps", align 8, !dbg !504
@cilium_ratelimit_metrics = dso_local global %struct.anon.7 zeroinitializer, section ".maps", align 8, !dbg !535
@cilium_lb6_reverse_nat = dso_local global %struct.anon.8 zeroinitializer, section ".maps", align 8, !dbg !557
@cilium_lb6_services_v2 = dso_local global %struct.anon.9 zeroinitializer, section ".maps", align 8, !dbg !572
@cilium_lb6_backends_v3 = dso_local global %struct.anon.10 zeroinitializer, section ".maps", align 8, !dbg !606
@cilium_lb6_affinity = dso_local global %struct.anon.11 zeroinitializer, section ".maps", align 8, !dbg !626
@cilium_lb6_source_range = dso_local global %struct.anon.12 zeroinitializer, section ".maps", align 8, !dbg !656
@cilium_lb6_health = dso_local global %struct.anon.13 zeroinitializer, section ".maps", align 8, !dbg !677
@cilium_lb6_maglev = dso_local global %struct.anon.14 zeroinitializer, section ".maps", align 8, !dbg !693
@cilium_lb4_reverse_nat = dso_local global %struct.anon.15 zeroinitializer, section ".maps", align 8, !dbg !724
@cilium_lb4_services_v2 = dso_local global %struct.anon.16 zeroinitializer, section ".maps", align 8, !dbg !739
@cilium_lb4_backends_v3 = dso_local global %struct.anon.17 zeroinitializer, section ".maps", align 8, !dbg !772
@cilium_lb4_affinity = dso_local global %struct.anon.18 zeroinitializer, section ".maps", align 8, !dbg !792
@cilium_lb4_source_range = dso_local global %struct.anon.19 zeroinitializer, section ".maps", align 8, !dbg !815
@cilium_lb4_health = dso_local global %struct.anon.20 zeroinitializer, section ".maps", align 8, !dbg !832
@cilium_lb4_maglev = dso_local global %struct.anon.21 zeroinitializer, section ".maps", align 8, !dbg !846
@cilium_lb_affinity_match = dso_local global %struct.anon.22 zeroinitializer, section ".maps", align 8, !dbg !865
@cilium_lb_act = dso_local global %struct.anon.23 zeroinitializer, section ".maps", align 8, !dbg !881
@cilium_skip_lb6 = dso_local global %struct.anon.24 zeroinitializer, section ".maps", align 8, !dbg !903
@cilium_skip_lb4 = dso_local global %struct.anon.25 zeroinitializer, section ".maps", align 8, !dbg !926
@__config_enable_lrp = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !943
@cilium_lb4_reverse_sk = dso_local global %struct.anon.26 zeroinitializer, section ".maps", align 8, !dbg !947
@cilium_lb6_reverse_sk = dso_local global %struct.anon.27 zeroinitializer, section ".maps", align 8, !dbg !975
@cilium_events = dso_local global %struct.anon.28 zeroinitializer, section ".maps", align 8, !dbg !998
@llvm.compiler.used = appending global [74 x ptr] [ptr @____license, ptr @__config_cilium_host_ifindex, ptr @__config_cilium_host_mac, ptr @__config_cilium_net_ifindex, ptr @__config_cilium_net_mac, ptr @__config_cluster_id, ptr @__config_cluster_id_bits, ptr @__config_debug_lb, ptr @__config_direct_routing_dev_ifindex, ptr @__config_enable_conntrack_accounting, ptr @__config_enable_endpoint_routes, ptr @__config_enable_extended_ip_protocols, ptr @__config_enable_identity_mark, ptr @__config_enable_ipv4_fragments, ptr @__config_enable_ipv6_fragments, ptr @__config_enable_jiffies, ptr @__config_enable_lrp, ptr @__config_enable_no_service_endpoints_routable, ptr @__config_enable_nodeport_source_lookup, ptr @__config_enable_tproxy, ptr @__config_events_map_burst_limit, ptr @__config_events_map_rate_limit, ptr @__config_hash_init4_seed, ptr @__config_hash_init6_seed, ptr @__config_kernel_hz, ptr @__config_nat_46x64_prefix, ptr @__config_nodeport_port_max, ptr @__config_nodeport_port_min, ptr @__config_policy_deny_response_enabled, ptr @__config_router_ipv6, ptr @__config_service_loopback_ipv4, ptr @__config_service_loopback_ipv6, ptr @__config_supports_fib_lookup_skip_neigh, ptr @__config_supports_fib_lookup_src, ptr @__config_trace_payload_len, ptr @__config_trace_payload_len_overlay, ptr @__config_tracing_ip_option_type, ptr @__config_tunnel_port, ptr @__config_tunnel_protocol, ptr @cil_sock4_connect, ptr @cil_sock4_recvmsg, ptr @cil_sock4_sendmsg, ptr @cil_sock6_connect, ptr @cil_sock6_recvmsg, ptr @cil_sock6_sendmsg, ptr @cil_sock_release, ptr @cilium_events, ptr @cilium_ipcache_v2, ptr @cilium_ipv4_frag_datagrams, ptr @cilium_ipv6_frag_datagrams, ptr @cilium_lb4_affinity, ptr @cilium_lb4_backends_v3, ptr @cilium_lb4_health, ptr @cilium_lb4_maglev, ptr @cilium_lb4_reverse_nat, ptr @cilium_lb4_reverse_sk, ptr @cilium_lb4_services_v2, ptr @cilium_lb4_source_range, ptr @cilium_lb6_affinity, ptr @cilium_lb6_backends_v3, ptr @cilium_lb6_health, ptr @cilium_lb6_maglev, ptr @cilium_lb6_reverse_nat, ptr @cilium_lb6_reverse_sk, ptr @cilium_lb6_services_v2, ptr @cilium_lb6_source_range, ptr @cilium_lb_act, ptr @cilium_lb_affinity_match, ptr @cilium_lxc, ptr @cilium_metrics, ptr @cilium_ratelimit, ptr @cilium_ratelimit_metrics, ptr @cilium_skip_lb4, ptr @cilium_skip_lb6], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local void @__check_cluster_id_bits() local_unnamed_addr #0 !dbg !1119 {
  %1 = tail call ptr asm sideeffect "$0 = __config_cluster_id_bits ll", "=r"() #6, !dbg !1125, !srcloc !1126
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1123, metadata !DIExpression()), !dbg !1127
  %2 = load volatile i32, ptr %1, align 4, !dbg !1128, !tbaa !1129
  ret void, !dbg !1128
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_connect(ptr noundef %0) #0 section "cgroup/connect4" !dbg !1133 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !1174
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !1175
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !1176
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !1177
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !1178
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !1179
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !1180
  %9 = alloca i32, align 4, !DIAssignID !1181
  %10 = alloca i32, align 4, !DIAssignID !1182
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !1183
  %12 = alloca i32, align 4, !DIAssignID !1184
  %13 = alloca %struct.metrics_value, align 8, !DIAssignID !1185
  %14 = alloca %struct.metrics_key, align 8, !DIAssignID !1186
  %15 = alloca %struct.metrics_value, align 8, !DIAssignID !1187
  %16 = alloca %struct.metrics_key, align 8, !DIAssignID !1188
  %17 = alloca %struct.metrics_value, align 8, !DIAssignID !1189
  %18 = alloca %struct.metrics_key, align 8, !DIAssignID !1190
  %19 = alloca %struct.lb4_key, align 4, !DIAssignID !1191
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1172, metadata !DIExpression()), !dbg !1192
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !1191, metadata ptr %19, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1199, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i1 false, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.value(metadata i1 true, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !1235
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !1235
  %20 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #6, !dbg !1237
  call void @llvm.dbg.value(metadata i64 %20, metadata !1234, metadata !DIExpression()), !dbg !1235
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !1203, metadata !DIExpression()), !dbg !1225
  %21 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !1238
  call void @llvm.dbg.value(metadata !DIArgList(i64 %20, i64 %21), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !1184, metadata ptr %12, metadata !DIExpression()), !dbg !1247
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !1247
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !1249
  %22 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !1250
  %23 = load i32, ptr %22, align 8, !dbg !1250, !tbaa !1251
  store volatile i32 %23, ptr %12, align 4, !dbg !1253, !tbaa !1129, !DIAssignID !1254
  call void @llvm.dbg.assign(metadata i32 %23, metadata !1239, metadata !DIExpression(), metadata !1254, metadata ptr %12, metadata !DIExpression()), !dbg !1247
  %24 = load volatile i32, ptr %12, align 4, !dbg !1255, !tbaa !1129
  %25 = trunc i32 %24 to i16, !dbg !1256
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !1257
  call void @llvm.dbg.value(metadata i16 %25, metadata !1211, metadata !DIExpression()), !dbg !1225
  %26 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !1258
  %27 = load i32, ptr %26, align 4, !dbg !1258, !tbaa !1259
  %28 = trunc i32 %27 to i8, !dbg !1258
  call void @llvm.dbg.value(metadata i8 %28, metadata !1212, metadata !DIExpression()), !dbg !1225
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !1260
  %30 = load i32, ptr %29, align 4, !dbg !1260, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %30, metadata !1213, metadata !DIExpression()), !dbg !1225
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %19) #6, !dbg !1262
  store i32 %30, ptr %19, align 4, !dbg !1263, !tbaa !1264, !DIAssignID !1267
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1267, metadata ptr %19, metadata !DIExpression()), !dbg !1225
  %31 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 1, !dbg !1263
  store i16 %25, ptr %31, align 4, !dbg !1263, !tbaa !1268, !DIAssignID !1269
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1269, metadata ptr %31, metadata !DIExpression()), !dbg !1225
  %32 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 2, !dbg !1263
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1270, metadata ptr %32, metadata !DIExpression()), !dbg !1225
  %33 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 3, !dbg !1263
  store i8 %28, ptr %33, align 4, !dbg !1263, !tbaa !1271, !DIAssignID !1272
  call void @llvm.dbg.assign(metadata i8 %28, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !1272, metadata ptr %33, metadata !DIExpression()), !dbg !1225
  %34 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 4, !dbg !1263
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !1273, metadata ptr %34, metadata !DIExpression()), !dbg !1225
  %35 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 5, !dbg !1263
  store i16 0, ptr %35, align 2, !dbg !1263, !DIAssignID !1274
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !1274, metadata ptr %35, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  tail call void @llvm.dbg.value(metadata i8 %28, metadata !1275, metadata !DIExpression()), !dbg !1280
  switch i8 %28, label %282 [
    i8 6, label %36
    i8 -120, label %36
    i8 17, label %36
  ], !dbg !1283

36:                                               ; preds = %1, %1, %1
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !1293, metadata ptr undef, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !1296, metadata ptr undef, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.value(metadata ptr %19, metadata !1289, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !1294
  store i16 0, ptr %32, align 2, !dbg !1297, !tbaa !1298
  store i8 0, ptr %34, align 1, !dbg !1299, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1306
  %37 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !1308
  call void @llvm.dbg.value(metadata ptr %37, metadata !1291, metadata !DIExpression()), !dbg !1294
  %38 = icmp eq ptr %37, null, !dbg !1309
  br i1 %38, label %282, label %39, !dbg !1311

39:                                               ; preds = %36
  tail call void @llvm.dbg.value(metadata ptr %37, metadata !1312, metadata !DIExpression()), !dbg !1317
  %40 = getelementptr inbounds %struct.lb4_service, ptr %37, i64 0, i32 4, !dbg !1320
  %41 = load i8, ptr %40, align 1, !dbg !1320, !tbaa !1321
  %42 = and i8 %41, 32, !dbg !1323
  %43 = icmp eq i8 %42, 0, !dbg !1324
  br i1 %43, label %47, label %44, !dbg !1325

44:                                               ; preds = %39
  store i8 1, ptr %34, align 1, !dbg !1326, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1327
  %45 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !1329
  call void @llvm.dbg.value(metadata ptr %45, metadata !1208, metadata !DIExpression()), !dbg !1225
  %46 = icmp eq ptr %45, null, !dbg !1330
  br i1 %46, label %282, label %47, !dbg !1332

47:                                               ; preds = %39, %44
  %48 = phi ptr [ %45, %44 ], [ %37, %39 ]
  call void @llvm.dbg.value(metadata ptr %48, metadata !1208, metadata !DIExpression()), !dbg !1225
  %49 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 1, !dbg !1333
  %50 = load i16, ptr %49, align 4, !dbg !1333, !tbaa !1334
  %51 = icmp eq i16 %50, 0, !dbg !1335
  br i1 %51, label %52, label %70, !dbg !1336

52:                                               ; preds = %47
  %53 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !1337, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %53, metadata !1217, metadata !DIExpression()), !dbg !1339
  %54 = load volatile i8, ptr %53, align 1, !dbg !1340, !tbaa !1341, !range !1343, !noundef !1344
  %55 = icmp eq i8 %54, 0, !dbg !1340
  br i1 %55, label %56, label %282, !dbg !1345

56:                                               ; preds = %52
  call void @llvm.dbg.value(metadata ptr %48, metadata !1346, metadata !DIExpression()), !dbg !1351
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1354, metadata !DIExpression()), !dbg !1357
  %57 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 3, !dbg !1360
  %58 = load i8, ptr %57, align 4, !dbg !1360, !tbaa !1361
  %59 = and i8 %58, 35, !dbg !1362
  %60 = icmp eq i8 %59, 0, !dbg !1363
  br i1 %60, label %64, label %61, !dbg !1364

61:                                               ; preds = %56
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1365, metadata !DIExpression()), !dbg !1368
  %62 = and i8 %58, 4, !dbg !1370
  %63 = icmp eq i8 %62, 0, !dbg !1371
  br i1 %63, label %282, label %69, !dbg !1372

64:                                               ; preds = %56
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1354, metadata !DIExpression()), !dbg !1373
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1375, metadata !DIExpression()), !dbg !1378
  %65 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1380
  %66 = load i8, ptr %65, align 1, !dbg !1380, !tbaa !1321
  %67 = and i8 %66, 16, !dbg !1381
  %68 = icmp eq i8 %67, 0, !dbg !1382
  br i1 %68, label %282, label %69, !dbg !1383

69:                                               ; preds = %64, %61
  br label %282, !dbg !1384

70:                                               ; preds = %47
  call void @llvm.dbg.value(metadata ptr %48, metadata !1385, metadata !DIExpression()), !dbg !1388
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1391, metadata !DIExpression()), !dbg !1394
  %71 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 3, !dbg !1396
  %72 = load i8, ptr %71, align 4, !dbg !1396, !tbaa !1361
  %73 = and i8 %72, 8, !dbg !1397
  %74 = icmp eq i8 %73, 0, !dbg !1398
  br i1 %74, label %75, label %80, !dbg !1399

75:                                               ; preds = %70
  %76 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1400
  %77 = load i8, ptr %76, align 1, !dbg !1400, !tbaa !1321
  %78 = and i8 %77, 8, !dbg !1401
  %79 = icmp eq i8 %78, 0, !dbg !1399
  br i1 %79, label %86, label %282, !dbg !1402

80:                                               ; preds = %70
  call void @llvm.dbg.value(metadata ptr %48, metadata !1403, metadata !DIExpression()), !dbg !1414
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1417, metadata !DIExpression()), !dbg !1420
  %81 = and i8 %72, 1, !dbg !1422
  %82 = icmp eq i8 %81, 0, !dbg !1423
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1391, metadata !DIExpression()), !dbg !1424
  %83 = and i32 %30, 255
  %84 = icmp eq i32 %83, 127
  %85 = select i1 %82, i1 %84, i1 false, !dbg !1426
  br i1 %85, label %99, label %89, !dbg !1426

86:                                               ; preds = %75
  call void @llvm.dbg.value(metadata ptr %48, metadata !1403, metadata !DIExpression()), !dbg !1414
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1417, metadata !DIExpression()), !dbg !1420
  %87 = and i8 %72, 1, !dbg !1422
  %88 = icmp eq i8 %87, 0, !dbg !1423
  br i1 %88, label %99, label %89, !dbg !1426

89:                                               ; preds = %86, %80
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !1178, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 %30, metadata !1433, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !1436
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #6, !dbg !1438
  %90 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !1439
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %90, i8 0, i64 18, i1 false), !dbg !1439, !DIAssignID !1440
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !1440, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !1441, metadata ptr undef, metadata !DIExpression()), !dbg !1436
  store i32 64, ptr %6, align 4, !dbg !1442, !tbaa.struct !1443, !DIAssignID !1445
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1445, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  %91 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !1446
  store i8 1, ptr %91, align 1, !dbg !1447, !tbaa !1448, !DIAssignID !1451
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !1451, metadata ptr %91, metadata !DIExpression()), !dbg !1436
  %92 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !1452
  store i32 %30, ptr %92, align 4, !dbg !1453, !tbaa !1444, !DIAssignID !1454
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1454, metadata ptr %92, metadata !DIExpression()), !dbg !1436
  %93 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !1455
  store i16 0, ptr %93, align 4, !dbg !1456, !tbaa !1457, !DIAssignID !1458
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1458, metadata ptr %93, metadata !DIExpression()), !dbg !1436
  %94 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #6, !dbg !1459
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #6, !dbg !1460
  call void @llvm.dbg.value(metadata ptr %94, metadata !1409, metadata !DIExpression()), !dbg !1461
  %95 = icmp eq ptr %94, null, !dbg !1462
  br i1 %95, label %282, label %96, !dbg !1464

96:                                               ; preds = %89
  %97 = load i32, ptr %94, align 4, !dbg !1465, !tbaa !1466
  %98 = icmp eq i32 %97, 1, !dbg !1468
  br i1 %98, label %99, label %282, !dbg !1469

99:                                               ; preds = %80, %86, %96
  %100 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !1470, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %100, metadata !1222, metadata !DIExpression()), !dbg !1472
  %101 = load volatile i8, ptr %100, align 1, !dbg !1473, !tbaa !1341, !range !1343, !noundef !1344
  %102 = icmp eq i8 %101, 0, !dbg !1473
  br i1 %102, label %114, label %103, !dbg !1474

103:                                              ; preds = %99
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1475, metadata !DIExpression()), !dbg !1478
  %104 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1480
  %105 = load i8, ptr %104, align 1, !dbg !1480, !tbaa !1321
  %106 = and i8 %105, 1, !dbg !1481
  %107 = icmp eq i8 %106, 0, !dbg !1482
  br i1 %107, label %114, label %108, !dbg !1483

108:                                              ; preds = %103
  %109 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !1484
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !1183, metadata ptr %11, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i64 %109, metadata !1490, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i32 %30, metadata !1491, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i16 %25, metadata !1492, metadata !DIExpression()), !dbg !1494
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #6, !dbg !1496
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !1529
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !1529
  call void @llvm.dbg.label(metadata !1527), !dbg !1532
  %110 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !1533
  call void @llvm.dbg.value(metadata ptr %110, metadata !1512, metadata !DIExpression()), !dbg !1529
  store i64 0, ptr %110, align 8, !dbg !1533, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !1536
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !1529
  store i64 %109, ptr %11, align 8, !dbg !1537, !tbaa !1538, !DIAssignID !1540
  call void @llvm.dbg.assign(metadata i64 %109, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1540, metadata ptr %11, metadata !DIExpression()), !dbg !1494
  store i32 %30, ptr %110, align 8, !dbg !1541, !tbaa !1542, !DIAssignID !1543
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1543, metadata ptr %110, metadata !DIExpression()), !dbg !1494
  %111 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !1544
  store i16 %25, ptr %111, align 4, !dbg !1545, !tbaa !1546, !DIAssignID !1547
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !1547, metadata ptr %111, metadata !DIExpression()), !dbg !1494
  %112 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #6, !dbg !1548
  call void @llvm.dbg.value(metadata ptr %112, metadata !1493, metadata !DIExpression()), !dbg !1494
  %113 = icmp eq ptr %112, null, !dbg !1549
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #6, !dbg !1551
  br i1 %113, label %114, label %282, !dbg !1552

114:                                              ; preds = %108, %103, %99
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1553, metadata !DIExpression()), !dbg !1556
  %115 = load i8, ptr %71, align 4, !dbg !1559, !tbaa !1361
  %116 = and i8 %115, 16, !dbg !1560
  %117 = icmp eq i8 %116, 0, !dbg !1561
  br i1 %117, label %173, label %118, !dbg !1562

118:                                              ; preds = %114
  call void @llvm.dbg.value(metadata ptr %48, metadata !1563, metadata !DIExpression()), !dbg !1570
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !1570
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !1176, metadata ptr %4, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !1177, metadata ptr %5, metadata !DIExpression()), !dbg !1595
  call void @llvm.dbg.value(metadata ptr %48, metadata !1580, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !1593
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #6, !dbg !1596
  store i64 %20, ptr %4, align 8, !dbg !1597, !DIAssignID !1598
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1598, metadata ptr %4, metadata !DIExpression()), !dbg !1593
  %119 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !1599
  %120 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1600
  %121 = load i16, ptr %120, align 2, !dbg !1600, !tbaa !1601
  store i16 %121, ptr %119, align 8, !dbg !1599, !tbaa !1602, !DIAssignID !1604
  call void @llvm.dbg.assign(metadata i16 %121, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !1604, metadata ptr %119, metadata !DIExpression()), !dbg !1593
  %122 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !1599
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !1605, metadata ptr %122, metadata !DIExpression()), !dbg !1593
  store i8 1, ptr %122, align 2, !dbg !1599, !DIAssignID !1606
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !1606, metadata ptr %122, metadata !DIExpression()), !dbg !1593
  %123 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !1599
  store i8 0, ptr %123, align 1, !dbg !1599, !tbaa !1607, !DIAssignID !1608
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !1608, metadata ptr %123, metadata !DIExpression()), !dbg !1593
  %124 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !1599
  store i32 0, ptr %124, align 4, !dbg !1599, !tbaa !1609, !DIAssignID !1610
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1610, metadata ptr %124, metadata !DIExpression()), !dbg !1593
  %125 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #6, !dbg !1611
  call void @llvm.dbg.value(metadata ptr %125, metadata !1583, metadata !DIExpression()), !dbg !1593
  %126 = icmp eq ptr %125, null, !dbg !1612
  br i1 %126, label %127, label %128, !dbg !1613

127:                                              ; preds = %118
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !1614
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  br label %173, !dbg !1615

128:                                              ; preds = %118
  %129 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !1616, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %129, metadata !1623, metadata !DIExpression()), !dbg !1626
  %130 = load volatile i8, ptr %129, align 1, !dbg !1627, !tbaa !1341, !range !1343, !noundef !1344
  %131 = icmp eq i8 %130, 0, !dbg !1627
  br i1 %131, label %135, label %132, !dbg !1628

132:                                              ; preds = %128
  %133 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !1629
  %134 = lshr i64 %133, 8, !dbg !1630
  br label %138, !dbg !1631

135:                                              ; preds = %128
  %136 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !1632
  %137 = udiv i64 %136, 1000000000, !dbg !1635
  br label %138, !dbg !1636

138:                                              ; preds = %132, %135
  %139 = phi i64 [ %134, %132 ], [ %137, %135 ], !dbg !1637
  call void @llvm.dbg.value(metadata i64 %139, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1595
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #6, !dbg !1638
  %140 = getelementptr inbounds %struct.lb_affinity_val, ptr %125, i64 0, i32 1, !dbg !1639
  %141 = load i32, ptr %140, align 1, !dbg !1639, !tbaa !1640
  store i32 %141, ptr %5, align 4, !dbg !1642, !tbaa !1643, !DIAssignID !1645
  call void @llvm.dbg.assign(metadata i32 %141, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1645, metadata ptr %5, metadata !DIExpression()), !dbg !1595
  %142 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !1642
  %143 = load i16, ptr %120, align 2, !dbg !1646, !tbaa !1601
  store i16 %143, ptr %142, align 4, !dbg !1642, !tbaa !1647, !DIAssignID !1648
  call void @llvm.dbg.assign(metadata i16 %143, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1648, metadata ptr %142, metadata !DIExpression()), !dbg !1595
  %144 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !1642
  store i16 0, ptr %144, align 2, !dbg !1642, !tbaa !1649, !DIAssignID !1650
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1650, metadata ptr %144, metadata !DIExpression()), !dbg !1595
  %145 = load volatile i64, ptr %125, align 1, !dbg !1651, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %145, metadata !1588, metadata !DIExpression()), !dbg !1652
  call void asm sideeffect "", "~{memory}"() #6, !dbg !1653, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1658, metadata !DIExpression()), !dbg !1663
  %146 = load i32, ptr %48, align 4, !dbg !1665, !tbaa !1444
  %147 = and i32 %146, 16777215, !dbg !1666
  call void @llvm.dbg.value(metadata i32 %147, metadata !1667, metadata !DIExpression()), !dbg !1677
  %148 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !1679, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %148, metadata !1672, metadata !DIExpression()), !dbg !1681
  %149 = load volatile i8, ptr %148, align 1, !dbg !1682, !tbaa !1341, !range !1343, !noundef !1344
  %150 = icmp eq i8 %149, 0, !dbg !1682
  br i1 %150, label %156, label %151, !dbg !1683

151:                                              ; preds = %138
  %152 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !1684, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %152, metadata !1675, metadata !DIExpression()), !dbg !1686
  %153 = load volatile i32, ptr %152, align 4, !dbg !1687, !tbaa !1129
  %154 = mul i32 %153, %147, !dbg !1688
  %155 = lshr i32 %154, 8, !dbg !1689
  br label %156, !dbg !1690

156:                                              ; preds = %138, %151
  %157 = phi i32 [ %155, %151 ], [ %147, %138 ], !dbg !1677
  %158 = zext nneg i32 %157 to i64, !dbg !1691
  %159 = add i64 %145, %158, !dbg !1692
  %160 = and i64 %139, 4294967295, !dbg !1693
  %161 = icmp ugt i64 %159, %160, !dbg !1694
  br i1 %161, label %162, label %165, !dbg !1695

162:                                              ; preds = %156
  %163 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #6, !dbg !1696
  %164 = icmp eq ptr %163, null, !dbg !1696
  br i1 %164, label %165, label %167, !dbg !1698

165:                                              ; preds = %162, %156
  %166 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #6, !dbg !1595
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !1699
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !1614
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  br label %173, !dbg !1615

167:                                              ; preds = %162
  call void @llvm.dbg.value(metadata i64 %160, metadata !1591, metadata !DIExpression()), !dbg !1700
  store volatile i64 %160, ptr %125, align 1, !dbg !1701, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !1702, !srcloc !1657
  %168 = load i32, ptr %140, align 1, !dbg !1704, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !1699
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !1614
  call void @llvm.dbg.value(metadata i32 %168, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  %169 = icmp eq i32 %168, 0, !dbg !1705
  br i1 %169, label %173, label %170, !dbg !1615

170:                                              ; preds = %167
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !1182, metadata ptr %10, metadata !DIExpression()), !dbg !1712
  store i32 %168, ptr %10, align 4, !tbaa !1129, !DIAssignID !1715
  call void @llvm.dbg.assign(metadata i32 %168, metadata !1707, metadata !DIExpression(), metadata !1715, metadata ptr %10, metadata !DIExpression()), !dbg !1712
  %171 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #6, !dbg !1716
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !1717
  call void @llvm.dbg.value(metadata ptr %171, metadata !1205, metadata !DIExpression()), !dbg !1225
  %172 = icmp eq ptr %171, null, !dbg !1718
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void asm sideeffect "", "~{memory}"() #6, !dbg !1720, !srcloc !1721
  br i1 %172, label %173, label %215, !dbg !1722

173:                                              ; preds = %170, %167, %114, %127, %165
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !1728
  %174 = load i32, ptr %26, align 4, !dbg !1732, !tbaa !1259
  %175 = and i32 %174, 255, !dbg !1732
  %176 = icmp eq i32 %175, 6, !dbg !1733
  br i1 %176, label %177, label %180, !dbg !1732

177:                                              ; preds = %173
  %178 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !1734
  %179 = zext i32 %178 to i64, !dbg !1734
  br label %182, !dbg !1732

180:                                              ; preds = %173
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !1740
  %181 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !1742
  br label %182, !dbg !1732

182:                                              ; preds = %177, %180
  %183 = phi i64 [ %179, %177 ], [ %181, %180 ], !dbg !1732
  %184 = load i16, ptr %49, align 4, !dbg !1743, !tbaa !1334
  %185 = zext i16 %184 to i64, !dbg !1744
  %186 = urem i64 %183, %185, !dbg !1745
  %187 = trunc i64 %186 to i16, !dbg !1746
  %188 = add nuw i16 %187, 1, !dbg !1746
  store i16 %188, ptr %32, align 2, !dbg !1747, !tbaa !1298, !DIAssignID !1748
  call void @llvm.dbg.assign(metadata i16 %188, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1748, metadata ptr %32, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %19, metadata !1749, metadata !DIExpression()), !dbg !1752
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1754
  %189 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !1756
  call void @llvm.dbg.value(metadata ptr %189, metadata !1214, metadata !DIExpression()), !dbg !1225
  %190 = icmp eq ptr %189, null, !dbg !1757
  br i1 %190, label %191, label %201, !dbg !1759

191:                                              ; preds = %182
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1189, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1190, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !1772
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %17) #6, !dbg !1775
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !1776, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %18) #6, !dbg !1777
  store i64 21502558725, ptr %18, align 8, !dbg !1778, !DIAssignID !1779
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !1779, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1780, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1781, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !1772
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !1782, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !1783, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !1772
  %192 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18) #6, !dbg !1784
  call void @llvm.dbg.value(metadata ptr %192, metadata !1770, metadata !DIExpression()), !dbg !1772
  %193 = icmp eq ptr %192, null, !dbg !1785
  br i1 %193, label %197, label %194, !dbg !1787

194:                                              ; preds = %191
  %195 = load i64, ptr %192, align 8, !dbg !1788, !tbaa !1790
  %196 = add i64 %195, 1, !dbg !1788
  store i64 %196, ptr %192, align 8, !dbg !1788, !tbaa !1790
  br label %200, !dbg !1792

197:                                              ; preds = %191
  store i64 1, ptr %17, align 8, !dbg !1793, !tbaa !1790, !DIAssignID !1795
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1795, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  %198 = getelementptr inbounds %struct.metrics_value, ptr %17, i64 0, i32 1, !dbg !1796
  store i64 0, ptr %198, align 8, !dbg !1797, !tbaa !1798, !DIAssignID !1799
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !1799, metadata ptr %198, metadata !DIExpression()), !dbg !1772
  %199 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #6, !dbg !1800
  br label %200

200:                                              ; preds = %194, %197
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %18) #6, !dbg !1801
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %17) #6, !dbg !1801
  br label %282, !dbg !1802

201:                                              ; preds = %182
  %202 = load i32, ptr %189, align 4, !dbg !1803, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %202, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !1181, metadata ptr %9, metadata !DIExpression()), !dbg !1804
  store i32 %202, ptr %9, align 4, !tbaa !1129, !DIAssignID !1806
  call void @llvm.dbg.assign(metadata i32 %202, metadata !1707, metadata !DIExpression(), metadata !1806, metadata ptr %9, metadata !DIExpression()), !dbg !1804
  %203 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #6, !dbg !1807
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !1808
  call void @llvm.dbg.value(metadata ptr %203, metadata !1205, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !1225
  %204 = icmp eq ptr %203, null, !dbg !1809
  br i1 %204, label %205, label %215, !dbg !1811

205:                                              ; preds = %201
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1187, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1188, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !1812
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %15) #6, !dbg !1815
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !1816, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %16) #6, !dbg !1817
  store i64 21503148550, ptr %16, align 8, !dbg !1818, !DIAssignID !1819
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !1819, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1820, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1821, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !1812
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !1822, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !1823, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !1812
  %206 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16) #6, !dbg !1824
  call void @llvm.dbg.value(metadata ptr %206, metadata !1770, metadata !DIExpression()), !dbg !1812
  %207 = icmp eq ptr %206, null, !dbg !1825
  br i1 %207, label %211, label %208, !dbg !1826

208:                                              ; preds = %205
  %209 = load i64, ptr %206, align 8, !dbg !1827, !tbaa !1790
  %210 = add i64 %209, 1, !dbg !1827
  store i64 %210, ptr %206, align 8, !dbg !1827, !tbaa !1790
  br label %214, !dbg !1828

211:                                              ; preds = %205
  store i64 1, ptr %15, align 8, !dbg !1829, !tbaa !1790, !DIAssignID !1830
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1830, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  %212 = getelementptr inbounds %struct.metrics_value, ptr %15, i64 0, i32 1, !dbg !1831
  store i64 0, ptr %212, align 8, !dbg !1832, !tbaa !1798, !DIAssignID !1833
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !1833, metadata ptr %212, metadata !DIExpression()), !dbg !1812
  %213 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16, ptr noundef nonnull %15, i32 noundef 0) #6, !dbg !1834
  br label %214

214:                                              ; preds = %208, %211
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %16) #6, !dbg !1835
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %15) #6, !dbg !1835
  br label %282, !dbg !1836

215:                                              ; preds = %170, %201
  %216 = phi ptr [ %203, %201 ], [ %171, %170 ]
  %217 = phi i1 [ false, %201 ], [ true, %170 ]
  %218 = phi i32 [ %202, %201 ], [ %168, %170 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !1837, !srcloc !1838
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1553, metadata !DIExpression()), !dbg !1839
  %219 = load i8, ptr %71, align 4, !dbg !1842, !tbaa !1361
  %220 = and i8 %219, 16, !dbg !1843
  %221 = icmp eq i8 %220, 0, !dbg !1844
  %222 = or i1 %217, %221, !dbg !1845
  br i1 %222, label %245, label %223, !dbg !1845

223:                                              ; preds = %215
  call void @llvm.dbg.value(metadata ptr %48, metadata !1846, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.value(metadata i32 %218, metadata !1852, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !1174, metadata ptr %2, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !1175, metadata ptr %3, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata ptr %48, metadata !1860, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata i32 %218, metadata !1863, metadata !DIExpression()), !dbg !1866
  %224 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !1868, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %224, metadata !1623, metadata !DIExpression()), !dbg !1870
  %225 = load volatile i8, ptr %224, align 1, !dbg !1871, !tbaa !1341, !range !1343, !noundef !1344
  %226 = icmp eq i8 %225, 0, !dbg !1871
  br i1 %226, label %230, label %227, !dbg !1872

227:                                              ; preds = %223
  %228 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !1873
  %229 = lshr i64 %228, 8, !dbg !1874
  br label %233, !dbg !1875

230:                                              ; preds = %223
  %231 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !1876
  %232 = udiv i64 %231, 1000000000, !dbg !1878
  br label %233, !dbg !1879

233:                                              ; preds = %227, %230
  %234 = phi i64 [ %229, %227 ], [ %232, %230 ], !dbg !1880
  call void @llvm.dbg.value(metadata i64 %234, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1866
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #6, !dbg !1881
  store i64 %20, ptr %2, align 8, !dbg !1882, !DIAssignID !1883
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1883, metadata ptr %2, metadata !DIExpression()), !dbg !1866
  %235 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !1884
  %236 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1885
  %237 = load i16, ptr %236, align 2, !dbg !1885, !tbaa !1601
  store i16 %237, ptr %235, align 8, !dbg !1884, !tbaa !1602, !DIAssignID !1886
  call void @llvm.dbg.assign(metadata i16 %237, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !1886, metadata ptr %235, metadata !DIExpression()), !dbg !1866
  %238 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !1884
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !1887, metadata ptr %238, metadata !DIExpression()), !dbg !1866
  store i8 1, ptr %238, align 2, !dbg !1884, !DIAssignID !1888
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !1888, metadata ptr %238, metadata !DIExpression()), !dbg !1866
  %239 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !1884
  store i8 0, ptr %239, align 1, !dbg !1884, !tbaa !1607, !DIAssignID !1889
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !1889, metadata ptr %239, metadata !DIExpression()), !dbg !1866
  %240 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !1884
  store i32 0, ptr %240, align 4, !dbg !1884, !tbaa !1609, !DIAssignID !1890
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1890, metadata ptr %240, metadata !DIExpression()), !dbg !1866
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !1891
  %241 = and i64 %234, 4294967295, !dbg !1892
  store i64 %241, ptr %3, align 8, !dbg !1893, !tbaa !1894, !DIAssignID !1895
  call void @llvm.dbg.assign(metadata i64 %241, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1895, metadata ptr %3, metadata !DIExpression()), !dbg !1866
  %242 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !1893
  store i32 %218, ptr %242, align 8, !dbg !1893, !tbaa !1640, !DIAssignID !1896
  call void @llvm.dbg.assign(metadata i32 %218, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1896, metadata ptr %242, metadata !DIExpression()), !dbg !1866
  %243 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !1893
  store i32 0, ptr %243, align 4, !dbg !1893, !tbaa !1897, !DIAssignID !1898
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1898, metadata ptr %243, metadata !DIExpression()), !dbg !1866
  %244 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !1899
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !1900
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #6, !dbg !1900
  br label %245, !dbg !1901

245:                                              ; preds = %233, %215
  %246 = getelementptr inbounds %struct.lb4_backend, ptr %216, i64 0, i32 1, !dbg !1902
  %247 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1903
  %248 = load i16, ptr %247, align 2, !dbg !1903, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !1179, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !1180, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %216, metadata !1911, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i32 %30, metadata !1912, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i16 %25, metadata !1913, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i16 %248, metadata !1914, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #6, !dbg !1920
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !1921, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #6, !dbg !1922
  %249 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !1923
  store i64 0, ptr %249, align 8, !dbg !1923, !DIAssignID !1924
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !1924, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1925, metadata ptr undef, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !1926
  %250 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !1928
  store i64 %250, ptr %8, align 8, !dbg !1929, !tbaa !1930, !DIAssignID !1932
  call void @llvm.dbg.assign(metadata i64 %250, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1932, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  %251 = load i32, ptr %216, align 4, !dbg !1933, !tbaa !1934
  %252 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !1936
  store i32 %251, ptr %252, align 8, !dbg !1937, !tbaa !1938, !DIAssignID !1939
  call void @llvm.dbg.assign(metadata i32 %251, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1939, metadata ptr %252, metadata !DIExpression()), !dbg !1918
  %253 = load i16, ptr %246, align 4, !dbg !1940, !tbaa !1941
  %254 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !1942
  store i16 %253, ptr %254, align 4, !dbg !1943, !tbaa !1944, !DIAssignID !1945
  call void @llvm.dbg.assign(metadata i16 %253, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !1945, metadata ptr %254, metadata !DIExpression()), !dbg !1918
  store i32 %30, ptr %7, align 4, !dbg !1946, !tbaa !1947, !DIAssignID !1949
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1949, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  %255 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !1950
  store i16 %25, ptr %255, align 4, !dbg !1951, !tbaa !1952, !DIAssignID !1953
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1953, metadata ptr %255, metadata !DIExpression()), !dbg !1918
  %256 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !1954
  store i16 %248, ptr %256, align 2, !dbg !1955, !tbaa !1956, !DIAssignID !1957
  call void @llvm.dbg.assign(metadata i16 %248, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1957, metadata ptr %256, metadata !DIExpression()), !dbg !1918
  %257 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #6, !dbg !1958
  call void @llvm.dbg.value(metadata ptr %257, metadata !1915, metadata !DIExpression()), !dbg !1918
  %258 = icmp eq ptr %257, null, !dbg !1959
  br i1 %258, label %264, label %259, !dbg !1961

259:                                              ; preds = %245
  call void @llvm.dbg.value(metadata ptr %257, metadata !1962, metadata !DIExpression()), !dbg !1969
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !1969
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !1969
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !1993
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !1993
  call void @llvm.dbg.value(metadata ptr %257, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !1993
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !1993
  call void @llvm.dbg.label(metadata !1992), !dbg !1995
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !1993
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !1993
  call void @llvm.dbg.value(metadata ptr %257, metadata !1974, metadata !DIExpression()), !dbg !1993
  %260 = load i64, ptr %257, align 8, !dbg !1996, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !1993
  %261 = load i64, ptr %7, align 8, !dbg !1996, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %260, i64 %261), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !1993
  %262 = icmp eq i64 %260, %261, !dbg !1997
  br i1 %262, label %263, label %264, !dbg !1998

263:                                              ; preds = %259
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #6, !dbg !1999
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #6, !dbg !1999
  br label %278, !dbg !2000

264:                                              ; preds = %245, %259
  %265 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #6, !dbg !2001
  call void @llvm.dbg.value(metadata i32 %265, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #6, !dbg !1999
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #6, !dbg !1999
  %266 = icmp slt i32 %265, 0, !dbg !2002
  br i1 %266, label %267, label %278, !dbg !2000

267:                                              ; preds = %264
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1185, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1186, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2003
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #6, !dbg !2006
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2007, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %14) #6, !dbg !2008
  store i64 21504197127, ptr %14, align 8, !dbg !2009, !DIAssignID !2010
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2010, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2011, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2012, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2003
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2013, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2014, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2003
  %268 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14) #6, !dbg !2015
  call void @llvm.dbg.value(metadata ptr %268, metadata !1770, metadata !DIExpression()), !dbg !2003
  %269 = icmp eq ptr %268, null, !dbg !2016
  br i1 %269, label %273, label %270, !dbg !2017

270:                                              ; preds = %267
  %271 = load i64, ptr %268, align 8, !dbg !2018, !tbaa !1790
  %272 = add i64 %271, 1, !dbg !2018
  store i64 %272, ptr %268, align 8, !dbg !2018, !tbaa !1790
  br label %276, !dbg !2019

273:                                              ; preds = %267
  store i64 1, ptr %13, align 8, !dbg !2020, !tbaa !1790, !DIAssignID !2021
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2021, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  %274 = getelementptr inbounds %struct.metrics_value, ptr %13, i64 0, i32 1, !dbg !2022
  store i64 0, ptr %274, align 8, !dbg !2023, !tbaa !1798, !DIAssignID !2024
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2024, metadata ptr %274, metadata !DIExpression()), !dbg !2003
  %275 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14, ptr noundef nonnull %13, i32 noundef 0) #6, !dbg !2025
  br label %276

276:                                              ; preds = %273, %270
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %14) #6, !dbg !2026
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #6, !dbg !2026
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #6, !dbg !2027
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !1173, metadata !DIExpression()), !dbg !1192
  %277 = call i1 @llvm.bpf.passthrough.i1.i1(i32 0, i1 false)
  br label %285, !dbg !2028

278:                                              ; preds = %263, %264
  %279 = load i32, ptr %216, align 4, !dbg !2030, !tbaa !1934
  store i32 %279, ptr %29, align 4, !dbg !2031, !tbaa !1261
  %280 = load i16, ptr %246, align 4, !dbg !2032, !tbaa !1941
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2039
  tail call void @llvm.dbg.value(metadata i16 %280, metadata !2038, metadata !DIExpression()), !dbg !2039
  %281 = zext i16 %280 to i32, !dbg !2041
  store i32 %281, ptr %22, align 8, !dbg !2042, !tbaa !1251
  br label %282, !dbg !2043

282:                                              ; preds = %61, %36, %89, %96, %69, %64, %44, %1, %52, %75, %108, %200, %214, %278
  %283 = phi i1 [ false, %278 ], [ true, %214 ], [ true, %200 ], [ true, %52 ], [ false, %75 ], [ false, %108 ], [ false, %1 ], [ false, %44 ], [ true, %69 ], [ false, %64 ], [ false, %96 ], [ false, %89 ], [ false, %36 ], [ false, %61 ], !dbg !1225
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #6, !dbg !2027
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1173, metadata !DIExpression()), !dbg !1192
  %284 = call i1 @llvm.bpf.passthrough.i1.i1(i32 0, i1 %283)
  br i1 %284, label %285, label %286, !dbg !2028

285:                                              ; preds = %276, %282
  br label %286, !dbg !2044

286:                                              ; preds = %282, %285
  %287 = phi i32 [ 0, %285 ], [ 1, %282 ], !dbg !1192
  ret i32 %287, !dbg !2046
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_sendmsg(ptr noundef %0) #0 section "cgroup/sendmsg4" !dbg !2047 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2051
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !2052
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2053
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !2054
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !2055
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !2056
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2057
  %9 = alloca i32, align 4, !DIAssignID !2058
  %10 = alloca i32, align 4, !DIAssignID !2059
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !2060
  %12 = alloca i32, align 4, !DIAssignID !2061
  %13 = alloca %struct.metrics_value, align 8, !DIAssignID !2062
  %14 = alloca %struct.metrics_key, align 8, !DIAssignID !2063
  %15 = alloca %struct.metrics_value, align 8, !DIAssignID !2064
  %16 = alloca %struct.metrics_key, align 8, !DIAssignID !2065
  %17 = alloca %struct.metrics_value, align 8, !DIAssignID !2066
  %18 = alloca %struct.metrics_key, align 8, !DIAssignID !2067
  %19 = alloca %struct.lb4_key, align 4, !DIAssignID !2068
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2049, metadata !DIExpression()), !dbg !2069
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !2068, metadata ptr %19, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1199, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i1 true, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.value(metadata i1 false, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2072
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !2072
  %20 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #6, !dbg !2074
  call void @llvm.dbg.value(metadata i64 %20, metadata !1234, metadata !DIExpression()), !dbg !2072
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !1203, metadata !DIExpression()), !dbg !2070
  %21 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !2075
  call void @llvm.dbg.value(metadata !DIArgList(i64 %20, i64 %21), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2061, metadata ptr %12, metadata !DIExpression()), !dbg !2076
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2076
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !2078
  %22 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2079
  %23 = load i32, ptr %22, align 8, !dbg !2079, !tbaa !1251
  store volatile i32 %23, ptr %12, align 4, !dbg !2080, !tbaa !1129, !DIAssignID !2081
  call void @llvm.dbg.assign(metadata i32 %23, metadata !1239, metadata !DIExpression(), metadata !2081, metadata ptr %12, metadata !DIExpression()), !dbg !2076
  %24 = load volatile i32, ptr %12, align 4, !dbg !2082, !tbaa !1129
  %25 = trunc i32 %24 to i16, !dbg !2083
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !2084
  call void @llvm.dbg.value(metadata i16 %25, metadata !1211, metadata !DIExpression()), !dbg !2070
  %26 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2085
  %27 = load i32, ptr %26, align 4, !dbg !2085, !tbaa !1259
  %28 = trunc i32 %27 to i8, !dbg !2085
  call void @llvm.dbg.value(metadata i8 %28, metadata !1212, metadata !DIExpression()), !dbg !2070
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !2086
  %30 = load i32, ptr %29, align 4, !dbg !2086, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %30, metadata !1213, metadata !DIExpression()), !dbg !2070
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %19) #6, !dbg !2087
  store i32 %30, ptr %19, align 4, !dbg !2088, !tbaa !1264, !DIAssignID !2089
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2089, metadata ptr %19, metadata !DIExpression()), !dbg !2070
  %31 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 1, !dbg !2088
  store i16 %25, ptr %31, align 4, !dbg !2088, !tbaa !1268, !DIAssignID !2090
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2090, metadata ptr %31, metadata !DIExpression()), !dbg !2070
  %32 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 2, !dbg !2088
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2091, metadata ptr %32, metadata !DIExpression()), !dbg !2070
  %33 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 3, !dbg !2088
  store i8 %28, ptr %33, align 4, !dbg !2088, !tbaa !1271, !DIAssignID !2092
  call void @llvm.dbg.assign(metadata i8 %28, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2092, metadata ptr %33, metadata !DIExpression()), !dbg !2070
  %34 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 4, !dbg !2088
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2093, metadata ptr %34, metadata !DIExpression()), !dbg !2070
  %35 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 5, !dbg !2088
  store i16 0, ptr %35, align 2, !dbg !2088, !DIAssignID !2094
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2094, metadata ptr %35, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %19, metadata !1289, metadata !DIExpression()), !dbg !2095
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2095
  store i16 0, ptr %32, align 2, !dbg !2097, !tbaa !1298
  store i8 0, ptr %34, align 1, !dbg !2098, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2099
  %36 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !2101
  call void @llvm.dbg.value(metadata ptr %36, metadata !1291, metadata !DIExpression()), !dbg !2095
  %37 = icmp eq ptr %36, null, !dbg !2102
  br i1 %37, label %281, label %38, !dbg !2103

38:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata ptr %36, metadata !1312, metadata !DIExpression()), !dbg !2104
  %39 = getelementptr inbounds %struct.lb4_service, ptr %36, i64 0, i32 4, !dbg !2106
  %40 = load i8, ptr %39, align 1, !dbg !2106, !tbaa !1321
  %41 = and i8 %40, 32, !dbg !2107
  %42 = icmp eq i8 %41, 0, !dbg !2108
  br i1 %42, label %46, label %43, !dbg !2109

43:                                               ; preds = %38
  store i8 1, ptr %34, align 1, !dbg !2110, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2111
  %44 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !2113
  call void @llvm.dbg.value(metadata ptr %44, metadata !1208, metadata !DIExpression()), !dbg !2070
  %45 = icmp eq ptr %44, null, !dbg !2114
  br i1 %45, label %281, label %46, !dbg !2115

46:                                               ; preds = %38, %43
  %47 = phi ptr [ %44, %43 ], [ %36, %38 ]
  call void @llvm.dbg.value(metadata ptr %47, metadata !1208, metadata !DIExpression()), !dbg !2070
  %48 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 1, !dbg !2116
  %49 = load i16, ptr %48, align 4, !dbg !2116, !tbaa !1334
  %50 = icmp eq i16 %49, 0, !dbg !2117
  br i1 %50, label %51, label %69, !dbg !2118

51:                                               ; preds = %46
  %52 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !2119, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %52, metadata !1217, metadata !DIExpression()), !dbg !2120
  %53 = load volatile i8, ptr %52, align 1, !dbg !2121, !tbaa !1341, !range !1343, !noundef !1344
  %54 = icmp eq i8 %53, 0, !dbg !2121
  br i1 %54, label %55, label %281, !dbg !2122

55:                                               ; preds = %51
  call void @llvm.dbg.value(metadata ptr %47, metadata !1346, metadata !DIExpression()), !dbg !2123
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1354, metadata !DIExpression()), !dbg !2125
  %56 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 3, !dbg !2127
  %57 = load i8, ptr %56, align 4, !dbg !2127, !tbaa !1361
  %58 = and i8 %57, 35, !dbg !2128
  %59 = icmp eq i8 %58, 0, !dbg !2129
  br i1 %59, label %63, label %60, !dbg !2130

60:                                               ; preds = %55
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1365, metadata !DIExpression()), !dbg !2131
  %61 = and i8 %57, 4, !dbg !2133
  %62 = icmp eq i8 %61, 0, !dbg !2134
  br i1 %62, label %281, label %68, !dbg !2135

63:                                               ; preds = %55
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1354, metadata !DIExpression()), !dbg !2136
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1375, metadata !DIExpression()), !dbg !2138
  %64 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2140
  %65 = load i8, ptr %64, align 1, !dbg !2140, !tbaa !1321
  %66 = and i8 %65, 16, !dbg !2141
  %67 = icmp eq i8 %66, 0, !dbg !2142
  br i1 %67, label %281, label %68, !dbg !2143

68:                                               ; preds = %63, %60
  br label %281, !dbg !2144

69:                                               ; preds = %46
  call void @llvm.dbg.value(metadata ptr %47, metadata !1385, metadata !DIExpression()), !dbg !2145
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1391, metadata !DIExpression()), !dbg !2147
  %70 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 3, !dbg !2149
  %71 = load i8, ptr %70, align 4, !dbg !2149, !tbaa !1361
  %72 = and i8 %71, 8, !dbg !2150
  %73 = icmp eq i8 %72, 0, !dbg !2151
  br i1 %73, label %74, label %79, !dbg !2152

74:                                               ; preds = %69
  %75 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2153
  %76 = load i8, ptr %75, align 1, !dbg !2153, !tbaa !1321
  %77 = and i8 %76, 8, !dbg !2154
  %78 = icmp eq i8 %77, 0, !dbg !2152
  br i1 %78, label %85, label %281, !dbg !2155

79:                                               ; preds = %69
  call void @llvm.dbg.value(metadata ptr %47, metadata !1403, metadata !DIExpression()), !dbg !2156
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !2156
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1417, metadata !DIExpression()), !dbg !2158
  %80 = and i8 %71, 1, !dbg !2160
  %81 = icmp eq i8 %80, 0, !dbg !2161
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1391, metadata !DIExpression()), !dbg !2162
  %82 = and i32 %30, 255
  %83 = icmp eq i32 %82, 127
  %84 = select i1 %81, i1 %83, i1 false, !dbg !2164
  br i1 %84, label %98, label %88, !dbg !2164

85:                                               ; preds = %74
  call void @llvm.dbg.value(metadata ptr %47, metadata !1403, metadata !DIExpression()), !dbg !2156
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !2156
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1417, metadata !DIExpression()), !dbg !2158
  %86 = and i8 %71, 1, !dbg !2160
  %87 = icmp eq i8 %86, 0, !dbg !2161
  br i1 %87, label %98, label %88, !dbg !2164

88:                                               ; preds = %85, %79
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !2055, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 %30, metadata !1433, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !2165
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #6, !dbg !2167
  %89 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !2168
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %89, i8 0, i64 18, i1 false), !dbg !2168, !DIAssignID !2169
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !2169, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !2170, metadata ptr undef, metadata !DIExpression()), !dbg !2165
  store i32 64, ptr %6, align 4, !dbg !2171, !tbaa.struct !1443, !DIAssignID !2172
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2172, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  %90 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !2173
  store i8 1, ptr %90, align 1, !dbg !2174, !tbaa !1448, !DIAssignID !2175
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !2175, metadata ptr %90, metadata !DIExpression()), !dbg !2165
  %91 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !2176
  store i32 %30, ptr %91, align 4, !dbg !2177, !tbaa !1444, !DIAssignID !2178
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2178, metadata ptr %91, metadata !DIExpression()), !dbg !2165
  %92 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !2179
  store i16 0, ptr %92, align 4, !dbg !2180, !tbaa !1457, !DIAssignID !2181
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2181, metadata ptr %92, metadata !DIExpression()), !dbg !2165
  %93 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #6, !dbg !2182
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #6, !dbg !2183
  call void @llvm.dbg.value(metadata ptr %93, metadata !1409, metadata !DIExpression()), !dbg !2184
  %94 = icmp eq ptr %93, null, !dbg !2185
  br i1 %94, label %281, label %95, !dbg !2186

95:                                               ; preds = %88
  %96 = load i32, ptr %93, align 4, !dbg !2187, !tbaa !1466
  %97 = icmp eq i32 %96, 1, !dbg !2188
  br i1 %97, label %98, label %281, !dbg !2189

98:                                               ; preds = %79, %85, %95
  %99 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !2190, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %99, metadata !1222, metadata !DIExpression()), !dbg !2191
  %100 = load volatile i8, ptr %99, align 1, !dbg !2192, !tbaa !1341, !range !1343, !noundef !1344
  %101 = icmp eq i8 %100, 0, !dbg !2192
  br i1 %101, label %113, label %102, !dbg !2193

102:                                              ; preds = %98
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1475, metadata !DIExpression()), !dbg !2194
  %103 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2196
  %104 = load i8, ptr %103, align 1, !dbg !2196, !tbaa !1321
  %105 = and i8 %104, 1, !dbg !2197
  %106 = icmp eq i8 %105, 0, !dbg !2198
  br i1 %106, label %113, label %107, !dbg !2199

107:                                              ; preds = %102
  %108 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !2200
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !2060, metadata ptr %11, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i64 %108, metadata !1490, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i32 %30, metadata !1491, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i16 %25, metadata !1492, metadata !DIExpression()), !dbg !2201
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #6, !dbg !2203
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !2206
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2206
  call void @llvm.dbg.label(metadata !1527), !dbg !2208
  %109 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !2209
  call void @llvm.dbg.value(metadata ptr %109, metadata !1512, metadata !DIExpression()), !dbg !2206
  store i64 0, ptr %109, align 8, !dbg !2209, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !2210
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !2206
  store i64 %108, ptr %11, align 8, !dbg !2211, !tbaa !1538, !DIAssignID !2212
  call void @llvm.dbg.assign(metadata i64 %108, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2212, metadata ptr %11, metadata !DIExpression()), !dbg !2201
  store i32 %30, ptr %109, align 8, !dbg !2213, !tbaa !1542, !DIAssignID !2214
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2214, metadata ptr %109, metadata !DIExpression()), !dbg !2201
  %110 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !2215
  store i16 %25, ptr %110, align 4, !dbg !2216, !tbaa !1546, !DIAssignID !2217
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2217, metadata ptr %110, metadata !DIExpression()), !dbg !2201
  %111 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #6, !dbg !2218
  call void @llvm.dbg.value(metadata ptr %111, metadata !1493, metadata !DIExpression()), !dbg !2201
  %112 = icmp eq ptr %111, null, !dbg !2219
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #6, !dbg !2220
  br i1 %112, label %113, label %281, !dbg !2221

113:                                              ; preds = %107, %102, %98
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1553, metadata !DIExpression()), !dbg !2222
  %114 = load i8, ptr %70, align 4, !dbg !2224, !tbaa !1361
  %115 = and i8 %114, 16, !dbg !2225
  %116 = icmp eq i8 %115, 0, !dbg !2226
  br i1 %116, label %172, label %117, !dbg !2227

117:                                              ; preds = %113
  call void @llvm.dbg.value(metadata ptr %47, metadata !1563, metadata !DIExpression()), !dbg !2228
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !2228
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !2053, metadata ptr %4, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !2054, metadata ptr %5, metadata !DIExpression()), !dbg !2232
  call void @llvm.dbg.value(metadata ptr %47, metadata !1580, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !2230
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #6, !dbg !2233
  store i64 %20, ptr %4, align 8, !dbg !2234, !DIAssignID !2235
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2235, metadata ptr %4, metadata !DIExpression()), !dbg !2230
  %118 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !2236
  %119 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2237
  %120 = load i16, ptr %119, align 2, !dbg !2237, !tbaa !1601
  store i16 %120, ptr %118, align 8, !dbg !2236, !tbaa !1602, !DIAssignID !2238
  call void @llvm.dbg.assign(metadata i16 %120, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !2238, metadata ptr %118, metadata !DIExpression()), !dbg !2230
  %121 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !2236
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !2239, metadata ptr %121, metadata !DIExpression()), !dbg !2230
  store i8 1, ptr %121, align 2, !dbg !2236, !DIAssignID !2240
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !2240, metadata ptr %121, metadata !DIExpression()), !dbg !2230
  %122 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !2236
  store i8 0, ptr %122, align 1, !dbg !2236, !tbaa !1607, !DIAssignID !2241
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !2241, metadata ptr %122, metadata !DIExpression()), !dbg !2230
  %123 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !2236
  store i32 0, ptr %123, align 4, !dbg !2236, !tbaa !1609, !DIAssignID !2242
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2242, metadata ptr %123, metadata !DIExpression()), !dbg !2230
  %124 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #6, !dbg !2243
  call void @llvm.dbg.value(metadata ptr %124, metadata !1583, metadata !DIExpression()), !dbg !2230
  %125 = icmp eq ptr %124, null, !dbg !2244
  br i1 %125, label %126, label %127, !dbg !2245

126:                                              ; preds = %117
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !2246
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  br label %172, !dbg !2247

127:                                              ; preds = %117
  %128 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !2248, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %128, metadata !1623, metadata !DIExpression()), !dbg !2250
  %129 = load volatile i8, ptr %128, align 1, !dbg !2251, !tbaa !1341, !range !1343, !noundef !1344
  %130 = icmp eq i8 %129, 0, !dbg !2251
  br i1 %130, label %134, label %131, !dbg !2252

131:                                              ; preds = %127
  %132 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !2253
  %133 = lshr i64 %132, 8, !dbg !2254
  br label %137, !dbg !2255

134:                                              ; preds = %127
  %135 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !2256
  %136 = udiv i64 %135, 1000000000, !dbg !2258
  br label %137, !dbg !2259

137:                                              ; preds = %131, %134
  %138 = phi i64 [ %133, %131 ], [ %136, %134 ], !dbg !2260
  call void @llvm.dbg.value(metadata i64 %138, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2232
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #6, !dbg !2261
  %139 = getelementptr inbounds %struct.lb_affinity_val, ptr %124, i64 0, i32 1, !dbg !2262
  %140 = load i32, ptr %139, align 1, !dbg !2262, !tbaa !1640
  store i32 %140, ptr %5, align 4, !dbg !2263, !tbaa !1643, !DIAssignID !2264
  call void @llvm.dbg.assign(metadata i32 %140, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2264, metadata ptr %5, metadata !DIExpression()), !dbg !2232
  %141 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !2263
  %142 = load i16, ptr %119, align 2, !dbg !2265, !tbaa !1601
  store i16 %142, ptr %141, align 4, !dbg !2263, !tbaa !1647, !DIAssignID !2266
  call void @llvm.dbg.assign(metadata i16 %142, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2266, metadata ptr %141, metadata !DIExpression()), !dbg !2232
  %143 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !2263
  store i16 0, ptr %143, align 2, !dbg !2263, !tbaa !1649, !DIAssignID !2267
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2267, metadata ptr %143, metadata !DIExpression()), !dbg !2232
  %144 = load volatile i64, ptr %124, align 1, !dbg !2268, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %144, metadata !1588, metadata !DIExpression()), !dbg !2269
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2270, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1658, metadata !DIExpression()), !dbg !2272
  %145 = load i32, ptr %47, align 4, !dbg !2274, !tbaa !1444
  %146 = and i32 %145, 16777215, !dbg !2275
  call void @llvm.dbg.value(metadata i32 %146, metadata !1667, metadata !DIExpression()), !dbg !2276
  %147 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !2278, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %147, metadata !1672, metadata !DIExpression()), !dbg !2279
  %148 = load volatile i8, ptr %147, align 1, !dbg !2280, !tbaa !1341, !range !1343, !noundef !1344
  %149 = icmp eq i8 %148, 0, !dbg !2280
  br i1 %149, label %155, label %150, !dbg !2281

150:                                              ; preds = %137
  %151 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !2282, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %151, metadata !1675, metadata !DIExpression()), !dbg !2283
  %152 = load volatile i32, ptr %151, align 4, !dbg !2284, !tbaa !1129
  %153 = mul i32 %152, %146, !dbg !2285
  %154 = lshr i32 %153, 8, !dbg !2286
  br label %155, !dbg !2287

155:                                              ; preds = %137, %150
  %156 = phi i32 [ %154, %150 ], [ %146, %137 ], !dbg !2276
  %157 = zext nneg i32 %156 to i64, !dbg !2288
  %158 = add i64 %144, %157, !dbg !2289
  %159 = and i64 %138, 4294967295, !dbg !2290
  %160 = icmp ugt i64 %158, %159, !dbg !2291
  br i1 %160, label %161, label %164, !dbg !2292

161:                                              ; preds = %155
  %162 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #6, !dbg !2293
  %163 = icmp eq ptr %162, null, !dbg !2293
  br i1 %163, label %164, label %166, !dbg !2294

164:                                              ; preds = %161, %155
  %165 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #6, !dbg !2232
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !2246
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  br label %172, !dbg !2247

166:                                              ; preds = %161
  call void @llvm.dbg.value(metadata i64 %159, metadata !1591, metadata !DIExpression()), !dbg !2296
  store volatile i64 %159, ptr %124, align 1, !dbg !2297, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2298, !srcloc !1657
  %167 = load i32, ptr %139, align 1, !dbg !2300, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !2246
  call void @llvm.dbg.value(metadata i32 %167, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  %168 = icmp eq i32 %167, 0, !dbg !2301
  br i1 %168, label %172, label %169, !dbg !2247

169:                                              ; preds = %166
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2059, metadata ptr %10, metadata !DIExpression()), !dbg !2302
  store i32 %167, ptr %10, align 4, !tbaa !1129, !DIAssignID !2304
  call void @llvm.dbg.assign(metadata i32 %167, metadata !1707, metadata !DIExpression(), metadata !2304, metadata ptr %10, metadata !DIExpression()), !dbg !2302
  %170 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #6, !dbg !2305
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !2306
  call void @llvm.dbg.value(metadata ptr %170, metadata !1205, metadata !DIExpression()), !dbg !2070
  %171 = icmp eq ptr %170, null, !dbg !2307
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2308, !srcloc !1721
  br i1 %171, label %172, label %214, !dbg !2309

172:                                              ; preds = %169, %166, %113, %126, %164
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !2310
  %173 = load i32, ptr %26, align 4, !dbg !2312, !tbaa !1259
  %174 = and i32 %173, 255, !dbg !2312
  %175 = icmp eq i32 %174, 6, !dbg !2313
  br i1 %175, label %176, label %179, !dbg !2312

176:                                              ; preds = %172
  %177 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !2314
  %178 = zext i32 %177 to i64, !dbg !2314
  br label %181, !dbg !2312

179:                                              ; preds = %172
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2315
  %180 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !2317
  br label %181, !dbg !2312

181:                                              ; preds = %176, %179
  %182 = phi i64 [ %178, %176 ], [ %180, %179 ], !dbg !2312
  %183 = load i16, ptr %48, align 4, !dbg !2318, !tbaa !1334
  %184 = zext i16 %183 to i64, !dbg !2319
  %185 = urem i64 %182, %184, !dbg !2320
  %186 = trunc i64 %185 to i16, !dbg !2321
  %187 = add nuw i16 %186, 1, !dbg !2321
  store i16 %187, ptr %32, align 2, !dbg !2322, !tbaa !1298, !DIAssignID !2323
  call void @llvm.dbg.assign(metadata i16 %187, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2323, metadata ptr %32, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %19, metadata !1749, metadata !DIExpression()), !dbg !2324
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2326
  %188 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #6, !dbg !2328
  call void @llvm.dbg.value(metadata ptr %188, metadata !1214, metadata !DIExpression()), !dbg !2070
  %189 = icmp eq ptr %188, null, !dbg !2329
  br i1 %189, label %190, label %200, !dbg !2330

190:                                              ; preds = %181
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2066, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2067, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2331
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %17) #6, !dbg !2333
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2334, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %18) #6, !dbg !2335
  store i64 21502558725, ptr %18, align 8, !dbg !2336, !DIAssignID !2337
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2337, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2338, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2339, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2331
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2340, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2341, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2331
  %191 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18) #6, !dbg !2342
  call void @llvm.dbg.value(metadata ptr %191, metadata !1770, metadata !DIExpression()), !dbg !2331
  %192 = icmp eq ptr %191, null, !dbg !2343
  br i1 %192, label %196, label %193, !dbg !2344

193:                                              ; preds = %190
  %194 = load i64, ptr %191, align 8, !dbg !2345, !tbaa !1790
  %195 = add i64 %194, 1, !dbg !2345
  store i64 %195, ptr %191, align 8, !dbg !2345, !tbaa !1790
  br label %199, !dbg !2346

196:                                              ; preds = %190
  store i64 1, ptr %17, align 8, !dbg !2347, !tbaa !1790, !DIAssignID !2348
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2348, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  %197 = getelementptr inbounds %struct.metrics_value, ptr %17, i64 0, i32 1, !dbg !2349
  store i64 0, ptr %197, align 8, !dbg !2350, !tbaa !1798, !DIAssignID !2351
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2351, metadata ptr %197, metadata !DIExpression()), !dbg !2331
  %198 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #6, !dbg !2352
  br label %199

199:                                              ; preds = %193, %196
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %18) #6, !dbg !2353
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %17) #6, !dbg !2353
  br label %281, !dbg !2354

200:                                              ; preds = %181
  %201 = load i32, ptr %188, align 4, !dbg !2355, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %201, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2058, metadata ptr %9, metadata !DIExpression()), !dbg !2356
  store i32 %201, ptr %9, align 4, !tbaa !1129, !DIAssignID !2358
  call void @llvm.dbg.assign(metadata i32 %201, metadata !1707, metadata !DIExpression(), metadata !2358, metadata ptr %9, metadata !DIExpression()), !dbg !2356
  %202 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #6, !dbg !2359
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !2360
  call void @llvm.dbg.value(metadata ptr %202, metadata !1205, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !2070
  %203 = icmp eq ptr %202, null, !dbg !2361
  br i1 %203, label %204, label %214, !dbg !2362

204:                                              ; preds = %200
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2064, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2065, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2363
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %15) #6, !dbg !2365
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2366, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %16) #6, !dbg !2367
  store i64 21503148550, ptr %16, align 8, !dbg !2368, !DIAssignID !2369
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2369, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2370, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2371, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2363
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2372, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2373, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2363
  %205 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16) #6, !dbg !2374
  call void @llvm.dbg.value(metadata ptr %205, metadata !1770, metadata !DIExpression()), !dbg !2363
  %206 = icmp eq ptr %205, null, !dbg !2375
  br i1 %206, label %210, label %207, !dbg !2376

207:                                              ; preds = %204
  %208 = load i64, ptr %205, align 8, !dbg !2377, !tbaa !1790
  %209 = add i64 %208, 1, !dbg !2377
  store i64 %209, ptr %205, align 8, !dbg !2377, !tbaa !1790
  br label %213, !dbg !2378

210:                                              ; preds = %204
  store i64 1, ptr %15, align 8, !dbg !2379, !tbaa !1790, !DIAssignID !2380
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2380, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  %211 = getelementptr inbounds %struct.metrics_value, ptr %15, i64 0, i32 1, !dbg !2381
  store i64 0, ptr %211, align 8, !dbg !2382, !tbaa !1798, !DIAssignID !2383
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2383, metadata ptr %211, metadata !DIExpression()), !dbg !2363
  %212 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16, ptr noundef nonnull %15, i32 noundef 0) #6, !dbg !2384
  br label %213

213:                                              ; preds = %207, %210
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %16) #6, !dbg !2385
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %15) #6, !dbg !2385
  br label %281, !dbg !2386

214:                                              ; preds = %169, %200
  %215 = phi ptr [ %202, %200 ], [ %170, %169 ]
  %216 = phi i1 [ false, %200 ], [ true, %169 ]
  %217 = phi i32 [ %201, %200 ], [ %167, %169 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2387, !srcloc !1838
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1553, metadata !DIExpression()), !dbg !2388
  %218 = load i8, ptr %70, align 4, !dbg !2390, !tbaa !1361
  %219 = and i8 %218, 16, !dbg !2391
  %220 = icmp eq i8 %219, 0, !dbg !2392
  %221 = or i1 %216, %220, !dbg !2393
  br i1 %221, label %244, label %222, !dbg !2393

222:                                              ; preds = %214
  call void @llvm.dbg.value(metadata ptr %47, metadata !1846, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.value(metadata i32 %217, metadata !1852, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !2051, metadata ptr %2, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !2052, metadata ptr %3, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata ptr %47, metadata !1860, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata i32 %217, metadata !1863, metadata !DIExpression()), !dbg !2396
  %223 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !2398, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %223, metadata !1623, metadata !DIExpression()), !dbg !2400
  %224 = load volatile i8, ptr %223, align 1, !dbg !2401, !tbaa !1341, !range !1343, !noundef !1344
  %225 = icmp eq i8 %224, 0, !dbg !2401
  br i1 %225, label %229, label %226, !dbg !2402

226:                                              ; preds = %222
  %227 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !2403
  %228 = lshr i64 %227, 8, !dbg !2404
  br label %232, !dbg !2405

229:                                              ; preds = %222
  %230 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !2406
  %231 = udiv i64 %230, 1000000000, !dbg !2408
  br label %232, !dbg !2409

232:                                              ; preds = %226, %229
  %233 = phi i64 [ %228, %226 ], [ %231, %229 ], !dbg !2410
  call void @llvm.dbg.value(metadata i64 %233, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2396
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #6, !dbg !2411
  store i64 %20, ptr %2, align 8, !dbg !2412, !DIAssignID !2413
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2413, metadata ptr %2, metadata !DIExpression()), !dbg !2396
  %234 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !2414
  %235 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2415
  %236 = load i16, ptr %235, align 2, !dbg !2415, !tbaa !1601
  store i16 %236, ptr %234, align 8, !dbg !2414, !tbaa !1602, !DIAssignID !2416
  call void @llvm.dbg.assign(metadata i16 %236, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !2416, metadata ptr %234, metadata !DIExpression()), !dbg !2396
  %237 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !2414
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !2417, metadata ptr %237, metadata !DIExpression()), !dbg !2396
  store i8 1, ptr %237, align 2, !dbg !2414, !DIAssignID !2418
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !2418, metadata ptr %237, metadata !DIExpression()), !dbg !2396
  %238 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !2414
  store i8 0, ptr %238, align 1, !dbg !2414, !tbaa !1607, !DIAssignID !2419
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !2419, metadata ptr %238, metadata !DIExpression()), !dbg !2396
  %239 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !2414
  store i32 0, ptr %239, align 4, !dbg !2414, !tbaa !1609, !DIAssignID !2420
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2420, metadata ptr %239, metadata !DIExpression()), !dbg !2396
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !2421
  %240 = and i64 %233, 4294967295, !dbg !2422
  store i64 %240, ptr %3, align 8, !dbg !2423, !tbaa !1894, !DIAssignID !2424
  call void @llvm.dbg.assign(metadata i64 %240, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2424, metadata ptr %3, metadata !DIExpression()), !dbg !2396
  %241 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !2423
  store i32 %217, ptr %241, align 8, !dbg !2423, !tbaa !1640, !DIAssignID !2425
  call void @llvm.dbg.assign(metadata i32 %217, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2425, metadata ptr %241, metadata !DIExpression()), !dbg !2396
  %242 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !2423
  store i32 0, ptr %242, align 4, !dbg !2423, !tbaa !1897, !DIAssignID !2426
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2426, metadata ptr %242, metadata !DIExpression()), !dbg !2396
  %243 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !2427
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !2428
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #6, !dbg !2428
  br label %244, !dbg !2429

244:                                              ; preds = %232, %214
  %245 = getelementptr inbounds %struct.lb4_backend, ptr %215, i64 0, i32 1, !dbg !2430
  %246 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2431
  %247 = load i16, ptr %246, align 2, !dbg !2431, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !2056, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !2057, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %215, metadata !1911, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i32 %30, metadata !1912, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i16 %25, metadata !1913, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i16 %247, metadata !1914, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #6, !dbg !2434
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !2435, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #6, !dbg !2436
  %248 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !2437
  store i64 0, ptr %248, align 8, !dbg !2437, !DIAssignID !2438
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !2438, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2439, metadata ptr undef, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2440
  %249 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !2442
  store i64 %249, ptr %8, align 8, !dbg !2443, !tbaa !1930, !DIAssignID !2444
  call void @llvm.dbg.assign(metadata i64 %249, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2444, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  %250 = load i32, ptr %215, align 4, !dbg !2445, !tbaa !1934
  %251 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !2446
  store i32 %250, ptr %251, align 8, !dbg !2447, !tbaa !1938, !DIAssignID !2448
  call void @llvm.dbg.assign(metadata i32 %250, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2448, metadata ptr %251, metadata !DIExpression()), !dbg !2432
  %252 = load i16, ptr %245, align 4, !dbg !2449, !tbaa !1941
  %253 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !2450
  store i16 %252, ptr %253, align 4, !dbg !2451, !tbaa !1944, !DIAssignID !2452
  call void @llvm.dbg.assign(metadata i16 %252, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2452, metadata ptr %253, metadata !DIExpression()), !dbg !2432
  store i32 %30, ptr %7, align 4, !dbg !2453, !tbaa !1947, !DIAssignID !2454
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2454, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  %254 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !2455
  store i16 %25, ptr %254, align 4, !dbg !2456, !tbaa !1952, !DIAssignID !2457
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2457, metadata ptr %254, metadata !DIExpression()), !dbg !2432
  %255 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !2458
  store i16 %247, ptr %255, align 2, !dbg !2459, !tbaa !1956, !DIAssignID !2460
  call void @llvm.dbg.assign(metadata i16 %247, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2460, metadata ptr %255, metadata !DIExpression()), !dbg !2432
  %256 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #6, !dbg !2461
  call void @llvm.dbg.value(metadata ptr %256, metadata !1915, metadata !DIExpression()), !dbg !2432
  %257 = icmp eq ptr %256, null, !dbg !2462
  br i1 %257, label %263, label %258, !dbg !2463

258:                                              ; preds = %244
  call void @llvm.dbg.value(metadata ptr %256, metadata !1962, metadata !DIExpression()), !dbg !2464
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !2464
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !2464
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !2466
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !2466
  call void @llvm.dbg.value(metadata ptr %256, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !2466
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !2466
  call void @llvm.dbg.label(metadata !1992), !dbg !2468
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !2466
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !2466
  call void @llvm.dbg.value(metadata ptr %256, metadata !1974, metadata !DIExpression()), !dbg !2466
  %259 = load i64, ptr %256, align 8, !dbg !2469, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !2466
  %260 = load i64, ptr %7, align 8, !dbg !2469, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %259, i64 %260), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !2466
  %261 = icmp eq i64 %259, %260, !dbg !2470
  br i1 %261, label %262, label %263, !dbg !2471

262:                                              ; preds = %258
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #6, !dbg !2472
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #6, !dbg !2472
  br label %277, !dbg !2473

263:                                              ; preds = %244, %258
  %264 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #6, !dbg !2474
  call void @llvm.dbg.value(metadata i32 %264, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #6, !dbg !2472
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #6, !dbg !2472
  %265 = icmp slt i32 %264, 0, !dbg !2475
  br i1 %265, label %266, label %277, !dbg !2473

266:                                              ; preds = %263
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2062, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2063, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2476
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #6, !dbg !2478
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2479, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %14) #6, !dbg !2480
  store i64 21504197127, ptr %14, align 8, !dbg !2481, !DIAssignID !2482
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2482, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2483, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2484, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2476
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2485, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2486, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2476
  %267 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14) #6, !dbg !2487
  call void @llvm.dbg.value(metadata ptr %267, metadata !1770, metadata !DIExpression()), !dbg !2476
  %268 = icmp eq ptr %267, null, !dbg !2488
  br i1 %268, label %272, label %269, !dbg !2489

269:                                              ; preds = %266
  %270 = load i64, ptr %267, align 8, !dbg !2490, !tbaa !1790
  %271 = add i64 %270, 1, !dbg !2490
  store i64 %271, ptr %267, align 8, !dbg !2490, !tbaa !1790
  br label %275, !dbg !2491

272:                                              ; preds = %266
  store i64 1, ptr %13, align 8, !dbg !2492, !tbaa !1790, !DIAssignID !2493
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2493, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  %273 = getelementptr inbounds %struct.metrics_value, ptr %13, i64 0, i32 1, !dbg !2494
  store i64 0, ptr %273, align 8, !dbg !2495, !tbaa !1798, !DIAssignID !2496
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2496, metadata ptr %273, metadata !DIExpression()), !dbg !2476
  %274 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14, ptr noundef nonnull %13, i32 noundef 0) #6, !dbg !2497
  br label %275

275:                                              ; preds = %272, %269
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %14) #6, !dbg !2498
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #6, !dbg !2498
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #6, !dbg !2499
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !2050, metadata !DIExpression()), !dbg !2069
  %276 = call i1 @llvm.bpf.passthrough.i1.i1(i32 1, i1 false)
  br label %284, !dbg !2500

277:                                              ; preds = %262, %263
  %278 = load i32, ptr %215, align 4, !dbg !2502, !tbaa !1934
  store i32 %278, ptr %29, align 4, !dbg !2503, !tbaa !1261
  %279 = load i16, ptr %245, align 4, !dbg !2504, !tbaa !1941
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2505
  tail call void @llvm.dbg.value(metadata i16 %279, metadata !2038, metadata !DIExpression()), !dbg !2505
  %280 = zext i16 %279 to i32, !dbg !2507
  store i32 %280, ptr %22, align 8, !dbg !2508, !tbaa !1251
  br label %281, !dbg !2509

281:                                              ; preds = %60, %1, %88, %95, %68, %63, %43, %51, %74, %107, %199, %213, %277
  %282 = phi i1 [ false, %277 ], [ true, %213 ], [ true, %199 ], [ true, %51 ], [ false, %74 ], [ false, %107 ], [ false, %43 ], [ true, %68 ], [ false, %63 ], [ false, %95 ], [ false, %88 ], [ false, %1 ], [ false, %60 ], !dbg !2070
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #6, !dbg !2499
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2050, metadata !DIExpression()), !dbg !2069
  %283 = call i1 @llvm.bpf.passthrough.i1.i1(i32 1, i1 %282)
  br i1 %283, label %284, label %285, !dbg !2500

284:                                              ; preds = %275, %281
  br label %285, !dbg !2510

285:                                              ; preds = %281, %284
  %286 = phi i32 [ 0, %284 ], [ 1, %281 ], !dbg !2069
  ret i32 %286, !dbg !2512
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_recvmsg(ptr noundef %0) #0 section "cgroup/recvmsg4" !dbg !2513 {
  %2 = alloca i32, align 4, !DIAssignID !2516
  %3 = alloca %struct.metrics_value, align 8, !DIAssignID !2517
  %4 = alloca %struct.metrics_key, align 8, !DIAssignID !2518
  %5 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2519
  %6 = alloca %struct.lb4_key, align 4, !DIAssignID !2520
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2515, metadata !DIExpression()), !dbg !2521
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2522, metadata !DIExpression(), metadata !2519, metadata ptr %5, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2536, metadata !DIExpression(), metadata !2520, metadata ptr %6, metadata !DIExpression()), !dbg !2539
  call void @llvm.dbg.value(metadata ptr %0, metadata !2527, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.value(metadata ptr %0, metadata !2528, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2516, metadata ptr %2, metadata !DIExpression()), !dbg !2540
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2540
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2), !dbg !2542
  %7 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2543
  %8 = load i32, ptr %7, align 8, !dbg !2543, !tbaa !1251
  store volatile i32 %8, ptr %2, align 4, !dbg !2544, !tbaa !1129, !DIAssignID !2545
  call void @llvm.dbg.assign(metadata i32 %8, metadata !1239, metadata !DIExpression(), metadata !2545, metadata ptr %2, metadata !DIExpression()), !dbg !2540
  %9 = load volatile i32, ptr %2, align 4, !dbg !2546, !tbaa !1129
  %10 = trunc i32 %9 to i16, !dbg !2547
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2), !dbg !2548
  call void @llvm.dbg.value(metadata i16 %10, metadata !2530, metadata !DIExpression()), !dbg !2537
  %11 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2549
  %12 = load i32, ptr %11, align 4, !dbg !2549, !tbaa !1259
  call void @llvm.dbg.value(metadata i32 %12, metadata !2531, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2537
  %13 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !2550
  %14 = load i32, ptr %13, align 4, !dbg !2550, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %14, metadata !2532, metadata !DIExpression()), !dbg !2537
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %5) #6, !dbg !2551
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2552
  %15 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef %0) #6, !dbg !2554
  store i64 %15, ptr %5, align 8, !dbg !2555, !tbaa !1930, !DIAssignID !2556
  call void @llvm.dbg.assign(metadata i64 %15, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2556, metadata ptr %5, metadata !DIExpression()), !dbg !2537
  %16 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 1, !dbg !2555
  store i32 %14, ptr %16, align 8, !dbg !2555, !tbaa !1938, !DIAssignID !2557
  call void @llvm.dbg.assign(metadata i32 %14, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2557, metadata ptr %16, metadata !DIExpression()), !dbg !2537
  %17 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 2, !dbg !2555
  store i16 %10, ptr %17, align 4, !dbg !2555, !tbaa !1944, !DIAssignID !2558
  call void @llvm.dbg.assign(metadata i16 %10, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2558, metadata ptr %17, metadata !DIExpression()), !dbg !2537
  %18 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 3, !dbg !2555
  store i16 0, ptr %18, align 2, !dbg !2555, !tbaa !2559, !DIAssignID !2560
  call void @llvm.dbg.assign(metadata i16 0, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 112, 16), metadata !2560, metadata ptr %18, metadata !DIExpression()), !dbg !2537
  %19 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %5) #6, !dbg !2561
  call void @llvm.dbg.value(metadata ptr %19, metadata !2529, metadata !DIExpression()), !dbg !2537
  %20 = icmp eq ptr %19, null, !dbg !2562
  br i1 %20, label %71, label %21, !dbg !2563

21:                                               ; preds = %1
  %22 = trunc i32 %12 to i8, !dbg !2549
  call void @llvm.dbg.value(metadata i8 %22, metadata !2531, metadata !DIExpression()), !dbg !2537
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %6) #6, !dbg !2564
  %23 = load i32, ptr %19, align 4, !dbg !2565, !tbaa !1947
  store i32 %23, ptr %6, align 4, !dbg !2566, !tbaa !1264, !DIAssignID !2567
  call void @llvm.dbg.assign(metadata i32 %23, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2567, metadata ptr %6, metadata !DIExpression()), !dbg !2539
  %24 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 1, !dbg !2566
  %25 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %19, i64 0, i32 1, !dbg !2568
  %26 = load i16, ptr %25, align 4, !dbg !2568, !tbaa !1952
  store i16 %26, ptr %24, align 4, !dbg !2566, !tbaa !1268, !DIAssignID !2569
  call void @llvm.dbg.assign(metadata i16 %26, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2569, metadata ptr %24, metadata !DIExpression()), !dbg !2539
  %27 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 2, !dbg !2566
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2570, metadata ptr %27, metadata !DIExpression()), !dbg !2539
  %28 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 3, !dbg !2566
  store i8 %22, ptr %28, align 4, !dbg !2566, !tbaa !1271, !DIAssignID !2571
  call void @llvm.dbg.assign(metadata i8 %22, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2571, metadata ptr %28, metadata !DIExpression()), !dbg !2539
  %29 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 4, !dbg !2566
  call void @llvm.dbg.assign(metadata i8 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2572, metadata ptr %29, metadata !DIExpression()), !dbg !2539
  %30 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 5, !dbg !2566
  store i16 0, ptr %30, align 2, !dbg !2566, !DIAssignID !2573
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2573, metadata ptr %30, metadata !DIExpression()), !dbg !2539
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !2574, metadata ptr undef, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !2577, metadata ptr undef, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.value(metadata ptr %6, metadata !1289, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2575
  store i16 0, ptr %27, align 2, !dbg !2578, !tbaa !1298
  store i8 0, ptr %29, align 1, !dbg !2579, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %6, metadata !1301, metadata !DIExpression()), !dbg !2580
  %31 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %6) #6, !dbg !2582
  call void @llvm.dbg.value(metadata ptr %31, metadata !1291, metadata !DIExpression()), !dbg !2575
  %32 = icmp eq ptr %31, null, !dbg !2583
  br i1 %32, label %41, label %33, !dbg !2584

33:                                               ; preds = %21
  tail call void @llvm.dbg.value(metadata ptr %31, metadata !1312, metadata !DIExpression()), !dbg !2585
  %34 = getelementptr inbounds %struct.lb4_service, ptr %31, i64 0, i32 4, !dbg !2587
  %35 = load i8, ptr %34, align 1, !dbg !2587, !tbaa !1321
  %36 = and i8 %35, 32, !dbg !2588
  %37 = icmp eq i8 %36, 0, !dbg !2589
  br i1 %37, label %44, label %38, !dbg !2590

38:                                               ; preds = %33
  store i8 1, ptr %29, align 1, !dbg !2591, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %6, metadata !1301, metadata !DIExpression()), !dbg !2592
  %39 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %6) #6, !dbg !2594
  call void @llvm.dbg.value(metadata ptr %39, metadata !2533, metadata !DIExpression()), !dbg !2539
  %40 = icmp eq ptr %39, null, !dbg !2595
  br i1 %40, label %41, label %44, !dbg !2597

41:                                               ; preds = %21, %38
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2598
  call void @llvm.dbg.value(metadata ptr null, metadata !1233, metadata !DIExpression()), !dbg !2598
  %42 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !2601
  call void @llvm.dbg.value(metadata i64 %42, metadata !1234, metadata !DIExpression()), !dbg !2598
  %43 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !2602
  br label %55, !dbg !2603

44:                                               ; preds = %33, %38
  %45 = phi ptr [ %39, %38 ], [ %31, %33 ]
  call void @llvm.dbg.value(metadata ptr %45, metadata !2533, metadata !DIExpression()), !dbg !2539
  %46 = getelementptr inbounds %struct.lb4_service, ptr %45, i64 0, i32 2, !dbg !2604
  %47 = load i16, ptr %46, align 2, !dbg !2604, !tbaa !1601
  %48 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %19, i64 0, i32 2, !dbg !2606
  %49 = load i16, ptr %48, align 2, !dbg !2606, !tbaa !1956
  %50 = icmp eq i16 %47, %49, !dbg !2607
  br i1 %50, label %51, label %55, !dbg !2608

51:                                               ; preds = %44
  %52 = getelementptr inbounds %struct.lb4_service, ptr %45, i64 0, i32 1, !dbg !2609
  %53 = load i16, ptr %52, align 4, !dbg !2609, !tbaa !1334
  %54 = icmp eq i16 %53, 0, !dbg !2610
  br i1 %54, label %55, label %66, !dbg !2611

55:                                               ; preds = %41, %51, %44
  %56 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %5) #6, !dbg !2612
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2517, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2518, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 1, metadata !1766, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 8, metadata !1767, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i16 612, metadata !1768, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2614
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !2616
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2617, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #6, !dbg !2618
  store i64 21514944776, ptr %4, align 8, !dbg !2619, !DIAssignID !2620
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2620, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 8, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2621, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 1, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2622, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2614
  call void @llvm.dbg.assign(metadata i16 612, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2623, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2624, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2614
  %57 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4) #6, !dbg !2625
  call void @llvm.dbg.value(metadata ptr %57, metadata !1770, metadata !DIExpression()), !dbg !2614
  %58 = icmp eq ptr %57, null, !dbg !2626
  br i1 %58, label %62, label %59, !dbg !2627

59:                                               ; preds = %55
  %60 = load i64, ptr %57, align 8, !dbg !2628, !tbaa !1790
  %61 = add i64 %60, 1, !dbg !2628
  store i64 %61, ptr %57, align 8, !dbg !2628, !tbaa !1790
  br label %65, !dbg !2629

62:                                               ; preds = %55
  store i64 1, ptr %3, align 8, !dbg !2630, !tbaa !1790, !DIAssignID !2631
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2631, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  %63 = getelementptr inbounds %struct.metrics_value, ptr %3, i64 0, i32 1, !dbg !2632
  store i64 0, ptr %63, align 8, !dbg !2633, !tbaa !1798, !DIAssignID !2634
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2634, metadata ptr %63, metadata !DIExpression()), !dbg !2614
  %64 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !2635
  br label %65

65:                                               ; preds = %59, %62
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #6, !dbg !2636
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !2636
  br label %70, !dbg !2637

66:                                               ; preds = %51
  %67 = load i32, ptr %19, align 4, !dbg !2638, !tbaa !1947
  store i32 %67, ptr %13, align 4, !dbg !2639, !tbaa !1261
  %68 = load i16, ptr %25, align 4, !dbg !2640, !tbaa !1952
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2641
  tail call void @llvm.dbg.value(metadata i16 %68, metadata !2038, metadata !DIExpression()), !dbg !2641
  %69 = zext i16 %68 to i32, !dbg !2643
  store i32 %69, ptr %7, align 8, !dbg !2644, !tbaa !1251
  br label %70, !dbg !2645

70:                                               ; preds = %66, %65
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %6) #6, !dbg !2646
  br label %71

71:                                               ; preds = %1, %70
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %5) #6, !dbg !2647
  ret i32 1, !dbg !2648
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock6_connect(ptr noundef %0) #0 section "cgroup/connect6" !dbg !2649 {
  %2 = alloca %struct.lb6_affinity_key, align 8, !DIAssignID !2653
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !2654
  %4 = alloca %struct.lb6_affinity_key, align 8, !DIAssignID !2655
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !2656
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !2657
  %7 = alloca %struct.ipv6_revnat_entry, align 8, !DIAssignID !2658
  %8 = alloca %struct.ipv6_revnat_tuple, align 8, !DIAssignID !2659
  %9 = alloca i32, align 4, !DIAssignID !2660
  %10 = alloca i32, align 4, !DIAssignID !2661
  %11 = alloca %struct.skip_lb6_key, align 8, !DIAssignID !2662
  %12 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2663
  %13 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !2664
  %14 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2665
  %15 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !2666
  %16 = alloca %struct.ipcache_key, align 4, !DIAssignID !2667
  %17 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !2668
  %18 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2669
  %19 = alloca i32, align 4, !DIAssignID !2670
  %20 = alloca i32, align 4, !DIAssignID !2671
  %21 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !2672
  %22 = alloca i32, align 4, !DIAssignID !2673
  %23 = alloca i32, align 4, !DIAssignID !2674
  %24 = alloca %struct.metrics_value, align 8, !DIAssignID !2675
  %25 = alloca %struct.metrics_key, align 8, !DIAssignID !2676
  %26 = alloca %struct.metrics_value, align 8, !DIAssignID !2677
  %27 = alloca %struct.metrics_key, align 8, !DIAssignID !2678
  %28 = alloca %struct.metrics_value, align 8, !DIAssignID !2679
  %29 = alloca %struct.metrics_key, align 8, !DIAssignID !2680
  %30 = alloca %struct.lb4_key, align 4, !DIAssignID !2681
  %31 = alloca i32, align 4, !DIAssignID !2682
  %32 = alloca %struct.metrics_value, align 8, !DIAssignID !2683
  %33 = alloca %struct.metrics_key, align 8, !DIAssignID !2684
  %34 = alloca %struct.metrics_value, align 8, !DIAssignID !2685
  %35 = alloca %struct.metrics_key, align 8, !DIAssignID !2686
  %36 = alloca %struct.metrics_value, align 8, !DIAssignID !2687
  %37 = alloca %struct.metrics_key, align 8, !DIAssignID !2688
  %38 = alloca %struct.lb6_key, align 8, !DIAssignID !2689
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2651, metadata !DIExpression()), !dbg !2690
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2691, metadata !DIExpression(), metadata !2689, metadata ptr %38, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata ptr %0, metadata !2696, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i1 false, metadata !2697, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2721
  call void @llvm.dbg.value(metadata i1 true, metadata !2698, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2721
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2723
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !2723
  %39 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #6, !dbg !2725
  call void @llvm.dbg.value(metadata i64 %39, metadata !1234, metadata !DIExpression()), !dbg !2723
  tail call void @llvm.dbg.value(metadata i64 %39, metadata !2699, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2721
  %40 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !2726
  call void @llvm.dbg.value(metadata !DIArgList(i64 %39, i64 %40), metadata !2700, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2721
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2682, metadata ptr %31, metadata !DIExpression()), !dbg !2727
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2727
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %31), !dbg !2729
  %41 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2730
  %42 = load i32, ptr %41, align 8, !dbg !2730, !tbaa !1251
  store volatile i32 %42, ptr %31, align 4, !dbg !2731, !tbaa !1129, !DIAssignID !2732
  call void @llvm.dbg.assign(metadata i32 %42, metadata !1239, metadata !DIExpression(), metadata !2732, metadata ptr %31, metadata !DIExpression()), !dbg !2727
  %43 = load volatile i32, ptr %31, align 4, !dbg !2733, !tbaa !1129
  %44 = trunc i32 %43 to i16, !dbg !2734
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %31), !dbg !2735
  call void @llvm.dbg.value(metadata i16 %44, metadata !2707, metadata !DIExpression()), !dbg !2721
  %45 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2736
  %46 = load i32, ptr %45, align 4, !dbg !2736, !tbaa !1259
  %47 = trunc i32 %46 to i8, !dbg !2736
  call void @llvm.dbg.value(metadata i8 %47, metadata !2708, metadata !DIExpression()), !dbg !2721
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %38) #6, !dbg !2737
  %48 = getelementptr inbounds i8, ptr %38, i64 16, !dbg !2738
  store i64 0, ptr %48, align 8, !dbg !2738, !DIAssignID !2739
  call void @llvm.dbg.assign(metadata i64 0, metadata !2691, metadata !DIExpression(), metadata !2739, metadata ptr %38, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.assign(metadata i8 0, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128), metadata !2740, metadata ptr undef, metadata !DIExpression()), !dbg !2721
  %49 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 1, !dbg !2741
  store i16 %44, ptr %49, align 8, !dbg !2741, !tbaa !2742, !DIAssignID !2744
  call void @llvm.dbg.assign(metadata i16 %44, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !2744, metadata ptr %49, metadata !DIExpression()), !dbg !2721
  %50 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 3, !dbg !2741
  store i8 %47, ptr %50, align 4, !dbg !2741, !tbaa !2745, !DIAssignID !2746
  call void @llvm.dbg.assign(metadata i8 %47, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 8), metadata !2746, metadata ptr %50, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 0, metadata !2711, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !2721
  tail call void @llvm.dbg.value(metadata i8 %47, metadata !1275, metadata !DIExpression()), !dbg !2747
  switch i8 %47, label %605 [
    i8 6, label %51
    i8 -120, label %51
    i8 17, label %51
  ], !dbg !2750

51:                                               ; preds = %1, %1, %1
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !2758
  call void @llvm.dbg.value(metadata ptr %38, metadata !2757, metadata !DIExpression()), !dbg !2758
  %52 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !2760
  %53 = load i32, ptr %52, align 8, !dbg !2761, !tbaa !1129
  store i32 %53, ptr %38, align 8, !dbg !2762, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !2763, !srcloc !2764
  %54 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !2765
  %55 = load i32, ptr %54, align 4, !dbg !2765, !tbaa !1129
  %56 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 1, !dbg !2766
  store i32 %55, ptr %56, align 4, !dbg !2767, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !2768, !srcloc !2769
  %57 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !2770
  %58 = load i32, ptr %57, align 8, !dbg !2770, !tbaa !1129
  %59 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 2, !dbg !2771
  store i32 %58, ptr %59, align 8, !dbg !2772, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !2773, !srcloc !2774
  %60 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !2775
  %61 = load i32, ptr %60, align 4, !dbg !2775, !tbaa !1129
  %62 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 3, !dbg !2776
  store i32 %61, ptr %62, align 4, !dbg !2777, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !2778, !srcloc !2779
  call void @llvm.dbg.value(metadata ptr undef, metadata !2780, metadata !DIExpression()), !dbg !2788
  call void @llvm.dbg.value(metadata ptr %38, metadata !2787, metadata !DIExpression()), !dbg !2788
  call void @llvm.dbg.value(metadata ptr undef, metadata !2790, metadata !DIExpression()), !dbg !2797
  call void @llvm.dbg.value(metadata ptr %38, metadata !2795, metadata !DIExpression()), !dbg !2797
  call void @llvm.dbg.value(metadata i64 16, metadata !2796, metadata !DIExpression()), !dbg !2797
  tail call void @llvm.dbg.value(metadata i64 16, metadata !2799, metadata !DIExpression()), !dbg !2820
  tail call void @llvm.dbg.value(metadata ptr %38, metadata !2803, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2820
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2802, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2820
  call void @llvm.dbg.label(metadata !2818), !dbg !2822
  tail call void @llvm.dbg.value(metadata ptr %59, metadata !2803, metadata !DIExpression()), !dbg !2820
  %63 = load i64, ptr %59, align 8, !dbg !2823, !tbaa !1534
  tail call void @llvm.dbg.value(metadata i64 %63, metadata !2709, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2721
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2802, metadata !DIExpression()), !dbg !2820
  call void @llvm.dbg.label(metadata !2819), !dbg !2824
  tail call void @llvm.dbg.value(metadata ptr %38, metadata !2803, metadata !DIExpression()), !dbg !2820
  %64 = load i64, ptr %38, align 8, !dbg !2825, !tbaa !1534
  tail call void @llvm.dbg.value(metadata i64 %64, metadata !2709, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2721
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2826, metadata !DIExpression(), metadata !2835, metadata ptr undef, metadata !DIExpression()), !dbg !2836
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2834, metadata !DIExpression(), metadata !2838, metadata ptr undef, metadata !DIExpression()), !dbg !2836
  call void @llvm.dbg.value(metadata ptr %38, metadata !2831, metadata !DIExpression()), !dbg !2836
  call void @llvm.dbg.value(metadata i8 1, metadata !2832, metadata !DIExpression()), !dbg !2836
  %65 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 2, !dbg !2839
  store i16 0, ptr %65, align 2, !dbg !2840, !tbaa !2841
  %66 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 4, !dbg !2842
  store i8 0, ptr %66, align 1, !dbg !2843, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !2850
  %67 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !2852
  call void @llvm.dbg.value(metadata ptr %67, metadata !2833, metadata !DIExpression()), !dbg !2836
  %68 = icmp eq ptr %67, null, !dbg !2853
  br i1 %68, label %77, label %69, !dbg !2855

69:                                               ; preds = %51
  tail call void @llvm.dbg.value(metadata ptr %67, metadata !2856, metadata !DIExpression()), !dbg !2861
  %70 = getelementptr inbounds %struct.lb6_service, ptr %67, i64 0, i32 4, !dbg !2864
  %71 = load i8, ptr %70, align 1, !dbg !2864, !tbaa !2865
  %72 = and i8 %71, 32, !dbg !2867
  %73 = icmp eq i8 %72, 0, !dbg !2868
  br i1 %73, label %353, label %74, !dbg !2869

74:                                               ; preds = %69
  store i8 1, ptr %66, align 1, !dbg !2870, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !2871
  %75 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !2873
  call void @llvm.dbg.value(metadata ptr %75, metadata !2704, metadata !DIExpression()), !dbg !2721
  %76 = icmp eq ptr %75, null, !dbg !2874
  br i1 %76, label %77, label %353, !dbg !2876

77:                                               ; preds = %51, %74
  call void @llvm.dbg.value(metadata ptr null, metadata !2704, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata ptr %0, metadata !2877, metadata !DIExpression()), !dbg !2885
  call void @llvm.dbg.value(metadata i1 false, metadata !2880, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2885
  call void @llvm.dbg.value(metadata i1 true, metadata !2881, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2885
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !2888
  call void @llvm.dbg.value(metadata ptr undef, metadata !2757, metadata !DIExpression()), !dbg !2888
  %78 = load i32, ptr %52, align 8, !dbg !2890, !tbaa !1129
  %79 = zext i32 %78 to i64, !dbg !2891
  tail call void @llvm.dbg.value(metadata i64 %79, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !2885
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2892, !srcloc !2764
  %80 = load i32, ptr %54, align 4, !dbg !2893, !tbaa !1129
  %81 = zext i32 %80 to i64, !dbg !2894
  %82 = shl nuw i64 %81, 32, !dbg !2894
  %83 = or disjoint i64 %82, %79, !dbg !2894
  tail call void @llvm.dbg.value(metadata i64 %83, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !2885
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2895, !srcloc !2769
  %84 = load i32, ptr %57, align 8, !dbg !2896, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %84, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !2885
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2897, !srcloc !2774
  %85 = load i32, ptr %60, align 4, !dbg !2898, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2883, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !2885
  call void asm sideeffect "", "~{memory}"() #6, !dbg !2899, !srcloc !2779
  call void @llvm.dbg.value(metadata ptr undef, metadata !2900, metadata !DIExpression()), !dbg !2908
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2908
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2908
  tail call void @llvm.dbg.value(metadata i64 %83, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2908
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2908
  tail call void @llvm.dbg.value(metadata i32 %84, metadata !2907, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !2908
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !2917
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !2917
  %86 = icmp eq i64 %83, 0, !dbg !2919
  %87 = icmp eq i32 %84, -65536
  %88 = select i1 %86, i1 %87, i1 false, !dbg !2921
  br i1 %88, label %89, label %605, !dbg !2921

89:                                               ; preds = %77
  tail call void @llvm.dbg.value(metadata i32 %84, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !2885
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2883, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !2885
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !2922
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !2922
  call void @llvm.dbg.value(metadata i64 72, metadata !1504, metadata !DIExpression()), !dbg !2922
  call void @llvm.dbg.value(metadata i64 72, metadata !1507, metadata !DIExpression()), !dbg !2924
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !2924
  call void @llvm.dbg.label(metadata !1520), !dbg !2926
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1521), !dbg !2927
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1522), !dbg !2928
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1523), !dbg !2929
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1524), !dbg !2930
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1525), !dbg !2931
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1526), !dbg !2932
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1527), !dbg !2933
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1528), !dbg !2934
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2885
  %90 = load i32, ptr %45, align 4, !dbg !2935, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %90, metadata !2882, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !2885
  tail call void @llvm.dbg.value(metadata i32 %85, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !2885
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2673, metadata ptr %22, metadata !DIExpression()), !dbg !2936
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2936
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %22), !dbg !2938
  %91 = load i32, ptr %41, align 8, !dbg !2939, !tbaa !1251
  store volatile i32 %91, ptr %22, align 4, !dbg !2940, !tbaa !1129, !DIAssignID !2941
  call void @llvm.dbg.assign(metadata i32 %91, metadata !1239, metadata !DIExpression(), metadata !2941, metadata ptr %22, metadata !DIExpression()), !dbg !2936
  %92 = load volatile i32, ptr %22, align 4, !dbg !2942, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %22), !dbg !2943
  %93 = and i32 %92, 65535, !dbg !2944
  tail call void @llvm.dbg.value(metadata i32 %93, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !2885
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !2681, metadata ptr %30, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata ptr undef, metadata !1199, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i1 false, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2945
  call void @llvm.dbg.value(metadata i1 true, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2945
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2947
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !2947
  %94 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !2949
  call void @llvm.dbg.value(metadata i64 %94, metadata !1234, metadata !DIExpression()), !dbg !2947
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !1203, metadata !DIExpression()), !dbg !2945
  %95 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !2950
  call void @llvm.dbg.value(metadata !DIArgList(i64 %94, i64 %95), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2945
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2674, metadata ptr %23, metadata !DIExpression()), !dbg !2951
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !2951
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %23), !dbg !2953
  store volatile i32 %93, ptr %23, align 4, !dbg !2954, !tbaa !1129, !DIAssignID !2955
  call void @llvm.dbg.assign(metadata i32 %93, metadata !1239, metadata !DIExpression(), metadata !2955, metadata ptr %23, metadata !DIExpression()), !dbg !2951
  %96 = load volatile i32, ptr %23, align 4, !dbg !2956, !tbaa !1129
  %97 = trunc i32 %96 to i16, !dbg !2957
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %23), !dbg !2958
  call void @llvm.dbg.value(metadata i16 %97, metadata !1211, metadata !DIExpression()), !dbg !2945
  %98 = trunc i32 %90 to i8, !dbg !2959
  call void @llvm.dbg.value(metadata i8 %98, metadata !1212, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i32 %85, metadata !1213, metadata !DIExpression()), !dbg !2945
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %30) #6, !dbg !2960
  store i32 %85, ptr %30, align 4, !dbg !2961, !tbaa !1264, !DIAssignID !2962
  call void @llvm.dbg.assign(metadata i32 %85, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2962, metadata ptr %30, metadata !DIExpression()), !dbg !2945
  %99 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 1, !dbg !2961
  store i16 %97, ptr %99, align 4, !dbg !2961, !tbaa !1268, !DIAssignID !2963
  call void @llvm.dbg.assign(metadata i16 %97, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2963, metadata ptr %99, metadata !DIExpression()), !dbg !2945
  %100 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 2, !dbg !2961
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2964, metadata ptr %100, metadata !DIExpression()), !dbg !2945
  %101 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 3, !dbg !2961
  store i8 %98, ptr %101, align 4, !dbg !2961, !tbaa !1271, !DIAssignID !2965
  call void @llvm.dbg.assign(metadata i8 %98, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2965, metadata ptr %101, metadata !DIExpression()), !dbg !2945
  %102 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 4, !dbg !2961
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2966, metadata ptr %102, metadata !DIExpression()), !dbg !2945
  %103 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 5, !dbg !2961
  store i16 0, ptr %103, align 2, !dbg !2961, !DIAssignID !2967
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2967, metadata ptr %103, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 %98, metadata !1275, metadata !DIExpression()), !dbg !2968
  switch i8 %98, label %348 [
    i8 6, label %104
    i8 -120, label %104
    i8 17, label %104
  ], !dbg !2970

104:                                              ; preds = %89, %89, %89
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !2971, metadata ptr undef, metadata !DIExpression()), !dbg !2972
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !2974, metadata ptr undef, metadata !DIExpression()), !dbg !2972
  call void @llvm.dbg.value(metadata ptr %30, metadata !1289, metadata !DIExpression()), !dbg !2972
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2972
  store i16 0, ptr %100, align 2, !dbg !2975, !tbaa !1298
  store i8 0, ptr %102, align 1, !dbg !2976, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !2977
  %105 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !2979
  call void @llvm.dbg.value(metadata ptr %105, metadata !1291, metadata !DIExpression()), !dbg !2972
  %106 = icmp eq ptr %105, null, !dbg !2980
  br i1 %106, label %348, label %107, !dbg !2981

107:                                              ; preds = %104
  call void @llvm.dbg.value(metadata ptr %105, metadata !1312, metadata !DIExpression()), !dbg !2982
  %108 = getelementptr inbounds %struct.lb4_service, ptr %105, i64 0, i32 4, !dbg !2984
  %109 = load i8, ptr %108, align 1, !dbg !2984, !tbaa !1321
  %110 = and i8 %109, 32, !dbg !2985
  %111 = icmp eq i8 %110, 0, !dbg !2986
  br i1 %111, label %115, label %112, !dbg !2987

112:                                              ; preds = %107
  store i8 1, ptr %102, align 1, !dbg !2988, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !2989
  %113 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !2991
  call void @llvm.dbg.value(metadata ptr %113, metadata !1208, metadata !DIExpression()), !dbg !2945
  %114 = icmp eq ptr %113, null, !dbg !2992
  br i1 %114, label %348, label %115, !dbg !2993

115:                                              ; preds = %107, %112
  %116 = phi ptr [ %113, %112 ], [ %105, %107 ]
  call void @llvm.dbg.value(metadata ptr %116, metadata !1208, metadata !DIExpression()), !dbg !2945
  %117 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 1, !dbg !2994
  %118 = load i16, ptr %117, align 4, !dbg !2994, !tbaa !1334
  %119 = icmp eq i16 %118, 0, !dbg !2995
  br i1 %119, label %120, label %137, !dbg !2996

120:                                              ; preds = %115
  %121 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !2997, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %121, metadata !1217, metadata !DIExpression()), !dbg !2998
  %122 = load volatile i8, ptr %121, align 1, !dbg !2999, !tbaa !1341, !range !1343, !noundef !1344
  %123 = icmp eq i8 %122, 0, !dbg !2999
  br i1 %123, label %124, label %348, !dbg !3000

124:                                              ; preds = %120
  call void @llvm.dbg.value(metadata ptr %116, metadata !1346, metadata !DIExpression()), !dbg !3001
  call void @llvm.dbg.value(metadata ptr %116, metadata !1354, metadata !DIExpression()), !dbg !3003
  %125 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 3, !dbg !3005
  %126 = load i8, ptr %125, align 4, !dbg !3005, !tbaa !1361
  %127 = and i8 %126, 35, !dbg !3006
  %128 = icmp eq i8 %127, 0, !dbg !3007
  br i1 %128, label %132, label %129, !dbg !3008

129:                                              ; preds = %124
  call void @llvm.dbg.value(metadata ptr %116, metadata !1365, metadata !DIExpression()), !dbg !3009
  %130 = and i8 %126, 4, !dbg !3011
  %131 = icmp eq i8 %130, 0, !dbg !3012
  br i1 %131, label %350, label %348, !dbg !3013

132:                                              ; preds = %124
  call void @llvm.dbg.value(metadata ptr %116, metadata !1354, metadata !DIExpression()), !dbg !3014
  call void @llvm.dbg.value(metadata ptr %116, metadata !1375, metadata !DIExpression()), !dbg !3016
  %133 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 4, !dbg !3018
  %134 = load i8, ptr %133, align 1, !dbg !3018, !tbaa !1321
  %135 = and i8 %134, 16, !dbg !3019
  %136 = icmp eq i8 %135, 0, !dbg !3020
  br i1 %136, label %350, label %348, !dbg !3021

137:                                              ; preds = %115
  call void @llvm.dbg.value(metadata ptr %116, metadata !1385, metadata !DIExpression()), !dbg !3022
  call void @llvm.dbg.value(metadata ptr %116, metadata !1391, metadata !DIExpression()), !dbg !3024
  %138 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 3, !dbg !3026
  %139 = load i8, ptr %138, align 4, !dbg !3026, !tbaa !1361
  %140 = and i8 %139, 8, !dbg !3027
  %141 = icmp eq i8 %140, 0, !dbg !3028
  br i1 %141, label %142, label %147, !dbg !3029

142:                                              ; preds = %137
  %143 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 4, !dbg !3030
  %144 = load i8, ptr %143, align 1, !dbg !3030, !tbaa !1321
  %145 = and i8 %144, 8, !dbg !3031
  %146 = icmp eq i8 %145, 0, !dbg !3029
  br i1 %146, label %153, label %350, !dbg !3032

147:                                              ; preds = %137
  call void @llvm.dbg.value(metadata ptr %116, metadata !1403, metadata !DIExpression()), !dbg !3033
  call void @llvm.dbg.value(metadata i32 %85, metadata !1408, metadata !DIExpression()), !dbg !3033
  call void @llvm.dbg.value(metadata ptr %116, metadata !1417, metadata !DIExpression()), !dbg !3035
  %148 = and i8 %139, 1, !dbg !3037
  %149 = icmp eq i8 %148, 0, !dbg !3038
  call void @llvm.dbg.value(metadata ptr %116, metadata !1391, metadata !DIExpression()), !dbg !3039
  %150 = and i32 %85, 255
  %151 = icmp eq i32 %150, 127
  %152 = select i1 %149, i1 %151, i1 false, !dbg !3041
  br i1 %152, label %166, label %156, !dbg !3041

153:                                              ; preds = %142
  call void @llvm.dbg.value(metadata ptr %116, metadata !1403, metadata !DIExpression()), !dbg !3033
  call void @llvm.dbg.value(metadata i32 %85, metadata !1408, metadata !DIExpression()), !dbg !3033
  call void @llvm.dbg.value(metadata ptr %116, metadata !1417, metadata !DIExpression()), !dbg !3035
  %154 = and i8 %139, 1, !dbg !3037
  %155 = icmp eq i8 %154, 0, !dbg !3038
  br i1 %155, label %166, label %156, !dbg !3041

156:                                              ; preds = %153, %147
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !2667, metadata ptr %16, metadata !DIExpression()), !dbg !3042
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !3042
  call void @llvm.dbg.value(metadata i32 %85, metadata !1433, metadata !DIExpression()), !dbg !3042
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !3042
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !3042
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %16) #6, !dbg !3044
  %157 = getelementptr inbounds i8, ptr %16, i64 6, !dbg !3045
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %157, i8 0, i64 18, i1 false), !dbg !3045, !DIAssignID !3046
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !3046, metadata ptr %16, metadata !DIExpression()), !dbg !3042
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !3047, metadata ptr undef, metadata !DIExpression()), !dbg !3042
  store i32 64, ptr %16, align 4, !dbg !3048, !tbaa.struct !1443, !DIAssignID !3049
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3049, metadata ptr %16, metadata !DIExpression()), !dbg !3042
  %158 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 3, !dbg !3050
  store i8 1, ptr %158, align 1, !dbg !3051, !tbaa !1448, !DIAssignID !3052
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !3052, metadata ptr %158, metadata !DIExpression()), !dbg !3042
  %159 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 4, !dbg !3053
  store i32 %85, ptr %159, align 4, !dbg !3054, !tbaa !1444, !DIAssignID !3055
  call void @llvm.dbg.assign(metadata i32 %85, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3055, metadata ptr %159, metadata !DIExpression()), !dbg !3042
  %160 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 1, !dbg !3056
  store i16 0, ptr %160, align 4, !dbg !3057, !tbaa !1457, !DIAssignID !3058
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3058, metadata ptr %160, metadata !DIExpression()), !dbg !3042
  %161 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %16) #6, !dbg !3059
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %16) #6, !dbg !3060
  call void @llvm.dbg.value(metadata ptr %161, metadata !1409, metadata !DIExpression()), !dbg !3061
  %162 = icmp eq ptr %161, null, !dbg !3062
  br i1 %162, label %348, label %163, !dbg !3063

163:                                              ; preds = %156
  %164 = load i32, ptr %161, align 4, !dbg !3064, !tbaa !1466
  %165 = icmp eq i32 %164, 1, !dbg !3065
  br i1 %165, label %166, label %348, !dbg !3066

166:                                              ; preds = %147, %153, %163
  %167 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !3067, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %167, metadata !1222, metadata !DIExpression()), !dbg !3068
  %168 = load volatile i8, ptr %167, align 1, !dbg !3069, !tbaa !1341, !range !1343, !noundef !1344
  %169 = icmp eq i8 %168, 0, !dbg !3069
  br i1 %169, label %181, label %170, !dbg !3070

170:                                              ; preds = %166
  call void @llvm.dbg.value(metadata ptr %116, metadata !1475, metadata !DIExpression()), !dbg !3071
  %171 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 4, !dbg !3073
  %172 = load i8, ptr %171, align 1, !dbg !3073, !tbaa !1321
  %173 = and i8 %172, 1, !dbg !3074
  %174 = icmp eq i8 %173, 0, !dbg !3075
  br i1 %174, label %181, label %175, !dbg !3076

175:                                              ; preds = %170
  %176 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !3077
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !2672, metadata ptr %21, metadata !DIExpression()), !dbg !3078
  call void @llvm.dbg.value(metadata i64 %176, metadata !1490, metadata !DIExpression()), !dbg !3078
  call void @llvm.dbg.value(metadata i32 %85, metadata !1491, metadata !DIExpression()), !dbg !3078
  call void @llvm.dbg.value(metadata i16 %97, metadata !1492, metadata !DIExpression()), !dbg !3078
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %21) #6, !dbg !3080
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !3078
  call void @llvm.dbg.value(metadata ptr %21, metadata !1497, metadata !DIExpression()), !dbg !3081
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3081
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !3081
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !3083
  call void @llvm.dbg.value(metadata ptr %21, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !3083
  call void @llvm.dbg.label(metadata !1527), !dbg !3085
  %177 = getelementptr inbounds i8, ptr %21, i64 8, !dbg !3086
  call void @llvm.dbg.value(metadata ptr %177, metadata !1512, metadata !DIExpression()), !dbg !3083
  store i64 0, ptr %177, align 8, !dbg !3086, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !3087
  call void @llvm.dbg.value(metadata ptr %21, metadata !1512, metadata !DIExpression()), !dbg !3083
  store i64 %176, ptr %21, align 8, !dbg !3088, !tbaa !1538, !DIAssignID !3089
  call void @llvm.dbg.assign(metadata i64 %176, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3089, metadata ptr %21, metadata !DIExpression()), !dbg !3078
  store i32 %85, ptr %177, align 8, !dbg !3090, !tbaa !1542, !DIAssignID !3091
  call void @llvm.dbg.assign(metadata i32 %85, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3091, metadata ptr %177, metadata !DIExpression()), !dbg !3078
  %178 = getelementptr inbounds %struct.skip_lb4_key, ptr %21, i64 0, i32 2, !dbg !3092
  store i16 %97, ptr %178, align 4, !dbg !3093, !tbaa !1546, !DIAssignID !3094
  call void @llvm.dbg.assign(metadata i16 %97, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3094, metadata ptr %178, metadata !DIExpression()), !dbg !3078
  %179 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %21) #6, !dbg !3095
  call void @llvm.dbg.value(metadata ptr %179, metadata !1493, metadata !DIExpression()), !dbg !3078
  %180 = icmp eq ptr %179, null, !dbg !3096
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %21) #6, !dbg !3097
  br i1 %180, label %181, label %348, !dbg !3098

181:                                              ; preds = %175, %170, %166
  call void @llvm.dbg.value(metadata ptr %116, metadata !1553, metadata !DIExpression()), !dbg !3099
  %182 = load i8, ptr %138, align 4, !dbg !3101, !tbaa !1361
  %183 = and i8 %182, 16, !dbg !3102
  %184 = icmp eq i8 %183, 0, !dbg !3103
  br i1 %184, label %240, label %185, !dbg !3104

185:                                              ; preds = %181
  call void @llvm.dbg.value(metadata ptr %116, metadata !1563, metadata !DIExpression()), !dbg !3105
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !3105
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !2665, metadata ptr %14, metadata !DIExpression()), !dbg !3107
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !2666, metadata ptr %15, metadata !DIExpression()), !dbg !3109
  call void @llvm.dbg.value(metadata ptr %116, metadata !1580, metadata !DIExpression()), !dbg !3107
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !3107
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !3107
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %14) #6, !dbg !3110
  store i64 %94, ptr %14, align 8, !dbg !3111, !DIAssignID !3112
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3112, metadata ptr %14, metadata !DIExpression()), !dbg !3107
  %186 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 1, !dbg !3113
  %187 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 2, !dbg !3114
  %188 = load i16, ptr %187, align 2, !dbg !3114, !tbaa !1601
  store i16 %188, ptr %186, align 8, !dbg !3113, !tbaa !1602, !DIAssignID !3115
  call void @llvm.dbg.assign(metadata i16 %188, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !3115, metadata ptr %186, metadata !DIExpression()), !dbg !3107
  %189 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 2, !dbg !3113
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !3116, metadata ptr %189, metadata !DIExpression()), !dbg !3107
  store i8 1, ptr %189, align 2, !dbg !3113, !DIAssignID !3117
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !3117, metadata ptr %189, metadata !DIExpression()), !dbg !3107
  %190 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 3, !dbg !3113
  store i8 0, ptr %190, align 1, !dbg !3113, !tbaa !1607, !DIAssignID !3118
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !3118, metadata ptr %190, metadata !DIExpression()), !dbg !3107
  %191 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 4, !dbg !3113
  store i32 0, ptr %191, align 4, !dbg !3113, !tbaa !1609, !DIAssignID !3119
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3119, metadata ptr %191, metadata !DIExpression()), !dbg !3107
  %192 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %14) #6, !dbg !3120
  call void @llvm.dbg.value(metadata ptr %192, metadata !1583, metadata !DIExpression()), !dbg !3107
  %193 = icmp eq ptr %192, null, !dbg !3121
  br i1 %193, label %194, label %195, !dbg !3122

194:                                              ; preds = %185
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !3123
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2945
  br label %240, !dbg !3124

195:                                              ; preds = %185
  %196 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3125, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %196, metadata !1623, metadata !DIExpression()), !dbg !3127
  %197 = load volatile i8, ptr %196, align 1, !dbg !3128, !tbaa !1341, !range !1343, !noundef !1344
  %198 = icmp eq i8 %197, 0, !dbg !3128
  br i1 %198, label %202, label %199, !dbg !3129

199:                                              ; preds = %195
  %200 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !3130
  %201 = lshr i64 %200, 8, !dbg !3131
  br label %205, !dbg !3132

202:                                              ; preds = %195
  %203 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !3133
  %204 = udiv i64 %203, 1000000000, !dbg !3135
  br label %205, !dbg !3136

205:                                              ; preds = %202, %199
  %206 = phi i64 [ %201, %199 ], [ %204, %202 ], !dbg !3137
  call void @llvm.dbg.value(metadata i64 %206, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3109
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %15) #6, !dbg !3138
  %207 = getelementptr inbounds %struct.lb_affinity_val, ptr %192, i64 0, i32 1, !dbg !3139
  %208 = load i32, ptr %207, align 1, !dbg !3139, !tbaa !1640
  store i32 %208, ptr %15, align 4, !dbg !3140, !tbaa !1643, !DIAssignID !3141
  call void @llvm.dbg.assign(metadata i32 %208, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3141, metadata ptr %15, metadata !DIExpression()), !dbg !3109
  %209 = getelementptr inbounds %struct.lb_affinity_match, ptr %15, i64 0, i32 1, !dbg !3140
  %210 = load i16, ptr %187, align 2, !dbg !3142, !tbaa !1601
  store i16 %210, ptr %209, align 4, !dbg !3140, !tbaa !1647, !DIAssignID !3143
  call void @llvm.dbg.assign(metadata i16 %210, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3143, metadata ptr %209, metadata !DIExpression()), !dbg !3109
  %211 = getelementptr inbounds %struct.lb_affinity_match, ptr %15, i64 0, i32 2, !dbg !3140
  store i16 0, ptr %211, align 2, !dbg !3140, !tbaa !1649, !DIAssignID !3144
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3144, metadata ptr %211, metadata !DIExpression()), !dbg !3109
  %212 = load volatile i64, ptr %192, align 1, !dbg !3145, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %212, metadata !1588, metadata !DIExpression()), !dbg !3146
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3147, !srcloc !1657
  call void @llvm.dbg.value(metadata ptr %116, metadata !1658, metadata !DIExpression()), !dbg !3149
  %213 = load i32, ptr %116, align 4, !dbg !3151, !tbaa !1444
  %214 = and i32 %213, 16777215, !dbg !3152
  call void @llvm.dbg.value(metadata i32 %214, metadata !1667, metadata !DIExpression()), !dbg !3153
  %215 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3155, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %215, metadata !1672, metadata !DIExpression()), !dbg !3156
  %216 = load volatile i8, ptr %215, align 1, !dbg !3157, !tbaa !1341, !range !1343, !noundef !1344
  %217 = icmp eq i8 %216, 0, !dbg !3157
  br i1 %217, label %223, label %218, !dbg !3158

218:                                              ; preds = %205
  %219 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !3159, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %219, metadata !1675, metadata !DIExpression()), !dbg !3160
  %220 = load volatile i32, ptr %219, align 4, !dbg !3161, !tbaa !1129
  %221 = mul i32 %220, %214, !dbg !3162
  %222 = lshr i32 %221, 8, !dbg !3163
  br label %223, !dbg !3164

223:                                              ; preds = %218, %205
  %224 = phi i32 [ %222, %218 ], [ %214, %205 ], !dbg !3153
  %225 = zext nneg i32 %224 to i64, !dbg !3165
  %226 = add i64 %212, %225, !dbg !3166
  %227 = and i64 %206, 4294967295, !dbg !3167
  %228 = icmp ugt i64 %226, %227, !dbg !3168
  br i1 %228, label %229, label %232, !dbg !3169

229:                                              ; preds = %223
  %230 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %15) #6, !dbg !3170
  %231 = icmp eq ptr %230, null, !dbg !3170
  br i1 %231, label %232, label %234, !dbg !3171

232:                                              ; preds = %229, %223
  %233 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %14) #6, !dbg !3109
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #6, !dbg !3172
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !3123
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2945
  br label %240, !dbg !3124

234:                                              ; preds = %229
  call void @llvm.dbg.value(metadata i64 %227, metadata !1591, metadata !DIExpression()), !dbg !3173
  store volatile i64 %227, ptr %192, align 1, !dbg !3174, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3175, !srcloc !1657
  %235 = load i32, ptr %207, align 1, !dbg !3177, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #6, !dbg !3172
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !3123
  call void @llvm.dbg.value(metadata i32 %235, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2945
  %236 = icmp eq i32 %235, 0, !dbg !3178
  br i1 %236, label %240, label %237, !dbg !3124

237:                                              ; preds = %234
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %20)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2671, metadata ptr %20, metadata !DIExpression()), !dbg !3179
  store i32 %235, ptr %20, align 4, !tbaa !1129, !DIAssignID !3181
  call void @llvm.dbg.assign(metadata i32 %235, metadata !1707, metadata !DIExpression(), metadata !3181, metadata ptr %20, metadata !DIExpression()), !dbg !3179
  %238 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %20) #6, !dbg !3182
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %20), !dbg !3183
  call void @llvm.dbg.value(metadata ptr %238, metadata !1205, metadata !DIExpression()), !dbg !2945
  %239 = icmp eq ptr %238, null, !dbg !3184
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3185, !srcloc !1721
  br i1 %239, label %240, label %282, !dbg !3186

240:                                              ; preds = %237, %234, %181, %194, %232
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !3187
  %241 = load i32, ptr %45, align 4, !dbg !3189, !tbaa !1259
  %242 = and i32 %241, 255, !dbg !3189
  %243 = icmp eq i32 %242, 6, !dbg !3190
  br i1 %243, label %244, label %247, !dbg !3189

244:                                              ; preds = %240
  %245 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !3191
  %246 = zext i32 %245 to i64, !dbg !3191
  br label %249, !dbg !3189

247:                                              ; preds = %240
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3192
  %248 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !3194
  br label %249, !dbg !3189

249:                                              ; preds = %247, %244
  %250 = phi i64 [ %246, %244 ], [ %248, %247 ], !dbg !3189
  %251 = load i16, ptr %117, align 4, !dbg !3195, !tbaa !1334
  %252 = zext i16 %251 to i64, !dbg !3196
  %253 = urem i64 %250, %252, !dbg !3197
  %254 = trunc i64 %253 to i16, !dbg !3198
  %255 = add nuw i16 %254, 1, !dbg !3198
  store i16 %255, ptr %100, align 2, !dbg !3199, !tbaa !1298, !DIAssignID !3200
  call void @llvm.dbg.assign(metadata i16 %255, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3200, metadata ptr %100, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata ptr %30, metadata !1749, metadata !DIExpression()), !dbg !3201
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !3203
  %256 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !3205
  call void @llvm.dbg.value(metadata ptr %256, metadata !1214, metadata !DIExpression()), !dbg !2945
  %257 = icmp eq ptr %256, null, !dbg !3206
  br i1 %257, label %258, label %268, !dbg !3207

258:                                              ; preds = %249
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2679, metadata ptr %28, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2680, metadata ptr %29, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3208
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %28) #6, !dbg !3210
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3211, metadata ptr %28, metadata !DIExpression()), !dbg !3208
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %29) #6, !dbg !3212
  store i64 21502558725, ptr %29, align 8, !dbg !3213, !DIAssignID !3214
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3214, metadata ptr %29, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3215, metadata ptr %29, metadata !DIExpression()), !dbg !3208
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3216, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3208
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3217, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3208
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3218, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3208
  %259 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %29) #6, !dbg !3219
  call void @llvm.dbg.value(metadata ptr %259, metadata !1770, metadata !DIExpression()), !dbg !3208
  %260 = icmp eq ptr %259, null, !dbg !3220
  br i1 %260, label %264, label %261, !dbg !3221

261:                                              ; preds = %258
  %262 = load i64, ptr %259, align 8, !dbg !3222, !tbaa !1790
  %263 = add i64 %262, 1, !dbg !3222
  store i64 %263, ptr %259, align 8, !dbg !3222, !tbaa !1790
  br label %267, !dbg !3223

264:                                              ; preds = %258
  store i64 1, ptr %28, align 8, !dbg !3224, !tbaa !1790, !DIAssignID !3225
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3225, metadata ptr %28, metadata !DIExpression()), !dbg !3208
  %265 = getelementptr inbounds %struct.metrics_value, ptr %28, i64 0, i32 1, !dbg !3226
  store i64 0, ptr %265, align 8, !dbg !3227, !tbaa !1798, !DIAssignID !3228
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3228, metadata ptr %265, metadata !DIExpression()), !dbg !3208
  %266 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %29, ptr noundef nonnull %28, i32 noundef 0) #6, !dbg !3229
  br label %267

267:                                              ; preds = %264, %261
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %29) #6, !dbg !3230
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %28) #6, !dbg !3230
  br label %348, !dbg !3231

268:                                              ; preds = %249
  %269 = load i32, ptr %256, align 4, !dbg !3232, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %269, metadata !1216, metadata !DIExpression()), !dbg !2945
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %19)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2670, metadata ptr %19, metadata !DIExpression()), !dbg !3233
  store i32 %269, ptr %19, align 4, !tbaa !1129, !DIAssignID !3235
  call void @llvm.dbg.assign(metadata i32 %269, metadata !1707, metadata !DIExpression(), metadata !3235, metadata ptr %19, metadata !DIExpression()), !dbg !3233
  %270 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %19) #6, !dbg !3236
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %19), !dbg !3237
  call void @llvm.dbg.value(metadata ptr %270, metadata !1205, metadata !DIExpression()), !dbg !2945
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !2945
  %271 = icmp eq ptr %270, null, !dbg !3238
  br i1 %271, label %272, label %282, !dbg !3239

272:                                              ; preds = %268
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2677, metadata ptr %26, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2678, metadata ptr %27, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3240
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %26) #6, !dbg !3242
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3243, metadata ptr %26, metadata !DIExpression()), !dbg !3240
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %27) #6, !dbg !3244
  store i64 21503148550, ptr %27, align 8, !dbg !3245, !DIAssignID !3246
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3246, metadata ptr %27, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3247, metadata ptr %27, metadata !DIExpression()), !dbg !3240
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3248, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3240
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3249, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3240
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3250, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3240
  %273 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %27) #6, !dbg !3251
  call void @llvm.dbg.value(metadata ptr %273, metadata !1770, metadata !DIExpression()), !dbg !3240
  %274 = icmp eq ptr %273, null, !dbg !3252
  br i1 %274, label %278, label %275, !dbg !3253

275:                                              ; preds = %272
  %276 = load i64, ptr %273, align 8, !dbg !3254, !tbaa !1790
  %277 = add i64 %276, 1, !dbg !3254
  store i64 %277, ptr %273, align 8, !dbg !3254, !tbaa !1790
  br label %281, !dbg !3255

278:                                              ; preds = %272
  store i64 1, ptr %26, align 8, !dbg !3256, !tbaa !1790, !DIAssignID !3257
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3257, metadata ptr %26, metadata !DIExpression()), !dbg !3240
  %279 = getelementptr inbounds %struct.metrics_value, ptr %26, i64 0, i32 1, !dbg !3258
  store i64 0, ptr %279, align 8, !dbg !3259, !tbaa !1798, !DIAssignID !3260
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3260, metadata ptr %279, metadata !DIExpression()), !dbg !3240
  %280 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %27, ptr noundef nonnull %26, i32 noundef 0) #6, !dbg !3261
  br label %281

281:                                              ; preds = %278, %275
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %27) #6, !dbg !3262
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %26) #6, !dbg !3262
  br label %348, !dbg !3263

282:                                              ; preds = %237, %268
  %283 = phi ptr [ %270, %268 ], [ %238, %237 ]
  %284 = phi i1 [ false, %268 ], [ true, %237 ]
  %285 = phi i32 [ %269, %268 ], [ %235, %237 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3264, !srcloc !1838
  call void @llvm.dbg.value(metadata ptr %116, metadata !1553, metadata !DIExpression()), !dbg !3265
  %286 = load i8, ptr %138, align 4, !dbg !3267, !tbaa !1361
  %287 = and i8 %286, 16, !dbg !3268
  %288 = icmp eq i8 %287, 0, !dbg !3269
  %289 = or i1 %284, %288, !dbg !3270
  br i1 %289, label %312, label %290, !dbg !3270

290:                                              ; preds = %282
  call void @llvm.dbg.value(metadata ptr %116, metadata !1846, metadata !DIExpression()), !dbg !3271
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !3271
  call void @llvm.dbg.value(metadata i32 %285, metadata !1852, metadata !DIExpression()), !dbg !3271
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !2663, metadata ptr %12, metadata !DIExpression()), !dbg !3273
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !2664, metadata ptr %13, metadata !DIExpression()), !dbg !3273
  call void @llvm.dbg.value(metadata ptr %116, metadata !1860, metadata !DIExpression()), !dbg !3273
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !3273
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !3273
  call void @llvm.dbg.value(metadata i32 %285, metadata !1863, metadata !DIExpression()), !dbg !3273
  %291 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3275, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %291, metadata !1623, metadata !DIExpression()), !dbg !3277
  %292 = load volatile i8, ptr %291, align 1, !dbg !3278, !tbaa !1341, !range !1343, !noundef !1344
  %293 = icmp eq i8 %292, 0, !dbg !3278
  br i1 %293, label %297, label %294, !dbg !3279

294:                                              ; preds = %290
  %295 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !3280
  %296 = lshr i64 %295, 8, !dbg !3281
  br label %300, !dbg !3282

297:                                              ; preds = %290
  %298 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !3283
  %299 = udiv i64 %298, 1000000000, !dbg !3285
  br label %300, !dbg !3286

300:                                              ; preds = %297, %294
  %301 = phi i64 [ %296, %294 ], [ %299, %297 ], !dbg !3287
  call void @llvm.dbg.value(metadata i64 %301, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3273
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %12) #6, !dbg !3288
  store i64 %94, ptr %12, align 8, !dbg !3289, !DIAssignID !3290
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3290, metadata ptr %12, metadata !DIExpression()), !dbg !3273
  %302 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 1, !dbg !3291
  %303 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 2, !dbg !3292
  %304 = load i16, ptr %303, align 2, !dbg !3292, !tbaa !1601
  store i16 %304, ptr %302, align 8, !dbg !3291, !tbaa !1602, !DIAssignID !3293
  call void @llvm.dbg.assign(metadata i16 %304, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !3293, metadata ptr %302, metadata !DIExpression()), !dbg !3273
  %305 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 2, !dbg !3291
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !3294, metadata ptr %305, metadata !DIExpression()), !dbg !3273
  store i8 1, ptr %305, align 2, !dbg !3291, !DIAssignID !3295
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !3295, metadata ptr %305, metadata !DIExpression()), !dbg !3273
  %306 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 3, !dbg !3291
  store i8 0, ptr %306, align 1, !dbg !3291, !tbaa !1607, !DIAssignID !3296
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !3296, metadata ptr %306, metadata !DIExpression()), !dbg !3273
  %307 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 4, !dbg !3291
  store i32 0, ptr %307, align 4, !dbg !3291, !tbaa !1609, !DIAssignID !3297
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3297, metadata ptr %307, metadata !DIExpression()), !dbg !3273
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #6, !dbg !3298
  %308 = and i64 %301, 4294967295, !dbg !3299
  store i64 %308, ptr %13, align 8, !dbg !3300, !tbaa !1894, !DIAssignID !3301
  call void @llvm.dbg.assign(metadata i64 %308, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3301, metadata ptr %13, metadata !DIExpression()), !dbg !3273
  %309 = getelementptr inbounds %struct.lb_affinity_val, ptr %13, i64 0, i32 1, !dbg !3300
  store i32 %285, ptr %309, align 8, !dbg !3300, !tbaa !1640, !DIAssignID !3302
  call void @llvm.dbg.assign(metadata i32 %285, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3302, metadata ptr %309, metadata !DIExpression()), !dbg !3273
  %310 = getelementptr inbounds %struct.lb_affinity_val, ptr %13, i64 0, i32 2, !dbg !3300
  store i32 0, ptr %310, align 4, !dbg !3300, !tbaa !1897, !DIAssignID !3303
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3303, metadata ptr %310, metadata !DIExpression()), !dbg !3273
  %311 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %12, ptr noundef nonnull %13, i32 noundef 0) #6, !dbg !3304
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #6, !dbg !3305
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %12) #6, !dbg !3305
  br label %312, !dbg !3306

312:                                              ; preds = %300, %282
  %313 = getelementptr inbounds %struct.lb4_backend, ptr %283, i64 0, i32 1, !dbg !3307
  %314 = getelementptr inbounds %struct.lb4_service, ptr %116, i64 0, i32 2, !dbg !3308
  %315 = load i16, ptr %314, align 2, !dbg !3308, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !2668, metadata ptr %17, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !2669, metadata ptr %18, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata ptr %283, metadata !1911, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata i32 %85, metadata !1912, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata i16 %97, metadata !1913, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata i16 %315, metadata !1914, metadata !DIExpression()), !dbg !3309
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %17) #6, !dbg !3311
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !3312, metadata ptr %17, metadata !DIExpression()), !dbg !3309
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %18) #6, !dbg !3313
  %316 = getelementptr inbounds i8, ptr %18, i64 8, !dbg !3314
  store i64 0, ptr %316, align 8, !dbg !3314, !DIAssignID !3315
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !3315, metadata ptr %18, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3316, metadata ptr undef, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3309
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3317
  %317 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !3319
  store i64 %317, ptr %18, align 8, !dbg !3320, !tbaa !1930, !DIAssignID !3321
  call void @llvm.dbg.assign(metadata i64 %317, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3321, metadata ptr %18, metadata !DIExpression()), !dbg !3309
  %318 = load i32, ptr %283, align 4, !dbg !3322, !tbaa !1934
  %319 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %18, i64 0, i32 1, !dbg !3323
  store i32 %318, ptr %319, align 8, !dbg !3324, !tbaa !1938, !DIAssignID !3325
  call void @llvm.dbg.assign(metadata i32 %318, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3325, metadata ptr %319, metadata !DIExpression()), !dbg !3309
  %320 = load i16, ptr %313, align 4, !dbg !3326, !tbaa !1941
  %321 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %18, i64 0, i32 2, !dbg !3327
  store i16 %320, ptr %321, align 4, !dbg !3328, !tbaa !1944, !DIAssignID !3329
  call void @llvm.dbg.assign(metadata i16 %320, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3329, metadata ptr %321, metadata !DIExpression()), !dbg !3309
  store i32 %85, ptr %17, align 4, !dbg !3330, !tbaa !1947, !DIAssignID !3331
  call void @llvm.dbg.assign(metadata i32 %85, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3331, metadata ptr %17, metadata !DIExpression()), !dbg !3309
  %322 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %17, i64 0, i32 1, !dbg !3332
  store i16 %97, ptr %322, align 4, !dbg !3333, !tbaa !1952, !DIAssignID !3334
  call void @llvm.dbg.assign(metadata i16 %97, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3334, metadata ptr %322, metadata !DIExpression()), !dbg !3309
  %323 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %17, i64 0, i32 2, !dbg !3335
  store i16 %315, ptr %323, align 2, !dbg !3336, !tbaa !1956, !DIAssignID !3337
  call void @llvm.dbg.assign(metadata i16 %315, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3337, metadata ptr %323, metadata !DIExpression()), !dbg !3309
  %324 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %18) #6, !dbg !3338
  call void @llvm.dbg.value(metadata ptr %324, metadata !1915, metadata !DIExpression()), !dbg !3309
  %325 = icmp eq ptr %324, null, !dbg !3339
  br i1 %325, label %331, label %326, !dbg !3340

326:                                              ; preds = %312
  call void @llvm.dbg.value(metadata ptr %324, metadata !1962, metadata !DIExpression()), !dbg !3341
  call void @llvm.dbg.value(metadata ptr %17, metadata !1967, metadata !DIExpression()), !dbg !3341
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !3341
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !3343
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !3343
  call void @llvm.dbg.value(metadata ptr %324, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3343
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3343
  call void @llvm.dbg.label(metadata !1992), !dbg !3345
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !3343
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !3343
  call void @llvm.dbg.value(metadata ptr %324, metadata !1974, metadata !DIExpression()), !dbg !3343
  %327 = load i64, ptr %324, align 8, !dbg !3346, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression()), !dbg !3343
  %328 = load i64, ptr %17, align 8, !dbg !3346, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %327, i64 %328), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !3343
  %329 = icmp eq i64 %327, %328, !dbg !3347
  br i1 %329, label %330, label %331, !dbg !3348

330:                                              ; preds = %326
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3309
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #6, !dbg !3349
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #6, !dbg !3349
  br label %344, !dbg !3350

331:                                              ; preds = %312, %326
  %332 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #6, !dbg !3351
  call void @llvm.dbg.value(metadata i32 %332, metadata !1917, metadata !DIExpression()), !dbg !3309
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #6, !dbg !3349
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #6, !dbg !3349
  %333 = icmp slt i32 %332, 0, !dbg !3352
  br i1 %333, label %334, label %344, !dbg !3350

334:                                              ; preds = %331
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2675, metadata ptr %24, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2676, metadata ptr %25, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3353
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %24) #6, !dbg !3355
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3356, metadata ptr %24, metadata !DIExpression()), !dbg !3353
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %25) #6, !dbg !3357
  store i64 21504197127, ptr %25, align 8, !dbg !3358, !DIAssignID !3359
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3359, metadata ptr %25, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3360, metadata ptr %25, metadata !DIExpression()), !dbg !3353
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3361, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3353
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3362, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3353
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3363, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3353
  %335 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %25) #6, !dbg !3364
  call void @llvm.dbg.value(metadata ptr %335, metadata !1770, metadata !DIExpression()), !dbg !3353
  %336 = icmp eq ptr %335, null, !dbg !3365
  br i1 %336, label %340, label %337, !dbg !3366

337:                                              ; preds = %334
  %338 = load i64, ptr %335, align 8, !dbg !3367, !tbaa !1790
  %339 = add i64 %338, 1, !dbg !3367
  store i64 %339, ptr %335, align 8, !dbg !3367, !tbaa !1790
  br label %343, !dbg !3368

340:                                              ; preds = %334
  store i64 1, ptr %24, align 8, !dbg !3369, !tbaa !1790, !DIAssignID !3370
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3370, metadata ptr %24, metadata !DIExpression()), !dbg !3353
  %341 = getelementptr inbounds %struct.metrics_value, ptr %24, i64 0, i32 1, !dbg !3371
  store i64 0, ptr %341, align 8, !dbg !3372, !tbaa !1798, !DIAssignID !3373
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3373, metadata ptr %341, metadata !DIExpression()), !dbg !3353
  %342 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %25, ptr noundef nonnull %24, i32 noundef 0) #6, !dbg !3374
  br label %343

343:                                              ; preds = %340, %337
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %25) #6, !dbg !3375
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %24) #6, !dbg !3375
  br label %348, !dbg !3376

344:                                              ; preds = %330, %331
  %345 = load i32, ptr %283, align 4, !dbg !3377, !tbaa !1934
  tail call void @llvm.dbg.value(metadata i32 %345, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !2885
  %346 = load i16, ptr %313, align 4, !dbg !3378, !tbaa !1941
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !3379
  call void @llvm.dbg.value(metadata i16 %346, metadata !2038, metadata !DIExpression()), !dbg !3379
  %347 = zext i16 %346 to i32, !dbg !3381
  tail call void @llvm.dbg.value(metadata i16 %346, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !2885
  br label %350, !dbg !3382

348:                                              ; preds = %343, %281, %267, %120, %175, %89, %112, %163, %156, %104, %132, %129
  %349 = phi i32 [ -1, %156 ], [ -1, %163 ], [ -6, %112 ], [ -95, %89 ], [ -6, %175 ], [ -113, %120 ], [ -113, %267 ], [ -113, %281 ], [ -12, %343 ], [ -6, %104 ], [ -113, %132 ], [ -113, %129 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2885
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2885
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %30) #6, !dbg !3383
  call void @llvm.dbg.value(metadata i32 %349, metadata !2884, metadata !DIExpression()), !dbg !2885
  br label %605, !dbg !3384

350:                                              ; preds = %129, %142, %344, %132
  %351 = phi i32 [ %85, %142 ], [ %345, %344 ], [ %85, %132 ], [ %85, %129 ]
  %352 = phi i32 [ %93, %142 ], [ %347, %344 ], [ %93, %132 ], [ %93, %129 ], !dbg !2885
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2885
  tail call void @llvm.dbg.value(metadata i32 %351, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !2885
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %30) #6, !dbg !3383
  call void @llvm.dbg.value(metadata i32 poison, metadata !2884, metadata !DIExpression()), !dbg !2885
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !3385
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3385
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !3385
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !3394
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !3394
  call void @llvm.dbg.label(metadata !1527), !dbg !3396
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2885
  call void @llvm.dbg.label(metadata !1528), !dbg !3397
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2885
  tail call void @llvm.dbg.value(metadata i32 %351, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !2885
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !3404
  call void @llvm.dbg.value(metadata ptr undef, metadata !3403, metadata !DIExpression()), !dbg !3404
  store i32 0, ptr %52, align 8, !dbg !3406, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3407, !srcloc !3408
  store i32 0, ptr %54, align 4, !dbg !3409, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3410, !srcloc !3411
  store i32 -65536, ptr %57, align 8, !dbg !3412, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3413, !srcloc !3414
  store i32 %351, ptr %60, align 4, !dbg !3415, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3416, !srcloc !3417
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !3418
  call void @llvm.dbg.value(metadata i32 %352, metadata !2038, metadata !DIExpression()), !dbg !3418
  store i32 %352, ptr %41, align 8, !dbg !3420, !tbaa !1251
  br label %605, !dbg !3421

353:                                              ; preds = %69, %74
  %354 = phi ptr [ %75, %74 ], [ %67, %69 ]
  call void @llvm.dbg.value(metadata ptr %354, metadata !2704, metadata !DIExpression()), !dbg !2721
  %355 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 1, !dbg !3422
  %356 = load i16, ptr %355, align 4, !dbg !3422, !tbaa !3423
  %357 = icmp eq i16 %356, 0, !dbg !3424
  br i1 %357, label %358, label %376, !dbg !3425

358:                                              ; preds = %353
  %359 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !3426, !srcloc !3427
  call void @llvm.dbg.value(metadata ptr %359, metadata !2713, metadata !DIExpression()), !dbg !3428
  %360 = load volatile i8, ptr %359, align 1, !dbg !3429, !tbaa !1341, !range !1343, !noundef !1344
  %361 = icmp eq i8 %360, 0, !dbg !3429
  br i1 %361, label %362, label %605, !dbg !3430

362:                                              ; preds = %358
  call void @llvm.dbg.value(metadata ptr %354, metadata !3431, metadata !DIExpression()), !dbg !3436
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3439, metadata !DIExpression()), !dbg !3442
  %363 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 3, !dbg !3445
  %364 = load i8, ptr %363, align 4, !dbg !3445, !tbaa !3446
  %365 = and i8 %364, 35, !dbg !3447
  %366 = icmp eq i8 %365, 0, !dbg !3448
  br i1 %366, label %370, label %367, !dbg !3449

367:                                              ; preds = %362
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3450, metadata !DIExpression()), !dbg !3453
  %368 = and i8 %364, 4, !dbg !3455
  %369 = icmp eq i8 %368, 0, !dbg !3456
  br i1 %369, label %605, label %375, !dbg !3457

370:                                              ; preds = %362
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3439, metadata !DIExpression()), !dbg !3458
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3460, metadata !DIExpression()), !dbg !3463
  %371 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 4, !dbg !3465
  %372 = load i8, ptr %371, align 1, !dbg !3465, !tbaa !2865
  %373 = and i8 %372, 16, !dbg !3466
  %374 = icmp eq i8 %373, 0, !dbg !3467
  br i1 %374, label %605, label %375, !dbg !3468

375:                                              ; preds = %370, %367
  br label %605, !dbg !3469

376:                                              ; preds = %353
  call void @llvm.dbg.value(metadata ptr %354, metadata !3470, metadata !DIExpression()), !dbg !3473
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3476, metadata !DIExpression()), !dbg !3479
  %377 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 3, !dbg !3481
  %378 = load i8, ptr %377, align 4, !dbg !3481, !tbaa !3446
  %379 = and i8 %378, 8, !dbg !3482
  %380 = icmp eq i8 %379, 0, !dbg !3483
  br i1 %380, label %381, label %386, !dbg !3484

381:                                              ; preds = %376
  %382 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 4, !dbg !3485
  %383 = load i8, ptr %382, align 1, !dbg !3485, !tbaa !2865
  %384 = and i8 %383, 8, !dbg !3486
  %385 = icmp eq i8 %384, 0, !dbg !3484
  br i1 %385, label %393, label %605, !dbg !3487

386:                                              ; preds = %376
  call void @llvm.dbg.value(metadata ptr %354, metadata !3488, metadata !DIExpression()), !dbg !3497
  call void @llvm.dbg.value(metadata ptr undef, metadata !3493, metadata !DIExpression()), !dbg !3497
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3500, metadata !DIExpression()), !dbg !3503
  %387 = and i8 %378, 1, !dbg !3505
  %388 = icmp eq i8 %387, 0, !dbg !3506
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3476, metadata !DIExpression()), !dbg !3507
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !3509
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !3509
  %389 = icmp eq i64 %64, 0
  %390 = select i1 %388, i1 %389, i1 false, !dbg !3516
  %391 = icmp eq i64 %63, 72057594037927936
  %392 = select i1 %390, i1 %391, i1 false, !dbg !3516
  br i1 %392, label %407, label %396, !dbg !3516

393:                                              ; preds = %381
  call void @llvm.dbg.value(metadata ptr %354, metadata !3488, metadata !DIExpression()), !dbg !3497
  call void @llvm.dbg.value(metadata ptr undef, metadata !3493, metadata !DIExpression()), !dbg !3497
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3500, metadata !DIExpression()), !dbg !3503
  %394 = and i8 %378, 1, !dbg !3505
  %395 = icmp eq i8 %394, 0, !dbg !3506
  br i1 %395, label %407, label %396, !dbg !3516

396:                                              ; preds = %393, %386
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3517, metadata !DIExpression(), metadata !2657, metadata ptr %6, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !3522, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.value(metadata ptr undef, metadata !3523, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.value(metadata i32 128, metadata !3524, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.value(metadata i32 0, metadata !3525, metadata !DIExpression()), !dbg !3526
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #6, !dbg !3528
  %397 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !3529
  store i8 0, ptr %397, align 2, !dbg !3529, !DIAssignID !3530
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(), metadata !3530, metadata ptr %6, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !3531, metadata ptr undef, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 136), metadata !3532, metadata ptr undef, metadata !DIExpression()), !dbg !3526
  store i32 160, ptr %6, align 4, !dbg !3533, !tbaa !3534, !DIAssignID !3535
  call void @llvm.dbg.assign(metadata i32 160, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3535, metadata ptr %6, metadata !DIExpression()), !dbg !3526
  %398 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !3536
  store i8 2, ptr %398, align 1, !dbg !3537, !tbaa !1448, !DIAssignID !3538
  call void @llvm.dbg.assign(metadata i8 2, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !3538, metadata ptr %398, metadata !DIExpression()), !dbg !3526
  %399 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !3539
  store i64 %64, ptr %399, align 4, !dbg !3540, !tbaa.struct !3541, !DIAssignID !3542
  %400 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, i32 0, i32 0, i32 1, !dbg !3540
  store i64 %63, ptr %400, align 4, !dbg !3540, !tbaa.struct !3543, !DIAssignID !3544
  call void @llvm.dbg.assign(metadata i64 %64, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3542, metadata ptr %399, metadata !DIExpression()), !dbg !3526
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !3544, metadata ptr %400, metadata !DIExpression()), !dbg !3526
  %401 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !3545
  store i16 0, ptr %401, align 4, !dbg !3546, !tbaa !1457, !DIAssignID !3547
  call void @llvm.dbg.assign(metadata i16 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3547, metadata ptr %401, metadata !DIExpression()), !dbg !3526
  %402 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #6, !dbg !3548
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #6, !dbg !3549
  call void @llvm.dbg.value(metadata ptr %402, metadata !3494, metadata !DIExpression()), !dbg !3550
  %403 = icmp eq ptr %402, null, !dbg !3551
  br i1 %403, label %605, label %404, !dbg !3553

404:                                              ; preds = %396
  %405 = load i32, ptr %402, align 4, !dbg !3554, !tbaa !1466
  %406 = icmp eq i32 %405, 1, !dbg !3555
  br i1 %406, label %407, label %605, !dbg !3556

407:                                              ; preds = %386, %393, %404
  %408 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !3557, !srcloc !3558
  call void @llvm.dbg.value(metadata ptr %408, metadata !2718, metadata !DIExpression()), !dbg !3559
  %409 = load volatile i8, ptr %408, align 1, !dbg !3560, !tbaa !1341, !range !1343, !noundef !1344
  %410 = icmp eq i8 %409, 0, !dbg !3560
  br i1 %410, label %424, label %411, !dbg !3561

411:                                              ; preds = %407
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3562, metadata !DIExpression()), !dbg !3565
  %412 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 4, !dbg !3567
  %413 = load i8, ptr %412, align 1, !dbg !3567, !tbaa !2865
  %414 = and i8 %413, 1, !dbg !3568
  %415 = icmp eq i8 %414, 0, !dbg !3569
  br i1 %415, label %424, label %416, !dbg !3570

416:                                              ; preds = %411
  %417 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !3571
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3572, metadata !DIExpression(), metadata !2662, metadata ptr %11, metadata !DIExpression()), !dbg !3581
  call void @llvm.dbg.value(metadata i64 %64, metadata !3578, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3581
  call void @llvm.dbg.value(metadata i64 %63, metadata !3578, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3581
  call void @llvm.dbg.value(metadata i64 %417, metadata !3577, metadata !DIExpression()), !dbg !3581
  call void @llvm.dbg.value(metadata i16 %44, metadata !3579, metadata !DIExpression()), !dbg !3581
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %11) #6, !dbg !3583
  call void @llvm.dbg.value(metadata ptr null, metadata !3580, metadata !DIExpression()), !dbg !3581
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !3584
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3584
  call void @llvm.dbg.value(metadata i64 32, metadata !1504, metadata !DIExpression()), !dbg !3584
  call void @llvm.dbg.value(metadata i64 32, metadata !1507, metadata !DIExpression()), !dbg !3586
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 32, DW_OP_stack_value)), !dbg !3586
  call void @llvm.dbg.label(metadata !1525), !dbg !3588
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 24, DW_OP_stack_value)), !dbg !3586
  call void @llvm.dbg.label(metadata !1526), !dbg !3589
  %418 = getelementptr inbounds i8, ptr %11, i64 16, !dbg !3590
  call void @llvm.dbg.value(metadata ptr %418, metadata !1512, metadata !DIExpression()), !dbg !3586
  call void @llvm.dbg.label(metadata !1527), !dbg !3591
  %419 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !3592
  call void @llvm.dbg.value(metadata ptr %419, metadata !1512, metadata !DIExpression()), !dbg !3586
  call void @llvm.dbg.label(metadata !1528), !dbg !3593
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !3586
  %420 = getelementptr inbounds i8, ptr %11, i64 24, !dbg !3590
  store i64 0, ptr %420, align 8, !dbg !3590
  store i64 %417, ptr %11, align 8, !dbg !3594, !tbaa !3595, !DIAssignID !3597
  call void @llvm.dbg.assign(metadata i64 %417, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3597, metadata ptr %11, metadata !DIExpression()), !dbg !3581
  store i64 %64, ptr %419, align 8, !dbg !3598, !tbaa.struct !3541, !DIAssignID !3599
  store i64 %63, ptr %418, align 8, !dbg !3598, !tbaa.struct !3543, !DIAssignID !3600
  call void @llvm.dbg.assign(metadata i64 %64, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3599, metadata ptr %419, metadata !DIExpression()), !dbg !3581
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !3600, metadata ptr %418, metadata !DIExpression()), !dbg !3581
  %421 = getelementptr inbounds %struct.skip_lb6_key, ptr %11, i64 0, i32 3, !dbg !3601
  store i16 %44, ptr %421, align 4, !dbg !3602, !tbaa !3603, !DIAssignID !3604
  call void @llvm.dbg.assign(metadata i16 %44, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 16), metadata !3604, metadata ptr %421, metadata !DIExpression()), !dbg !3581
  %422 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb6, ptr noundef nonnull %11) #6, !dbg !3605
  call void @llvm.dbg.value(metadata ptr %422, metadata !3580, metadata !DIExpression()), !dbg !3581
  %423 = icmp eq ptr %422, null, !dbg !3606
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %11) #6, !dbg !3608
  br i1 %423, label %424, label %605, !dbg !3609

424:                                              ; preds = %416, %411, %407
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3610, metadata !DIExpression()), !dbg !3613
  %425 = load i8, ptr %377, align 4, !dbg !3616, !tbaa !3446
  %426 = and i8 %425, 16, !dbg !3617
  %427 = icmp eq i8 %426, 0, !dbg !3618
  br i1 %427, label %481, label %428, !dbg !3619

428:                                              ; preds = %424
  call void @llvm.dbg.value(metadata ptr %354, metadata !3620, metadata !DIExpression()), !dbg !3627
  call void @llvm.dbg.value(metadata ptr undef, metadata !3626, metadata !DIExpression()), !dbg !3627
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3630, metadata !DIExpression(), metadata !2655, metadata ptr %4, metadata !DIExpression()), !dbg !3648
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3642, metadata !DIExpression(), metadata !2656, metadata ptr %5, metadata !DIExpression()), !dbg !3650
  call void @llvm.dbg.value(metadata ptr %354, metadata !3635, metadata !DIExpression()), !dbg !3648
  call void @llvm.dbg.value(metadata i8 1, metadata !3636, metadata !DIExpression()), !dbg !3648
  call void @llvm.dbg.value(metadata ptr undef, metadata !3637, metadata !DIExpression()), !dbg !3648
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %4) #6, !dbg !3651
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %4, i8 0, i64 24, i1 false), !dbg !3652, !DIAssignID !3653
  call void @llvm.dbg.assign(metadata i8 0, metadata !3630, metadata !DIExpression(), metadata !3653, metadata ptr %4, metadata !DIExpression()), !dbg !3648
  %429 = getelementptr inbounds %struct.lb6_affinity_key, ptr %4, i64 0, i32 1, !dbg !3654
  %430 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 2, !dbg !3655
  %431 = load i16, ptr %430, align 2, !dbg !3655, !tbaa !3656
  store i16 %431, ptr %429, align 8, !dbg !3654, !tbaa !3657, !DIAssignID !3659
  call void @llvm.dbg.assign(metadata i16 %431, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !3659, metadata ptr %429, metadata !DIExpression()), !dbg !3648
  %432 = getelementptr inbounds %struct.lb6_affinity_key, ptr %4, i64 0, i32 2, !dbg !3654
  store i8 1, ptr %432, align 2, !dbg !3654, !DIAssignID !3660
  call void @llvm.dbg.assign(metadata i8 1, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 8), metadata !3660, metadata ptr %432, metadata !DIExpression()), !dbg !3648
  store i64 %39, ptr %4, align 8, !dbg !3661, !tbaa !1444, !DIAssignID !3663
  call void @llvm.dbg.assign(metadata i64 %39, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3663, metadata ptr %4, metadata !DIExpression()), !dbg !3648
  %433 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %4) #6, !dbg !3664
  call void @llvm.dbg.value(metadata ptr %433, metadata !3638, metadata !DIExpression()), !dbg !3648
  %434 = icmp eq ptr %433, null, !dbg !3665
  br i1 %434, label %435, label %436, !dbg !3666

435:                                              ; preds = %428
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !3667
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !2721
  br label %481, !dbg !3668

436:                                              ; preds = %428
  %437 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3669, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %437, metadata !1623, metadata !DIExpression()), !dbg !3671
  %438 = load volatile i8, ptr %437, align 1, !dbg !3672, !tbaa !1341, !range !1343, !noundef !1344
  %439 = icmp eq i8 %438, 0, !dbg !3672
  br i1 %439, label %443, label %440, !dbg !3673

440:                                              ; preds = %436
  %441 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !3674
  %442 = lshr i64 %441, 8, !dbg !3675
  br label %446, !dbg !3676

443:                                              ; preds = %436
  %444 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !3677
  %445 = udiv i64 %444, 1000000000, !dbg !3679
  br label %446, !dbg !3680

446:                                              ; preds = %443, %440
  %447 = phi i64 [ %442, %440 ], [ %445, %443 ], !dbg !3681
  call void @llvm.dbg.value(metadata i64 %447, metadata !3639, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3650
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #6, !dbg !3682
  %448 = getelementptr inbounds %struct.lb_affinity_val, ptr %433, i64 0, i32 1, !dbg !3683
  %449 = load i32, ptr %448, align 1, !dbg !3683, !tbaa !1640
  store i32 %449, ptr %5, align 4, !dbg !3684, !tbaa !1643, !DIAssignID !3685
  call void @llvm.dbg.assign(metadata i32 %449, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3685, metadata ptr %5, metadata !DIExpression()), !dbg !3650
  %450 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !3684
  %451 = load i16, ptr %430, align 2, !dbg !3686, !tbaa !3656
  store i16 %451, ptr %450, align 4, !dbg !3684, !tbaa !1647, !DIAssignID !3687
  call void @llvm.dbg.assign(metadata i16 %451, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3687, metadata ptr %450, metadata !DIExpression()), !dbg !3650
  %452 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !3684
  store i16 0, ptr %452, align 2, !dbg !3684, !tbaa !1649, !DIAssignID !3688
  call void @llvm.dbg.assign(metadata i16 0, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3688, metadata ptr %452, metadata !DIExpression()), !dbg !3650
  %453 = load volatile i64, ptr %433, align 1, !dbg !3689, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %453, metadata !3643, metadata !DIExpression()), !dbg !3690
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3691, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3693, metadata !DIExpression()), !dbg !3698
  %454 = load i32, ptr %354, align 4, !dbg !3700, !tbaa !1444
  %455 = and i32 %454, 16777215, !dbg !3701
  call void @llvm.dbg.value(metadata i32 %455, metadata !1667, metadata !DIExpression()), !dbg !3702
  %456 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3704, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %456, metadata !1672, metadata !DIExpression()), !dbg !3705
  %457 = load volatile i8, ptr %456, align 1, !dbg !3706, !tbaa !1341, !range !1343, !noundef !1344
  %458 = icmp eq i8 %457, 0, !dbg !3706
  br i1 %458, label %464, label %459, !dbg !3707

459:                                              ; preds = %446
  %460 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !3708, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %460, metadata !1675, metadata !DIExpression()), !dbg !3709
  %461 = load volatile i32, ptr %460, align 4, !dbg !3710, !tbaa !1129
  %462 = mul i32 %461, %455, !dbg !3711
  %463 = lshr i32 %462, 8, !dbg !3712
  br label %464, !dbg !3713

464:                                              ; preds = %459, %446
  %465 = phi i32 [ %463, %459 ], [ %455, %446 ], !dbg !3702
  %466 = zext nneg i32 %465 to i64, !dbg !3714
  %467 = add i64 %453, %466, !dbg !3715
  %468 = and i64 %447, 4294967295, !dbg !3716
  %469 = icmp ugt i64 %467, %468, !dbg !3717
  br i1 %469, label %470, label %473, !dbg !3718

470:                                              ; preds = %464
  %471 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #6, !dbg !3719
  %472 = icmp eq ptr %471, null, !dbg !3719
  br i1 %472, label %473, label %475, !dbg !3721

473:                                              ; preds = %470, %464
  %474 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %4) #6, !dbg !3650
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !3722
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !3667
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !2721
  br label %481, !dbg !3668

475:                                              ; preds = %470
  call void @llvm.dbg.value(metadata i64 %468, metadata !3646, metadata !DIExpression()), !dbg !3723
  store volatile i64 %468, ptr %433, align 1, !dbg !3724, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3725, !srcloc !1657
  %476 = load i32, ptr %448, align 1, !dbg !3727, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !3722
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !3667
  call void @llvm.dbg.value(metadata i32 %476, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !2721
  %477 = icmp eq i32 %476, 0, !dbg !3728
  br i1 %477, label %481, label %478, !dbg !3668

478:                                              ; preds = %475
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3730, metadata !DIExpression(), metadata !2661, metadata ptr %10, metadata !DIExpression()), !dbg !3735
  store i32 %476, ptr %10, align 4, !tbaa !1129, !DIAssignID !3738
  call void @llvm.dbg.assign(metadata i32 %476, metadata !3730, metadata !DIExpression(), metadata !3738, metadata ptr %10, metadata !DIExpression()), !dbg !3735
  %479 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_backends_v3, ptr noundef nonnull %10) #6, !dbg !3739
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !3740
  call void @llvm.dbg.value(metadata ptr %479, metadata !2701, metadata !DIExpression()), !dbg !2721
  %480 = icmp eq ptr %479, null, !dbg !3741
  call void @llvm.dbg.value(metadata i32 undef, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3743, !srcloc !3744
  br i1 %480, label %481, label %523, !dbg !3745

481:                                              ; preds = %478, %475, %424, %435, %473
  call void @llvm.dbg.value(metadata ptr poison, metadata !2701, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 0, metadata !2711, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !3746
  %482 = load i32, ptr %45, align 4, !dbg !3750, !tbaa !1259
  %483 = and i32 %482, 255, !dbg !3750
  %484 = icmp eq i32 %483, 6, !dbg !3751
  br i1 %484, label %485, label %488, !dbg !3750

485:                                              ; preds = %481
  %486 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !3752
  %487 = zext i32 %486 to i64, !dbg !3752
  br label %490, !dbg !3750

488:                                              ; preds = %481
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3753
  %489 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !3755
  br label %490, !dbg !3750

490:                                              ; preds = %485, %488
  %491 = phi i64 [ %487, %485 ], [ %489, %488 ], !dbg !3750
  %492 = load i16, ptr %355, align 4, !dbg !3756, !tbaa !3423
  %493 = zext i16 %492 to i64, !dbg !3757
  %494 = urem i64 %491, %493, !dbg !3758
  %495 = trunc i64 %494 to i16, !dbg !3759
  %496 = add nuw i16 %495, 1, !dbg !3759
  store i16 %496, ptr %65, align 2, !dbg !3760, !tbaa !2841, !DIAssignID !3761
  call void @llvm.dbg.assign(metadata i16 %496, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 16), metadata !3761, metadata ptr %65, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata ptr %38, metadata !3762, metadata !DIExpression()), !dbg !3765
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !3767
  %497 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !3769
  call void @llvm.dbg.value(metadata ptr %497, metadata !2710, metadata !DIExpression()), !dbg !2721
  %498 = icmp eq ptr %497, null, !dbg !3770
  br i1 %498, label %499, label %509, !dbg !3772

499:                                              ; preds = %490
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2687, metadata ptr %36, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2688, metadata ptr %37, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.value(metadata i16 1123, metadata !1768, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3773
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %36) #6, !dbg !3776
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3777, metadata ptr %36, metadata !DIExpression()), !dbg !3773
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %37) #6, !dbg !3778
  store i64 21548433925, ptr %37, align 8, !dbg !3779, !DIAssignID !3780
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3780, metadata ptr %37, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3781, metadata ptr %37, metadata !DIExpression()), !dbg !3773
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3782, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3773
  call void @llvm.dbg.assign(metadata i16 1123, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3783, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3773
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3784, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3773
  %500 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %37) #6, !dbg !3785
  call void @llvm.dbg.value(metadata ptr %500, metadata !1770, metadata !DIExpression()), !dbg !3773
  %501 = icmp eq ptr %500, null, !dbg !3786
  br i1 %501, label %505, label %502, !dbg !3787

502:                                              ; preds = %499
  %503 = load i64, ptr %500, align 8, !dbg !3788, !tbaa !1790
  %504 = add i64 %503, 1, !dbg !3788
  store i64 %504, ptr %500, align 8, !dbg !3788, !tbaa !1790
  br label %508, !dbg !3789

505:                                              ; preds = %499
  store i64 1, ptr %36, align 8, !dbg !3790, !tbaa !1790, !DIAssignID !3791
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3791, metadata ptr %36, metadata !DIExpression()), !dbg !3773
  %506 = getelementptr inbounds %struct.metrics_value, ptr %36, i64 0, i32 1, !dbg !3792
  store i64 0, ptr %506, align 8, !dbg !3793, !tbaa !1798, !DIAssignID !3794
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3794, metadata ptr %506, metadata !DIExpression()), !dbg !3773
  %507 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %37, ptr noundef nonnull %36, i32 noundef 0) #6, !dbg !3795
  br label %508

508:                                              ; preds = %502, %505
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %37) #6, !dbg !3796
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %36) #6, !dbg !3796
  br label %605, !dbg !3797

509:                                              ; preds = %490
  %510 = load i32, ptr %497, align 4, !dbg !3798, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %510, metadata !2712, metadata !DIExpression()), !dbg !2721
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3730, metadata !DIExpression(), metadata !2660, metadata ptr %9, metadata !DIExpression()), !dbg !3799
  store i32 %510, ptr %9, align 4, !tbaa !1129, !DIAssignID !3801
  call void @llvm.dbg.assign(metadata i32 %510, metadata !3730, metadata !DIExpression(), metadata !3801, metadata ptr %9, metadata !DIExpression()), !dbg !3799
  %511 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_backends_v3, ptr noundef nonnull %9) #6, !dbg !3802
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !3803
  call void @llvm.dbg.value(metadata ptr %511, metadata !2701, metadata !DIExpression()), !dbg !2721
  call void @llvm.dbg.value(metadata i8 poison, metadata !2711, metadata !DIExpression()), !dbg !2721
  %512 = icmp eq ptr %511, null, !dbg !3804
  br i1 %512, label %513, label %523, !dbg !3806

513:                                              ; preds = %509
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2685, metadata ptr %34, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2686, metadata ptr %35, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.value(metadata i16 1132, metadata !1768, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3807
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %34) #6, !dbg !3810
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3811, metadata ptr %34, metadata !DIExpression()), !dbg !3807
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %35) #6, !dbg !3812
  store i64 21549023750, ptr %35, align 8, !dbg !3813, !DIAssignID !3814
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3814, metadata ptr %35, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3815, metadata ptr %35, metadata !DIExpression()), !dbg !3807
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3816, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3807
  call void @llvm.dbg.assign(metadata i16 1132, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3817, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3807
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3818, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3807
  %514 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %35) #6, !dbg !3819
  call void @llvm.dbg.value(metadata ptr %514, metadata !1770, metadata !DIExpression()), !dbg !3807
  %515 = icmp eq ptr %514, null, !dbg !3820
  br i1 %515, label %519, label %516, !dbg !3821

516:                                              ; preds = %513
  %517 = load i64, ptr %514, align 8, !dbg !3822, !tbaa !1790
  %518 = add i64 %517, 1, !dbg !3822
  store i64 %518, ptr %514, align 8, !dbg !3822, !tbaa !1790
  br label %522, !dbg !3823

519:                                              ; preds = %513
  store i64 1, ptr %34, align 8, !dbg !3824, !tbaa !1790, !DIAssignID !3825
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3825, metadata ptr %34, metadata !DIExpression()), !dbg !3807
  %520 = getelementptr inbounds %struct.metrics_value, ptr %34, i64 0, i32 1, !dbg !3826
  store i64 0, ptr %520, align 8, !dbg !3827, !tbaa !1798, !DIAssignID !3828
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3828, metadata ptr %520, metadata !DIExpression()), !dbg !3807
  %521 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %35, ptr noundef nonnull %34, i32 noundef 0) #6, !dbg !3829
  br label %522

522:                                              ; preds = %516, %519
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %35) #6, !dbg !3830
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %34) #6, !dbg !3830
  br label %605, !dbg !3831

523:                                              ; preds = %478, %509
  %524 = phi ptr [ %511, %509 ], [ %479, %478 ]
  %525 = phi i1 [ false, %509 ], [ true, %478 ]
  %526 = phi i32 [ %510, %509 ], [ %476, %478 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3832, !srcloc !3833
  tail call void @llvm.dbg.value(metadata ptr %354, metadata !3610, metadata !DIExpression()), !dbg !3834
  %527 = load i8, ptr %377, align 4, !dbg !3837, !tbaa !3446
  %528 = and i8 %527, 16, !dbg !3838
  %529 = icmp eq i8 %528, 0, !dbg !3839
  %530 = or i1 %525, %529, !dbg !3840
  br i1 %530, label %552, label %531, !dbg !3840

531:                                              ; preds = %523
  call void @llvm.dbg.value(metadata ptr %354, metadata !3841, metadata !DIExpression()), !dbg !3848
  call void @llvm.dbg.value(metadata ptr undef, metadata !3846, metadata !DIExpression()), !dbg !3848
  call void @llvm.dbg.value(metadata i32 %526, metadata !3847, metadata !DIExpression()), !dbg !3848
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3850, metadata !DIExpression(), metadata !2653, metadata ptr %2, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3860, metadata !DIExpression(), metadata !2654, metadata ptr %3, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.value(metadata ptr %354, metadata !3855, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.value(metadata i8 1, metadata !3856, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.value(metadata ptr undef, metadata !3857, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.value(metadata i32 %526, metadata !3858, metadata !DIExpression()), !dbg !3861
  %532 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !3863, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %532, metadata !1623, metadata !DIExpression()), !dbg !3865
  %533 = load volatile i8, ptr %532, align 1, !dbg !3866, !tbaa !1341, !range !1343, !noundef !1344
  %534 = icmp eq i8 %533, 0, !dbg !3866
  br i1 %534, label %538, label %535, !dbg !3867

535:                                              ; preds = %531
  %536 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !3868
  %537 = lshr i64 %536, 8, !dbg !3869
  br label %541, !dbg !3870

538:                                              ; preds = %531
  %539 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !3871
  %540 = udiv i64 %539, 1000000000, !dbg !3873
  br label %541, !dbg !3874

541:                                              ; preds = %535, %538
  %542 = phi i64 [ %537, %535 ], [ %540, %538 ], !dbg !3875
  call void @llvm.dbg.value(metadata i64 %542, metadata !3859, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3861
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %2) #6, !dbg !3876
  %543 = getelementptr inbounds i8, ptr %2, i64 8, !dbg !3877
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %543, i8 0, i64 16, i1 false), !dbg !3877, !DIAssignID !3878
  call void @llvm.dbg.assign(metadata i8 0, metadata !3850, metadata !DIExpression(), metadata !3878, metadata ptr %2, metadata !DIExpression()), !dbg !3861
  call void @llvm.dbg.assign(metadata i8 0, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3879, metadata ptr undef, metadata !DIExpression()), !dbg !3861
  %544 = getelementptr inbounds %struct.lb6_affinity_key, ptr %2, i64 0, i32 1, !dbg !3880
  %545 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 2, !dbg !3881
  %546 = load i16, ptr %545, align 2, !dbg !3881, !tbaa !3656
  store i16 %546, ptr %544, align 8, !dbg !3880, !tbaa !3657, !DIAssignID !3882
  call void @llvm.dbg.assign(metadata i16 %546, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !3882, metadata ptr %544, metadata !DIExpression()), !dbg !3861
  %547 = getelementptr inbounds %struct.lb6_affinity_key, ptr %2, i64 0, i32 2, !dbg !3880
  store i8 1, ptr %547, align 2, !dbg !3880, !DIAssignID !3883
  call void @llvm.dbg.assign(metadata i8 1, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 8), metadata !3883, metadata ptr %547, metadata !DIExpression()), !dbg !3861
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !3884
  %548 = and i64 %542, 4294967295, !dbg !3885
  store i64 %548, ptr %3, align 8, !dbg !3886, !tbaa !1894, !DIAssignID !3887
  call void @llvm.dbg.assign(metadata i64 %548, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3887, metadata ptr %3, metadata !DIExpression()), !dbg !3861
  %549 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !3886
  store i32 %526, ptr %549, align 8, !dbg !3886, !tbaa !1640, !DIAssignID !3888
  call void @llvm.dbg.assign(metadata i32 %526, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3888, metadata ptr %549, metadata !DIExpression()), !dbg !3861
  %550 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !3886
  store i32 0, ptr %550, align 4, !dbg !3886, !tbaa !1897, !DIAssignID !3889
  call void @llvm.dbg.assign(metadata i32 0, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3889, metadata ptr %550, metadata !DIExpression()), !dbg !3861
  store i64 %39, ptr %2, align 8, !dbg !3890, !tbaa !1444, !DIAssignID !3892
  call void @llvm.dbg.assign(metadata i64 %39, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3892, metadata ptr %2, metadata !DIExpression()), !dbg !3861
  %551 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !3893
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !3894
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %2) #6, !dbg !3894
  br label %552, !dbg !3895

552:                                              ; preds = %541, %523
  %553 = getelementptr inbounds %struct.lb6_backend, ptr %524, i64 0, i32 1, !dbg !3896
  %554 = getelementptr inbounds %struct.lb6_service, ptr %354, i64 0, i32 2, !dbg !3897
  %555 = load i16, ptr %554, align 2, !dbg !3897, !tbaa !3656
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3899, metadata !DIExpression(), metadata !2658, metadata ptr %7, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3910, metadata !DIExpression(), metadata !2659, metadata ptr %8, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata ptr %0, metadata !3904, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata ptr %524, metadata !3905, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata ptr undef, metadata !3906, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata i16 %44, metadata !3907, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata i16 %555, metadata !3908, metadata !DIExpression()), !dbg !3912
  call void @llvm.lifetime.start.p0(i64 20, ptr nonnull %7) #6, !dbg !3914
  call void @llvm.dbg.assign(metadata i8 0, metadata !3899, metadata !DIExpression(), metadata !3915, metadata ptr %7, metadata !DIExpression()), !dbg !3912
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %8) #6, !dbg !3916
  %556 = getelementptr inbounds i8, ptr %8, i64 24, !dbg !3917
  store i64 0, ptr %556, align 8, !dbg !3917, !DIAssignID !3918
  call void @llvm.dbg.assign(metadata i64 0, metadata !3910, metadata !DIExpression(), metadata !3918, metadata ptr %8, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.assign(metadata i8 0, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 192), metadata !3919, metadata ptr undef, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata i32 0, metadata !3911, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3920
  %557 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !3922
  store i64 %557, ptr %8, align 8, !dbg !3923, !tbaa !3924, !DIAssignID !3926
  call void @llvm.dbg.assign(metadata i64 %557, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3926, metadata ptr %8, metadata !DIExpression()), !dbg !3912
  %558 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !3927
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %558, ptr noundef nonnull align 2 dereferenceable(16) %524, i64 16, i1 false), !dbg !3928, !tbaa.struct !3541, !DIAssignID !3929
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 128), metadata !3929, metadata ptr %558, metadata !DIExpression()), !dbg !3912
  %559 = load i16, ptr %553, align 2, !dbg !3930, !tbaa !3931
  %560 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !3933
  store i16 %559, ptr %560, align 8, !dbg !3934, !tbaa !3935, !DIAssignID !3936
  call void @llvm.dbg.assign(metadata i16 %559, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 16), metadata !3936, metadata ptr %560, metadata !DIExpression()), !dbg !3912
  store i64 %64, ptr %7, align 8, !dbg !3937, !tbaa.struct !3541, !DIAssignID !3938
  %561 = getelementptr inbounds i8, ptr %7, i64 8, !dbg !3937
  store i64 %63, ptr %561, align 8, !dbg !3937, !tbaa.struct !3543, !DIAssignID !3939
  call void @llvm.dbg.assign(metadata i64 %64, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3938, metadata ptr %7, metadata !DIExpression()), !dbg !3912
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3939, metadata ptr %561, metadata !DIExpression()), !dbg !3912
  %562 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %7, i64 0, i32 1, !dbg !3940
  store i16 %44, ptr %562, align 8, !dbg !3941, !tbaa !3942, !DIAssignID !3944
  call void @llvm.dbg.assign(metadata i16 %44, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !3944, metadata ptr %562, metadata !DIExpression()), !dbg !3912
  %563 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %7, i64 0, i32 2, !dbg !3945
  store i16 %555, ptr %563, align 2, !dbg !3946, !tbaa !3947, !DIAssignID !3948
  call void @llvm.dbg.assign(metadata i16 %555, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 16), metadata !3948, metadata ptr %563, metadata !DIExpression()), !dbg !3912
  %564 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %8) #6, !dbg !3949
  call void @llvm.dbg.value(metadata ptr %564, metadata !3909, metadata !DIExpression()), !dbg !3912
  %565 = icmp eq ptr %564, null, !dbg !3950
  br i1 %565, label %581, label %566, !dbg !3952

566:                                              ; preds = %552
  call void @llvm.dbg.value(metadata ptr %564, metadata !1962, metadata !DIExpression()), !dbg !3953
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !3953
  call void @llvm.dbg.value(metadata i64 20, metadata !1968, metadata !DIExpression()), !dbg !3953
  call void @llvm.dbg.value(metadata i64 20, metadata !1971, metadata !DIExpression()), !dbg !3955
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !3955
  call void @llvm.dbg.value(metadata ptr %564, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 20, DW_OP_stack_value)), !dbg !3955
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 20, DW_OP_stack_value)), !dbg !3955
  %567 = getelementptr inbounds i8, ptr %564, i64 16, !dbg !3957
  call void @llvm.dbg.value(metadata ptr %567, metadata !1974, metadata !DIExpression()), !dbg !3955
  %568 = load i32, ptr %567, align 4, !dbg !3957, !tbaa !1129
  call void @llvm.dbg.value(metadata ptr %562, metadata !1975, metadata !DIExpression()), !dbg !3955
  %569 = load i32, ptr %562, align 8, !dbg !3957, !tbaa !1129
  %570 = xor i32 %569, %568, !dbg !3957
  %571 = zext i32 %570 to i64, !dbg !3957
  call void @llvm.dbg.value(metadata i64 %571, metadata !1976, metadata !DIExpression()), !dbg !3955
  call void @llvm.dbg.label(metadata !1991), !dbg !3958
  %572 = getelementptr inbounds i8, ptr %564, i64 8, !dbg !3959
  call void @llvm.dbg.value(metadata ptr %572, metadata !1974, metadata !DIExpression()), !dbg !3955
  %573 = load i64, ptr %572, align 8, !dbg !3959, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %561, metadata !1975, metadata !DIExpression()), !dbg !3955
  %574 = xor i64 %63, %573, !dbg !3959
  %575 = or i64 %574, %571, !dbg !3959
  call void @llvm.dbg.value(metadata i64 %575, metadata !1976, metadata !DIExpression()), !dbg !3955
  call void @llvm.dbg.label(metadata !1992), !dbg !3960
  call void @llvm.dbg.value(metadata ptr %561, metadata !1975, metadata !DIExpression(DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !3955
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !3955
  call void @llvm.dbg.value(metadata ptr %564, metadata !1974, metadata !DIExpression()), !dbg !3955
  %576 = load i64, ptr %564, align 8, !dbg !3961, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !3955
  call void @llvm.dbg.value(metadata !DIArgList(i64 %575, i64 %576, i64 %64), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !3955
  %577 = xor i64 %64, %576, !dbg !3961
  call void @llvm.dbg.value(metadata !DIArgList(i64 %575, i64 %577), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !3955
  %578 = or i64 %575, %577, !dbg !3961
  call void @llvm.dbg.value(metadata i64 %578, metadata !1976, metadata !DIExpression()), !dbg !3955
  %579 = icmp eq i64 %578, 0, !dbg !3962
  br i1 %579, label %580, label %581, !dbg !3963

580:                                              ; preds = %566
  call void @llvm.dbg.value(metadata i32 0, metadata !3911, metadata !DIExpression()), !dbg !3912
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %8) #6, !dbg !3964
  call void @llvm.lifetime.end.p0(i64 20, ptr nonnull %7) #6, !dbg !3964
  br label %595, !dbg !3965

581:                                              ; preds = %552, %566
  %582 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #6, !dbg !3966
  call void @llvm.dbg.value(metadata i32 %582, metadata !3911, metadata !DIExpression()), !dbg !3912
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %8) #6, !dbg !3964
  call void @llvm.lifetime.end.p0(i64 20, ptr nonnull %7) #6, !dbg !3964
  %583 = icmp slt i32 %582, 0, !dbg !3967
  br i1 %583, label %584, label %595, !dbg !3965

584:                                              ; preds = %581
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2683, metadata ptr %32, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2684, metadata ptr %33, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.value(metadata i16 1148, metadata !1768, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3968
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %32) #6, !dbg !3971
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3972, metadata ptr %32, metadata !DIExpression()), !dbg !3968
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %33) #6, !dbg !3973
  store i64 21550072327, ptr %33, align 8, !dbg !3974, !DIAssignID !3975
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3975, metadata ptr %33, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3976, metadata ptr %33, metadata !DIExpression()), !dbg !3968
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3977, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3968
  call void @llvm.dbg.assign(metadata i16 1148, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3978, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3968
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3979, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3968
  %585 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %33) #6, !dbg !3980
  call void @llvm.dbg.value(metadata ptr %585, metadata !1770, metadata !DIExpression()), !dbg !3968
  %586 = icmp eq ptr %585, null, !dbg !3981
  br i1 %586, label %590, label %587, !dbg !3982

587:                                              ; preds = %584
  %588 = load i64, ptr %585, align 8, !dbg !3983, !tbaa !1790
  %589 = add i64 %588, 1, !dbg !3983
  store i64 %589, ptr %585, align 8, !dbg !3983, !tbaa !1790
  br label %593, !dbg !3984

590:                                              ; preds = %584
  store i64 1, ptr %32, align 8, !dbg !3985, !tbaa !1790, !DIAssignID !3986
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3986, metadata ptr %32, metadata !DIExpression()), !dbg !3968
  %591 = getelementptr inbounds %struct.metrics_value, ptr %32, i64 0, i32 1, !dbg !3987
  store i64 0, ptr %591, align 8, !dbg !3988, !tbaa !1798, !DIAssignID !3989
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3989, metadata ptr %591, metadata !DIExpression()), !dbg !3968
  %592 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %33, ptr noundef nonnull %32, i32 noundef 0) #6, !dbg !3990
  br label %593

593:                                              ; preds = %590, %587
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %33) #6, !dbg !3991
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %32) #6, !dbg !3991
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %38) #6, !dbg !3992
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !2652, metadata !DIExpression()), !dbg !2690
  %594 = call i1 @llvm.bpf.passthrough.i1.i1(i32 2, i1 false)
  br label %611, !dbg !3993

595:                                              ; preds = %580, %581
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata ptr %524, metadata !3403, metadata !DIExpression()), !dbg !3995
  %596 = load i32, ptr %524, align 1, !dbg !3997, !tbaa !1444
  store i32 %596, ptr %52, align 8, !dbg !3998, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !3999, !srcloc !3408
  %597 = getelementptr inbounds %struct.anon, ptr %524, i64 0, i32 1, !dbg !4000
  %598 = load i32, ptr %597, align 1, !dbg !4000, !tbaa !1444
  store i32 %598, ptr %54, align 4, !dbg !4001, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4002, !srcloc !3411
  %599 = getelementptr inbounds %struct.anon, ptr %524, i64 0, i32 2, !dbg !4003
  %600 = load i32, ptr %599, align 1, !dbg !4003, !tbaa !1444
  store i32 %600, ptr %57, align 8, !dbg !4004, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4005, !srcloc !3414
  %601 = getelementptr inbounds %struct.anon, ptr %524, i64 0, i32 3, !dbg !4006
  %602 = load i32, ptr %601, align 1, !dbg !4006, !tbaa !1444
  store i32 %602, ptr %60, align 4, !dbg !4007, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4008, !srcloc !3417
  %603 = load i16, ptr %553, align 2, !dbg !4009, !tbaa !3931
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !4010
  tail call void @llvm.dbg.value(metadata i16 %603, metadata !2038, metadata !DIExpression()), !dbg !4010
  %604 = zext i16 %603 to i32, !dbg !4012
  store i32 %604, ptr %41, align 8, !dbg !4013, !tbaa !1251
  br label %605, !dbg !4014

605:                                              ; preds = %367, %77, %396, %404, %375, %370, %350, %348, %1, %358, %381, %416, %508, %522, %595
  %606 = phi i32 [ 0, %595 ], [ -113, %522 ], [ -113, %508 ], [ -113, %358 ], [ 1, %381 ], [ -6, %416 ], [ -95, %1 ], [ 0, %350 ], [ %349, %348 ], [ -113, %375 ], [ 0, %370 ], [ -1, %404 ], [ -1, %396 ], [ -6, %77 ], [ 0, %367 ], !dbg !2721
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %38) #6, !dbg !3992
  tail call void @llvm.dbg.value(metadata i32 %606, metadata !2652, metadata !DIExpression()), !dbg !2690
  %607 = icmp eq i32 %606, -113, !dbg !4015
  %608 = icmp eq i32 %606, -12
  %609 = call i1 @llvm.bpf.passthrough.i1.i1(i32 2, i1 %607)
  %610 = or i1 %608, %609, !dbg !3993
  br i1 %610, label %611, label %612, !dbg !3993

611:                                              ; preds = %593, %605
  br label %612, !dbg !4016

612:                                              ; preds = %605, %611
  %613 = phi i32 [ 0, %611 ], [ 1, %605 ], !dbg !2690
  ret i32 %613, !dbg !4018
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock6_sendmsg(ptr noundef %0) #0 section "cgroup/sendmsg6" !dbg !4019 {
  %2 = alloca %struct.lb6_affinity_key, align 8, !DIAssignID !4023
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !4024
  %4 = alloca %struct.lb6_affinity_key, align 8, !DIAssignID !4025
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !4026
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !4027
  %7 = alloca %struct.ipv6_revnat_entry, align 8, !DIAssignID !4028
  %8 = alloca %struct.ipv6_revnat_tuple, align 8, !DIAssignID !4029
  %9 = alloca i32, align 4, !DIAssignID !4030
  %10 = alloca i32, align 4, !DIAssignID !4031
  %11 = alloca %struct.skip_lb6_key, align 8, !DIAssignID !4032
  %12 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !4033
  %13 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !4034
  %14 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !4035
  %15 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !4036
  %16 = alloca %struct.ipcache_key, align 4, !DIAssignID !4037
  %17 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !4038
  %18 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !4039
  %19 = alloca i32, align 4, !DIAssignID !4040
  %20 = alloca i32, align 4, !DIAssignID !4041
  %21 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !4042
  %22 = alloca i32, align 4, !DIAssignID !4043
  %23 = alloca i32, align 4, !DIAssignID !4044
  %24 = alloca %struct.metrics_value, align 8, !DIAssignID !4045
  %25 = alloca %struct.metrics_key, align 8, !DIAssignID !4046
  %26 = alloca %struct.metrics_value, align 8, !DIAssignID !4047
  %27 = alloca %struct.metrics_key, align 8, !DIAssignID !4048
  %28 = alloca %struct.metrics_value, align 8, !DIAssignID !4049
  %29 = alloca %struct.metrics_key, align 8, !DIAssignID !4050
  %30 = alloca %struct.lb4_key, align 4, !DIAssignID !4051
  %31 = alloca i32, align 4, !DIAssignID !4052
  %32 = alloca %struct.metrics_value, align 8, !DIAssignID !4053
  %33 = alloca %struct.metrics_key, align 8, !DIAssignID !4054
  %34 = alloca %struct.metrics_value, align 8, !DIAssignID !4055
  %35 = alloca %struct.metrics_key, align 8, !DIAssignID !4056
  %36 = alloca %struct.metrics_value, align 8, !DIAssignID !4057
  %37 = alloca %struct.metrics_key, align 8, !DIAssignID !4058
  %38 = alloca %struct.lb6_key, align 8, !DIAssignID !4059
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !4021, metadata !DIExpression()), !dbg !4060
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2691, metadata !DIExpression(), metadata !4059, metadata ptr %38, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %0, metadata !2696, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i1 true, metadata !2697, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4061
  call void @llvm.dbg.value(metadata i1 false, metadata !2698, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !4063
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !4063
  %39 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #6, !dbg !4065
  call void @llvm.dbg.value(metadata i64 %39, metadata !1234, metadata !DIExpression()), !dbg !4063
  tail call void @llvm.dbg.value(metadata i64 %39, metadata !2699, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4061
  %40 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !4066
  call void @llvm.dbg.value(metadata !DIArgList(i64 %39, i64 %40), metadata !2700, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4061
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !4052, metadata ptr %31, metadata !DIExpression()), !dbg !4067
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !4067
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %31), !dbg !4069
  %41 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !4070
  %42 = load i32, ptr %41, align 8, !dbg !4070, !tbaa !1251
  store volatile i32 %42, ptr %31, align 4, !dbg !4071, !tbaa !1129, !DIAssignID !4072
  call void @llvm.dbg.assign(metadata i32 %42, metadata !1239, metadata !DIExpression(), metadata !4072, metadata ptr %31, metadata !DIExpression()), !dbg !4067
  %43 = load volatile i32, ptr %31, align 4, !dbg !4073, !tbaa !1129
  %44 = trunc i32 %43 to i16, !dbg !4074
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %31), !dbg !4075
  call void @llvm.dbg.value(metadata i16 %44, metadata !2707, metadata !DIExpression()), !dbg !4061
  %45 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !4076
  %46 = load i32, ptr %45, align 4, !dbg !4076, !tbaa !1259
  %47 = trunc i32 %46 to i8, !dbg !4076
  call void @llvm.dbg.value(metadata i8 %47, metadata !2708, metadata !DIExpression()), !dbg !4061
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %38) #6, !dbg !4077
  %48 = getelementptr inbounds i8, ptr %38, i64 16, !dbg !4078
  store i64 0, ptr %48, align 8, !dbg !4078, !DIAssignID !4079
  call void @llvm.dbg.assign(metadata i64 0, metadata !2691, metadata !DIExpression(), metadata !4079, metadata ptr %38, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.assign(metadata i8 0, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128), metadata !4080, metadata ptr undef, metadata !DIExpression()), !dbg !4061
  %49 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 1, !dbg !4081
  store i16 %44, ptr %49, align 8, !dbg !4081, !tbaa !2742, !DIAssignID !4082
  call void @llvm.dbg.assign(metadata i16 %44, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !4082, metadata ptr %49, metadata !DIExpression()), !dbg !4061
  %50 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 3, !dbg !4081
  store i8 %47, ptr %50, align 4, !dbg !4081, !tbaa !2745, !DIAssignID !4083
  call void @llvm.dbg.assign(metadata i8 %47, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 8), metadata !4083, metadata ptr %50, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 0, metadata !2711, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !4084
  call void @llvm.dbg.value(metadata ptr %38, metadata !2757, metadata !DIExpression()), !dbg !4084
  %51 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !4086
  %52 = load i32, ptr %51, align 8, !dbg !4087, !tbaa !1129
  store i32 %52, ptr %38, align 8, !dbg !4088, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !4089, !srcloc !2764
  %53 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !4090
  %54 = load i32, ptr %53, align 4, !dbg !4090, !tbaa !1129
  %55 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 1, !dbg !4091
  store i32 %54, ptr %55, align 4, !dbg !4092, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !4093, !srcloc !2769
  %56 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !4094
  %57 = load i32, ptr %56, align 8, !dbg !4094, !tbaa !1129
  %58 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 2, !dbg !4095
  store i32 %57, ptr %58, align 8, !dbg !4096, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !4097, !srcloc !2774
  %59 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !4098
  %60 = load i32, ptr %59, align 4, !dbg !4098, !tbaa !1129
  %61 = getelementptr inbounds %struct.anon, ptr %38, i64 0, i32 3, !dbg !4099
  store i32 %60, ptr %61, align 4, !dbg !4100, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !4101, !srcloc !2779
  call void @llvm.dbg.value(metadata ptr undef, metadata !2780, metadata !DIExpression()), !dbg !4102
  call void @llvm.dbg.value(metadata ptr %38, metadata !2787, metadata !DIExpression()), !dbg !4102
  call void @llvm.dbg.value(metadata ptr undef, metadata !2790, metadata !DIExpression()), !dbg !4104
  call void @llvm.dbg.value(metadata ptr %38, metadata !2795, metadata !DIExpression()), !dbg !4104
  call void @llvm.dbg.value(metadata i64 16, metadata !2796, metadata !DIExpression()), !dbg !4104
  tail call void @llvm.dbg.value(metadata i64 16, metadata !2799, metadata !DIExpression()), !dbg !4106
  tail call void @llvm.dbg.value(metadata ptr %38, metadata !2803, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !4106
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2802, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !4106
  call void @llvm.dbg.label(metadata !2818), !dbg !4108
  tail call void @llvm.dbg.value(metadata ptr %58, metadata !2803, metadata !DIExpression()), !dbg !4106
  %62 = load i64, ptr %58, align 8, !dbg !4109, !tbaa !1534
  tail call void @llvm.dbg.value(metadata i64 %62, metadata !2709, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4061
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2802, metadata !DIExpression()), !dbg !4106
  call void @llvm.dbg.label(metadata !2819), !dbg !4110
  tail call void @llvm.dbg.value(metadata ptr %38, metadata !2803, metadata !DIExpression()), !dbg !4106
  %63 = load i64, ptr %38, align 8, !dbg !4111, !tbaa !1534
  tail call void @llvm.dbg.value(metadata i64 %63, metadata !2709, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %38, metadata !2831, metadata !DIExpression()), !dbg !4112
  call void @llvm.dbg.value(metadata i8 1, metadata !2832, metadata !DIExpression()), !dbg !4112
  %64 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 2, !dbg !4114
  store i16 0, ptr %64, align 2, !dbg !4115, !tbaa !2841
  %65 = getelementptr inbounds %struct.lb6_key, ptr %38, i64 0, i32 4, !dbg !4116
  store i8 0, ptr %65, align 1, !dbg !4117, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !4118
  %66 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !4120
  call void @llvm.dbg.value(metadata ptr %66, metadata !2833, metadata !DIExpression()), !dbg !4112
  %67 = icmp eq ptr %66, null, !dbg !4121
  br i1 %67, label %76, label %68, !dbg !4122

68:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata ptr %66, metadata !2856, metadata !DIExpression()), !dbg !4123
  %69 = getelementptr inbounds %struct.lb6_service, ptr %66, i64 0, i32 4, !dbg !4125
  %70 = load i8, ptr %69, align 1, !dbg !4125, !tbaa !2865
  %71 = and i8 %70, 32, !dbg !4126
  %72 = icmp eq i8 %71, 0, !dbg !4127
  br i1 %72, label %351, label %73, !dbg !4128

73:                                               ; preds = %68
  store i8 1, ptr %65, align 1, !dbg !4129, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !4130
  %74 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !4132
  call void @llvm.dbg.value(metadata ptr %74, metadata !2704, metadata !DIExpression()), !dbg !4061
  %75 = icmp eq ptr %74, null, !dbg !4133
  br i1 %75, label %76, label %351, !dbg !4134

76:                                               ; preds = %1, %73
  call void @llvm.dbg.value(metadata ptr null, metadata !2704, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %0, metadata !2877, metadata !DIExpression()), !dbg !4135
  call void @llvm.dbg.value(metadata i1 true, metadata !2880, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4135
  call void @llvm.dbg.value(metadata i1 false, metadata !2881, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4135
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !4137
  call void @llvm.dbg.value(metadata ptr undef, metadata !2757, metadata !DIExpression()), !dbg !4137
  %77 = load i32, ptr %51, align 8, !dbg !4139, !tbaa !1129
  %78 = zext i32 %77 to i64, !dbg !4140
  tail call void @llvm.dbg.value(metadata i64 %78, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !4135
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4141, !srcloc !2764
  %79 = load i32, ptr %53, align 4, !dbg !4142, !tbaa !1129
  %80 = zext i32 %79 to i64, !dbg !4143
  %81 = shl nuw i64 %80, 32, !dbg !4143
  %82 = or disjoint i64 %81, %78, !dbg !4143
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !4135
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4144, !srcloc !2769
  %83 = load i32, ptr %56, align 8, !dbg !4145, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !4135
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4146, !srcloc !2774
  %84 = load i32, ptr %59, align 4, !dbg !4147, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2883, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !4135
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4148, !srcloc !2779
  call void @llvm.dbg.value(metadata ptr undef, metadata !2900, metadata !DIExpression()), !dbg !4149
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4149
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4149
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4149
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4149
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !2907, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !4149
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !4151
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !4151
  %85 = icmp eq i64 %82, 0, !dbg !4153
  %86 = icmp eq i32 %83, -65536
  %87 = select i1 %85, i1 %86, i1 false, !dbg !4154
  br i1 %87, label %88, label %603, !dbg !4154

88:                                               ; preds = %76
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !4135
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2883, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !4135
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !4155
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !4155
  call void @llvm.dbg.value(metadata i64 72, metadata !1504, metadata !DIExpression()), !dbg !4155
  call void @llvm.dbg.value(metadata i64 72, metadata !1507, metadata !DIExpression()), !dbg !4157
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !4157
  call void @llvm.dbg.label(metadata !1520), !dbg !4159
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1521), !dbg !4160
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1522), !dbg !4161
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1523), !dbg !4162
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1524), !dbg !4163
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1525), !dbg !4164
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1526), !dbg !4165
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1527), !dbg !4166
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1528), !dbg !4167
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4135
  %89 = load i32, ptr %45, align 4, !dbg !4168, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %89, metadata !2882, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !4135
  tail call void @llvm.dbg.value(metadata i32 %84, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !4135
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !4043, metadata ptr %22, metadata !DIExpression()), !dbg !4169
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !4169
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %22), !dbg !4171
  %90 = load i32, ptr %41, align 8, !dbg !4172, !tbaa !1251
  store volatile i32 %90, ptr %22, align 4, !dbg !4173, !tbaa !1129, !DIAssignID !4174
  call void @llvm.dbg.assign(metadata i32 %90, metadata !1239, metadata !DIExpression(), metadata !4174, metadata ptr %22, metadata !DIExpression()), !dbg !4169
  %91 = load volatile i32, ptr %22, align 4, !dbg !4175, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %22), !dbg !4176
  %92 = and i32 %91, 65535, !dbg !4177
  tail call void @llvm.dbg.value(metadata i32 %92, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !4135
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !4051, metadata ptr %30, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata ptr undef, metadata !1199, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i1 true, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4178
  call void @llvm.dbg.value(metadata i1 false, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4178
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !4180
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !4180
  %93 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !4182
  call void @llvm.dbg.value(metadata i64 %93, metadata !1234, metadata !DIExpression()), !dbg !4180
  tail call void @llvm.dbg.value(metadata i64 %93, metadata !1203, metadata !DIExpression()), !dbg !4178
  %94 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !4183
  call void @llvm.dbg.value(metadata !DIArgList(i64 %93, i64 %94), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4178
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !4044, metadata ptr %23, metadata !DIExpression()), !dbg !4184
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !4184
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %23), !dbg !4186
  store volatile i32 %92, ptr %23, align 4, !dbg !4187, !tbaa !1129, !DIAssignID !4188
  call void @llvm.dbg.assign(metadata i32 %92, metadata !1239, metadata !DIExpression(), metadata !4188, metadata ptr %23, metadata !DIExpression()), !dbg !4184
  %95 = load volatile i32, ptr %23, align 4, !dbg !4189, !tbaa !1129
  %96 = trunc i32 %95 to i16, !dbg !4190
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %23), !dbg !4191
  call void @llvm.dbg.value(metadata i16 %96, metadata !1211, metadata !DIExpression()), !dbg !4178
  %97 = trunc i32 %89 to i8, !dbg !4192
  call void @llvm.dbg.value(metadata i8 %97, metadata !1212, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i32 %84, metadata !1213, metadata !DIExpression()), !dbg !4178
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %30) #6, !dbg !4193
  store i32 %84, ptr %30, align 4, !dbg !4194, !tbaa !1264, !DIAssignID !4195
  call void @llvm.dbg.assign(metadata i32 %84, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4195, metadata ptr %30, metadata !DIExpression()), !dbg !4178
  %98 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 1, !dbg !4194
  store i16 %96, ptr %98, align 4, !dbg !4194, !tbaa !1268, !DIAssignID !4196
  call void @llvm.dbg.assign(metadata i16 %96, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4196, metadata ptr %98, metadata !DIExpression()), !dbg !4178
  %99 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 2, !dbg !4194
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !4197, metadata ptr %99, metadata !DIExpression()), !dbg !4178
  %100 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 3, !dbg !4194
  store i8 %97, ptr %100, align 4, !dbg !4194, !tbaa !1271, !DIAssignID !4198
  call void @llvm.dbg.assign(metadata i8 %97, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !4198, metadata ptr %100, metadata !DIExpression()), !dbg !4178
  %101 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 4, !dbg !4194
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !4199, metadata ptr %101, metadata !DIExpression()), !dbg !4178
  %102 = getelementptr inbounds %struct.lb4_key, ptr %30, i64 0, i32 5, !dbg !4194
  store i16 0, ptr %102, align 2, !dbg !4194, !DIAssignID !4200
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !4200, metadata ptr %102, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !4201, metadata ptr undef, metadata !DIExpression()), !dbg !4202
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !4204, metadata ptr undef, metadata !DIExpression()), !dbg !4202
  call void @llvm.dbg.value(metadata ptr %30, metadata !1289, metadata !DIExpression()), !dbg !4202
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !4202
  store i16 0, ptr %99, align 2, !dbg !4205, !tbaa !1298
  store i8 0, ptr %101, align 1, !dbg !4206, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !4207
  %103 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !4209
  call void @llvm.dbg.value(metadata ptr %103, metadata !1291, metadata !DIExpression()), !dbg !4202
  %104 = icmp eq ptr %103, null, !dbg !4210
  br i1 %104, label %346, label %105, !dbg !4211

105:                                              ; preds = %88
  call void @llvm.dbg.value(metadata ptr %103, metadata !1312, metadata !DIExpression()), !dbg !4212
  %106 = getelementptr inbounds %struct.lb4_service, ptr %103, i64 0, i32 4, !dbg !4214
  %107 = load i8, ptr %106, align 1, !dbg !4214, !tbaa !1321
  %108 = and i8 %107, 32, !dbg !4215
  %109 = icmp eq i8 %108, 0, !dbg !4216
  br i1 %109, label %113, label %110, !dbg !4217

110:                                              ; preds = %105
  store i8 1, ptr %101, align 1, !dbg !4218, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !4219
  %111 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !4221
  call void @llvm.dbg.value(metadata ptr %111, metadata !1208, metadata !DIExpression()), !dbg !4178
  %112 = icmp eq ptr %111, null, !dbg !4222
  br i1 %112, label %346, label %113, !dbg !4223

113:                                              ; preds = %105, %110
  %114 = phi ptr [ %111, %110 ], [ %103, %105 ]
  call void @llvm.dbg.value(metadata ptr %114, metadata !1208, metadata !DIExpression()), !dbg !4178
  %115 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 1, !dbg !4224
  %116 = load i16, ptr %115, align 4, !dbg !4224, !tbaa !1334
  %117 = icmp eq i16 %116, 0, !dbg !4225
  br i1 %117, label %118, label %135, !dbg !4226

118:                                              ; preds = %113
  %119 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !4227, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %119, metadata !1217, metadata !DIExpression()), !dbg !4228
  %120 = load volatile i8, ptr %119, align 1, !dbg !4229, !tbaa !1341, !range !1343, !noundef !1344
  %121 = icmp eq i8 %120, 0, !dbg !4229
  br i1 %121, label %122, label %346, !dbg !4230

122:                                              ; preds = %118
  call void @llvm.dbg.value(metadata ptr %114, metadata !1346, metadata !DIExpression()), !dbg !4231
  call void @llvm.dbg.value(metadata ptr %114, metadata !1354, metadata !DIExpression()), !dbg !4233
  %123 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 3, !dbg !4235
  %124 = load i8, ptr %123, align 4, !dbg !4235, !tbaa !1361
  %125 = and i8 %124, 35, !dbg !4236
  %126 = icmp eq i8 %125, 0, !dbg !4237
  br i1 %126, label %130, label %127, !dbg !4238

127:                                              ; preds = %122
  call void @llvm.dbg.value(metadata ptr %114, metadata !1365, metadata !DIExpression()), !dbg !4239
  %128 = and i8 %124, 4, !dbg !4241
  %129 = icmp eq i8 %128, 0, !dbg !4242
  br i1 %129, label %348, label %346, !dbg !4243

130:                                              ; preds = %122
  call void @llvm.dbg.value(metadata ptr %114, metadata !1354, metadata !DIExpression()), !dbg !4244
  call void @llvm.dbg.value(metadata ptr %114, metadata !1375, metadata !DIExpression()), !dbg !4246
  %131 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 4, !dbg !4248
  %132 = load i8, ptr %131, align 1, !dbg !4248, !tbaa !1321
  %133 = and i8 %132, 16, !dbg !4249
  %134 = icmp eq i8 %133, 0, !dbg !4250
  br i1 %134, label %348, label %346, !dbg !4251

135:                                              ; preds = %113
  call void @llvm.dbg.value(metadata ptr %114, metadata !1385, metadata !DIExpression()), !dbg !4252
  call void @llvm.dbg.value(metadata ptr %114, metadata !1391, metadata !DIExpression()), !dbg !4254
  %136 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 3, !dbg !4256
  %137 = load i8, ptr %136, align 4, !dbg !4256, !tbaa !1361
  %138 = and i8 %137, 8, !dbg !4257
  %139 = icmp eq i8 %138, 0, !dbg !4258
  br i1 %139, label %140, label %145, !dbg !4259

140:                                              ; preds = %135
  %141 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 4, !dbg !4260
  %142 = load i8, ptr %141, align 1, !dbg !4260, !tbaa !1321
  %143 = and i8 %142, 8, !dbg !4261
  %144 = icmp eq i8 %143, 0, !dbg !4259
  br i1 %144, label %151, label %348, !dbg !4262

145:                                              ; preds = %135
  call void @llvm.dbg.value(metadata ptr %114, metadata !1403, metadata !DIExpression()), !dbg !4263
  call void @llvm.dbg.value(metadata i32 %84, metadata !1408, metadata !DIExpression()), !dbg !4263
  call void @llvm.dbg.value(metadata ptr %114, metadata !1417, metadata !DIExpression()), !dbg !4265
  %146 = and i8 %137, 1, !dbg !4267
  %147 = icmp eq i8 %146, 0, !dbg !4268
  call void @llvm.dbg.value(metadata ptr %114, metadata !1391, metadata !DIExpression()), !dbg !4269
  %148 = and i32 %84, 255
  %149 = icmp eq i32 %148, 127
  %150 = select i1 %147, i1 %149, i1 false, !dbg !4271
  br i1 %150, label %164, label %154, !dbg !4271

151:                                              ; preds = %140
  call void @llvm.dbg.value(metadata ptr %114, metadata !1403, metadata !DIExpression()), !dbg !4263
  call void @llvm.dbg.value(metadata i32 %84, metadata !1408, metadata !DIExpression()), !dbg !4263
  call void @llvm.dbg.value(metadata ptr %114, metadata !1417, metadata !DIExpression()), !dbg !4265
  %152 = and i8 %137, 1, !dbg !4267
  %153 = icmp eq i8 %152, 0, !dbg !4268
  br i1 %153, label %164, label %154, !dbg !4271

154:                                              ; preds = %151, %145
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !4037, metadata ptr %16, metadata !DIExpression()), !dbg !4272
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !4272
  call void @llvm.dbg.value(metadata i32 %84, metadata !1433, metadata !DIExpression()), !dbg !4272
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !4272
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !4272
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %16) #6, !dbg !4274
  %155 = getelementptr inbounds i8, ptr %16, i64 6, !dbg !4275
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %155, i8 0, i64 18, i1 false), !dbg !4275, !DIAssignID !4276
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !4276, metadata ptr %16, metadata !DIExpression()), !dbg !4272
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !4277, metadata ptr undef, metadata !DIExpression()), !dbg !4272
  store i32 64, ptr %16, align 4, !dbg !4278, !tbaa.struct !1443, !DIAssignID !4279
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4279, metadata ptr %16, metadata !DIExpression()), !dbg !4272
  %156 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 3, !dbg !4280
  store i8 1, ptr %156, align 1, !dbg !4281, !tbaa !1448, !DIAssignID !4282
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !4282, metadata ptr %156, metadata !DIExpression()), !dbg !4272
  %157 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 4, !dbg !4283
  store i32 %84, ptr %157, align 4, !dbg !4284, !tbaa !1444, !DIAssignID !4285
  call void @llvm.dbg.assign(metadata i32 %84, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !4285, metadata ptr %157, metadata !DIExpression()), !dbg !4272
  %158 = getelementptr inbounds %struct.ipcache_key, ptr %16, i64 0, i32 1, !dbg !4286
  store i16 0, ptr %158, align 4, !dbg !4287, !tbaa !1457, !DIAssignID !4288
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4288, metadata ptr %158, metadata !DIExpression()), !dbg !4272
  %159 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %16) #6, !dbg !4289
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %16) #6, !dbg !4290
  call void @llvm.dbg.value(metadata ptr %159, metadata !1409, metadata !DIExpression()), !dbg !4291
  %160 = icmp eq ptr %159, null, !dbg !4292
  br i1 %160, label %346, label %161, !dbg !4293

161:                                              ; preds = %154
  %162 = load i32, ptr %159, align 4, !dbg !4294, !tbaa !1466
  %163 = icmp eq i32 %162, 1, !dbg !4295
  br i1 %163, label %164, label %346, !dbg !4296

164:                                              ; preds = %145, %151, %161
  %165 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !4297, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %165, metadata !1222, metadata !DIExpression()), !dbg !4298
  %166 = load volatile i8, ptr %165, align 1, !dbg !4299, !tbaa !1341, !range !1343, !noundef !1344
  %167 = icmp eq i8 %166, 0, !dbg !4299
  br i1 %167, label %179, label %168, !dbg !4300

168:                                              ; preds = %164
  call void @llvm.dbg.value(metadata ptr %114, metadata !1475, metadata !DIExpression()), !dbg !4301
  %169 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 4, !dbg !4303
  %170 = load i8, ptr %169, align 1, !dbg !4303, !tbaa !1321
  %171 = and i8 %170, 1, !dbg !4304
  %172 = icmp eq i8 %171, 0, !dbg !4305
  br i1 %172, label %179, label %173, !dbg !4306

173:                                              ; preds = %168
  %174 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !4307
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !4042, metadata ptr %21, metadata !DIExpression()), !dbg !4308
  call void @llvm.dbg.value(metadata i64 %174, metadata !1490, metadata !DIExpression()), !dbg !4308
  call void @llvm.dbg.value(metadata i32 %84, metadata !1491, metadata !DIExpression()), !dbg !4308
  call void @llvm.dbg.value(metadata i16 %96, metadata !1492, metadata !DIExpression()), !dbg !4308
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %21) #6, !dbg !4310
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !4308
  call void @llvm.dbg.value(metadata ptr %21, metadata !1497, metadata !DIExpression()), !dbg !4311
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !4311
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !4311
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !4313
  call void @llvm.dbg.value(metadata ptr %21, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !4313
  call void @llvm.dbg.label(metadata !1527), !dbg !4315
  %175 = getelementptr inbounds i8, ptr %21, i64 8, !dbg !4316
  call void @llvm.dbg.value(metadata ptr %175, metadata !1512, metadata !DIExpression()), !dbg !4313
  store i64 0, ptr %175, align 8, !dbg !4316, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !4317
  call void @llvm.dbg.value(metadata ptr %21, metadata !1512, metadata !DIExpression()), !dbg !4313
  store i64 %174, ptr %21, align 8, !dbg !4318, !tbaa !1538, !DIAssignID !4319
  call void @llvm.dbg.assign(metadata i64 %174, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4319, metadata ptr %21, metadata !DIExpression()), !dbg !4308
  store i32 %84, ptr %175, align 8, !dbg !4320, !tbaa !1542, !DIAssignID !4321
  call void @llvm.dbg.assign(metadata i32 %84, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !4321, metadata ptr %175, metadata !DIExpression()), !dbg !4308
  %176 = getelementptr inbounds %struct.skip_lb4_key, ptr %21, i64 0, i32 2, !dbg !4322
  store i16 %96, ptr %176, align 4, !dbg !4323, !tbaa !1546, !DIAssignID !4324
  call void @llvm.dbg.assign(metadata i16 %96, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !4324, metadata ptr %176, metadata !DIExpression()), !dbg !4308
  %177 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %21) #6, !dbg !4325
  call void @llvm.dbg.value(metadata ptr %177, metadata !1493, metadata !DIExpression()), !dbg !4308
  %178 = icmp eq ptr %177, null, !dbg !4326
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %21) #6, !dbg !4327
  br i1 %178, label %179, label %346, !dbg !4328

179:                                              ; preds = %173, %168, %164
  call void @llvm.dbg.value(metadata ptr %114, metadata !1553, metadata !DIExpression()), !dbg !4329
  %180 = load i8, ptr %136, align 4, !dbg !4331, !tbaa !1361
  %181 = and i8 %180, 16, !dbg !4332
  %182 = icmp eq i8 %181, 0, !dbg !4333
  br i1 %182, label %238, label %183, !dbg !4334

183:                                              ; preds = %179
  call void @llvm.dbg.value(metadata ptr %114, metadata !1563, metadata !DIExpression()), !dbg !4335
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !4335
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !4035, metadata ptr %14, metadata !DIExpression()), !dbg !4337
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !4036, metadata ptr %15, metadata !DIExpression()), !dbg !4339
  call void @llvm.dbg.value(metadata ptr %114, metadata !1580, metadata !DIExpression()), !dbg !4337
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !4337
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !4337
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %14) #6, !dbg !4340
  store i64 %93, ptr %14, align 8, !dbg !4341, !DIAssignID !4342
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4342, metadata ptr %14, metadata !DIExpression()), !dbg !4337
  %184 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 1, !dbg !4343
  %185 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 2, !dbg !4344
  %186 = load i16, ptr %185, align 2, !dbg !4344, !tbaa !1601
  store i16 %186, ptr %184, align 8, !dbg !4343, !tbaa !1602, !DIAssignID !4345
  call void @llvm.dbg.assign(metadata i16 %186, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !4345, metadata ptr %184, metadata !DIExpression()), !dbg !4337
  %187 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 2, !dbg !4343
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !4346, metadata ptr %187, metadata !DIExpression()), !dbg !4337
  store i8 1, ptr %187, align 2, !dbg !4343, !DIAssignID !4347
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !4347, metadata ptr %187, metadata !DIExpression()), !dbg !4337
  %188 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 3, !dbg !4343
  store i8 0, ptr %188, align 1, !dbg !4343, !tbaa !1607, !DIAssignID !4348
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !4348, metadata ptr %188, metadata !DIExpression()), !dbg !4337
  %189 = getelementptr inbounds %struct.lb4_affinity_key, ptr %14, i64 0, i32 4, !dbg !4343
  store i32 0, ptr %189, align 4, !dbg !4343, !tbaa !1609, !DIAssignID !4349
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !4349, metadata ptr %189, metadata !DIExpression()), !dbg !4337
  %190 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %14) #6, !dbg !4350
  call void @llvm.dbg.value(metadata ptr %190, metadata !1583, metadata !DIExpression()), !dbg !4337
  %191 = icmp eq ptr %190, null, !dbg !4351
  br i1 %191, label %192, label %193, !dbg !4352

192:                                              ; preds = %183
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !4353
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !4178
  br label %238, !dbg !4354

193:                                              ; preds = %183
  %194 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4355, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %194, metadata !1623, metadata !DIExpression()), !dbg !4357
  %195 = load volatile i8, ptr %194, align 1, !dbg !4358, !tbaa !1341, !range !1343, !noundef !1344
  %196 = icmp eq i8 %195, 0, !dbg !4358
  br i1 %196, label %200, label %197, !dbg !4359

197:                                              ; preds = %193
  %198 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !4360
  %199 = lshr i64 %198, 8, !dbg !4361
  br label %203, !dbg !4362

200:                                              ; preds = %193
  %201 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !4363
  %202 = udiv i64 %201, 1000000000, !dbg !4365
  br label %203, !dbg !4366

203:                                              ; preds = %200, %197
  %204 = phi i64 [ %199, %197 ], [ %202, %200 ], !dbg !4367
  call void @llvm.dbg.value(metadata i64 %204, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4339
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %15) #6, !dbg !4368
  %205 = getelementptr inbounds %struct.lb_affinity_val, ptr %190, i64 0, i32 1, !dbg !4369
  %206 = load i32, ptr %205, align 1, !dbg !4369, !tbaa !1640
  store i32 %206, ptr %15, align 4, !dbg !4370, !tbaa !1643, !DIAssignID !4371
  call void @llvm.dbg.assign(metadata i32 %206, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4371, metadata ptr %15, metadata !DIExpression()), !dbg !4339
  %207 = getelementptr inbounds %struct.lb_affinity_match, ptr %15, i64 0, i32 1, !dbg !4370
  %208 = load i16, ptr %185, align 2, !dbg !4372, !tbaa !1601
  store i16 %208, ptr %207, align 4, !dbg !4370, !tbaa !1647, !DIAssignID !4373
  call void @llvm.dbg.assign(metadata i16 %208, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4373, metadata ptr %207, metadata !DIExpression()), !dbg !4339
  %209 = getelementptr inbounds %struct.lb_affinity_match, ptr %15, i64 0, i32 2, !dbg !4370
  store i16 0, ptr %209, align 2, !dbg !4370, !tbaa !1649, !DIAssignID !4374
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !4374, metadata ptr %209, metadata !DIExpression()), !dbg !4339
  %210 = load volatile i64, ptr %190, align 1, !dbg !4375, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %210, metadata !1588, metadata !DIExpression()), !dbg !4376
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4377, !srcloc !1657
  call void @llvm.dbg.value(metadata ptr %114, metadata !1658, metadata !DIExpression()), !dbg !4379
  %211 = load i32, ptr %114, align 4, !dbg !4381, !tbaa !1444
  %212 = and i32 %211, 16777215, !dbg !4382
  call void @llvm.dbg.value(metadata i32 %212, metadata !1667, metadata !DIExpression()), !dbg !4383
  %213 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4385, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %213, metadata !1672, metadata !DIExpression()), !dbg !4386
  %214 = load volatile i8, ptr %213, align 1, !dbg !4387, !tbaa !1341, !range !1343, !noundef !1344
  %215 = icmp eq i8 %214, 0, !dbg !4387
  br i1 %215, label %221, label %216, !dbg !4388

216:                                              ; preds = %203
  %217 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !4389, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %217, metadata !1675, metadata !DIExpression()), !dbg !4390
  %218 = load volatile i32, ptr %217, align 4, !dbg !4391, !tbaa !1129
  %219 = mul i32 %218, %212, !dbg !4392
  %220 = lshr i32 %219, 8, !dbg !4393
  br label %221, !dbg !4394

221:                                              ; preds = %216, %203
  %222 = phi i32 [ %220, %216 ], [ %212, %203 ], !dbg !4383
  %223 = zext nneg i32 %222 to i64, !dbg !4395
  %224 = add i64 %210, %223, !dbg !4396
  %225 = and i64 %204, 4294967295, !dbg !4397
  %226 = icmp ugt i64 %224, %225, !dbg !4398
  br i1 %226, label %227, label %230, !dbg !4399

227:                                              ; preds = %221
  %228 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %15) #6, !dbg !4400
  %229 = icmp eq ptr %228, null, !dbg !4400
  br i1 %229, label %230, label %232, !dbg !4401

230:                                              ; preds = %227, %221
  %231 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %14) #6, !dbg !4339
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #6, !dbg !4402
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !4353
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !4178
  br label %238, !dbg !4354

232:                                              ; preds = %227
  call void @llvm.dbg.value(metadata i64 %225, metadata !1591, metadata !DIExpression()), !dbg !4403
  store volatile i64 %225, ptr %190, align 1, !dbg !4404, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4405, !srcloc !1657
  %233 = load i32, ptr %205, align 1, !dbg !4407, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #6, !dbg !4402
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #6, !dbg !4353
  call void @llvm.dbg.value(metadata i32 %233, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !4178
  %234 = icmp eq i32 %233, 0, !dbg !4408
  br i1 %234, label %238, label %235, !dbg !4354

235:                                              ; preds = %232
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %20)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !4041, metadata ptr %20, metadata !DIExpression()), !dbg !4409
  store i32 %233, ptr %20, align 4, !tbaa !1129, !DIAssignID !4411
  call void @llvm.dbg.assign(metadata i32 %233, metadata !1707, metadata !DIExpression(), metadata !4411, metadata ptr %20, metadata !DIExpression()), !dbg !4409
  %236 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %20) #6, !dbg !4412
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %20), !dbg !4413
  call void @llvm.dbg.value(metadata ptr %236, metadata !1205, metadata !DIExpression()), !dbg !4178
  %237 = icmp eq ptr %236, null, !dbg !4414
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4415, !srcloc !1721
  br i1 %237, label %238, label %280, !dbg !4416

238:                                              ; preds = %235, %232, %179, %192, %230
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !4417
  %239 = load i32, ptr %45, align 4, !dbg !4419, !tbaa !1259
  %240 = and i32 %239, 255, !dbg !4419
  %241 = icmp eq i32 %240, 6, !dbg !4420
  br i1 %241, label %242, label %245, !dbg !4419

242:                                              ; preds = %238
  %243 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !4421
  %244 = zext i32 %243 to i64, !dbg !4421
  br label %247, !dbg !4419

245:                                              ; preds = %238
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !4422
  %246 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !4424
  br label %247, !dbg !4419

247:                                              ; preds = %245, %242
  %248 = phi i64 [ %244, %242 ], [ %246, %245 ], !dbg !4419
  %249 = load i16, ptr %115, align 4, !dbg !4425, !tbaa !1334
  %250 = zext i16 %249 to i64, !dbg !4426
  %251 = urem i64 %248, %250, !dbg !4427
  %252 = trunc i64 %251 to i16, !dbg !4428
  %253 = add nuw i16 %252, 1, !dbg !4428
  store i16 %253, ptr %99, align 2, !dbg !4429, !tbaa !1298, !DIAssignID !4430
  call void @llvm.dbg.assign(metadata i16 %253, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !4430, metadata ptr %99, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata ptr %30, metadata !1749, metadata !DIExpression()), !dbg !4431
  call void @llvm.dbg.value(metadata ptr %30, metadata !1301, metadata !DIExpression()), !dbg !4433
  %254 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %30) #6, !dbg !4435
  call void @llvm.dbg.value(metadata ptr %254, metadata !1214, metadata !DIExpression()), !dbg !4178
  %255 = icmp eq ptr %254, null, !dbg !4436
  br i1 %255, label %256, label %266, !dbg !4437

256:                                              ; preds = %247
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4049, metadata ptr %28, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4050, metadata ptr %29, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !4438
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %28) #6, !dbg !4440
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !4441, metadata ptr %28, metadata !DIExpression()), !dbg !4438
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %29) #6, !dbg !4442
  store i64 21502558725, ptr %29, align 8, !dbg !4443, !DIAssignID !4444
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4444, metadata ptr %29, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4445, metadata ptr %29, metadata !DIExpression()), !dbg !4438
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4446, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !4438
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4447, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !4438
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4448, metadata ptr %29, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !4438
  %257 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %29) #6, !dbg !4449
  call void @llvm.dbg.value(metadata ptr %257, metadata !1770, metadata !DIExpression()), !dbg !4438
  %258 = icmp eq ptr %257, null, !dbg !4450
  br i1 %258, label %262, label %259, !dbg !4451

259:                                              ; preds = %256
  %260 = load i64, ptr %257, align 8, !dbg !4452, !tbaa !1790
  %261 = add i64 %260, 1, !dbg !4452
  store i64 %261, ptr %257, align 8, !dbg !4452, !tbaa !1790
  br label %265, !dbg !4453

262:                                              ; preds = %256
  store i64 1, ptr %28, align 8, !dbg !4454, !tbaa !1790, !DIAssignID !4455
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4455, metadata ptr %28, metadata !DIExpression()), !dbg !4438
  %263 = getelementptr inbounds %struct.metrics_value, ptr %28, i64 0, i32 1, !dbg !4456
  store i64 0, ptr %263, align 8, !dbg !4457, !tbaa !1798, !DIAssignID !4458
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4458, metadata ptr %263, metadata !DIExpression()), !dbg !4438
  %264 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %29, ptr noundef nonnull %28, i32 noundef 0) #6, !dbg !4459
  br label %265

265:                                              ; preds = %262, %259
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %29) #6, !dbg !4460
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %28) #6, !dbg !4460
  br label %346, !dbg !4461

266:                                              ; preds = %247
  %267 = load i32, ptr %254, align 4, !dbg !4462, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %267, metadata !1216, metadata !DIExpression()), !dbg !4178
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %19)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !4040, metadata ptr %19, metadata !DIExpression()), !dbg !4463
  store i32 %267, ptr %19, align 4, !tbaa !1129, !DIAssignID !4465
  call void @llvm.dbg.assign(metadata i32 %267, metadata !1707, metadata !DIExpression(), metadata !4465, metadata ptr %19, metadata !DIExpression()), !dbg !4463
  %268 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %19) #6, !dbg !4466
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %19), !dbg !4467
  call void @llvm.dbg.value(metadata ptr %268, metadata !1205, metadata !DIExpression()), !dbg !4178
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !4178
  %269 = icmp eq ptr %268, null, !dbg !4468
  br i1 %269, label %270, label %280, !dbg !4469

270:                                              ; preds = %266
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4047, metadata ptr %26, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4048, metadata ptr %27, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !4470
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %26) #6, !dbg !4472
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !4473, metadata ptr %26, metadata !DIExpression()), !dbg !4470
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %27) #6, !dbg !4474
  store i64 21503148550, ptr %27, align 8, !dbg !4475, !DIAssignID !4476
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4476, metadata ptr %27, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4477, metadata ptr %27, metadata !DIExpression()), !dbg !4470
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4478, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !4470
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4479, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !4470
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4480, metadata ptr %27, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !4470
  %271 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %27) #6, !dbg !4481
  call void @llvm.dbg.value(metadata ptr %271, metadata !1770, metadata !DIExpression()), !dbg !4470
  %272 = icmp eq ptr %271, null, !dbg !4482
  br i1 %272, label %276, label %273, !dbg !4483

273:                                              ; preds = %270
  %274 = load i64, ptr %271, align 8, !dbg !4484, !tbaa !1790
  %275 = add i64 %274, 1, !dbg !4484
  store i64 %275, ptr %271, align 8, !dbg !4484, !tbaa !1790
  br label %279, !dbg !4485

276:                                              ; preds = %270
  store i64 1, ptr %26, align 8, !dbg !4486, !tbaa !1790, !DIAssignID !4487
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4487, metadata ptr %26, metadata !DIExpression()), !dbg !4470
  %277 = getelementptr inbounds %struct.metrics_value, ptr %26, i64 0, i32 1, !dbg !4488
  store i64 0, ptr %277, align 8, !dbg !4489, !tbaa !1798, !DIAssignID !4490
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4490, metadata ptr %277, metadata !DIExpression()), !dbg !4470
  %278 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %27, ptr noundef nonnull %26, i32 noundef 0) #6, !dbg !4491
  br label %279

279:                                              ; preds = %276, %273
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %27) #6, !dbg !4492
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %26) #6, !dbg !4492
  br label %346, !dbg !4493

280:                                              ; preds = %235, %266
  %281 = phi ptr [ %268, %266 ], [ %236, %235 ]
  %282 = phi i1 [ false, %266 ], [ true, %235 ]
  %283 = phi i32 [ %267, %266 ], [ %233, %235 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4494, !srcloc !1838
  call void @llvm.dbg.value(metadata ptr %114, metadata !1553, metadata !DIExpression()), !dbg !4495
  %284 = load i8, ptr %136, align 4, !dbg !4497, !tbaa !1361
  %285 = and i8 %284, 16, !dbg !4498
  %286 = icmp eq i8 %285, 0, !dbg !4499
  %287 = or i1 %282, %286, !dbg !4500
  br i1 %287, label %310, label %288, !dbg !4500

288:                                              ; preds = %280
  call void @llvm.dbg.value(metadata ptr %114, metadata !1846, metadata !DIExpression()), !dbg !4501
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !4501
  call void @llvm.dbg.value(metadata i32 %283, metadata !1852, metadata !DIExpression()), !dbg !4501
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !4033, metadata ptr %12, metadata !DIExpression()), !dbg !4503
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !4034, metadata ptr %13, metadata !DIExpression()), !dbg !4503
  call void @llvm.dbg.value(metadata ptr %114, metadata !1860, metadata !DIExpression()), !dbg !4503
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !4503
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !4503
  call void @llvm.dbg.value(metadata i32 %283, metadata !1863, metadata !DIExpression()), !dbg !4503
  %289 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4505, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %289, metadata !1623, metadata !DIExpression()), !dbg !4507
  %290 = load volatile i8, ptr %289, align 1, !dbg !4508, !tbaa !1341, !range !1343, !noundef !1344
  %291 = icmp eq i8 %290, 0, !dbg !4508
  br i1 %291, label %295, label %292, !dbg !4509

292:                                              ; preds = %288
  %293 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !4510
  %294 = lshr i64 %293, 8, !dbg !4511
  br label %298, !dbg !4512

295:                                              ; preds = %288
  %296 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !4513
  %297 = udiv i64 %296, 1000000000, !dbg !4515
  br label %298, !dbg !4516

298:                                              ; preds = %295, %292
  %299 = phi i64 [ %294, %292 ], [ %297, %295 ], !dbg !4517
  call void @llvm.dbg.value(metadata i64 %299, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4503
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %12) #6, !dbg !4518
  store i64 %93, ptr %12, align 8, !dbg !4519, !DIAssignID !4520
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4520, metadata ptr %12, metadata !DIExpression()), !dbg !4503
  %300 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 1, !dbg !4521
  %301 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 2, !dbg !4522
  %302 = load i16, ptr %301, align 2, !dbg !4522, !tbaa !1601
  store i16 %302, ptr %300, align 8, !dbg !4521, !tbaa !1602, !DIAssignID !4523
  call void @llvm.dbg.assign(metadata i16 %302, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !4523, metadata ptr %300, metadata !DIExpression()), !dbg !4503
  %303 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 2, !dbg !4521
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !4524, metadata ptr %303, metadata !DIExpression()), !dbg !4503
  store i8 1, ptr %303, align 2, !dbg !4521, !DIAssignID !4525
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !4525, metadata ptr %303, metadata !DIExpression()), !dbg !4503
  %304 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 3, !dbg !4521
  store i8 0, ptr %304, align 1, !dbg !4521, !tbaa !1607, !DIAssignID !4526
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !4526, metadata ptr %304, metadata !DIExpression()), !dbg !4503
  %305 = getelementptr inbounds %struct.lb4_affinity_key, ptr %12, i64 0, i32 4, !dbg !4521
  store i32 0, ptr %305, align 4, !dbg !4521, !tbaa !1609, !DIAssignID !4527
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !4527, metadata ptr %305, metadata !DIExpression()), !dbg !4503
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #6, !dbg !4528
  %306 = and i64 %299, 4294967295, !dbg !4529
  store i64 %306, ptr %13, align 8, !dbg !4530, !tbaa !1894, !DIAssignID !4531
  call void @llvm.dbg.assign(metadata i64 %306, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4531, metadata ptr %13, metadata !DIExpression()), !dbg !4503
  %307 = getelementptr inbounds %struct.lb_affinity_val, ptr %13, i64 0, i32 1, !dbg !4530
  store i32 %283, ptr %307, align 8, !dbg !4530, !tbaa !1640, !DIAssignID !4532
  call void @llvm.dbg.assign(metadata i32 %283, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !4532, metadata ptr %307, metadata !DIExpression()), !dbg !4503
  %308 = getelementptr inbounds %struct.lb_affinity_val, ptr %13, i64 0, i32 2, !dbg !4530
  store i32 0, ptr %308, align 4, !dbg !4530, !tbaa !1897, !DIAssignID !4533
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !4533, metadata ptr %308, metadata !DIExpression()), !dbg !4503
  %309 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %12, ptr noundef nonnull %13, i32 noundef 0) #6, !dbg !4534
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #6, !dbg !4535
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %12) #6, !dbg !4535
  br label %310, !dbg !4536

310:                                              ; preds = %298, %280
  %311 = getelementptr inbounds %struct.lb4_backend, ptr %281, i64 0, i32 1, !dbg !4537
  %312 = getelementptr inbounds %struct.lb4_service, ptr %114, i64 0, i32 2, !dbg !4538
  %313 = load i16, ptr %312, align 2, !dbg !4538, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !4038, metadata ptr %17, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !4039, metadata ptr %18, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata ptr %281, metadata !1911, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata i32 %84, metadata !1912, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata i16 %96, metadata !1913, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata i16 %313, metadata !1914, metadata !DIExpression()), !dbg !4539
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %17) #6, !dbg !4541
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !4542, metadata ptr %17, metadata !DIExpression()), !dbg !4539
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %18) #6, !dbg !4543
  %314 = getelementptr inbounds i8, ptr %18, i64 8, !dbg !4544
  store i64 0, ptr %314, align 8, !dbg !4544, !DIAssignID !4545
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !4545, metadata ptr %18, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4546, metadata ptr undef, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !4539
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !4547
  %315 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !4549
  store i64 %315, ptr %18, align 8, !dbg !4550, !tbaa !1930, !DIAssignID !4551
  call void @llvm.dbg.assign(metadata i64 %315, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4551, metadata ptr %18, metadata !DIExpression()), !dbg !4539
  %316 = load i32, ptr %281, align 4, !dbg !4552, !tbaa !1934
  %317 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %18, i64 0, i32 1, !dbg !4553
  store i32 %316, ptr %317, align 8, !dbg !4554, !tbaa !1938, !DIAssignID !4555
  call void @llvm.dbg.assign(metadata i32 %316, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !4555, metadata ptr %317, metadata !DIExpression()), !dbg !4539
  %318 = load i16, ptr %311, align 4, !dbg !4556, !tbaa !1941
  %319 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %18, i64 0, i32 2, !dbg !4557
  store i16 %318, ptr %319, align 4, !dbg !4558, !tbaa !1944, !DIAssignID !4559
  call void @llvm.dbg.assign(metadata i16 %318, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !4559, metadata ptr %319, metadata !DIExpression()), !dbg !4539
  store i32 %84, ptr %17, align 4, !dbg !4560, !tbaa !1947, !DIAssignID !4561
  call void @llvm.dbg.assign(metadata i32 %84, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4561, metadata ptr %17, metadata !DIExpression()), !dbg !4539
  %320 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %17, i64 0, i32 1, !dbg !4562
  store i16 %96, ptr %320, align 4, !dbg !4563, !tbaa !1952, !DIAssignID !4564
  call void @llvm.dbg.assign(metadata i16 %96, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4564, metadata ptr %320, metadata !DIExpression()), !dbg !4539
  %321 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %17, i64 0, i32 2, !dbg !4565
  store i16 %313, ptr %321, align 2, !dbg !4566, !tbaa !1956, !DIAssignID !4567
  call void @llvm.dbg.assign(metadata i16 %313, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !4567, metadata ptr %321, metadata !DIExpression()), !dbg !4539
  %322 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %18) #6, !dbg !4568
  call void @llvm.dbg.value(metadata ptr %322, metadata !1915, metadata !DIExpression()), !dbg !4539
  %323 = icmp eq ptr %322, null, !dbg !4569
  br i1 %323, label %329, label %324, !dbg !4570

324:                                              ; preds = %310
  call void @llvm.dbg.value(metadata ptr %322, metadata !1962, metadata !DIExpression()), !dbg !4571
  call void @llvm.dbg.value(metadata ptr %17, metadata !1967, metadata !DIExpression()), !dbg !4571
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !4571
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !4573
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !4573
  call void @llvm.dbg.value(metadata ptr %322, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !4573
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !4573
  call void @llvm.dbg.label(metadata !1992), !dbg !4575
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !4573
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !4573
  call void @llvm.dbg.value(metadata ptr %322, metadata !1974, metadata !DIExpression()), !dbg !4573
  %325 = load i64, ptr %322, align 8, !dbg !4576, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %17, metadata !1975, metadata !DIExpression()), !dbg !4573
  %326 = load i64, ptr %17, align 8, !dbg !4576, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %325, i64 %326), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !4573
  %327 = icmp eq i64 %325, %326, !dbg !4577
  br i1 %327, label %328, label %329, !dbg !4578

328:                                              ; preds = %324
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !4539
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #6, !dbg !4579
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #6, !dbg !4579
  br label %342, !dbg !4580

329:                                              ; preds = %310, %324
  %330 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #6, !dbg !4581
  call void @llvm.dbg.value(metadata i32 %330, metadata !1917, metadata !DIExpression()), !dbg !4539
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #6, !dbg !4579
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #6, !dbg !4579
  %331 = icmp slt i32 %330, 0, !dbg !4582
  br i1 %331, label %332, label %342, !dbg !4580

332:                                              ; preds = %329
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4045, metadata ptr %24, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4046, metadata ptr %25, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !4583
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %24) #6, !dbg !4585
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !4586, metadata ptr %24, metadata !DIExpression()), !dbg !4583
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %25) #6, !dbg !4587
  store i64 21504197127, ptr %25, align 8, !dbg !4588, !DIAssignID !4589
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4589, metadata ptr %25, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4590, metadata ptr %25, metadata !DIExpression()), !dbg !4583
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4591, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !4583
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4592, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !4583
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4593, metadata ptr %25, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !4583
  %333 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %25) #6, !dbg !4594
  call void @llvm.dbg.value(metadata ptr %333, metadata !1770, metadata !DIExpression()), !dbg !4583
  %334 = icmp eq ptr %333, null, !dbg !4595
  br i1 %334, label %338, label %335, !dbg !4596

335:                                              ; preds = %332
  %336 = load i64, ptr %333, align 8, !dbg !4597, !tbaa !1790
  %337 = add i64 %336, 1, !dbg !4597
  store i64 %337, ptr %333, align 8, !dbg !4597, !tbaa !1790
  br label %341, !dbg !4598

338:                                              ; preds = %332
  store i64 1, ptr %24, align 8, !dbg !4599, !tbaa !1790, !DIAssignID !4600
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4600, metadata ptr %24, metadata !DIExpression()), !dbg !4583
  %339 = getelementptr inbounds %struct.metrics_value, ptr %24, i64 0, i32 1, !dbg !4601
  store i64 0, ptr %339, align 8, !dbg !4602, !tbaa !1798, !DIAssignID !4603
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4603, metadata ptr %339, metadata !DIExpression()), !dbg !4583
  %340 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %25, ptr noundef nonnull %24, i32 noundef 0) #6, !dbg !4604
  br label %341

341:                                              ; preds = %338, %335
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %25) #6, !dbg !4605
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %24) #6, !dbg !4605
  br label %346, !dbg !4606

342:                                              ; preds = %328, %329
  %343 = load i32, ptr %281, align 4, !dbg !4607, !tbaa !1934
  tail call void @llvm.dbg.value(metadata i32 %343, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !4135
  %344 = load i16, ptr %311, align 4, !dbg !4608, !tbaa !1941
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !4609
  call void @llvm.dbg.value(metadata i16 %344, metadata !2038, metadata !DIExpression()), !dbg !4609
  %345 = zext i16 %344 to i32, !dbg !4611
  tail call void @llvm.dbg.value(metadata i16 %344, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !4135
  br label %348, !dbg !4612

346:                                              ; preds = %341, %279, %265, %118, %173, %110, %161, %154, %88, %130, %127
  %347 = phi i32 [ -1, %154 ], [ -1, %161 ], [ -6, %110 ], [ -6, %173 ], [ -113, %118 ], [ -113, %265 ], [ -113, %279 ], [ -12, %341 ], [ -6, %88 ], [ -113, %130 ], [ -113, %127 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !4135
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4135
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %30) #6, !dbg !4613
  call void @llvm.dbg.value(metadata i32 %347, metadata !2884, metadata !DIExpression()), !dbg !4135
  br label %603, !dbg !4614

348:                                              ; preds = %127, %140, %342, %130
  %349 = phi i32 [ %84, %140 ], [ %343, %342 ], [ %84, %130 ], [ %84, %127 ]
  %350 = phi i32 [ %92, %140 ], [ %345, %342 ], [ %92, %130 ], [ %92, %127 ], !dbg !4135
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2882, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !4135
  tail call void @llvm.dbg.value(metadata i32 %349, metadata !2882, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !4135
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %30) #6, !dbg !4613
  call void @llvm.dbg.value(metadata i32 poison, metadata !2884, metadata !DIExpression()), !dbg !4135
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !4615
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !4615
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !4615
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !4618
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !4618
  call void @llvm.dbg.label(metadata !1527), !dbg !4620
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4135
  call void @llvm.dbg.label(metadata !1528), !dbg !4621
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2883, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4135
  tail call void @llvm.dbg.value(metadata i32 %349, metadata !2883, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !4135
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !4622
  call void @llvm.dbg.value(metadata ptr undef, metadata !3403, metadata !DIExpression()), !dbg !4622
  store i32 0, ptr %51, align 8, !dbg !4624, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4625, !srcloc !3408
  store i32 0, ptr %53, align 4, !dbg !4626, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4627, !srcloc !3411
  store i32 -65536, ptr %56, align 8, !dbg !4628, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4629, !srcloc !3414
  store i32 %349, ptr %59, align 4, !dbg !4630, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4631, !srcloc !3417
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !4632
  call void @llvm.dbg.value(metadata i32 %350, metadata !2038, metadata !DIExpression()), !dbg !4632
  store i32 %350, ptr %41, align 8, !dbg !4634, !tbaa !1251
  br label %603, !dbg !4635

351:                                              ; preds = %68, %73
  %352 = phi ptr [ %74, %73 ], [ %66, %68 ]
  call void @llvm.dbg.value(metadata ptr %352, metadata !2704, metadata !DIExpression()), !dbg !4061
  %353 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 1, !dbg !4636
  %354 = load i16, ptr %353, align 4, !dbg !4636, !tbaa !3423
  %355 = icmp eq i16 %354, 0, !dbg !4637
  br i1 %355, label %356, label %374, !dbg !4638

356:                                              ; preds = %351
  %357 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #6, !dbg !4639, !srcloc !3427
  call void @llvm.dbg.value(metadata ptr %357, metadata !2713, metadata !DIExpression()), !dbg !4640
  %358 = load volatile i8, ptr %357, align 1, !dbg !4641, !tbaa !1341, !range !1343, !noundef !1344
  %359 = icmp eq i8 %358, 0, !dbg !4641
  br i1 %359, label %360, label %603, !dbg !4642

360:                                              ; preds = %356
  call void @llvm.dbg.value(metadata ptr %352, metadata !3431, metadata !DIExpression()), !dbg !4643
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3439, metadata !DIExpression()), !dbg !4645
  %361 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 3, !dbg !4647
  %362 = load i8, ptr %361, align 4, !dbg !4647, !tbaa !3446
  %363 = and i8 %362, 35, !dbg !4648
  %364 = icmp eq i8 %363, 0, !dbg !4649
  br i1 %364, label %368, label %365, !dbg !4650

365:                                              ; preds = %360
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3450, metadata !DIExpression()), !dbg !4651
  %366 = and i8 %362, 4, !dbg !4653
  %367 = icmp eq i8 %366, 0, !dbg !4654
  br i1 %367, label %603, label %373, !dbg !4655

368:                                              ; preds = %360
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3439, metadata !DIExpression()), !dbg !4656
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3460, metadata !DIExpression()), !dbg !4658
  %369 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 4, !dbg !4660
  %370 = load i8, ptr %369, align 1, !dbg !4660, !tbaa !2865
  %371 = and i8 %370, 16, !dbg !4661
  %372 = icmp eq i8 %371, 0, !dbg !4662
  br i1 %372, label %603, label %373, !dbg !4663

373:                                              ; preds = %368, %365
  br label %603, !dbg !4664

374:                                              ; preds = %351
  call void @llvm.dbg.value(metadata ptr %352, metadata !3470, metadata !DIExpression()), !dbg !4665
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3476, metadata !DIExpression()), !dbg !4667
  %375 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 3, !dbg !4669
  %376 = load i8, ptr %375, align 4, !dbg !4669, !tbaa !3446
  %377 = and i8 %376, 8, !dbg !4670
  %378 = icmp eq i8 %377, 0, !dbg !4671
  br i1 %378, label %379, label %384, !dbg !4672

379:                                              ; preds = %374
  %380 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 4, !dbg !4673
  %381 = load i8, ptr %380, align 1, !dbg !4673, !tbaa !2865
  %382 = and i8 %381, 8, !dbg !4674
  %383 = icmp eq i8 %382, 0, !dbg !4672
  br i1 %383, label %391, label %603, !dbg !4675

384:                                              ; preds = %374
  call void @llvm.dbg.value(metadata ptr %352, metadata !3488, metadata !DIExpression()), !dbg !4676
  call void @llvm.dbg.value(metadata ptr undef, metadata !3493, metadata !DIExpression()), !dbg !4676
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3500, metadata !DIExpression()), !dbg !4678
  %385 = and i8 %376, 1, !dbg !4680
  %386 = icmp eq i8 %385, 0, !dbg !4681
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3476, metadata !DIExpression()), !dbg !4682
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !4684
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !4684
  %387 = icmp eq i64 %63, 0
  %388 = select i1 %386, i1 %387, i1 false, !dbg !4687
  %389 = icmp eq i64 %62, 72057594037927936
  %390 = select i1 %388, i1 %389, i1 false, !dbg !4687
  br i1 %390, label %405, label %394, !dbg !4687

391:                                              ; preds = %379
  call void @llvm.dbg.value(metadata ptr %352, metadata !3488, metadata !DIExpression()), !dbg !4676
  call void @llvm.dbg.value(metadata ptr undef, metadata !3493, metadata !DIExpression()), !dbg !4676
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3500, metadata !DIExpression()), !dbg !4678
  %392 = and i8 %376, 1, !dbg !4680
  %393 = icmp eq i8 %392, 0, !dbg !4681
  br i1 %393, label %405, label %394, !dbg !4687

394:                                              ; preds = %391, %384
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3517, metadata !DIExpression(), metadata !4027, metadata ptr %6, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !3522, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.value(metadata ptr undef, metadata !3523, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.value(metadata i32 128, metadata !3524, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.value(metadata i32 0, metadata !3525, metadata !DIExpression()), !dbg !4688
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #6, !dbg !4690
  %395 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !4691
  store i8 0, ptr %395, align 2, !dbg !4691, !DIAssignID !4692
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(), metadata !4692, metadata ptr %6, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !4693, metadata ptr undef, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.assign(metadata i8 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 136), metadata !4694, metadata ptr undef, metadata !DIExpression()), !dbg !4688
  store i32 160, ptr %6, align 4, !dbg !4695, !tbaa !3534, !DIAssignID !4696
  call void @llvm.dbg.assign(metadata i32 160, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4696, metadata ptr %6, metadata !DIExpression()), !dbg !4688
  %396 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !4697
  store i8 2, ptr %396, align 1, !dbg !4698, !tbaa !1448, !DIAssignID !4699
  call void @llvm.dbg.assign(metadata i8 2, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !4699, metadata ptr %396, metadata !DIExpression()), !dbg !4688
  %397 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !4700
  store i64 %63, ptr %397, align 4, !dbg !4701, !tbaa.struct !3541, !DIAssignID !4702
  %398 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, i32 0, i32 0, i32 1, !dbg !4701
  store i64 %62, ptr %398, align 4, !dbg !4701, !tbaa.struct !3543, !DIAssignID !4703
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4702, metadata ptr %397, metadata !DIExpression()), !dbg !4688
  call void @llvm.dbg.assign(metadata i64 %62, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !4703, metadata ptr %398, metadata !DIExpression()), !dbg !4688
  %399 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !4704
  store i16 0, ptr %399, align 4, !dbg !4705, !tbaa !1457, !DIAssignID !4706
  call void @llvm.dbg.assign(metadata i16 0, metadata !3517, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4706, metadata ptr %399, metadata !DIExpression()), !dbg !4688
  %400 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #6, !dbg !4707
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #6, !dbg !4708
  call void @llvm.dbg.value(metadata ptr %400, metadata !3494, metadata !DIExpression()), !dbg !4709
  %401 = icmp eq ptr %400, null, !dbg !4710
  br i1 %401, label %603, label %402, !dbg !4711

402:                                              ; preds = %394
  %403 = load i32, ptr %400, align 4, !dbg !4712, !tbaa !1466
  %404 = icmp eq i32 %403, 1, !dbg !4713
  br i1 %404, label %405, label %603, !dbg !4714

405:                                              ; preds = %384, %391, %402
  %406 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #6, !dbg !4715, !srcloc !3558
  call void @llvm.dbg.value(metadata ptr %406, metadata !2718, metadata !DIExpression()), !dbg !4716
  %407 = load volatile i8, ptr %406, align 1, !dbg !4717, !tbaa !1341, !range !1343, !noundef !1344
  %408 = icmp eq i8 %407, 0, !dbg !4717
  br i1 %408, label %422, label %409, !dbg !4718

409:                                              ; preds = %405
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3562, metadata !DIExpression()), !dbg !4719
  %410 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 4, !dbg !4721
  %411 = load i8, ptr %410, align 1, !dbg !4721, !tbaa !2865
  %412 = and i8 %411, 1, !dbg !4722
  %413 = icmp eq i8 %412, 0, !dbg !4723
  br i1 %413, label %422, label %414, !dbg !4724

414:                                              ; preds = %409
  %415 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !4725
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3572, metadata !DIExpression(), metadata !4032, metadata ptr %11, metadata !DIExpression()), !dbg !4726
  call void @llvm.dbg.value(metadata i64 %63, metadata !3578, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !4726
  call void @llvm.dbg.value(metadata i64 %62, metadata !3578, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !4726
  call void @llvm.dbg.value(metadata i64 %415, metadata !3577, metadata !DIExpression()), !dbg !4726
  call void @llvm.dbg.value(metadata i16 %44, metadata !3579, metadata !DIExpression()), !dbg !4726
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %11) #6, !dbg !4728
  call void @llvm.dbg.value(metadata ptr null, metadata !3580, metadata !DIExpression()), !dbg !4726
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !4729
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !4729
  call void @llvm.dbg.value(metadata i64 32, metadata !1504, metadata !DIExpression()), !dbg !4729
  call void @llvm.dbg.value(metadata i64 32, metadata !1507, metadata !DIExpression()), !dbg !4731
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 32, DW_OP_stack_value)), !dbg !4731
  call void @llvm.dbg.label(metadata !1525), !dbg !4733
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 24, DW_OP_stack_value)), !dbg !4731
  call void @llvm.dbg.label(metadata !1526), !dbg !4734
  %416 = getelementptr inbounds i8, ptr %11, i64 16, !dbg !4735
  call void @llvm.dbg.value(metadata ptr %416, metadata !1512, metadata !DIExpression()), !dbg !4731
  call void @llvm.dbg.label(metadata !1527), !dbg !4736
  %417 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !4737
  call void @llvm.dbg.value(metadata ptr %417, metadata !1512, metadata !DIExpression()), !dbg !4731
  call void @llvm.dbg.label(metadata !1528), !dbg !4738
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !4731
  %418 = getelementptr inbounds i8, ptr %11, i64 24, !dbg !4735
  store i64 0, ptr %418, align 8, !dbg !4735
  store i64 %415, ptr %11, align 8, !dbg !4739, !tbaa !3595, !DIAssignID !4740
  call void @llvm.dbg.assign(metadata i64 %415, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4740, metadata ptr %11, metadata !DIExpression()), !dbg !4726
  store i64 %63, ptr %417, align 8, !dbg !4741, !tbaa.struct !3541, !DIAssignID !4742
  store i64 %62, ptr %416, align 8, !dbg !4741, !tbaa.struct !3543, !DIAssignID !4743
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4742, metadata ptr %417, metadata !DIExpression()), !dbg !4726
  call void @llvm.dbg.assign(metadata i64 %62, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !4743, metadata ptr %416, metadata !DIExpression()), !dbg !4726
  %419 = getelementptr inbounds %struct.skip_lb6_key, ptr %11, i64 0, i32 3, !dbg !4744
  store i16 %44, ptr %419, align 4, !dbg !4745, !tbaa !3603, !DIAssignID !4746
  call void @llvm.dbg.assign(metadata i16 %44, metadata !3572, metadata !DIExpression(DW_OP_LLVM_fragment, 224, 16), metadata !4746, metadata ptr %419, metadata !DIExpression()), !dbg !4726
  %420 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb6, ptr noundef nonnull %11) #6, !dbg !4747
  call void @llvm.dbg.value(metadata ptr %420, metadata !3580, metadata !DIExpression()), !dbg !4726
  %421 = icmp eq ptr %420, null, !dbg !4748
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %11) #6, !dbg !4749
  br i1 %421, label %422, label %603, !dbg !4750

422:                                              ; preds = %414, %409, %405
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3610, metadata !DIExpression()), !dbg !4751
  %423 = load i8, ptr %375, align 4, !dbg !4753, !tbaa !3446
  %424 = and i8 %423, 16, !dbg !4754
  %425 = icmp eq i8 %424, 0, !dbg !4755
  br i1 %425, label %479, label %426, !dbg !4756

426:                                              ; preds = %422
  call void @llvm.dbg.value(metadata ptr %352, metadata !3620, metadata !DIExpression()), !dbg !4757
  call void @llvm.dbg.value(metadata ptr undef, metadata !3626, metadata !DIExpression()), !dbg !4757
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3630, metadata !DIExpression(), metadata !4025, metadata ptr %4, metadata !DIExpression()), !dbg !4759
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3642, metadata !DIExpression(), metadata !4026, metadata ptr %5, metadata !DIExpression()), !dbg !4761
  call void @llvm.dbg.value(metadata ptr %352, metadata !3635, metadata !DIExpression()), !dbg !4759
  call void @llvm.dbg.value(metadata i8 1, metadata !3636, metadata !DIExpression()), !dbg !4759
  call void @llvm.dbg.value(metadata ptr undef, metadata !3637, metadata !DIExpression()), !dbg !4759
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %4) #6, !dbg !4762
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %4, i8 0, i64 24, i1 false), !dbg !4763, !DIAssignID !4764
  call void @llvm.dbg.assign(metadata i8 0, metadata !3630, metadata !DIExpression(), metadata !4764, metadata ptr %4, metadata !DIExpression()), !dbg !4759
  %427 = getelementptr inbounds %struct.lb6_affinity_key, ptr %4, i64 0, i32 1, !dbg !4765
  %428 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 2, !dbg !4766
  %429 = load i16, ptr %428, align 2, !dbg !4766, !tbaa !3656
  store i16 %429, ptr %427, align 8, !dbg !4765, !tbaa !3657, !DIAssignID !4767
  call void @llvm.dbg.assign(metadata i16 %429, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !4767, metadata ptr %427, metadata !DIExpression()), !dbg !4759
  %430 = getelementptr inbounds %struct.lb6_affinity_key, ptr %4, i64 0, i32 2, !dbg !4765
  store i8 1, ptr %430, align 2, !dbg !4765, !DIAssignID !4768
  call void @llvm.dbg.assign(metadata i8 1, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 8), metadata !4768, metadata ptr %430, metadata !DIExpression()), !dbg !4759
  store i64 %39, ptr %4, align 8, !dbg !4769, !tbaa !1444, !DIAssignID !4770
  call void @llvm.dbg.assign(metadata i64 %39, metadata !3630, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4770, metadata ptr %4, metadata !DIExpression()), !dbg !4759
  %431 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %4) #6, !dbg !4771
  call void @llvm.dbg.value(metadata ptr %431, metadata !3638, metadata !DIExpression()), !dbg !4759
  %432 = icmp eq ptr %431, null, !dbg !4772
  br i1 %432, label %433, label %434, !dbg !4773

433:                                              ; preds = %426
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !4774
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !4061
  br label %479, !dbg !4775

434:                                              ; preds = %426
  %435 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4776, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %435, metadata !1623, metadata !DIExpression()), !dbg !4778
  %436 = load volatile i8, ptr %435, align 1, !dbg !4779, !tbaa !1341, !range !1343, !noundef !1344
  %437 = icmp eq i8 %436, 0, !dbg !4779
  br i1 %437, label %441, label %438, !dbg !4780

438:                                              ; preds = %434
  %439 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !4781
  %440 = lshr i64 %439, 8, !dbg !4782
  br label %444, !dbg !4783

441:                                              ; preds = %434
  %442 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !4784
  %443 = udiv i64 %442, 1000000000, !dbg !4786
  br label %444, !dbg !4787

444:                                              ; preds = %441, %438
  %445 = phi i64 [ %440, %438 ], [ %443, %441 ], !dbg !4788
  call void @llvm.dbg.value(metadata i64 %445, metadata !3639, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4761
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #6, !dbg !4789
  %446 = getelementptr inbounds %struct.lb_affinity_val, ptr %431, i64 0, i32 1, !dbg !4790
  %447 = load i32, ptr %446, align 1, !dbg !4790, !tbaa !1640
  store i32 %447, ptr %5, align 4, !dbg !4791, !tbaa !1643, !DIAssignID !4792
  call void @llvm.dbg.assign(metadata i32 %447, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !4792, metadata ptr %5, metadata !DIExpression()), !dbg !4761
  %448 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !4791
  %449 = load i16, ptr %428, align 2, !dbg !4793, !tbaa !3656
  store i16 %449, ptr %448, align 4, !dbg !4791, !tbaa !1647, !DIAssignID !4794
  call void @llvm.dbg.assign(metadata i16 %449, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !4794, metadata ptr %448, metadata !DIExpression()), !dbg !4761
  %450 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !4791
  store i16 0, ptr %450, align 2, !dbg !4791, !tbaa !1649, !DIAssignID !4795
  call void @llvm.dbg.assign(metadata i16 0, metadata !3642, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !4795, metadata ptr %450, metadata !DIExpression()), !dbg !4761
  %451 = load volatile i64, ptr %431, align 1, !dbg !4796, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %451, metadata !3643, metadata !DIExpression()), !dbg !4797
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4798, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3693, metadata !DIExpression()), !dbg !4800
  %452 = load i32, ptr %352, align 4, !dbg !4802, !tbaa !1444
  %453 = and i32 %452, 16777215, !dbg !4803
  call void @llvm.dbg.value(metadata i32 %453, metadata !1667, metadata !DIExpression()), !dbg !4804
  %454 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4806, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %454, metadata !1672, metadata !DIExpression()), !dbg !4807
  %455 = load volatile i8, ptr %454, align 1, !dbg !4808, !tbaa !1341, !range !1343, !noundef !1344
  %456 = icmp eq i8 %455, 0, !dbg !4808
  br i1 %456, label %462, label %457, !dbg !4809

457:                                              ; preds = %444
  %458 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #6, !dbg !4810, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %458, metadata !1675, metadata !DIExpression()), !dbg !4811
  %459 = load volatile i32, ptr %458, align 4, !dbg !4812, !tbaa !1129
  %460 = mul i32 %459, %453, !dbg !4813
  %461 = lshr i32 %460, 8, !dbg !4814
  br label %462, !dbg !4815

462:                                              ; preds = %457, %444
  %463 = phi i32 [ %461, %457 ], [ %453, %444 ], !dbg !4804
  %464 = zext nneg i32 %463 to i64, !dbg !4816
  %465 = add i64 %451, %464, !dbg !4817
  %466 = and i64 %445, 4294967295, !dbg !4818
  %467 = icmp ugt i64 %465, %466, !dbg !4819
  br i1 %467, label %468, label %471, !dbg !4820

468:                                              ; preds = %462
  %469 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #6, !dbg !4821
  %470 = icmp eq ptr %469, null, !dbg !4821
  br i1 %470, label %471, label %473, !dbg !4822

471:                                              ; preds = %468, %462
  %472 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %4) #6, !dbg !4761
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !4823
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !4774
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !4061
  br label %479, !dbg !4775

473:                                              ; preds = %468
  call void @llvm.dbg.value(metadata i64 %466, metadata !3646, metadata !DIExpression()), !dbg !4824
  store volatile i64 %466, ptr %431, align 1, !dbg !4825, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4826, !srcloc !1657
  %474 = load i32, ptr %446, align 1, !dbg !4828, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !4823
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %4) #6, !dbg !4774
  call void @llvm.dbg.value(metadata i32 %474, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 1, metadata !2711, metadata !DIExpression()), !dbg !4061
  %475 = icmp eq i32 %474, 0, !dbg !4829
  br i1 %475, label %479, label %476, !dbg !4775

476:                                              ; preds = %473
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3730, metadata !DIExpression(), metadata !4031, metadata ptr %10, metadata !DIExpression()), !dbg !4830
  store i32 %474, ptr %10, align 4, !tbaa !1129, !DIAssignID !4832
  call void @llvm.dbg.assign(metadata i32 %474, metadata !3730, metadata !DIExpression(), metadata !4832, metadata ptr %10, metadata !DIExpression()), !dbg !4830
  %477 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_backends_v3, ptr noundef nonnull %10) #6, !dbg !4833
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !4834
  call void @llvm.dbg.value(metadata ptr %477, metadata !2701, metadata !DIExpression()), !dbg !4061
  %478 = icmp eq ptr %477, null, !dbg !4835
  call void @llvm.dbg.value(metadata i32 undef, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4836, !srcloc !3744
  br i1 %478, label %479, label %521, !dbg !4837

479:                                              ; preds = %476, %473, %422, %433, %471
  call void @llvm.dbg.value(metadata ptr poison, metadata !2701, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i32 0, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 0, metadata !2711, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !4838
  %480 = load i32, ptr %45, align 4, !dbg !4840, !tbaa !1259
  %481 = and i32 %480, 255, !dbg !4840
  %482 = icmp eq i32 %481, 6, !dbg !4841
  br i1 %482, label %483, label %486, !dbg !4840

483:                                              ; preds = %479
  %484 = call i32 inttoptr (i64 7 to ptr)() #6, !dbg !4842
  %485 = zext i32 %484 to i64, !dbg !4842
  br label %488, !dbg !4840

486:                                              ; preds = %479
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !4843
  %487 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !4845
  br label %488, !dbg !4840

488:                                              ; preds = %483, %486
  %489 = phi i64 [ %485, %483 ], [ %487, %486 ], !dbg !4840
  %490 = load i16, ptr %353, align 4, !dbg !4846, !tbaa !3423
  %491 = zext i16 %490 to i64, !dbg !4847
  %492 = urem i64 %489, %491, !dbg !4848
  %493 = trunc i64 %492 to i16, !dbg !4849
  %494 = add nuw i16 %493, 1, !dbg !4849
  store i16 %494, ptr %64, align 2, !dbg !4850, !tbaa !2841, !DIAssignID !4851
  call void @llvm.dbg.assign(metadata i16 %494, metadata !2691, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 16), metadata !4851, metadata ptr %64, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata ptr %38, metadata !3762, metadata !DIExpression()), !dbg !4852
  call void @llvm.dbg.value(metadata ptr %38, metadata !2845, metadata !DIExpression()), !dbg !4854
  %495 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %38) #6, !dbg !4856
  call void @llvm.dbg.value(metadata ptr %495, metadata !2710, metadata !DIExpression()), !dbg !4061
  %496 = icmp eq ptr %495, null, !dbg !4857
  br i1 %496, label %497, label %507, !dbg !4858

497:                                              ; preds = %488
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4057, metadata ptr %36, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4058, metadata ptr %37, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.value(metadata i16 1123, metadata !1768, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !4859
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %36) #6, !dbg !4861
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !4862, metadata ptr %36, metadata !DIExpression()), !dbg !4859
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %37) #6, !dbg !4863
  store i64 21548433925, ptr %37, align 8, !dbg !4864, !DIAssignID !4865
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4865, metadata ptr %37, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4866, metadata ptr %37, metadata !DIExpression()), !dbg !4859
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4867, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !4859
  call void @llvm.dbg.assign(metadata i16 1123, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4868, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !4859
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4869, metadata ptr %37, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !4859
  %498 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %37) #6, !dbg !4870
  call void @llvm.dbg.value(metadata ptr %498, metadata !1770, metadata !DIExpression()), !dbg !4859
  %499 = icmp eq ptr %498, null, !dbg !4871
  br i1 %499, label %503, label %500, !dbg !4872

500:                                              ; preds = %497
  %501 = load i64, ptr %498, align 8, !dbg !4873, !tbaa !1790
  %502 = add i64 %501, 1, !dbg !4873
  store i64 %502, ptr %498, align 8, !dbg !4873, !tbaa !1790
  br label %506, !dbg !4874

503:                                              ; preds = %497
  store i64 1, ptr %36, align 8, !dbg !4875, !tbaa !1790, !DIAssignID !4876
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4876, metadata ptr %36, metadata !DIExpression()), !dbg !4859
  %504 = getelementptr inbounds %struct.metrics_value, ptr %36, i64 0, i32 1, !dbg !4877
  store i64 0, ptr %504, align 8, !dbg !4878, !tbaa !1798, !DIAssignID !4879
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4879, metadata ptr %504, metadata !DIExpression()), !dbg !4859
  %505 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %37, ptr noundef nonnull %36, i32 noundef 0) #6, !dbg !4880
  br label %506

506:                                              ; preds = %500, %503
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %37) #6, !dbg !4881
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %36) #6, !dbg !4881
  br label %603, !dbg !4882

507:                                              ; preds = %488
  %508 = load i32, ptr %495, align 4, !dbg !4883, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %508, metadata !2712, metadata !DIExpression()), !dbg !4061
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3730, metadata !DIExpression(), metadata !4030, metadata ptr %9, metadata !DIExpression()), !dbg !4884
  store i32 %508, ptr %9, align 4, !tbaa !1129, !DIAssignID !4886
  call void @llvm.dbg.assign(metadata i32 %508, metadata !3730, metadata !DIExpression(), metadata !4886, metadata ptr %9, metadata !DIExpression()), !dbg !4884
  %509 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_backends_v3, ptr noundef nonnull %9) #6, !dbg !4887
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !4888
  call void @llvm.dbg.value(metadata ptr %509, metadata !2701, metadata !DIExpression()), !dbg !4061
  call void @llvm.dbg.value(metadata i8 poison, metadata !2711, metadata !DIExpression()), !dbg !4061
  %510 = icmp eq ptr %509, null, !dbg !4889
  br i1 %510, label %511, label %521, !dbg !4890

511:                                              ; preds = %507
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4055, metadata ptr %34, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4056, metadata ptr %35, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.value(metadata i16 1132, metadata !1768, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !4891
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %34) #6, !dbg !4893
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !4894, metadata ptr %34, metadata !DIExpression()), !dbg !4891
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %35) #6, !dbg !4895
  store i64 21549023750, ptr %35, align 8, !dbg !4896, !DIAssignID !4897
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4897, metadata ptr %35, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4898, metadata ptr %35, metadata !DIExpression()), !dbg !4891
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4899, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !4891
  call void @llvm.dbg.assign(metadata i16 1132, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4900, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !4891
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4901, metadata ptr %35, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !4891
  %512 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %35) #6, !dbg !4902
  call void @llvm.dbg.value(metadata ptr %512, metadata !1770, metadata !DIExpression()), !dbg !4891
  %513 = icmp eq ptr %512, null, !dbg !4903
  br i1 %513, label %517, label %514, !dbg !4904

514:                                              ; preds = %511
  %515 = load i64, ptr %512, align 8, !dbg !4905, !tbaa !1790
  %516 = add i64 %515, 1, !dbg !4905
  store i64 %516, ptr %512, align 8, !dbg !4905, !tbaa !1790
  br label %520, !dbg !4906

517:                                              ; preds = %511
  store i64 1, ptr %34, align 8, !dbg !4907, !tbaa !1790, !DIAssignID !4908
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4908, metadata ptr %34, metadata !DIExpression()), !dbg !4891
  %518 = getelementptr inbounds %struct.metrics_value, ptr %34, i64 0, i32 1, !dbg !4909
  store i64 0, ptr %518, align 8, !dbg !4910, !tbaa !1798, !DIAssignID !4911
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4911, metadata ptr %518, metadata !DIExpression()), !dbg !4891
  %519 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %35, ptr noundef nonnull %34, i32 noundef 0) #6, !dbg !4912
  br label %520

520:                                              ; preds = %514, %517
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %35) #6, !dbg !4913
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %34) #6, !dbg !4913
  br label %603, !dbg !4914

521:                                              ; preds = %476, %507
  %522 = phi ptr [ %509, %507 ], [ %477, %476 ]
  %523 = phi i1 [ false, %507 ], [ true, %476 ]
  %524 = phi i32 [ %508, %507 ], [ %474, %476 ]
  call void asm sideeffect "", "~{memory}"() #6, !dbg !4915, !srcloc !3833
  tail call void @llvm.dbg.value(metadata ptr %352, metadata !3610, metadata !DIExpression()), !dbg !4916
  %525 = load i8, ptr %375, align 4, !dbg !4918, !tbaa !3446
  %526 = and i8 %525, 16, !dbg !4919
  %527 = icmp eq i8 %526, 0, !dbg !4920
  %528 = or i1 %523, %527, !dbg !4921
  br i1 %528, label %550, label %529, !dbg !4921

529:                                              ; preds = %521
  call void @llvm.dbg.value(metadata ptr %352, metadata !3841, metadata !DIExpression()), !dbg !4922
  call void @llvm.dbg.value(metadata ptr undef, metadata !3846, metadata !DIExpression()), !dbg !4922
  call void @llvm.dbg.value(metadata i32 %524, metadata !3847, metadata !DIExpression()), !dbg !4922
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3850, metadata !DIExpression(), metadata !4023, metadata ptr %2, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3860, metadata !DIExpression(), metadata !4024, metadata ptr %3, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.value(metadata ptr %352, metadata !3855, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.value(metadata i8 1, metadata !3856, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.value(metadata ptr undef, metadata !3857, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.value(metadata i32 %524, metadata !3858, metadata !DIExpression()), !dbg !4924
  %530 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #6, !dbg !4926, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %530, metadata !1623, metadata !DIExpression()), !dbg !4928
  %531 = load volatile i8, ptr %530, align 1, !dbg !4929, !tbaa !1341, !range !1343, !noundef !1344
  %532 = icmp eq i8 %531, 0, !dbg !4929
  br i1 %532, label %536, label %533, !dbg !4930

533:                                              ; preds = %529
  %534 = call i64 inttoptr (i64 118 to ptr)() #6, !dbg !4931
  %535 = lshr i64 %534, 8, !dbg !4932
  br label %539, !dbg !4933

536:                                              ; preds = %529
  %537 = call i64 inttoptr (i64 5 to ptr)() #6, !dbg !4934
  %538 = udiv i64 %537, 1000000000, !dbg !4936
  br label %539, !dbg !4937

539:                                              ; preds = %533, %536
  %540 = phi i64 [ %535, %533 ], [ %538, %536 ], !dbg !4938
  call void @llvm.dbg.value(metadata i64 %540, metadata !3859, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !4924
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %2) #6, !dbg !4939
  %541 = getelementptr inbounds i8, ptr %2, i64 8, !dbg !4940
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %541, i8 0, i64 16, i1 false), !dbg !4940, !DIAssignID !4941
  call void @llvm.dbg.assign(metadata i8 0, metadata !3850, metadata !DIExpression(), metadata !4941, metadata ptr %2, metadata !DIExpression()), !dbg !4924
  call void @llvm.dbg.assign(metadata i8 0, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4942, metadata ptr undef, metadata !DIExpression()), !dbg !4924
  %542 = getelementptr inbounds %struct.lb6_affinity_key, ptr %2, i64 0, i32 1, !dbg !4943
  %543 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 2, !dbg !4944
  %544 = load i16, ptr %543, align 2, !dbg !4944, !tbaa !3656
  store i16 %544, ptr %542, align 8, !dbg !4943, !tbaa !3657, !DIAssignID !4945
  call void @llvm.dbg.assign(metadata i16 %544, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !4945, metadata ptr %542, metadata !DIExpression()), !dbg !4924
  %545 = getelementptr inbounds %struct.lb6_affinity_key, ptr %2, i64 0, i32 2, !dbg !4943
  store i8 1, ptr %545, align 2, !dbg !4943, !DIAssignID !4946
  call void @llvm.dbg.assign(metadata i8 1, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 8), metadata !4946, metadata ptr %545, metadata !DIExpression()), !dbg !4924
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !4947
  %546 = and i64 %540, 4294967295, !dbg !4948
  store i64 %546, ptr %3, align 8, !dbg !4949, !tbaa !1894, !DIAssignID !4950
  call void @llvm.dbg.assign(metadata i64 %546, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4950, metadata ptr %3, metadata !DIExpression()), !dbg !4924
  %547 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !4949
  store i32 %524, ptr %547, align 8, !dbg !4949, !tbaa !1640, !DIAssignID !4951
  call void @llvm.dbg.assign(metadata i32 %524, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !4951, metadata ptr %547, metadata !DIExpression()), !dbg !4924
  %548 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !4949
  store i32 0, ptr %548, align 4, !dbg !4949, !tbaa !1897, !DIAssignID !4952
  call void @llvm.dbg.assign(metadata i32 0, metadata !3860, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !4952, metadata ptr %548, metadata !DIExpression()), !dbg !4924
  store i64 %39, ptr %2, align 8, !dbg !4953, !tbaa !1444, !DIAssignID !4954
  call void @llvm.dbg.assign(metadata i64 %39, metadata !3850, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4954, metadata ptr %2, metadata !DIExpression()), !dbg !4924
  %549 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb6_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !4955
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !4956
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %2) #6, !dbg !4956
  br label %550, !dbg !4957

550:                                              ; preds = %539, %521
  %551 = getelementptr inbounds %struct.lb6_backend, ptr %522, i64 0, i32 1, !dbg !4958
  %552 = getelementptr inbounds %struct.lb6_service, ptr %352, i64 0, i32 2, !dbg !4959
  %553 = load i16, ptr %552, align 2, !dbg !4959, !tbaa !3656
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3899, metadata !DIExpression(), metadata !4028, metadata ptr %7, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3910, metadata !DIExpression(), metadata !4029, metadata ptr %8, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata ptr %0, metadata !3904, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata ptr %522, metadata !3905, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata ptr undef, metadata !3906, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata i16 %44, metadata !3907, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata i16 %553, metadata !3908, metadata !DIExpression()), !dbg !4960
  call void @llvm.lifetime.start.p0(i64 20, ptr nonnull %7) #6, !dbg !4962
  call void @llvm.dbg.assign(metadata i8 0, metadata !3899, metadata !DIExpression(), metadata !4963, metadata ptr %7, metadata !DIExpression()), !dbg !4960
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %8) #6, !dbg !4964
  %554 = getelementptr inbounds i8, ptr %8, i64 24, !dbg !4965
  store i64 0, ptr %554, align 8, !dbg !4965, !DIAssignID !4966
  call void @llvm.dbg.assign(metadata i64 0, metadata !3910, metadata !DIExpression(), metadata !4966, metadata ptr %8, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.assign(metadata i8 0, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 192), metadata !4967, metadata ptr undef, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata i32 0, metadata !3911, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !4968
  %555 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !4970
  store i64 %555, ptr %8, align 8, !dbg !4971, !tbaa !3924, !DIAssignID !4972
  call void @llvm.dbg.assign(metadata i64 %555, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4972, metadata ptr %8, metadata !DIExpression()), !dbg !4960
  %556 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !4973
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %556, ptr noundef nonnull align 2 dereferenceable(16) %522, i64 16, i1 false), !dbg !4974, !tbaa.struct !3541, !DIAssignID !4975
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 128), metadata !4975, metadata ptr %556, metadata !DIExpression()), !dbg !4960
  %557 = load i16, ptr %551, align 2, !dbg !4976, !tbaa !3931
  %558 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !4977
  store i16 %557, ptr %558, align 8, !dbg !4978, !tbaa !3935, !DIAssignID !4979
  call void @llvm.dbg.assign(metadata i16 %557, metadata !3910, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 16), metadata !4979, metadata ptr %558, metadata !DIExpression()), !dbg !4960
  store i64 %63, ptr %7, align 8, !dbg !4980, !tbaa.struct !3541, !DIAssignID !4981
  %559 = getelementptr inbounds i8, ptr %7, i64 8, !dbg !4980
  store i64 %62, ptr %559, align 8, !dbg !4980, !tbaa.struct !3543, !DIAssignID !4982
  call void @llvm.dbg.assign(metadata i64 %63, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4981, metadata ptr %7, metadata !DIExpression()), !dbg !4960
  call void @llvm.dbg.assign(metadata i64 %62, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4982, metadata ptr %559, metadata !DIExpression()), !dbg !4960
  %560 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %7, i64 0, i32 1, !dbg !4983
  store i16 %44, ptr %560, align 8, !dbg !4984, !tbaa !3942, !DIAssignID !4985
  call void @llvm.dbg.assign(metadata i16 %44, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !4985, metadata ptr %560, metadata !DIExpression()), !dbg !4960
  %561 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %7, i64 0, i32 2, !dbg !4986
  store i16 %553, ptr %561, align 2, !dbg !4987, !tbaa !3947, !DIAssignID !4988
  call void @llvm.dbg.assign(metadata i16 %553, metadata !3899, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 16), metadata !4988, metadata ptr %561, metadata !DIExpression()), !dbg !4960
  %562 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %8) #6, !dbg !4989
  call void @llvm.dbg.value(metadata ptr %562, metadata !3909, metadata !DIExpression()), !dbg !4960
  %563 = icmp eq ptr %562, null, !dbg !4990
  br i1 %563, label %579, label %564, !dbg !4991

564:                                              ; preds = %550
  call void @llvm.dbg.value(metadata ptr %562, metadata !1962, metadata !DIExpression()), !dbg !4992
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !4992
  call void @llvm.dbg.value(metadata i64 20, metadata !1968, metadata !DIExpression()), !dbg !4992
  call void @llvm.dbg.value(metadata i64 20, metadata !1971, metadata !DIExpression()), !dbg !4994
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !4994
  call void @llvm.dbg.value(metadata ptr %562, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 20, DW_OP_stack_value)), !dbg !4994
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 20, DW_OP_stack_value)), !dbg !4994
  %565 = getelementptr inbounds i8, ptr %562, i64 16, !dbg !4996
  call void @llvm.dbg.value(metadata ptr %565, metadata !1974, metadata !DIExpression()), !dbg !4994
  %566 = load i32, ptr %565, align 4, !dbg !4996, !tbaa !1129
  call void @llvm.dbg.value(metadata ptr %560, metadata !1975, metadata !DIExpression()), !dbg !4994
  %567 = load i32, ptr %560, align 8, !dbg !4996, !tbaa !1129
  %568 = xor i32 %567, %566, !dbg !4996
  %569 = zext i32 %568 to i64, !dbg !4996
  call void @llvm.dbg.value(metadata i64 %569, metadata !1976, metadata !DIExpression()), !dbg !4994
  call void @llvm.dbg.label(metadata !1991), !dbg !4997
  %570 = getelementptr inbounds i8, ptr %562, i64 8, !dbg !4998
  call void @llvm.dbg.value(metadata ptr %570, metadata !1974, metadata !DIExpression()), !dbg !4994
  %571 = load i64, ptr %570, align 8, !dbg !4998, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %559, metadata !1975, metadata !DIExpression()), !dbg !4994
  %572 = xor i64 %62, %571, !dbg !4998
  %573 = or i64 %572, %569, !dbg !4998
  call void @llvm.dbg.value(metadata i64 %573, metadata !1976, metadata !DIExpression()), !dbg !4994
  call void @llvm.dbg.label(metadata !1992), !dbg !4999
  call void @llvm.dbg.value(metadata ptr %559, metadata !1975, metadata !DIExpression(DW_OP_constu, 8, DW_OP_minus, DW_OP_stack_value)), !dbg !4994
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !4994
  call void @llvm.dbg.value(metadata ptr %562, metadata !1974, metadata !DIExpression()), !dbg !4994
  %574 = load i64, ptr %562, align 8, !dbg !5000, !tbaa !1534
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !4994
  call void @llvm.dbg.value(metadata !DIArgList(i64 %573, i64 %574, i64 %63), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !4994
  %575 = xor i64 %63, %574, !dbg !5000
  call void @llvm.dbg.value(metadata !DIArgList(i64 %573, i64 %575), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !4994
  %576 = or i64 %573, %575, !dbg !5000
  call void @llvm.dbg.value(metadata i64 %576, metadata !1976, metadata !DIExpression()), !dbg !4994
  %577 = icmp eq i64 %576, 0, !dbg !5001
  br i1 %577, label %578, label %579, !dbg !5002

578:                                              ; preds = %564
  call void @llvm.dbg.value(metadata i32 0, metadata !3911, metadata !DIExpression()), !dbg !4960
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %8) #6, !dbg !5003
  call void @llvm.lifetime.end.p0(i64 20, ptr nonnull %7) #6, !dbg !5003
  br label %593, !dbg !5004

579:                                              ; preds = %550, %564
  %580 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #6, !dbg !5005
  call void @llvm.dbg.value(metadata i32 %580, metadata !3911, metadata !DIExpression()), !dbg !4960
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %8) #6, !dbg !5003
  call void @llvm.lifetime.end.p0(i64 20, ptr nonnull %7) #6, !dbg !5003
  %581 = icmp slt i32 %580, 0, !dbg !5006
  br i1 %581, label %582, label %593, !dbg !5004

582:                                              ; preds = %579
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !4053, metadata ptr %32, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !4054, metadata ptr %33, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.value(metadata i16 1148, metadata !1768, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5007
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %32) #6, !dbg !5009
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5010, metadata ptr %32, metadata !DIExpression()), !dbg !5007
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %33) #6, !dbg !5011
  store i64 21550072327, ptr %33, align 8, !dbg !5012, !DIAssignID !5013
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5013, metadata ptr %33, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5014, metadata ptr %33, metadata !DIExpression()), !dbg !5007
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5015, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5007
  call void @llvm.dbg.assign(metadata i16 1148, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5016, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5007
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5017, metadata ptr %33, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5007
  %583 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %33) #6, !dbg !5018
  call void @llvm.dbg.value(metadata ptr %583, metadata !1770, metadata !DIExpression()), !dbg !5007
  %584 = icmp eq ptr %583, null, !dbg !5019
  br i1 %584, label %588, label %585, !dbg !5020

585:                                              ; preds = %582
  %586 = load i64, ptr %583, align 8, !dbg !5021, !tbaa !1790
  %587 = add i64 %586, 1, !dbg !5021
  store i64 %587, ptr %583, align 8, !dbg !5021, !tbaa !1790
  br label %591, !dbg !5022

588:                                              ; preds = %582
  store i64 1, ptr %32, align 8, !dbg !5023, !tbaa !1790, !DIAssignID !5024
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5024, metadata ptr %32, metadata !DIExpression()), !dbg !5007
  %589 = getelementptr inbounds %struct.metrics_value, ptr %32, i64 0, i32 1, !dbg !5025
  store i64 0, ptr %589, align 8, !dbg !5026, !tbaa !1798, !DIAssignID !5027
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5027, metadata ptr %589, metadata !DIExpression()), !dbg !5007
  %590 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %33, ptr noundef nonnull %32, i32 noundef 0) #6, !dbg !5028
  br label %591

591:                                              ; preds = %588, %585
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %33) #6, !dbg !5029
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %32) #6, !dbg !5029
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %38) #6, !dbg !5030
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !4022, metadata !DIExpression()), !dbg !4060
  %592 = call i1 @llvm.bpf.passthrough.i1.i1(i32 3, i1 false)
  br label %609, !dbg !5031

593:                                              ; preds = %578, %579
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !5033
  call void @llvm.dbg.value(metadata ptr %522, metadata !3403, metadata !DIExpression()), !dbg !5033
  %594 = load i32, ptr %522, align 1, !dbg !5035, !tbaa !1444
  store i32 %594, ptr %51, align 8, !dbg !5036, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5037, !srcloc !3408
  %595 = getelementptr inbounds %struct.anon, ptr %522, i64 0, i32 1, !dbg !5038
  %596 = load i32, ptr %595, align 1, !dbg !5038, !tbaa !1444
  store i32 %596, ptr %53, align 4, !dbg !5039, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5040, !srcloc !3411
  %597 = getelementptr inbounds %struct.anon, ptr %522, i64 0, i32 2, !dbg !5041
  %598 = load i32, ptr %597, align 1, !dbg !5041, !tbaa !1444
  store i32 %598, ptr %56, align 8, !dbg !5042, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5043, !srcloc !3414
  %599 = getelementptr inbounds %struct.anon, ptr %522, i64 0, i32 3, !dbg !5044
  %600 = load i32, ptr %599, align 1, !dbg !5044, !tbaa !1444
  store i32 %600, ptr %59, align 4, !dbg !5045, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5046, !srcloc !3417
  %601 = load i16, ptr %551, align 2, !dbg !5047, !tbaa !3931
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !5048
  tail call void @llvm.dbg.value(metadata i16 %601, metadata !2038, metadata !DIExpression()), !dbg !5048
  %602 = zext i16 %601 to i32, !dbg !5050
  store i32 %602, ptr %41, align 8, !dbg !5051, !tbaa !1251
  br label %603, !dbg !5052

603:                                              ; preds = %365, %76, %394, %402, %373, %368, %348, %346, %356, %379, %414, %506, %520, %593
  %604 = phi i32 [ 0, %593 ], [ -113, %520 ], [ -113, %506 ], [ -113, %356 ], [ 1, %379 ], [ -6, %414 ], [ 0, %348 ], [ %347, %346 ], [ -113, %373 ], [ 0, %368 ], [ -1, %402 ], [ -1, %394 ], [ -6, %76 ], [ 0, %365 ], !dbg !4061
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %38) #6, !dbg !5030
  tail call void @llvm.dbg.value(metadata i32 %604, metadata !4022, metadata !DIExpression()), !dbg !4060
  %605 = icmp eq i32 %604, -113, !dbg !5053
  %606 = icmp eq i32 %604, -12
  %607 = call i1 @llvm.bpf.passthrough.i1.i1(i32 3, i1 %605)
  %608 = or i1 %606, %607, !dbg !5031
  br i1 %608, label %609, label %610, !dbg !5031

609:                                              ; preds = %591, %603
  br label %610, !dbg !5054

610:                                              ; preds = %603, %609
  %611 = phi i32 [ 0, %609 ], [ 1, %603 ], !dbg !4060
  ret i32 %611, !dbg !5056
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock6_recvmsg(ptr noundef %0) #0 section "cgroup/recvmsg6" !dbg !5057 {
  %2 = alloca i32, align 4, !DIAssignID !5060
  %3 = alloca i32, align 4, !DIAssignID !5061
  %4 = alloca %struct.metrics_value, align 8, !DIAssignID !5062
  %5 = alloca %struct.metrics_key, align 8, !DIAssignID !5063
  %6 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !5064
  %7 = alloca %struct.lb4_key, align 4, !DIAssignID !5065
  %8 = alloca i32, align 4, !DIAssignID !5066
  %9 = alloca %struct.metrics_value, align 8, !DIAssignID !5067
  %10 = alloca %struct.metrics_key, align 8, !DIAssignID !5068
  %11 = alloca %struct.ipv6_revnat_tuple, align 8, !DIAssignID !5069
  %12 = alloca %struct.lb6_key, align 2, !DIAssignID !5070
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !5059, metadata !DIExpression()), !dbg !5071
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5072, metadata !DIExpression(), metadata !5069, metadata ptr %11, metadata !DIExpression()), !dbg !5083
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5082, metadata !DIExpression(), metadata !5070, metadata ptr %12, metadata !DIExpression()), !dbg !5085
  call void @llvm.dbg.value(metadata ptr %0, metadata !5075, metadata !DIExpression()), !dbg !5083
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %11) #6, !dbg !5086
  %13 = getelementptr inbounds i8, ptr %11, i64 24, !dbg !5087
  store i64 0, ptr %13, align 8, !dbg !5087, !DIAssignID !5088
  call void @llvm.dbg.assign(metadata i64 0, metadata !5072, metadata !DIExpression(), metadata !5088, metadata ptr %11, metadata !DIExpression()), !dbg !5083
  call void @llvm.dbg.assign(metadata i8 0, metadata !5072, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 192), metadata !5089, metadata ptr undef, metadata !DIExpression()), !dbg !5083
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !5066, metadata ptr %8, metadata !DIExpression()), !dbg !5090
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !5090
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8), !dbg !5092
  %14 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !5093
  %15 = load i32, ptr %14, align 8, !dbg !5093, !tbaa !1251
  store volatile i32 %15, ptr %8, align 4, !dbg !5094, !tbaa !1129, !DIAssignID !5095
  call void @llvm.dbg.assign(metadata i32 %15, metadata !1239, metadata !DIExpression(), metadata !5095, metadata ptr %8, metadata !DIExpression()), !dbg !5090
  %16 = load volatile i32, ptr %8, align 4, !dbg !5096, !tbaa !1129
  %17 = trunc i32 %16 to i16, !dbg !5097
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8), !dbg !5098
  call void @llvm.dbg.value(metadata i16 %17, metadata !5077, metadata !DIExpression()), !dbg !5083
  %18 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !5099
  %19 = load i32, ptr %18, align 4, !dbg !5099, !tbaa !1259
  call void @llvm.dbg.value(metadata i32 %19, metadata !5078, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !5083
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !5100
  %20 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef %0) #6, !dbg !5102
  store i64 %20, ptr %11, align 8, !dbg !5103, !tbaa !3924, !DIAssignID !5104
  call void @llvm.dbg.assign(metadata i64 %20, metadata !5072, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5104, metadata ptr %11, metadata !DIExpression()), !dbg !5083
  %21 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %11, i64 0, i32 2, !dbg !5105
  store i16 %17, ptr %21, align 8, !dbg !5106, !tbaa !3935, !DIAssignID !5107
  call void @llvm.dbg.assign(metadata i16 %17, metadata !5072, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 16), metadata !5107, metadata ptr %21, metadata !DIExpression()), !dbg !5083
  %22 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %11, i64 0, i32 1, !dbg !5108
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !5109
  call void @llvm.dbg.value(metadata ptr %22, metadata !2757, metadata !DIExpression()), !dbg !5109
  %23 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !5111
  %24 = load i32, ptr %23, align 8, !dbg !5112, !tbaa !1129
  store i32 %24, ptr %22, align 8, !dbg !5113, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !5114, !srcloc !2764
  %25 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !5115
  %26 = load i32, ptr %25, align 4, !dbg !5115, !tbaa !1129
  %27 = getelementptr inbounds i8, ptr %11, i64 12, !dbg !5116
  store i32 %26, ptr %27, align 4, !dbg !5117, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !5118, !srcloc !2769
  %28 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !5119
  %29 = load i32, ptr %28, align 8, !dbg !5119, !tbaa !1129
  %30 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %11, i64 0, i32 1, i32 0, i32 1, !dbg !5120
  store i32 %29, ptr %30, align 8, !dbg !5121, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !5122, !srcloc !2774
  %31 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !5123
  %32 = load i32, ptr %31, align 4, !dbg !5123, !tbaa !1129
  %33 = getelementptr inbounds i8, ptr %11, i64 20, !dbg !5124
  store i32 %32, ptr %33, align 4, !dbg !5125, !tbaa !1444
  tail call void asm sideeffect "", "~{memory}"() #6, !dbg !5126, !srcloc !2779
  %34 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %11) #6, !dbg !5127
  call void @llvm.dbg.value(metadata ptr %34, metadata !5076, metadata !DIExpression()), !dbg !5083
  %35 = icmp eq ptr %34, null, !dbg !5128
  br i1 %35, label %91, label %36, !dbg !5129

36:                                               ; preds = %1
  %37 = trunc i32 %19 to i8, !dbg !5099
  call void @llvm.dbg.value(metadata i8 %37, metadata !5078, metadata !DIExpression()), !dbg !5083
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %12) #6, !dbg !5130
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(16) %12, ptr noundef nonnull align 2 dereferenceable(16) %34, i64 16, i1 false), !dbg !5131, !tbaa.struct !3541, !DIAssignID !5132
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 128), metadata !5132, metadata ptr %12, metadata !DIExpression()), !dbg !5085
  %38 = getelementptr inbounds %struct.lb6_key, ptr %12, i64 0, i32 1, !dbg !5133
  %39 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %34, i64 0, i32 1, !dbg !5134
  %40 = load i16, ptr %39, align 2, !dbg !5134, !tbaa !3942
  store i16 %40, ptr %38, align 2, !dbg !5133, !tbaa !2742, !DIAssignID !5135
  call void @llvm.dbg.assign(metadata i16 %40, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 16), metadata !5135, metadata ptr %38, metadata !DIExpression()), !dbg !5085
  %41 = getelementptr inbounds %struct.lb6_key, ptr %12, i64 0, i32 2, !dbg !5133
  call void @llvm.dbg.assign(metadata i16 0, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 144, 16), metadata !5136, metadata ptr %41, metadata !DIExpression()), !dbg !5085
  %42 = getelementptr inbounds %struct.lb6_key, ptr %12, i64 0, i32 3, !dbg !5133
  store i8 %37, ptr %42, align 2, !dbg !5133, !tbaa !2745, !DIAssignID !5137
  call void @llvm.dbg.assign(metadata i8 %37, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 8), metadata !5137, metadata ptr %42, metadata !DIExpression()), !dbg !5085
  %43 = getelementptr inbounds %struct.lb6_key, ptr %12, i64 0, i32 4, !dbg !5133
  call void @llvm.dbg.assign(metadata i8 0, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 168, 8), metadata !5138, metadata ptr %43, metadata !DIExpression()), !dbg !5085
  %44 = getelementptr inbounds %struct.lb6_key, ptr %12, i64 0, i32 5, !dbg !5133
  store i16 0, ptr %44, align 2, !dbg !5133, !DIAssignID !5139
  call void @llvm.dbg.assign(metadata i16 0, metadata !5082, metadata !DIExpression(DW_OP_LLVM_fragment, 176, 16), metadata !5139, metadata ptr %44, metadata !DIExpression()), !dbg !5085
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2826, metadata !DIExpression(), metadata !5140, metadata ptr undef, metadata !DIExpression()), !dbg !5141
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2834, metadata !DIExpression(), metadata !5143, metadata ptr undef, metadata !DIExpression()), !dbg !5141
  call void @llvm.dbg.value(metadata ptr %12, metadata !2831, metadata !DIExpression()), !dbg !5141
  call void @llvm.dbg.value(metadata i8 1, metadata !2832, metadata !DIExpression()), !dbg !5141
  store i16 0, ptr %41, align 2, !dbg !5144, !tbaa !2841
  store i8 0, ptr %43, align 1, !dbg !5145, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %12, metadata !2845, metadata !DIExpression()), !dbg !5146
  %45 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %12) #6, !dbg !5148
  call void @llvm.dbg.value(metadata ptr %45, metadata !2833, metadata !DIExpression()), !dbg !5141
  %46 = icmp eq ptr %45, null, !dbg !5149
  br i1 %46, label %55, label %47, !dbg !5150

47:                                               ; preds = %36
  tail call void @llvm.dbg.value(metadata ptr %45, metadata !2856, metadata !DIExpression()), !dbg !5151
  %48 = getelementptr inbounds %struct.lb6_service, ptr %45, i64 0, i32 4, !dbg !5153
  %49 = load i8, ptr %48, align 1, !dbg !5153, !tbaa !2865
  %50 = and i8 %49, 32, !dbg !5154
  %51 = icmp eq i8 %50, 0, !dbg !5155
  br i1 %51, label %58, label %52, !dbg !5156

52:                                               ; preds = %47
  store i8 1, ptr %43, align 1, !dbg !5157, !tbaa !2844
  call void @llvm.dbg.value(metadata ptr %12, metadata !2845, metadata !DIExpression()), !dbg !5158
  %53 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb6_services_v2, ptr noundef nonnull %12) #6, !dbg !5160
  call void @llvm.dbg.value(metadata ptr %53, metadata !5079, metadata !DIExpression()), !dbg !5085
  %54 = icmp eq ptr %53, null, !dbg !5161
  br i1 %54, label %55, label %58, !dbg !5163

55:                                               ; preds = %36, %52
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !5164
  call void @llvm.dbg.value(metadata ptr null, metadata !1233, metadata !DIExpression()), !dbg !5164
  %56 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !5167
  call void @llvm.dbg.value(metadata i64 %56, metadata !1234, metadata !DIExpression()), !dbg !5164
  %57 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !5168
  br label %69, !dbg !5169

58:                                               ; preds = %47, %52
  %59 = phi ptr [ %53, %52 ], [ %45, %47 ]
  call void @llvm.dbg.value(metadata ptr %59, metadata !5079, metadata !DIExpression()), !dbg !5085
  %60 = getelementptr inbounds %struct.lb6_service, ptr %59, i64 0, i32 2, !dbg !5170
  %61 = load i16, ptr %60, align 2, !dbg !5170, !tbaa !3656
  %62 = getelementptr inbounds %struct.ipv6_revnat_entry, ptr %34, i64 0, i32 2, !dbg !5172
  %63 = load i16, ptr %62, align 2, !dbg !5172, !tbaa !3947
  %64 = icmp eq i16 %61, %63, !dbg !5173
  br i1 %64, label %65, label %69, !dbg !5174

65:                                               ; preds = %58
  %66 = getelementptr inbounds %struct.lb6_service, ptr %59, i64 0, i32 1, !dbg !5175
  %67 = load i16, ptr %66, align 4, !dbg !5175, !tbaa !3423
  %68 = icmp eq i16 %67, 0, !dbg !5176
  br i1 %68, label %69, label %80, !dbg !5177

69:                                               ; preds = %55, %65, %58
  %70 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %11) #6, !dbg !5178
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !5067, metadata ptr %9, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !5068, metadata ptr %10, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.value(metadata i8 1, metadata !1766, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.value(metadata i8 8, metadata !1767, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.value(metadata i16 1242, metadata !1768, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5180
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %9) #6, !dbg !5182
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5183, metadata ptr %9, metadata !DIExpression()), !dbg !5180
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %10) #6, !dbg !5184
  store i64 21556232456, ptr %10, align 8, !dbg !5185, !DIAssignID !5186
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5186, metadata ptr %10, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.assign(metadata i8 8, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5187, metadata ptr %10, metadata !DIExpression()), !dbg !5180
  call void @llvm.dbg.assign(metadata i8 1, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5188, metadata ptr %10, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5180
  call void @llvm.dbg.assign(metadata i16 1242, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5189, metadata ptr %10, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5180
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5190, metadata ptr %10, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5180
  %71 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %10) #6, !dbg !5191
  call void @llvm.dbg.value(metadata ptr %71, metadata !1770, metadata !DIExpression()), !dbg !5180
  %72 = icmp eq ptr %71, null, !dbg !5192
  br i1 %72, label %76, label %73, !dbg !5193

73:                                               ; preds = %69
  %74 = load i64, ptr %71, align 8, !dbg !5194, !tbaa !1790
  %75 = add i64 %74, 1, !dbg !5194
  store i64 %75, ptr %71, align 8, !dbg !5194, !tbaa !1790
  br label %79, !dbg !5195

76:                                               ; preds = %69
  store i64 1, ptr %9, align 8, !dbg !5196, !tbaa !1790, !DIAssignID !5197
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5197, metadata ptr %9, metadata !DIExpression()), !dbg !5180
  %77 = getelementptr inbounds %struct.metrics_value, ptr %9, i64 0, i32 1, !dbg !5198
  store i64 0, ptr %77, align 8, !dbg !5199, !tbaa !1798, !DIAssignID !5200
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5200, metadata ptr %77, metadata !DIExpression()), !dbg !5180
  %78 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %10, ptr noundef nonnull %9, i32 noundef 0) #6, !dbg !5201
  br label %79

79:                                               ; preds = %73, %76
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %10) #6, !dbg !5202
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %9) #6, !dbg !5202
  br label %90, !dbg !5203

80:                                               ; preds = %65
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !5204
  call void @llvm.dbg.value(metadata ptr %34, metadata !3403, metadata !DIExpression()), !dbg !5204
  %81 = load i32, ptr %34, align 1, !dbg !5206, !tbaa !1444
  store i32 %81, ptr %23, align 8, !dbg !5207, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5208, !srcloc !3408
  %82 = getelementptr inbounds %struct.anon, ptr %34, i64 0, i32 1, !dbg !5209
  %83 = load i32, ptr %82, align 1, !dbg !5209, !tbaa !1444
  store i32 %83, ptr %25, align 4, !dbg !5210, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5211, !srcloc !3411
  %84 = getelementptr inbounds %struct.anon, ptr %34, i64 0, i32 2, !dbg !5212
  %85 = load i32, ptr %84, align 1, !dbg !5212, !tbaa !1444
  store i32 %85, ptr %28, align 8, !dbg !5213, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5214, !srcloc !3414
  %86 = getelementptr inbounds %struct.anon, ptr %34, i64 0, i32 3, !dbg !5215
  %87 = load i32, ptr %86, align 1, !dbg !5215, !tbaa !1444
  store i32 %87, ptr %31, align 4, !dbg !5216, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5217, !srcloc !3417
  %88 = load i16, ptr %39, align 2, !dbg !5218, !tbaa !3942
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !5219
  tail call void @llvm.dbg.value(metadata i16 %88, metadata !2038, metadata !DIExpression()), !dbg !5219
  %89 = zext i16 %88 to i32, !dbg !5221
  store i32 %89, ptr %14, align 8, !dbg !5222, !tbaa !1251
  br label %90, !dbg !5223

90:                                               ; preds = %80, %79
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %12) #6, !dbg !5224
  br label %166

91:                                               ; preds = %1
  call void @llvm.dbg.value(metadata ptr %0, metadata !5225, metadata !DIExpression()), !dbg !5231
  call void @llvm.dbg.value(metadata ptr %0, metadata !2751, metadata !DIExpression()), !dbg !5233
  call void @llvm.dbg.value(metadata ptr undef, metadata !2757, metadata !DIExpression()), !dbg !5233
  %92 = load i32, ptr %23, align 8, !dbg !5235, !tbaa !1129
  %93 = zext i32 %92 to i64, !dbg !5236
  tail call void @llvm.dbg.value(metadata i64 %93, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !5231
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5237, !srcloc !2764
  %94 = load i32, ptr %25, align 4, !dbg !5238, !tbaa !1129
  %95 = zext i32 %94 to i64, !dbg !5239
  %96 = shl nuw i64 %95, 32, !dbg !5239
  %97 = or disjoint i64 %96, %93, !dbg !5239
  tail call void @llvm.dbg.value(metadata i64 %97, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !5231
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5240, !srcloc !2769
  %98 = load i32, ptr %28, align 8, !dbg !5241, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %98, metadata !5229, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !5231
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5242, !srcloc !2774
  %99 = load i32, ptr %31, align 4, !dbg !5243, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !5229, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !5231
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5244, !srcloc !2779
  call void @llvm.dbg.value(metadata ptr undef, metadata !2900, metadata !DIExpression()), !dbg !5245
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5245
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5245
  tail call void @llvm.dbg.value(metadata i64 %97, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5245
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5245
  tail call void @llvm.dbg.value(metadata i32 %98, metadata !2907, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !5245
  call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !5248
  call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !5248
  %100 = icmp eq i64 %97, 0, !dbg !5250
  %101 = icmp eq i32 %98, -65536
  %102 = select i1 %100, i1 %101, i1 false, !dbg !5251
  br i1 %102, label %103, label %166, !dbg !5251

103:                                              ; preds = %91
  tail call void @llvm.dbg.value(metadata i32 %98, metadata !5229, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !5231
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !5229, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  %104 = load i32, ptr %18, align 4, !dbg !5252, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %104, metadata !5228, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5228, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !5231
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !5060, metadata ptr %2, metadata !DIExpression()), !dbg !5253
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !5253
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2), !dbg !5255
  %105 = load i32, ptr %14, align 8, !dbg !5256, !tbaa !1251
  store volatile i32 %105, ptr %2, align 4, !dbg !5257, !tbaa !1129, !DIAssignID !5258
  call void @llvm.dbg.assign(metadata i32 %105, metadata !1239, metadata !DIExpression(), metadata !5258, metadata ptr %2, metadata !DIExpression()), !dbg !5253
  %106 = load volatile i32, ptr %2, align 4, !dbg !5259, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2), !dbg !5260
  %107 = and i32 %106, 65535, !dbg !5261
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !5231
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2522, metadata !DIExpression(), metadata !5064, metadata ptr %6, metadata !DIExpression()), !dbg !5262
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2536, metadata !DIExpression(), metadata !5065, metadata ptr %7, metadata !DIExpression()), !dbg !5264
  call void @llvm.dbg.value(metadata ptr undef, metadata !2527, metadata !DIExpression()), !dbg !5262
  call void @llvm.dbg.value(metadata ptr %0, metadata !2528, metadata !DIExpression()), !dbg !5262
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !5061, metadata ptr %3, metadata !DIExpression()), !dbg !5265
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !5265
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3), !dbg !5267
  store volatile i32 %107, ptr %3, align 4, !dbg !5268, !tbaa !1129, !DIAssignID !5269
  call void @llvm.dbg.assign(metadata i32 %107, metadata !1239, metadata !DIExpression(DW_OP_constu, 65535, DW_OP_and, DW_OP_stack_value), metadata !5269, metadata ptr %3, metadata !DIExpression()), !dbg !5265
  %108 = load volatile i32, ptr %3, align 4, !dbg !5270, !tbaa !1129
  %109 = trunc i32 %108 to i16, !dbg !5271
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3), !dbg !5272
  call void @llvm.dbg.value(metadata i16 %109, metadata !2530, metadata !DIExpression()), !dbg !5262
  call void @llvm.dbg.value(metadata i32 %104, metadata !2531, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !5262
  call void @llvm.dbg.value(metadata i32 poison, metadata !2532, metadata !DIExpression()), !dbg !5262
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %6) #6, !dbg !5273
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !5274
  %110 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !5276
  store i64 %110, ptr %6, align 8, !dbg !5277, !tbaa !1930, !DIAssignID !5278
  call void @llvm.dbg.assign(metadata i64 %110, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5278, metadata ptr %6, metadata !DIExpression()), !dbg !5262
  %111 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 1, !dbg !5277
  store i32 %99, ptr %111, align 8, !dbg !5277, !tbaa !1938, !DIAssignID !5279
  call void @llvm.dbg.assign(metadata i32 poison, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !5279, metadata ptr %111, metadata !DIExpression()), !dbg !5262
  %112 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 2, !dbg !5277
  store i16 %109, ptr %112, align 4, !dbg !5277, !tbaa !1944, !DIAssignID !5280
  call void @llvm.dbg.assign(metadata i16 %109, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !5280, metadata ptr %112, metadata !DIExpression()), !dbg !5262
  %113 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 3, !dbg !5277
  store i16 0, ptr %113, align 2, !dbg !5277, !tbaa !2559, !DIAssignID !5281
  call void @llvm.dbg.assign(metadata i16 0, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 112, 16), metadata !5281, metadata ptr %113, metadata !DIExpression()), !dbg !5262
  %114 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %6) #6, !dbg !5282
  call void @llvm.dbg.value(metadata ptr %114, metadata !2529, metadata !DIExpression()), !dbg !5262
  %115 = icmp eq ptr %114, null, !dbg !5283
  br i1 %115, label %116, label %117, !dbg !5284

116:                                              ; preds = %103
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #6, !dbg !5285
  call void @llvm.dbg.value(metadata i32 -6, metadata !5230, metadata !DIExpression()), !dbg !5231
  br label %166, !dbg !5286

117:                                              ; preds = %103
  %118 = trunc i32 %104 to i8, !dbg !5287
  call void @llvm.dbg.value(metadata i8 %118, metadata !2531, metadata !DIExpression()), !dbg !5262
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %7) #6, !dbg !5288
  %119 = load i32, ptr %114, align 4, !dbg !5289, !tbaa !1947
  store i32 %119, ptr %7, align 4, !dbg !5290, !tbaa !1264, !DIAssignID !5291
  call void @llvm.dbg.assign(metadata i32 %119, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !5291, metadata ptr %7, metadata !DIExpression()), !dbg !5264
  %120 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 1, !dbg !5290
  %121 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %114, i64 0, i32 1, !dbg !5292
  %122 = load i16, ptr %121, align 4, !dbg !5292, !tbaa !1952
  store i16 %122, ptr %120, align 4, !dbg !5290, !tbaa !1268, !DIAssignID !5293
  call void @llvm.dbg.assign(metadata i16 %122, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !5293, metadata ptr %120, metadata !DIExpression()), !dbg !5264
  %123 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 2, !dbg !5290
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !5294, metadata ptr %123, metadata !DIExpression()), !dbg !5264
  %124 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 3, !dbg !5290
  store i8 %118, ptr %124, align 4, !dbg !5290, !tbaa !1271, !DIAssignID !5295
  call void @llvm.dbg.assign(metadata i8 %118, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !5295, metadata ptr %124, metadata !DIExpression()), !dbg !5264
  %125 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 4, !dbg !5290
  call void @llvm.dbg.assign(metadata i8 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !5296, metadata ptr %125, metadata !DIExpression()), !dbg !5264
  %126 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 5, !dbg !5290
  store i16 0, ptr %126, align 2, !dbg !5290, !DIAssignID !5297
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !5297, metadata ptr %126, metadata !DIExpression()), !dbg !5264
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !5298, metadata ptr undef, metadata !DIExpression()), !dbg !5299
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !5301, metadata ptr undef, metadata !DIExpression()), !dbg !5299
  call void @llvm.dbg.value(metadata ptr %7, metadata !1289, metadata !DIExpression()), !dbg !5299
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !5299
  store i16 0, ptr %123, align 2, !dbg !5302, !tbaa !1298
  store i8 0, ptr %125, align 1, !dbg !5303, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %7, metadata !1301, metadata !DIExpression()), !dbg !5304
  %127 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %7) #6, !dbg !5306
  call void @llvm.dbg.value(metadata ptr %127, metadata !1291, metadata !DIExpression()), !dbg !5299
  %128 = icmp eq ptr %127, null, !dbg !5307
  br i1 %128, label %137, label %129, !dbg !5308

129:                                              ; preds = %117
  call void @llvm.dbg.value(metadata ptr %127, metadata !1312, metadata !DIExpression()), !dbg !5309
  %130 = getelementptr inbounds %struct.lb4_service, ptr %127, i64 0, i32 4, !dbg !5311
  %131 = load i8, ptr %130, align 1, !dbg !5311, !tbaa !1321
  %132 = and i8 %131, 32, !dbg !5312
  %133 = icmp eq i8 %132, 0, !dbg !5313
  br i1 %133, label %140, label %134, !dbg !5314

134:                                              ; preds = %129
  store i8 1, ptr %125, align 1, !dbg !5315, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %7, metadata !1301, metadata !DIExpression()), !dbg !5316
  %135 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %7) #6, !dbg !5318
  call void @llvm.dbg.value(metadata ptr %135, metadata !2533, metadata !DIExpression()), !dbg !5264
  %136 = icmp eq ptr %135, null, !dbg !5319
  br i1 %136, label %137, label %140, !dbg !5320

137:                                              ; preds = %117, %134
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !5321
  call void @llvm.dbg.value(metadata ptr null, metadata !1233, metadata !DIExpression()), !dbg !5321
  %138 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #6, !dbg !5323
  call void @llvm.dbg.value(metadata i64 %138, metadata !1234, metadata !DIExpression()), !dbg !5321
  %139 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #6, !dbg !5324
  br label %151, !dbg !5325

140:                                              ; preds = %129, %134
  %141 = phi ptr [ %135, %134 ], [ %127, %129 ]
  call void @llvm.dbg.value(metadata ptr %141, metadata !2533, metadata !DIExpression()), !dbg !5264
  %142 = getelementptr inbounds %struct.lb4_service, ptr %141, i64 0, i32 2, !dbg !5326
  %143 = load i16, ptr %142, align 2, !dbg !5326, !tbaa !1601
  %144 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %114, i64 0, i32 2, !dbg !5327
  %145 = load i16, ptr %144, align 2, !dbg !5327, !tbaa !1956
  %146 = icmp eq i16 %143, %145, !dbg !5328
  br i1 %146, label %147, label %151, !dbg !5329

147:                                              ; preds = %140
  %148 = getelementptr inbounds %struct.lb4_service, ptr %141, i64 0, i32 1, !dbg !5330
  %149 = load i16, ptr %148, align 4, !dbg !5330, !tbaa !1334
  %150 = icmp eq i16 %149, 0, !dbg !5331
  br i1 %150, label %151, label %162, !dbg !5332

151:                                              ; preds = %137, %147, %140
  %152 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %6) #6, !dbg !5333
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !5062, metadata ptr %4, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !5063, metadata ptr %5, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.value(metadata i8 1, metadata !1766, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.value(metadata i8 8, metadata !1767, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.value(metadata i16 612, metadata !1768, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5334
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #6, !dbg !5336
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5337, metadata ptr %4, metadata !DIExpression()), !dbg !5334
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #6, !dbg !5338
  store i64 21514944776, ptr %5, align 8, !dbg !5339, !DIAssignID !5340
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5340, metadata ptr %5, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.assign(metadata i8 8, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5341, metadata ptr %5, metadata !DIExpression()), !dbg !5334
  call void @llvm.dbg.assign(metadata i8 1, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5342, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5334
  call void @llvm.dbg.assign(metadata i16 612, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5343, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5334
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5344, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5334
  %153 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %5) #6, !dbg !5345
  call void @llvm.dbg.value(metadata ptr %153, metadata !1770, metadata !DIExpression()), !dbg !5334
  %154 = icmp eq ptr %153, null, !dbg !5346
  br i1 %154, label %158, label %155, !dbg !5347

155:                                              ; preds = %151
  %156 = load i64, ptr %153, align 8, !dbg !5348, !tbaa !1790
  %157 = add i64 %156, 1, !dbg !5348
  store i64 %157, ptr %153, align 8, !dbg !5348, !tbaa !1790
  br label %161, !dbg !5349

158:                                              ; preds = %151
  store i64 1, ptr %4, align 8, !dbg !5350, !tbaa !1790, !DIAssignID !5351
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5351, metadata ptr %4, metadata !DIExpression()), !dbg !5334
  %159 = getelementptr inbounds %struct.metrics_value, ptr %4, i64 0, i32 1, !dbg !5352
  store i64 0, ptr %159, align 8, !dbg !5353, !tbaa !1798, !DIAssignID !5354
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5354, metadata ptr %159, metadata !DIExpression()), !dbg !5334
  %160 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %5, ptr noundef nonnull %4, i32 noundef 0) #6, !dbg !5355
  br label %161

161:                                              ; preds = %155, %158
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #6, !dbg !5356
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #6, !dbg !5356
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %7) #6, !dbg !5357
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #6, !dbg !5285
  call void @llvm.dbg.value(metadata i32 -2, metadata !5230, metadata !DIExpression()), !dbg !5231
  br label %166, !dbg !5286

162:                                              ; preds = %147
  %163 = load i32, ptr %114, align 4, !dbg !5358, !tbaa !1947
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !5231
  %164 = load i16, ptr %121, align 4, !dbg !5359, !tbaa !1952
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !5360
  call void @llvm.dbg.value(metadata i16 poison, metadata !2038, metadata !DIExpression()), !dbg !5360
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %7) #6, !dbg !5357
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !5228, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 64)), !dbg !5231
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #6, !dbg !5285
  call void @llvm.dbg.value(metadata i32 0, metadata !5230, metadata !DIExpression()), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 16711680, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !5229, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8)), !dbg !5231
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !5229, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !5231
  call void @llvm.dbg.value(metadata ptr %0, metadata !3398, metadata !DIExpression()), !dbg !5362
  call void @llvm.dbg.value(metadata ptr undef, metadata !3403, metadata !DIExpression()), !dbg !5362
  store i32 0, ptr %23, align 8, !dbg !5364, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5365, !srcloc !3408
  store i32 0, ptr %25, align 4, !dbg !5366, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5367, !srcloc !3411
  store i32 -65536, ptr %28, align 8, !dbg !5368, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5369, !srcloc !3414
  store i32 %163, ptr %31, align 4, !dbg !5370, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5371, !srcloc !3417
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !5372
  call void @llvm.dbg.value(metadata i16 %164, metadata !2038, metadata !DIExpression()), !dbg !5372
  %165 = zext i16 %164 to i32, !dbg !5374
  store i32 %165, ptr %14, align 8, !dbg !5375, !tbaa !1251
  br label %166, !dbg !5376

166:                                              ; preds = %91, %162, %116, %161, %90
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %11) #6, !dbg !5377
  ret i32 1, !dbg !5378
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock_release(ptr noundef %0) #0 section "cgroup/sock_release" !dbg !5379 {
  %2 = alloca %struct.ipv6_revnat_tuple, align 8, !DIAssignID !5390
  %3 = alloca %struct.metrics_value, align 8, !DIAssignID !5391
  %4 = alloca %struct.metrics_key, align 8, !DIAssignID !5392
  %5 = alloca %struct.metrics_value, align 8, !DIAssignID !5393
  %6 = alloca %struct.metrics_key, align 8, !DIAssignID !5394
  %7 = alloca %struct.metrics_value, align 8, !DIAssignID !5395
  %8 = alloca %struct.metrics_key, align 8, !DIAssignID !5396
  %9 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !5397
  %10 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !5398
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !5383, metadata !DIExpression()), !dbg !5399
  %11 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 1, !dbg !5400
  %12 = load i32, ptr %11, align 4, !dbg !5400, !tbaa !5402
  %13 = icmp eq i32 %12, 2, !dbg !5404
  br i1 %13, label %14, label %37, !dbg !5405

14:                                               ; preds = %1
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5406, metadata !DIExpression(), metadata !5397, metadata ptr %9, metadata !DIExpression()), !dbg !5416
  call void @llvm.dbg.value(metadata ptr %0, metadata !5413, metadata !DIExpression()), !dbg !5416
  call void @llvm.dbg.value(metadata ptr %0, metadata !5414, metadata !DIExpression()), !dbg !5416
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %9) #6, !dbg !5420
  %15 = getelementptr inbounds i8, ptr %9, i64 8, !dbg !5421
  store i64 0, ptr %15, align 8, !dbg !5421, !DIAssignID !5422
  call void @llvm.dbg.assign(metadata i64 0, metadata !5406, metadata !DIExpression(), metadata !5422, metadata ptr %9, metadata !DIExpression()), !dbg !5416
  call void @llvm.dbg.assign(metadata i8 0, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5423, metadata ptr undef, metadata !DIExpression()), !dbg !5416
  call void @llvm.dbg.value(metadata i32 0, metadata !5415, metadata !DIExpression()), !dbg !5416
  %16 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !5424
  store i64 %16, ptr %9, align 8, !dbg !5425, !tbaa !1930, !DIAssignID !5426
  call void @llvm.dbg.assign(metadata i64 %16, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5426, metadata ptr %9, metadata !DIExpression()), !dbg !5416
  %17 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 11, !dbg !5427
  %18 = load i32, ptr %17, align 4, !dbg !5427, !tbaa !5428
  %19 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %9, i64 0, i32 1, !dbg !5429
  store i32 %18, ptr %19, align 8, !dbg !5430, !tbaa !1938, !DIAssignID !5431
  call void @llvm.dbg.assign(metadata i32 %18, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !5431, metadata ptr %19, metadata !DIExpression()), !dbg !5416
  %20 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 9, !dbg !5432
  %21 = load i16, ptr %20, align 4, !dbg !5432, !tbaa !5433
  %22 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %9, i64 0, i32 2, !dbg !5434
  store i16 %21, ptr %22, align 4, !dbg !5435, !tbaa !1944, !DIAssignID !5436
  call void @llvm.dbg.assign(metadata i16 %21, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !5436, metadata ptr %22, metadata !DIExpression()), !dbg !5416
  %23 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %9) #6, !dbg !5437
  call void @llvm.dbg.value(metadata i32 %23, metadata !5415, metadata !DIExpression()), !dbg !5416
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %9) #6, !dbg !5438
  %24 = icmp eq i32 %23, 0, !dbg !5439
  br i1 %24, label %25, label %35, !dbg !5440

25:                                               ; preds = %14
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !5391, metadata ptr %3, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !5392, metadata ptr %4, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.value(metadata i8 14, metadata !1767, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.value(metadata i16 1294, metadata !1768, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5441
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #6, !dbg !5443
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5444, metadata ptr %3, metadata !DIExpression()), !dbg !5441
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #6, !dbg !5445
  store i64 21559640590, ptr %4, align 8, !dbg !5446, !DIAssignID !5447
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5447, metadata ptr %4, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.assign(metadata i8 14, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5448, metadata ptr %4, metadata !DIExpression()), !dbg !5441
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5449, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5441
  call void @llvm.dbg.assign(metadata i16 1294, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5450, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5441
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5451, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5441
  %26 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4) #6, !dbg !5452
  call void @llvm.dbg.value(metadata ptr %26, metadata !1770, metadata !DIExpression()), !dbg !5441
  %27 = icmp eq ptr %26, null, !dbg !5453
  br i1 %27, label %31, label %28, !dbg !5454

28:                                               ; preds = %25
  %29 = load i64, ptr %26, align 8, !dbg !5455, !tbaa !1790
  %30 = add i64 %29, 1, !dbg !5455
  store i64 %30, ptr %26, align 8, !dbg !5455, !tbaa !1790
  br label %34, !dbg !5456

31:                                               ; preds = %25
  store i64 1, ptr %3, align 8, !dbg !5457, !tbaa !1790, !DIAssignID !5458
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5458, metadata ptr %3, metadata !DIExpression()), !dbg !5441
  %32 = getelementptr inbounds %struct.metrics_value, ptr %3, i64 0, i32 1, !dbg !5459
  store i64 0, ptr %32, align 8, !dbg !5460, !tbaa !1798, !DIAssignID !5461
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5461, metadata ptr %32, metadata !DIExpression()), !dbg !5441
  %33 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4, ptr noundef nonnull %3, i32 noundef 0) #6, !dbg !5462
  br label %34

34:                                               ; preds = %28, %31
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #6, !dbg !5463
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #6, !dbg !5463
  br label %35, !dbg !5464

35:                                               ; preds = %34, %14
  %36 = load i32, ptr %11, align 4, !dbg !5465, !tbaa !5402
  br label %37, !dbg !5465

37:                                               ; preds = %35, %1
  %38 = phi i32 [ %36, %35 ], [ %12, %1 ], !dbg !5465
  %39 = icmp eq i32 %38, 10, !dbg !5466
  br i1 %39, label %40, label %101, !dbg !5467

40:                                               ; preds = %37
  call void @llvm.dbg.value(metadata ptr %0, metadata !5468, metadata !DIExpression()), !dbg !5474
  call void @llvm.dbg.value(metadata ptr undef, metadata !5473, metadata !DIExpression()), !dbg !5474
  %41 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 12, !dbg !5476
  %42 = load i32, ptr %41, align 4, !dbg !5477, !tbaa !1129
  %43 = zext i32 %42 to i64, !dbg !5478
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !5384, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !5479
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5480, !srcloc !5481
  %44 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 12, i64 1, !dbg !5482
  %45 = load i32, ptr %44, align 4, !dbg !5482, !tbaa !1129
  %46 = zext i32 %45 to i64, !dbg !5483
  %47 = shl nuw i64 %46, 32, !dbg !5483
  %48 = or disjoint i64 %47, %43, !dbg !5483
  tail call void @llvm.dbg.value(metadata i64 %48, metadata !5384, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !5479
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5484, !srcloc !5485
  %49 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 12, i64 2, !dbg !5486
  %50 = load i32, ptr %49, align 4, !dbg !5486, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %50, metadata !5384, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32)), !dbg !5479
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5487, !srcloc !5488
  %51 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 12, i64 3, !dbg !5489
  %52 = load i32, ptr %51, align 4, !dbg !5489, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !5384, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32)), !dbg !5479
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5490, !srcloc !5491
  call void @llvm.dbg.value(metadata ptr undef, metadata !2900, metadata !DIExpression()), !dbg !5492
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5492
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2906, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5492
  tail call void @llvm.dbg.value(metadata i64 %48, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5492
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2907, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5492
  tail call void @llvm.dbg.value(metadata i32 %50, metadata !2907, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !5492
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2911, metadata !DIExpression()), !dbg !5494
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2916, metadata !DIExpression()), !dbg !5494
  %53 = icmp eq i64 %48, 0, !dbg !5496
  %54 = icmp eq i32 %50, -65536
  %55 = select i1 %53, i1 %54, i1 false, !dbg !5497
  br i1 %55, label %56, label %75, !dbg !5497

56:                                               ; preds = %40
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !5498
  tail call void @llvm.dbg.value(metadata i64 0, metadata !5387, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 416, 32)), !dbg !5498
  %57 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 9, !dbg !5499
  %58 = load i16, ptr %57, align 4, !dbg !5499, !tbaa !5433
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i16 poison), metadata !5387, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 384, 16)), !dbg !5498
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5406, metadata !DIExpression(), metadata !5398, metadata ptr %10, metadata !DIExpression()), !dbg !5500
  call void @llvm.dbg.value(metadata ptr undef, metadata !5413, metadata !DIExpression()), !dbg !5500
  call void @llvm.dbg.value(metadata ptr %0, metadata !5414, metadata !DIExpression()), !dbg !5500
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %10) #6, !dbg !5503
  %59 = getelementptr inbounds i8, ptr %10, i64 8, !dbg !5504
  store i64 0, ptr %59, align 8, !dbg !5504, !DIAssignID !5505
  call void @llvm.dbg.assign(metadata i64 0, metadata !5406, metadata !DIExpression(), metadata !5505, metadata ptr %10, metadata !DIExpression()), !dbg !5500
  call void @llvm.dbg.assign(metadata i8 0, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5506, metadata ptr undef, metadata !DIExpression()), !dbg !5500
  call void @llvm.dbg.value(metadata i32 0, metadata !5415, metadata !DIExpression()), !dbg !5500
  %60 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !5507
  store i64 %60, ptr %10, align 8, !dbg !5508, !tbaa !1930, !DIAssignID !5509
  call void @llvm.dbg.assign(metadata i64 %60, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5509, metadata ptr %10, metadata !DIExpression()), !dbg !5500
  %61 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %10, i64 0, i32 1, !dbg !5510
  store i32 %52, ptr %61, align 8, !dbg !5511, !tbaa !1938, !DIAssignID !5512
  call void @llvm.dbg.assign(metadata i32 poison, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !5512, metadata ptr %61, metadata !DIExpression()), !dbg !5500
  %62 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %10, i64 0, i32 2, !dbg !5513
  store i16 %58, ptr %62, align 4, !dbg !5514, !tbaa !1944, !DIAssignID !5515
  call void @llvm.dbg.assign(metadata i16 %58, metadata !5406, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !5515, metadata ptr %62, metadata !DIExpression()), !dbg !5500
  %63 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %10) #6, !dbg !5516
  call void @llvm.dbg.value(metadata i32 %63, metadata !5415, metadata !DIExpression()), !dbg !5500
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %10) #6, !dbg !5517
  %64 = icmp eq i32 %63, 0, !dbg !5518
  br i1 %64, label %65, label %101, !dbg !5519

65:                                               ; preds = %56
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !5393, metadata ptr %5, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !5394, metadata ptr %6, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.value(metadata i8 14, metadata !1767, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.value(metadata i16 1312, metadata !1768, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5520
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %5) #6, !dbg !5522
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5523, metadata ptr %5, metadata !DIExpression()), !dbg !5520
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6) #6, !dbg !5524
  store i64 21560820238, ptr %6, align 8, !dbg !5525, !DIAssignID !5526
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5526, metadata ptr %6, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.assign(metadata i8 14, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5527, metadata ptr %6, metadata !DIExpression()), !dbg !5520
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5528, metadata ptr %6, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5520
  call void @llvm.dbg.assign(metadata i16 1312, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5529, metadata ptr %6, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5520
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5530, metadata ptr %6, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5520
  %66 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %6) #6, !dbg !5531
  call void @llvm.dbg.value(metadata ptr %66, metadata !1770, metadata !DIExpression()), !dbg !5520
  %67 = icmp eq ptr %66, null, !dbg !5532
  br i1 %67, label %71, label %68, !dbg !5533

68:                                               ; preds = %65
  %69 = load i64, ptr %66, align 8, !dbg !5534, !tbaa !1790
  %70 = add i64 %69, 1, !dbg !5534
  store i64 %70, ptr %66, align 8, !dbg !5534, !tbaa !1790
  br label %74, !dbg !5535

71:                                               ; preds = %65
  store i64 1, ptr %5, align 8, !dbg !5536, !tbaa !1790, !DIAssignID !5537
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5537, metadata ptr %5, metadata !DIExpression()), !dbg !5520
  %72 = getelementptr inbounds %struct.metrics_value, ptr %5, i64 0, i32 1, !dbg !5538
  store i64 0, ptr %72, align 8, !dbg !5539, !tbaa !1798, !DIAssignID !5540
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5540, metadata ptr %72, metadata !DIExpression()), !dbg !5520
  %73 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %6, ptr noundef nonnull %5, i32 noundef 0) #6, !dbg !5541
  br label %74

74:                                               ; preds = %68, %71
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6) #6, !dbg !5542
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %5) #6, !dbg !5542
  br label %101, !dbg !5543

75:                                               ; preds = %40
  call void @llvm.dbg.assign(metadata i1 undef, metadata !5544, metadata !DIExpression(), metadata !5390, metadata ptr %2, metadata !DIExpression()), !dbg !5549
  call void @llvm.dbg.value(metadata ptr %0, metadata !5547, metadata !DIExpression()), !dbg !5549
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %2) #6, !dbg !5553
  %76 = getelementptr inbounds i8, ptr %2, i64 24, !dbg !5554
  store i64 0, ptr %76, align 8, !dbg !5554, !DIAssignID !5555
  call void @llvm.dbg.assign(metadata i64 0, metadata !5544, metadata !DIExpression(), metadata !5555, metadata ptr %2, metadata !DIExpression()), !dbg !5549
  call void @llvm.dbg.assign(metadata i8 0, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 192), metadata !5556, metadata ptr undef, metadata !DIExpression()), !dbg !5549
  call void @llvm.dbg.value(metadata i32 0, metadata !5548, metadata !DIExpression()), !dbg !5549
  %77 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #6, !dbg !5557
  store i64 %77, ptr %2, align 8, !dbg !5558, !tbaa !3924, !DIAssignID !5559
  call void @llvm.dbg.assign(metadata i64 %77, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5559, metadata ptr %2, metadata !DIExpression()), !dbg !5549
  %78 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %2, i64 0, i32 1, !dbg !5560
  call void @llvm.dbg.value(metadata ptr %0, metadata !5468, metadata !DIExpression()), !dbg !5561
  call void @llvm.dbg.value(metadata ptr %78, metadata !5473, metadata !DIExpression()), !dbg !5561
  %79 = load i32, ptr %41, align 4, !dbg !5563, !tbaa !1129
  store i32 %79, ptr %78, align 8, !dbg !5564, !tbaa !1444, !DIAssignID !5565
  call void @llvm.dbg.assign(metadata i32 %79, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !5565, metadata ptr %78, metadata !DIExpression()), !dbg !5549
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5566, !srcloc !5481
  %80 = load i32, ptr %44, align 4, !dbg !5567, !tbaa !1129
  %81 = getelementptr inbounds i8, ptr %2, i64 12, !dbg !5568
  store i32 %80, ptr %81, align 4, !dbg !5569, !tbaa !1444, !DIAssignID !5570
  call void @llvm.dbg.assign(metadata i32 %80, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !5570, metadata ptr %81, metadata !DIExpression()), !dbg !5549
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5571, !srcloc !5485
  %82 = load i32, ptr %49, align 4, !dbg !5572, !tbaa !1129
  %83 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %2, i64 0, i32 1, i32 0, i32 1, !dbg !5573
  store i32 %82, ptr %83, align 8, !dbg !5574, !tbaa !1444, !DIAssignID !5575
  call void @llvm.dbg.assign(metadata i32 %82, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 32), metadata !5575, metadata ptr %83, metadata !DIExpression()), !dbg !5549
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5576, !srcloc !5488
  %84 = load i32, ptr %51, align 4, !dbg !5577, !tbaa !1129
  %85 = getelementptr inbounds i8, ptr %2, i64 20, !dbg !5578
  store i32 %84, ptr %85, align 4, !dbg !5579, !tbaa !1444, !DIAssignID !5580
  call void @llvm.dbg.assign(metadata i32 %84, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 160, 32), metadata !5580, metadata ptr %85, metadata !DIExpression()), !dbg !5549
  call void asm sideeffect "", "~{memory}"() #6, !dbg !5581, !srcloc !5491
  %86 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 9, !dbg !5582
  %87 = load i16, ptr %86, align 4, !dbg !5582, !tbaa !5433
  %88 = getelementptr inbounds %struct.ipv6_revnat_tuple, ptr %2, i64 0, i32 2, !dbg !5583
  store i16 %87, ptr %88, align 8, !dbg !5584, !tbaa !3935, !DIAssignID !5585
  call void @llvm.dbg.assign(metadata i16 %87, metadata !5544, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 16), metadata !5585, metadata ptr %88, metadata !DIExpression()), !dbg !5549
  %89 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb6_reverse_sk, ptr noundef nonnull %2) #6, !dbg !5586
  call void @llvm.dbg.value(metadata i32 %89, metadata !5548, metadata !DIExpression()), !dbg !5549
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %2) #6, !dbg !5587
  %90 = icmp eq i32 %89, 0, !dbg !5588
  br i1 %90, label %91, label %101, !dbg !5589

91:                                               ; preds = %75
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !5395, metadata ptr %7, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !5396, metadata ptr %8, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.value(metadata i8 14, metadata !1767, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.value(metadata i16 1318, metadata !1768, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !5590
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %7) #6, !dbg !5592
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !5593, metadata ptr %7, metadata !DIExpression()), !dbg !5590
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %8) #6, !dbg !5594
  store i64 21561213454, ptr %8, align 8, !dbg !5595, !DIAssignID !5596
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !5596, metadata ptr %8, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.assign(metadata i8 14, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !5597, metadata ptr %8, metadata !DIExpression()), !dbg !5590
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !5598, metadata ptr %8, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !5590
  call void @llvm.dbg.assign(metadata i16 1318, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !5599, metadata ptr %8, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !5590
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !5600, metadata ptr %8, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !5590
  %92 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %8) #6, !dbg !5601
  call void @llvm.dbg.value(metadata ptr %92, metadata !1770, metadata !DIExpression()), !dbg !5590
  %93 = icmp eq ptr %92, null, !dbg !5602
  br i1 %93, label %97, label %94, !dbg !5603

94:                                               ; preds = %91
  %95 = load i64, ptr %92, align 8, !dbg !5604, !tbaa !1790
  %96 = add i64 %95, 1, !dbg !5604
  store i64 %96, ptr %92, align 8, !dbg !5604, !tbaa !1790
  br label %100, !dbg !5605

97:                                               ; preds = %91
  store i64 1, ptr %7, align 8, !dbg !5606, !tbaa !1790, !DIAssignID !5607
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !5607, metadata ptr %7, metadata !DIExpression()), !dbg !5590
  %98 = getelementptr inbounds %struct.metrics_value, ptr %7, i64 0, i32 1, !dbg !5608
  store i64 0, ptr %98, align 8, !dbg !5609, !tbaa !1798, !DIAssignID !5610
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !5610, metadata ptr %98, metadata !DIExpression()), !dbg !5590
  %99 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #6, !dbg !5611
  br label %100

100:                                              ; preds = %94, %97
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %8) #6, !dbg !5612
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %7) #6, !dbg !5612
  br label %101, !dbg !5613

101:                                              ; preds = %100, %75, %74, %56, %37
  ret i32 1, !dbg !5614
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #4

; Function Attrs: nounwind memory(none)
declare i1 @llvm.bpf.passthrough.i1.i1(i32, i1) #5

attributes #0 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind memory(none) }
attributes #6 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!1113, !1114, !1115, !1116, !1117}
!llvm.ident = !{!1118}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "__config_cluster_id_bits", scope: !2, file: !116, line: 57, type: !80, isLocal: false, isDefinition: true, annotations: !1111)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !78, globals: !101, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/repository/vendor/repos/cilium/bpf/bpf_sock.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "c266373ca70a10c959f52e3be5615484")
!4 = !{!5, !11, !18, !26, !55, !68}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 12, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../stddef.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "0595dbc0c9f00117e6524ed413cda666")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10}
!9 = !DIEnumerator(name: "false", value: 0)
!10 = !DIEnumerator(name: "true", value: 1)
!11 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "metric_dir", file: !12, line: 241, baseType: !13, size: 8, elements: !14)
!12 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/common.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "6d717dcb2b302aba4aa83d59567585a9")
!13 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!14 = !{!15, !16, !17}
!15 = !DIEnumerator(name: "METRIC_INGRESS", value: 1)
!16 = !DIEnumerator(name: "METRIC_EGRESS", value: 2)
!17 = !DIEnumerator(name: "METRIC_SERVICE", value: 3)
!18 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "xlate_point", file: !19, line: 52, baseType: !13, size: 8, elements: !20)
!19 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/trace_sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "030d77c2fb19a84a2ba208444488c6b2")
!20 = !{!21, !22, !23, !24, !25}
!21 = !DIEnumerator(name: "XLATE_UNKNOWN", value: 0)
!22 = !DIEnumerator(name: "XLATE_PRE_DIRECTION_FWD", value: 1)
!23 = !DIEnumerator(name: "XLATE_POST_DIRECTION_FWD", value: 2)
!24 = !DIEnumerator(name: "XLATE_PRE_DIRECTION_REV", value: 3)
!25 = !DIEnumerator(name: "XLATE_POST_DIRECTION_REV", value: 4)
!26 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !27, line: 25, baseType: !7, size: 32, elements: !28)
!27 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/in.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "655dc6bc041c7af070df041a2bf6f562")
!28 = !{!29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54}
!29 = !DIEnumerator(name: "IPPROTO_IP", value: 0)
!30 = !DIEnumerator(name: "IPPROTO_ICMP", value: 1)
!31 = !DIEnumerator(name: "IPPROTO_IGMP", value: 2)
!32 = !DIEnumerator(name: "IPPROTO_IPIP", value: 4)
!33 = !DIEnumerator(name: "IPPROTO_TCP", value: 6)
!34 = !DIEnumerator(name: "IPPROTO_EGP", value: 8)
!35 = !DIEnumerator(name: "IPPROTO_PUP", value: 12)
!36 = !DIEnumerator(name: "IPPROTO_UDP", value: 17)
!37 = !DIEnumerator(name: "IPPROTO_IDP", value: 22)
!38 = !DIEnumerator(name: "IPPROTO_TP", value: 29)
!39 = !DIEnumerator(name: "IPPROTO_DCCP", value: 33)
!40 = !DIEnumerator(name: "IPPROTO_IPV6", value: 41)
!41 = !DIEnumerator(name: "IPPROTO_RSVP", value: 46)
!42 = !DIEnumerator(name: "IPPROTO_GRE", value: 47)
!43 = !DIEnumerator(name: "IPPROTO_ESP", value: 50)
!44 = !DIEnumerator(name: "IPPROTO_AH", value: 51)
!45 = !DIEnumerator(name: "IPPROTO_MTP", value: 92)
!46 = !DIEnumerator(name: "IPPROTO_BEETPH", value: 94)
!47 = !DIEnumerator(name: "IPPROTO_ENCAP", value: 98)
!48 = !DIEnumerator(name: "IPPROTO_PIM", value: 103)
!49 = !DIEnumerator(name: "IPPROTO_COMP", value: 108)
!50 = !DIEnumerator(name: "IPPROTO_SCTP", value: 132)
!51 = !DIEnumerator(name: "IPPROTO_UDPLITE", value: 136)
!52 = !DIEnumerator(name: "IPPROTO_MPLS", value: 137)
!53 = !DIEnumerator(name: "IPPROTO_RAW", value: 255)
!54 = !DIEnumerator(name: "IPPROTO_MAX", value: 256)
!55 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !56, line: 368, baseType: !7, size: 32, elements: !57)
!56 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/lb.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "589b82b01c055c395b82efa3d1b0b55a")
!57 = !{!58, !59, !60, !61, !62, !63, !64, !65, !66, !67}
!58 = !DIEnumerator(name: "SVC_FLAG_LOCALREDIRECT", value: 1)
!59 = !DIEnumerator(name: "SVC_FLAG_NAT_46X64", value: 2)
!60 = !DIEnumerator(name: "SVC_FLAG_L7_LOADBALANCER", value: 4)
!61 = !DIEnumerator(name: "SVC_FLAG_LOOPBACK", value: 8)
!62 = !DIEnumerator(name: "SVC_FLAG_L7_DELEGATE", value: 8)
!63 = !DIEnumerator(name: "SVC_FLAG_INT_LOCAL_SCOPE", value: 16)
!64 = !DIEnumerator(name: "SVC_FLAG_TWO_SCOPES", value: 32)
!65 = !DIEnumerator(name: "SVC_FLAG_QUARANTINED", value: 64)
!66 = !DIEnumerator(name: "SVC_FLAG_SOURCE_RANGE_DENY", value: 64)
!67 = !DIEnumerator(name: "SVC_FLAG_FWD_MODE_DSR", value: 128)
!68 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !56, line: 356, baseType: !7, size: 32, elements: !69)
!69 = !{!70, !71, !72, !73, !74, !75, !76, !77}
!70 = !DIEnumerator(name: "SVC_FLAG_EXTERNAL_IP", value: 1)
!71 = !DIEnumerator(name: "SVC_FLAG_NODEPORT", value: 2)
!72 = !DIEnumerator(name: "SVC_FLAG_EXT_LOCAL_SCOPE", value: 4)
!73 = !DIEnumerator(name: "SVC_FLAG_HOSTPORT", value: 8)
!74 = !DIEnumerator(name: "SVC_FLAG_AFFINITY", value: 16)
!75 = !DIEnumerator(name: "SVC_FLAG_LOADBALANCER", value: 32)
!76 = !DIEnumerator(name: "SVC_FLAG_ROUTABLE", value: 64)
!77 = !DIEnumerator(name: "SVC_FLAG_SOURCE_RANGE", value: 128)
!78 = !{!79, !84, !85, !82, !87, !91, !92, !93, !97, !98, !99, !100}
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !80, size: 64)
!80 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !81)
!81 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !82)
!82 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !83, line: 13, baseType: !7)
!83 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/../bpf/types_mapper.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "ed32c96abe0b86529815ffb521dc9d75")
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !83, line: 7, baseType: !13)
!85 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !83, line: 10, baseType: !86)
!86 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!87 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !88, size: 64)
!88 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !89)
!89 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !90)
!90 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !83, line: 19, baseType: !85)
!93 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64)
!94 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !95)
!95 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !83, line: 16, baseType: !96)
!96 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!97 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64)
!98 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !95, size: 64)
!99 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !85, size: 64)
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!101 = !{!0, !102, !109, !114, !120, !134, !138, !142, !156, !181, !185, !189, !193, !197, !201, !205, !209, !215, !219, !223, !227, !231, !237, !241, !245, !249, !253, !257, !261, !265, !269, !273, !279, !284, !288, !293, !297, !338, !374, !378, !402, !406, !411, !454, !504, !535, !557, !572, !606, !626, !656, !677, !693, !724, !739, !772, !792, !815, !832, !846, !865, !881, !903, !926, !943, !947, !975, !998, !1007, !1015, !1020, !1025, !1027, !1032, !1037, !1042, !1047, !1050, !1055, !1060, !1062, !1065, !1070, !1072, !1077, !1079, !1082, !1084, !1086, !1091, !1096, !1098, !1100, !1102, !1107, !1109}
!102 = !DIGlobalVariableExpression(var: !103, expr: !DIExpression())
!103 = distinct !DIGlobalVariable(scope: null, file: !104, line: 1293, type: !105, isLocal: true, isDefinition: true)
!104 = !DIFile(filename: "vendor/repos/cilium/bpf/bpf_sock.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "c266373ca70a10c959f52e3be5615484")
!105 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 88, elements: !107)
!106 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!107 = !{!108}
!108 = !DISubrange(count: 11)
!109 = !DIGlobalVariableExpression(var: !110, expr: !DIExpression())
!110 = distinct !DIGlobalVariable(name: "____license", scope: !2, file: !104, line: 1326, type: !111, isLocal: false, isDefinition: true)
!111 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 104, elements: !112)
!112 = !{!113}
!113 = !DISubrange(count: 13)
!114 = !DIGlobalVariableExpression(var: !115, expr: !DIExpression())
!115 = distinct !DIGlobalVariable(name: "__config_cilium_net_ifindex", scope: !2, file: !116, line: 18, type: !80, isLocal: false, isDefinition: true, annotations: !117)
!116 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/config/node.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "2c957a7d9212068bebde674044b7ae68")
!117 = !{!118, !119}
!118 = !{!"btf_decl_tag", !"kind:node"}
!119 = !{!"btf_decl_tag", !"Interface index of the cilium_net device"}
!120 = !DIGlobalVariableExpression(var: !121, expr: !DIExpression())
!121 = distinct !DIGlobalVariable(name: "__config_cilium_net_mac", scope: !2, file: !116, line: 19, type: !122, isLocal: false, isDefinition: true, annotations: !132)
!122 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !123)
!123 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !124)
!124 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "macaddr", file: !125, line: 17, size: 64, elements: !126)
!125 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/eth.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "e93e5308c934dae62adf207729923efa")
!126 = !{!127, !131}
!127 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !124, file: !125, line: 18, baseType: !128, size: 48)
!128 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 48, elements: !129)
!129 = !{!130}
!130 = !DISubrange(count: 6)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !124, file: !125, line: 19, baseType: !95, size: 64)
!132 = !{!118, !133}
!133 = !{!"btf_decl_tag", !"MAC address of the cilium_net device"}
!134 = !DIGlobalVariableExpression(var: !135, expr: !DIExpression())
!135 = distinct !DIGlobalVariable(name: "__config_cilium_host_ifindex", scope: !2, file: !116, line: 20, type: !80, isLocal: false, isDefinition: true, annotations: !136)
!136 = !{!118, !137}
!137 = !{!"btf_decl_tag", !"Interface index of the cilium_host device"}
!138 = !DIGlobalVariableExpression(var: !139, expr: !DIExpression())
!139 = distinct !DIGlobalVariable(name: "__config_cilium_host_mac", scope: !2, file: !116, line: 21, type: !122, isLocal: false, isDefinition: true, annotations: !140)
!140 = !{!118, !141}
!141 = !{!"btf_decl_tag", !"MAC address of the cilium_host device"}
!142 = !DIGlobalVariableExpression(var: !143, expr: !DIExpression())
!143 = distinct !DIGlobalVariable(name: "__config_service_loopback_ipv4", scope: !2, file: !116, line: 23, type: !144, isLocal: false, isDefinition: true, annotations: !154)
!144 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !145)
!145 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !146)
!146 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "v4addr", file: !12, line: 65, size: 32, elements: !147)
!147 = !{!148, !152}
!148 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !146, file: !12, line: 66, baseType: !149, size: 32)
!149 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 32, elements: !150)
!150 = !{!151}
!151 = !DISubrange(count: 4)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "be32", scope: !146, file: !12, line: 67, baseType: !153, size: 32)
!153 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !83, line: 22, baseType: !82)
!154 = !{!118, !155}
!155 = !{!"btf_decl_tag", !"IPv4 source address used for SNAT when a Pod talks to itself over a Service"}
!156 = !DIGlobalVariableExpression(var: !157, expr: !DIExpression())
!157 = distinct !DIGlobalVariable(name: "__config_service_loopback_ipv6", scope: !2, file: !116, line: 24, type: !158, isLocal: false, isDefinition: true, annotations: !179)
!158 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !159)
!159 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !160)
!160 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "v6addr", file: !161, line: 6, size: 128, elements: !162)
!161 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv6_core.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "302bbd1e468493867fe227a3cbb3d3ac")
!162 = !{!163, !167, !174}
!163 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !160, file: !161, line: 7, baseType: !164, size: 128)
!164 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 128, elements: !165)
!165 = !{!166}
!166 = !DISubrange(count: 16)
!167 = !DIDerivedType(tag: DW_TAG_member, name: "p", scope: !160, file: !161, line: 13, baseType: !168, size: 128)
!168 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !160, file: !161, line: 8, size: 128, elements: !169)
!169 = !{!170, !171, !172, !173}
!170 = !DIDerivedType(tag: DW_TAG_member, name: "p1", scope: !168, file: !161, line: 9, baseType: !82, size: 32)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "p2", scope: !168, file: !161, line: 10, baseType: !82, size: 32, offset: 32)
!172 = !DIDerivedType(tag: DW_TAG_member, name: "p3", scope: !168, file: !161, line: 11, baseType: !82, size: 32, offset: 64)
!173 = !DIDerivedType(tag: DW_TAG_member, name: "p4", scope: !168, file: !161, line: 12, baseType: !82, size: 32, offset: 96)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "d", scope: !160, file: !161, line: 21, baseType: !175, size: 128)
!175 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !160, file: !161, line: 18, size: 128, elements: !176)
!176 = !{!177, !178}
!177 = !DIDerivedType(tag: DW_TAG_member, name: "d1", scope: !175, file: !161, line: 19, baseType: !95, size: 64)
!178 = !DIDerivedType(tag: DW_TAG_member, name: "d2", scope: !175, file: !161, line: 20, baseType: !95, size: 64, offset: 64)
!179 = !{!118, !180}
!180 = !{!"btf_decl_tag", !"IPv6 source address used for SNAT when a Pod talks to itself over a Service"}
!181 = !DIGlobalVariableExpression(var: !182, expr: !DIExpression())
!182 = distinct !DIGlobalVariable(name: "__config_router_ipv6", scope: !2, file: !116, line: 26, type: !158, isLocal: false, isDefinition: true, annotations: !183)
!183 = !{!118, !184}
!184 = !{!"btf_decl_tag", !"Internal IPv6 router address assigned to the cilium_host interface"}
!185 = !DIGlobalVariableExpression(var: !186, expr: !DIExpression())
!186 = distinct !DIGlobalVariable(name: "__config_trace_payload_len", scope: !2, file: !116, line: 28, type: !80, isLocal: false, isDefinition: true, annotations: !187)
!187 = !{!118, !188}
!188 = !{!"btf_decl_tag", !"Length of payload to capture when tracing native packets."}
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(name: "__config_trace_payload_len_overlay", scope: !2, file: !116, line: 31, type: !80, isLocal: false, isDefinition: true, annotations: !191)
!191 = !{!118, !192}
!192 = !{!"btf_decl_tag", !"Length of payload to capture when tracing overlay packets."}
!193 = !DIGlobalVariableExpression(var: !194, expr: !DIExpression())
!194 = distinct !DIGlobalVariable(name: "__config_direct_routing_dev_ifindex", scope: !2, file: !116, line: 33, type: !80, isLocal: false, isDefinition: true, annotations: !195)
!195 = !{!118, !196}
!196 = !{!"btf_decl_tag", !"Index of the interface used to connect nodes in the cluster."}
!197 = !DIGlobalVariableExpression(var: !198, expr: !DIExpression())
!198 = distinct !DIGlobalVariable(name: "__config_supports_fib_lookup_skip_neigh", scope: !2, file: !116, line: 35, type: !88, isLocal: false, isDefinition: true, annotations: !199)
!199 = !{!118, !200}
!200 = !{!"btf_decl_tag", !"Whether or not BPF_FIB_LOOKUP_SKIP_NEIGH is supported."}
!201 = !DIGlobalVariableExpression(var: !202, expr: !DIExpression())
!202 = distinct !DIGlobalVariable(name: "__config_supports_fib_lookup_src", scope: !2, file: !116, line: 38, type: !88, isLocal: false, isDefinition: true, annotations: !203)
!203 = !{!118, !204}
!204 = !{!"btf_decl_tag", !"Whether or not BPF_FIB_LOOKUP_SRC is supported."}
!205 = !DIGlobalVariableExpression(var: !206, expr: !DIExpression())
!206 = distinct !DIGlobalVariable(name: "__config_enable_nodeport_source_lookup", scope: !2, file: !116, line: 41, type: !88, isLocal: false, isDefinition: true, annotations: !207)
!207 = !{!118, !208}
!208 = !{!"btf_decl_tag", !"Enable dynamic source IP resolution for SNAT via linux's routing table."}
!209 = !DIGlobalVariableExpression(var: !210, expr: !DIExpression())
!210 = distinct !DIGlobalVariable(name: "__config_tracing_ip_option_type", scope: !2, file: !116, line: 44, type: !211, isLocal: false, isDefinition: true, annotations: !213)
!211 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !212)
!212 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !84)
!213 = !{!118, !214}
!214 = !{!"btf_decl_tag", !"The IP option type to use for packet tracing"}
!215 = !DIGlobalVariableExpression(var: !216, expr: !DIExpression())
!216 = distinct !DIGlobalVariable(name: "__config_policy_deny_response_enabled", scope: !2, file: !116, line: 46, type: !88, isLocal: false, isDefinition: true, annotations: !217)
!217 = !{!118, !218}
!218 = !{!"btf_decl_tag", !"Enable ICMP responses for policy-denied traffic"}
!219 = !DIGlobalVariableExpression(var: !220, expr: !DIExpression())
!220 = distinct !DIGlobalVariable(name: "__config_cluster_id", scope: !2, file: !116, line: 48, type: !80, isLocal: false, isDefinition: true, annotations: !221)
!221 = !{!118, !222}
!222 = !{!"btf_decl_tag", !"Cluster ID"}
!223 = !DIGlobalVariableExpression(var: !224, expr: !DIExpression())
!224 = distinct !DIGlobalVariable(name: "__config_enable_conntrack_accounting", scope: !2, file: !116, line: 59, type: !88, isLocal: false, isDefinition: true, annotations: !225)
!225 = !{!118, !226}
!226 = !{!"btf_decl_tag", !"Enable per flow (conntrack) statistics"}
!227 = !DIGlobalVariableExpression(var: !228, expr: !DIExpression())
!228 = distinct !DIGlobalVariable(name: "__config_debug_lb", scope: !2, file: !116, line: 61, type: !88, isLocal: false, isDefinition: true, annotations: !229)
!229 = !{!118, !230}
!230 = !{!"btf_decl_tag", !"Enable debugging trace statements for load balancer"}
!231 = !DIGlobalVariableExpression(var: !232, expr: !DIExpression())
!232 = distinct !DIGlobalVariable(name: "__config_nodeport_port_min", scope: !2, file: !116, line: 63, type: !233, isLocal: false, isDefinition: true, annotations: !235)
!233 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !234)
!234 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !85)
!235 = !{!118, !236}
!236 = !{!"btf_decl_tag", !"Nodeport minimum port value."}
!237 = !DIGlobalVariableExpression(var: !238, expr: !DIExpression())
!238 = distinct !DIGlobalVariable(name: "__config_nodeport_port_max", scope: !2, file: !116, line: 64, type: !233, isLocal: false, isDefinition: true, annotations: !239)
!239 = !{!118, !240}
!240 = !{!"btf_decl_tag", !"Nodeport maximum port value."}
!241 = !DIGlobalVariableExpression(var: !242, expr: !DIExpression())
!242 = distinct !DIGlobalVariable(name: "__config_hash_init4_seed", scope: !2, file: !116, line: 66, type: !80, isLocal: false, isDefinition: true, annotations: !243)
!243 = !{!118, !244}
!244 = !{!"btf_decl_tag", !"Cluster-wide IPv4 tuple hash seed sourced"}
!245 = !DIGlobalVariableExpression(var: !246, expr: !DIExpression())
!246 = distinct !DIGlobalVariable(name: "__config_hash_init6_seed", scope: !2, file: !116, line: 67, type: !80, isLocal: false, isDefinition: true, annotations: !247)
!247 = !{!118, !248}
!248 = !{!"btf_decl_tag", !"Cluster-wide IPv6 tuple hash seed sourced"}
!249 = !DIGlobalVariableExpression(var: !250, expr: !DIExpression())
!250 = distinct !DIGlobalVariable(name: "__config_nat_46x64_prefix", scope: !2, file: !116, line: 69, type: !144, isLocal: false, isDefinition: true, annotations: !251)
!251 = !{!118, !252}
!252 = !{!"btf_decl_tag", !"NAT 46x64 prefix"}
!253 = !DIGlobalVariableExpression(var: !254, expr: !DIExpression())
!254 = distinct !DIGlobalVariable(name: "__config_enable_tproxy", scope: !2, file: !116, line: 71, type: !88, isLocal: false, isDefinition: true, annotations: !255)
!255 = !{!118, !256}
!256 = !{!"btf_decl_tag", !"Enable BPF-based proxy redirection"}
!257 = !DIGlobalVariableExpression(var: !258, expr: !DIExpression())
!258 = distinct !DIGlobalVariable(name: "__config_events_map_rate_limit", scope: !2, file: !116, line: 73, type: !80, isLocal: false, isDefinition: true, annotations: !259)
!259 = !{!118, !260}
!260 = !{!"btf_decl_tag", !"The sustained message rate for the BPF events map in messages per second"}
!261 = !DIGlobalVariableExpression(var: !262, expr: !DIExpression())
!262 = distinct !DIGlobalVariable(name: "__config_events_map_burst_limit", scope: !2, file: !116, line: 75, type: !80, isLocal: false, isDefinition: true, annotations: !263)
!263 = !{!118, !264}
!264 = !{!"btf_decl_tag", !"Maximum number of messages that can be written to BPF events map in 1 second"}
!265 = !DIGlobalVariableExpression(var: !266, expr: !DIExpression())
!266 = distinct !DIGlobalVariable(name: "__config_enable_endpoint_routes", scope: !2, file: !116, line: 78, type: !88, isLocal: false, isDefinition: true, annotations: !267)
!267 = !{!118, !268}
!268 = !{!"btf_decl_tag", !"Enable per endpoint routes"}
!269 = !DIGlobalVariableExpression(var: !270, expr: !DIExpression())
!270 = distinct !DIGlobalVariable(name: "__config_enable_identity_mark", scope: !2, file: !116, line: 80, type: !88, isLocal: false, isDefinition: true, annotations: !271)
!271 = !{!118, !272}
!272 = !{!"btf_decl_tag", !"Enable setting identity mark for local traffic"}
!273 = !DIGlobalVariableExpression(var: !274, expr: !DIExpression())
!274 = distinct !DIGlobalVariable(name: "__config_enable_no_service_endpoints_routable", scope: !2, file: !275, line: 12, type: !88, isLocal: false, isDefinition: true, annotations: !276)
!275 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/config/sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "9d4aa23e1dc39e0b8f56dbae0a0d0aaa")
!276 = !{!277, !278}
!277 = !{!"btf_decl_tag", !"kind:object"}
!278 = !{!"btf_decl_tag", !"Enable routes when service has 0 endpoints"}
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(name: "__config_tunnel_protocol", scope: !2, file: !281, line: 13, type: !211, isLocal: false, isDefinition: true, annotations: !282)
!281 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/tunnel.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "deadd08d84a77550e53e333137948c7d")
!282 = !{!277, !283}
!283 = !{!"btf_decl_tag", !"The identifier of the tunnel protocol used for the overlay network"}
!284 = !DIGlobalVariableExpression(var: !285, expr: !DIExpression())
!285 = distinct !DIGlobalVariable(name: "__config_tunnel_port", scope: !2, file: !281, line: 15, type: !233, isLocal: false, isDefinition: true, annotations: !286)
!286 = !{!277, !287}
!287 = !{!"btf_decl_tag", !"Port number used for the overlay network"}
!288 = !DIGlobalVariableExpression(var: !289, expr: !DIExpression())
!289 = distinct !DIGlobalVariable(name: "__config_enable_jiffies", scope: !2, file: !290, line: 13, type: !88, isLocal: false, isDefinition: true, annotations: !291)
!290 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/time.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "cede07acb17595554e213823ab4d68f8")
!291 = !{!118, !292}
!292 = !{!"btf_decl_tag", !"Use jiffies (count of timer ticks since boot)."}
!293 = !DIGlobalVariableExpression(var: !294, expr: !DIExpression())
!294 = distinct !DIGlobalVariable(name: "__config_kernel_hz", scope: !2, file: !290, line: 14, type: !80, isLocal: false, isDefinition: true, annotations: !295)
!295 = !{!118, !296}
!296 = !{!"btf_decl_tag", !"Number of timer ticks per second."}
!297 = !DIGlobalVariableExpression(var: !298, expr: !DIExpression())
!298 = distinct !DIGlobalVariable(name: "cilium_metrics", scope: !2, file: !299, line: 35, type: !300, isLocal: false, isDefinition: true)
!299 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/metrics.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "bd6864e45aaef2a70477bbef7a6154c5")
!300 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !299, line: 28, size: 384, elements: !301)
!301 = !{!302, !308, !321, !327, !332, !337}
!302 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !300, file: !299, line: 29, baseType: !303, size: 64)
!303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !304, size: 64)
!304 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 160, elements: !306)
!305 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!306 = !{!307}
!307 = !DISubrange(count: 5)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !300, file: !299, line: 30, baseType: !309, size: 64, offset: 64)
!309 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !310, size: 64)
!310 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "metrics_key", file: !299, line: 14, size: 64, elements: !311)
!311 = !{!312, !313, !314, !315, !316, !317}
!312 = !DIDerivedType(tag: DW_TAG_member, name: "reason", scope: !310, file: !299, line: 15, baseType: !84, size: 8)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "dir", scope: !310, file: !299, line: 16, baseType: !84, size: 2, offset: 8, flags: DIFlagBitField, extraData: i64 8)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !310, file: !299, line: 17, baseType: !84, size: 6, offset: 10, flags: DIFlagBitField, extraData: i64 8)
!315 = !DIDerivedType(tag: DW_TAG_member, name: "line", scope: !310, file: !299, line: 18, baseType: !85, size: 16, offset: 16)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "file", scope: !310, file: !299, line: 19, baseType: !84, size: 8, offset: 32)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !310, file: !299, line: 20, baseType: !318, size: 24, offset: 40)
!318 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 24, elements: !319)
!319 = !{!320}
!320 = !DISubrange(count: 3)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !300, file: !299, line: 31, baseType: !322, size: 64, offset: 128)
!322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !323, size: 64)
!323 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "metrics_value", file: !299, line: 23, size: 128, elements: !324)
!324 = !{!325, !326}
!325 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !323, file: !299, line: 24, baseType: !95, size: 64)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !323, file: !299, line: 25, baseType: !95, size: 64, offset: 64)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !300, file: !299, line: 32, baseType: !328, size: 64, offset: 192)
!328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !329, size: 64)
!329 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32, elements: !330)
!330 = !{!331}
!331 = !DISubrange(count: 1)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !300, file: !299, line: 33, baseType: !333, size: 64, offset: 256)
!333 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !334, size: 64)
!334 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 2097152, elements: !335)
!335 = !{!336}
!336 = !DISubrange(count: 65536)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !300, file: !299, line: 34, baseType: !328, size: 64, offset: 320)
!338 = !DIGlobalVariableExpression(var: !339, expr: !DIExpression())
!339 = distinct !DIGlobalVariable(name: "cilium_ipv4_frag_datagrams", scope: !2, file: !340, line: 36, type: !341, isLocal: false, isDefinition: true)
!340 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv4.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "95f511aec67302923e0996ea848a1a83")
!341 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !340, line: 29, size: 384, elements: !342)
!342 = !{!343, !348, !357, !363, !364, !369}
!343 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !341, file: !340, line: 30, baseType: !344, size: 64)
!344 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!345 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 288, elements: !346)
!346 = !{!347}
!347 = !DISubrange(count: 9)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !341, file: !340, line: 31, baseType: !349, size: 64, offset: 64)
!349 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!350 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_frag_id", file: !340, line: 16, size: 96, elements: !351)
!351 = !{!352, !353, !354, !355, !356}
!352 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !350, file: !340, line: 17, baseType: !153, size: 32)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !350, file: !340, line: 18, baseType: !153, size: 32, offset: 32)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !350, file: !340, line: 19, baseType: !92, size: 16, offset: 64)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !350, file: !340, line: 20, baseType: !84, size: 8, offset: 80)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !350, file: !340, line: 21, baseType: !84, size: 8, offset: 88)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !341, file: !340, line: 32, baseType: !358, size: 64, offset: 128)
!358 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !359, size: 64)
!359 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_frag_l4ports", file: !340, line: 24, size: 32, elements: !360)
!360 = !{!361, !362}
!361 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !359, file: !340, line: 25, baseType: !92, size: 16)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !359, file: !340, line: 26, baseType: !92, size: 16, offset: 16)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !341, file: !340, line: 33, baseType: !328, size: 64, offset: 192)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !341, file: !340, line: 34, baseType: !365, size: 64, offset: 256)
!365 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !366, size: 64)
!366 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 262144, elements: !367)
!367 = !{!368}
!368 = !DISubrange(count: 8192)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !341, file: !340, line: 35, baseType: !370, size: 64, offset: 320)
!370 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !371, size: 64)
!371 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, elements: !372)
!372 = !{!373}
!373 = !DISubrange(count: 0)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "__config_enable_ipv4_fragments", scope: !2, file: !340, line: 38, type: !88, isLocal: false, isDefinition: true, annotations: !376)
!376 = !{!277, !377}
!377 = !{!"btf_decl_tag", !"Enable IPv4 fragments tracking"}
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(name: "cilium_ipv6_frag_datagrams", scope: !2, file: !380, line: 63, type: !381, isLocal: false, isDefinition: true)
!380 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv6.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "9b34fd6d79827b36002c907097fa16e8")
!381 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !380, line: 56, size: 384, elements: !382)
!382 = !{!383, !384, !393, !399, !400, !401}
!383 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !381, file: !380, line: 57, baseType: !344, size: 64)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !381, file: !380, line: 58, baseType: !385, size: 64, offset: 64)
!385 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !386, size: 64)
!386 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_frag_id", file: !380, line: 43, size: 320, elements: !387)
!387 = !{!388, !389, !390, !391, !392}
!388 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !386, file: !380, line: 44, baseType: !153, size: 32)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !386, file: !380, line: 45, baseType: !84, size: 8, offset: 32)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !386, file: !380, line: 46, baseType: !318, size: 24, offset: 40)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !386, file: !380, line: 47, baseType: !160, size: 128, offset: 64)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !386, file: !380, line: 48, baseType: !160, size: 128, offset: 192)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !381, file: !380, line: 59, baseType: !394, size: 64, offset: 128)
!394 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !395, size: 64)
!395 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_frag_l4ports", file: !380, line: 51, size: 32, elements: !396)
!396 = !{!397, !398}
!397 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !395, file: !380, line: 52, baseType: !92, size: 16)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !395, file: !380, line: 53, baseType: !92, size: 16, offset: 16)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !381, file: !380, line: 60, baseType: !328, size: 64, offset: 192)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !381, file: !380, line: 61, baseType: !365, size: 64, offset: 256)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !381, file: !380, line: 62, baseType: !370, size: 64, offset: 320)
!402 = !DIGlobalVariableExpression(var: !403, expr: !DIExpression())
!403 = distinct !DIGlobalVariable(name: "__config_enable_ipv6_fragments", scope: !2, file: !380, line: 65, type: !88, isLocal: false, isDefinition: true, annotations: !404)
!404 = !{!277, !405}
!405 = !{!"btf_decl_tag", !"Enable IPv6 fragments tracking"}
!406 = !DIGlobalVariableExpression(var: !407, expr: !DIExpression())
!407 = distinct !DIGlobalVariable(name: "__config_enable_extended_ip_protocols", scope: !2, file: !408, line: 20, type: !88, isLocal: false, isDefinition: true, annotations: !409)
!408 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/conntrack.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "55dc355b668ff7d7eba6e075c9719098")
!409 = !{!277, !410}
!410 = !{!"btf_decl_tag", !"Pass traffic with extended IP protocols"}
!411 = !DIGlobalVariableExpression(var: !412, expr: !DIExpression())
!412 = distinct !DIGlobalVariable(name: "cilium_lxc", scope: !2, file: !413, line: 56, type: !414, isLocal: false, isDefinition: true)
!413 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/eps.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "e1aa19a2efaa3c0442f444e1d917b318")
!414 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !413, line: 49, size: 384, elements: !415)
!415 = !{!416, !417, !429, !447, !448, !449}
!416 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !414, file: !413, line: 50, baseType: !328, size: 64)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !414, file: !413, line: 51, baseType: !418, size: 64, offset: 64)
!418 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !419, size: 64)
!419 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "endpoint_key", file: !413, line: 17, size: 160, elements: !420)
!420 = !{!421, !426, !427, !428}
!421 = !DIDerivedType(tag: DW_TAG_member, scope: !419, file: !413, line: 18, baseType: !422, size: 128)
!422 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !419, file: !413, line: 18, size: 128, elements: !423)
!423 = !{!424, !425}
!424 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !422, file: !413, line: 19, baseType: !146, size: 32)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !422, file: !413, line: 20, baseType: !160, size: 128)
!426 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !419, file: !413, line: 22, baseType: !84, size: 8, offset: 128)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !419, file: !413, line: 23, baseType: !84, size: 8, offset: 136)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !419, file: !413, line: 24, baseType: !85, size: 16, offset: 144)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !414, file: !413, line: 52, baseType: !430, size: 64, offset: 128)
!430 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !431, size: 64)
!431 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "endpoint_info", file: !413, line: 36, size: 384, elements: !432)
!432 = !{!433, !434, !435, !436, !437, !438, !440, !441, !442, !443}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !431, file: !413, line: 37, baseType: !82, size: 32)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "unused", scope: !431, file: !413, line: 38, baseType: !85, size: 16, offset: 32)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "lxc_id", scope: !431, file: !413, line: 39, baseType: !85, size: 16, offset: 48)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !431, file: !413, line: 40, baseType: !82, size: 32, offset: 64)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "rt_info", scope: !431, file: !413, line: 41, baseType: !82, size: 32, offset: 96)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "mac", scope: !431, file: !413, line: 42, baseType: !439, size: 64, offset: 128)
!439 = !DIDerivedType(tag: DW_TAG_typedef, name: "mac_t", file: !12, line: 63, baseType: !95)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "node_mac", scope: !431, file: !413, line: 43, baseType: !439, size: 64, offset: 192)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "sec_id", scope: !431, file: !413, line: 44, baseType: !82, size: 32, offset: 256)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "parent_ifindex", scope: !431, file: !413, line: 45, baseType: !82, size: 32, offset: 288)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !431, file: !413, line: 46, baseType: !444, size: 64, offset: 320)
!444 = !DICompositeType(tag: DW_TAG_array_type, baseType: !82, size: 64, elements: !445)
!445 = !{!446}
!446 = !DISubrange(count: 2)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !414, file: !413, line: 53, baseType: !328, size: 64, offset: 192)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !414, file: !413, line: 54, baseType: !333, size: 64, offset: 256)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !414, file: !413, line: 55, baseType: !450, size: 64, offset: 320)
!450 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !451, size: 64)
!451 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 4128, elements: !452)
!452 = !{!453}
!453 = !DISubrange(count: 129)
!454 = !DIGlobalVariableExpression(var: !455, expr: !DIExpression())
!455 = distinct !DIGlobalVariable(name: "cilium_ipcache_v2", scope: !2, file: !413, line: 126, type: !456, isLocal: false, isDefinition: true)
!456 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !413, line: 119, size: 384, elements: !457)
!457 = !{!458, !461, !480, !497, !498, !503}
!458 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !456, file: !413, line: 120, baseType: !459, size: 64)
!459 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !460, size: 64)
!460 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 352, elements: !107)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !456, file: !413, line: 121, baseType: !462, size: 64, offset: 64)
!462 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !463, size: 64)
!463 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipcache_key", file: !413, line: 107, size: 192, elements: !464)
!464 = !{!465, !472, !473, !474, !475}
!465 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !463, file: !413, line: 108, baseType: !466, size: 32)
!466 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_lpm_trie_key", file: !467, line: 82, size: 32, elements: !468)
!467 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "3d6f4ba3c0dbd345e28bb269cff4f6f1")
!468 = !{!469, !470}
!469 = !DIDerivedType(tag: DW_TAG_member, name: "prefixlen", scope: !466, file: !467, line: 83, baseType: !82, size: 32)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !466, file: !467, line: 84, baseType: !471, offset: 32)
!471 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, elements: !372)
!472 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !463, file: !413, line: 109, baseType: !85, size: 16, offset: 32)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !463, file: !413, line: 110, baseType: !84, size: 8, offset: 48)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !463, file: !413, line: 111, baseType: !84, size: 8, offset: 56)
!475 = !DIDerivedType(tag: DW_TAG_member, scope: !463, file: !413, line: 112, baseType: !476, size: 128, offset: 64)
!476 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !463, file: !413, line: 112, size: 128, elements: !477)
!477 = !{!478, !479}
!478 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !476, file: !413, line: 113, baseType: !146, size: 32)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !476, file: !413, line: 114, baseType: !160, size: 128)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !456, file: !413, line: 122, baseType: !481, size: 64, offset: 128)
!481 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !482, size: 64)
!482 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "remote_endpoint_info", file: !413, line: 92, size: 192, elements: !483)
!483 = !{!484, !485, !490, !491, !492, !493, !494, !495, !496}
!484 = !DIDerivedType(tag: DW_TAG_member, name: "sec_identity", scope: !482, file: !413, line: 93, baseType: !82, size: 32)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_endpoint", scope: !482, file: !413, line: 97, baseType: !486, size: 128, offset: 32)
!486 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !482, file: !413, line: 94, size: 128, elements: !487)
!487 = !{!488, !489}
!488 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !486, file: !413, line: 95, baseType: !146, size: 32)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !486, file: !413, line: 96, baseType: !160, size: 128)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !482, file: !413, line: 98, baseType: !85, size: 16, offset: 160)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !482, file: !413, line: 99, baseType: !84, size: 8, offset: 176)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "flag_skip_tunnel", scope: !482, file: !413, line: 100, baseType: !84, size: 1, offset: 184, flags: DIFlagBitField, extraData: i64 184)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "flag_has_tunnel_ep", scope: !482, file: !413, line: 101, baseType: !84, size: 1, offset: 185, flags: DIFlagBitField, extraData: i64 184)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "flag_ipv6_tunnel_ep", scope: !482, file: !413, line: 102, baseType: !84, size: 1, offset: 186, flags: DIFlagBitField, extraData: i64 184)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "flag_remote_cluster", scope: !482, file: !413, line: 103, baseType: !84, size: 1, offset: 187, flags: DIFlagBitField, extraData: i64 184)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !482, file: !413, line: 104, baseType: !84, size: 4, offset: 188, flags: DIFlagBitField, extraData: i64 184)
!497 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !456, file: !413, line: 123, baseType: !328, size: 64, offset: 192)
!498 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !456, file: !413, line: 124, baseType: !499, size: 64, offset: 256)
!499 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !500, size: 64)
!500 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 16384000, elements: !501)
!501 = !{!502}
!502 = !DISubrange(count: 512000)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !456, file: !413, line: 125, baseType: !450, size: 64, offset: 320)
!504 = !DIGlobalVariableExpression(var: !505, expr: !DIExpression())
!505 = distinct !DIGlobalVariable(name: "cilium_ratelimit", scope: !2, file: !506, line: 34, type: !507, isLocal: false, isDefinition: true)
!506 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ratelimit.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "1c2ea6163fda2531791bda72da99556a")
!507 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !506, line: 27, size: 384, elements: !508)
!508 = !{!509, !510, !522, !528, !529, !534}
!509 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !507, file: !506, line: 28, baseType: !344, size: 64)
!510 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !507, file: !506, line: 29, baseType: !511, size: 64, offset: 64)
!511 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !512, size: 64)
!512 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_key", file: !506, line: 13, size: 64, elements: !513)
!513 = !{!514, !515}
!514 = !DIDerivedType(tag: DW_TAG_member, name: "usage", scope: !512, file: !506, line: 14, baseType: !82, size: 32)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !512, file: !506, line: 19, baseType: !516, size: 32, offset: 32)
!516 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !512, file: !506, line: 15, size: 32, elements: !517)
!517 = !{!518}
!518 = !DIDerivedType(tag: DW_TAG_member, name: "icmpv6", scope: !516, file: !506, line: 18, baseType: !519, size: 32)
!519 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !516, file: !506, line: 16, size: 32, elements: !520)
!520 = !{!521}
!521 = !DIDerivedType(tag: DW_TAG_member, name: "netdev_idx", scope: !519, file: !506, line: 17, baseType: !82, size: 32)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !507, file: !506, line: 30, baseType: !523, size: 64, offset: 128)
!523 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !524, size: 64)
!524 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_value", file: !506, line: 22, size: 128, elements: !525)
!525 = !{!526, !527}
!526 = !DIDerivedType(tag: DW_TAG_member, name: "last_topup", scope: !524, file: !506, line: 23, baseType: !95, size: 64)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "tokens", scope: !524, file: !506, line: 24, baseType: !95, size: 64, offset: 64)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !507, file: !506, line: 31, baseType: !328, size: 64, offset: 192)
!529 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !507, file: !506, line: 32, baseType: !530, size: 64, offset: 256)
!530 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !531, size: 64)
!531 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32768, elements: !532)
!532 = !{!533}
!533 = !DISubrange(count: 1024)
!534 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !507, file: !506, line: 33, baseType: !370, size: 64, offset: 320)
!535 = !DIGlobalVariableExpression(var: !536, expr: !DIExpression())
!536 = distinct !DIGlobalVariable(name: "cilium_ratelimit_metrics", scope: !2, file: !506, line: 51, type: !537, isLocal: false, isDefinition: true)
!537 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !506, line: 44, size: 384, elements: !538)
!538 = !{!539, !540, !545, !550, !551, !556}
!539 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !537, file: !506, line: 45, baseType: !328, size: 64)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !537, file: !506, line: 46, baseType: !541, size: 64, offset: 64)
!541 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !542, size: 64)
!542 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_metrics_key", file: !506, line: 36, size: 32, elements: !543)
!543 = !{!544}
!544 = !DIDerivedType(tag: DW_TAG_member, name: "usage", scope: !542, file: !506, line: 37, baseType: !82, size: 32)
!545 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !537, file: !506, line: 47, baseType: !546, size: 64, offset: 128)
!546 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !547, size: 64)
!547 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_metrics_value", file: !506, line: 40, size: 64, elements: !548)
!548 = !{!549}
!549 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !547, file: !506, line: 41, baseType: !95, size: 64)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !537, file: !506, line: 48, baseType: !328, size: 64, offset: 192)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !537, file: !506, line: 49, baseType: !552, size: 64, offset: 256)
!552 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !553, size: 64)
!553 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 2048, elements: !554)
!554 = !{!555}
!555 = !DISubrange(count: 64)
!556 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !537, file: !506, line: 50, baseType: !328, size: 64, offset: 320)
!557 = !DIGlobalVariableExpression(var: !558, expr: !DIExpression())
!558 = distinct !DIGlobalVariable(name: "cilium_lb6_reverse_nat", scope: !2, file: !56, line: 193, type: !559, isLocal: false, isDefinition: true)
!559 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 186, size: 384, elements: !560)
!560 = !{!561, !562, !563, !569, !570, !571}
!561 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !559, file: !56, line: 187, baseType: !328, size: 64)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !559, file: !56, line: 188, baseType: !99, size: 64, offset: 64)
!563 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !559, file: !56, line: 189, baseType: !564, size: 64, offset: 128)
!564 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !565, size: 64)
!565 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_reverse_nat", file: !12, line: 410, size: 144, elements: !566)
!566 = !{!567, !568}
!567 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !565, file: !12, line: 411, baseType: !160, size: 128)
!568 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !565, file: !12, line: 412, baseType: !92, size: 16, offset: 128)
!569 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !559, file: !56, line: 190, baseType: !328, size: 64, offset: 192)
!570 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !559, file: !56, line: 191, baseType: !333, size: 64, offset: 256)
!571 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !559, file: !56, line: 192, baseType: !328, size: 64, offset: 320)
!572 = !DIGlobalVariableExpression(var: !573, expr: !DIExpression())
!573 = distinct !DIGlobalVariable(name: "cilium_lb6_services_v2", scope: !2, file: !56, line: 202, type: !574, isLocal: false, isDefinition: true)
!574 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 195, size: 384, elements: !575)
!575 = !{!576, !577, !588, !603, !604, !605}
!576 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !574, file: !56, line: 196, baseType: !328, size: 64)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !574, file: !56, line: 197, baseType: !578, size: 64, offset: 64)
!578 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !579, size: 64)
!579 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_key", file: !56, line: 24, size: 192, elements: !580)
!580 = !{!581, !582, !583, !584, !585, !586}
!581 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !579, file: !56, line: 25, baseType: !160, size: 128)
!582 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !579, file: !56, line: 26, baseType: !92, size: 16, offset: 128)
!583 = !DIDerivedType(tag: DW_TAG_member, name: "backend_slot", scope: !579, file: !56, line: 27, baseType: !85, size: 16, offset: 144)
!584 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !579, file: !56, line: 28, baseType: !84, size: 8, offset: 160)
!585 = !DIDerivedType(tag: DW_TAG_member, name: "scope", scope: !579, file: !56, line: 29, baseType: !84, size: 8, offset: 168)
!586 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !579, file: !56, line: 30, baseType: !587, size: 16, offset: 176)
!587 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 16, elements: !445)
!588 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !574, file: !56, line: 198, baseType: !589, size: 64, offset: 128)
!589 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !590, size: 64)
!590 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_service", file: !56, line: 34, size: 96, elements: !591)
!591 = !{!592, !598, !599, !600, !601, !602}
!592 = !DIDerivedType(tag: DW_TAG_member, scope: !590, file: !56, line: 35, baseType: !593, size: 32)
!593 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !590, file: !56, line: 35, size: 32, elements: !594)
!594 = !{!595, !596, !597}
!595 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !593, file: !56, line: 36, baseType: !82, size: 32)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "affinity_timeout", scope: !593, file: !56, line: 38, baseType: !82, size: 32)
!597 = !DIDerivedType(tag: DW_TAG_member, name: "l7_lb_proxy_port", scope: !593, file: !56, line: 39, baseType: !82, size: 32)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !590, file: !56, line: 41, baseType: !85, size: 16, offset: 32)
!599 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !590, file: !56, line: 42, baseType: !85, size: 16, offset: 48)
!600 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !590, file: !56, line: 43, baseType: !84, size: 8, offset: 64)
!601 = !DIDerivedType(tag: DW_TAG_member, name: "flags2", scope: !590, file: !56, line: 44, baseType: !84, size: 8, offset: 72)
!602 = !DIDerivedType(tag: DW_TAG_member, name: "qcount", scope: !590, file: !56, line: 45, baseType: !85, size: 16, offset: 80)
!603 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !574, file: !56, line: 199, baseType: !328, size: 64, offset: 192)
!604 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !574, file: !56, line: 200, baseType: !333, size: 64, offset: 256)
!605 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !574, file: !56, line: 201, baseType: !450, size: 64, offset: 320)
!606 = !DIGlobalVariableExpression(var: !607, expr: !DIExpression())
!607 = distinct !DIGlobalVariable(name: "cilium_lb6_backends_v3", scope: !2, file: !56, line: 215, type: !608, isLocal: false, isDefinition: true)
!608 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 208, size: 384, elements: !609)
!609 = !{!610, !611, !612, !623, !624, !625}
!610 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !608, file: !56, line: 209, baseType: !328, size: 64)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !608, file: !56, line: 210, baseType: !100, size: 64, offset: 64)
!612 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !608, file: !56, line: 211, baseType: !613, size: 64, offset: 128)
!613 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !614, size: 64)
!614 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_backend", file: !56, line: 49, size: 192, elements: !615)
!615 = !{!616, !617, !618, !619, !620, !621, !622}
!616 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !614, file: !56, line: 50, baseType: !160, size: 128)
!617 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !614, file: !56, line: 51, baseType: !92, size: 16, offset: 128)
!618 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !614, file: !56, line: 52, baseType: !84, size: 8, offset: 144)
!619 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !614, file: !56, line: 53, baseType: !84, size: 8, offset: 152)
!620 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !614, file: !56, line: 54, baseType: !85, size: 16, offset: 160)
!621 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !614, file: !56, line: 58, baseType: !84, size: 8, offset: 176)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !614, file: !56, line: 59, baseType: !84, size: 8, offset: 184)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !608, file: !56, line: 212, baseType: !328, size: 64, offset: 192)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !608, file: !56, line: 213, baseType: !333, size: 64, offset: 256)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !608, file: !56, line: 214, baseType: !328, size: 64, offset: 320)
!626 = !DIGlobalVariableExpression(var: !627, expr: !DIExpression())
!627 = distinct !DIGlobalVariable(name: "cilium_lb6_affinity", scope: !2, file: !56, line: 224, type: !628, isLocal: false, isDefinition: true)
!628 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 217, size: 384, elements: !629)
!629 = !{!630, !631, !646, !653, !654, !655}
!630 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !628, file: !56, line: 218, baseType: !344, size: 64)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !628, file: !56, line: 219, baseType: !632, size: 64, offset: 64)
!632 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !633, size: 64)
!633 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_affinity_key", file: !56, line: 144, size: 192, elements: !634)
!634 = !{!635, !641, !642, !643, !644, !645}
!635 = !DIDerivedType(tag: DW_TAG_member, name: "client_id", scope: !633, file: !56, line: 145, baseType: !636, size: 128)
!636 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "lb6_affinity_client_id", file: !56, line: 139, size: 128, elements: !637)
!637 = !{!638, !639}
!638 = !DIDerivedType(tag: DW_TAG_member, name: "client_ip", scope: !636, file: !56, line: 140, baseType: !160, size: 128)
!639 = !DIDerivedType(tag: DW_TAG_member, name: "client_cookie", scope: !636, file: !56, line: 141, baseType: !640, size: 64)
!640 = !DIDerivedType(tag: DW_TAG_typedef, name: "__net_cookie", file: !83, line: 32, baseType: !95)
!641 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !633, file: !56, line: 146, baseType: !85, size: 16, offset: 128)
!642 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !633, file: !56, line: 147, baseType: !84, size: 1, offset: 144, flags: DIFlagBitField, extraData: i64 144)
!643 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !633, file: !56, line: 148, baseType: !84, size: 7, offset: 145, flags: DIFlagBitField, extraData: i64 144)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !633, file: !56, line: 149, baseType: !84, size: 8, offset: 152)
!645 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !633, file: !56, line: 150, baseType: !82, size: 32, offset: 160)
!646 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !628, file: !56, line: 220, baseType: !647, size: 64, offset: 128)
!647 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !648, size: 64)
!648 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_affinity_val", file: !56, line: 153, size: 128, elements: !649)
!649 = !{!650, !651, !652}
!650 = !DIDerivedType(tag: DW_TAG_member, name: "last_used", scope: !648, file: !56, line: 154, baseType: !95, size: 64)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !648, file: !56, line: 155, baseType: !82, size: 32, offset: 64)
!652 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !648, file: !56, line: 156, baseType: !82, size: 32, offset: 96)
!653 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !628, file: !56, line: 221, baseType: !328, size: 64, offset: 192)
!654 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !628, file: !56, line: 222, baseType: !333, size: 64, offset: 256)
!655 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !628, file: !56, line: 223, baseType: !370, size: 64, offset: 320)
!656 = !DIGlobalVariableExpression(var: !657, expr: !DIExpression())
!657 = distinct !DIGlobalVariable(name: "cilium_lb6_source_range", scope: !2, file: !56, line: 233, type: !658, isLocal: false, isDefinition: true)
!658 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 226, size: 384, elements: !659)
!659 = !{!660, !661, !669, !670, !671, !676}
!660 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !658, file: !56, line: 227, baseType: !459, size: 64)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !658, file: !56, line: 228, baseType: !662, size: 64, offset: 64)
!662 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !663, size: 64)
!663 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_src_range_key", file: !56, line: 175, size: 192, elements: !664)
!664 = !{!665, !666, !667, !668}
!665 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !663, file: !56, line: 176, baseType: !466, size: 32)
!666 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !663, file: !56, line: 177, baseType: !85, size: 16, offset: 32)
!667 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !663, file: !56, line: 178, baseType: !85, size: 16, offset: 48)
!668 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !663, file: !56, line: 179, baseType: !160, size: 128, offset: 64)
!669 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !658, file: !56, line: 229, baseType: !97, size: 64, offset: 128)
!670 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !658, file: !56, line: 230, baseType: !328, size: 64, offset: 192)
!671 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !658, file: !56, line: 231, baseType: !672, size: 64, offset: 256)
!672 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !673, size: 64)
!673 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32000, elements: !674)
!674 = !{!675}
!675 = !DISubrange(count: 1000)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !658, file: !56, line: 232, baseType: !450, size: 64, offset: 320)
!677 = !DIGlobalVariableExpression(var: !678, expr: !DIExpression())
!678 = distinct !DIGlobalVariable(name: "cilium_lb6_health", scope: !2, file: !56, line: 242, type: !679, isLocal: false, isDefinition: true)
!679 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 235, size: 384, elements: !680)
!680 = !{!681, !682, !685, !690, !691, !692}
!681 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !679, file: !56, line: 236, baseType: !344, size: 64)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !679, file: !56, line: 237, baseType: !683, size: 64, offset: 64)
!683 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !684, size: 64)
!684 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sock_cookie", file: !83, line: 33, baseType: !95)
!685 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !679, file: !56, line: 238, baseType: !686, size: 64, offset: 128)
!686 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !687, size: 64)
!687 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_health", file: !56, line: 62, size: 192, elements: !688)
!688 = !{!689}
!689 = !DIDerivedType(tag: DW_TAG_member, name: "peer", scope: !687, file: !56, line: 63, baseType: !614, size: 192)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !679, file: !56, line: 239, baseType: !328, size: 64, offset: 192)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !679, file: !56, line: 240, baseType: !333, size: 64, offset: 256)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !679, file: !56, line: 241, baseType: !370, size: 64, offset: 320)
!693 = !DIGlobalVariableExpression(var: !694, expr: !DIExpression())
!694 = distinct !DIGlobalVariable(name: "cilium_lb6_maglev", scope: !2, file: !56, line: 259, type: !695, isLocal: false, isDefinition: true)
!695 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 245, size: 384, elements: !696)
!696 = !{!697, !700, !701, !702, !703, !704, !705}
!697 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !695, file: !56, line: 246, baseType: !698, size: 64)
!698 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !699, size: 64)
!699 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 416, elements: !112)
!700 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !695, file: !56, line: 247, baseType: !99, size: 64, offset: 64)
!701 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !695, file: !56, line: 248, baseType: !100, size: 64, offset: 128)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !695, file: !56, line: 249, baseType: !328, size: 64, offset: 192)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !695, file: !56, line: 250, baseType: !333, size: 64, offset: 256)
!704 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !695, file: !56, line: 251, baseType: !450, size: 64, offset: 320)
!705 = !DIDerivedType(tag: DW_TAG_member, name: "values", scope: !695, file: !56, line: 253, baseType: !706, offset: 384)
!706 = !DICompositeType(tag: DW_TAG_array_type, baseType: !707, elements: !722)
!707 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !708, size: 64)
!708 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !695, file: !56, line: 253, size: 256, elements: !709)
!709 = !{!710, !713, !716, !721}
!710 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !708, file: !56, line: 253, baseType: !711, size: 64)
!711 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !712, size: 64)
!712 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 64, elements: !445)
!713 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !708, file: !56, line: 253, baseType: !714, size: 64, offset: 64)
!714 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !715, size: 64)
!715 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 128, elements: !150)
!716 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !708, file: !56, line: 253, baseType: !717, size: 64, offset: 128)
!717 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !718, size: 64)
!718 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 4191872, elements: !719)
!719 = !{!720}
!720 = !DISubrange(count: 130996)
!721 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !708, file: !56, line: 253, baseType: !328, size: 64, offset: 192)
!722 = !{!723}
!723 = !DISubrange(count: -1)
!724 = !DIGlobalVariableExpression(var: !725, expr: !DIExpression())
!725 = distinct !DIGlobalVariable(name: "cilium_lb4_reverse_nat", scope: !2, file: !56, line: 273, type: !726, isLocal: false, isDefinition: true)
!726 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 266, size: 384, elements: !727)
!727 = !{!728, !729, !730, !736, !737, !738}
!728 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !726, file: !56, line: 267, baseType: !328, size: 64)
!729 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !726, file: !56, line: 268, baseType: !99, size: 64, offset: 64)
!730 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !726, file: !56, line: 269, baseType: !731, size: 64, offset: 128)
!731 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !732, size: 64)
!732 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_reverse_nat", file: !12, line: 415, size: 48, elements: !733)
!733 = !{!734, !735}
!734 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !732, file: !12, line: 416, baseType: !153, size: 32)
!735 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !732, file: !12, line: 417, baseType: !92, size: 16, offset: 32)
!736 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !726, file: !56, line: 270, baseType: !328, size: 64, offset: 192)
!737 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !726, file: !56, line: 271, baseType: !333, size: 64, offset: 256)
!738 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !726, file: !56, line: 272, baseType: !328, size: 64, offset: 320)
!739 = !DIGlobalVariableExpression(var: !740, expr: !DIExpression())
!740 = distinct !DIGlobalVariable(name: "cilium_lb4_services_v2", scope: !2, file: !56, line: 282, type: !741, isLocal: false, isDefinition: true)
!741 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 275, size: 384, elements: !742)
!742 = !{!743, !744, !754, !769, !770, !771}
!743 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !741, file: !56, line: 276, baseType: !328, size: 64)
!744 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !741, file: !56, line: 277, baseType: !745, size: 64, offset: 64)
!745 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !746, size: 64)
!746 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_key", file: !56, line: 66, size: 96, elements: !747)
!747 = !{!748, !749, !750, !751, !752, !753}
!748 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !746, file: !56, line: 67, baseType: !153, size: 32)
!749 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !746, file: !56, line: 68, baseType: !92, size: 16, offset: 32)
!750 = !DIDerivedType(tag: DW_TAG_member, name: "backend_slot", scope: !746, file: !56, line: 69, baseType: !85, size: 16, offset: 48)
!751 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !746, file: !56, line: 70, baseType: !84, size: 8, offset: 64)
!752 = !DIDerivedType(tag: DW_TAG_member, name: "scope", scope: !746, file: !56, line: 71, baseType: !84, size: 8, offset: 72)
!753 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !746, file: !56, line: 72, baseType: !587, size: 16, offset: 80)
!754 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !741, file: !56, line: 278, baseType: !755, size: 64, offset: 128)
!755 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !756, size: 64)
!756 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_service", file: !56, line: 75, size: 96, elements: !757)
!757 = !{!758, !764, !765, !766, !767, !768}
!758 = !DIDerivedType(tag: DW_TAG_member, scope: !756, file: !56, line: 76, baseType: !759, size: 32)
!759 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !756, file: !56, line: 76, size: 32, elements: !760)
!760 = !{!761, !762, !763}
!761 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !759, file: !56, line: 78, baseType: !82, size: 32)
!762 = !DIDerivedType(tag: DW_TAG_member, name: "affinity_timeout", scope: !759, file: !56, line: 89, baseType: !82, size: 32)
!763 = !DIDerivedType(tag: DW_TAG_member, name: "l7_lb_proxy_port", scope: !759, file: !56, line: 93, baseType: !82, size: 32)
!764 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !756, file: !56, line: 98, baseType: !85, size: 16, offset: 32)
!765 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !756, file: !56, line: 99, baseType: !85, size: 16, offset: 48)
!766 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !756, file: !56, line: 100, baseType: !84, size: 8, offset: 64)
!767 = !DIDerivedType(tag: DW_TAG_member, name: "flags2", scope: !756, file: !56, line: 101, baseType: !84, size: 8, offset: 72)
!768 = !DIDerivedType(tag: DW_TAG_member, name: "qcount", scope: !756, file: !56, line: 105, baseType: !85, size: 16, offset: 80)
!769 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !741, file: !56, line: 279, baseType: !328, size: 64, offset: 192)
!770 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !741, file: !56, line: 280, baseType: !333, size: 64, offset: 256)
!771 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !741, file: !56, line: 281, baseType: !450, size: 64, offset: 320)
!772 = !DIGlobalVariableExpression(var: !773, expr: !DIExpression())
!773 = distinct !DIGlobalVariable(name: "cilium_lb4_backends_v3", scope: !2, file: !56, line: 295, type: !774, isLocal: false, isDefinition: true)
!774 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 288, size: 384, elements: !775)
!775 = !{!776, !777, !778, !789, !790, !791}
!776 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !774, file: !56, line: 289, baseType: !328, size: 64)
!777 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !774, file: !56, line: 290, baseType: !100, size: 64, offset: 64)
!778 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !774, file: !56, line: 291, baseType: !779, size: 64, offset: 128)
!779 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !780, size: 64)
!780 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_backend", file: !56, line: 108, size: 96, elements: !781)
!781 = !{!782, !783, !784, !785, !786, !787, !788}
!782 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !780, file: !56, line: 109, baseType: !153, size: 32)
!783 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !780, file: !56, line: 110, baseType: !92, size: 16, offset: 32)
!784 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !780, file: !56, line: 111, baseType: !84, size: 8, offset: 48)
!785 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !780, file: !56, line: 112, baseType: !84, size: 8, offset: 56)
!786 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !780, file: !56, line: 113, baseType: !85, size: 16, offset: 64)
!787 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !780, file: !56, line: 117, baseType: !84, size: 8, offset: 80)
!788 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !780, file: !56, line: 118, baseType: !84, size: 8, offset: 88)
!789 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !774, file: !56, line: 292, baseType: !328, size: 64, offset: 192)
!790 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !774, file: !56, line: 293, baseType: !333, size: 64, offset: 256)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !774, file: !56, line: 294, baseType: !328, size: 64, offset: 320)
!792 = !DIGlobalVariableExpression(var: !793, expr: !DIExpression())
!793 = distinct !DIGlobalVariable(name: "cilium_lb4_affinity", scope: !2, file: !56, line: 304, type: !794, isLocal: false, isDefinition: true)
!794 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 297, size: 384, elements: !795)
!795 = !{!796, !797, !811, !812, !813, !814}
!796 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !794, file: !56, line: 298, baseType: !344, size: 64)
!797 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !794, file: !56, line: 299, baseType: !798, size: 64, offset: 64)
!798 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !799, size: 64)
!799 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_affinity_key", file: !56, line: 130, size: 128, elements: !800)
!800 = !{!801, !806, !807, !808, !809, !810}
!801 = !DIDerivedType(tag: DW_TAG_member, name: "client_id", scope: !799, file: !56, line: 131, baseType: !802, size: 64)
!802 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "lb4_affinity_client_id", file: !56, line: 125, size: 64, elements: !803)
!803 = !{!804, !805}
!804 = !DIDerivedType(tag: DW_TAG_member, name: "client_ip", scope: !802, file: !56, line: 126, baseType: !82, size: 32)
!805 = !DIDerivedType(tag: DW_TAG_member, name: "client_cookie", scope: !802, file: !56, line: 127, baseType: !640, size: 64)
!806 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !799, file: !56, line: 132, baseType: !85, size: 16, offset: 64)
!807 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !799, file: !56, line: 133, baseType: !84, size: 1, offset: 80, flags: DIFlagBitField, extraData: i64 80)
!808 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !799, file: !56, line: 134, baseType: !84, size: 7, offset: 81, flags: DIFlagBitField, extraData: i64 80)
!809 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !799, file: !56, line: 135, baseType: !84, size: 8, offset: 88)
!810 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !799, file: !56, line: 136, baseType: !82, size: 32, offset: 96)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !794, file: !56, line: 300, baseType: !647, size: 64, offset: 128)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !794, file: !56, line: 301, baseType: !328, size: 64, offset: 192)
!813 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !794, file: !56, line: 302, baseType: !333, size: 64, offset: 256)
!814 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !794, file: !56, line: 303, baseType: !370, size: 64, offset: 320)
!815 = !DIGlobalVariableExpression(var: !816, expr: !DIExpression())
!816 = distinct !DIGlobalVariable(name: "cilium_lb4_source_range", scope: !2, file: !56, line: 313, type: !817, isLocal: false, isDefinition: true)
!817 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 306, size: 384, elements: !818)
!818 = !{!819, !820, !828, !829, !830, !831}
!819 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !817, file: !56, line: 307, baseType: !459, size: 64)
!820 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !817, file: !56, line: 308, baseType: !821, size: 64, offset: 64)
!821 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !822, size: 64)
!822 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_src_range_key", file: !56, line: 168, size: 96, elements: !823)
!823 = !{!824, !825, !826, !827}
!824 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !822, file: !56, line: 169, baseType: !466, size: 32)
!825 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !822, file: !56, line: 170, baseType: !85, size: 16, offset: 32)
!826 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !822, file: !56, line: 171, baseType: !85, size: 16, offset: 48)
!827 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !822, file: !56, line: 172, baseType: !82, size: 32, offset: 64)
!828 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !817, file: !56, line: 309, baseType: !97, size: 64, offset: 128)
!829 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !817, file: !56, line: 310, baseType: !328, size: 64, offset: 192)
!830 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !817, file: !56, line: 311, baseType: !672, size: 64, offset: 256)
!831 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !817, file: !56, line: 312, baseType: !450, size: 64, offset: 320)
!832 = !DIGlobalVariableExpression(var: !833, expr: !DIExpression())
!833 = distinct !DIGlobalVariable(name: "cilium_lb4_health", scope: !2, file: !56, line: 322, type: !834, isLocal: false, isDefinition: true)
!834 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 315, size: 384, elements: !835)
!835 = !{!836, !837, !838, !843, !844, !845}
!836 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !834, file: !56, line: 316, baseType: !344, size: 64)
!837 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !834, file: !56, line: 317, baseType: !683, size: 64, offset: 64)
!838 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !834, file: !56, line: 318, baseType: !839, size: 64, offset: 128)
!839 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !840, size: 64)
!840 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_health", file: !56, line: 121, size: 96, elements: !841)
!841 = !{!842}
!842 = !DIDerivedType(tag: DW_TAG_member, name: "peer", scope: !840, file: !56, line: 122, baseType: !780, size: 96)
!843 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !834, file: !56, line: 319, baseType: !328, size: 64, offset: 192)
!844 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !834, file: !56, line: 320, baseType: !333, size: 64, offset: 256)
!845 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !834, file: !56, line: 321, baseType: !370, size: 64, offset: 320)
!846 = !DIGlobalVariableExpression(var: !847, expr: !DIExpression())
!847 = distinct !DIGlobalVariable(name: "cilium_lb4_maglev", scope: !2, file: !56, line: 339, type: !848, isLocal: false, isDefinition: true)
!848 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 325, size: 384, elements: !849)
!849 = !{!850, !851, !852, !853, !854, !855, !856}
!850 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !848, file: !56, line: 326, baseType: !698, size: 64)
!851 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !848, file: !56, line: 327, baseType: !99, size: 64, offset: 64)
!852 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !848, file: !56, line: 328, baseType: !100, size: 64, offset: 128)
!853 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !848, file: !56, line: 329, baseType: !328, size: 64, offset: 192)
!854 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !848, file: !56, line: 330, baseType: !333, size: 64, offset: 256)
!855 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !848, file: !56, line: 331, baseType: !450, size: 64, offset: 320)
!856 = !DIDerivedType(tag: DW_TAG_member, name: "values", scope: !848, file: !56, line: 333, baseType: !857, offset: 384)
!857 = !DICompositeType(tag: DW_TAG_array_type, baseType: !858, elements: !722)
!858 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !859, size: 64)
!859 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !848, file: !56, line: 333, size: 256, elements: !860)
!860 = !{!861, !862, !863, !864}
!861 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !859, file: !56, line: 333, baseType: !711, size: 64)
!862 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !859, file: !56, line: 333, baseType: !714, size: 64, offset: 64)
!863 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !859, file: !56, line: 333, baseType: !717, size: 64, offset: 128)
!864 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !859, file: !56, line: 333, baseType: !328, size: 64, offset: 192)
!865 = !DIGlobalVariableExpression(var: !866, expr: !DIExpression())
!866 = distinct !DIGlobalVariable(name: "cilium_lb_affinity_match", scope: !2, file: !56, line: 349, type: !867, isLocal: false, isDefinition: true)
!867 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 342, size: 384, elements: !868)
!868 = !{!869, !870, !877, !878, !879, !880}
!869 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !867, file: !56, line: 343, baseType: !328, size: 64)
!870 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !867, file: !56, line: 344, baseType: !871, size: 64, offset: 64)
!871 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !872, size: 64)
!872 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_affinity_match", file: !56, line: 159, size: 64, elements: !873)
!873 = !{!874, !875, !876}
!874 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !872, file: !56, line: 160, baseType: !82, size: 32)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !872, file: !56, line: 161, baseType: !85, size: 16, offset: 32)
!876 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !872, file: !56, line: 162, baseType: !85, size: 16, offset: 48)
!877 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !867, file: !56, line: 345, baseType: !97, size: 64, offset: 128)
!878 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !867, file: !56, line: 346, baseType: !328, size: 64, offset: 192)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !867, file: !56, line: 347, baseType: !333, size: 64, offset: 256)
!880 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !867, file: !56, line: 348, baseType: !450, size: 64, offset: 320)
!881 = !DIGlobalVariableExpression(var: !882, expr: !DIExpression())
!882 = distinct !DIGlobalVariable(name: "cilium_lb_act", scope: !2, file: !883, line: 28, type: !884, isLocal: false, isDefinition: true)
!883 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/act.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "fedf61bdb03fde76463add1b3bc5404c")
!884 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !883, line: 21, size: 384, elements: !885)
!885 = !{!886, !887, !894, !900, !901, !902}
!886 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !884, file: !883, line: 22, baseType: !344, size: 64)
!887 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !884, file: !883, line: 23, baseType: !888, size: 64, offset: 64)
!888 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !889, size: 64)
!889 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_act_key", file: !883, line: 10, size: 32, elements: !890)
!890 = !{!891, !892, !893}
!891 = !DIDerivedType(tag: DW_TAG_member, name: "svc_id", scope: !889, file: !883, line: 11, baseType: !85, size: 16)
!892 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !889, file: !883, line: 12, baseType: !84, size: 8, offset: 16)
!893 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !889, file: !883, line: 13, baseType: !84, size: 8, offset: 24)
!894 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !884, file: !883, line: 24, baseType: !895, size: 64, offset: 128)
!895 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !896, size: 64)
!896 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_act_value", file: !883, line: 16, size: 64, elements: !897)
!897 = !{!898, !899}
!898 = !DIDerivedType(tag: DW_TAG_member, name: "opened", scope: !896, file: !883, line: 17, baseType: !82, size: 32)
!899 = !DIDerivedType(tag: DW_TAG_member, name: "closed", scope: !896, file: !883, line: 18, baseType: !82, size: 32, offset: 32)
!900 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !884, file: !883, line: 25, baseType: !328, size: 64, offset: 192)
!901 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !884, file: !883, line: 26, baseType: !333, size: 64, offset: 256)
!902 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !884, file: !883, line: 27, baseType: !370, size: 64, offset: 320)
!903 = !DIGlobalVariableExpression(var: !904, expr: !DIExpression())
!904 = distinct !DIGlobalVariable(name: "cilium_skip_lb6", scope: !2, file: !905, line: 28, type: !906, isLocal: false, isDefinition: true)
!905 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/lrp.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "03dbfb650c93a58cdb7545f6c98dd875")
!906 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !905, line: 21, size: 384, elements: !907)
!907 = !{!908, !909, !918, !919, !920, !925}
!908 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !906, file: !905, line: 22, baseType: !328, size: 64)
!909 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !906, file: !905, line: 23, baseType: !910, size: 64, offset: 64)
!910 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !911, size: 64)
!911 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "skip_lb6_key", file: !905, line: 13, size: 256, elements: !912)
!912 = !{!913, !914, !915, !916, !917}
!913 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !911, file: !905, line: 14, baseType: !95, size: 64)
!914 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !911, file: !905, line: 15, baseType: !160, size: 128, offset: 64)
!915 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !911, file: !905, line: 16, baseType: !82, size: 32, offset: 192)
!916 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !911, file: !905, line: 17, baseType: !85, size: 16, offset: 224)
!917 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !911, file: !905, line: 18, baseType: !85, size: 16, offset: 240)
!918 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !906, file: !905, line: 24, baseType: !97, size: 64, offset: 128)
!919 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !906, file: !905, line: 25, baseType: !328, size: 64, offset: 192)
!920 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !906, file: !905, line: 26, baseType: !921, size: 64, offset: 256)
!921 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !922, size: 64)
!922 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 3200, elements: !923)
!923 = !{!924}
!924 = !DISubrange(count: 100)
!925 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !906, file: !905, line: 27, baseType: !450, size: 64, offset: 320)
!926 = !DIGlobalVariableExpression(var: !927, expr: !DIExpression())
!927 = distinct !DIGlobalVariable(name: "cilium_skip_lb4", scope: !2, file: !905, line: 37, type: !928, isLocal: false, isDefinition: true)
!928 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !905, line: 30, size: 384, elements: !929)
!929 = !{!930, !931, !939, !940, !941, !942}
!930 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !928, file: !905, line: 31, baseType: !328, size: 64)
!931 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !928, file: !905, line: 32, baseType: !932, size: 64, offset: 64)
!932 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !933, size: 64)
!933 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "skip_lb4_key", file: !905, line: 6, size: 128, elements: !934)
!934 = !{!935, !936, !937, !938}
!935 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !933, file: !905, line: 7, baseType: !95, size: 64)
!936 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !933, file: !905, line: 8, baseType: !82, size: 32, offset: 64)
!937 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !933, file: !905, line: 9, baseType: !85, size: 16, offset: 96)
!938 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !933, file: !905, line: 10, baseType: !85, size: 16, offset: 112)
!939 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !928, file: !905, line: 33, baseType: !97, size: 64, offset: 128)
!940 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !928, file: !905, line: 34, baseType: !328, size: 64, offset: 192)
!941 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !928, file: !905, line: 35, baseType: !921, size: 64, offset: 256)
!942 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !928, file: !905, line: 36, baseType: !450, size: 64, offset: 320)
!943 = !DIGlobalVariableExpression(var: !944, expr: !DIExpression())
!944 = distinct !DIGlobalVariable(name: "__config_enable_lrp", scope: !2, file: !905, line: 39, type: !88, isLocal: false, isDefinition: true, annotations: !945)
!945 = !{!277, !946}
!946 = !{!"btf_decl_tag", !"Enable support for Local Redirect Policy"}
!947 = !DIGlobalVariableExpression(var: !948, expr: !DIExpression())
!948 = distinct !DIGlobalVariable(name: "cilium_lb4_reverse_sk", scope: !2, file: !949, line: 42, type: !950, isLocal: false, isDefinition: true)
!949 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "ae3d583b4ce8be357b1cbf765842c908")
!950 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !949, line: 35, size: 384, elements: !951)
!951 = !{!952, !953, !961, !968, !969, !974}
!952 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !950, file: !949, line: 36, baseType: !344, size: 64)
!953 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !950, file: !949, line: 37, baseType: !954, size: 64, offset: 64)
!954 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !955, size: 64)
!955 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_revnat_tuple", file: !949, line: 22, size: 128, elements: !956)
!956 = !{!957, !958, !959, !960}
!957 = !DIDerivedType(tag: DW_TAG_member, name: "cookie", scope: !955, file: !949, line: 23, baseType: !684, size: 64)
!958 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !955, file: !949, line: 24, baseType: !153, size: 32, offset: 64)
!959 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !955, file: !949, line: 25, baseType: !92, size: 16, offset: 96)
!960 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !955, file: !949, line: 26, baseType: !85, size: 16, offset: 112)
!961 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !950, file: !949, line: 38, baseType: !962, size: 64, offset: 128)
!962 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !963, size: 64)
!963 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_revnat_entry", file: !949, line: 29, size: 64, elements: !964)
!964 = !{!965, !966, !967}
!965 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !963, file: !949, line: 30, baseType: !153, size: 32)
!966 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !963, file: !949, line: 31, baseType: !92, size: 16, offset: 32)
!967 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !963, file: !949, line: 32, baseType: !85, size: 16, offset: 48)
!968 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !950, file: !949, line: 39, baseType: !328, size: 64, offset: 192)
!969 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !950, file: !949, line: 40, baseType: !970, size: 64, offset: 256)
!970 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !971, size: 64)
!971 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 8388608, elements: !972)
!972 = !{!973}
!973 = !DISubrange(count: 262144)
!974 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !950, file: !949, line: 41, baseType: !370, size: 64, offset: 320)
!975 = !DIGlobalVariableExpression(var: !976, expr: !DIExpression())
!976 = distinct !DIGlobalVariable(name: "cilium_lb6_reverse_sk", scope: !2, file: !949, line: 64, type: !977, isLocal: false, isDefinition: true)
!977 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !949, line: 57, size: 384, elements: !978)
!978 = !{!979, !980, !988, !995, !996, !997}
!979 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !977, file: !949, line: 58, baseType: !344, size: 64)
!980 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !977, file: !949, line: 59, baseType: !981, size: 64, offset: 64)
!981 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !982, size: 64)
!982 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_revnat_tuple", file: !949, line: 44, size: 256, elements: !983)
!983 = !{!984, !985, !986, !987}
!984 = !DIDerivedType(tag: DW_TAG_member, name: "cookie", scope: !982, file: !949, line: 45, baseType: !684, size: 64)
!985 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !982, file: !949, line: 46, baseType: !160, size: 128, offset: 64)
!986 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !982, file: !949, line: 47, baseType: !92, size: 16, offset: 192)
!987 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !982, file: !949, line: 48, baseType: !85, size: 16, offset: 208)
!988 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !977, file: !949, line: 60, baseType: !989, size: 64, offset: 128)
!989 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !990, size: 64)
!990 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_revnat_entry", file: !949, line: 51, size: 160, elements: !991)
!991 = !{!992, !993, !994}
!992 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !990, file: !949, line: 52, baseType: !160, size: 128)
!993 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !990, file: !949, line: 53, baseType: !92, size: 16, offset: 128)
!994 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !990, file: !949, line: 54, baseType: !85, size: 16, offset: 144)
!995 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !977, file: !949, line: 61, baseType: !328, size: 64, offset: 192)
!996 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !977, file: !949, line: 62, baseType: !970, size: 64, offset: 256)
!997 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !977, file: !949, line: 63, baseType: !370, size: 64, offset: 320)
!998 = !DIGlobalVariableExpression(var: !999, expr: !DIExpression())
!999 = distinct !DIGlobalVariable(name: "cilium_events", scope: !2, file: !1000, line: 13, type: !1001, isLocal: false, isDefinition: true)
!1000 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/events.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "61b587317a5ed8647de3686340876e90")
!1001 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1000, line: 8, size: 256, elements: !1002)
!1002 = !{!1003, !1004, !1005, !1006}
!1003 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1001, file: !1000, line: 9, baseType: !714, size: 64)
!1004 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !1001, file: !1000, line: 10, baseType: !714, size: 64, offset: 64)
!1005 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !1001, file: !1000, line: 11, baseType: !714, size: 64, offset: 128)
!1006 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !1001, file: !1000, line: 12, baseType: !328, size: 64, offset: 192)
!1007 = !DIGlobalVariableExpression(var: !1008, expr: !DIExpression(DW_OP_constu, 1, DW_OP_stack_value))
!1008 = distinct !DIGlobalVariable(name: "map_lookup_elem", scope: !2, file: !1009, line: 33, type: !1010, isLocal: true, isDefinition: true)
!1009 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../helpers.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "186086bcd68d0bf51ebf2512e88283a5")
!1010 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1011, size: 64)
!1011 = !DISubroutineType(types: !1012)
!1012 = !{!91, !1013, !1013}
!1013 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1014, size: 64)
!1014 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!1015 = !DIGlobalVariableExpression(var: !1016, expr: !DIExpression(DW_OP_constu, 122, DW_OP_stack_value))
!1016 = distinct !DIGlobalVariable(name: "get_netns_cookie", scope: !2, file: !1009, line: 49, type: !1017, isLocal: true, isDefinition: true)
!1017 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1018, size: 64)
!1018 = !DISubroutineType(types: !1019)
!1019 = !{!640, !91}
!1020 = !DIGlobalVariableExpression(var: !1021, expr: !DIExpression(DW_OP_constu, 118, DW_OP_stack_value))
!1021 = distinct !DIGlobalVariable(name: "jiffies64", scope: !2, file: !1009, line: 45, type: !1022, isLocal: true, isDefinition: true)
!1022 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1023, size: 64)
!1023 = !DISubroutineType(types: !1024)
!1024 = !{!95, null}
!1025 = !DIGlobalVariableExpression(var: !1026, expr: !DIExpression(DW_OP_constu, 5, DW_OP_stack_value))
!1026 = distinct !DIGlobalVariable(name: "ktime_get_ns", scope: !2, file: !1009, line: 43, type: !1022, isLocal: true, isDefinition: true)
!1027 = !DIGlobalVariableExpression(var: !1028, expr: !DIExpression(DW_OP_constu, 3, DW_OP_stack_value))
!1028 = distinct !DIGlobalVariable(name: "map_delete_elem", scope: !2, file: !1009, line: 36, type: !1029, isLocal: true, isDefinition: true)
!1029 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1030, size: 64)
!1030 = !DISubroutineType(types: !1031)
!1031 = !{!305, !1013, !1013}
!1032 = !DIGlobalVariableExpression(var: !1033, expr: !DIExpression(DW_OP_constu, 7, DW_OP_stack_value))
!1033 = distinct !DIGlobalVariable(name: "get_prandom_u32", scope: !2, file: !1009, line: 59, type: !1034, isLocal: true, isDefinition: true)
!1034 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1035, size: 64)
!1035 = !DISubroutineType(types: !1036)
!1036 = !{!82, null}
!1037 = !DIGlobalVariableExpression(var: !1038, expr: !DIExpression(DW_OP_constu, 46, DW_OP_stack_value))
!1038 = distinct !DIGlobalVariable(name: "get_socket_cookie", scope: !2, file: !1009, line: 48, type: !1039, isLocal: true, isDefinition: true)
!1039 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1040, size: 64)
!1040 = !DISubroutineType(types: !1041)
!1041 = !{!684, !91}
!1042 = !DIGlobalVariableExpression(var: !1043, expr: !DIExpression(DW_OP_constu, 2, DW_OP_stack_value))
!1043 = distinct !DIGlobalVariable(name: "map_update_elem", scope: !2, file: !1009, line: 34, type: !1044, isLocal: true, isDefinition: true)
!1044 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1045, size: 64)
!1045 = !DISubroutineType(types: !1046)
!1046 = !{!305, !1013, !1013, !1013, !82}
!1047 = !DIGlobalVariableExpression(var: !1048, expr: !DIExpression())
!1048 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 36, type: !105, isLocal: true, isDefinition: true)
!1049 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/source_info.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "527298247430c74ca5c56b703daf641a")
!1050 = !DIGlobalVariableExpression(var: !1051, expr: !DIExpression())
!1051 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 37, type: !1052, isLocal: true, isDefinition: true)
!1052 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 80, elements: !1053)
!1053 = !{!1054}
!1054 = !DISubrange(count: 10)
!1055 = !DIGlobalVariableExpression(var: !1056, expr: !DIExpression())
!1056 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 38, type: !1057, isLocal: true, isDefinition: true)
!1057 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 112, elements: !1058)
!1058 = !{!1059}
!1059 = !DISubrange(count: 14)
!1060 = !DIGlobalVariableExpression(var: !1061, expr: !DIExpression())
!1061 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 39, type: !1052, isLocal: true, isDefinition: true)
!1062 = !DIGlobalVariableExpression(var: !1063, expr: !DIExpression())
!1063 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 42, type: !1064, isLocal: true, isDefinition: true)
!1064 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 128, elements: !165)
!1065 = !DIGlobalVariableExpression(var: !1066, expr: !DIExpression())
!1066 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 45, type: !1067, isLocal: true, isDefinition: true)
!1067 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 56, elements: !1068)
!1068 = !{!1069}
!1069 = !DISubrange(count: 7)
!1070 = !DIGlobalVariableExpression(var: !1071, expr: !DIExpression())
!1071 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 46, type: !1067, isLocal: true, isDefinition: true)
!1072 = !DIGlobalVariableExpression(var: !1073, expr: !DIExpression())
!1073 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 47, type: !1074, isLocal: true, isDefinition: true)
!1074 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 64, elements: !1075)
!1075 = !{!1076}
!1076 = !DISubrange(count: 8)
!1077 = !DIGlobalVariableExpression(var: !1078, expr: !DIExpression())
!1078 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 48, type: !105, isLocal: true, isDefinition: true)
!1079 = !DIGlobalVariableExpression(var: !1080, expr: !DIExpression())
!1080 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 49, type: !1081, isLocal: true, isDefinition: true)
!1081 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 40, elements: !306)
!1082 = !DIGlobalVariableExpression(var: !1083, expr: !DIExpression())
!1083 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 50, type: !1074, isLocal: true, isDefinition: true)
!1084 = !DIGlobalVariableExpression(var: !1085, expr: !DIExpression())
!1085 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 51, type: !1067, isLocal: true, isDefinition: true)
!1086 = !DIGlobalVariableExpression(var: !1087, expr: !DIExpression())
!1087 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 52, type: !1088, isLocal: true, isDefinition: true)
!1088 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 96, elements: !1089)
!1089 = !{!1090}
!1090 = !DISubrange(count: 12)
!1091 = !DIGlobalVariableExpression(var: !1092, expr: !DIExpression())
!1092 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 53, type: !1093, isLocal: true, isDefinition: true)
!1093 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 136, elements: !1094)
!1094 = !{!1095}
!1095 = !DISubrange(count: 17)
!1096 = !DIGlobalVariableExpression(var: !1097, expr: !DIExpression())
!1097 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 54, type: !1074, isLocal: true, isDefinition: true)
!1098 = !DIGlobalVariableExpression(var: !1099, expr: !DIExpression())
!1099 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 55, type: !1074, isLocal: true, isDefinition: true)
!1100 = !DIGlobalVariableExpression(var: !1101, expr: !DIExpression())
!1101 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 56, type: !1064, isLocal: true, isDefinition: true)
!1102 = !DIGlobalVariableExpression(var: !1103, expr: !DIExpression())
!1103 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 57, type: !1104, isLocal: true, isDefinition: true)
!1104 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 144, elements: !1105)
!1105 = !{!1106}
!1106 = !DISubrange(count: 18)
!1107 = !DIGlobalVariableExpression(var: !1108, expr: !DIExpression())
!1108 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 58, type: !1067, isLocal: true, isDefinition: true)
!1109 = !DIGlobalVariableExpression(var: !1110, expr: !DIExpression())
!1110 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 59, type: !1057, isLocal: true, isDefinition: true)
!1111 = !{!118, !1112}
!1112 = !{!"btf_decl_tag", !"Number of bits of the identity reserved for the Cluster ID"}
!1113 = !{i32 7, !"Dwarf Version", i32 5}
!1114 = !{i32 2, !"Debug Info Version", i32 3}
!1115 = !{i32 1, !"wchar_size", i32 4}
!1116 = !{i32 7, !"frame-pointer", i32 2}
!1117 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!1118 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!1119 = distinct !DISubprogram(name: "__check_cluster_id_bits", scope: !116, file: !116, line: 57, type: !1120, scopeLine: 57, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1122)
!1120 = !DISubroutineType(types: !1121)
!1121 = !{null}
!1122 = !{!1123}
!1123 = !DILocalVariable(name: "out", scope: !1124, file: !116, line: 57, type: !91)
!1124 = distinct !DILexicalBlock(scope: !1119, file: !116, line: 57, column: 1)
!1125 = !DILocation(line: 57, column: 1, scope: !1124)
!1126 = !{i64 2148005493}
!1127 = !DILocation(line: 0, scope: !1124)
!1128 = !DILocation(line: 57, column: 1, scope: !1119)
!1129 = !{!1130, !1130, i64 0}
!1130 = !{!"int", !1131, i64 0}
!1131 = !{!"omnipotent char", !1132, i64 0}
!1132 = !{!"Simple C/C++ TBAA"}
!1133 = distinct !DISubprogram(name: "cil_sock4_connect", scope: !104, file: !104, line: 459, type: !1134, scopeLine: 460, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1171)
!1134 = !DISubroutineType(types: !1135)
!1135 = !{!305, !1136}
!1136 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1137, size: 64)
!1137 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock_addr", file: !467, line: 6567, size: 576, elements: !1138)
!1138 = !{!1139, !1140, !1141, !1143, !1144, !1145, !1146, !1147, !1148, !1149}
!1139 = !DIDerivedType(tag: DW_TAG_member, name: "user_family", scope: !1137, file: !467, line: 6568, baseType: !82, size: 32)
!1140 = !DIDerivedType(tag: DW_TAG_member, name: "user_ip4", scope: !1137, file: !467, line: 6569, baseType: !82, size: 32, offset: 32)
!1141 = !DIDerivedType(tag: DW_TAG_member, name: "user_ip6", scope: !1137, file: !467, line: 6572, baseType: !1142, size: 128, offset: 64)
!1142 = !DICompositeType(tag: DW_TAG_array_type, baseType: !82, size: 128, elements: !150)
!1143 = !DIDerivedType(tag: DW_TAG_member, name: "user_port", scope: !1137, file: !467, line: 6575, baseType: !82, size: 32, offset: 192)
!1144 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !1137, file: !467, line: 6578, baseType: !82, size: 32, offset: 224)
!1145 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1137, file: !467, line: 6579, baseType: !82, size: 32, offset: 256)
!1146 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !1137, file: !467, line: 6580, baseType: !82, size: 32, offset: 288)
!1147 = !DIDerivedType(tag: DW_TAG_member, name: "msg_src_ip4", scope: !1137, file: !467, line: 6581, baseType: !82, size: 32, offset: 320)
!1148 = !DIDerivedType(tag: DW_TAG_member, name: "msg_src_ip6", scope: !1137, file: !467, line: 6584, baseType: !1142, size: 128, offset: 352)
!1149 = !DIDerivedType(tag: DW_TAG_member, scope: !1137, file: !467, line: 6587, baseType: !1150, size: 64, align: 64, offset: 512)
!1150 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !1137, file: !467, line: 6587, size: 64, align: 64, elements: !1151)
!1151 = !{!1152}
!1152 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !1150, file: !467, line: 6587, baseType: !1153, size: 64)
!1153 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1154, size: 64)
!1154 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !467, line: 6180, size: 640, elements: !1155)
!1155 = !{!1156, !1157, !1158, !1159, !1160, !1161, !1162, !1163, !1164, !1165, !1166, !1167, !1168, !1169}
!1156 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !1154, file: !467, line: 6181, baseType: !82, size: 32)
!1157 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !1154, file: !467, line: 6182, baseType: !82, size: 32, offset: 32)
!1158 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1154, file: !467, line: 6183, baseType: !82, size: 32, offset: 64)
!1159 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !1154, file: !467, line: 6184, baseType: !82, size: 32, offset: 96)
!1160 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !1154, file: !467, line: 6185, baseType: !82, size: 32, offset: 128)
!1161 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !1154, file: !467, line: 6186, baseType: !82, size: 32, offset: 160)
!1162 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !1154, file: !467, line: 6188, baseType: !82, size: 32, offset: 192)
!1163 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !1154, file: !467, line: 6189, baseType: !1142, size: 128, offset: 224)
!1164 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !1154, file: !467, line: 6190, baseType: !82, size: 32, offset: 352)
!1165 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !1154, file: !467, line: 6191, baseType: !92, size: 16, offset: 384)
!1166 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !1154, file: !467, line: 6193, baseType: !82, size: 32, offset: 416)
!1167 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !1154, file: !467, line: 6194, baseType: !1142, size: 128, offset: 448)
!1168 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !1154, file: !467, line: 6195, baseType: !82, size: 32, offset: 576)
!1169 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !1154, file: !467, line: 6196, baseType: !1170, size: 32, offset: 608)
!1170 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !83, line: 12, baseType: !305)
!1171 = !{!1172, !1173}
!1172 = !DILocalVariable(name: "ctx", arg: 1, scope: !1133, file: !104, line: 459, type: !1136)
!1173 = !DILocalVariable(name: "err", scope: !1133, file: !104, line: 461, type: !305)
!1174 = distinct !DIAssignID()
!1175 = distinct !DIAssignID()
!1176 = distinct !DIAssignID()
!1177 = distinct !DIAssignID()
!1178 = distinct !DIAssignID()
!1179 = distinct !DIAssignID()
!1180 = distinct !DIAssignID()
!1181 = distinct !DIAssignID()
!1182 = distinct !DIAssignID()
!1183 = distinct !DIAssignID()
!1184 = distinct !DIAssignID()
!1185 = distinct !DIAssignID()
!1186 = distinct !DIAssignID()
!1187 = distinct !DIAssignID()
!1188 = distinct !DIAssignID()
!1189 = distinct !DIAssignID()
!1190 = distinct !DIAssignID()
!1191 = distinct !DIAssignID()
!1192 = !DILocation(line: 0, scope: !1133)
!1193 = !DILocalVariable(name: "key", scope: !1194, file: !104, line: 302, type: !746)
!1194 = distinct !DISubprogram(name: "__sock4_xlate_fwd", scope: !104, file: !104, line: 290, type: !1195, scopeLine: 294, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1198)
!1195 = !DISubroutineType(types: !1196)
!1196 = !{!305, !1136, !1136, !1197, !1197}
!1197 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !90)
!1198 = !{!1199, !1200, !1201, !1202, !1203, !1204, !1205, !1208, !1211, !1212, !1213, !1193, !1214, !1215, !1216, !1217, !1222}
!1199 = !DILocalVariable(name: "ctx", arg: 1, scope: !1194, file: !104, line: 290, type: !1136)
!1200 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !1194, file: !104, line: 291, type: !1136)
!1201 = !DILocalVariable(name: "udp_only", arg: 3, scope: !1194, file: !104, line: 292, type: !1197)
!1202 = !DILocalVariable(name: "is_connect", arg: 4, scope: !1194, file: !104, line: 293, type: !1197)
!1203 = !DILocalVariable(name: "id", scope: !1194, file: !104, line: 295, type: !802)
!1204 = !DILocalVariable(name: "in_hostns", scope: !1194, file: !104, line: 296, type: !1197)
!1205 = !DILocalVariable(name: "backend", scope: !1194, file: !104, line: 297, type: !1206)
!1206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1207, size: 64)
!1207 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !780)
!1208 = !DILocalVariable(name: "svc", scope: !1194, file: !104, line: 298, type: !1209)
!1209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1210, size: 64)
!1210 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !756)
!1211 = !DILocalVariable(name: "dst_port", scope: !1194, file: !104, line: 299, type: !92)
!1212 = !DILocalVariable(name: "protocol", scope: !1194, file: !104, line: 300, type: !84)
!1213 = !DILocalVariable(name: "dst_ip", scope: !1194, file: !104, line: 301, type: !153)
!1214 = !DILocalVariable(name: "backend_slot", scope: !1194, file: !104, line: 307, type: !1209)
!1215 = !DILocalVariable(name: "backend_from_affinity", scope: !1194, file: !104, line: 308, type: !90)
!1216 = !DILocalVariable(name: "backend_id", scope: !1194, file: !104, line: 309, type: !82)
!1217 = !DILocalVariable(name: "out", scope: !1218, file: !104, line: 331, type: !91)
!1218 = distinct !DILexicalBlock(scope: !1219, file: !104, line: 331, column: 7)
!1219 = distinct !DILexicalBlock(scope: !1220, file: !104, line: 331, column: 7)
!1220 = distinct !DILexicalBlock(scope: !1221, file: !104, line: 329, column: 59)
!1221 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 329, column: 6)
!1222 = !DILocalVariable(name: "out", scope: !1223, file: !104, line: 357, type: !91)
!1223 = distinct !DILexicalBlock(scope: !1224, file: !104, line: 357, column: 6)
!1224 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 357, column: 6)
!1225 = !DILocation(line: 0, scope: !1194, inlinedAt: !1226)
!1226 = distinct !DILocation(line: 468, column: 8, scope: !1133)
!1227 = !DILocalVariable(name: "ctx", arg: 1, scope: !1228, file: !104, line: 84, type: !91)
!1228 = distinct !DISubprogram(name: "ctx_in_hostns", scope: !104, file: !104, line: 84, type: !1229, scopeLine: 85, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1232)
!1229 = !DISubroutineType(types: !1230)
!1230 = !{!90, !91, !1231}
!1231 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !640, size: 64)
!1232 = !{!1227, !1233, !1234}
!1233 = !DILocalVariable(name: "cookie", arg: 2, scope: !1228, file: !104, line: 84, type: !1231)
!1234 = !DILocalVariable(name: "own_cookie", scope: !1228, file: !104, line: 86, type: !640)
!1235 = !DILocation(line: 0, scope: !1228, inlinedAt: !1236)
!1236 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !1226)
!1237 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !1236)
!1238 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !1236)
!1239 = !DILocalVariable(name: "dport", scope: !1240, file: !104, line: 54, type: !81)
!1240 = distinct !DISubprogram(name: "ctx_dst_port", scope: !104, file: !104, line: 52, type: !1241, scopeLine: 53, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1245)
!1241 = !DISubroutineType(types: !1242)
!1242 = !{!92, !1243}
!1243 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1244, size: 64)
!1244 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1137)
!1245 = !{!1246, !1239}
!1246 = !DILocalVariable(name: "ctx", arg: 1, scope: !1240, file: !104, line: 52, type: !1243)
!1247 = !DILocation(line: 0, scope: !1240, inlinedAt: !1248)
!1248 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !1226)
!1249 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !1248)
!1250 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !1248)
!1251 = !{!1252, !1130, i64 24}
!1252 = !{!"bpf_sock_addr", !1130, i64 0, !1130, i64 4, !1131, i64 8, !1130, i64 24, !1130, i64 28, !1130, i64 32, !1130, i64 36, !1130, i64 40, !1131, i64 44, !1131, i64 64}
!1253 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !1248)
!1254 = distinct !DIAssignID()
!1255 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !1248)
!1256 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !1248)
!1257 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !1248)
!1258 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !1226)
!1259 = !{!1252, !1130, i64 36}
!1260 = !DILocation(line: 301, column: 23, scope: !1194, inlinedAt: !1226)
!1261 = !{!1252, !1130, i64 4}
!1262 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !1226)
!1263 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !1226)
!1264 = !{!1265, !1130, i64 0}
!1265 = !{!"lb4_key", !1130, i64 0, !1266, i64 4, !1266, i64 6, !1131, i64 8, !1131, i64 9, !1131, i64 10}
!1266 = !{!"short", !1131, i64 0}
!1267 = distinct !DIAssignID()
!1268 = !{!1265, !1266, i64 4}
!1269 = distinct !DIAssignID()
!1270 = distinct !DIAssignID()
!1271 = !{!1265, !1131, i64 8}
!1272 = distinct !DIAssignID()
!1273 = distinct !DIAssignID()
!1274 = distinct !DIAssignID()
!1275 = !DILocalVariable(name: "proto", arg: 1, scope: !1276, file: !104, line: 130, type: !84)
!1276 = distinct !DISubprogram(name: "sock_proto_enabled", scope: !104, file: !104, line: 130, type: !1277, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1279)
!1277 = !DISubroutineType(types: !1278)
!1278 = !{!90, !84}
!1279 = !{!1275}
!1280 = !DILocation(line: 0, scope: !1276, inlinedAt: !1281)
!1281 = distinct !DILocation(line: 317, column: 20, scope: !1282, inlinedAt: !1226)
!1282 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 317, column: 6)
!1283 = !DILocation(line: 132, column: 2, scope: !1276, inlinedAt: !1281)
!1284 = !DILocalVariable(name: "dport", scope: !1285, file: !56, line: 1748, type: !85)
!1285 = distinct !DISubprogram(name: "lb4_lookup_service", scope: !56, file: !56, line: 1745, type: !1286, scopeLine: 1746, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1288)
!1286 = !DISubroutineType(types: !1287)
!1287 = !{!1209, !745, !1197}
!1288 = !{!1289, !1290, !1291, !1284, !1292}
!1289 = !DILocalVariable(name: "key", arg: 1, scope: !1285, file: !56, line: 1745, type: !745)
!1290 = !DILocalVariable(name: "east_west", arg: 2, scope: !1285, file: !56, line: 1745, type: !1197)
!1291 = !DILocalVariable(name: "svc", scope: !1285, file: !56, line: 1747, type: !1209)
!1292 = !DILocalVariable(name: "proto", scope: !1285, file: !56, line: 1749, type: !84)
!1293 = distinct !DIAssignID()
!1294 = !DILocation(line: 0, scope: !1285, inlinedAt: !1295)
!1295 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !1226)
!1296 = distinct !DIAssignID()
!1297 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !1295)
!1298 = !{!1265, !1266, i64 6}
!1299 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !1295)
!1300 = !{!1265, !1131, i64 9}
!1301 = !DILocalVariable(name: "key", arg: 1, scope: !1302, file: !56, line: 1715, type: !745)
!1302 = distinct !DISubprogram(name: "__lb4_lookup_service", scope: !56, file: !56, line: 1715, type: !1303, scopeLine: 1716, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1305)
!1303 = !DISubroutineType(types: !1304)
!1304 = !{!1209, !745}
!1305 = !{!1301}
!1306 = !DILocation(line: 0, scope: !1302, inlinedAt: !1307)
!1307 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !1295)
!1308 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1307)
!1309 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !1295)
!1310 = distinct !DILexicalBlock(scope: !1285, file: !56, line: 1755, column: 6)
!1311 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !1295)
!1312 = !DILocalVariable(name: "svc", arg: 1, scope: !1313, file: !56, line: 505, type: !1209)
!1313 = distinct !DISubprogram(name: "lb4_svc_is_two_scopes", scope: !56, file: !56, line: 505, type: !1314, scopeLine: 506, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1316)
!1314 = !DISubroutineType(types: !1315)
!1315 = !{!90, !1209}
!1316 = !{!1312}
!1317 = !DILocation(line: 0, scope: !1313, inlinedAt: !1318)
!1318 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !1295)
!1319 = distinct !DILexicalBlock(scope: !1285, file: !56, line: 1775, column: 6)
!1320 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !1318)
!1321 = !{!1322, !1131, i64 9}
!1322 = !{!"lb4_service", !1131, i64 0, !1266, i64 4, !1266, i64 6, !1131, i64 8, !1131, i64 9, !1266, i64 10}
!1323 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !1318)
!1324 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !1318)
!1325 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !1295)
!1326 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !1295)
!1327 = !DILocation(line: 0, scope: !1302, inlinedAt: !1328)
!1328 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !1295)
!1329 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1328)
!1330 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !1226)
!1331 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 325, column: 6)
!1332 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !1226)
!1333 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !1226)
!1334 = !{!1322, !1266, i64 4}
!1335 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !1226)
!1336 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !1226)
!1337 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !1226)
!1338 = !{i64 2148410311}
!1339 = !DILocation(line: 0, scope: !1218, inlinedAt: !1226)
!1340 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !1226)
!1341 = !{!1342, !1342, i64 0}
!1342 = !{!"_Bool", !1131, i64 0}
!1343 = !{i8 0, i8 2}
!1344 = !{}
!1345 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !1226)
!1346 = !DILocalVariable(name: "svc", arg: 1, scope: !1347, file: !56, line: 2355, type: !1209)
!1347 = distinct !DISubprogram(name: "handle_nonroutable_endpoints_v4", scope: !56, file: !56, line: 2355, type: !1348, scopeLine: 2356, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1350)
!1348 = !DISubroutineType(types: !1349)
!1349 = !{!305, !1209}
!1350 = !{!1346}
!1351 = !DILocation(line: 0, scope: !1347, inlinedAt: !1352)
!1352 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !1226)
!1353 = distinct !DILexicalBlock(scope: !1220, file: !104, line: 333, column: 7)
!1354 = !DILocalVariable(name: "svc", arg: 1, scope: !1355, file: !56, line: 612, type: !1209)
!1355 = distinct !DISubprogram(name: "lb4_svc_is_external", scope: !56, file: !56, line: 612, type: !1314, scopeLine: 613, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1356)
!1356 = !{!1354}
!1357 = !DILocation(line: 0, scope: !1355, inlinedAt: !1358)
!1358 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !1352)
!1359 = distinct !DILexicalBlock(scope: !1347, file: !56, line: 2358, column: 6)
!1360 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !1358)
!1361 = !{!1322, !1131, i64 8}
!1362 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !1358)
!1363 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !1358)
!1364 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !1352)
!1365 = !DILocalVariable(name: "svc", arg: 1, scope: !1366, file: !56, line: 624, type: !1209)
!1366 = distinct !DISubprogram(name: "lb4_svc_is_etp_local", scope: !56, file: !56, line: 624, type: !1314, scopeLine: 625, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1367)
!1367 = !{!1365}
!1368 = !DILocation(line: 0, scope: !1366, inlinedAt: !1369)
!1369 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !1352)
!1370 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !1369)
!1371 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !1369)
!1372 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !1352)
!1373 = !DILocation(line: 0, scope: !1355, inlinedAt: !1374)
!1374 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !1352)
!1375 = !DILocalVariable(name: "svc", arg: 1, scope: !1376, file: !56, line: 636, type: !1209)
!1376 = distinct !DISubprogram(name: "lb4_svc_is_itp_local", scope: !56, file: !56, line: 636, type: !1314, scopeLine: 637, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1377)
!1377 = !{!1375}
!1378 = !DILocation(line: 0, scope: !1376, inlinedAt: !1379)
!1379 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !1352)
!1380 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !1379)
!1381 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !1379)
!1382 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !1379)
!1383 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !1352)
!1384 = !DILocation(line: 0, scope: !1220, inlinedAt: !1226)
!1385 = !DILocalVariable(name: "svc", arg: 1, scope: !1386, file: !56, line: 568, type: !1209)
!1386 = distinct !DISubprogram(name: "lb4_svc_is_l7_punt_proxy", scope: !56, file: !56, line: 568, type: !1314, scopeLine: 569, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1387)
!1387 = !{!1385}
!1388 = !DILocation(line: 0, scope: !1386, inlinedAt: !1389)
!1389 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !1226)
!1390 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 345, column: 6)
!1391 = !DILocalVariable(name: "svc", arg: 1, scope: !1392, file: !56, line: 469, type: !1209)
!1392 = distinct !DISubprogram(name: "lb4_svc_is_hostport", scope: !56, file: !56, line: 469, type: !1314, scopeLine: 470, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1393)
!1393 = !{!1391}
!1394 = !DILocation(line: 0, scope: !1392, inlinedAt: !1395)
!1395 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !1389)
!1396 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !1395)
!1397 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !1395)
!1398 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !1395)
!1399 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !1389)
!1400 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !1389)
!1401 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !1389)
!1402 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !1226)
!1403 = !DILocalVariable(name: "svc", arg: 1, scope: !1404, file: !104, line: 188, type: !1209)
!1404 = distinct !DISubprogram(name: "sock4_skip_xlate", scope: !104, file: !104, line: 188, type: !1405, scopeLine: 189, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1407)
!1405 = !DISubroutineType(types: !1406)
!1406 = !{!90, !1209, !153}
!1407 = !{!1403, !1408, !1409}
!1408 = !DILocalVariable(name: "address", arg: 2, scope: !1404, file: !104, line: 188, type: !153)
!1409 = !DILocalVariable(name: "info", scope: !1410, file: !104, line: 194, type: !1412)
!1410 = distinct !DILexicalBlock(scope: !1411, file: !104, line: 193, column: 62)
!1411 = distinct !DILexicalBlock(scope: !1404, file: !104, line: 192, column: 6)
!1412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1413, size: 64)
!1413 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !482)
!1414 = !DILocation(line: 0, scope: !1404, inlinedAt: !1415)
!1415 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !1226)
!1416 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 354, column: 6)
!1417 = !DILocalVariable(name: "svc", arg: 1, scope: !1418, file: !56, line: 457, type: !1209)
!1418 = distinct !DISubprogram(name: "lb4_svc_is_external_ip", scope: !56, file: !56, line: 457, type: !1314, scopeLine: 458, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1419)
!1419 = !{!1417}
!1420 = !DILocation(line: 0, scope: !1418, inlinedAt: !1421)
!1421 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !1415)
!1422 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !1421)
!1423 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !1421)
!1424 = !DILocation(line: 0, scope: !1392, inlinedAt: !1425)
!1425 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !1415)
!1426 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !1415)
!1427 = !DILocalVariable(name: "key", scope: !1428, file: !413, line: 161, type: !463)
!1428 = distinct !DISubprogram(name: "ipcache_lookup4", scope: !413, file: !413, line: 159, type: !1429, scopeLine: 160, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1431)
!1429 = !DISubroutineType(types: !1430)
!1430 = !{!1412, !1013, !153, !82, !82}
!1431 = !{!1432, !1433, !1434, !1435, !1427}
!1432 = !DILocalVariable(name: "map", arg: 1, scope: !1428, file: !413, line: 159, type: !1013)
!1433 = !DILocalVariable(name: "addr", arg: 2, scope: !1428, file: !413, line: 159, type: !153)
!1434 = !DILocalVariable(name: "prefix", arg: 3, scope: !1428, file: !413, line: 159, type: !82)
!1435 = !DILocalVariable(name: "cluster_id", arg: 4, scope: !1428, file: !413, line: 159, type: !82)
!1436 = !DILocation(line: 0, scope: !1428, inlinedAt: !1437)
!1437 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !1415)
!1438 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !1437)
!1439 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !1437)
!1440 = distinct !DIAssignID()
!1441 = distinct !DIAssignID()
!1442 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !1437)
!1443 = !{i64 0, i64 4, !1129, i64 4, i64 0, !1444}
!1444 = !{!1131, !1131, i64 0}
!1445 = distinct !DIAssignID()
!1446 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !1437)
!1447 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !1437)
!1448 = !{!1449, !1131, i64 7}
!1449 = !{!"ipcache_key", !1450, i64 0, !1266, i64 4, !1131, i64 6, !1131, i64 7, !1131, i64 8}
!1450 = !{!"bpf_lpm_trie_key", !1130, i64 0, !1131, i64 4}
!1451 = distinct !DIAssignID()
!1452 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !1437)
!1453 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !1437)
!1454 = distinct !DIAssignID()
!1455 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !1437)
!1456 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !1437)
!1457 = !{!1449, !1266, i64 4}
!1458 = distinct !DIAssignID()
!1459 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !1437)
!1460 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !1437)
!1461 = !DILocation(line: 0, scope: !1410, inlinedAt: !1415)
!1462 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !1415)
!1463 = distinct !DILexicalBlock(scope: !1410, file: !104, line: 197, column: 7)
!1464 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !1415)
!1465 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !1415)
!1466 = !{!1467, !1130, i64 0}
!1467 = !{!"remote_endpoint_info", !1130, i64 0, !1131, i64 4, !1266, i64 20, !1131, i64 22, !1131, i64 23, !1131, i64 23, !1131, i64 23, !1131, i64 23, !1131, i64 23}
!1468 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !1415)
!1469 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !1415)
!1470 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !1226)
!1471 = !{i64 2148415797}
!1472 = !DILocation(line: 0, scope: !1223, inlinedAt: !1226)
!1473 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !1226)
!1474 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !1226)
!1475 = !DILocalVariable(name: "svc", arg: 1, scope: !1476, file: !56, line: 546, type: !1209)
!1476 = distinct !DISubprogram(name: "lb4_svc_is_localredirect", scope: !56, file: !56, line: 546, type: !1314, scopeLine: 547, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1477)
!1477 = !{!1475}
!1478 = !DILocation(line: 0, scope: !1476, inlinedAt: !1479)
!1479 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !1226)
!1480 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !1479)
!1481 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !1479)
!1482 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !1479)
!1483 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !1226)
!1484 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !1226)
!1485 = !DILocalVariable(name: "key", scope: !1486, file: !905, line: 77, type: !933)
!1486 = distinct !DISubprogram(name: "lrp_v4_skip_xlate_from_ctx_to_svc", scope: !905, file: !905, line: 75, type: !1487, scopeLine: 76, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1489)
!1487 = !DISubroutineType(types: !1488)
!1488 = !{!90, !640, !153, !92}
!1489 = !{!1490, !1491, !1492, !1485, !1493}
!1490 = !DILocalVariable(name: "cookie", arg: 1, scope: !1486, file: !905, line: 75, type: !640)
!1491 = !DILocalVariable(name: "address", arg: 2, scope: !1486, file: !905, line: 75, type: !153)
!1492 = !DILocalVariable(name: "port", arg: 3, scope: !1486, file: !905, line: 75, type: !92)
!1493 = !DILocalVariable(name: "val", scope: !1486, file: !905, line: 78, type: !97)
!1494 = !DILocation(line: 0, scope: !1486, inlinedAt: !1495)
!1495 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !1226)
!1496 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !1495)
!1497 = !DILocalVariable(name: "d", arg: 1, scope: !1498, file: !1499, line: 152, type: !91)
!1498 = distinct !DISubprogram(name: "memset", scope: !1499, file: !1499, line: 152, type: !1500, scopeLine: 154, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1502)
!1499 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/builtins.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "b637b2eb683f238f586aafe0a119b3ec")
!1500 = !DISubroutineType(types: !1501)
!1501 = !{null, !91, !305, !95}
!1502 = !{!1497, !1503, !1504}
!1503 = !DILocalVariable(name: "c", arg: 2, scope: !1498, file: !1499, line: 152, type: !305)
!1504 = !DILocalVariable(name: "len", arg: 3, scope: !1498, file: !1499, line: 153, type: !95)
!1505 = !DILocation(line: 0, scope: !1498, inlinedAt: !1506)
!1506 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !1495)
!1507 = !DILocalVariable(name: "len", arg: 2, scope: !1508, file: !1499, line: 44, type: !95)
!1508 = distinct !DISubprogram(name: "__bpf_memzero", scope: !1499, file: !1499, line: 44, type: !1509, scopeLine: 45, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1511)
!1509 = !DISubroutineType(types: !1510)
!1510 = !{null, !91, !95}
!1511 = !{!1512, !1507, !1513, !1515, !1516, !1517, !1518, !1519, !1520, !1521, !1522, !1523, !1524, !1525, !1526, !1527, !1528}
!1512 = !DILocalVariable(name: "d", arg: 1, scope: !1508, file: !1499, line: 44, type: !91)
!1513 = !DILabel(scope: !1514, name: "jmp_120", file: !1499, line: 58)
!1514 = distinct !DILexicalBlock(scope: !1508, file: !1499, line: 56, column: 15)
!1515 = !DILabel(scope: !1514, name: "jmp_112", file: !1499, line: 59)
!1516 = !DILabel(scope: !1514, name: "jmp_104", file: !1499, line: 60)
!1517 = !DILabel(scope: !1514, name: "jmp_96", file: !1499, line: 61)
!1518 = !DILabel(scope: !1514, name: "jmp_88", file: !1499, line: 62)
!1519 = !DILabel(scope: !1514, name: "jmp_80", file: !1499, line: 63)
!1520 = !DILabel(scope: !1514, name: "jmp_72", file: !1499, line: 64)
!1521 = !DILabel(scope: !1514, name: "jmp_64", file: !1499, line: 65)
!1522 = !DILabel(scope: !1514, name: "jmp_56", file: !1499, line: 66)
!1523 = !DILabel(scope: !1514, name: "jmp_48", file: !1499, line: 67)
!1524 = !DILabel(scope: !1514, name: "jmp_40", file: !1499, line: 68)
!1525 = !DILabel(scope: !1514, name: "jmp_32", file: !1499, line: 69)
!1526 = !DILabel(scope: !1514, name: "jmp_24", file: !1499, line: 70)
!1527 = !DILabel(scope: !1514, name: "jmp_16", file: !1499, line: 71)
!1528 = !DILabel(scope: !1514, name: "jmp_8", file: !1499, line: 72)
!1529 = !DILocation(line: 0, scope: !1508, inlinedAt: !1530)
!1530 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !1506)
!1531 = distinct !DILexicalBlock(scope: !1498, file: !1499, line: 155, column: 6)
!1532 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !1530)
!1533 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !1530)
!1534 = !{!1535, !1535, i64 0}
!1535 = !{!"long long", !1131, i64 0}
!1536 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !1530)
!1537 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !1495)
!1538 = !{!1539, !1535, i64 0}
!1539 = !{!"skip_lb4_key", !1535, i64 0, !1130, i64 8, !1266, i64 12, !1266, i64 14}
!1540 = distinct !DIAssignID()
!1541 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !1495)
!1542 = !{!1539, !1130, i64 8}
!1543 = distinct !DIAssignID()
!1544 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !1495)
!1545 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !1495)
!1546 = !{!1539, !1266, i64 12}
!1547 = distinct !DIAssignID()
!1548 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !1495)
!1549 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !1495)
!1550 = distinct !DILexicalBlock(scope: !1486, file: !905, line: 85, column: 6)
!1551 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !1495)
!1552 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !1226)
!1553 = !DILocalVariable(name: "svc", arg: 1, scope: !1554, file: !56, line: 517, type: !1209)
!1554 = distinct !DISubprogram(name: "lb4_svc_is_affinity", scope: !56, file: !56, line: 517, type: !1314, scopeLine: 518, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1555)
!1555 = !{!1553}
!1556 = !DILocation(line: 0, scope: !1554, inlinedAt: !1557)
!1557 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !1226)
!1558 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 392, column: 6)
!1559 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !1557)
!1560 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !1557)
!1561 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !1557)
!1562 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !1226)
!1563 = !DILocalVariable(name: "svc", arg: 1, scope: !1564, file: !56, line: 2109, type: !1209)
!1564 = distinct !DISubprogram(name: "lb4_affinity_backend_id_by_netns", scope: !56, file: !56, line: 2109, type: !1565, scopeLine: 2111, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1568)
!1565 = !DISubroutineType(types: !1566)
!1566 = !{!82, !1209, !1567}
!1567 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !802, size: 64)
!1568 = !{!1563, !1569}
!1569 = !DILocalVariable(name: "id", arg: 2, scope: !1564, file: !56, line: 2110, type: !1567)
!1570 = !DILocation(line: 0, scope: !1564, inlinedAt: !1571)
!1571 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !1226)
!1572 = distinct !DILexicalBlock(scope: !1558, file: !104, line: 392, column: 32)
!1573 = !DILocalVariable(name: "key", scope: !1574, file: !56, line: 2037, type: !799)
!1574 = distinct !DISubprogram(name: "__lb4_affinity_backend_id", scope: !56, file: !56, line: 2034, type: !1575, scopeLine: 2036, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1579)
!1575 = !DISubroutineType(types: !1576)
!1576 = !{!82, !1209, !90, !1577}
!1577 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1578, size: 64)
!1578 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !802)
!1579 = !{!1580, !1581, !1582, !1573, !1583, !1584, !1587, !1588, !1591}
!1580 = !DILocalVariable(name: "svc", arg: 1, scope: !1574, file: !56, line: 2034, type: !1209)
!1581 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !1574, file: !56, line: 2034, type: !90)
!1582 = !DILocalVariable(name: "id", arg: 3, scope: !1574, file: !56, line: 2035, type: !1577)
!1583 = !DILocalVariable(name: "val", scope: !1574, file: !56, line: 2042, type: !647)
!1584 = !DILocalVariable(name: "now", scope: !1585, file: !56, line: 2046, type: !82)
!1585 = distinct !DILexicalBlock(scope: !1586, file: !56, line: 2045, column: 19)
!1586 = distinct !DILexicalBlock(scope: !1574, file: !56, line: 2045, column: 6)
!1587 = !DILocalVariable(name: "match", scope: !1585, file: !56, line: 2047, type: !872)
!1588 = !DILocalVariable(name: "__val", scope: !1589, file: !56, line: 2057, type: !95)
!1589 = distinct !DILexicalBlock(scope: !1590, file: !56, line: 2057, column: 7)
!1590 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2057, column: 7)
!1591 = !DILocalVariable(name: "__val", scope: !1592, file: !56, line: 2068, type: !95)
!1592 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2068, column: 3)
!1593 = !DILocation(line: 0, scope: !1574, inlinedAt: !1594)
!1594 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !1571)
!1595 = !DILocation(line: 0, scope: !1585, inlinedAt: !1594)
!1596 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !1594)
!1597 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !1594)
!1598 = distinct !DIAssignID()
!1599 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !1594)
!1600 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !1594)
!1601 = !{!1322, !1266, i64 6}
!1602 = !{!1603, !1266, i64 8}
!1603 = !{!"lb4_affinity_key", !1131, i64 0, !1266, i64 8, !1131, i64 10, !1131, i64 10, !1131, i64 11, !1130, i64 12}
!1604 = distinct !DIAssignID()
!1605 = distinct !DIAssignID()
!1606 = distinct !DIAssignID()
!1607 = !{!1603, !1131, i64 11}
!1608 = distinct !DIAssignID()
!1609 = !{!1603, !1130, i64 12}
!1610 = distinct !DIAssignID()
!1611 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !1594)
!1612 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !1594)
!1613 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !1594)
!1614 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !1594)
!1615 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !1226)
!1616 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !1624)
!1617 = distinct !DILexicalBlock(scope: !1618, file: !290, line: 26, column: 6)
!1618 = distinct !DILexicalBlock(scope: !1619, file: !290, line: 26, column: 6)
!1619 = distinct !DISubprogram(name: "bpf_mono_now", scope: !290, file: !290, line: 24, type: !1620, scopeLine: 25, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1622)
!1620 = !DISubroutineType(types: !1621)
!1621 = !{!95}
!1622 = !{!1623}
!1623 = !DILocalVariable(name: "out", scope: !1617, file: !290, line: 26, type: !91)
!1624 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !1594)
!1625 = !{i64 2148214018}
!1626 = !DILocation(line: 0, scope: !1617, inlinedAt: !1624)
!1627 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !1624)
!1628 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !1624)
!1629 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !1624)
!1630 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !1624)
!1631 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !1624)
!1632 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !1634)
!1633 = distinct !DISubprogram(name: "bpf_ktime_get_sec", scope: !290, file: !290, line: 17, type: !1620, scopeLine: 18, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1634 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !1624)
!1635 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !1634)
!1636 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !1624)
!1637 = !DILocation(line: 0, scope: !1619, inlinedAt: !1624)
!1638 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !1594)
!1639 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !1594)
!1640 = !{!1641, !1130, i64 8}
!1641 = !{!"lb_affinity_val", !1535, i64 0, !1130, i64 8, !1130, i64 12}
!1642 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !1594)
!1643 = !{!1644, !1130, i64 0}
!1644 = !{!"lb_affinity_match", !1130, i64 0, !1266, i64 4, !1266, i64 6}
!1645 = distinct !DIAssignID()
!1646 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !1594)
!1647 = !{!1644, !1266, i64 4}
!1648 = distinct !DIAssignID()
!1649 = !{!1644, !1266, i64 6}
!1650 = distinct !DIAssignID()
!1651 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !1594)
!1652 = !DILocation(line: 0, scope: !1589, inlinedAt: !1594)
!1653 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !1656)
!1654 = distinct !DISubprogram(name: "bpf_barrier", scope: !1655, file: !1655, line: 83, type: !1120, scopeLine: 84, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1655 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../compiler.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "223438cf74958b7bda161886abcea0ce")
!1656 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !1594)
!1657 = !{i64 2147845043}
!1658 = !DILocalVariable(name: "svc", arg: 1, scope: !1659, file: !56, line: 2028, type: !1209)
!1659 = distinct !DISubprogram(name: "lb4_affinity_timeout", scope: !56, file: !56, line: 2028, type: !1660, scopeLine: 2029, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1662)
!1660 = !DISubroutineType(types: !1661)
!1661 = !{!82, !1209}
!1662 = !{!1658}
!1663 = !DILocation(line: 0, scope: !1659, inlinedAt: !1664)
!1664 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !1594)
!1665 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !1664)
!1666 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !1664)
!1667 = !DILocalVariable(name: "s", arg: 1, scope: !1668, file: !290, line: 31, type: !82)
!1668 = distinct !DISubprogram(name: "bpf_sec_to_mono", scope: !290, file: !290, line: 31, type: !1669, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1671)
!1669 = !DISubroutineType(types: !1670)
!1670 = !{!82, !82}
!1671 = !{!1667, !1672, !1675}
!1672 = !DILocalVariable(name: "out", scope: !1673, file: !290, line: 33, type: !91)
!1673 = distinct !DILexicalBlock(scope: !1674, file: !290, line: 33, column: 6)
!1674 = distinct !DILexicalBlock(scope: !1668, file: !290, line: 33, column: 6)
!1675 = !DILocalVariable(name: "out", scope: !1676, file: !290, line: 34, type: !91)
!1676 = distinct !DILexicalBlock(scope: !1674, file: !290, line: 34, column: 22)
!1677 = !DILocation(line: 0, scope: !1668, inlinedAt: !1678)
!1678 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !1594)
!1679 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !1678)
!1680 = !{i64 2148214946}
!1681 = !DILocation(line: 0, scope: !1673, inlinedAt: !1678)
!1682 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !1678)
!1683 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !1678)
!1684 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !1678)
!1685 = !{i64 2148219895}
!1686 = !DILocation(line: 0, scope: !1676, inlinedAt: !1678)
!1687 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !1678)
!1688 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !1678)
!1689 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !1678)
!1690 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !1678)
!1691 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !1594)
!1692 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !1594)
!1693 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !1594)
!1694 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !1594)
!1695 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !1594)
!1696 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !1594)
!1697 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2063, column: 7)
!1698 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !1594)
!1699 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !1594)
!1700 = !DILocation(line: 0, scope: !1592, inlinedAt: !1594)
!1701 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !1594)
!1702 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !1703)
!1703 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !1594)
!1704 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !1594)
!1705 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !1226)
!1706 = distinct !DILexicalBlock(scope: !1572, file: !104, line: 403, column: 7)
!1707 = !DILocalVariable(name: "backend_id", arg: 1, scope: !1708, file: !56, line: 1847, type: !82)
!1708 = distinct !DISubprogram(name: "__lb4_lookup_backend", scope: !56, file: !56, line: 1847, type: !1709, scopeLine: 1848, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1711)
!1709 = !DISubroutineType(types: !1710)
!1710 = !{!1206, !82}
!1711 = !{!1707}
!1712 = !DILocation(line: 0, scope: !1708, inlinedAt: !1713)
!1713 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !1226)
!1714 = distinct !DILexicalBlock(scope: !1706, file: !104, line: 403, column: 24)
!1715 = distinct !DIAssignID()
!1716 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !1713)
!1717 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !1713)
!1718 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !1226)
!1719 = distinct !DILexicalBlock(scope: !1714, file: !104, line: 405, column: 8)
!1720 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !1226)
!1721 = !{i64 2148416002}
!1722 = !DILocation(line: 0, scope: !1714, inlinedAt: !1226)
!1723 = !DILocalVariable(name: "ctx", arg: 1, scope: !1724, file: !104, line: 123, type: !1136)
!1724 = distinct !DISubprogram(name: "sock_select_slot", scope: !104, file: !104, line: 123, type: !1725, scopeLine: 124, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1727)
!1725 = !DISubroutineType(types: !1726)
!1726 = !{!95, !1136}
!1727 = !{!1723}
!1728 = !DILocation(line: 0, scope: !1724, inlinedAt: !1729)
!1729 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !1226)
!1730 = distinct !DILexicalBlock(scope: !1731, file: !104, line: 417, column: 23)
!1731 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 417, column: 6)
!1732 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !1729)
!1733 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !1729)
!1734 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !1729)
!1735 = !DILocalVariable(name: "ctx", arg: 1, scope: !1736, file: !949, line: 10, type: !1136)
!1736 = distinct !DISubprogram(name: "sock_local_cookie", scope: !949, file: !949, line: 10, type: !1737, scopeLine: 11, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1739)
!1737 = !DISubroutineType(types: !1738)
!1738 = !{!684, !1136}
!1739 = !{!1735}
!1740 = !DILocation(line: 0, scope: !1736, inlinedAt: !1741)
!1741 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !1729)
!1742 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !1741)
!1743 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !1226)
!1744 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !1226)
!1745 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !1226)
!1746 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !1226)
!1747 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !1226)
!1748 = distinct !DIAssignID()
!1749 = !DILocalVariable(name: "key", arg: 1, scope: !1750, file: !56, line: 1865, type: !745)
!1750 = distinct !DISubprogram(name: "__lb4_lookup_backend_slot", scope: !56, file: !56, line: 1865, type: !1303, scopeLine: 1866, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1751)
!1751 = !{!1749}
!1752 = !DILocation(line: 0, scope: !1750, inlinedAt: !1753)
!1753 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !1226)
!1754 = !DILocation(line: 0, scope: !1302, inlinedAt: !1755)
!1755 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !1753)
!1756 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1755)
!1757 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !1226)
!1758 = distinct !DILexicalBlock(scope: !1730, file: !104, line: 422, column: 7)
!1759 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !1226)
!1760 = !DILocalVariable(name: "new_entry", scope: !1761, file: !299, line: 50, type: !323)
!1761 = distinct !DISubprogram(name: "_update_metrics", scope: !299, file: !299, line: 47, type: !1762, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1764)
!1762 = !DISubroutineType(types: !1763)
!1763 = !{null, !95, !84, !84, !85, !84}
!1764 = !{!1765, !1766, !1767, !1768, !1769, !1770, !1760, !1771}
!1765 = !DILocalVariable(name: "bytes", arg: 1, scope: !1761, file: !299, line: 47, type: !95)
!1766 = !DILocalVariable(name: "direction", arg: 2, scope: !1761, file: !299, line: 47, type: !84)
!1767 = !DILocalVariable(name: "reason", arg: 3, scope: !1761, file: !299, line: 48, type: !84)
!1768 = !DILocalVariable(name: "line", arg: 4, scope: !1761, file: !299, line: 48, type: !85)
!1769 = !DILocalVariable(name: "file", arg: 5, scope: !1761, file: !299, line: 48, type: !84)
!1770 = !DILocalVariable(name: "entry", scope: !1761, file: !299, line: 50, type: !322)
!1771 = !DILocalVariable(name: "key", scope: !1761, file: !299, line: 51, type: !310)
!1772 = !DILocation(line: 0, scope: !1761, inlinedAt: !1773)
!1773 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !1226)
!1774 = distinct !DILexicalBlock(scope: !1758, file: !104, line: 422, column: 22)
!1775 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !1773)
!1776 = distinct !DIAssignID()
!1777 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !1773)
!1778 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !1773)
!1779 = distinct !DIAssignID()
!1780 = distinct !DIAssignID()
!1781 = distinct !DIAssignID()
!1782 = distinct !DIAssignID()
!1783 = distinct !DIAssignID()
!1784 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !1773)
!1785 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !1773)
!1786 = distinct !DILexicalBlock(scope: !1761, file: !299, line: 59, column: 6)
!1787 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !1773)
!1788 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !1773)
!1789 = distinct !DILexicalBlock(scope: !1786, file: !299, line: 59, column: 13)
!1790 = !{!1791, !1535, i64 0}
!1791 = !{!"metrics_value", !1535, i64 0, !1535, i64 8}
!1792 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !1773)
!1793 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !1773)
!1794 = distinct !DILexicalBlock(scope: !1786, file: !299, line: 62, column: 9)
!1795 = distinct !DIAssignID()
!1796 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !1773)
!1797 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !1773)
!1798 = !{!1791, !1535, i64 8}
!1799 = distinct !DIAssignID()
!1800 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !1773)
!1801 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !1773)
!1802 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !1226)
!1803 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !1226)
!1804 = !DILocation(line: 0, scope: !1708, inlinedAt: !1805)
!1805 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !1226)
!1806 = distinct !DIAssignID()
!1807 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !1805)
!1808 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !1805)
!1809 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !1226)
!1810 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 431, column: 6)
!1811 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !1226)
!1812 = !DILocation(line: 0, scope: !1761, inlinedAt: !1813)
!1813 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !1226)
!1814 = distinct !DILexicalBlock(scope: !1810, file: !104, line: 431, column: 16)
!1815 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !1813)
!1816 = distinct !DIAssignID()
!1817 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !1813)
!1818 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !1813)
!1819 = distinct !DIAssignID()
!1820 = distinct !DIAssignID()
!1821 = distinct !DIAssignID()
!1822 = distinct !DIAssignID()
!1823 = distinct !DIAssignID()
!1824 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !1813)
!1825 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !1813)
!1826 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !1813)
!1827 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !1813)
!1828 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !1813)
!1829 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !1813)
!1830 = distinct !DIAssignID()
!1831 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !1813)
!1832 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !1813)
!1833 = distinct !DIAssignID()
!1834 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !1813)
!1835 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !1813)
!1836 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !1226)
!1837 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !1226)
!1838 = !{i64 2148416350}
!1839 = !DILocation(line: 0, scope: !1554, inlinedAt: !1840)
!1840 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !1226)
!1841 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 437, column: 6)
!1842 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !1840)
!1843 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !1840)
!1844 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !1840)
!1845 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !1226)
!1846 = !DILocalVariable(name: "svc", arg: 1, scope: !1847, file: !56, line: 2116, type: !1209)
!1847 = distinct !DISubprogram(name: "lb4_update_affinity_by_netns", scope: !56, file: !56, line: 2116, type: !1848, scopeLine: 2119, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1850)
!1848 = !DISubroutineType(types: !1849)
!1849 = !{null, !1209, !1567, !82}
!1850 = !{!1846, !1851, !1852}
!1851 = !DILocalVariable(name: "id", arg: 2, scope: !1847, file: !56, line: 2117, type: !1567)
!1852 = !DILocalVariable(name: "backend_id", arg: 3, scope: !1847, file: !56, line: 2118, type: !82)
!1853 = !DILocation(line: 0, scope: !1847, inlinedAt: !1854)
!1854 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !1226)
!1855 = !DILocalVariable(name: "key", scope: !1856, file: !56, line: 2088, type: !799)
!1856 = distinct !DISubprogram(name: "__lb4_update_affinity", scope: !56, file: !56, line: 2083, type: !1857, scopeLine: 2086, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1859)
!1857 = !DISubroutineType(types: !1858)
!1858 = !{null, !1209, !90, !1577, !82}
!1859 = !{!1860, !1861, !1862, !1863, !1864, !1855, !1865}
!1860 = !DILocalVariable(name: "svc", arg: 1, scope: !1856, file: !56, line: 2083, type: !1209)
!1861 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !1856, file: !56, line: 2083, type: !90)
!1862 = !DILocalVariable(name: "id", arg: 3, scope: !1856, file: !56, line: 2084, type: !1577)
!1863 = !DILocalVariable(name: "backend_id", arg: 4, scope: !1856, file: !56, line: 2085, type: !82)
!1864 = !DILocalVariable(name: "now", scope: !1856, file: !56, line: 2087, type: !82)
!1865 = !DILocalVariable(name: "val", scope: !1856, file: !56, line: 2093, type: !648)
!1866 = !DILocation(line: 0, scope: !1856, inlinedAt: !1867)
!1867 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !1854)
!1868 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !1869)
!1869 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !1867)
!1870 = !DILocation(line: 0, scope: !1617, inlinedAt: !1869)
!1871 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !1869)
!1872 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !1869)
!1873 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !1869)
!1874 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !1869)
!1875 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !1869)
!1876 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !1877)
!1877 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !1869)
!1878 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !1877)
!1879 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !1869)
!1880 = !DILocation(line: 0, scope: !1619, inlinedAt: !1869)
!1881 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !1867)
!1882 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !1867)
!1883 = distinct !DIAssignID()
!1884 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !1867)
!1885 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !1867)
!1886 = distinct !DIAssignID()
!1887 = distinct !DIAssignID()
!1888 = distinct !DIAssignID()
!1889 = distinct !DIAssignID()
!1890 = distinct !DIAssignID()
!1891 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !1867)
!1892 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !1867)
!1893 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !1867)
!1894 = !{!1641, !1535, i64 0}
!1895 = distinct !DIAssignID()
!1896 = distinct !DIAssignID()
!1897 = !{!1641, !1130, i64 12}
!1898 = distinct !DIAssignID()
!1899 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !1867)
!1900 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !1867)
!1901 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !1226)
!1902 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !1226)
!1903 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !1226)
!1904 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 446, column: 6)
!1905 = !DILocalVariable(name: "val", scope: !1906, file: !104, line: 150, type: !963)
!1906 = distinct !DISubprogram(name: "sock4_update_revnat", scope: !104, file: !104, line: 145, type: !1907, scopeLine: 149, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1909)
!1907 = !DISubroutineType(types: !1908)
!1908 = !{!305, !1136, !1206, !153, !92, !85}
!1909 = !{!1910, !1911, !1912, !1913, !1914, !1905, !1915, !1916, !1917}
!1910 = !DILocalVariable(name: "ctx", arg: 1, scope: !1906, file: !104, line: 145, type: !1136)
!1911 = !DILocalVariable(name: "backend", arg: 2, scope: !1906, file: !104, line: 146, type: !1206)
!1912 = !DILocalVariable(name: "dst_ip", arg: 3, scope: !1906, file: !104, line: 147, type: !153)
!1913 = !DILocalVariable(name: "dst_port", arg: 4, scope: !1906, file: !104, line: 147, type: !92)
!1914 = !DILocalVariable(name: "rev_nat_id", arg: 5, scope: !1906, file: !104, line: 148, type: !85)
!1915 = !DILocalVariable(name: "tmp", scope: !1906, file: !104, line: 150, type: !962)
!1916 = !DILocalVariable(name: "key", scope: !1906, file: !104, line: 151, type: !955)
!1917 = !DILocalVariable(name: "ret", scope: !1906, file: !104, line: 152, type: !305)
!1918 = !DILocation(line: 0, scope: !1906, inlinedAt: !1919)
!1919 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !1226)
!1920 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !1919)
!1921 = distinct !DIAssignID()
!1922 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !1919)
!1923 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !1919)
!1924 = distinct !DIAssignID()
!1925 = distinct !DIAssignID()
!1926 = !DILocation(line: 0, scope: !1736, inlinedAt: !1927)
!1927 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !1919)
!1928 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !1927)
!1929 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !1919)
!1930 = !{!1931, !1535, i64 0}
!1931 = !{!"ipv4_revnat_tuple", !1535, i64 0, !1130, i64 8, !1266, i64 12, !1266, i64 14}
!1932 = distinct !DIAssignID()
!1933 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !1919)
!1934 = !{!1935, !1130, i64 0}
!1935 = !{!"lb4_backend", !1130, i64 0, !1266, i64 4, !1131, i64 6, !1131, i64 7, !1266, i64 8, !1131, i64 10, !1131, i64 11}
!1936 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !1919)
!1937 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !1919)
!1938 = !{!1931, !1130, i64 8}
!1939 = distinct !DIAssignID()
!1940 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !1919)
!1941 = !{!1935, !1266, i64 4}
!1942 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !1919)
!1943 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !1919)
!1944 = !{!1931, !1266, i64 12}
!1945 = distinct !DIAssignID()
!1946 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !1919)
!1947 = !{!1948, !1130, i64 0}
!1948 = !{!"ipv4_revnat_entry", !1130, i64 0, !1266, i64 4, !1266, i64 6}
!1949 = distinct !DIAssignID()
!1950 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !1919)
!1951 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !1919)
!1952 = !{!1948, !1266, i64 4}
!1953 = distinct !DIAssignID()
!1954 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !1919)
!1955 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !1919)
!1956 = !{!1948, !1266, i64 6}
!1957 = distinct !DIAssignID()
!1958 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !1919)
!1959 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !1919)
!1960 = distinct !DILexicalBlock(scope: !1906, file: !104, line: 167, column: 6)
!1961 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !1919)
!1962 = !DILocalVariable(name: "x", arg: 1, scope: !1963, file: !1499, line: 411, type: !1013)
!1963 = distinct !DISubprogram(name: "memcmp", scope: !1499, file: !1499, line: 411, type: !1964, scopeLine: 414, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1966)
!1964 = !DISubroutineType(types: !1965)
!1965 = !{!95, !1013, !1013, !95}
!1966 = !{!1962, !1967, !1968}
!1967 = !DILocalVariable(name: "y", arg: 2, scope: !1963, file: !1499, line: 412, type: !1013)
!1968 = !DILocalVariable(name: "len", arg: 3, scope: !1963, file: !1499, line: 413, type: !95)
!1969 = !DILocation(line: 0, scope: !1963, inlinedAt: !1970)
!1970 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !1919)
!1971 = !DILocalVariable(name: "len", arg: 3, scope: !1972, file: !1499, line: 299, type: !95)
!1972 = distinct !DISubprogram(name: "__bpf_memcmp", scope: !1499, file: !1499, line: 298, type: !1964, scopeLine: 300, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1973)
!1973 = !{!1974, !1975, !1971, !1976, !1977, !1979, !1980, !1981, !1982, !1983, !1984, !1985, !1986, !1987, !1988, !1989, !1990, !1991, !1992}
!1974 = !DILocalVariable(name: "x", arg: 1, scope: !1972, file: !1499, line: 298, type: !1013)
!1975 = !DILocalVariable(name: "y", arg: 2, scope: !1972, file: !1499, line: 298, type: !1013)
!1976 = !DILocalVariable(name: "r", scope: !1972, file: !1499, line: 301, type: !95)
!1977 = !DILabel(scope: !1978, name: "jmp_120", file: !1499, line: 316)
!1978 = distinct !DILexicalBlock(scope: !1972, file: !1499, line: 314, column: 15)
!1979 = !DILabel(scope: !1978, name: "jmp_112", file: !1499, line: 317)
!1980 = !DILabel(scope: !1978, name: "jmp_104", file: !1499, line: 318)
!1981 = !DILabel(scope: !1978, name: "jmp_96", file: !1499, line: 319)
!1982 = !DILabel(scope: !1978, name: "jmp_88", file: !1499, line: 320)
!1983 = !DILabel(scope: !1978, name: "jmp_80", file: !1499, line: 321)
!1984 = !DILabel(scope: !1978, name: "jmp_72", file: !1499, line: 322)
!1985 = !DILabel(scope: !1978, name: "jmp_64", file: !1499, line: 323)
!1986 = !DILabel(scope: !1978, name: "jmp_56", file: !1499, line: 324)
!1987 = !DILabel(scope: !1978, name: "jmp_48", file: !1499, line: 325)
!1988 = !DILabel(scope: !1978, name: "jmp_40", file: !1499, line: 326)
!1989 = !DILabel(scope: !1978, name: "jmp_32", file: !1499, line: 327)
!1990 = !DILabel(scope: !1978, name: "jmp_24", file: !1499, line: 328)
!1991 = !DILabel(scope: !1978, name: "jmp_16", file: !1499, line: 329)
!1992 = !DILabel(scope: !1978, name: "jmp_8", file: !1499, line: 330)
!1993 = !DILocation(line: 0, scope: !1972, inlinedAt: !1994)
!1994 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !1970)
!1995 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !1994)
!1996 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !1994)
!1997 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !1919)
!1998 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !1919)
!1999 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !1919)
!2000 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !1226)
!2001 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !1919)
!2002 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !1226)
!2003 = !DILocation(line: 0, scope: !1761, inlinedAt: !2004)
!2004 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !1226)
!2005 = distinct !DILexicalBlock(scope: !1904, file: !104, line: 447, column: 30)
!2006 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2004)
!2007 = distinct !DIAssignID()
!2008 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2004)
!2009 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2004)
!2010 = distinct !DIAssignID()
!2011 = distinct !DIAssignID()
!2012 = distinct !DIAssignID()
!2013 = distinct !DIAssignID()
!2014 = distinct !DIAssignID()
!2015 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2004)
!2016 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2004)
!2017 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2004)
!2018 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2004)
!2019 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2004)
!2020 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2004)
!2021 = distinct !DIAssignID()
!2022 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2004)
!2023 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2004)
!2024 = distinct !DIAssignID()
!2025 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2004)
!2026 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2004)
!2027 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !1226)
!2028 = !DILocation(line: 469, column: 27, scope: !2029)
!2029 = distinct !DILexicalBlock(scope: !1133, file: !104, line: 469, column: 6)
!2030 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !1226)
!2031 = !DILocation(line: 452, column: 16, scope: !1194, inlinedAt: !1226)
!2032 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !1226)
!2033 = !DILocalVariable(name: "ctx", arg: 1, scope: !2034, file: !104, line: 68, type: !1136)
!2034 = distinct !DISubprogram(name: "ctx_set_port", scope: !104, file: !104, line: 68, type: !2035, scopeLine: 69, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2037)
!2035 = !DISubroutineType(types: !2036)
!2036 = !{null, !1136, !92}
!2037 = !{!2033, !2038}
!2038 = !DILocalVariable(name: "dport", arg: 2, scope: !2034, file: !104, line: 68, type: !92)
!2039 = !DILocation(line: 0, scope: !2034, inlinedAt: !2040)
!2040 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !1226)
!2041 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2040)
!2042 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2040)
!2043 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !1226)
!2044 = !DILocation(line: 471, column: 3, scope: !2045)
!2045 = distinct !DILexicalBlock(scope: !2029, file: !104, line: 469, column: 46)
!2046 = !DILocation(line: 475, column: 1, scope: !1133)
!2047 = distinct !DISubprogram(name: "cil_sock4_sendmsg", scope: !104, file: !104, line: 627, type: !1134, scopeLine: 628, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2048)
!2048 = !{!2049, !2050}
!2049 = !DILocalVariable(name: "ctx", arg: 1, scope: !2047, file: !104, line: 627, type: !1136)
!2050 = !DILocalVariable(name: "err", scope: !2047, file: !104, line: 629, type: !305)
!2051 = distinct !DIAssignID()
!2052 = distinct !DIAssignID()
!2053 = distinct !DIAssignID()
!2054 = distinct !DIAssignID()
!2055 = distinct !DIAssignID()
!2056 = distinct !DIAssignID()
!2057 = distinct !DIAssignID()
!2058 = distinct !DIAssignID()
!2059 = distinct !DIAssignID()
!2060 = distinct !DIAssignID()
!2061 = distinct !DIAssignID()
!2062 = distinct !DIAssignID()
!2063 = distinct !DIAssignID()
!2064 = distinct !DIAssignID()
!2065 = distinct !DIAssignID()
!2066 = distinct !DIAssignID()
!2067 = distinct !DIAssignID()
!2068 = distinct !DIAssignID()
!2069 = !DILocation(line: 0, scope: !2047)
!2070 = !DILocation(line: 0, scope: !1194, inlinedAt: !2071)
!2071 = distinct !DILocation(line: 631, column: 8, scope: !2047)
!2072 = !DILocation(line: 0, scope: !1228, inlinedAt: !2073)
!2073 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !2071)
!2074 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2073)
!2075 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2073)
!2076 = !DILocation(line: 0, scope: !1240, inlinedAt: !2077)
!2077 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !2071)
!2078 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2077)
!2079 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2077)
!2080 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2077)
!2081 = distinct !DIAssignID()
!2082 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2077)
!2083 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2077)
!2084 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2077)
!2085 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !2071)
!2086 = !DILocation(line: 301, column: 23, scope: !1194, inlinedAt: !2071)
!2087 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !2071)
!2088 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !2071)
!2089 = distinct !DIAssignID()
!2090 = distinct !DIAssignID()
!2091 = distinct !DIAssignID()
!2092 = distinct !DIAssignID()
!2093 = distinct !DIAssignID()
!2094 = distinct !DIAssignID()
!2095 = !DILocation(line: 0, scope: !1285, inlinedAt: !2096)
!2096 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !2071)
!2097 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2096)
!2098 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2096)
!2099 = !DILocation(line: 0, scope: !1302, inlinedAt: !2100)
!2100 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2096)
!2101 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2100)
!2102 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2096)
!2103 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2096)
!2104 = !DILocation(line: 0, scope: !1313, inlinedAt: !2105)
!2105 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2096)
!2106 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2105)
!2107 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2105)
!2108 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2105)
!2109 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2096)
!2110 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2096)
!2111 = !DILocation(line: 0, scope: !1302, inlinedAt: !2112)
!2112 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2096)
!2113 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2112)
!2114 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !2071)
!2115 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !2071)
!2116 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !2071)
!2117 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !2071)
!2118 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !2071)
!2119 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !2071)
!2120 = !DILocation(line: 0, scope: !1218, inlinedAt: !2071)
!2121 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !2071)
!2122 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !2071)
!2123 = !DILocation(line: 0, scope: !1347, inlinedAt: !2124)
!2124 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !2071)
!2125 = !DILocation(line: 0, scope: !1355, inlinedAt: !2126)
!2126 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !2124)
!2127 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !2126)
!2128 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !2126)
!2129 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !2126)
!2130 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !2124)
!2131 = !DILocation(line: 0, scope: !1366, inlinedAt: !2132)
!2132 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !2124)
!2133 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !2132)
!2134 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !2132)
!2135 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !2124)
!2136 = !DILocation(line: 0, scope: !1355, inlinedAt: !2137)
!2137 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !2124)
!2138 = !DILocation(line: 0, scope: !1376, inlinedAt: !2139)
!2139 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !2124)
!2140 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !2139)
!2141 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !2139)
!2142 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !2139)
!2143 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !2124)
!2144 = !DILocation(line: 0, scope: !1220, inlinedAt: !2071)
!2145 = !DILocation(line: 0, scope: !1386, inlinedAt: !2146)
!2146 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !2071)
!2147 = !DILocation(line: 0, scope: !1392, inlinedAt: !2148)
!2148 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !2146)
!2149 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !2148)
!2150 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !2148)
!2151 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !2148)
!2152 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !2146)
!2153 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !2146)
!2154 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !2146)
!2155 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !2071)
!2156 = !DILocation(line: 0, scope: !1404, inlinedAt: !2157)
!2157 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !2071)
!2158 = !DILocation(line: 0, scope: !1418, inlinedAt: !2159)
!2159 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !2157)
!2160 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !2159)
!2161 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !2159)
!2162 = !DILocation(line: 0, scope: !1392, inlinedAt: !2163)
!2163 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !2157)
!2164 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !2157)
!2165 = !DILocation(line: 0, scope: !1428, inlinedAt: !2166)
!2166 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !2157)
!2167 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !2166)
!2168 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !2166)
!2169 = distinct !DIAssignID()
!2170 = distinct !DIAssignID()
!2171 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !2166)
!2172 = distinct !DIAssignID()
!2173 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !2166)
!2174 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !2166)
!2175 = distinct !DIAssignID()
!2176 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !2166)
!2177 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !2166)
!2178 = distinct !DIAssignID()
!2179 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !2166)
!2180 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !2166)
!2181 = distinct !DIAssignID()
!2182 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !2166)
!2183 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !2166)
!2184 = !DILocation(line: 0, scope: !1410, inlinedAt: !2157)
!2185 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !2157)
!2186 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !2157)
!2187 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !2157)
!2188 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !2157)
!2189 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !2157)
!2190 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !2071)
!2191 = !DILocation(line: 0, scope: !1223, inlinedAt: !2071)
!2192 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !2071)
!2193 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !2071)
!2194 = !DILocation(line: 0, scope: !1476, inlinedAt: !2195)
!2195 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !2071)
!2196 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !2195)
!2197 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !2195)
!2198 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !2195)
!2199 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !2071)
!2200 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !2071)
!2201 = !DILocation(line: 0, scope: !1486, inlinedAt: !2202)
!2202 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !2071)
!2203 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !2202)
!2204 = !DILocation(line: 0, scope: !1498, inlinedAt: !2205)
!2205 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !2202)
!2206 = !DILocation(line: 0, scope: !1508, inlinedAt: !2207)
!2207 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !2205)
!2208 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !2207)
!2209 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !2207)
!2210 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !2207)
!2211 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !2202)
!2212 = distinct !DIAssignID()
!2213 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !2202)
!2214 = distinct !DIAssignID()
!2215 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !2202)
!2216 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !2202)
!2217 = distinct !DIAssignID()
!2218 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !2202)
!2219 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !2202)
!2220 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !2202)
!2221 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !2071)
!2222 = !DILocation(line: 0, scope: !1554, inlinedAt: !2223)
!2223 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !2071)
!2224 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !2223)
!2225 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !2223)
!2226 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !2223)
!2227 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !2071)
!2228 = !DILocation(line: 0, scope: !1564, inlinedAt: !2229)
!2229 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !2071)
!2230 = !DILocation(line: 0, scope: !1574, inlinedAt: !2231)
!2231 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !2229)
!2232 = !DILocation(line: 0, scope: !1585, inlinedAt: !2231)
!2233 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !2231)
!2234 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !2231)
!2235 = distinct !DIAssignID()
!2236 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !2231)
!2237 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !2231)
!2238 = distinct !DIAssignID()
!2239 = distinct !DIAssignID()
!2240 = distinct !DIAssignID()
!2241 = distinct !DIAssignID()
!2242 = distinct !DIAssignID()
!2243 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !2231)
!2244 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !2231)
!2245 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !2231)
!2246 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !2231)
!2247 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !2071)
!2248 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !2249)
!2249 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !2231)
!2250 = !DILocation(line: 0, scope: !1617, inlinedAt: !2249)
!2251 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !2249)
!2252 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !2249)
!2253 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !2249)
!2254 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !2249)
!2255 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !2249)
!2256 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !2257)
!2257 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !2249)
!2258 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !2257)
!2259 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !2249)
!2260 = !DILocation(line: 0, scope: !1619, inlinedAt: !2249)
!2261 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !2231)
!2262 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !2231)
!2263 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !2231)
!2264 = distinct !DIAssignID()
!2265 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !2231)
!2266 = distinct !DIAssignID()
!2267 = distinct !DIAssignID()
!2268 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2231)
!2269 = !DILocation(line: 0, scope: !1589, inlinedAt: !2231)
!2270 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2271)
!2271 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2231)
!2272 = !DILocation(line: 0, scope: !1659, inlinedAt: !2273)
!2273 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !2231)
!2274 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !2273)
!2275 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !2273)
!2276 = !DILocation(line: 0, scope: !1668, inlinedAt: !2277)
!2277 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2231)
!2278 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !2277)
!2279 = !DILocation(line: 0, scope: !1673, inlinedAt: !2277)
!2280 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !2277)
!2281 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !2277)
!2282 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !2277)
!2283 = !DILocation(line: 0, scope: !1676, inlinedAt: !2277)
!2284 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !2277)
!2285 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !2277)
!2286 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !2277)
!2287 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !2277)
!2288 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2231)
!2289 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !2231)
!2290 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !2231)
!2291 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !2231)
!2292 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !2231)
!2293 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !2231)
!2294 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !2231)
!2295 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !2231)
!2296 = !DILocation(line: 0, scope: !1592, inlinedAt: !2231)
!2297 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2231)
!2298 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2299)
!2299 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2231)
!2300 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !2231)
!2301 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !2071)
!2302 = !DILocation(line: 0, scope: !1708, inlinedAt: !2303)
!2303 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !2071)
!2304 = distinct !DIAssignID()
!2305 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !2303)
!2306 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !2303)
!2307 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !2071)
!2308 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !2071)
!2309 = !DILocation(line: 0, scope: !1714, inlinedAt: !2071)
!2310 = !DILocation(line: 0, scope: !1724, inlinedAt: !2311)
!2311 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !2071)
!2312 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !2311)
!2313 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !2311)
!2314 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !2311)
!2315 = !DILocation(line: 0, scope: !1736, inlinedAt: !2316)
!2316 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !2311)
!2317 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2316)
!2318 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !2071)
!2319 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !2071)
!2320 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !2071)
!2321 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !2071)
!2322 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !2071)
!2323 = distinct !DIAssignID()
!2324 = !DILocation(line: 0, scope: !1750, inlinedAt: !2325)
!2325 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !2071)
!2326 = !DILocation(line: 0, scope: !1302, inlinedAt: !2327)
!2327 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !2325)
!2328 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2327)
!2329 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !2071)
!2330 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !2071)
!2331 = !DILocation(line: 0, scope: !1761, inlinedAt: !2332)
!2332 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !2071)
!2333 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2332)
!2334 = distinct !DIAssignID()
!2335 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2332)
!2336 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2332)
!2337 = distinct !DIAssignID()
!2338 = distinct !DIAssignID()
!2339 = distinct !DIAssignID()
!2340 = distinct !DIAssignID()
!2341 = distinct !DIAssignID()
!2342 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2332)
!2343 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2332)
!2344 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2332)
!2345 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2332)
!2346 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2332)
!2347 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2332)
!2348 = distinct !DIAssignID()
!2349 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2332)
!2350 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2332)
!2351 = distinct !DIAssignID()
!2352 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2332)
!2353 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2332)
!2354 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !2071)
!2355 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !2071)
!2356 = !DILocation(line: 0, scope: !1708, inlinedAt: !2357)
!2357 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !2071)
!2358 = distinct !DIAssignID()
!2359 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !2357)
!2360 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !2357)
!2361 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !2071)
!2362 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !2071)
!2363 = !DILocation(line: 0, scope: !1761, inlinedAt: !2364)
!2364 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !2071)
!2365 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2364)
!2366 = distinct !DIAssignID()
!2367 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2364)
!2368 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2364)
!2369 = distinct !DIAssignID()
!2370 = distinct !DIAssignID()
!2371 = distinct !DIAssignID()
!2372 = distinct !DIAssignID()
!2373 = distinct !DIAssignID()
!2374 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2364)
!2375 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2364)
!2376 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2364)
!2377 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2364)
!2378 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2364)
!2379 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2364)
!2380 = distinct !DIAssignID()
!2381 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2364)
!2382 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2364)
!2383 = distinct !DIAssignID()
!2384 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2364)
!2385 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2364)
!2386 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !2071)
!2387 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !2071)
!2388 = !DILocation(line: 0, scope: !1554, inlinedAt: !2389)
!2389 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !2071)
!2390 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !2389)
!2391 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !2389)
!2392 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !2389)
!2393 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !2071)
!2394 = !DILocation(line: 0, scope: !1847, inlinedAt: !2395)
!2395 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2071)
!2396 = !DILocation(line: 0, scope: !1856, inlinedAt: !2397)
!2397 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !2395)
!2398 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !2399)
!2399 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !2397)
!2400 = !DILocation(line: 0, scope: !1617, inlinedAt: !2399)
!2401 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !2399)
!2402 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !2399)
!2403 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !2399)
!2404 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !2399)
!2405 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !2399)
!2406 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !2407)
!2407 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !2399)
!2408 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !2407)
!2409 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !2399)
!2410 = !DILocation(line: 0, scope: !1619, inlinedAt: !2399)
!2411 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !2397)
!2412 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !2397)
!2413 = distinct !DIAssignID()
!2414 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !2397)
!2415 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !2397)
!2416 = distinct !DIAssignID()
!2417 = distinct !DIAssignID()
!2418 = distinct !DIAssignID()
!2419 = distinct !DIAssignID()
!2420 = distinct !DIAssignID()
!2421 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !2397)
!2422 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !2397)
!2423 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !2397)
!2424 = distinct !DIAssignID()
!2425 = distinct !DIAssignID()
!2426 = distinct !DIAssignID()
!2427 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !2397)
!2428 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !2397)
!2429 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2071)
!2430 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !2071)
!2431 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !2071)
!2432 = !DILocation(line: 0, scope: !1906, inlinedAt: !2433)
!2433 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !2071)
!2434 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !2433)
!2435 = distinct !DIAssignID()
!2436 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !2433)
!2437 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !2433)
!2438 = distinct !DIAssignID()
!2439 = distinct !DIAssignID()
!2440 = !DILocation(line: 0, scope: !1736, inlinedAt: !2441)
!2441 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !2433)
!2442 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2441)
!2443 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !2433)
!2444 = distinct !DIAssignID()
!2445 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !2433)
!2446 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !2433)
!2447 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !2433)
!2448 = distinct !DIAssignID()
!2449 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !2433)
!2450 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !2433)
!2451 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !2433)
!2452 = distinct !DIAssignID()
!2453 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !2433)
!2454 = distinct !DIAssignID()
!2455 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !2433)
!2456 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !2433)
!2457 = distinct !DIAssignID()
!2458 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !2433)
!2459 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !2433)
!2460 = distinct !DIAssignID()
!2461 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !2433)
!2462 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !2433)
!2463 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !2433)
!2464 = !DILocation(line: 0, scope: !1963, inlinedAt: !2465)
!2465 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !2433)
!2466 = !DILocation(line: 0, scope: !1972, inlinedAt: !2467)
!2467 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !2465)
!2468 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !2467)
!2469 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !2467)
!2470 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !2433)
!2471 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !2433)
!2472 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !2433)
!2473 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !2071)
!2474 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !2433)
!2475 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !2071)
!2476 = !DILocation(line: 0, scope: !1761, inlinedAt: !2477)
!2477 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !2071)
!2478 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2477)
!2479 = distinct !DIAssignID()
!2480 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2477)
!2481 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2477)
!2482 = distinct !DIAssignID()
!2483 = distinct !DIAssignID()
!2484 = distinct !DIAssignID()
!2485 = distinct !DIAssignID()
!2486 = distinct !DIAssignID()
!2487 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2477)
!2488 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2477)
!2489 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2477)
!2490 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2477)
!2491 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2477)
!2492 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2477)
!2493 = distinct !DIAssignID()
!2494 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2477)
!2495 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2477)
!2496 = distinct !DIAssignID()
!2497 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2477)
!2498 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2477)
!2499 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !2071)
!2500 = !DILocation(line: 632, column: 27, scope: !2501)
!2501 = distinct !DILexicalBlock(scope: !2047, file: !104, line: 632, column: 6)
!2502 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !2071)
!2503 = !DILocation(line: 452, column: 16, scope: !1194, inlinedAt: !2071)
!2504 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !2071)
!2505 = !DILocation(line: 0, scope: !2034, inlinedAt: !2506)
!2506 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !2071)
!2507 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2506)
!2508 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2506)
!2509 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !2071)
!2510 = !DILocation(line: 634, column: 3, scope: !2511)
!2511 = distinct !DILexicalBlock(scope: !2501, file: !104, line: 632, column: 46)
!2512 = !DILocation(line: 638, column: 1, scope: !2047)
!2513 = distinct !DISubprogram(name: "cil_sock4_recvmsg", scope: !104, file: !104, line: 641, type: !1134, scopeLine: 642, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2514)
!2514 = !{!2515}
!2515 = !DILocalVariable(name: "ctx", arg: 1, scope: !2513, file: !104, line: 641, type: !1136)
!2516 = distinct !DIAssignID()
!2517 = distinct !DIAssignID()
!2518 = distinct !DIAssignID()
!2519 = distinct !DIAssignID()
!2520 = distinct !DIAssignID()
!2521 = !DILocation(line: 0, scope: !2513)
!2522 = !DILocalVariable(name: "key", scope: !2523, file: !104, line: 587, type: !955)
!2523 = distinct !DISubprogram(name: "__sock4_xlate_rev", scope: !104, file: !104, line: 580, type: !2524, scopeLine: 582, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2526)
!2524 = !DISubroutineType(types: !2525)
!2525 = !{!305, !1136, !1136}
!2526 = !{!2527, !2528, !2529, !2530, !2531, !2532, !2522, !2533, !2536}
!2527 = !DILocalVariable(name: "ctx", arg: 1, scope: !2523, file: !104, line: 580, type: !1136)
!2528 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !2523, file: !104, line: 581, type: !1136)
!2529 = !DILocalVariable(name: "val", scope: !2523, file: !104, line: 583, type: !962)
!2530 = !DILocalVariable(name: "dst_port", scope: !2523, file: !104, line: 584, type: !85)
!2531 = !DILocalVariable(name: "protocol", scope: !2523, file: !104, line: 585, type: !84)
!2532 = !DILocalVariable(name: "dst_ip", scope: !2523, file: !104, line: 586, type: !82)
!2533 = !DILocalVariable(name: "svc", scope: !2534, file: !104, line: 597, type: !1209)
!2534 = distinct !DILexicalBlock(scope: !2535, file: !104, line: 596, column: 11)
!2535 = distinct !DILexicalBlock(scope: !2523, file: !104, line: 596, column: 6)
!2536 = !DILocalVariable(name: "svc_key", scope: !2534, file: !104, line: 598, type: !746)
!2537 = !DILocation(line: 0, scope: !2523, inlinedAt: !2538)
!2538 = distinct !DILocation(line: 643, column: 2, scope: !2513)
!2539 = !DILocation(line: 0, scope: !2534, inlinedAt: !2538)
!2540 = !DILocation(line: 0, scope: !1240, inlinedAt: !2541)
!2541 = distinct !DILocation(line: 584, column: 19, scope: !2523, inlinedAt: !2538)
!2542 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2541)
!2543 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2541)
!2544 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2541)
!2545 = distinct !DIAssignID()
!2546 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2541)
!2547 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2541)
!2548 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2541)
!2549 = !DILocation(line: 585, column: 18, scope: !2523, inlinedAt: !2538)
!2550 = !DILocation(line: 586, column: 22, scope: !2523, inlinedAt: !2538)
!2551 = !DILocation(line: 587, column: 2, scope: !2523, inlinedAt: !2538)
!2552 = !DILocation(line: 0, scope: !1736, inlinedAt: !2553)
!2553 = distinct !DILocation(line: 588, column: 14, scope: !2523, inlinedAt: !2538)
!2554 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2553)
!2555 = !DILocation(line: 587, column: 33, scope: !2523, inlinedAt: !2538)
!2556 = distinct !DIAssignID()
!2557 = distinct !DIAssignID()
!2558 = distinct !DIAssignID()
!2559 = !{!1931, !1266, i64 14}
!2560 = distinct !DIAssignID()
!2561 = !DILocation(line: 595, column: 8, scope: !2523, inlinedAt: !2538)
!2562 = !DILocation(line: 596, column: 6, scope: !2535, inlinedAt: !2538)
!2563 = !DILocation(line: 596, column: 6, scope: !2523, inlinedAt: !2538)
!2564 = !DILocation(line: 598, column: 3, scope: !2534, inlinedAt: !2538)
!2565 = !DILocation(line: 599, column: 20, scope: !2534, inlinedAt: !2538)
!2566 = !DILocation(line: 598, column: 28, scope: !2534, inlinedAt: !2538)
!2567 = distinct !DIAssignID()
!2568 = !DILocation(line: 600, column: 19, scope: !2534, inlinedAt: !2538)
!2569 = distinct !DIAssignID()
!2570 = distinct !DIAssignID()
!2571 = distinct !DIAssignID()
!2572 = distinct !DIAssignID()
!2573 = distinct !DIAssignID()
!2574 = distinct !DIAssignID()
!2575 = !DILocation(line: 0, scope: !1285, inlinedAt: !2576)
!2576 = distinct !DILocation(line: 604, column: 9, scope: !2534, inlinedAt: !2538)
!2577 = distinct !DIAssignID()
!2578 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2576)
!2579 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2576)
!2580 = !DILocation(line: 0, scope: !1302, inlinedAt: !2581)
!2581 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2576)
!2582 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2581)
!2583 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2576)
!2584 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2576)
!2585 = !DILocation(line: 0, scope: !1313, inlinedAt: !2586)
!2586 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2576)
!2587 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2586)
!2588 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2586)
!2589 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2586)
!2590 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2576)
!2591 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2576)
!2592 = !DILocation(line: 0, scope: !1302, inlinedAt: !2593)
!2593 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2576)
!2594 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2593)
!2595 = !DILocation(line: 605, column: 8, scope: !2596, inlinedAt: !2538)
!2596 = distinct !DILexicalBlock(scope: !2534, file: !104, line: 605, column: 7)
!2597 = !DILocation(line: 605, column: 7, scope: !2534, inlinedAt: !2538)
!2598 = !DILocation(line: 0, scope: !1228, inlinedAt: !2599)
!2599 = distinct !DILocation(line: 607, column: 7, scope: !2600, inlinedAt: !2538)
!2600 = distinct !DILexicalBlock(scope: !2596, file: !104, line: 605, column: 13)
!2601 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2599)
!2602 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2599)
!2603 = !DILocation(line: 90, column: 41, scope: !1228, inlinedAt: !2599)
!2604 = !DILocation(line: 609, column: 20, scope: !2605, inlinedAt: !2538)
!2605 = distinct !DILexicalBlock(scope: !2534, file: !104, line: 609, column: 7)
!2606 = !DILocation(line: 609, column: 42, scope: !2605, inlinedAt: !2538)
!2607 = !DILocation(line: 609, column: 34, scope: !2605, inlinedAt: !2538)
!2608 = !DILocation(line: 609, column: 56, scope: !2605, inlinedAt: !2538)
!2609 = !DILocation(line: 610, column: 13, scope: !2605, inlinedAt: !2538)
!2610 = !DILocation(line: 610, column: 19, scope: !2605, inlinedAt: !2538)
!2611 = !DILocation(line: 610, column: 24, scope: !2605, inlinedAt: !2538)
!2612 = !DILocation(line: 611, column: 4, scope: !2613, inlinedAt: !2538)
!2613 = distinct !DILexicalBlock(scope: !2605, file: !104, line: 610, column: 62)
!2614 = !DILocation(line: 0, scope: !1761, inlinedAt: !2615)
!2615 = distinct !DILocation(line: 612, column: 4, scope: !2613, inlinedAt: !2538)
!2616 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2615)
!2617 = distinct !DIAssignID()
!2618 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2615)
!2619 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2615)
!2620 = distinct !DIAssignID()
!2621 = distinct !DIAssignID()
!2622 = distinct !DIAssignID()
!2623 = distinct !DIAssignID()
!2624 = distinct !DIAssignID()
!2625 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2615)
!2626 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2615)
!2627 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2615)
!2628 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2615)
!2629 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2615)
!2630 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2615)
!2631 = distinct !DIAssignID()
!2632 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2615)
!2633 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2615)
!2634 = distinct !DIAssignID()
!2635 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2615)
!2636 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2615)
!2637 = !DILocation(line: 613, column: 4, scope: !2613, inlinedAt: !2538)
!2638 = !DILocation(line: 616, column: 24, scope: !2534, inlinedAt: !2538)
!2639 = !DILocation(line: 616, column: 17, scope: !2534, inlinedAt: !2538)
!2640 = !DILocation(line: 617, column: 26, scope: !2534, inlinedAt: !2538)
!2641 = !DILocation(line: 0, scope: !2034, inlinedAt: !2642)
!2642 = distinct !DILocation(line: 617, column: 3, scope: !2534, inlinedAt: !2538)
!2643 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2642)
!2644 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2642)
!2645 = !DILocation(line: 620, column: 3, scope: !2534, inlinedAt: !2538)
!2646 = !DILocation(line: 621, column: 2, scope: !2535, inlinedAt: !2538)
!2647 = !DILocation(line: 624, column: 1, scope: !2523, inlinedAt: !2538)
!2648 = !DILocation(line: 644, column: 2, scope: !2513)
!2649 = distinct !DISubprogram(name: "cil_sock6_connect", scope: !104, file: !104, line: 1162, type: !1134, scopeLine: 1163, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2650)
!2650 = !{!2651, !2652}
!2651 = !DILocalVariable(name: "ctx", arg: 1, scope: !2649, file: !104, line: 1162, type: !1136)
!2652 = !DILocalVariable(name: "err", scope: !2649, file: !104, line: 1164, type: !305)
!2653 = distinct !DIAssignID()
!2654 = distinct !DIAssignID()
!2655 = distinct !DIAssignID()
!2656 = distinct !DIAssignID()
!2657 = distinct !DIAssignID()
!2658 = distinct !DIAssignID()
!2659 = distinct !DIAssignID()
!2660 = distinct !DIAssignID()
!2661 = distinct !DIAssignID()
!2662 = distinct !DIAssignID()
!2663 = distinct !DIAssignID()
!2664 = distinct !DIAssignID()
!2665 = distinct !DIAssignID()
!2666 = distinct !DIAssignID()
!2667 = distinct !DIAssignID()
!2668 = distinct !DIAssignID()
!2669 = distinct !DIAssignID()
!2670 = distinct !DIAssignID()
!2671 = distinct !DIAssignID()
!2672 = distinct !DIAssignID()
!2673 = distinct !DIAssignID()
!2674 = distinct !DIAssignID()
!2675 = distinct !DIAssignID()
!2676 = distinct !DIAssignID()
!2677 = distinct !DIAssignID()
!2678 = distinct !DIAssignID()
!2679 = distinct !DIAssignID()
!2680 = distinct !DIAssignID()
!2681 = distinct !DIAssignID()
!2682 = distinct !DIAssignID()
!2683 = distinct !DIAssignID()
!2684 = distinct !DIAssignID()
!2685 = distinct !DIAssignID()
!2686 = distinct !DIAssignID()
!2687 = distinct !DIAssignID()
!2688 = distinct !DIAssignID()
!2689 = distinct !DIAssignID()
!2690 = !DILocation(line: 0, scope: !2649)
!2691 = !DILocalVariable(name: "key", scope: !2692, file: !104, line: 1040, type: !579, align: 64)
!2692 = distinct !DISubprogram(name: "__sock6_xlate_fwd", scope: !104, file: !104, line: 1028, type: !2693, scopeLine: 1031, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2695)
!2693 = !DISubroutineType(types: !2694)
!2694 = !{!305, !1136, !1197, !1197}
!2695 = !{!2696, !2697, !2698, !2699, !2700, !2701, !2704, !2707, !2708, !2709, !2691, !2710, !2711, !2712, !2713, !2718}
!2696 = !DILocalVariable(name: "ctx", arg: 1, scope: !2692, file: !104, line: 1028, type: !1136)
!2697 = !DILocalVariable(name: "udp_only", arg: 2, scope: !2692, file: !104, line: 1029, type: !1197)
!2698 = !DILocalVariable(name: "is_connect", arg: 3, scope: !2692, file: !104, line: 1030, type: !1197)
!2699 = !DILocalVariable(name: "id", scope: !2692, file: !104, line: 1033, type: !636)
!2700 = !DILocalVariable(name: "in_hostns", scope: !2692, file: !104, line: 1034, type: !1197)
!2701 = !DILocalVariable(name: "backend", scope: !2692, file: !104, line: 1035, type: !2702)
!2702 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2703, size: 64)
!2703 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !614)
!2704 = !DILocalVariable(name: "svc", scope: !2692, file: !104, line: 1036, type: !2705)
!2705 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2706, size: 64)
!2706 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !590)
!2707 = !DILocalVariable(name: "dst_port", scope: !2692, file: !104, line: 1037, type: !92)
!2708 = !DILocalVariable(name: "protocol", scope: !2692, file: !104, line: 1038, type: !84)
!2709 = !DILocalVariable(name: "dst_ip", scope: !2692, file: !104, line: 1039, type: !160, align: 64)
!2710 = !DILocalVariable(name: "backend_slot", scope: !2692, file: !104, line: 1044, type: !2705)
!2711 = !DILocalVariable(name: "backend_from_affinity", scope: !2692, file: !104, line: 1045, type: !90)
!2712 = !DILocalVariable(name: "backend_id", scope: !2692, file: !104, line: 1046, type: !82)
!2713 = !DILocalVariable(name: "out", scope: !2714, file: !104, line: 1067, type: !91)
!2714 = distinct !DILexicalBlock(scope: !2715, file: !104, line: 1067, column: 7)
!2715 = distinct !DILexicalBlock(scope: !2716, file: !104, line: 1067, column: 7)
!2716 = distinct !DILexicalBlock(scope: !2717, file: !104, line: 1065, column: 59)
!2717 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1065, column: 6)
!2718 = !DILocalVariable(name: "out", scope: !2719, file: !104, line: 1082, type: !91)
!2719 = distinct !DILexicalBlock(scope: !2720, file: !104, line: 1082, column: 6)
!2720 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1082, column: 6)
!2721 = !DILocation(line: 0, scope: !2692, inlinedAt: !2722)
!2722 = distinct !DILocation(line: 1171, column: 8, scope: !2649)
!2723 = !DILocation(line: 0, scope: !1228, inlinedAt: !2724)
!2724 = distinct !DILocation(line: 1034, column: 25, scope: !2692, inlinedAt: !2722)
!2725 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2724)
!2726 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2724)
!2727 = !DILocation(line: 0, scope: !1240, inlinedAt: !2728)
!2728 = distinct !DILocation(line: 1037, column: 20, scope: !2692, inlinedAt: !2722)
!2729 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2728)
!2730 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2728)
!2731 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2728)
!2732 = distinct !DIAssignID()
!2733 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2728)
!2734 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2728)
!2735 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2728)
!2736 = !DILocation(line: 1038, column: 18, scope: !2692, inlinedAt: !2722)
!2737 = !DILocation(line: 1040, column: 2, scope: !2692, inlinedAt: !2722)
!2738 = !DILocation(line: 1040, column: 17, scope: !2692, inlinedAt: !2722)
!2739 = distinct !DIAssignID()
!2740 = distinct !DIAssignID()
!2741 = !DILocation(line: 1040, column: 39, scope: !2692, inlinedAt: !2722)
!2742 = !{!2743, !1266, i64 16}
!2743 = !{!"lb6_key", !1131, i64 0, !1266, i64 16, !1266, i64 18, !1131, i64 20, !1131, i64 21, !1131, i64 22}
!2744 = distinct !DIAssignID()
!2745 = !{!2743, !1131, i64 20}
!2746 = distinct !DIAssignID()
!2747 = !DILocation(line: 0, scope: !1276, inlinedAt: !2748)
!2748 = distinct !DILocation(line: 1054, column: 20, scope: !2749, inlinedAt: !2722)
!2749 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1054, column: 6)
!2750 = !DILocation(line: 132, column: 2, scope: !1276, inlinedAt: !2748)
!2751 = !DILocalVariable(name: "ctx", arg: 1, scope: !2752, file: !104, line: 713, type: !1243)
!2752 = distinct !DISubprogram(name: "ctx_get_v6_address", scope: !104, file: !104, line: 713, type: !2753, scopeLine: 715, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2756)
!2753 = !DISubroutineType(types: !2754)
!2754 = !{null, !1243, !2755}
!2755 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !160, size: 64)
!2756 = !{!2751, !2757}
!2757 = !DILocalVariable(name: "addr", arg: 2, scope: !2752, file: !104, line: 714, type: !2755)
!2758 = !DILocation(line: 0, scope: !2752, inlinedAt: !2759)
!2759 = distinct !DILocation(line: 1057, column: 2, scope: !2692, inlinedAt: !2722)
!2760 = !DILocation(line: 716, column: 18, scope: !2752, inlinedAt: !2759)
!2761 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !2759)
!2762 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !2759)
!2763 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !2759)
!2764 = !{i64 2148418536}
!2765 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !2759)
!2766 = !DILocation(line: 718, column: 8, scope: !2752, inlinedAt: !2759)
!2767 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !2759)
!2768 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !2759)
!2769 = !{i64 2148418571}
!2770 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !2759)
!2771 = !DILocation(line: 720, column: 8, scope: !2752, inlinedAt: !2759)
!2772 = !DILocation(line: 720, column: 11, scope: !2752, inlinedAt: !2759)
!2773 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !2759)
!2774 = !{i64 2148418606}
!2775 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !2759)
!2776 = !DILocation(line: 722, column: 8, scope: !2752, inlinedAt: !2759)
!2777 = !DILocation(line: 722, column: 11, scope: !2752, inlinedAt: !2759)
!2778 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !2759)
!2779 = !{i64 2148418641}
!2780 = !DILocalVariable(name: "dst", arg: 1, scope: !2781, file: !161, line: 26, type: !2755)
!2781 = distinct !DISubprogram(name: "ipv6_addr_copy", scope: !161, file: !161, line: 26, type: !2782, scopeLine: 28, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2786)
!2782 = !DISubroutineType(types: !2783)
!2783 = !{null, !2755, !2784}
!2784 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2785, size: 64)
!2785 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !160)
!2786 = !{!2780, !2787}
!2787 = !DILocalVariable(name: "src", arg: 2, scope: !2781, file: !161, line: 27, type: !2784)
!2788 = !DILocation(line: 0, scope: !2781, inlinedAt: !2789)
!2789 = distinct !DILocation(line: 1058, column: 2, scope: !2692, inlinedAt: !2722)
!2790 = !DILocalVariable(name: "d", arg: 1, scope: !2791, file: !1499, line: 277, type: !91)
!2791 = distinct !DISubprogram(name: "memcpy", scope: !1499, file: !1499, line: 277, type: !2792, scopeLine: 279, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2794)
!2792 = !DISubroutineType(types: !2793)
!2793 = !{null, !91, !1013, !95}
!2794 = !{!2790, !2795, !2796}
!2795 = !DILocalVariable(name: "s", arg: 2, scope: !2791, file: !1499, line: 277, type: !1013)
!2796 = !DILocalVariable(name: "len", arg: 3, scope: !2791, file: !1499, line: 278, type: !95)
!2797 = !DILocation(line: 0, scope: !2791, inlinedAt: !2798)
!2798 = distinct !DILocation(line: 29, column: 2, scope: !2781, inlinedAt: !2789)
!2799 = !DILocalVariable(name: "len", arg: 3, scope: !2800, file: !1499, line: 168, type: !95)
!2800 = distinct !DISubprogram(name: "__bpf_memcpy", scope: !1499, file: !1499, line: 168, type: !2792, scopeLine: 169, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2801)
!2801 = !{!2802, !2803, !2799, !2804, !2806, !2807, !2808, !2809, !2810, !2811, !2812, !2813, !2814, !2815, !2816, !2817, !2818, !2819}
!2802 = !DILocalVariable(name: "d", arg: 1, scope: !2800, file: !1499, line: 168, type: !91)
!2803 = !DILocalVariable(name: "s", arg: 2, scope: !2800, file: !1499, line: 168, type: !1013)
!2804 = !DILabel(scope: !2805, name: "jmp_120", file: !1499, line: 183)
!2805 = distinct !DILexicalBlock(scope: !2800, file: !1499, line: 181, column: 15)
!2806 = !DILabel(scope: !2805, name: "jmp_112", file: !1499, line: 184)
!2807 = !DILabel(scope: !2805, name: "jmp_104", file: !1499, line: 185)
!2808 = !DILabel(scope: !2805, name: "jmp_96", file: !1499, line: 186)
!2809 = !DILabel(scope: !2805, name: "jmp_88", file: !1499, line: 187)
!2810 = !DILabel(scope: !2805, name: "jmp_80", file: !1499, line: 188)
!2811 = !DILabel(scope: !2805, name: "jmp_72", file: !1499, line: 189)
!2812 = !DILabel(scope: !2805, name: "jmp_64", file: !1499, line: 190)
!2813 = !DILabel(scope: !2805, name: "jmp_56", file: !1499, line: 191)
!2814 = !DILabel(scope: !2805, name: "jmp_48", file: !1499, line: 192)
!2815 = !DILabel(scope: !2805, name: "jmp_40", file: !1499, line: 193)
!2816 = !DILabel(scope: !2805, name: "jmp_32", file: !1499, line: 194)
!2817 = !DILabel(scope: !2805, name: "jmp_24", file: !1499, line: 195)
!2818 = !DILabel(scope: !2805, name: "jmp_16", file: !1499, line: 196)
!2819 = !DILabel(scope: !2805, name: "jmp_8", file: !1499, line: 197)
!2820 = !DILocation(line: 0, scope: !2800, inlinedAt: !2821)
!2821 = distinct !DILocation(line: 280, column: 9, scope: !2791, inlinedAt: !2798)
!2822 = !DILocation(line: 196, column: 12, scope: !2805, inlinedAt: !2821)
!2823 = !DILocation(line: 196, column: 21, scope: !2805, inlinedAt: !2821)
!2824 = !DILocation(line: 197, column: 12, scope: !2805, inlinedAt: !2821)
!2825 = !DILocation(line: 197, column: 21, scope: !2805, inlinedAt: !2821)
!2826 = !DILocalVariable(name: "dport", scope: !2827, file: !56, line: 978, type: !85)
!2827 = distinct !DISubprogram(name: "lb6_lookup_service", scope: !56, file: !56, line: 975, type: !2828, scopeLine: 976, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2830)
!2828 = !DISubroutineType(types: !2829)
!2829 = !{!2705, !578, !1197}
!2830 = !{!2831, !2832, !2833, !2826, !2834}
!2831 = !DILocalVariable(name: "key", arg: 1, scope: !2827, file: !56, line: 975, type: !578)
!2832 = !DILocalVariable(name: "east_west", arg: 2, scope: !2827, file: !56, line: 975, type: !1197)
!2833 = !DILocalVariable(name: "svc", scope: !2827, file: !56, line: 977, type: !2705)
!2834 = !DILocalVariable(name: "proto", scope: !2827, file: !56, line: 979, type: !84)
!2835 = distinct !DIAssignID()
!2836 = !DILocation(line: 0, scope: !2827, inlinedAt: !2837)
!2837 = distinct !DILocation(line: 1060, column: 8, scope: !2692, inlinedAt: !2722)
!2838 = distinct !DIAssignID()
!2839 = !DILocation(line: 981, column: 7, scope: !2827, inlinedAt: !2837)
!2840 = !DILocation(line: 981, column: 20, scope: !2827, inlinedAt: !2837)
!2841 = !{!2743, !1266, i64 18}
!2842 = !DILocation(line: 983, column: 7, scope: !2827, inlinedAt: !2837)
!2843 = !DILocation(line: 983, column: 13, scope: !2827, inlinedAt: !2837)
!2844 = !{!2743, !1131, i64 21}
!2845 = !DILocalVariable(name: "key", arg: 1, scope: !2846, file: !56, line: 945, type: !578)
!2846 = distinct !DISubprogram(name: "__lb6_lookup_service", scope: !56, file: !56, line: 945, type: !2847, scopeLine: 946, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2849)
!2847 = !DISubroutineType(types: !2848)
!2848 = !{!2705, !578}
!2849 = !{!2845}
!2850 = !DILocation(line: 0, scope: !2846, inlinedAt: !2851)
!2851 = distinct !DILocation(line: 984, column: 8, scope: !2827, inlinedAt: !2837)
!2852 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !2851)
!2853 = !DILocation(line: 985, column: 7, scope: !2854, inlinedAt: !2837)
!2854 = distinct !DILexicalBlock(scope: !2827, file: !56, line: 985, column: 6)
!2855 = !DILocation(line: 985, column: 6, scope: !2827, inlinedAt: !2837)
!2856 = !DILocalVariable(name: "svc", arg: 1, scope: !2857, file: !56, line: 511, type: !2705)
!2857 = distinct !DISubprogram(name: "lb6_svc_is_two_scopes", scope: !56, file: !56, line: 511, type: !2858, scopeLine: 512, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2860)
!2858 = !DISubroutineType(types: !2859)
!2859 = !{!90, !2705}
!2860 = !{!2856}
!2861 = !DILocation(line: 0, scope: !2857, inlinedAt: !2862)
!2862 = distinct !DILocation(line: 1005, column: 21, scope: !2863, inlinedAt: !2837)
!2863 = distinct !DILexicalBlock(scope: !2827, file: !56, line: 1005, column: 6)
!2864 = !DILocation(line: 513, column: 14, scope: !2857, inlinedAt: !2862)
!2865 = !{!2866, !1131, i64 9}
!2866 = !{!"lb6_service", !1131, i64 0, !1266, i64 4, !1266, i64 6, !1131, i64 8, !1131, i64 9, !1266, i64 10}
!2867 = !DILocation(line: 513, column: 21, scope: !2857, inlinedAt: !2862)
!2868 = !DILocation(line: 513, column: 9, scope: !2857, inlinedAt: !2862)
!2869 = !DILocation(line: 1005, column: 6, scope: !2827, inlinedAt: !2837)
!2870 = !DILocation(line: 1008, column: 13, scope: !2827, inlinedAt: !2837)
!2871 = !DILocation(line: 0, scope: !2846, inlinedAt: !2872)
!2872 = distinct !DILocation(line: 1009, column: 9, scope: !2827, inlinedAt: !2837)
!2873 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !2872)
!2874 = !DILocation(line: 1061, column: 7, scope: !2875, inlinedAt: !2722)
!2875 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1061, column: 6)
!2876 = !DILocation(line: 1061, column: 6, scope: !2692, inlinedAt: !2722)
!2877 = !DILocalVariable(name: "ctx", arg: 1, scope: !2878, file: !104, line: 851, type: !1136)
!2878 = distinct !DISubprogram(name: "sock6_xlate_v4_in_v6", scope: !104, file: !104, line: 851, type: !2693, scopeLine: 854, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2879)
!2879 = !{!2877, !2880, !2881, !2882, !2883, !2884}
!2880 = !DILocalVariable(name: "udp_only", arg: 2, scope: !2878, file: !104, line: 852, type: !1197)
!2881 = !DILocalVariable(name: "is_connect", arg: 3, scope: !2878, file: !104, line: 853, type: !1197)
!2882 = !DILocalVariable(name: "fake_ctx", scope: !2878, file: !104, line: 856, type: !1137)
!2883 = !DILocalVariable(name: "addr6", scope: !2878, file: !104, line: 857, type: !160)
!2884 = !DILocalVariable(name: "ret", scope: !2878, file: !104, line: 858, type: !305)
!2885 = !DILocation(line: 0, scope: !2878, inlinedAt: !2886)
!2886 = distinct !DILocation(line: 1064, column: 10, scope: !2887, inlinedAt: !2722)
!2887 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1063, column: 6)
!2888 = !DILocation(line: 0, scope: !2752, inlinedAt: !2889)
!2889 = distinct !DILocation(line: 860, column: 2, scope: !2878, inlinedAt: !2886)
!2890 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !2889)
!2891 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !2889)
!2892 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !2889)
!2893 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !2889)
!2894 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !2889)
!2895 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !2889)
!2896 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !2889)
!2897 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !2889)
!2898 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !2889)
!2899 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !2889)
!2900 = !DILocalVariable(name: "daddr", arg: 1, scope: !2901, file: !2902, line: 16, type: !2784)
!2901 = distinct !DISubprogram(name: "is_v4_in_v6", scope: !2902, file: !2902, line: 16, type: !2903, scopeLine: 17, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2905)
!2902 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/nat_46x64.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "a07799fd0bb120425c60542dca5a00b1")
!2903 = !DISubroutineType(types: !2904)
!2904 = !{!90, !2784}
!2905 = !{!2900, !2906, !2907}
!2906 = !DILocalVariable(name: "dprobe", scope: !2901, file: !2902, line: 19, type: !160)
!2907 = !DILocalVariable(name: "dmasked", scope: !2901, file: !2902, line: 23, type: !160)
!2908 = !DILocation(line: 0, scope: !2901, inlinedAt: !2909)
!2909 = distinct !DILocation(line: 861, column: 7, scope: !2910, inlinedAt: !2886)
!2910 = distinct !DILexicalBlock(scope: !2878, file: !104, line: 861, column: 6)
!2911 = !DILocalVariable(name: "a", arg: 1, scope: !2912, file: !161, line: 39, type: !2784)
!2912 = distinct !DISubprogram(name: "ipv6_addr_equals", scope: !161, file: !161, line: 39, type: !2913, scopeLine: 41, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2915)
!2913 = !DISubroutineType(types: !2914)
!2914 = !{!90, !2784, !2784}
!2915 = !{!2911, !2916}
!2916 = !DILocalVariable(name: "b", arg: 2, scope: !2912, file: !161, line: 40, type: !2784)
!2917 = !DILocation(line: 0, scope: !2912, inlinedAt: !2918)
!2918 = distinct !DILocation(line: 28, column: 9, scope: !2901, inlinedAt: !2909)
!2919 = !DILocation(line: 42, column: 12, scope: !2920, inlinedAt: !2918)
!2920 = distinct !DILexicalBlock(scope: !2912, file: !161, line: 42, column: 6)
!2921 = !DILocation(line: 42, column: 6, scope: !2912, inlinedAt: !2918)
!2922 = !DILocation(line: 0, scope: !1498, inlinedAt: !2923)
!2923 = distinct !DILocation(line: 864, column: 2, scope: !2878, inlinedAt: !2886)
!2924 = !DILocation(line: 0, scope: !1508, inlinedAt: !2925)
!2925 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !2923)
!2926 = !DILocation(line: 64, column: 12, scope: !1514, inlinedAt: !2925)
!2927 = !DILocation(line: 65, column: 12, scope: !1514, inlinedAt: !2925)
!2928 = !DILocation(line: 66, column: 12, scope: !1514, inlinedAt: !2925)
!2929 = !DILocation(line: 67, column: 12, scope: !1514, inlinedAt: !2925)
!2930 = !DILocation(line: 68, column: 12, scope: !1514, inlinedAt: !2925)
!2931 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !2925)
!2932 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !2925)
!2933 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !2925)
!2934 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !2925)
!2935 = !DILocation(line: 865, column: 23, scope: !2878, inlinedAt: !2886)
!2936 = !DILocation(line: 0, scope: !1240, inlinedAt: !2937)
!2937 = distinct !DILocation(line: 867, column: 23, scope: !2878, inlinedAt: !2886)
!2938 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2937)
!2939 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2937)
!2940 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2937)
!2941 = distinct !DIAssignID()
!2942 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2937)
!2943 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2937)
!2944 = !DILocation(line: 867, column: 23, scope: !2878, inlinedAt: !2886)
!2945 = !DILocation(line: 0, scope: !1194, inlinedAt: !2946)
!2946 = distinct !DILocation(line: 869, column: 8, scope: !2878, inlinedAt: !2886)
!2947 = !DILocation(line: 0, scope: !1228, inlinedAt: !2948)
!2948 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !2946)
!2949 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2948)
!2950 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2948)
!2951 = !DILocation(line: 0, scope: !1240, inlinedAt: !2952)
!2952 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !2946)
!2953 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2952)
!2954 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2952)
!2955 = distinct !DIAssignID()
!2956 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2952)
!2957 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2952)
!2958 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2952)
!2959 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !2946)
!2960 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !2946)
!2961 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !2946)
!2962 = distinct !DIAssignID()
!2963 = distinct !DIAssignID()
!2964 = distinct !DIAssignID()
!2965 = distinct !DIAssignID()
!2966 = distinct !DIAssignID()
!2967 = distinct !DIAssignID()
!2968 = !DILocation(line: 0, scope: !1276, inlinedAt: !2969)
!2969 = distinct !DILocation(line: 317, column: 20, scope: !1282, inlinedAt: !2946)
!2970 = !DILocation(line: 132, column: 2, scope: !1276, inlinedAt: !2969)
!2971 = distinct !DIAssignID()
!2972 = !DILocation(line: 0, scope: !1285, inlinedAt: !2973)
!2973 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !2946)
!2974 = distinct !DIAssignID()
!2975 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2973)
!2976 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2973)
!2977 = !DILocation(line: 0, scope: !1302, inlinedAt: !2978)
!2978 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2973)
!2979 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2978)
!2980 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2973)
!2981 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2973)
!2982 = !DILocation(line: 0, scope: !1313, inlinedAt: !2983)
!2983 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2973)
!2984 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2983)
!2985 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2983)
!2986 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2983)
!2987 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2973)
!2988 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2973)
!2989 = !DILocation(line: 0, scope: !1302, inlinedAt: !2990)
!2990 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2973)
!2991 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2990)
!2992 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !2946)
!2993 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !2946)
!2994 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !2946)
!2995 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !2946)
!2996 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !2946)
!2997 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !2946)
!2998 = !DILocation(line: 0, scope: !1218, inlinedAt: !2946)
!2999 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !2946)
!3000 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !2946)
!3001 = !DILocation(line: 0, scope: !1347, inlinedAt: !3002)
!3002 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !2946)
!3003 = !DILocation(line: 0, scope: !1355, inlinedAt: !3004)
!3004 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !3002)
!3005 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !3004)
!3006 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !3004)
!3007 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !3004)
!3008 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !3002)
!3009 = !DILocation(line: 0, scope: !1366, inlinedAt: !3010)
!3010 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !3002)
!3011 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !3010)
!3012 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !3010)
!3013 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !3002)
!3014 = !DILocation(line: 0, scope: !1355, inlinedAt: !3015)
!3015 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !3002)
!3016 = !DILocation(line: 0, scope: !1376, inlinedAt: !3017)
!3017 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !3002)
!3018 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !3017)
!3019 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !3017)
!3020 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !3017)
!3021 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !3002)
!3022 = !DILocation(line: 0, scope: !1386, inlinedAt: !3023)
!3023 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !2946)
!3024 = !DILocation(line: 0, scope: !1392, inlinedAt: !3025)
!3025 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !3023)
!3026 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !3025)
!3027 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !3025)
!3028 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !3025)
!3029 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !3023)
!3030 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !3023)
!3031 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !3023)
!3032 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !2946)
!3033 = !DILocation(line: 0, scope: !1404, inlinedAt: !3034)
!3034 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !2946)
!3035 = !DILocation(line: 0, scope: !1418, inlinedAt: !3036)
!3036 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !3034)
!3037 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !3036)
!3038 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !3036)
!3039 = !DILocation(line: 0, scope: !1392, inlinedAt: !3040)
!3040 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !3034)
!3041 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !3034)
!3042 = !DILocation(line: 0, scope: !1428, inlinedAt: !3043)
!3043 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !3034)
!3044 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !3043)
!3045 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !3043)
!3046 = distinct !DIAssignID()
!3047 = distinct !DIAssignID()
!3048 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !3043)
!3049 = distinct !DIAssignID()
!3050 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !3043)
!3051 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !3043)
!3052 = distinct !DIAssignID()
!3053 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !3043)
!3054 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !3043)
!3055 = distinct !DIAssignID()
!3056 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !3043)
!3057 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !3043)
!3058 = distinct !DIAssignID()
!3059 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !3043)
!3060 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !3043)
!3061 = !DILocation(line: 0, scope: !1410, inlinedAt: !3034)
!3062 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !3034)
!3063 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !3034)
!3064 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !3034)
!3065 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !3034)
!3066 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !3034)
!3067 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !2946)
!3068 = !DILocation(line: 0, scope: !1223, inlinedAt: !2946)
!3069 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !2946)
!3070 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !2946)
!3071 = !DILocation(line: 0, scope: !1476, inlinedAt: !3072)
!3072 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !2946)
!3073 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !3072)
!3074 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !3072)
!3075 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !3072)
!3076 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !2946)
!3077 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !2946)
!3078 = !DILocation(line: 0, scope: !1486, inlinedAt: !3079)
!3079 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !2946)
!3080 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !3079)
!3081 = !DILocation(line: 0, scope: !1498, inlinedAt: !3082)
!3082 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !3079)
!3083 = !DILocation(line: 0, scope: !1508, inlinedAt: !3084)
!3084 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3082)
!3085 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3084)
!3086 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !3084)
!3087 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3084)
!3088 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !3079)
!3089 = distinct !DIAssignID()
!3090 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !3079)
!3091 = distinct !DIAssignID()
!3092 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !3079)
!3093 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !3079)
!3094 = distinct !DIAssignID()
!3095 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !3079)
!3096 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !3079)
!3097 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !3079)
!3098 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !2946)
!3099 = !DILocation(line: 0, scope: !1554, inlinedAt: !3100)
!3100 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !2946)
!3101 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !3100)
!3102 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !3100)
!3103 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !3100)
!3104 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !2946)
!3105 = !DILocation(line: 0, scope: !1564, inlinedAt: !3106)
!3106 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !2946)
!3107 = !DILocation(line: 0, scope: !1574, inlinedAt: !3108)
!3108 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !3106)
!3109 = !DILocation(line: 0, scope: !1585, inlinedAt: !3108)
!3110 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !3108)
!3111 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !3108)
!3112 = distinct !DIAssignID()
!3113 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !3108)
!3114 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !3108)
!3115 = distinct !DIAssignID()
!3116 = distinct !DIAssignID()
!3117 = distinct !DIAssignID()
!3118 = distinct !DIAssignID()
!3119 = distinct !DIAssignID()
!3120 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !3108)
!3121 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !3108)
!3122 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !3108)
!3123 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !3108)
!3124 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !2946)
!3125 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3126)
!3126 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !3108)
!3127 = !DILocation(line: 0, scope: !1617, inlinedAt: !3126)
!3128 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3126)
!3129 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3126)
!3130 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3126)
!3131 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3126)
!3132 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3126)
!3133 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3134)
!3134 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3126)
!3135 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3134)
!3136 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3126)
!3137 = !DILocation(line: 0, scope: !1619, inlinedAt: !3126)
!3138 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !3108)
!3139 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !3108)
!3140 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !3108)
!3141 = distinct !DIAssignID()
!3142 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !3108)
!3143 = distinct !DIAssignID()
!3144 = distinct !DIAssignID()
!3145 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !3108)
!3146 = !DILocation(line: 0, scope: !1589, inlinedAt: !3108)
!3147 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3148)
!3148 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !3108)
!3149 = !DILocation(line: 0, scope: !1659, inlinedAt: !3150)
!3150 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !3108)
!3151 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !3150)
!3152 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !3150)
!3153 = !DILocation(line: 0, scope: !1668, inlinedAt: !3154)
!3154 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !3108)
!3155 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !3154)
!3156 = !DILocation(line: 0, scope: !1673, inlinedAt: !3154)
!3157 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !3154)
!3158 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !3154)
!3159 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !3154)
!3160 = !DILocation(line: 0, scope: !1676, inlinedAt: !3154)
!3161 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !3154)
!3162 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !3154)
!3163 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !3154)
!3164 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !3154)
!3165 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !3108)
!3166 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !3108)
!3167 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !3108)
!3168 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !3108)
!3169 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !3108)
!3170 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !3108)
!3171 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !3108)
!3172 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !3108)
!3173 = !DILocation(line: 0, scope: !1592, inlinedAt: !3108)
!3174 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !3108)
!3175 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3176)
!3176 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !3108)
!3177 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !3108)
!3178 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !2946)
!3179 = !DILocation(line: 0, scope: !1708, inlinedAt: !3180)
!3180 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !2946)
!3181 = distinct !DIAssignID()
!3182 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !3180)
!3183 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !3180)
!3184 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !2946)
!3185 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !2946)
!3186 = !DILocation(line: 0, scope: !1714, inlinedAt: !2946)
!3187 = !DILocation(line: 0, scope: !1724, inlinedAt: !3188)
!3188 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !2946)
!3189 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !3188)
!3190 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !3188)
!3191 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !3188)
!3192 = !DILocation(line: 0, scope: !1736, inlinedAt: !3193)
!3193 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !3188)
!3194 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3193)
!3195 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !2946)
!3196 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !2946)
!3197 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !2946)
!3198 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !2946)
!3199 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !2946)
!3200 = distinct !DIAssignID()
!3201 = !DILocation(line: 0, scope: !1750, inlinedAt: !3202)
!3202 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !2946)
!3203 = !DILocation(line: 0, scope: !1302, inlinedAt: !3204)
!3204 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !3202)
!3205 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3204)
!3206 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !2946)
!3207 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !2946)
!3208 = !DILocation(line: 0, scope: !1761, inlinedAt: !3209)
!3209 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !2946)
!3210 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3209)
!3211 = distinct !DIAssignID()
!3212 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3209)
!3213 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3209)
!3214 = distinct !DIAssignID()
!3215 = distinct !DIAssignID()
!3216 = distinct !DIAssignID()
!3217 = distinct !DIAssignID()
!3218 = distinct !DIAssignID()
!3219 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3209)
!3220 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3209)
!3221 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3209)
!3222 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3209)
!3223 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3209)
!3224 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3209)
!3225 = distinct !DIAssignID()
!3226 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3209)
!3227 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3209)
!3228 = distinct !DIAssignID()
!3229 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3209)
!3230 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3209)
!3231 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !2946)
!3232 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !2946)
!3233 = !DILocation(line: 0, scope: !1708, inlinedAt: !3234)
!3234 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !2946)
!3235 = distinct !DIAssignID()
!3236 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !3234)
!3237 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !3234)
!3238 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !2946)
!3239 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !2946)
!3240 = !DILocation(line: 0, scope: !1761, inlinedAt: !3241)
!3241 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !2946)
!3242 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3241)
!3243 = distinct !DIAssignID()
!3244 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3241)
!3245 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3241)
!3246 = distinct !DIAssignID()
!3247 = distinct !DIAssignID()
!3248 = distinct !DIAssignID()
!3249 = distinct !DIAssignID()
!3250 = distinct !DIAssignID()
!3251 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3241)
!3252 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3241)
!3253 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3241)
!3254 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3241)
!3255 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3241)
!3256 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3241)
!3257 = distinct !DIAssignID()
!3258 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3241)
!3259 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3241)
!3260 = distinct !DIAssignID()
!3261 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3241)
!3262 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3241)
!3263 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !2946)
!3264 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !2946)
!3265 = !DILocation(line: 0, scope: !1554, inlinedAt: !3266)
!3266 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !2946)
!3267 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !3266)
!3268 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !3266)
!3269 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !3266)
!3270 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !2946)
!3271 = !DILocation(line: 0, scope: !1847, inlinedAt: !3272)
!3272 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2946)
!3273 = !DILocation(line: 0, scope: !1856, inlinedAt: !3274)
!3274 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !3272)
!3275 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3276)
!3276 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !3274)
!3277 = !DILocation(line: 0, scope: !1617, inlinedAt: !3276)
!3278 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3276)
!3279 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3276)
!3280 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3276)
!3281 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3276)
!3282 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3276)
!3283 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3284)
!3284 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3276)
!3285 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3284)
!3286 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3276)
!3287 = !DILocation(line: 0, scope: !1619, inlinedAt: !3276)
!3288 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !3274)
!3289 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !3274)
!3290 = distinct !DIAssignID()
!3291 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !3274)
!3292 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !3274)
!3293 = distinct !DIAssignID()
!3294 = distinct !DIAssignID()
!3295 = distinct !DIAssignID()
!3296 = distinct !DIAssignID()
!3297 = distinct !DIAssignID()
!3298 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !3274)
!3299 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !3274)
!3300 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !3274)
!3301 = distinct !DIAssignID()
!3302 = distinct !DIAssignID()
!3303 = distinct !DIAssignID()
!3304 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !3274)
!3305 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !3274)
!3306 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2946)
!3307 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !2946)
!3308 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !2946)
!3309 = !DILocation(line: 0, scope: !1906, inlinedAt: !3310)
!3310 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !2946)
!3311 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !3310)
!3312 = distinct !DIAssignID()
!3313 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !3310)
!3314 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !3310)
!3315 = distinct !DIAssignID()
!3316 = distinct !DIAssignID()
!3317 = !DILocation(line: 0, scope: !1736, inlinedAt: !3318)
!3318 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !3310)
!3319 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3318)
!3320 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !3310)
!3321 = distinct !DIAssignID()
!3322 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !3310)
!3323 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !3310)
!3324 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !3310)
!3325 = distinct !DIAssignID()
!3326 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !3310)
!3327 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !3310)
!3328 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !3310)
!3329 = distinct !DIAssignID()
!3330 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !3310)
!3331 = distinct !DIAssignID()
!3332 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !3310)
!3333 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !3310)
!3334 = distinct !DIAssignID()
!3335 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !3310)
!3336 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !3310)
!3337 = distinct !DIAssignID()
!3338 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !3310)
!3339 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !3310)
!3340 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !3310)
!3341 = !DILocation(line: 0, scope: !1963, inlinedAt: !3342)
!3342 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3310)
!3343 = !DILocation(line: 0, scope: !1972, inlinedAt: !3344)
!3344 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !3342)
!3345 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !3344)
!3346 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !3344)
!3347 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3310)
!3348 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !3310)
!3349 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !3310)
!3350 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !2946)
!3351 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !3310)
!3352 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !2946)
!3353 = !DILocation(line: 0, scope: !1761, inlinedAt: !3354)
!3354 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !2946)
!3355 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3354)
!3356 = distinct !DIAssignID()
!3357 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3354)
!3358 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3354)
!3359 = distinct !DIAssignID()
!3360 = distinct !DIAssignID()
!3361 = distinct !DIAssignID()
!3362 = distinct !DIAssignID()
!3363 = distinct !DIAssignID()
!3364 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3354)
!3365 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3354)
!3366 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3354)
!3367 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3354)
!3368 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3354)
!3369 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3354)
!3370 = distinct !DIAssignID()
!3371 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3354)
!3372 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3354)
!3373 = distinct !DIAssignID()
!3374 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3354)
!3375 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3354)
!3376 = !DILocation(line: 449, column: 3, scope: !2005, inlinedAt: !2946)
!3377 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !2946)
!3378 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !2946)
!3379 = !DILocation(line: 0, scope: !2034, inlinedAt: !3380)
!3380 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !2946)
!3381 = !DILocation(line: 875, column: 36, scope: !2878, inlinedAt: !2886)
!3382 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !2946)
!3383 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !2946)
!3384 = !DILocation(line: 870, column: 6, scope: !2878, inlinedAt: !2886)
!3385 = !DILocation(line: 0, scope: !1498, inlinedAt: !3386)
!3386 = distinct !DILocation(line: 55, column: 2, scope: !3387, inlinedAt: !3393)
!3387 = distinct !DISubprogram(name: "build_v4_in_v6", scope: !2902, file: !2902, line: 53, type: !3388, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3390)
!3388 = !DISubroutineType(types: !3389)
!3389 = !{null, !2755, !153}
!3390 = !{!3391, !3392}
!3391 = !DILocalVariable(name: "daddr", arg: 1, scope: !3387, file: !2902, line: 53, type: !2755)
!3392 = !DILocalVariable(name: "v4", arg: 2, scope: !3387, file: !2902, line: 53, type: !153)
!3393 = distinct !DILocation(line: 873, column: 2, scope: !2878, inlinedAt: !2886)
!3394 = !DILocation(line: 0, scope: !1508, inlinedAt: !3395)
!3395 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3386)
!3396 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3395)
!3397 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3395)
!3398 = !DILocalVariable(name: "ctx", arg: 1, scope: !3399, file: !104, line: 741, type: !1136)
!3399 = distinct !DISubprogram(name: "ctx_set_v6_address", scope: !104, file: !104, line: 741, type: !3400, scopeLine: 743, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3402)
!3400 = !DISubroutineType(types: !3401)
!3401 = !{null, !1136, !2784}
!3402 = !{!3398, !3403}
!3403 = !DILocalVariable(name: "addr", arg: 2, scope: !3399, file: !104, line: 742, type: !2784)
!3404 = !DILocation(line: 0, scope: !3399, inlinedAt: !3405)
!3405 = distinct !DILocation(line: 874, column: 2, scope: !2878, inlinedAt: !2886)
!3406 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !3405)
!3407 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !3405)
!3408 = !{i64 2148418714}
!3409 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !3405)
!3410 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !3405)
!3411 = !{i64 2148418749}
!3412 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !3405)
!3413 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !3405)
!3414 = !{i64 2148418784}
!3415 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !3405)
!3416 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !3405)
!3417 = !{i64 2148418819}
!3418 = !DILocation(line: 0, scope: !2034, inlinedAt: !3419)
!3419 = distinct !DILocation(line: 875, column: 2, scope: !2878, inlinedAt: !2886)
!3420 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !3419)
!3421 = !DILocation(line: 877, column: 2, scope: !2878, inlinedAt: !2886)
!3422 = !DILocation(line: 1065, column: 11, scope: !2717, inlinedAt: !2722)
!3423 = !{!2866, !1266, i64 4}
!3424 = !DILocation(line: 1065, column: 17, scope: !2717, inlinedAt: !2722)
!3425 = !DILocation(line: 1065, column: 22, scope: !2717, inlinedAt: !2722)
!3426 = !DILocation(line: 1067, column: 7, scope: !2714, inlinedAt: !2722)
!3427 = !{i64 2148420827}
!3428 = !DILocation(line: 0, scope: !2714, inlinedAt: !2722)
!3429 = !DILocation(line: 1067, column: 7, scope: !2715, inlinedAt: !2722)
!3430 = !DILocation(line: 1067, column: 7, scope: !2716, inlinedAt: !2722)
!3431 = !DILocalVariable(name: "svc", arg: 1, scope: !3432, file: !56, line: 2367, type: !2705)
!3432 = distinct !DISubprogram(name: "handle_nonroutable_endpoints_v6", scope: !56, file: !56, line: 2367, type: !3433, scopeLine: 2368, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3435)
!3433 = !DISubroutineType(types: !3434)
!3434 = !{!305, !2705}
!3435 = !{!3431}
!3436 = !DILocation(line: 0, scope: !3432, inlinedAt: !3437)
!3437 = distinct !DILocation(line: 1069, column: 7, scope: !3438, inlinedAt: !2722)
!3438 = distinct !DILexicalBlock(scope: !2716, file: !104, line: 1069, column: 7)
!3439 = !DILocalVariable(name: "svc", arg: 1, scope: !3440, file: !56, line: 618, type: !2705)
!3440 = distinct !DISubprogram(name: "lb6_svc_is_external", scope: !56, file: !56, line: 618, type: !2858, scopeLine: 619, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3441)
!3441 = !{!3439}
!3442 = !DILocation(line: 0, scope: !3440, inlinedAt: !3443)
!3443 = distinct !DILocation(line: 2370, column: 7, scope: !3444, inlinedAt: !3437)
!3444 = distinct !DILexicalBlock(scope: !3432, file: !56, line: 2370, column: 6)
!3445 = !DILocation(line: 620, column: 14, scope: !3440, inlinedAt: !3443)
!3446 = !{!2866, !1131, i64 8}
!3447 = !DILocation(line: 620, column: 20, scope: !3440, inlinedAt: !3443)
!3448 = !DILocation(line: 620, column: 9, scope: !3440, inlinedAt: !3443)
!3449 = !DILocation(line: 2370, column: 32, scope: !3444, inlinedAt: !3437)
!3450 = !DILocalVariable(name: "svc", arg: 1, scope: !3451, file: !56, line: 630, type: !2705)
!3451 = distinct !DISubprogram(name: "lb6_svc_is_etp_local", scope: !56, file: !56, line: 630, type: !2858, scopeLine: 631, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3452)
!3452 = !{!3450}
!3453 = !DILocation(line: 0, scope: !3451, inlinedAt: !3454)
!3454 = distinct !DILocation(line: 2370, column: 35, scope: !3444, inlinedAt: !3437)
!3455 = !DILocation(line: 632, column: 20, scope: !3451, inlinedAt: !3454)
!3456 = !DILocation(line: 632, column: 9, scope: !3451, inlinedAt: !3454)
!3457 = !DILocation(line: 2370, column: 62, scope: !3444, inlinedAt: !3437)
!3458 = !DILocation(line: 0, scope: !3440, inlinedAt: !3459)
!3459 = distinct !DILocation(line: 2371, column: 8, scope: !3444, inlinedAt: !3437)
!3460 = !DILocalVariable(name: "svc", arg: 1, scope: !3461, file: !56, line: 642, type: !2705)
!3461 = distinct !DISubprogram(name: "lb6_svc_is_itp_local", scope: !56, file: !56, line: 642, type: !2858, scopeLine: 643, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3462)
!3462 = !{!3460}
!3463 = !DILocation(line: 0, scope: !3461, inlinedAt: !3464)
!3464 = distinct !DILocation(line: 2371, column: 36, scope: !3444, inlinedAt: !3437)
!3465 = !DILocation(line: 644, column: 14, scope: !3461, inlinedAt: !3464)
!3466 = !DILocation(line: 644, column: 21, scope: !3461, inlinedAt: !3464)
!3467 = !DILocation(line: 644, column: 9, scope: !3461, inlinedAt: !3464)
!3468 = !DILocation(line: 2370, column: 6, scope: !3432, inlinedAt: !3437)
!3469 = !DILocation(line: 0, scope: !2716, inlinedAt: !2722)
!3470 = !DILocalVariable(name: "svc", arg: 1, scope: !3471, file: !56, line: 595, type: !2705)
!3471 = distinct !DISubprogram(name: "lb6_svc_is_l7_punt_proxy", scope: !56, file: !56, line: 595, type: !2858, scopeLine: 596, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3472)
!3472 = !{!3470}
!3473 = !DILocation(line: 0, scope: !3471, inlinedAt: !3474)
!3474 = distinct !DILocation(line: 1077, column: 6, scope: !3475, inlinedAt: !2722)
!3475 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1077, column: 6)
!3476 = !DILocalVariable(name: "svc", arg: 1, scope: !3477, file: !56, line: 475, type: !2705)
!3477 = distinct !DISubprogram(name: "lb6_svc_is_hostport", scope: !56, file: !56, line: 475, type: !2858, scopeLine: 476, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3478)
!3478 = !{!3476}
!3479 = !DILocation(line: 0, scope: !3477, inlinedAt: !3480)
!3480 = distinct !DILocation(line: 597, column: 10, scope: !3471, inlinedAt: !3474)
!3481 = !DILocation(line: 477, column: 14, scope: !3477, inlinedAt: !3480)
!3482 = !DILocation(line: 477, column: 20, scope: !3477, inlinedAt: !3480)
!3483 = !DILocation(line: 477, column: 9, scope: !3477, inlinedAt: !3480)
!3484 = !DILocation(line: 597, column: 35, scope: !3471, inlinedAt: !3474)
!3485 = !DILocation(line: 597, column: 44, scope: !3471, inlinedAt: !3474)
!3486 = !DILocation(line: 597, column: 51, scope: !3471, inlinedAt: !3474)
!3487 = !DILocation(line: 1077, column: 6, scope: !2692, inlinedAt: !2722)
!3488 = !DILocalVariable(name: "svc", arg: 1, scope: !3489, file: !104, line: 755, type: !2705)
!3489 = distinct !DISubprogram(name: "sock6_skip_xlate", scope: !104, file: !104, line: 755, type: !3490, scopeLine: 756, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3492)
!3490 = !DISubroutineType(types: !3491)
!3491 = !{!90, !2705, !2784}
!3492 = !{!3488, !3493, !3494}
!3493 = !DILocalVariable(name: "address", arg: 2, scope: !3489, file: !104, line: 755, type: !2784)
!3494 = !DILocalVariable(name: "info", scope: !3495, file: !104, line: 761, type: !1412)
!3495 = distinct !DILexicalBlock(scope: !3496, file: !104, line: 760, column: 62)
!3496 = distinct !DILexicalBlock(scope: !3489, file: !104, line: 759, column: 6)
!3497 = !DILocation(line: 0, scope: !3489, inlinedAt: !3498)
!3498 = distinct !DILocation(line: 1079, column: 6, scope: !3499, inlinedAt: !2722)
!3499 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1079, column: 6)
!3500 = !DILocalVariable(name: "svc", arg: 1, scope: !3501, file: !56, line: 463, type: !2705)
!3501 = distinct !DISubprogram(name: "lb6_svc_is_external_ip", scope: !56, file: !56, line: 463, type: !2858, scopeLine: 464, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3502)
!3502 = !{!3500}
!3503 = !DILocation(line: 0, scope: !3501, inlinedAt: !3504)
!3504 = distinct !DILocation(line: 759, column: 7, scope: !3496, inlinedAt: !3498)
!3505 = !DILocation(line: 465, column: 20, scope: !3501, inlinedAt: !3504)
!3506 = !DILocation(line: 465, column: 9, scope: !3501, inlinedAt: !3504)
!3507 = !DILocation(line: 0, scope: !3477, inlinedAt: !3508)
!3508 = distinct !DILocation(line: 760, column: 7, scope: !3496, inlinedAt: !3498)
!3509 = !DILocation(line: 0, scope: !2912, inlinedAt: !3510)
!3510 = distinct !DILocation(line: 44, column: 9, scope: !3511, inlinedAt: !3515)
!3511 = distinct !DISubprogram(name: "is_v6_loopback", scope: !104, file: !104, line: 39, type: !2903, scopeLine: 40, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3512)
!3512 = !{!3513, !3514}
!3513 = !DILocalVariable(name: "daddr", arg: 1, scope: !3511, file: !104, line: 39, type: !2784)
!3514 = !DILocalVariable(name: "loopback", scope: !3511, file: !104, line: 42, type: !160)
!3515 = distinct !DILocation(line: 760, column: 36, scope: !3496, inlinedAt: !3498)
!3516 = !DILocation(line: 759, column: 83, scope: !3496, inlinedAt: !3498)
!3517 = !DILocalVariable(name: "key", scope: !3518, file: !413, line: 140, type: !463)
!3518 = distinct !DISubprogram(name: "ipcache_lookup6", scope: !413, file: !413, line: 137, type: !3519, scopeLine: 139, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3521)
!3519 = !DISubroutineType(types: !3520)
!3520 = !{!1412, !1013, !2784, !82, !82}
!3521 = !{!3522, !3523, !3524, !3525, !3517}
!3522 = !DILocalVariable(name: "map", arg: 1, scope: !3518, file: !413, line: 137, type: !1013)
!3523 = !DILocalVariable(name: "addr", arg: 2, scope: !3518, file: !413, line: 137, type: !2784)
!3524 = !DILocalVariable(name: "prefix", arg: 3, scope: !3518, file: !413, line: 138, type: !82)
!3525 = !DILocalVariable(name: "cluster_id", arg: 4, scope: !3518, file: !413, line: 138, type: !82)
!3526 = !DILocation(line: 0, scope: !3518, inlinedAt: !3527)
!3527 = distinct !DILocation(line: 763, column: 10, scope: !3495, inlinedAt: !3498)
!3528 = !DILocation(line: 140, column: 2, scope: !3518, inlinedAt: !3527)
!3529 = !DILocation(line: 140, column: 21, scope: !3518, inlinedAt: !3527)
!3530 = distinct !DIAssignID()
!3531 = distinct !DIAssignID()
!3532 = distinct !DIAssignID()
!3533 = !DILocation(line: 142, column: 24, scope: !3518, inlinedAt: !3527)
!3534 = !{!1449, !1130, i64 0}
!3535 = distinct !DIAssignID()
!3536 = !DILocation(line: 143, column: 6, scope: !3518, inlinedAt: !3527)
!3537 = !DILocation(line: 143, column: 13, scope: !3518, inlinedAt: !3527)
!3538 = distinct !DIAssignID()
!3539 = !DILocation(line: 144, column: 6, scope: !3518, inlinedAt: !3527)
!3540 = !DILocation(line: 144, column: 12, scope: !3518, inlinedAt: !3527)
!3541 = !{i64 0, i64 16, !1444, i64 0, i64 4, !1129, i64 4, i64 4, !1129, i64 8, i64 4, !1129, i64 12, i64 4, !1129, i64 0, i64 8, !1534, i64 8, i64 8, !1534}
!3542 = distinct !DIAssignID()
!3543 = !{i64 0, i64 8, !1444, i64 0, i64 4, !1129, i64 4, i64 4, !1129, i64 0, i64 8, !1534}
!3544 = distinct !DIAssignID()
!3545 = !DILocation(line: 150, column: 6, scope: !3518, inlinedAt: !3527)
!3546 = !DILocation(line: 150, column: 17, scope: !3518, inlinedAt: !3527)
!3547 = distinct !DIAssignID()
!3548 = !DILocation(line: 153, column: 9, scope: !3518, inlinedAt: !3527)
!3549 = !DILocation(line: 154, column: 1, scope: !3518, inlinedAt: !3527)
!3550 = !DILocation(line: 0, scope: !3495, inlinedAt: !3498)
!3551 = !DILocation(line: 764, column: 8, scope: !3552, inlinedAt: !3498)
!3552 = distinct !DILexicalBlock(scope: !3495, file: !104, line: 764, column: 7)
!3553 = !DILocation(line: 764, column: 13, scope: !3552, inlinedAt: !3498)
!3554 = !DILocation(line: 764, column: 22, scope: !3552, inlinedAt: !3498)
!3555 = !DILocation(line: 764, column: 35, scope: !3552, inlinedAt: !3498)
!3556 = !DILocation(line: 764, column: 7, scope: !3495, inlinedAt: !3498)
!3557 = !DILocation(line: 1082, column: 6, scope: !2719, inlinedAt: !2722)
!3558 = !{i64 2148422252}
!3559 = !DILocation(line: 0, scope: !2719, inlinedAt: !2722)
!3560 = !DILocation(line: 1082, column: 6, scope: !2720, inlinedAt: !2722)
!3561 = !DILocation(line: 1082, column: 25, scope: !2720, inlinedAt: !2722)
!3562 = !DILocalVariable(name: "svc", arg: 1, scope: !3563, file: !56, line: 552, type: !2705)
!3563 = distinct !DISubprogram(name: "lb6_svc_is_localredirect", scope: !56, file: !56, line: 552, type: !2858, scopeLine: 553, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3564)
!3564 = !{!3562}
!3565 = !DILocation(line: 0, scope: !3563, inlinedAt: !3566)
!3566 = distinct !DILocation(line: 1083, column: 6, scope: !2720, inlinedAt: !2722)
!3567 = !DILocation(line: 554, column: 14, scope: !3563, inlinedAt: !3566)
!3568 = !DILocation(line: 554, column: 21, scope: !3563, inlinedAt: !3566)
!3569 = !DILocation(line: 554, column: 9, scope: !3563, inlinedAt: !3566)
!3570 = !DILocation(line: 1083, column: 36, scope: !2720, inlinedAt: !2722)
!3571 = !DILocation(line: 1084, column: 40, scope: !2720, inlinedAt: !2722)
!3572 = !DILocalVariable(name: "key", scope: !3573, file: !905, line: 44, type: !911)
!3573 = distinct !DISubprogram(name: "lrp_v6_skip_xlate_from_ctx_to_svc", scope: !905, file: !905, line: 42, type: !3574, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3576)
!3574 = !DISubroutineType(types: !3575)
!3575 = !{!90, !640, !160, !92}
!3576 = !{!3577, !3578, !3579, !3572, !3580}
!3577 = !DILocalVariable(name: "cookie", arg: 1, scope: !3573, file: !905, line: 42, type: !640)
!3578 = !DILocalVariable(name: "addr", arg: 2, scope: !3573, file: !905, line: 42, type: !160)
!3579 = !DILocalVariable(name: "port", arg: 3, scope: !3573, file: !905, line: 42, type: !92)
!3580 = !DILocalVariable(name: "val", scope: !3573, file: !905, line: 45, type: !97)
!3581 = !DILocation(line: 0, scope: !3573, inlinedAt: !3582)
!3582 = distinct !DILocation(line: 1084, column: 6, scope: !2720, inlinedAt: !2722)
!3583 = !DILocation(line: 44, column: 2, scope: !3573, inlinedAt: !3582)
!3584 = !DILocation(line: 0, scope: !1498, inlinedAt: !3585)
!3585 = distinct !DILocation(line: 47, column: 2, scope: !3573, inlinedAt: !3582)
!3586 = !DILocation(line: 0, scope: !1508, inlinedAt: !3587)
!3587 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3585)
!3588 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !3587)
!3589 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !3587)
!3590 = !DILocation(line: 70, column: 21, scope: !1514, inlinedAt: !3587)
!3591 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3587)
!3592 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !3587)
!3593 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3587)
!3594 = !DILocation(line: 48, column: 19, scope: !3573, inlinedAt: !3582)
!3595 = !{!3596, !1535, i64 0}
!3596 = !{!"skip_lb6_key", !1535, i64 0, !1131, i64 8, !1130, i64 24, !1266, i64 28, !1266, i64 30}
!3597 = distinct !DIAssignID()
!3598 = !DILocation(line: 49, column: 16, scope: !3573, inlinedAt: !3582)
!3599 = distinct !DIAssignID()
!3600 = distinct !DIAssignID()
!3601 = !DILocation(line: 50, column: 6, scope: !3573, inlinedAt: !3582)
!3602 = !DILocation(line: 50, column: 11, scope: !3573, inlinedAt: !3582)
!3603 = !{!3596, !1266, i64 28}
!3604 = distinct !DIAssignID()
!3605 = !DILocation(line: 51, column: 8, scope: !3573, inlinedAt: !3582)
!3606 = !DILocation(line: 52, column: 6, scope: !3607, inlinedAt: !3582)
!3607 = distinct !DILexicalBlock(scope: !3573, file: !905, line: 52, column: 6)
!3608 = !DILocation(line: 55, column: 1, scope: !3573, inlinedAt: !3582)
!3609 = !DILocation(line: 1082, column: 6, scope: !2692, inlinedAt: !2722)
!3610 = !DILocalVariable(name: "svc", arg: 1, scope: !3611, file: !56, line: 523, type: !2705)
!3611 = distinct !DISubprogram(name: "lb6_svc_is_affinity", scope: !56, file: !56, line: 523, type: !2858, scopeLine: 524, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3612)
!3612 = !{!3610}
!3613 = !DILocation(line: 0, scope: !3611, inlinedAt: !3614)
!3614 = distinct !DILocation(line: 1105, column: 6, scope: !3615, inlinedAt: !2722)
!3615 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1105, column: 6)
!3616 = !DILocation(line: 525, column: 14, scope: !3611, inlinedAt: !3614)
!3617 = !DILocation(line: 525, column: 20, scope: !3611, inlinedAt: !3614)
!3618 = !DILocation(line: 525, column: 9, scope: !3611, inlinedAt: !3614)
!3619 = !DILocation(line: 1105, column: 6, scope: !2692, inlinedAt: !2722)
!3620 = !DILocalVariable(name: "svc", arg: 1, scope: !3621, file: !56, line: 1320, type: !2705)
!3621 = distinct !DISubprogram(name: "lb6_affinity_backend_id_by_netns", scope: !56, file: !56, line: 1320, type: !3622, scopeLine: 1322, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3625)
!3622 = !DISubroutineType(types: !3623)
!3623 = !{!82, !2705, !3624}
!3624 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !636, size: 64)
!3625 = !{!3620, !3626}
!3626 = !DILocalVariable(name: "id", arg: 2, scope: !3621, file: !56, line: 1321, type: !3624)
!3627 = !DILocation(line: 0, scope: !3621, inlinedAt: !3628)
!3628 = distinct !DILocation(line: 1106, column: 16, scope: !3629, inlinedAt: !2722)
!3629 = distinct !DILexicalBlock(scope: !3615, file: !104, line: 1105, column: 32)
!3630 = !DILocalVariable(name: "key", scope: !3631, file: !56, line: 1246, type: !633)
!3631 = distinct !DISubprogram(name: "__lb6_affinity_backend_id", scope: !56, file: !56, line: 1243, type: !3632, scopeLine: 1245, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3634)
!3632 = !DISubroutineType(types: !3633)
!3633 = !{!82, !2705, !90, !3624}
!3634 = !{!3635, !3636, !3637, !3630, !3638, !3639, !3642, !3643, !3646}
!3635 = !DILocalVariable(name: "svc", arg: 1, scope: !3631, file: !56, line: 1243, type: !2705)
!3636 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !3631, file: !56, line: 1243, type: !90)
!3637 = !DILocalVariable(name: "id", arg: 3, scope: !3631, file: !56, line: 1244, type: !3624)
!3638 = !DILocalVariable(name: "val", scope: !3631, file: !56, line: 1250, type: !647)
!3639 = !DILocalVariable(name: "now", scope: !3640, file: !56, line: 1259, type: !82)
!3640 = distinct !DILexicalBlock(scope: !3641, file: !56, line: 1258, column: 19)
!3641 = distinct !DILexicalBlock(scope: !3631, file: !56, line: 1258, column: 6)
!3642 = !DILocalVariable(name: "match", scope: !3640, file: !56, line: 1260, type: !872)
!3643 = !DILocalVariable(name: "__val", scope: !3644, file: !56, line: 1265, type: !95)
!3644 = distinct !DILexicalBlock(scope: !3645, file: !56, line: 1265, column: 7)
!3645 = distinct !DILexicalBlock(scope: !3640, file: !56, line: 1265, column: 7)
!3646 = !DILocalVariable(name: "__val", scope: !3647, file: !56, line: 1276, type: !95)
!3647 = distinct !DILexicalBlock(scope: !3640, file: !56, line: 1276, column: 3)
!3648 = !DILocation(line: 0, scope: !3631, inlinedAt: !3649)
!3649 = distinct !DILocation(line: 1323, column: 9, scope: !3621, inlinedAt: !3628)
!3650 = !DILocation(line: 0, scope: !3640, inlinedAt: !3649)
!3651 = !DILocation(line: 1246, column: 2, scope: !3631, inlinedAt: !3649)
!3652 = !DILocation(line: 1246, column: 26, scope: !3631, inlinedAt: !3649)
!3653 = distinct !DIAssignID()
!3654 = !DILocation(line: 1246, column: 32, scope: !3631, inlinedAt: !3649)
!3655 = !DILocation(line: 1247, column: 22, scope: !3631, inlinedAt: !3649)
!3656 = !{!2866, !1266, i64 6}
!3657 = !{!3658, !1266, i64 16}
!3658 = !{!"lb6_affinity_key", !1131, i64 0, !1266, i64 16, !1131, i64 18, !1131, i64 18, !1131, i64 19, !1130, i64 20}
!3659 = distinct !DIAssignID()
!3660 = distinct !DIAssignID()
!3661 = !DILocation(line: 1253, column: 31, scope: !3662, inlinedAt: !3649)
!3662 = distinct !DILexicalBlock(scope: !3631, file: !56, line: 1252, column: 6)
!3663 = distinct !DIAssignID()
!3664 = !DILocation(line: 1257, column: 8, scope: !3631, inlinedAt: !3649)
!3665 = !DILocation(line: 1258, column: 10, scope: !3641, inlinedAt: !3649)
!3666 = !DILocation(line: 1258, column: 6, scope: !3631, inlinedAt: !3649)
!3667 = !DILocation(line: 1281, column: 1, scope: !3631, inlinedAt: !3649)
!3668 = !DILocation(line: 1109, column: 7, scope: !3629, inlinedAt: !2722)
!3669 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3670)
!3670 = distinct !DILocation(line: 1259, column: 22, scope: !3640, inlinedAt: !3649)
!3671 = !DILocation(line: 0, scope: !1617, inlinedAt: !3670)
!3672 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3670)
!3673 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3670)
!3674 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3670)
!3675 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3670)
!3676 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3670)
!3677 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3678)
!3678 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3670)
!3679 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3678)
!3680 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3670)
!3681 = !DILocation(line: 0, scope: !1619, inlinedAt: !3670)
!3682 = !DILocation(line: 1260, column: 3, scope: !3640, inlinedAt: !3649)
!3683 = !DILocation(line: 1262, column: 23, scope: !3640, inlinedAt: !3649)
!3684 = !DILocation(line: 1260, column: 36, scope: !3640, inlinedAt: !3649)
!3685 = distinct !DIAssignID()
!3686 = !DILocation(line: 1261, column: 23, scope: !3640, inlinedAt: !3649)
!3687 = distinct !DIAssignID()
!3688 = distinct !DIAssignID()
!3689 = !DILocation(line: 1265, column: 7, scope: !3644, inlinedAt: !3649)
!3690 = !DILocation(line: 0, scope: !3644, inlinedAt: !3649)
!3691 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3692)
!3692 = distinct !DILocation(line: 1265, column: 7, scope: !3644, inlinedAt: !3649)
!3693 = !DILocalVariable(name: "svc", arg: 1, scope: !3694, file: !56, line: 1237, type: !2705)
!3694 = distinct !DISubprogram(name: "lb6_affinity_timeout", scope: !56, file: !56, line: 1237, type: !3695, scopeLine: 1238, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3697)
!3695 = !DISubroutineType(types: !3696)
!3696 = !{!82, !2705}
!3697 = !{!3693}
!3698 = !DILocation(line: 0, scope: !3694, inlinedAt: !3699)
!3699 = distinct !DILocation(line: 1266, column: 23, scope: !3645, inlinedAt: !3649)
!3700 = !DILocation(line: 1239, column: 14, scope: !3694, inlinedAt: !3699)
!3701 = !DILocation(line: 1239, column: 31, scope: !3694, inlinedAt: !3699)
!3702 = !DILocation(line: 0, scope: !1668, inlinedAt: !3703)
!3703 = distinct !DILocation(line: 1266, column: 7, scope: !3645, inlinedAt: !3649)
!3704 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !3703)
!3705 = !DILocation(line: 0, scope: !1673, inlinedAt: !3703)
!3706 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !3703)
!3707 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !3703)
!3708 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !3703)
!3709 = !DILocation(line: 0, scope: !1676, inlinedAt: !3703)
!3710 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !3703)
!3711 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !3703)
!3712 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !3703)
!3713 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !3703)
!3714 = !DILocation(line: 1266, column: 7, scope: !3645, inlinedAt: !3649)
!3715 = !DILocation(line: 1265, column: 33, scope: !3645, inlinedAt: !3649)
!3716 = !DILocation(line: 1266, column: 53, scope: !3645, inlinedAt: !3649)
!3717 = !DILocation(line: 1266, column: 50, scope: !3645, inlinedAt: !3649)
!3718 = !DILocation(line: 1265, column: 7, scope: !3640, inlinedAt: !3649)
!3719 = !DILocation(line: 1271, column: 8, scope: !3720, inlinedAt: !3649)
!3720 = distinct !DILexicalBlock(scope: !3640, file: !56, line: 1271, column: 7)
!3721 = !DILocation(line: 1271, column: 7, scope: !3640, inlinedAt: !3649)
!3722 = !DILocation(line: 1278, column: 2, scope: !3641, inlinedAt: !3649)
!3723 = !DILocation(line: 0, scope: !3647, inlinedAt: !3649)
!3724 = !DILocation(line: 1276, column: 3, scope: !3647, inlinedAt: !3649)
!3725 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3726)
!3726 = distinct !DILocation(line: 1276, column: 3, scope: !3647, inlinedAt: !3649)
!3727 = !DILocation(line: 1277, column: 15, scope: !3640, inlinedAt: !3649)
!3728 = !DILocation(line: 1109, column: 18, scope: !3729, inlinedAt: !2722)
!3729 = distinct !DILexicalBlock(scope: !3629, file: !104, line: 1109, column: 7)
!3730 = !DILocalVariable(name: "backend_id", arg: 1, scope: !3731, file: !56, line: 1062, type: !82)
!3731 = distinct !DISubprogram(name: "__lb6_lookup_backend", scope: !56, file: !56, line: 1062, type: !3732, scopeLine: 1063, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3734)
!3732 = !DISubroutineType(types: !3733)
!3733 = !{!2702, !82}
!3734 = !{!3730}
!3735 = !DILocation(line: 0, scope: !3731, inlinedAt: !3736)
!3736 = distinct !DILocation(line: 1110, column: 14, scope: !3737, inlinedAt: !2722)
!3737 = distinct !DILexicalBlock(scope: !3729, file: !104, line: 1109, column: 24)
!3738 = distinct !DIAssignID()
!3739 = !DILocation(line: 1064, column: 9, scope: !3731, inlinedAt: !3736)
!3740 = !DILocation(line: 1064, column: 2, scope: !3731, inlinedAt: !3736)
!3741 = !DILocation(line: 1111, column: 9, scope: !3742, inlinedAt: !2722)
!3742 = distinct !DILexicalBlock(scope: !3737, file: !104, line: 1111, column: 8)
!3743 = !DILocation(line: 1113, column: 4, scope: !3737, inlinedAt: !2722)
!3744 = !{i64 2148422457}
!3745 = !DILocation(line: 0, scope: !3737, inlinedAt: !2722)
!3746 = !DILocation(line: 0, scope: !1724, inlinedAt: !3747)
!3747 = distinct !DILocation(line: 1120, column: 23, scope: !3748, inlinedAt: !2722)
!3748 = distinct !DILexicalBlock(scope: !3749, file: !104, line: 1117, column: 23)
!3749 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1117, column: 6)
!3750 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !3747)
!3751 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !3747)
!3752 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !3747)
!3753 = !DILocation(line: 0, scope: !1736, inlinedAt: !3754)
!3754 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !3747)
!3755 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3754)
!3756 = !DILocation(line: 1120, column: 52, scope: !3748, inlinedAt: !2722)
!3757 = !DILocation(line: 1120, column: 47, scope: !3748, inlinedAt: !2722)
!3758 = !DILocation(line: 1120, column: 45, scope: !3748, inlinedAt: !2722)
!3759 = !DILocation(line: 1120, column: 22, scope: !3748, inlinedAt: !2722)
!3760 = !DILocation(line: 1120, column: 20, scope: !3748, inlinedAt: !2722)
!3761 = distinct !DIAssignID()
!3762 = !DILocalVariable(name: "key", arg: 1, scope: !3763, file: !56, line: 1080, type: !578)
!3763 = distinct !DISubprogram(name: "__lb6_lookup_backend_slot", scope: !56, file: !56, line: 1080, type: !2847, scopeLine: 1081, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3764)
!3764 = !{!3762}
!3765 = !DILocation(line: 0, scope: !3763, inlinedAt: !3766)
!3766 = distinct !DILocation(line: 1121, column: 18, scope: !3748, inlinedAt: !2722)
!3767 = !DILocation(line: 0, scope: !2846, inlinedAt: !3768)
!3768 = distinct !DILocation(line: 1082, column: 9, scope: !3763, inlinedAt: !3766)
!3769 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !3768)
!3770 = !DILocation(line: 1122, column: 8, scope: !3771, inlinedAt: !2722)
!3771 = distinct !DILexicalBlock(scope: !3748, file: !104, line: 1122, column: 7)
!3772 = !DILocation(line: 1122, column: 7, scope: !3748, inlinedAt: !2722)
!3773 = !DILocation(line: 0, scope: !1761, inlinedAt: !3774)
!3774 = distinct !DILocation(line: 1123, column: 4, scope: !3775, inlinedAt: !2722)
!3775 = distinct !DILexicalBlock(scope: !3771, file: !104, line: 1122, column: 22)
!3776 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3774)
!3777 = distinct !DIAssignID()
!3778 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3774)
!3779 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3774)
!3780 = distinct !DIAssignID()
!3781 = distinct !DIAssignID()
!3782 = distinct !DIAssignID()
!3783 = distinct !DIAssignID()
!3784 = distinct !DIAssignID()
!3785 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3774)
!3786 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3774)
!3787 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3774)
!3788 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3774)
!3789 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3774)
!3790 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3774)
!3791 = distinct !DIAssignID()
!3792 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3774)
!3793 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3774)
!3794 = distinct !DIAssignID()
!3795 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3774)
!3796 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3774)
!3797 = !DILocation(line: 1124, column: 4, scope: !3775, inlinedAt: !2722)
!3798 = !DILocation(line: 1127, column: 30, scope: !3748, inlinedAt: !2722)
!3799 = !DILocation(line: 0, scope: !3731, inlinedAt: !3800)
!3800 = distinct !DILocation(line: 1128, column: 13, scope: !3748, inlinedAt: !2722)
!3801 = distinct !DIAssignID()
!3802 = !DILocation(line: 1064, column: 9, scope: !3731, inlinedAt: !3800)
!3803 = !DILocation(line: 1064, column: 2, scope: !3731, inlinedAt: !3800)
!3804 = !DILocation(line: 1131, column: 7, scope: !3805, inlinedAt: !2722)
!3805 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1131, column: 6)
!3806 = !DILocation(line: 1131, column: 6, scope: !2692, inlinedAt: !2722)
!3807 = !DILocation(line: 0, scope: !1761, inlinedAt: !3808)
!3808 = distinct !DILocation(line: 1132, column: 3, scope: !3809, inlinedAt: !2722)
!3809 = distinct !DILexicalBlock(scope: !3805, file: !104, line: 1131, column: 16)
!3810 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3808)
!3811 = distinct !DIAssignID()
!3812 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3808)
!3813 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3808)
!3814 = distinct !DIAssignID()
!3815 = distinct !DIAssignID()
!3816 = distinct !DIAssignID()
!3817 = distinct !DIAssignID()
!3818 = distinct !DIAssignID()
!3819 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3808)
!3820 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3808)
!3821 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3808)
!3822 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3808)
!3823 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3808)
!3824 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3808)
!3825 = distinct !DIAssignID()
!3826 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3808)
!3827 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3808)
!3828 = distinct !DIAssignID()
!3829 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3808)
!3830 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3808)
!3831 = !DILocation(line: 1133, column: 3, scope: !3809, inlinedAt: !2722)
!3832 = !DILocation(line: 1135, column: 2, scope: !2692, inlinedAt: !2722)
!3833 = !{i64 2148422807}
!3834 = !DILocation(line: 0, scope: !3611, inlinedAt: !3835)
!3835 = distinct !DILocation(line: 1137, column: 6, scope: !3836, inlinedAt: !2722)
!3836 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1137, column: 6)
!3837 = !DILocation(line: 525, column: 14, scope: !3611, inlinedAt: !3835)
!3838 = !DILocation(line: 525, column: 20, scope: !3611, inlinedAt: !3835)
!3839 = !DILocation(line: 525, column: 9, scope: !3611, inlinedAt: !3835)
!3840 = !DILocation(line: 1137, column: 31, scope: !3836, inlinedAt: !2722)
!3841 = !DILocalVariable(name: "svc", arg: 1, scope: !3842, file: !56, line: 1327, type: !2705)
!3842 = distinct !DISubprogram(name: "lb6_update_affinity_by_netns", scope: !56, file: !56, line: 1327, type: !3843, scopeLine: 1330, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3845)
!3843 = !DISubroutineType(types: !3844)
!3844 = !{null, !2705, !3624, !82}
!3845 = !{!3841, !3846, !3847}
!3846 = !DILocalVariable(name: "id", arg: 2, scope: !3842, file: !56, line: 1328, type: !3624)
!3847 = !DILocalVariable(name: "backend_id", arg: 3, scope: !3842, file: !56, line: 1329, type: !82)
!3848 = !DILocation(line: 0, scope: !3842, inlinedAt: !3849)
!3849 = distinct !DILocation(line: 1138, column: 3, scope: !3836, inlinedAt: !2722)
!3850 = !DILocalVariable(name: "key", scope: !3851, file: !56, line: 1295, type: !633)
!3851 = distinct !DISubprogram(name: "__lb6_update_affinity", scope: !56, file: !56, line: 1291, type: !3852, scopeLine: 1293, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3854)
!3852 = !DISubroutineType(types: !3853)
!3853 = !{null, !2705, !90, !3624, !82}
!3854 = !{!3855, !3856, !3857, !3858, !3859, !3850, !3860}
!3855 = !DILocalVariable(name: "svc", arg: 1, scope: !3851, file: !56, line: 1291, type: !2705)
!3856 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !3851, file: !56, line: 1291, type: !90)
!3857 = !DILocalVariable(name: "id", arg: 3, scope: !3851, file: !56, line: 1292, type: !3624)
!3858 = !DILocalVariable(name: "backend_id", arg: 4, scope: !3851, file: !56, line: 1292, type: !82)
!3859 = !DILocalVariable(name: "now", scope: !3851, file: !56, line: 1294, type: !82)
!3860 = !DILocalVariable(name: "val", scope: !3851, file: !56, line: 1299, type: !648)
!3861 = !DILocation(line: 0, scope: !3851, inlinedAt: !3862)
!3862 = distinct !DILocation(line: 1331, column: 2, scope: !3842, inlinedAt: !3849)
!3863 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3864)
!3864 = distinct !DILocation(line: 1294, column: 21, scope: !3851, inlinedAt: !3862)
!3865 = !DILocation(line: 0, scope: !1617, inlinedAt: !3864)
!3866 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3864)
!3867 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3864)
!3868 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3864)
!3869 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3864)
!3870 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3864)
!3871 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3872)
!3872 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3864)
!3873 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3872)
!3874 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3864)
!3875 = !DILocation(line: 0, scope: !1619, inlinedAt: !3864)
!3876 = !DILocation(line: 1295, column: 2, scope: !3851, inlinedAt: !3862)
!3877 = !DILocation(line: 1295, column: 26, scope: !3851, inlinedAt: !3862)
!3878 = distinct !DIAssignID()
!3879 = distinct !DIAssignID()
!3880 = !DILocation(line: 1295, column: 32, scope: !3851, inlinedAt: !3862)
!3881 = !DILocation(line: 1296, column: 22, scope: !3851, inlinedAt: !3862)
!3882 = distinct !DIAssignID()
!3883 = distinct !DIAssignID()
!3884 = !DILocation(line: 1299, column: 2, scope: !3851, inlinedAt: !3862)
!3885 = !DILocation(line: 1301, column: 16, scope: !3851, inlinedAt: !3862)
!3886 = !DILocation(line: 1299, column: 31, scope: !3851, inlinedAt: !3862)
!3887 = distinct !DIAssignID()
!3888 = distinct !DIAssignID()
!3889 = distinct !DIAssignID()
!3890 = !DILocation(line: 1305, column: 31, scope: !3891, inlinedAt: !3862)
!3891 = distinct !DILexicalBlock(scope: !3851, file: !56, line: 1304, column: 6)
!3892 = distinct !DIAssignID()
!3893 = !DILocation(line: 1309, column: 2, scope: !3851, inlinedAt: !3862)
!3894 = !DILocation(line: 1310, column: 1, scope: !3851, inlinedAt: !3862)
!3895 = !DILocation(line: 1138, column: 3, scope: !3836, inlinedAt: !2722)
!3896 = !DILocation(line: 1141, column: 5, scope: !2692, inlinedAt: !2722)
!3897 = !DILocation(line: 1147, column: 10, scope: !3898, inlinedAt: !2722)
!3898 = distinct !DILexicalBlock(scope: !2692, file: !104, line: 1146, column: 6)
!3899 = !DILocalVariable(name: "val", scope: !3900, file: !104, line: 667, type: !990)
!3900 = distinct !DISubprogram(name: "sock6_update_revnat", scope: !104, file: !104, line: 661, type: !3901, scopeLine: 666, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3903)
!3901 = !DISubroutineType(types: !3902)
!3902 = !{!305, !1136, !2702, !2784, !92, !85}
!3903 = !{!3904, !3905, !3906, !3907, !3908, !3899, !3909, !3910, !3911}
!3904 = !DILocalVariable(name: "ctx", arg: 1, scope: !3900, file: !104, line: 661, type: !1136)
!3905 = !DILocalVariable(name: "backend", arg: 2, scope: !3900, file: !104, line: 662, type: !2702)
!3906 = !DILocalVariable(name: "dst_ip", arg: 3, scope: !3900, file: !104, line: 663, type: !2784)
!3907 = !DILocalVariable(name: "dst_port", arg: 4, scope: !3900, file: !104, line: 664, type: !92)
!3908 = !DILocalVariable(name: "rev_nat_index", arg: 5, scope: !3900, file: !104, line: 665, type: !85)
!3909 = !DILocalVariable(name: "tmp", scope: !3900, file: !104, line: 667, type: !989)
!3910 = !DILocalVariable(name: "key", scope: !3900, file: !104, line: 668, type: !982)
!3911 = !DILocalVariable(name: "ret", scope: !3900, file: !104, line: 669, type: !305)
!3912 = !DILocation(line: 0, scope: !3900, inlinedAt: !3913)
!3913 = distinct !DILocation(line: 1146, column: 6, scope: !3898, inlinedAt: !2722)
!3914 = !DILocation(line: 667, column: 2, scope: !3900, inlinedAt: !3913)
!3915 = distinct !DIAssignID()
!3916 = !DILocation(line: 668, column: 2, scope: !3900, inlinedAt: !3913)
!3917 = !DILocation(line: 668, column: 27, scope: !3900, inlinedAt: !3913)
!3918 = distinct !DIAssignID()
!3919 = distinct !DIAssignID()
!3920 = !DILocation(line: 0, scope: !1736, inlinedAt: !3921)
!3921 = distinct !DILocation(line: 671, column: 15, scope: !3900, inlinedAt: !3913)
!3922 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3921)
!3923 = !DILocation(line: 671, column: 13, scope: !3900, inlinedAt: !3913)
!3924 = !{!3925, !1535, i64 0}
!3925 = !{!"ipv6_revnat_tuple", !1535, i64 0, !1131, i64 8, !1266, i64 24, !1266, i64 26}
!3926 = distinct !DIAssignID()
!3927 = !DILocation(line: 672, column: 6, scope: !3900, inlinedAt: !3913)
!3928 = !DILocation(line: 672, column: 25, scope: !3900, inlinedAt: !3913)
!3929 = distinct !DIAssignID()
!3930 = !DILocation(line: 673, column: 22, scope: !3900, inlinedAt: !3913)
!3931 = !{!3932, !1266, i64 16}
!3932 = !{!"lb6_backend", !1131, i64 0, !1266, i64 16, !1131, i64 18, !1131, i64 19, !1266, i64 20, !1131, i64 22, !1131, i64 23}
!3933 = !DILocation(line: 673, column: 6, scope: !3900, inlinedAt: !3913)
!3934 = !DILocation(line: 673, column: 11, scope: !3900, inlinedAt: !3913)
!3935 = !{!3925, !1266, i64 24}
!3936 = distinct !DIAssignID()
!3937 = !DILocation(line: 675, column: 16, scope: !3900, inlinedAt: !3913)
!3938 = distinct !DIAssignID()
!3939 = distinct !DIAssignID()
!3940 = !DILocation(line: 676, column: 6, scope: !3900, inlinedAt: !3913)
!3941 = !DILocation(line: 676, column: 11, scope: !3900, inlinedAt: !3913)
!3942 = !{!3943, !1266, i64 16}
!3943 = !{!"ipv6_revnat_entry", !1131, i64 0, !1266, i64 16, !1266, i64 18}
!3944 = distinct !DIAssignID()
!3945 = !DILocation(line: 677, column: 6, scope: !3900, inlinedAt: !3913)
!3946 = !DILocation(line: 677, column: 20, scope: !3900, inlinedAt: !3913)
!3947 = !{!3943, !1266, i64 18}
!3948 = distinct !DIAssignID()
!3949 = !DILocation(line: 679, column: 8, scope: !3900, inlinedAt: !3913)
!3950 = !DILocation(line: 680, column: 7, scope: !3951, inlinedAt: !3913)
!3951 = distinct !DILexicalBlock(scope: !3900, file: !104, line: 680, column: 6)
!3952 = !DILocation(line: 680, column: 11, scope: !3951, inlinedAt: !3913)
!3953 = !DILocation(line: 0, scope: !1963, inlinedAt: !3954)
!3954 = distinct !DILocation(line: 680, column: 14, scope: !3951, inlinedAt: !3913)
!3955 = !DILocation(line: 0, scope: !1972, inlinedAt: !3956)
!3956 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !3954)
!3957 = !DILocation(line: 364, column: 12, scope: !1978, inlinedAt: !3956)
!3958 = !DILocation(line: 329, column: 12, scope: !1978, inlinedAt: !3956)
!3959 = !DILocation(line: 329, column: 21, scope: !1978, inlinedAt: !3956)
!3960 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !3956)
!3961 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !3956)
!3962 = !DILocation(line: 680, column: 14, scope: !3951, inlinedAt: !3913)
!3963 = !DILocation(line: 680, column: 6, scope: !3900, inlinedAt: !3913)
!3964 = !DILocation(line: 684, column: 1, scope: !3900, inlinedAt: !3913)
!3965 = !DILocation(line: 1146, column: 6, scope: !2692, inlinedAt: !2722)
!3966 = !DILocation(line: 681, column: 9, scope: !3951, inlinedAt: !3913)
!3967 = !DILocation(line: 1147, column: 25, scope: !3898, inlinedAt: !2722)
!3968 = !DILocation(line: 0, scope: !1761, inlinedAt: !3969)
!3969 = distinct !DILocation(line: 1148, column: 3, scope: !3970, inlinedAt: !2722)
!3970 = distinct !DILexicalBlock(scope: !3898, file: !104, line: 1147, column: 30)
!3971 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3969)
!3972 = distinct !DIAssignID()
!3973 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3969)
!3974 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3969)
!3975 = distinct !DIAssignID()
!3976 = distinct !DIAssignID()
!3977 = distinct !DIAssignID()
!3978 = distinct !DIAssignID()
!3979 = distinct !DIAssignID()
!3980 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3969)
!3981 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3969)
!3982 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3969)
!3983 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3969)
!3984 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3969)
!3985 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3969)
!3986 = distinct !DIAssignID()
!3987 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3969)
!3988 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3969)
!3989 = distinct !DIAssignID()
!3990 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3969)
!3991 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3969)
!3992 = !DILocation(line: 1159, column: 1, scope: !2692, inlinedAt: !2722)
!3993 = !DILocation(line: 1172, column: 27, scope: !3994)
!3994 = distinct !DILexicalBlock(scope: !2649, file: !104, line: 1172, column: 6)
!3995 = !DILocation(line: 0, scope: !3399, inlinedAt: !3996)
!3996 = distinct !DILocation(line: 1152, column: 2, scope: !2692, inlinedAt: !2722)
!3997 = !DILocation(line: 744, column: 27, scope: !3399, inlinedAt: !3996)
!3998 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !3996)
!3999 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !3996)
!4000 = !DILocation(line: 746, column: 27, scope: !3399, inlinedAt: !3996)
!4001 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !3996)
!4002 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !3996)
!4003 = !DILocation(line: 748, column: 27, scope: !3399, inlinedAt: !3996)
!4004 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !3996)
!4005 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !3996)
!4006 = !DILocation(line: 750, column: 27, scope: !3399, inlinedAt: !3996)
!4007 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !3996)
!4008 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !3996)
!4009 = !DILocation(line: 1153, column: 29, scope: !2692, inlinedAt: !2722)
!4010 = !DILocation(line: 0, scope: !2034, inlinedAt: !4011)
!4011 = distinct !DILocation(line: 1153, column: 2, scope: !2692, inlinedAt: !2722)
!4012 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !4011)
!4013 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !4011)
!4014 = !DILocation(line: 1155, column: 2, scope: !2692, inlinedAt: !2722)
!4015 = !DILocation(line: 1172, column: 10, scope: !3994)
!4016 = !DILocation(line: 1174, column: 3, scope: !4017)
!4017 = distinct !DILexicalBlock(scope: !3994, file: !104, line: 1172, column: 46)
!4018 = !DILocation(line: 1178, column: 1, scope: !2649)
!4019 = distinct !DISubprogram(name: "cil_sock6_sendmsg", scope: !104, file: !104, line: 1258, type: !1134, scopeLine: 1259, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !4020)
!4020 = !{!4021, !4022}
!4021 = !DILocalVariable(name: "ctx", arg: 1, scope: !4019, file: !104, line: 1258, type: !1136)
!4022 = !DILocalVariable(name: "err", scope: !4019, file: !104, line: 1260, type: !305)
!4023 = distinct !DIAssignID()
!4024 = distinct !DIAssignID()
!4025 = distinct !DIAssignID()
!4026 = distinct !DIAssignID()
!4027 = distinct !DIAssignID()
!4028 = distinct !DIAssignID()
!4029 = distinct !DIAssignID()
!4030 = distinct !DIAssignID()
!4031 = distinct !DIAssignID()
!4032 = distinct !DIAssignID()
!4033 = distinct !DIAssignID()
!4034 = distinct !DIAssignID()
!4035 = distinct !DIAssignID()
!4036 = distinct !DIAssignID()
!4037 = distinct !DIAssignID()
!4038 = distinct !DIAssignID()
!4039 = distinct !DIAssignID()
!4040 = distinct !DIAssignID()
!4041 = distinct !DIAssignID()
!4042 = distinct !DIAssignID()
!4043 = distinct !DIAssignID()
!4044 = distinct !DIAssignID()
!4045 = distinct !DIAssignID()
!4046 = distinct !DIAssignID()
!4047 = distinct !DIAssignID()
!4048 = distinct !DIAssignID()
!4049 = distinct !DIAssignID()
!4050 = distinct !DIAssignID()
!4051 = distinct !DIAssignID()
!4052 = distinct !DIAssignID()
!4053 = distinct !DIAssignID()
!4054 = distinct !DIAssignID()
!4055 = distinct !DIAssignID()
!4056 = distinct !DIAssignID()
!4057 = distinct !DIAssignID()
!4058 = distinct !DIAssignID()
!4059 = distinct !DIAssignID()
!4060 = !DILocation(line: 0, scope: !4019)
!4061 = !DILocation(line: 0, scope: !2692, inlinedAt: !4062)
!4062 = distinct !DILocation(line: 1262, column: 8, scope: !4019)
!4063 = !DILocation(line: 0, scope: !1228, inlinedAt: !4064)
!4064 = distinct !DILocation(line: 1034, column: 25, scope: !2692, inlinedAt: !4062)
!4065 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !4064)
!4066 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !4064)
!4067 = !DILocation(line: 0, scope: !1240, inlinedAt: !4068)
!4068 = distinct !DILocation(line: 1037, column: 20, scope: !2692, inlinedAt: !4062)
!4069 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !4068)
!4070 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !4068)
!4071 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !4068)
!4072 = distinct !DIAssignID()
!4073 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !4068)
!4074 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !4068)
!4075 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !4068)
!4076 = !DILocation(line: 1038, column: 18, scope: !2692, inlinedAt: !4062)
!4077 = !DILocation(line: 1040, column: 2, scope: !2692, inlinedAt: !4062)
!4078 = !DILocation(line: 1040, column: 17, scope: !2692, inlinedAt: !4062)
!4079 = distinct !DIAssignID()
!4080 = distinct !DIAssignID()
!4081 = !DILocation(line: 1040, column: 39, scope: !2692, inlinedAt: !4062)
!4082 = distinct !DIAssignID()
!4083 = distinct !DIAssignID()
!4084 = !DILocation(line: 0, scope: !2752, inlinedAt: !4085)
!4085 = distinct !DILocation(line: 1057, column: 2, scope: !2692, inlinedAt: !4062)
!4086 = !DILocation(line: 716, column: 18, scope: !2752, inlinedAt: !4085)
!4087 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !4085)
!4088 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !4085)
!4089 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !4085)
!4090 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !4085)
!4091 = !DILocation(line: 718, column: 8, scope: !2752, inlinedAt: !4085)
!4092 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !4085)
!4093 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !4085)
!4094 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !4085)
!4095 = !DILocation(line: 720, column: 8, scope: !2752, inlinedAt: !4085)
!4096 = !DILocation(line: 720, column: 11, scope: !2752, inlinedAt: !4085)
!4097 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !4085)
!4098 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !4085)
!4099 = !DILocation(line: 722, column: 8, scope: !2752, inlinedAt: !4085)
!4100 = !DILocation(line: 722, column: 11, scope: !2752, inlinedAt: !4085)
!4101 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !4085)
!4102 = !DILocation(line: 0, scope: !2781, inlinedAt: !4103)
!4103 = distinct !DILocation(line: 1058, column: 2, scope: !2692, inlinedAt: !4062)
!4104 = !DILocation(line: 0, scope: !2791, inlinedAt: !4105)
!4105 = distinct !DILocation(line: 29, column: 2, scope: !2781, inlinedAt: !4103)
!4106 = !DILocation(line: 0, scope: !2800, inlinedAt: !4107)
!4107 = distinct !DILocation(line: 280, column: 9, scope: !2791, inlinedAt: !4105)
!4108 = !DILocation(line: 196, column: 12, scope: !2805, inlinedAt: !4107)
!4109 = !DILocation(line: 196, column: 21, scope: !2805, inlinedAt: !4107)
!4110 = !DILocation(line: 197, column: 12, scope: !2805, inlinedAt: !4107)
!4111 = !DILocation(line: 197, column: 21, scope: !2805, inlinedAt: !4107)
!4112 = !DILocation(line: 0, scope: !2827, inlinedAt: !4113)
!4113 = distinct !DILocation(line: 1060, column: 8, scope: !2692, inlinedAt: !4062)
!4114 = !DILocation(line: 981, column: 7, scope: !2827, inlinedAt: !4113)
!4115 = !DILocation(line: 981, column: 20, scope: !2827, inlinedAt: !4113)
!4116 = !DILocation(line: 983, column: 7, scope: !2827, inlinedAt: !4113)
!4117 = !DILocation(line: 983, column: 13, scope: !2827, inlinedAt: !4113)
!4118 = !DILocation(line: 0, scope: !2846, inlinedAt: !4119)
!4119 = distinct !DILocation(line: 984, column: 8, scope: !2827, inlinedAt: !4113)
!4120 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !4119)
!4121 = !DILocation(line: 985, column: 7, scope: !2854, inlinedAt: !4113)
!4122 = !DILocation(line: 985, column: 6, scope: !2827, inlinedAt: !4113)
!4123 = !DILocation(line: 0, scope: !2857, inlinedAt: !4124)
!4124 = distinct !DILocation(line: 1005, column: 21, scope: !2863, inlinedAt: !4113)
!4125 = !DILocation(line: 513, column: 14, scope: !2857, inlinedAt: !4124)
!4126 = !DILocation(line: 513, column: 21, scope: !2857, inlinedAt: !4124)
!4127 = !DILocation(line: 513, column: 9, scope: !2857, inlinedAt: !4124)
!4128 = !DILocation(line: 1005, column: 6, scope: !2827, inlinedAt: !4113)
!4129 = !DILocation(line: 1008, column: 13, scope: !2827, inlinedAt: !4113)
!4130 = !DILocation(line: 0, scope: !2846, inlinedAt: !4131)
!4131 = distinct !DILocation(line: 1009, column: 9, scope: !2827, inlinedAt: !4113)
!4132 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !4131)
!4133 = !DILocation(line: 1061, column: 7, scope: !2875, inlinedAt: !4062)
!4134 = !DILocation(line: 1061, column: 6, scope: !2692, inlinedAt: !4062)
!4135 = !DILocation(line: 0, scope: !2878, inlinedAt: !4136)
!4136 = distinct !DILocation(line: 1064, column: 10, scope: !2887, inlinedAt: !4062)
!4137 = !DILocation(line: 0, scope: !2752, inlinedAt: !4138)
!4138 = distinct !DILocation(line: 860, column: 2, scope: !2878, inlinedAt: !4136)
!4139 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !4138)
!4140 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !4138)
!4141 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !4138)
!4142 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !4138)
!4143 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !4138)
!4144 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !4138)
!4145 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !4138)
!4146 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !4138)
!4147 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !4138)
!4148 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !4138)
!4149 = !DILocation(line: 0, scope: !2901, inlinedAt: !4150)
!4150 = distinct !DILocation(line: 861, column: 7, scope: !2910, inlinedAt: !4136)
!4151 = !DILocation(line: 0, scope: !2912, inlinedAt: !4152)
!4152 = distinct !DILocation(line: 28, column: 9, scope: !2901, inlinedAt: !4150)
!4153 = !DILocation(line: 42, column: 12, scope: !2920, inlinedAt: !4152)
!4154 = !DILocation(line: 42, column: 6, scope: !2912, inlinedAt: !4152)
!4155 = !DILocation(line: 0, scope: !1498, inlinedAt: !4156)
!4156 = distinct !DILocation(line: 864, column: 2, scope: !2878, inlinedAt: !4136)
!4157 = !DILocation(line: 0, scope: !1508, inlinedAt: !4158)
!4158 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !4156)
!4159 = !DILocation(line: 64, column: 12, scope: !1514, inlinedAt: !4158)
!4160 = !DILocation(line: 65, column: 12, scope: !1514, inlinedAt: !4158)
!4161 = !DILocation(line: 66, column: 12, scope: !1514, inlinedAt: !4158)
!4162 = !DILocation(line: 67, column: 12, scope: !1514, inlinedAt: !4158)
!4163 = !DILocation(line: 68, column: 12, scope: !1514, inlinedAt: !4158)
!4164 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !4158)
!4165 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !4158)
!4166 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !4158)
!4167 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !4158)
!4168 = !DILocation(line: 865, column: 23, scope: !2878, inlinedAt: !4136)
!4169 = !DILocation(line: 0, scope: !1240, inlinedAt: !4170)
!4170 = distinct !DILocation(line: 867, column: 23, scope: !2878, inlinedAt: !4136)
!4171 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !4170)
!4172 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !4170)
!4173 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !4170)
!4174 = distinct !DIAssignID()
!4175 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !4170)
!4176 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !4170)
!4177 = !DILocation(line: 867, column: 23, scope: !2878, inlinedAt: !4136)
!4178 = !DILocation(line: 0, scope: !1194, inlinedAt: !4179)
!4179 = distinct !DILocation(line: 869, column: 8, scope: !2878, inlinedAt: !4136)
!4180 = !DILocation(line: 0, scope: !1228, inlinedAt: !4181)
!4181 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !4179)
!4182 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !4181)
!4183 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !4181)
!4184 = !DILocation(line: 0, scope: !1240, inlinedAt: !4185)
!4185 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !4179)
!4186 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !4185)
!4187 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !4185)
!4188 = distinct !DIAssignID()
!4189 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !4185)
!4190 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !4185)
!4191 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !4185)
!4192 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !4179)
!4193 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !4179)
!4194 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !4179)
!4195 = distinct !DIAssignID()
!4196 = distinct !DIAssignID()
!4197 = distinct !DIAssignID()
!4198 = distinct !DIAssignID()
!4199 = distinct !DIAssignID()
!4200 = distinct !DIAssignID()
!4201 = distinct !DIAssignID()
!4202 = !DILocation(line: 0, scope: !1285, inlinedAt: !4203)
!4203 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !4179)
!4204 = distinct !DIAssignID()
!4205 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !4203)
!4206 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !4203)
!4207 = !DILocation(line: 0, scope: !1302, inlinedAt: !4208)
!4208 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !4203)
!4209 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !4208)
!4210 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !4203)
!4211 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !4203)
!4212 = !DILocation(line: 0, scope: !1313, inlinedAt: !4213)
!4213 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !4203)
!4214 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !4213)
!4215 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !4213)
!4216 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !4213)
!4217 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !4203)
!4218 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !4203)
!4219 = !DILocation(line: 0, scope: !1302, inlinedAt: !4220)
!4220 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !4203)
!4221 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !4220)
!4222 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !4179)
!4223 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !4179)
!4224 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !4179)
!4225 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !4179)
!4226 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !4179)
!4227 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !4179)
!4228 = !DILocation(line: 0, scope: !1218, inlinedAt: !4179)
!4229 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !4179)
!4230 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !4179)
!4231 = !DILocation(line: 0, scope: !1347, inlinedAt: !4232)
!4232 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !4179)
!4233 = !DILocation(line: 0, scope: !1355, inlinedAt: !4234)
!4234 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !4232)
!4235 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !4234)
!4236 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !4234)
!4237 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !4234)
!4238 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !4232)
!4239 = !DILocation(line: 0, scope: !1366, inlinedAt: !4240)
!4240 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !4232)
!4241 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !4240)
!4242 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !4240)
!4243 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !4232)
!4244 = !DILocation(line: 0, scope: !1355, inlinedAt: !4245)
!4245 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !4232)
!4246 = !DILocation(line: 0, scope: !1376, inlinedAt: !4247)
!4247 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !4232)
!4248 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !4247)
!4249 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !4247)
!4250 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !4247)
!4251 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !4232)
!4252 = !DILocation(line: 0, scope: !1386, inlinedAt: !4253)
!4253 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !4179)
!4254 = !DILocation(line: 0, scope: !1392, inlinedAt: !4255)
!4255 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !4253)
!4256 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !4255)
!4257 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !4255)
!4258 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !4255)
!4259 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !4253)
!4260 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !4253)
!4261 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !4253)
!4262 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !4179)
!4263 = !DILocation(line: 0, scope: !1404, inlinedAt: !4264)
!4264 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !4179)
!4265 = !DILocation(line: 0, scope: !1418, inlinedAt: !4266)
!4266 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !4264)
!4267 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !4266)
!4268 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !4266)
!4269 = !DILocation(line: 0, scope: !1392, inlinedAt: !4270)
!4270 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !4264)
!4271 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !4264)
!4272 = !DILocation(line: 0, scope: !1428, inlinedAt: !4273)
!4273 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !4264)
!4274 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !4273)
!4275 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !4273)
!4276 = distinct !DIAssignID()
!4277 = distinct !DIAssignID()
!4278 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !4273)
!4279 = distinct !DIAssignID()
!4280 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !4273)
!4281 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !4273)
!4282 = distinct !DIAssignID()
!4283 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !4273)
!4284 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !4273)
!4285 = distinct !DIAssignID()
!4286 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !4273)
!4287 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !4273)
!4288 = distinct !DIAssignID()
!4289 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !4273)
!4290 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !4273)
!4291 = !DILocation(line: 0, scope: !1410, inlinedAt: !4264)
!4292 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !4264)
!4293 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !4264)
!4294 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !4264)
!4295 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !4264)
!4296 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !4264)
!4297 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !4179)
!4298 = !DILocation(line: 0, scope: !1223, inlinedAt: !4179)
!4299 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !4179)
!4300 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !4179)
!4301 = !DILocation(line: 0, scope: !1476, inlinedAt: !4302)
!4302 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !4179)
!4303 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !4302)
!4304 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !4302)
!4305 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !4302)
!4306 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !4179)
!4307 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !4179)
!4308 = !DILocation(line: 0, scope: !1486, inlinedAt: !4309)
!4309 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !4179)
!4310 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !4309)
!4311 = !DILocation(line: 0, scope: !1498, inlinedAt: !4312)
!4312 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !4309)
!4313 = !DILocation(line: 0, scope: !1508, inlinedAt: !4314)
!4314 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !4312)
!4315 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !4314)
!4316 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !4314)
!4317 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !4314)
!4318 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !4309)
!4319 = distinct !DIAssignID()
!4320 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !4309)
!4321 = distinct !DIAssignID()
!4322 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !4309)
!4323 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !4309)
!4324 = distinct !DIAssignID()
!4325 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !4309)
!4326 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !4309)
!4327 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !4309)
!4328 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !4179)
!4329 = !DILocation(line: 0, scope: !1554, inlinedAt: !4330)
!4330 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !4179)
!4331 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !4330)
!4332 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !4330)
!4333 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !4330)
!4334 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !4179)
!4335 = !DILocation(line: 0, scope: !1564, inlinedAt: !4336)
!4336 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !4179)
!4337 = !DILocation(line: 0, scope: !1574, inlinedAt: !4338)
!4338 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !4336)
!4339 = !DILocation(line: 0, scope: !1585, inlinedAt: !4338)
!4340 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !4338)
!4341 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !4338)
!4342 = distinct !DIAssignID()
!4343 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !4338)
!4344 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !4338)
!4345 = distinct !DIAssignID()
!4346 = distinct !DIAssignID()
!4347 = distinct !DIAssignID()
!4348 = distinct !DIAssignID()
!4349 = distinct !DIAssignID()
!4350 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !4338)
!4351 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !4338)
!4352 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !4338)
!4353 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !4338)
!4354 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !4179)
!4355 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !4356)
!4356 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !4338)
!4357 = !DILocation(line: 0, scope: !1617, inlinedAt: !4356)
!4358 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !4356)
!4359 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !4356)
!4360 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !4356)
!4361 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !4356)
!4362 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !4356)
!4363 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !4364)
!4364 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !4356)
!4365 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !4364)
!4366 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !4356)
!4367 = !DILocation(line: 0, scope: !1619, inlinedAt: !4356)
!4368 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !4338)
!4369 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !4338)
!4370 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !4338)
!4371 = distinct !DIAssignID()
!4372 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !4338)
!4373 = distinct !DIAssignID()
!4374 = distinct !DIAssignID()
!4375 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !4338)
!4376 = !DILocation(line: 0, scope: !1589, inlinedAt: !4338)
!4377 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !4378)
!4378 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !4338)
!4379 = !DILocation(line: 0, scope: !1659, inlinedAt: !4380)
!4380 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !4338)
!4381 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !4380)
!4382 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !4380)
!4383 = !DILocation(line: 0, scope: !1668, inlinedAt: !4384)
!4384 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !4338)
!4385 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !4384)
!4386 = !DILocation(line: 0, scope: !1673, inlinedAt: !4384)
!4387 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !4384)
!4388 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !4384)
!4389 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !4384)
!4390 = !DILocation(line: 0, scope: !1676, inlinedAt: !4384)
!4391 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !4384)
!4392 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !4384)
!4393 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !4384)
!4394 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !4384)
!4395 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !4338)
!4396 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !4338)
!4397 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !4338)
!4398 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !4338)
!4399 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !4338)
!4400 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !4338)
!4401 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !4338)
!4402 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !4338)
!4403 = !DILocation(line: 0, scope: !1592, inlinedAt: !4338)
!4404 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !4338)
!4405 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !4406)
!4406 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !4338)
!4407 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !4338)
!4408 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !4179)
!4409 = !DILocation(line: 0, scope: !1708, inlinedAt: !4410)
!4410 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !4179)
!4411 = distinct !DIAssignID()
!4412 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !4410)
!4413 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !4410)
!4414 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !4179)
!4415 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !4179)
!4416 = !DILocation(line: 0, scope: !1714, inlinedAt: !4179)
!4417 = !DILocation(line: 0, scope: !1724, inlinedAt: !4418)
!4418 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !4179)
!4419 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !4418)
!4420 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !4418)
!4421 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !4418)
!4422 = !DILocation(line: 0, scope: !1736, inlinedAt: !4423)
!4423 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !4418)
!4424 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !4423)
!4425 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !4179)
!4426 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !4179)
!4427 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !4179)
!4428 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !4179)
!4429 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !4179)
!4430 = distinct !DIAssignID()
!4431 = !DILocation(line: 0, scope: !1750, inlinedAt: !4432)
!4432 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !4179)
!4433 = !DILocation(line: 0, scope: !1302, inlinedAt: !4434)
!4434 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !4432)
!4435 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !4434)
!4436 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !4179)
!4437 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !4179)
!4438 = !DILocation(line: 0, scope: !1761, inlinedAt: !4439)
!4439 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !4179)
!4440 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !4439)
!4441 = distinct !DIAssignID()
!4442 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !4439)
!4443 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !4439)
!4444 = distinct !DIAssignID()
!4445 = distinct !DIAssignID()
!4446 = distinct !DIAssignID()
!4447 = distinct !DIAssignID()
!4448 = distinct !DIAssignID()
!4449 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !4439)
!4450 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !4439)
!4451 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !4439)
!4452 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !4439)
!4453 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !4439)
!4454 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !4439)
!4455 = distinct !DIAssignID()
!4456 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !4439)
!4457 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !4439)
!4458 = distinct !DIAssignID()
!4459 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !4439)
!4460 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !4439)
!4461 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !4179)
!4462 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !4179)
!4463 = !DILocation(line: 0, scope: !1708, inlinedAt: !4464)
!4464 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !4179)
!4465 = distinct !DIAssignID()
!4466 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !4464)
!4467 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !4464)
!4468 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !4179)
!4469 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !4179)
!4470 = !DILocation(line: 0, scope: !1761, inlinedAt: !4471)
!4471 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !4179)
!4472 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !4471)
!4473 = distinct !DIAssignID()
!4474 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !4471)
!4475 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !4471)
!4476 = distinct !DIAssignID()
!4477 = distinct !DIAssignID()
!4478 = distinct !DIAssignID()
!4479 = distinct !DIAssignID()
!4480 = distinct !DIAssignID()
!4481 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !4471)
!4482 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !4471)
!4483 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !4471)
!4484 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !4471)
!4485 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !4471)
!4486 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !4471)
!4487 = distinct !DIAssignID()
!4488 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !4471)
!4489 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !4471)
!4490 = distinct !DIAssignID()
!4491 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !4471)
!4492 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !4471)
!4493 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !4179)
!4494 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !4179)
!4495 = !DILocation(line: 0, scope: !1554, inlinedAt: !4496)
!4496 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !4179)
!4497 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !4496)
!4498 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !4496)
!4499 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !4496)
!4500 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !4179)
!4501 = !DILocation(line: 0, scope: !1847, inlinedAt: !4502)
!4502 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !4179)
!4503 = !DILocation(line: 0, scope: !1856, inlinedAt: !4504)
!4504 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !4502)
!4505 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !4506)
!4506 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !4504)
!4507 = !DILocation(line: 0, scope: !1617, inlinedAt: !4506)
!4508 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !4506)
!4509 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !4506)
!4510 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !4506)
!4511 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !4506)
!4512 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !4506)
!4513 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !4514)
!4514 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !4506)
!4515 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !4514)
!4516 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !4506)
!4517 = !DILocation(line: 0, scope: !1619, inlinedAt: !4506)
!4518 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !4504)
!4519 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !4504)
!4520 = distinct !DIAssignID()
!4521 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !4504)
!4522 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !4504)
!4523 = distinct !DIAssignID()
!4524 = distinct !DIAssignID()
!4525 = distinct !DIAssignID()
!4526 = distinct !DIAssignID()
!4527 = distinct !DIAssignID()
!4528 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !4504)
!4529 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !4504)
!4530 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !4504)
!4531 = distinct !DIAssignID()
!4532 = distinct !DIAssignID()
!4533 = distinct !DIAssignID()
!4534 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !4504)
!4535 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !4504)
!4536 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !4179)
!4537 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !4179)
!4538 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !4179)
!4539 = !DILocation(line: 0, scope: !1906, inlinedAt: !4540)
!4540 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !4179)
!4541 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !4540)
!4542 = distinct !DIAssignID()
!4543 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !4540)
!4544 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !4540)
!4545 = distinct !DIAssignID()
!4546 = distinct !DIAssignID()
!4547 = !DILocation(line: 0, scope: !1736, inlinedAt: !4548)
!4548 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !4540)
!4549 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !4548)
!4550 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !4540)
!4551 = distinct !DIAssignID()
!4552 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !4540)
!4553 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !4540)
!4554 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !4540)
!4555 = distinct !DIAssignID()
!4556 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !4540)
!4557 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !4540)
!4558 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !4540)
!4559 = distinct !DIAssignID()
!4560 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !4540)
!4561 = distinct !DIAssignID()
!4562 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !4540)
!4563 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !4540)
!4564 = distinct !DIAssignID()
!4565 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !4540)
!4566 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !4540)
!4567 = distinct !DIAssignID()
!4568 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !4540)
!4569 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !4540)
!4570 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !4540)
!4571 = !DILocation(line: 0, scope: !1963, inlinedAt: !4572)
!4572 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !4540)
!4573 = !DILocation(line: 0, scope: !1972, inlinedAt: !4574)
!4574 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !4572)
!4575 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !4574)
!4576 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !4574)
!4577 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !4540)
!4578 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !4540)
!4579 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !4540)
!4580 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !4179)
!4581 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !4540)
!4582 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !4179)
!4583 = !DILocation(line: 0, scope: !1761, inlinedAt: !4584)
!4584 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !4179)
!4585 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !4584)
!4586 = distinct !DIAssignID()
!4587 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !4584)
!4588 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !4584)
!4589 = distinct !DIAssignID()
!4590 = distinct !DIAssignID()
!4591 = distinct !DIAssignID()
!4592 = distinct !DIAssignID()
!4593 = distinct !DIAssignID()
!4594 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !4584)
!4595 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !4584)
!4596 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !4584)
!4597 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !4584)
!4598 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !4584)
!4599 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !4584)
!4600 = distinct !DIAssignID()
!4601 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !4584)
!4602 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !4584)
!4603 = distinct !DIAssignID()
!4604 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !4584)
!4605 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !4584)
!4606 = !DILocation(line: 449, column: 3, scope: !2005, inlinedAt: !4179)
!4607 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !4179)
!4608 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !4179)
!4609 = !DILocation(line: 0, scope: !2034, inlinedAt: !4610)
!4610 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !4179)
!4611 = !DILocation(line: 875, column: 36, scope: !2878, inlinedAt: !4136)
!4612 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !4179)
!4613 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !4179)
!4614 = !DILocation(line: 870, column: 6, scope: !2878, inlinedAt: !4136)
!4615 = !DILocation(line: 0, scope: !1498, inlinedAt: !4616)
!4616 = distinct !DILocation(line: 55, column: 2, scope: !3387, inlinedAt: !4617)
!4617 = distinct !DILocation(line: 873, column: 2, scope: !2878, inlinedAt: !4136)
!4618 = !DILocation(line: 0, scope: !1508, inlinedAt: !4619)
!4619 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !4616)
!4620 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !4619)
!4621 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !4619)
!4622 = !DILocation(line: 0, scope: !3399, inlinedAt: !4623)
!4623 = distinct !DILocation(line: 874, column: 2, scope: !2878, inlinedAt: !4136)
!4624 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !4623)
!4625 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !4623)
!4626 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !4623)
!4627 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !4623)
!4628 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !4623)
!4629 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !4623)
!4630 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !4623)
!4631 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !4623)
!4632 = !DILocation(line: 0, scope: !2034, inlinedAt: !4633)
!4633 = distinct !DILocation(line: 875, column: 2, scope: !2878, inlinedAt: !4136)
!4634 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !4633)
!4635 = !DILocation(line: 877, column: 2, scope: !2878, inlinedAt: !4136)
!4636 = !DILocation(line: 1065, column: 11, scope: !2717, inlinedAt: !4062)
!4637 = !DILocation(line: 1065, column: 17, scope: !2717, inlinedAt: !4062)
!4638 = !DILocation(line: 1065, column: 22, scope: !2717, inlinedAt: !4062)
!4639 = !DILocation(line: 1067, column: 7, scope: !2714, inlinedAt: !4062)
!4640 = !DILocation(line: 0, scope: !2714, inlinedAt: !4062)
!4641 = !DILocation(line: 1067, column: 7, scope: !2715, inlinedAt: !4062)
!4642 = !DILocation(line: 1067, column: 7, scope: !2716, inlinedAt: !4062)
!4643 = !DILocation(line: 0, scope: !3432, inlinedAt: !4644)
!4644 = distinct !DILocation(line: 1069, column: 7, scope: !3438, inlinedAt: !4062)
!4645 = !DILocation(line: 0, scope: !3440, inlinedAt: !4646)
!4646 = distinct !DILocation(line: 2370, column: 7, scope: !3444, inlinedAt: !4644)
!4647 = !DILocation(line: 620, column: 14, scope: !3440, inlinedAt: !4646)
!4648 = !DILocation(line: 620, column: 20, scope: !3440, inlinedAt: !4646)
!4649 = !DILocation(line: 620, column: 9, scope: !3440, inlinedAt: !4646)
!4650 = !DILocation(line: 2370, column: 32, scope: !3444, inlinedAt: !4644)
!4651 = !DILocation(line: 0, scope: !3451, inlinedAt: !4652)
!4652 = distinct !DILocation(line: 2370, column: 35, scope: !3444, inlinedAt: !4644)
!4653 = !DILocation(line: 632, column: 20, scope: !3451, inlinedAt: !4652)
!4654 = !DILocation(line: 632, column: 9, scope: !3451, inlinedAt: !4652)
!4655 = !DILocation(line: 2370, column: 62, scope: !3444, inlinedAt: !4644)
!4656 = !DILocation(line: 0, scope: !3440, inlinedAt: !4657)
!4657 = distinct !DILocation(line: 2371, column: 8, scope: !3444, inlinedAt: !4644)
!4658 = !DILocation(line: 0, scope: !3461, inlinedAt: !4659)
!4659 = distinct !DILocation(line: 2371, column: 36, scope: !3444, inlinedAt: !4644)
!4660 = !DILocation(line: 644, column: 14, scope: !3461, inlinedAt: !4659)
!4661 = !DILocation(line: 644, column: 21, scope: !3461, inlinedAt: !4659)
!4662 = !DILocation(line: 644, column: 9, scope: !3461, inlinedAt: !4659)
!4663 = !DILocation(line: 2370, column: 6, scope: !3432, inlinedAt: !4644)
!4664 = !DILocation(line: 0, scope: !2716, inlinedAt: !4062)
!4665 = !DILocation(line: 0, scope: !3471, inlinedAt: !4666)
!4666 = distinct !DILocation(line: 1077, column: 6, scope: !3475, inlinedAt: !4062)
!4667 = !DILocation(line: 0, scope: !3477, inlinedAt: !4668)
!4668 = distinct !DILocation(line: 597, column: 10, scope: !3471, inlinedAt: !4666)
!4669 = !DILocation(line: 477, column: 14, scope: !3477, inlinedAt: !4668)
!4670 = !DILocation(line: 477, column: 20, scope: !3477, inlinedAt: !4668)
!4671 = !DILocation(line: 477, column: 9, scope: !3477, inlinedAt: !4668)
!4672 = !DILocation(line: 597, column: 35, scope: !3471, inlinedAt: !4666)
!4673 = !DILocation(line: 597, column: 44, scope: !3471, inlinedAt: !4666)
!4674 = !DILocation(line: 597, column: 51, scope: !3471, inlinedAt: !4666)
!4675 = !DILocation(line: 1077, column: 6, scope: !2692, inlinedAt: !4062)
!4676 = !DILocation(line: 0, scope: !3489, inlinedAt: !4677)
!4677 = distinct !DILocation(line: 1079, column: 6, scope: !3499, inlinedAt: !4062)
!4678 = !DILocation(line: 0, scope: !3501, inlinedAt: !4679)
!4679 = distinct !DILocation(line: 759, column: 7, scope: !3496, inlinedAt: !4677)
!4680 = !DILocation(line: 465, column: 20, scope: !3501, inlinedAt: !4679)
!4681 = !DILocation(line: 465, column: 9, scope: !3501, inlinedAt: !4679)
!4682 = !DILocation(line: 0, scope: !3477, inlinedAt: !4683)
!4683 = distinct !DILocation(line: 760, column: 7, scope: !3496, inlinedAt: !4677)
!4684 = !DILocation(line: 0, scope: !2912, inlinedAt: !4685)
!4685 = distinct !DILocation(line: 44, column: 9, scope: !3511, inlinedAt: !4686)
!4686 = distinct !DILocation(line: 760, column: 36, scope: !3496, inlinedAt: !4677)
!4687 = !DILocation(line: 759, column: 83, scope: !3496, inlinedAt: !4677)
!4688 = !DILocation(line: 0, scope: !3518, inlinedAt: !4689)
!4689 = distinct !DILocation(line: 763, column: 10, scope: !3495, inlinedAt: !4677)
!4690 = !DILocation(line: 140, column: 2, scope: !3518, inlinedAt: !4689)
!4691 = !DILocation(line: 140, column: 21, scope: !3518, inlinedAt: !4689)
!4692 = distinct !DIAssignID()
!4693 = distinct !DIAssignID()
!4694 = distinct !DIAssignID()
!4695 = !DILocation(line: 142, column: 24, scope: !3518, inlinedAt: !4689)
!4696 = distinct !DIAssignID()
!4697 = !DILocation(line: 143, column: 6, scope: !3518, inlinedAt: !4689)
!4698 = !DILocation(line: 143, column: 13, scope: !3518, inlinedAt: !4689)
!4699 = distinct !DIAssignID()
!4700 = !DILocation(line: 144, column: 6, scope: !3518, inlinedAt: !4689)
!4701 = !DILocation(line: 144, column: 12, scope: !3518, inlinedAt: !4689)
!4702 = distinct !DIAssignID()
!4703 = distinct !DIAssignID()
!4704 = !DILocation(line: 150, column: 6, scope: !3518, inlinedAt: !4689)
!4705 = !DILocation(line: 150, column: 17, scope: !3518, inlinedAt: !4689)
!4706 = distinct !DIAssignID()
!4707 = !DILocation(line: 153, column: 9, scope: !3518, inlinedAt: !4689)
!4708 = !DILocation(line: 154, column: 1, scope: !3518, inlinedAt: !4689)
!4709 = !DILocation(line: 0, scope: !3495, inlinedAt: !4677)
!4710 = !DILocation(line: 764, column: 8, scope: !3552, inlinedAt: !4677)
!4711 = !DILocation(line: 764, column: 13, scope: !3552, inlinedAt: !4677)
!4712 = !DILocation(line: 764, column: 22, scope: !3552, inlinedAt: !4677)
!4713 = !DILocation(line: 764, column: 35, scope: !3552, inlinedAt: !4677)
!4714 = !DILocation(line: 764, column: 7, scope: !3495, inlinedAt: !4677)
!4715 = !DILocation(line: 1082, column: 6, scope: !2719, inlinedAt: !4062)
!4716 = !DILocation(line: 0, scope: !2719, inlinedAt: !4062)
!4717 = !DILocation(line: 1082, column: 6, scope: !2720, inlinedAt: !4062)
!4718 = !DILocation(line: 1082, column: 25, scope: !2720, inlinedAt: !4062)
!4719 = !DILocation(line: 0, scope: !3563, inlinedAt: !4720)
!4720 = distinct !DILocation(line: 1083, column: 6, scope: !2720, inlinedAt: !4062)
!4721 = !DILocation(line: 554, column: 14, scope: !3563, inlinedAt: !4720)
!4722 = !DILocation(line: 554, column: 21, scope: !3563, inlinedAt: !4720)
!4723 = !DILocation(line: 554, column: 9, scope: !3563, inlinedAt: !4720)
!4724 = !DILocation(line: 1083, column: 36, scope: !2720, inlinedAt: !4062)
!4725 = !DILocation(line: 1084, column: 40, scope: !2720, inlinedAt: !4062)
!4726 = !DILocation(line: 0, scope: !3573, inlinedAt: !4727)
!4727 = distinct !DILocation(line: 1084, column: 6, scope: !2720, inlinedAt: !4062)
!4728 = !DILocation(line: 44, column: 2, scope: !3573, inlinedAt: !4727)
!4729 = !DILocation(line: 0, scope: !1498, inlinedAt: !4730)
!4730 = distinct !DILocation(line: 47, column: 2, scope: !3573, inlinedAt: !4727)
!4731 = !DILocation(line: 0, scope: !1508, inlinedAt: !4732)
!4732 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !4730)
!4733 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !4732)
!4734 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !4732)
!4735 = !DILocation(line: 70, column: 21, scope: !1514, inlinedAt: !4732)
!4736 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !4732)
!4737 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !4732)
!4738 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !4732)
!4739 = !DILocation(line: 48, column: 19, scope: !3573, inlinedAt: !4727)
!4740 = distinct !DIAssignID()
!4741 = !DILocation(line: 49, column: 16, scope: !3573, inlinedAt: !4727)
!4742 = distinct !DIAssignID()
!4743 = distinct !DIAssignID()
!4744 = !DILocation(line: 50, column: 6, scope: !3573, inlinedAt: !4727)
!4745 = !DILocation(line: 50, column: 11, scope: !3573, inlinedAt: !4727)
!4746 = distinct !DIAssignID()
!4747 = !DILocation(line: 51, column: 8, scope: !3573, inlinedAt: !4727)
!4748 = !DILocation(line: 52, column: 6, scope: !3607, inlinedAt: !4727)
!4749 = !DILocation(line: 55, column: 1, scope: !3573, inlinedAt: !4727)
!4750 = !DILocation(line: 1082, column: 6, scope: !2692, inlinedAt: !4062)
!4751 = !DILocation(line: 0, scope: !3611, inlinedAt: !4752)
!4752 = distinct !DILocation(line: 1105, column: 6, scope: !3615, inlinedAt: !4062)
!4753 = !DILocation(line: 525, column: 14, scope: !3611, inlinedAt: !4752)
!4754 = !DILocation(line: 525, column: 20, scope: !3611, inlinedAt: !4752)
!4755 = !DILocation(line: 525, column: 9, scope: !3611, inlinedAt: !4752)
!4756 = !DILocation(line: 1105, column: 6, scope: !2692, inlinedAt: !4062)
!4757 = !DILocation(line: 0, scope: !3621, inlinedAt: !4758)
!4758 = distinct !DILocation(line: 1106, column: 16, scope: !3629, inlinedAt: !4062)
!4759 = !DILocation(line: 0, scope: !3631, inlinedAt: !4760)
!4760 = distinct !DILocation(line: 1323, column: 9, scope: !3621, inlinedAt: !4758)
!4761 = !DILocation(line: 0, scope: !3640, inlinedAt: !4760)
!4762 = !DILocation(line: 1246, column: 2, scope: !3631, inlinedAt: !4760)
!4763 = !DILocation(line: 1246, column: 26, scope: !3631, inlinedAt: !4760)
!4764 = distinct !DIAssignID()
!4765 = !DILocation(line: 1246, column: 32, scope: !3631, inlinedAt: !4760)
!4766 = !DILocation(line: 1247, column: 22, scope: !3631, inlinedAt: !4760)
!4767 = distinct !DIAssignID()
!4768 = distinct !DIAssignID()
!4769 = !DILocation(line: 1253, column: 31, scope: !3662, inlinedAt: !4760)
!4770 = distinct !DIAssignID()
!4771 = !DILocation(line: 1257, column: 8, scope: !3631, inlinedAt: !4760)
!4772 = !DILocation(line: 1258, column: 10, scope: !3641, inlinedAt: !4760)
!4773 = !DILocation(line: 1258, column: 6, scope: !3631, inlinedAt: !4760)
!4774 = !DILocation(line: 1281, column: 1, scope: !3631, inlinedAt: !4760)
!4775 = !DILocation(line: 1109, column: 7, scope: !3629, inlinedAt: !4062)
!4776 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !4777)
!4777 = distinct !DILocation(line: 1259, column: 22, scope: !3640, inlinedAt: !4760)
!4778 = !DILocation(line: 0, scope: !1617, inlinedAt: !4777)
!4779 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !4777)
!4780 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !4777)
!4781 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !4777)
!4782 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !4777)
!4783 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !4777)
!4784 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !4785)
!4785 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !4777)
!4786 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !4785)
!4787 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !4777)
!4788 = !DILocation(line: 0, scope: !1619, inlinedAt: !4777)
!4789 = !DILocation(line: 1260, column: 3, scope: !3640, inlinedAt: !4760)
!4790 = !DILocation(line: 1262, column: 23, scope: !3640, inlinedAt: !4760)
!4791 = !DILocation(line: 1260, column: 36, scope: !3640, inlinedAt: !4760)
!4792 = distinct !DIAssignID()
!4793 = !DILocation(line: 1261, column: 23, scope: !3640, inlinedAt: !4760)
!4794 = distinct !DIAssignID()
!4795 = distinct !DIAssignID()
!4796 = !DILocation(line: 1265, column: 7, scope: !3644, inlinedAt: !4760)
!4797 = !DILocation(line: 0, scope: !3644, inlinedAt: !4760)
!4798 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !4799)
!4799 = distinct !DILocation(line: 1265, column: 7, scope: !3644, inlinedAt: !4760)
!4800 = !DILocation(line: 0, scope: !3694, inlinedAt: !4801)
!4801 = distinct !DILocation(line: 1266, column: 23, scope: !3645, inlinedAt: !4760)
!4802 = !DILocation(line: 1239, column: 14, scope: !3694, inlinedAt: !4801)
!4803 = !DILocation(line: 1239, column: 31, scope: !3694, inlinedAt: !4801)
!4804 = !DILocation(line: 0, scope: !1668, inlinedAt: !4805)
!4805 = distinct !DILocation(line: 1266, column: 7, scope: !3645, inlinedAt: !4760)
!4806 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !4805)
!4807 = !DILocation(line: 0, scope: !1673, inlinedAt: !4805)
!4808 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !4805)
!4809 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !4805)
!4810 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !4805)
!4811 = !DILocation(line: 0, scope: !1676, inlinedAt: !4805)
!4812 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !4805)
!4813 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !4805)
!4814 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !4805)
!4815 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !4805)
!4816 = !DILocation(line: 1266, column: 7, scope: !3645, inlinedAt: !4760)
!4817 = !DILocation(line: 1265, column: 33, scope: !3645, inlinedAt: !4760)
!4818 = !DILocation(line: 1266, column: 53, scope: !3645, inlinedAt: !4760)
!4819 = !DILocation(line: 1266, column: 50, scope: !3645, inlinedAt: !4760)
!4820 = !DILocation(line: 1265, column: 7, scope: !3640, inlinedAt: !4760)
!4821 = !DILocation(line: 1271, column: 8, scope: !3720, inlinedAt: !4760)
!4822 = !DILocation(line: 1271, column: 7, scope: !3640, inlinedAt: !4760)
!4823 = !DILocation(line: 1278, column: 2, scope: !3641, inlinedAt: !4760)
!4824 = !DILocation(line: 0, scope: !3647, inlinedAt: !4760)
!4825 = !DILocation(line: 1276, column: 3, scope: !3647, inlinedAt: !4760)
!4826 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !4827)
!4827 = distinct !DILocation(line: 1276, column: 3, scope: !3647, inlinedAt: !4760)
!4828 = !DILocation(line: 1277, column: 15, scope: !3640, inlinedAt: !4760)
!4829 = !DILocation(line: 1109, column: 18, scope: !3729, inlinedAt: !4062)
!4830 = !DILocation(line: 0, scope: !3731, inlinedAt: !4831)
!4831 = distinct !DILocation(line: 1110, column: 14, scope: !3737, inlinedAt: !4062)
!4832 = distinct !DIAssignID()
!4833 = !DILocation(line: 1064, column: 9, scope: !3731, inlinedAt: !4831)
!4834 = !DILocation(line: 1064, column: 2, scope: !3731, inlinedAt: !4831)
!4835 = !DILocation(line: 1111, column: 9, scope: !3742, inlinedAt: !4062)
!4836 = !DILocation(line: 1113, column: 4, scope: !3737, inlinedAt: !4062)
!4837 = !DILocation(line: 0, scope: !3737, inlinedAt: !4062)
!4838 = !DILocation(line: 0, scope: !1724, inlinedAt: !4839)
!4839 = distinct !DILocation(line: 1120, column: 23, scope: !3748, inlinedAt: !4062)
!4840 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !4839)
!4841 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !4839)
!4842 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !4839)
!4843 = !DILocation(line: 0, scope: !1736, inlinedAt: !4844)
!4844 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !4839)
!4845 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !4844)
!4846 = !DILocation(line: 1120, column: 52, scope: !3748, inlinedAt: !4062)
!4847 = !DILocation(line: 1120, column: 47, scope: !3748, inlinedAt: !4062)
!4848 = !DILocation(line: 1120, column: 45, scope: !3748, inlinedAt: !4062)
!4849 = !DILocation(line: 1120, column: 22, scope: !3748, inlinedAt: !4062)
!4850 = !DILocation(line: 1120, column: 20, scope: !3748, inlinedAt: !4062)
!4851 = distinct !DIAssignID()
!4852 = !DILocation(line: 0, scope: !3763, inlinedAt: !4853)
!4853 = distinct !DILocation(line: 1121, column: 18, scope: !3748, inlinedAt: !4062)
!4854 = !DILocation(line: 0, scope: !2846, inlinedAt: !4855)
!4855 = distinct !DILocation(line: 1082, column: 9, scope: !3763, inlinedAt: !4853)
!4856 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !4855)
!4857 = !DILocation(line: 1122, column: 8, scope: !3771, inlinedAt: !4062)
!4858 = !DILocation(line: 1122, column: 7, scope: !3748, inlinedAt: !4062)
!4859 = !DILocation(line: 0, scope: !1761, inlinedAt: !4860)
!4860 = distinct !DILocation(line: 1123, column: 4, scope: !3775, inlinedAt: !4062)
!4861 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !4860)
!4862 = distinct !DIAssignID()
!4863 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !4860)
!4864 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !4860)
!4865 = distinct !DIAssignID()
!4866 = distinct !DIAssignID()
!4867 = distinct !DIAssignID()
!4868 = distinct !DIAssignID()
!4869 = distinct !DIAssignID()
!4870 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !4860)
!4871 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !4860)
!4872 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !4860)
!4873 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !4860)
!4874 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !4860)
!4875 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !4860)
!4876 = distinct !DIAssignID()
!4877 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !4860)
!4878 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !4860)
!4879 = distinct !DIAssignID()
!4880 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !4860)
!4881 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !4860)
!4882 = !DILocation(line: 1124, column: 4, scope: !3775, inlinedAt: !4062)
!4883 = !DILocation(line: 1127, column: 30, scope: !3748, inlinedAt: !4062)
!4884 = !DILocation(line: 0, scope: !3731, inlinedAt: !4885)
!4885 = distinct !DILocation(line: 1128, column: 13, scope: !3748, inlinedAt: !4062)
!4886 = distinct !DIAssignID()
!4887 = !DILocation(line: 1064, column: 9, scope: !3731, inlinedAt: !4885)
!4888 = !DILocation(line: 1064, column: 2, scope: !3731, inlinedAt: !4885)
!4889 = !DILocation(line: 1131, column: 7, scope: !3805, inlinedAt: !4062)
!4890 = !DILocation(line: 1131, column: 6, scope: !2692, inlinedAt: !4062)
!4891 = !DILocation(line: 0, scope: !1761, inlinedAt: !4892)
!4892 = distinct !DILocation(line: 1132, column: 3, scope: !3809, inlinedAt: !4062)
!4893 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !4892)
!4894 = distinct !DIAssignID()
!4895 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !4892)
!4896 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !4892)
!4897 = distinct !DIAssignID()
!4898 = distinct !DIAssignID()
!4899 = distinct !DIAssignID()
!4900 = distinct !DIAssignID()
!4901 = distinct !DIAssignID()
!4902 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !4892)
!4903 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !4892)
!4904 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !4892)
!4905 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !4892)
!4906 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !4892)
!4907 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !4892)
!4908 = distinct !DIAssignID()
!4909 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !4892)
!4910 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !4892)
!4911 = distinct !DIAssignID()
!4912 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !4892)
!4913 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !4892)
!4914 = !DILocation(line: 1133, column: 3, scope: !3809, inlinedAt: !4062)
!4915 = !DILocation(line: 1135, column: 2, scope: !2692, inlinedAt: !4062)
!4916 = !DILocation(line: 0, scope: !3611, inlinedAt: !4917)
!4917 = distinct !DILocation(line: 1137, column: 6, scope: !3836, inlinedAt: !4062)
!4918 = !DILocation(line: 525, column: 14, scope: !3611, inlinedAt: !4917)
!4919 = !DILocation(line: 525, column: 20, scope: !3611, inlinedAt: !4917)
!4920 = !DILocation(line: 525, column: 9, scope: !3611, inlinedAt: !4917)
!4921 = !DILocation(line: 1137, column: 31, scope: !3836, inlinedAt: !4062)
!4922 = !DILocation(line: 0, scope: !3842, inlinedAt: !4923)
!4923 = distinct !DILocation(line: 1138, column: 3, scope: !3836, inlinedAt: !4062)
!4924 = !DILocation(line: 0, scope: !3851, inlinedAt: !4925)
!4925 = distinct !DILocation(line: 1331, column: 2, scope: !3842, inlinedAt: !4923)
!4926 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !4927)
!4927 = distinct !DILocation(line: 1294, column: 21, scope: !3851, inlinedAt: !4925)
!4928 = !DILocation(line: 0, scope: !1617, inlinedAt: !4927)
!4929 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !4927)
!4930 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !4927)
!4931 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !4927)
!4932 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !4927)
!4933 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !4927)
!4934 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !4935)
!4935 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !4927)
!4936 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !4935)
!4937 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !4927)
!4938 = !DILocation(line: 0, scope: !1619, inlinedAt: !4927)
!4939 = !DILocation(line: 1295, column: 2, scope: !3851, inlinedAt: !4925)
!4940 = !DILocation(line: 1295, column: 26, scope: !3851, inlinedAt: !4925)
!4941 = distinct !DIAssignID()
!4942 = distinct !DIAssignID()
!4943 = !DILocation(line: 1295, column: 32, scope: !3851, inlinedAt: !4925)
!4944 = !DILocation(line: 1296, column: 22, scope: !3851, inlinedAt: !4925)
!4945 = distinct !DIAssignID()
!4946 = distinct !DIAssignID()
!4947 = !DILocation(line: 1299, column: 2, scope: !3851, inlinedAt: !4925)
!4948 = !DILocation(line: 1301, column: 16, scope: !3851, inlinedAt: !4925)
!4949 = !DILocation(line: 1299, column: 31, scope: !3851, inlinedAt: !4925)
!4950 = distinct !DIAssignID()
!4951 = distinct !DIAssignID()
!4952 = distinct !DIAssignID()
!4953 = !DILocation(line: 1305, column: 31, scope: !3891, inlinedAt: !4925)
!4954 = distinct !DIAssignID()
!4955 = !DILocation(line: 1309, column: 2, scope: !3851, inlinedAt: !4925)
!4956 = !DILocation(line: 1310, column: 1, scope: !3851, inlinedAt: !4925)
!4957 = !DILocation(line: 1138, column: 3, scope: !3836, inlinedAt: !4062)
!4958 = !DILocation(line: 1141, column: 5, scope: !2692, inlinedAt: !4062)
!4959 = !DILocation(line: 1147, column: 10, scope: !3898, inlinedAt: !4062)
!4960 = !DILocation(line: 0, scope: !3900, inlinedAt: !4961)
!4961 = distinct !DILocation(line: 1146, column: 6, scope: !3898, inlinedAt: !4062)
!4962 = !DILocation(line: 667, column: 2, scope: !3900, inlinedAt: !4961)
!4963 = distinct !DIAssignID()
!4964 = !DILocation(line: 668, column: 2, scope: !3900, inlinedAt: !4961)
!4965 = !DILocation(line: 668, column: 27, scope: !3900, inlinedAt: !4961)
!4966 = distinct !DIAssignID()
!4967 = distinct !DIAssignID()
!4968 = !DILocation(line: 0, scope: !1736, inlinedAt: !4969)
!4969 = distinct !DILocation(line: 671, column: 15, scope: !3900, inlinedAt: !4961)
!4970 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !4969)
!4971 = !DILocation(line: 671, column: 13, scope: !3900, inlinedAt: !4961)
!4972 = distinct !DIAssignID()
!4973 = !DILocation(line: 672, column: 6, scope: !3900, inlinedAt: !4961)
!4974 = !DILocation(line: 672, column: 25, scope: !3900, inlinedAt: !4961)
!4975 = distinct !DIAssignID()
!4976 = !DILocation(line: 673, column: 22, scope: !3900, inlinedAt: !4961)
!4977 = !DILocation(line: 673, column: 6, scope: !3900, inlinedAt: !4961)
!4978 = !DILocation(line: 673, column: 11, scope: !3900, inlinedAt: !4961)
!4979 = distinct !DIAssignID()
!4980 = !DILocation(line: 675, column: 16, scope: !3900, inlinedAt: !4961)
!4981 = distinct !DIAssignID()
!4982 = distinct !DIAssignID()
!4983 = !DILocation(line: 676, column: 6, scope: !3900, inlinedAt: !4961)
!4984 = !DILocation(line: 676, column: 11, scope: !3900, inlinedAt: !4961)
!4985 = distinct !DIAssignID()
!4986 = !DILocation(line: 677, column: 6, scope: !3900, inlinedAt: !4961)
!4987 = !DILocation(line: 677, column: 20, scope: !3900, inlinedAt: !4961)
!4988 = distinct !DIAssignID()
!4989 = !DILocation(line: 679, column: 8, scope: !3900, inlinedAt: !4961)
!4990 = !DILocation(line: 680, column: 7, scope: !3951, inlinedAt: !4961)
!4991 = !DILocation(line: 680, column: 11, scope: !3951, inlinedAt: !4961)
!4992 = !DILocation(line: 0, scope: !1963, inlinedAt: !4993)
!4993 = distinct !DILocation(line: 680, column: 14, scope: !3951, inlinedAt: !4961)
!4994 = !DILocation(line: 0, scope: !1972, inlinedAt: !4995)
!4995 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !4993)
!4996 = !DILocation(line: 364, column: 12, scope: !1978, inlinedAt: !4995)
!4997 = !DILocation(line: 329, column: 12, scope: !1978, inlinedAt: !4995)
!4998 = !DILocation(line: 329, column: 21, scope: !1978, inlinedAt: !4995)
!4999 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !4995)
!5000 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !4995)
!5001 = !DILocation(line: 680, column: 14, scope: !3951, inlinedAt: !4961)
!5002 = !DILocation(line: 680, column: 6, scope: !3900, inlinedAt: !4961)
!5003 = !DILocation(line: 684, column: 1, scope: !3900, inlinedAt: !4961)
!5004 = !DILocation(line: 1146, column: 6, scope: !2692, inlinedAt: !4062)
!5005 = !DILocation(line: 681, column: 9, scope: !3951, inlinedAt: !4961)
!5006 = !DILocation(line: 1147, column: 25, scope: !3898, inlinedAt: !4062)
!5007 = !DILocation(line: 0, scope: !1761, inlinedAt: !5008)
!5008 = distinct !DILocation(line: 1148, column: 3, scope: !3970, inlinedAt: !4062)
!5009 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5008)
!5010 = distinct !DIAssignID()
!5011 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5008)
!5012 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5008)
!5013 = distinct !DIAssignID()
!5014 = distinct !DIAssignID()
!5015 = distinct !DIAssignID()
!5016 = distinct !DIAssignID()
!5017 = distinct !DIAssignID()
!5018 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5008)
!5019 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5008)
!5020 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5008)
!5021 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5008)
!5022 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5008)
!5023 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5008)
!5024 = distinct !DIAssignID()
!5025 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5008)
!5026 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5008)
!5027 = distinct !DIAssignID()
!5028 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5008)
!5029 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5008)
!5030 = !DILocation(line: 1159, column: 1, scope: !2692, inlinedAt: !4062)
!5031 = !DILocation(line: 1263, column: 27, scope: !5032)
!5032 = distinct !DILexicalBlock(scope: !4019, file: !104, line: 1263, column: 6)
!5033 = !DILocation(line: 0, scope: !3399, inlinedAt: !5034)
!5034 = distinct !DILocation(line: 1152, column: 2, scope: !2692, inlinedAt: !4062)
!5035 = !DILocation(line: 744, column: 27, scope: !3399, inlinedAt: !5034)
!5036 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !5034)
!5037 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !5034)
!5038 = !DILocation(line: 746, column: 27, scope: !3399, inlinedAt: !5034)
!5039 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !5034)
!5040 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !5034)
!5041 = !DILocation(line: 748, column: 27, scope: !3399, inlinedAt: !5034)
!5042 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !5034)
!5043 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !5034)
!5044 = !DILocation(line: 750, column: 27, scope: !3399, inlinedAt: !5034)
!5045 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !5034)
!5046 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !5034)
!5047 = !DILocation(line: 1153, column: 29, scope: !2692, inlinedAt: !4062)
!5048 = !DILocation(line: 0, scope: !2034, inlinedAt: !5049)
!5049 = distinct !DILocation(line: 1153, column: 2, scope: !2692, inlinedAt: !4062)
!5050 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !5049)
!5051 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !5049)
!5052 = !DILocation(line: 1155, column: 2, scope: !2692, inlinedAt: !4062)
!5053 = !DILocation(line: 1263, column: 10, scope: !5032)
!5054 = !DILocation(line: 1265, column: 3, scope: !5055)
!5055 = distinct !DILexicalBlock(scope: !5032, file: !104, line: 1263, column: 46)
!5056 = !DILocation(line: 1269, column: 1, scope: !4019)
!5057 = distinct !DISubprogram(name: "cil_sock6_recvmsg", scope: !104, file: !104, line: 1272, type: !1134, scopeLine: 1273, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5058)
!5058 = !{!5059}
!5059 = !DILocalVariable(name: "ctx", arg: 1, scope: !5057, file: !104, line: 1272, type: !1136)
!5060 = distinct !DIAssignID()
!5061 = distinct !DIAssignID()
!5062 = distinct !DIAssignID()
!5063 = distinct !DIAssignID()
!5064 = distinct !DIAssignID()
!5065 = distinct !DIAssignID()
!5066 = distinct !DIAssignID()
!5067 = distinct !DIAssignID()
!5068 = distinct !DIAssignID()
!5069 = distinct !DIAssignID()
!5070 = distinct !DIAssignID()
!5071 = !DILocation(line: 0, scope: !5057)
!5072 = !DILocalVariable(name: "key", scope: !5073, file: !104, line: 1213, type: !982)
!5073 = distinct !DISubprogram(name: "__sock6_xlate_rev", scope: !104, file: !104, line: 1210, type: !1134, scopeLine: 1211, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5074)
!5074 = !{!5075, !5072, !5076, !5077, !5078, !5079, !5082}
!5075 = !DILocalVariable(name: "ctx", arg: 1, scope: !5073, file: !104, line: 1210, type: !1136)
!5076 = !DILocalVariable(name: "val", scope: !5073, file: !104, line: 1214, type: !989)
!5077 = !DILocalVariable(name: "dst_port", scope: !5073, file: !104, line: 1215, type: !85)
!5078 = !DILocalVariable(name: "protocol", scope: !5073, file: !104, line: 1216, type: !84)
!5079 = !DILocalVariable(name: "svc", scope: !5080, file: !104, line: 1227, type: !2705)
!5080 = distinct !DILexicalBlock(scope: !5081, file: !104, line: 1226, column: 11)
!5081 = distinct !DILexicalBlock(scope: !5073, file: !104, line: 1226, column: 6)
!5082 = !DILocalVariable(name: "svc_key", scope: !5080, file: !104, line: 1228, type: !579)
!5083 = !DILocation(line: 0, scope: !5073, inlinedAt: !5084)
!5084 = distinct !DILocation(line: 1274, column: 2, scope: !5057)
!5085 = !DILocation(line: 0, scope: !5080, inlinedAt: !5084)
!5086 = !DILocation(line: 1213, column: 2, scope: !5073, inlinedAt: !5084)
!5087 = !DILocation(line: 1213, column: 27, scope: !5073, inlinedAt: !5084)
!5088 = distinct !DIAssignID()
!5089 = distinct !DIAssignID()
!5090 = !DILocation(line: 0, scope: !1240, inlinedAt: !5091)
!5091 = distinct !DILocation(line: 1215, column: 19, scope: !5073, inlinedAt: !5084)
!5092 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !5091)
!5093 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !5091)
!5094 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !5091)
!5095 = distinct !DIAssignID()
!5096 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !5091)
!5097 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !5091)
!5098 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !5091)
!5099 = !DILocation(line: 1216, column: 18, scope: !5073, inlinedAt: !5084)
!5100 = !DILocation(line: 0, scope: !1736, inlinedAt: !5101)
!5101 = distinct !DILocation(line: 1218, column: 15, scope: !5073, inlinedAt: !5084)
!5102 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !5101)
!5103 = !DILocation(line: 1218, column: 13, scope: !5073, inlinedAt: !5084)
!5104 = distinct !DIAssignID()
!5105 = !DILocation(line: 1219, column: 6, scope: !5073, inlinedAt: !5084)
!5106 = !DILocation(line: 1219, column: 11, scope: !5073, inlinedAt: !5084)
!5107 = distinct !DIAssignID()
!5108 = !DILocation(line: 1220, column: 31, scope: !5073, inlinedAt: !5084)
!5109 = !DILocation(line: 0, scope: !2752, inlinedAt: !5110)
!5110 = distinct !DILocation(line: 1220, column: 2, scope: !5073, inlinedAt: !5084)
!5111 = !DILocation(line: 716, column: 18, scope: !2752, inlinedAt: !5110)
!5112 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !5110)
!5113 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !5110)
!5114 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !5110)
!5115 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !5110)
!5116 = !DILocation(line: 718, column: 8, scope: !2752, inlinedAt: !5110)
!5117 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !5110)
!5118 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !5110)
!5119 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !5110)
!5120 = !DILocation(line: 720, column: 8, scope: !2752, inlinedAt: !5110)
!5121 = !DILocation(line: 720, column: 11, scope: !2752, inlinedAt: !5110)
!5122 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !5110)
!5123 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !5110)
!5124 = !DILocation(line: 722, column: 8, scope: !2752, inlinedAt: !5110)
!5125 = !DILocation(line: 722, column: 11, scope: !2752, inlinedAt: !5110)
!5126 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !5110)
!5127 = !DILocation(line: 1225, column: 8, scope: !5073, inlinedAt: !5084)
!5128 = !DILocation(line: 1226, column: 6, scope: !5081, inlinedAt: !5084)
!5129 = !DILocation(line: 1226, column: 6, scope: !5073, inlinedAt: !5084)
!5130 = !DILocation(line: 1228, column: 3, scope: !5080, inlinedAt: !5084)
!5131 = !DILocation(line: 1229, column: 20, scope: !5080, inlinedAt: !5084)
!5132 = distinct !DIAssignID()
!5133 = !DILocation(line: 1228, column: 28, scope: !5080, inlinedAt: !5084)
!5134 = !DILocation(line: 1230, column: 19, scope: !5080, inlinedAt: !5084)
!5135 = distinct !DIAssignID()
!5136 = distinct !DIAssignID()
!5137 = distinct !DIAssignID()
!5138 = distinct !DIAssignID()
!5139 = distinct !DIAssignID()
!5140 = distinct !DIAssignID()
!5141 = !DILocation(line: 0, scope: !2827, inlinedAt: !5142)
!5142 = distinct !DILocation(line: 1234, column: 9, scope: !5080, inlinedAt: !5084)
!5143 = distinct !DIAssignID()
!5144 = !DILocation(line: 981, column: 20, scope: !2827, inlinedAt: !5142)
!5145 = !DILocation(line: 983, column: 13, scope: !2827, inlinedAt: !5142)
!5146 = !DILocation(line: 0, scope: !2846, inlinedAt: !5147)
!5147 = distinct !DILocation(line: 984, column: 8, scope: !2827, inlinedAt: !5142)
!5148 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !5147)
!5149 = !DILocation(line: 985, column: 7, scope: !2854, inlinedAt: !5142)
!5150 = !DILocation(line: 985, column: 6, scope: !2827, inlinedAt: !5142)
!5151 = !DILocation(line: 0, scope: !2857, inlinedAt: !5152)
!5152 = distinct !DILocation(line: 1005, column: 21, scope: !2863, inlinedAt: !5142)
!5153 = !DILocation(line: 513, column: 14, scope: !2857, inlinedAt: !5152)
!5154 = !DILocation(line: 513, column: 21, scope: !2857, inlinedAt: !5152)
!5155 = !DILocation(line: 513, column: 9, scope: !2857, inlinedAt: !5152)
!5156 = !DILocation(line: 1005, column: 6, scope: !2827, inlinedAt: !5142)
!5157 = !DILocation(line: 1008, column: 13, scope: !2827, inlinedAt: !5142)
!5158 = !DILocation(line: 0, scope: !2846, inlinedAt: !5159)
!5159 = distinct !DILocation(line: 1009, column: 9, scope: !2827, inlinedAt: !5142)
!5160 = !DILocation(line: 947, column: 9, scope: !2846, inlinedAt: !5159)
!5161 = !DILocation(line: 1235, column: 8, scope: !5162, inlinedAt: !5084)
!5162 = distinct !DILexicalBlock(scope: !5080, file: !104, line: 1235, column: 7)
!5163 = !DILocation(line: 1235, column: 7, scope: !5080, inlinedAt: !5084)
!5164 = !DILocation(line: 0, scope: !1228, inlinedAt: !5165)
!5165 = distinct !DILocation(line: 1237, column: 7, scope: !5166, inlinedAt: !5084)
!5166 = distinct !DILexicalBlock(scope: !5162, file: !104, line: 1235, column: 13)
!5167 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !5165)
!5168 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !5165)
!5169 = !DILocation(line: 90, column: 41, scope: !1228, inlinedAt: !5165)
!5170 = !DILocation(line: 1239, column: 20, scope: !5171, inlinedAt: !5084)
!5171 = distinct !DILexicalBlock(scope: !5080, file: !104, line: 1239, column: 7)
!5172 = !DILocation(line: 1239, column: 42, scope: !5171, inlinedAt: !5084)
!5173 = !DILocation(line: 1239, column: 34, scope: !5171, inlinedAt: !5084)
!5174 = !DILocation(line: 1239, column: 56, scope: !5171, inlinedAt: !5084)
!5175 = !DILocation(line: 1240, column: 13, scope: !5171, inlinedAt: !5084)
!5176 = !DILocation(line: 1240, column: 19, scope: !5171, inlinedAt: !5084)
!5177 = !DILocation(line: 1240, column: 24, scope: !5171, inlinedAt: !5084)
!5178 = !DILocation(line: 1241, column: 4, scope: !5179, inlinedAt: !5084)
!5179 = distinct !DILexicalBlock(scope: !5171, file: !104, line: 1240, column: 62)
!5180 = !DILocation(line: 0, scope: !1761, inlinedAt: !5181)
!5181 = distinct !DILocation(line: 1242, column: 4, scope: !5179, inlinedAt: !5084)
!5182 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5181)
!5183 = distinct !DIAssignID()
!5184 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5181)
!5185 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5181)
!5186 = distinct !DIAssignID()
!5187 = distinct !DIAssignID()
!5188 = distinct !DIAssignID()
!5189 = distinct !DIAssignID()
!5190 = distinct !DIAssignID()
!5191 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5181)
!5192 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5181)
!5193 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5181)
!5194 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5181)
!5195 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5181)
!5196 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5181)
!5197 = distinct !DIAssignID()
!5198 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5181)
!5199 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5181)
!5200 = distinct !DIAssignID()
!5201 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5181)
!5202 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5181)
!5203 = !DILocation(line: 1243, column: 4, scope: !5179, inlinedAt: !5084)
!5204 = !DILocation(line: 0, scope: !3399, inlinedAt: !5205)
!5205 = distinct !DILocation(line: 1246, column: 3, scope: !5080, inlinedAt: !5084)
!5206 = !DILocation(line: 744, column: 27, scope: !3399, inlinedAt: !5205)
!5207 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !5205)
!5208 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !5205)
!5209 = !DILocation(line: 746, column: 27, scope: !3399, inlinedAt: !5205)
!5210 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !5205)
!5211 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !5205)
!5212 = !DILocation(line: 748, column: 27, scope: !3399, inlinedAt: !5205)
!5213 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !5205)
!5214 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !5205)
!5215 = !DILocation(line: 750, column: 27, scope: !3399, inlinedAt: !5205)
!5216 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !5205)
!5217 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !5205)
!5218 = !DILocation(line: 1247, column: 26, scope: !5080, inlinedAt: !5084)
!5219 = !DILocation(line: 0, scope: !2034, inlinedAt: !5220)
!5220 = distinct !DILocation(line: 1247, column: 3, scope: !5080, inlinedAt: !5084)
!5221 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !5220)
!5222 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !5220)
!5223 = !DILocation(line: 1250, column: 3, scope: !5080, inlinedAt: !5084)
!5224 = !DILocation(line: 1251, column: 2, scope: !5081, inlinedAt: !5084)
!5225 = !DILocalVariable(name: "ctx", arg: 1, scope: !5226, file: !104, line: 1181, type: !1136)
!5226 = distinct !DISubprogram(name: "sock6_xlate_rev_v4_in_v6", scope: !104, file: !104, line: 1181, type: !1134, scopeLine: 1182, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5227)
!5227 = !{!5225, !5228, !5229, !5230}
!5228 = !DILocalVariable(name: "fake_ctx", scope: !5226, file: !104, line: 1184, type: !1137)
!5229 = !DILocalVariable(name: "addr6", scope: !5226, file: !104, line: 1185, type: !160)
!5230 = !DILocalVariable(name: "ret", scope: !5226, file: !104, line: 1186, type: !305)
!5231 = !DILocation(line: 0, scope: !5226, inlinedAt: !5232)
!5232 = distinct !DILocation(line: 1254, column: 9, scope: !5073, inlinedAt: !5084)
!5233 = !DILocation(line: 0, scope: !2752, inlinedAt: !5234)
!5234 = distinct !DILocation(line: 1188, column: 2, scope: !5226, inlinedAt: !5232)
!5235 = !DILocation(line: 716, column: 13, scope: !2752, inlinedAt: !5234)
!5236 = !DILocation(line: 716, column: 11, scope: !2752, inlinedAt: !5234)
!5237 = !DILocation(line: 717, column: 2, scope: !2752, inlinedAt: !5234)
!5238 = !DILocation(line: 718, column: 13, scope: !2752, inlinedAt: !5234)
!5239 = !DILocation(line: 718, column: 11, scope: !2752, inlinedAt: !5234)
!5240 = !DILocation(line: 719, column: 2, scope: !2752, inlinedAt: !5234)
!5241 = !DILocation(line: 720, column: 13, scope: !2752, inlinedAt: !5234)
!5242 = !DILocation(line: 721, column: 2, scope: !2752, inlinedAt: !5234)
!5243 = !DILocation(line: 722, column: 13, scope: !2752, inlinedAt: !5234)
!5244 = !DILocation(line: 723, column: 2, scope: !2752, inlinedAt: !5234)
!5245 = !DILocation(line: 0, scope: !2901, inlinedAt: !5246)
!5246 = distinct !DILocation(line: 1189, column: 7, scope: !5247, inlinedAt: !5232)
!5247 = distinct !DILexicalBlock(scope: !5226, file: !104, line: 1189, column: 6)
!5248 = !DILocation(line: 0, scope: !2912, inlinedAt: !5249)
!5249 = distinct !DILocation(line: 28, column: 9, scope: !2901, inlinedAt: !5246)
!5250 = !DILocation(line: 42, column: 12, scope: !2920, inlinedAt: !5249)
!5251 = !DILocation(line: 42, column: 6, scope: !2912, inlinedAt: !5249)
!5252 = !DILocation(line: 1193, column: 23, scope: !5226, inlinedAt: !5232)
!5253 = !DILocation(line: 0, scope: !1240, inlinedAt: !5254)
!5254 = distinct !DILocation(line: 1195, column: 23, scope: !5226, inlinedAt: !5232)
!5255 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !5254)
!5256 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !5254)
!5257 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !5254)
!5258 = distinct !DIAssignID()
!5259 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !5254)
!5260 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !5254)
!5261 = !DILocation(line: 1195, column: 23, scope: !5226, inlinedAt: !5232)
!5262 = !DILocation(line: 0, scope: !2523, inlinedAt: !5263)
!5263 = distinct !DILocation(line: 1197, column: 8, scope: !5226, inlinedAt: !5232)
!5264 = !DILocation(line: 0, scope: !2534, inlinedAt: !5263)
!5265 = !DILocation(line: 0, scope: !1240, inlinedAt: !5266)
!5266 = distinct !DILocation(line: 584, column: 19, scope: !2523, inlinedAt: !5263)
!5267 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !5266)
!5268 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !5266)
!5269 = distinct !DIAssignID()
!5270 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !5266)
!5271 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !5266)
!5272 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !5266)
!5273 = !DILocation(line: 587, column: 2, scope: !2523, inlinedAt: !5263)
!5274 = !DILocation(line: 0, scope: !1736, inlinedAt: !5275)
!5275 = distinct !DILocation(line: 588, column: 14, scope: !2523, inlinedAt: !5263)
!5276 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !5275)
!5277 = !DILocation(line: 587, column: 33, scope: !2523, inlinedAt: !5263)
!5278 = distinct !DIAssignID()
!5279 = distinct !DIAssignID()
!5280 = distinct !DIAssignID()
!5281 = distinct !DIAssignID()
!5282 = !DILocation(line: 595, column: 8, scope: !2523, inlinedAt: !5263)
!5283 = !DILocation(line: 596, column: 6, scope: !2535, inlinedAt: !5263)
!5284 = !DILocation(line: 596, column: 6, scope: !2523, inlinedAt: !5263)
!5285 = !DILocation(line: 624, column: 1, scope: !2523, inlinedAt: !5263)
!5286 = !DILocation(line: 1198, column: 6, scope: !5226, inlinedAt: !5232)
!5287 = !DILocation(line: 585, column: 18, scope: !2523, inlinedAt: !5263)
!5288 = !DILocation(line: 598, column: 3, scope: !2534, inlinedAt: !5263)
!5289 = !DILocation(line: 599, column: 20, scope: !2534, inlinedAt: !5263)
!5290 = !DILocation(line: 598, column: 28, scope: !2534, inlinedAt: !5263)
!5291 = distinct !DIAssignID()
!5292 = !DILocation(line: 600, column: 19, scope: !2534, inlinedAt: !5263)
!5293 = distinct !DIAssignID()
!5294 = distinct !DIAssignID()
!5295 = distinct !DIAssignID()
!5296 = distinct !DIAssignID()
!5297 = distinct !DIAssignID()
!5298 = distinct !DIAssignID()
!5299 = !DILocation(line: 0, scope: !1285, inlinedAt: !5300)
!5300 = distinct !DILocation(line: 604, column: 9, scope: !2534, inlinedAt: !5263)
!5301 = distinct !DIAssignID()
!5302 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !5300)
!5303 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !5300)
!5304 = !DILocation(line: 0, scope: !1302, inlinedAt: !5305)
!5305 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !5300)
!5306 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !5305)
!5307 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !5300)
!5308 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !5300)
!5309 = !DILocation(line: 0, scope: !1313, inlinedAt: !5310)
!5310 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !5300)
!5311 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !5310)
!5312 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !5310)
!5313 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !5310)
!5314 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !5300)
!5315 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !5300)
!5316 = !DILocation(line: 0, scope: !1302, inlinedAt: !5317)
!5317 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !5300)
!5318 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !5317)
!5319 = !DILocation(line: 605, column: 8, scope: !2596, inlinedAt: !5263)
!5320 = !DILocation(line: 605, column: 7, scope: !2534, inlinedAt: !5263)
!5321 = !DILocation(line: 0, scope: !1228, inlinedAt: !5322)
!5322 = distinct !DILocation(line: 607, column: 7, scope: !2600, inlinedAt: !5263)
!5323 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !5322)
!5324 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !5322)
!5325 = !DILocation(line: 90, column: 41, scope: !1228, inlinedAt: !5322)
!5326 = !DILocation(line: 609, column: 20, scope: !2605, inlinedAt: !5263)
!5327 = !DILocation(line: 609, column: 42, scope: !2605, inlinedAt: !5263)
!5328 = !DILocation(line: 609, column: 34, scope: !2605, inlinedAt: !5263)
!5329 = !DILocation(line: 609, column: 56, scope: !2605, inlinedAt: !5263)
!5330 = !DILocation(line: 610, column: 13, scope: !2605, inlinedAt: !5263)
!5331 = !DILocation(line: 610, column: 19, scope: !2605, inlinedAt: !5263)
!5332 = !DILocation(line: 610, column: 24, scope: !2605, inlinedAt: !5263)
!5333 = !DILocation(line: 611, column: 4, scope: !2613, inlinedAt: !5263)
!5334 = !DILocation(line: 0, scope: !1761, inlinedAt: !5335)
!5335 = distinct !DILocation(line: 612, column: 4, scope: !2613, inlinedAt: !5263)
!5336 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5335)
!5337 = distinct !DIAssignID()
!5338 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5335)
!5339 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5335)
!5340 = distinct !DIAssignID()
!5341 = distinct !DIAssignID()
!5342 = distinct !DIAssignID()
!5343 = distinct !DIAssignID()
!5344 = distinct !DIAssignID()
!5345 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5335)
!5346 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5335)
!5347 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5335)
!5348 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5335)
!5349 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5335)
!5350 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5335)
!5351 = distinct !DIAssignID()
!5352 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5335)
!5353 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5335)
!5354 = distinct !DIAssignID()
!5355 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5335)
!5356 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5335)
!5357 = !DILocation(line: 621, column: 2, scope: !2535, inlinedAt: !5263)
!5358 = !DILocation(line: 616, column: 24, scope: !2534, inlinedAt: !5263)
!5359 = !DILocation(line: 617, column: 26, scope: !2534, inlinedAt: !5263)
!5360 = !DILocation(line: 0, scope: !2034, inlinedAt: !5361)
!5361 = distinct !DILocation(line: 617, column: 3, scope: !2534, inlinedAt: !5263)
!5362 = !DILocation(line: 0, scope: !3399, inlinedAt: !5363)
!5363 = distinct !DILocation(line: 1202, column: 2, scope: !5226, inlinedAt: !5232)
!5364 = !DILocation(line: 744, column: 19, scope: !3399, inlinedAt: !5363)
!5365 = !DILocation(line: 745, column: 2, scope: !3399, inlinedAt: !5363)
!5366 = !DILocation(line: 746, column: 19, scope: !3399, inlinedAt: !5363)
!5367 = !DILocation(line: 747, column: 2, scope: !3399, inlinedAt: !5363)
!5368 = !DILocation(line: 748, column: 19, scope: !3399, inlinedAt: !5363)
!5369 = !DILocation(line: 749, column: 2, scope: !3399, inlinedAt: !5363)
!5370 = !DILocation(line: 750, column: 19, scope: !3399, inlinedAt: !5363)
!5371 = !DILocation(line: 751, column: 2, scope: !3399, inlinedAt: !5363)
!5372 = !DILocation(line: 0, scope: !2034, inlinedAt: !5373)
!5373 = distinct !DILocation(line: 1203, column: 2, scope: !5226, inlinedAt: !5232)
!5374 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !5373)
!5375 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !5373)
!5376 = !DILocation(line: 1205, column: 2, scope: !5226, inlinedAt: !5232)
!5377 = !DILocation(line: 1255, column: 1, scope: !5073, inlinedAt: !5084)
!5378 = !DILocation(line: 1275, column: 2, scope: !5057)
!5379 = distinct !DISubprogram(name: "cil_sock_release", scope: !104, file: !104, line: 1288, type: !5380, scopeLine: 1289, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5382)
!5380 = !DISubroutineType(types: !5381)
!5381 = !{!305, !1153}
!5382 = !{!5383, !5384, !5387}
!5383 = !DILocalVariable(name: "ctx", arg: 1, scope: !5379, file: !104, line: 1288, type: !1153)
!5384 = !DILocalVariable(name: "addr6", scope: !5385, file: !104, line: 1300, type: !160)
!5385 = distinct !DILexicalBlock(scope: !5386, file: !104, line: 1298, column: 31)
!5386 = distinct !DILexicalBlock(scope: !5379, file: !104, line: 1298, column: 6)
!5387 = !DILocalVariable(name: "fake_ctx", scope: !5388, file: !104, line: 1304, type: !1154)
!5388 = distinct !DILexicalBlock(scope: !5389, file: !104, line: 1303, column: 28)
!5389 = distinct !DILexicalBlock(scope: !5385, file: !104, line: 1303, column: 7)
!5390 = distinct !DIAssignID()
!5391 = distinct !DIAssignID()
!5392 = distinct !DIAssignID()
!5393 = distinct !DIAssignID()
!5394 = distinct !DIAssignID()
!5395 = distinct !DIAssignID()
!5396 = distinct !DIAssignID()
!5397 = distinct !DIAssignID()
!5398 = distinct !DIAssignID()
!5399 = !DILocation(line: 0, scope: !5379)
!5400 = !DILocation(line: 1291, column: 11, scope: !5401)
!5401 = distinct !DILexicalBlock(scope: !5379, file: !104, line: 1291, column: 6)
!5402 = !{!5403, !1130, i64 4}
!5403 = !{!"bpf_sock", !1130, i64 0, !1130, i64 4, !1130, i64 8, !1130, i64 12, !1130, i64 16, !1130, i64 20, !1130, i64 24, !1131, i64 28, !1130, i64 44, !1266, i64 48, !1130, i64 52, !1131, i64 56, !1130, i64 72, !1130, i64 76}
!5404 = !DILocation(line: 1291, column: 18, scope: !5401)
!5405 = !DILocation(line: 1291, column: 6, scope: !5379)
!5406 = !DILocalVariable(name: "key", scope: !5407, file: !104, line: 176, type: !955)
!5407 = distinct !DISubprogram(name: "sock4_delete_revnat", scope: !104, file: !104, line: 173, type: !5408, scopeLine: 175, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5412)
!5408 = !DISubroutineType(types: !5409)
!5409 = !{!305, !5410, !1153}
!5410 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5411, size: 64)
!5411 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1154)
!5412 = !{!5413, !5414, !5406, !5415}
!5413 = !DILocalVariable(name: "ctx", arg: 1, scope: !5407, file: !104, line: 173, type: !5410)
!5414 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !5407, file: !104, line: 174, type: !1153)
!5415 = !DILocalVariable(name: "ret", scope: !5407, file: !104, line: 177, type: !305)
!5416 = !DILocation(line: 0, scope: !5407, inlinedAt: !5417)
!5417 = distinct !DILocation(line: 1292, column: 8, scope: !5418)
!5418 = distinct !DILexicalBlock(scope: !5419, file: !104, line: 1292, column: 7)
!5419 = distinct !DILexicalBlock(scope: !5401, file: !104, line: 1291, column: 30)
!5420 = !DILocation(line: 176, column: 5, scope: !5407, inlinedAt: !5417)
!5421 = !DILocation(line: 176, column: 30, scope: !5407, inlinedAt: !5417)
!5422 = distinct !DIAssignID()
!5423 = distinct !DIAssignID()
!5424 = !DILocation(line: 179, column: 18, scope: !5407, inlinedAt: !5417)
!5425 = !DILocation(line: 179, column: 16, scope: !5407, inlinedAt: !5417)
!5426 = distinct !DIAssignID()
!5427 = !DILocation(line: 180, column: 31, scope: !5407, inlinedAt: !5417)
!5428 = !{!5403, !1130, i64 52}
!5429 = !DILocation(line: 180, column: 9, scope: !5407, inlinedAt: !5417)
!5430 = !DILocation(line: 180, column: 17, scope: !5407, inlinedAt: !5417)
!5431 = distinct !DIAssignID()
!5432 = !DILocation(line: 181, column: 28, scope: !5407, inlinedAt: !5417)
!5433 = !{!5403, !1266, i64 48}
!5434 = !DILocation(line: 181, column: 9, scope: !5407, inlinedAt: !5417)
!5435 = !DILocation(line: 181, column: 14, scope: !5407, inlinedAt: !5417)
!5436 = distinct !DIAssignID()
!5437 = !DILocation(line: 183, column: 11, scope: !5407, inlinedAt: !5417)
!5438 = !DILocation(line: 185, column: 1, scope: !5407, inlinedAt: !5417)
!5439 = !DILocation(line: 1292, column: 8, scope: !5418)
!5440 = !DILocation(line: 1292, column: 7, scope: !5419)
!5441 = !DILocation(line: 0, scope: !1761, inlinedAt: !5442)
!5442 = distinct !DILocation(line: 1293, column: 4, scope: !5418)
!5443 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5442)
!5444 = distinct !DIAssignID()
!5445 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5442)
!5446 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5442)
!5447 = distinct !DIAssignID()
!5448 = distinct !DIAssignID()
!5449 = distinct !DIAssignID()
!5450 = distinct !DIAssignID()
!5451 = distinct !DIAssignID()
!5452 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5442)
!5453 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5442)
!5454 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5442)
!5455 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5442)
!5456 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5442)
!5457 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5442)
!5458 = distinct !DIAssignID()
!5459 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5442)
!5460 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5442)
!5461 = distinct !DIAssignID()
!5462 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5442)
!5463 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5442)
!5464 = !DILocation(line: 1293, column: 4, scope: !5418)
!5465 = !DILocation(line: 1298, column: 11, scope: !5386)
!5466 = !DILocation(line: 1298, column: 18, scope: !5386)
!5467 = !DILocation(line: 1298, column: 6, scope: !5379)
!5468 = !DILocalVariable(name: "ctx", arg: 1, scope: !5469, file: !104, line: 686, type: !5410)
!5469 = distinct !DISubprogram(name: "ctx_get_v6_dst_address", scope: !104, file: !104, line: 686, type: !5470, scopeLine: 688, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5472)
!5470 = !DISubroutineType(types: !5471)
!5471 = !{null, !5410, !2755}
!5472 = !{!5468, !5473}
!5473 = !DILocalVariable(name: "addr", arg: 2, scope: !5469, file: !104, line: 687, type: !2755)
!5474 = !DILocation(line: 0, scope: !5469, inlinedAt: !5475)
!5475 = distinct !DILocation(line: 1302, column: 3, scope: !5385)
!5476 = !DILocation(line: 689, column: 18, scope: !5469, inlinedAt: !5475)
!5477 = !DILocation(line: 689, column: 13, scope: !5469, inlinedAt: !5475)
!5478 = !DILocation(line: 689, column: 11, scope: !5469, inlinedAt: !5475)
!5479 = !DILocation(line: 0, scope: !5385)
!5480 = !DILocation(line: 690, column: 2, scope: !5469, inlinedAt: !5475)
!5481 = !{i64 2148418320}
!5482 = !DILocation(line: 691, column: 13, scope: !5469, inlinedAt: !5475)
!5483 = !DILocation(line: 691, column: 11, scope: !5469, inlinedAt: !5475)
!5484 = !DILocation(line: 692, column: 2, scope: !5469, inlinedAt: !5475)
!5485 = !{i64 2148418355}
!5486 = !DILocation(line: 693, column: 13, scope: !5469, inlinedAt: !5475)
!5487 = !DILocation(line: 694, column: 2, scope: !5469, inlinedAt: !5475)
!5488 = !{i64 2148418390}
!5489 = !DILocation(line: 695, column: 13, scope: !5469, inlinedAt: !5475)
!5490 = !DILocation(line: 696, column: 2, scope: !5469, inlinedAt: !5475)
!5491 = !{i64 2148418425}
!5492 = !DILocation(line: 0, scope: !2901, inlinedAt: !5493)
!5493 = distinct !DILocation(line: 1303, column: 7, scope: !5389)
!5494 = !DILocation(line: 0, scope: !2912, inlinedAt: !5495)
!5495 = distinct !DILocation(line: 28, column: 9, scope: !2901, inlinedAt: !5493)
!5496 = !DILocation(line: 42, column: 12, scope: !2920, inlinedAt: !5495)
!5497 = !DILocation(line: 42, column: 6, scope: !2912, inlinedAt: !5495)
!5498 = !DILocation(line: 0, scope: !5388)
!5499 = !DILocation(line: 1308, column: 36, scope: !5388)
!5500 = !DILocation(line: 0, scope: !5407, inlinedAt: !5501)
!5501 = distinct !DILocation(line: 1310, column: 9, scope: !5502)
!5502 = distinct !DILexicalBlock(scope: !5388, file: !104, line: 1310, column: 8)
!5503 = !DILocation(line: 176, column: 5, scope: !5407, inlinedAt: !5501)
!5504 = !DILocation(line: 176, column: 30, scope: !5407, inlinedAt: !5501)
!5505 = distinct !DIAssignID()
!5506 = distinct !DIAssignID()
!5507 = !DILocation(line: 179, column: 18, scope: !5407, inlinedAt: !5501)
!5508 = !DILocation(line: 179, column: 16, scope: !5407, inlinedAt: !5501)
!5509 = distinct !DIAssignID()
!5510 = !DILocation(line: 180, column: 9, scope: !5407, inlinedAt: !5501)
!5511 = !DILocation(line: 180, column: 17, scope: !5407, inlinedAt: !5501)
!5512 = distinct !DIAssignID()
!5513 = !DILocation(line: 181, column: 9, scope: !5407, inlinedAt: !5501)
!5514 = !DILocation(line: 181, column: 14, scope: !5407, inlinedAt: !5501)
!5515 = distinct !DIAssignID()
!5516 = !DILocation(line: 183, column: 11, scope: !5407, inlinedAt: !5501)
!5517 = !DILocation(line: 185, column: 1, scope: !5407, inlinedAt: !5501)
!5518 = !DILocation(line: 1310, column: 9, scope: !5502)
!5519 = !DILocation(line: 1310, column: 8, scope: !5388)
!5520 = !DILocation(line: 0, scope: !1761, inlinedAt: !5521)
!5521 = distinct !DILocation(line: 1311, column: 5, scope: !5502)
!5522 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5521)
!5523 = distinct !DIAssignID()
!5524 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5521)
!5525 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5521)
!5526 = distinct !DIAssignID()
!5527 = distinct !DIAssignID()
!5528 = distinct !DIAssignID()
!5529 = distinct !DIAssignID()
!5530 = distinct !DIAssignID()
!5531 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5521)
!5532 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5521)
!5533 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5521)
!5534 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5521)
!5535 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5521)
!5536 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5521)
!5537 = distinct !DIAssignID()
!5538 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5521)
!5539 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5521)
!5540 = distinct !DIAssignID()
!5541 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5521)
!5542 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5521)
!5543 = !DILocation(line: 1311, column: 5, scope: !5502)
!5544 = !DILocalVariable(name: "key", scope: !5545, file: !104, line: 701, type: !982)
!5545 = distinct !DISubprogram(name: "sock6_delete_revnat", scope: !104, file: !104, line: 699, type: !5380, scopeLine: 700, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !5546)
!5546 = !{!5547, !5544, !5548}
!5547 = !DILocalVariable(name: "ctx", arg: 1, scope: !5545, file: !104, line: 699, type: !1153)
!5548 = !DILocalVariable(name: "ret", scope: !5545, file: !104, line: 702, type: !305)
!5549 = !DILocation(line: 0, scope: !5545, inlinedAt: !5550)
!5550 = distinct !DILocation(line: 1316, column: 9, scope: !5551)
!5551 = distinct !DILexicalBlock(scope: !5552, file: !104, line: 1316, column: 8)
!5552 = distinct !DILexicalBlock(scope: !5389, file: !104, line: 1315, column: 3)
!5553 = !DILocation(line: 701, column: 5, scope: !5545, inlinedAt: !5550)
!5554 = !DILocation(line: 701, column: 30, scope: !5545, inlinedAt: !5550)
!5555 = distinct !DIAssignID()
!5556 = distinct !DIAssignID()
!5557 = !DILocation(line: 704, column: 18, scope: !5545, inlinedAt: !5550)
!5558 = !DILocation(line: 704, column: 16, scope: !5545, inlinedAt: !5550)
!5559 = distinct !DIAssignID()
!5560 = !DILocation(line: 705, column: 38, scope: !5545, inlinedAt: !5550)
!5561 = !DILocation(line: 0, scope: !5469, inlinedAt: !5562)
!5562 = distinct !DILocation(line: 705, column: 5, scope: !5545, inlinedAt: !5550)
!5563 = !DILocation(line: 689, column: 13, scope: !5469, inlinedAt: !5562)
!5564 = !DILocation(line: 689, column: 11, scope: !5469, inlinedAt: !5562)
!5565 = distinct !DIAssignID()
!5566 = !DILocation(line: 690, column: 2, scope: !5469, inlinedAt: !5562)
!5567 = !DILocation(line: 691, column: 13, scope: !5469, inlinedAt: !5562)
!5568 = !DILocation(line: 691, column: 8, scope: !5469, inlinedAt: !5562)
!5569 = !DILocation(line: 691, column: 11, scope: !5469, inlinedAt: !5562)
!5570 = distinct !DIAssignID()
!5571 = !DILocation(line: 692, column: 2, scope: !5469, inlinedAt: !5562)
!5572 = !DILocation(line: 693, column: 13, scope: !5469, inlinedAt: !5562)
!5573 = !DILocation(line: 693, column: 8, scope: !5469, inlinedAt: !5562)
!5574 = !DILocation(line: 693, column: 11, scope: !5469, inlinedAt: !5562)
!5575 = distinct !DIAssignID()
!5576 = !DILocation(line: 694, column: 2, scope: !5469, inlinedAt: !5562)
!5577 = !DILocation(line: 695, column: 13, scope: !5469, inlinedAt: !5562)
!5578 = !DILocation(line: 695, column: 8, scope: !5469, inlinedAt: !5562)
!5579 = !DILocation(line: 695, column: 11, scope: !5469, inlinedAt: !5562)
!5580 = distinct !DIAssignID()
!5581 = !DILocation(line: 696, column: 2, scope: !5469, inlinedAt: !5562)
!5582 = !DILocation(line: 706, column: 28, scope: !5545, inlinedAt: !5550)
!5583 = !DILocation(line: 706, column: 9, scope: !5545, inlinedAt: !5550)
!5584 = !DILocation(line: 706, column: 14, scope: !5545, inlinedAt: !5550)
!5585 = distinct !DIAssignID()
!5586 = !DILocation(line: 708, column: 11, scope: !5545, inlinedAt: !5550)
!5587 = !DILocation(line: 710, column: 1, scope: !5545, inlinedAt: !5550)
!5588 = !DILocation(line: 1316, column: 9, scope: !5551)
!5589 = !DILocation(line: 1316, column: 8, scope: !5552)
!5590 = !DILocation(line: 0, scope: !1761, inlinedAt: !5591)
!5591 = distinct !DILocation(line: 1317, column: 5, scope: !5551)
!5592 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !5591)
!5593 = distinct !DIAssignID()
!5594 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !5591)
!5595 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !5591)
!5596 = distinct !DIAssignID()
!5597 = distinct !DIAssignID()
!5598 = distinct !DIAssignID()
!5599 = distinct !DIAssignID()
!5600 = distinct !DIAssignID()
!5601 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !5591)
!5602 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !5591)
!5603 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !5591)
!5604 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !5591)
!5605 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !5591)
!5606 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !5591)
!5607 = distinct !DIAssignID()
!5608 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !5591)
!5609 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !5591)
!5610 = distinct !DIAssignID()
!5611 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !5591)
!5612 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !5591)
!5613 = !DILocation(line: 1317, column: 5, scope: !5551)
!5614 = !DILocation(line: 1322, column: 2, scope: !5379)
