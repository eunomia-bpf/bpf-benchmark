use anyhow::{Result,bail};
use std::path::PathBuf;
use std::fs;
#[derive(Clone)] struct RuntimeLpmLayout {map_type:u32,lpm_type:u32,root:u32,max_prefixlen:u32,data_size:u32,child:u32,child_stride:u32,node_prefixlen:u32,node_flags:u32,node_data:u32,key_prefixlen:u32,key_data:u32}
struct RelocRecord {offset:u32,kind:u32,target:u64}
const X86_HELPER_CALL_REL32_SLOT:[u8;5]=[0xe8,0,0,0,0];
fn append_x86_jcc_rel32(b:&mut Vec<u8>,condition:u8)->usize {b.extend_from_slice(&[0x0f,condition]);let at=b.len();b.extend_from_slice(&[0;4]);at}
fn patch_x86_rel32(b:&mut Vec<u8>,offset:usize,target:usize)->Result<()> {let diff=i32::try_from(target as isize-offset as isize-4)?;b[offset..offset+4].copy_from_slice(&diff.to_le_bytes());Ok(())}
mod candidate;
fn main()->Result<()> {
 let l=RuntimeLpmLayout{map_type:12,lpm_type:11,root:40,max_prefixlen:56,data_size:64,child:8,child_stride:8,node_prefixlen:32,node_flags:36,node_data:48,key_prefixlen:0,key_data:4};
 let (bytes,call)=candidate::routine(&l)?;
 let out=PathBuf::from(std::env::args().nth(1).unwrap());fs::write(out.join("lpm.bin"),bytes)?;fs::write(out.join("fallback-offset"),call.to_string())?;Ok(())
}
