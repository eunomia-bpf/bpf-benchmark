#!/bin/bash
set -euo pipefail
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-lpm-overlap
date -u +%FT%TZ > "$r/build-started"
export CARGO_TARGET_DIR="$r/cargo" NATIVE_LINK_LPM_TEST_OUTPUT="$r/host-production"
taskset -c 20-23 cargo test --offline --manifest-path kprog/x86/native_lab/native_link/Cargo.toml > "$r/cargo-test.log" 2>&1
echo $? > "$r/cargo-test.exit"
taskset -c 20-23 cargo build --release --offline --manifest-path kprog/x86/native_lab/native_link/Cargo.toml > "$r/cargo-build.log" 2>&1
echo $? > "$r/cargo-build.exit"
mkdir -p "$r/payload"
install -m755 "$r/cargo/release/native-link" "$r/payload/native-link.real"
for name in runtime-lpm-layout.json runtime-hash-layout.json runtime-probe-read-layout.json; do cp corpus/results/perf-lpm-lto-linker-20261114/$name "$r/payload/$name"; done
install -m755 kprog/build/native-link-lpm.sh "$r/payload/native-link-on"
install -m755 kprog/build/native-link-lpm.sh "$r/payload/native-link-off"
taskset -c 20-23 make -f kprog/build/Makefile hash-lookup-kernel-inputs HASH_KERNEL_BUILD="$r/inputs" HASH_KERNEL_CASES='4-11 2-11' > "$r/kernel-inputs.log" 2>&1
date -u +%FT%TZ > "$r/build-finished"
