#!/bin/bash
set -uo pipefail
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-lpm-overlap
exec > "$r/kernel/job.log" 2>&1
exec 9>>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
date -u +%FT%TZ > "$r/kernel/started"
taskset -c 22-23 vng --run /workspaces/.agent-state/kprog-ck/build-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/kprog-raw --overlay-rwdir /tmp --disable-monitor --cpus 1 --memory 4G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -f kprog/build/Makefile guest-hash-lookup HASH_KERNEL_OUTPUT=/workspaces/kprog-raw/perf/20261114-lpm-overlap/kernel RUNTIME_HASH_PAYLOAD=/workspaces/kprog-raw/perf/20261114-lpm-overlap/payload HASH_KERNEL_CASES="4-11 2-11"'
echo $? > "$r/kernel/exit-code"
date -u +%FT%TZ > "$r/kernel/finished"
