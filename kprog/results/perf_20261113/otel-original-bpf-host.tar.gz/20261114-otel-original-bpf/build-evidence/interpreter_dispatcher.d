/var/tmp/kprog-tmp/perf/otel-upstream-all/interpreter_dispatcher.bc: \
  interpreter_dispatcher.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h \
  extmaps.h frametypes.h types.h tsd.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
tsd.h:
