/var/tmp/kprog-tmp/perf/otel-upstream-all/off_cpu.bc: off_cpu.ebpf.c \
  bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
