/var/tmp/kprog-tmp/perf/otel-upstream-all/uprobe.bc: uprobe.ebpf.c \
  bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
