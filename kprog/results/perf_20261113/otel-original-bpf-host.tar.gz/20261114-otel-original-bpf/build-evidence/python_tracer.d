/var/tmp/kprog-tmp/perf/otel-upstream-all/python_tracer.bc: \
  python_tracer.ebpf.c bpfdefs.h kernel.h errors.h tracemgmt.h extmaps.h \
  frametypes.h types.h tsd.h
bpfdefs.h:
kernel.h:
errors.h:
tracemgmt.h:
extmaps.h:
frametypes.h:
types.h:
tsd.h:
