/var/tmp/kprog-tmp/perf/otel-upstream-all/hotspot_tracer.bc: \
  hotspot_tracer.ebpf.c bpfdefs.h kernel.h errors.h tracemgmt.h \
  extmaps.h frametypes.h types.h
bpfdefs.h:
kernel.h:
errors.h:
tracemgmt.h:
extmaps.h:
frametypes.h:
types.h:
