/var/tmp/kprog-tmp/perf/otel-upstream-all/integration_test.bc: \
  integration_test.ebpf.c bpfdefs.h kernel.h extmaps.h frametypes.h \
  tracemgmt.h errors.h types.h
bpfdefs.h:
kernel.h:
extmaps.h:
frametypes.h:
tracemgmt.h:
errors.h:
types.h:
