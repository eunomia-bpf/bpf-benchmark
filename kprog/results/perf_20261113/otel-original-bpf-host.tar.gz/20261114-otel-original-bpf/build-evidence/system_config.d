/var/tmp/kprog-tmp/perf/otel-upstream-all/system_config.bc: \
  system_config.ebpf.c bpfdefs.h kernel.h extmaps.h types.h errors.h
bpfdefs.h:
kernel.h:
extmaps.h:
types.h:
errors.h:
