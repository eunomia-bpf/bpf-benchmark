/var/tmp/kprog-tmp/perf/otel-upstream-all/sched_monitor.bc: \
  sched_monitor.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
