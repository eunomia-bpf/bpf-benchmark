/var/tmp/kprog-tmp/perf/otel-upstream-all/custom_trace.bc: \
  custom_trace.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
