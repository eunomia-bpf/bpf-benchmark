/var/tmp/kprog-tmp/perf/otel-upstream-all/php_tracer.bc: \
  php_tracer.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
