/var/tmp/kprog-tmp/perf/otel-upstream-all/ruby_tracer.bc: \
  ruby_tracer.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h tsd.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
tsd.h:
