/var/tmp/kprog-tmp/perf/otel-upstream-all/dotnet_tracer.bc: \
  dotnet_tracer.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
