/var/tmp/kprog-tmp/perf/otel-upstream-all/perl_tracer.bc: \
  perl_tracer.ebpf.c bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h tsd.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
tsd.h:
