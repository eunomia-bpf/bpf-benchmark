/var/tmp/kprog-tmp/perf/otel-upstream-all/v8_tracer.bc: v8_tracer.ebpf.c \
  v8_tracer.h bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h \
  frametypes.h types.h
v8_tracer.h:
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
