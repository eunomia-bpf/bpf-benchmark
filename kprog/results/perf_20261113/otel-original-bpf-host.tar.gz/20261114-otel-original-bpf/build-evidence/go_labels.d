/var/tmp/kprog-tmp/perf/otel-upstream-all/go_labels.bc: go_labels.ebpf.c \
  bpfdefs.h kernel.h tracemgmt.h errors.h extmaps.h frametypes.h types.h \
  tsd.h
bpfdefs.h:
kernel.h:
tracemgmt.h:
errors.h:
extmaps.h:
frametypes.h:
types.h:
tsd.h:
