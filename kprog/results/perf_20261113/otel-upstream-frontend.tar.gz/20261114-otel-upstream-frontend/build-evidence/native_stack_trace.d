/var/tmp/kprog-tmp/perf/otel-upstream/native_stack_trace.bc: \
  native_stack_trace.ebpf.c bpfdefs.h kernel.h frametypes.h \
  stackdeltatypes.h tracemgmt.h errors.h extmaps.h types.h
bpfdefs.h:
kernel.h:
frametypes.h:
stackdeltatypes.h:
tracemgmt.h:
errors.h:
extmaps.h:
types.h:
