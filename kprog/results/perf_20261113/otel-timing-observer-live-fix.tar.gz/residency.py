from pathlib import Path
import os,json,time,datetime
r=Path(__file__).resolve().parent;streams={}
def snapshot(event,log=None):
 guests=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   args=(p/'cmdline').read_bytes().split(b'\0')
   if not args or b'qemu-system' not in args[0]:continue
   status=(p/'status').read_text();affinities={}
   for t in (p/'task').iterdir():
    try:affinities[t.name]=(t/'status').read_text().split('Cpus_allowed_list:')[1].splitlines()[0].strip()
    except (FileNotFoundError,ProcessLookupError):pass
   guests.append(dict(pid=int(p.name),argv=[a.decode(errors='replace') for a in args if a],thread_cpus=affinities,rss_kib=next(int(x.split()[1]) for x in status.splitlines() if x.startswith('VmRSS:')),start_ticks=(p/'stat').read_text().split()[21]))
  except (FileNotFoundError,ProcessLookupError,StopIteration):pass
 row=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),monotonic_ns=time.monotonic_ns(),event=event,log=log,guests=guests,scope='Read-only host observation at log consumption, up to1s after event; no causal interference claim.')
 with (r/'residency.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
snapshot('watcher_start')
while True:
 for p in (r/'runs').glob('*stats*.log'):
  if p not in streams:streams[p]=p.open()
  f=streams[p]
  while True:
   offset=f.tell();line=f.readline()
   if not line or not line.endswith('\n'):f.seek(offset);break
   try:event=json.loads(line)
   except ValueError:continue
   if event.get('event') in ('app_start','measurement_start','measurement_done','app_done'):snapshot(event,str(p))
 if (r/'finished').exists():snapshot('job_finished');break
 time.sleep(1)
