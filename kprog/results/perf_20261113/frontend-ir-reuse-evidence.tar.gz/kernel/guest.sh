#!/bin/bash
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-frontend-ir-reuse/kernel
for item in 4-11 2-11; do
 output="$r/$item";mkdir -p "$output"
 CLANG=/workspaces/repository/kprog/stock-path/bin/clang python3 kprog/trusted_service.py --arch 1 --endpoint /sys/kernel/debug/bpf_x86_native_lab/specializer --module /workspaces/.agent-state/kprog-ck/verified-module/bpf_x86_native_lab.ko --state "$output/state" --results "$output/service.tar.gz" --native-link /workspaces/kprog-raw/perf/20261114-lpm-overlap/payload/native-link-on --loader /workspaces/.agent-state/kprog-ck/verified-loader/trusted-native-loader --execution-mode checked-sim-c --sim-native-compiler /workspaces/.agent-state/kprog-ck/verified-compiler/compile-sim-ir --sim-context-compiler /workspaces/.agent-state/kprog-ck/verified-compiler/context-lower --sim-public-layout /workspaces/.agent-state/kprog-ck/verified-compiler/public-layout.json --sim-physical-layout /workspaces/.agent-state/kprog-ck/verified-compiler/physical-layout.json --sim-bounds-compiler /workspaces/.agent-state/kprog-ck/verified-compiler/packet-bounds --run "$r/client" "$r/$item.bpf.o" "$r/$item.native.o" /workspaces/kprog-raw/perf/20261114-lpm-overlap/payload/native-link-on "$output" > "$output/service.log" 2>&1
 echo $? > "$output/exit-code"
done
