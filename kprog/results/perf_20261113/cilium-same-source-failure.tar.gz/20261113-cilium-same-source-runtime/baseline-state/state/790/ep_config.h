/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: bpfbench-cepa
 * Container Interface: eth0
 * IPv4 address: 10.244.0.149
 * Identity: 28241
 * PolicyMap: cilium_policy_v2_00790
 * NodeMAC: c6:23:f7:7b:61:a6
 */

/*
 * Labels:
 * - container:app=bpfbench-cilium
 * - container:instance=a
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#undef MONITOR_AGGREGATION
#define POLICY_AUDIT_MODE 1
#define POLICY_VERDICT_NOTIFY 1
#undef ENABLE_SIP_VERIFICATION
#define TRACE_NOTIFY 1
