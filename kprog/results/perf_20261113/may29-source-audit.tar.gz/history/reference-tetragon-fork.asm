
/workspaces/kprog-raw/kprog-r-art/art/native-bpf/x86_64/tetragon/bpf_fork_v511.native.o:	file format elf64-x86-64

Disassembly of section kprobe/wake_up_new_task:

0000000000000000 <event_wake_up_new_task>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x118, %rsp            # imm = 0x118
      11:      	movq	0x70(%rdi), %r14
      15:      	testq	%r14, %r14
      18:      	je	0xf42 <event_wake_up_new_task+0xf42>
      1e:      	movq	%rdi, %r13
      21:      	leaq	0xaf4(%r14), %rdx
      28:      	leaq	0x80(%rsp), %rdi
      30:      	movl	$0x4, %ecx
      35:      	movl	$0x4, %eax
      3a:      	movl	$0x4, %esi
      3f:      	callq	*%rax
      41:      	movl	0x80(%rsp), %ebp
      48:      	movq	%r14, 0x80(%rsp)
      50:      	leaq	0xb00(%r14), %rcx
      57:      	leaq	0x80(%rsp), %rdi
      5f:      	movl	$0x8, %edx
      64:      	movl	$0x71, %eax
      69:      	movl	$0xb00, %edx            # imm = 0xB00
      6e:      	addq	0x80(%rsp), %rdx
      76:      	movl	$0x8, %esi
      7b:      	callq	*%rax
      7d:      	movq	0x80(%rsp), %rcx
      85:      	testq	%rcx, %rcx
      88:      	je	0xf42 <event_wake_up_new_task+0xf42>
      8e:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      95:      	leaq	0x10(%rsp), %rdi
      9a:      	movl	$0x4, %edx
      9f:      	movl	$0x71, %eax
      a4:      	movl	$0xaf4, %edx            # imm = 0xAF4
      a9:      	addq	0x80(%rsp), %rdx
      b1:      	movl	$0x4, %esi
      b6:      	callq	*%rax
      b8:      	movl	0x10(%rsp), %eax
      bc:      	movl	%eax, 0x40(%rsp)
      c0:      	movq	(%rip), %rdi            # 0xc7 <event_wake_up_new_task+0xc7>
      c7:      	leaq	0x40(%rsp), %rsi
      cc:      	movl	$0x1, %eax
      d1:      	callq	*%rax
      d3:      	testq	%rax, %rax
      d6:      	je	0xe6 <event_wake_up_new_task+0xe6>
      d8:      	movq	%rax, %r15
      db:      	cmpq	$0x0, 0x8(%rax)
      e0:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
      e6:      	movl	$0xb00, %edx            # imm = 0xB00
      eb:      	movq	0x80(%rsp), %rcx
      f3:      	addq	%rdx, %rcx
      f6:      	leaq	0x80(%rsp), %rdi
      fe:      	movl	$0x8, %esi
     103:      	movl	$0x71, %eax
     108:      	addq	0x80(%rsp), %rdx
     110:      	movl	$0x8, %esi
     115:      	callq	*%rax
     117:      	movq	0x80(%rsp), %rcx
     11f:      	testq	%rcx, %rcx
     122:      	je	0xf42 <event_wake_up_new_task+0xf42>
     128:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     12f:      	leaq	0x10(%rsp), %rdi
     134:      	movl	$0x4, %edx
     139:      	movl	$0x71, %eax
     13e:      	movl	$0xaf4, %edx            # imm = 0xAF4
     143:      	addq	0x80(%rsp), %rdx
     14b:      	movl	$0x4, %esi
     150:      	callq	*%rax
     152:      	movl	0x10(%rsp), %eax
     156:      	movl	%eax, 0x40(%rsp)
     15a:      	movq	(%rip), %rdi            # 0x161 <event_wake_up_new_task+0x161>
     161:      	leaq	0x40(%rsp), %rsi
     166:      	movl	$0x1, %eax
     16b:      	callq	*%rax
     16d:      	testq	%rax, %rax
     170:      	je	0x180 <event_wake_up_new_task+0x180>
     172:      	movq	%rax, %r15
     175:      	cmpq	$0x0, 0x8(%rax)
     17a:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
     180:      	movl	$0xb00, %edx            # imm = 0xB00
     185:      	movq	0x80(%rsp), %rcx
     18d:      	addq	%rdx, %rcx
     190:      	leaq	0x80(%rsp), %rdi
     198:      	movl	$0x8, %esi
     19d:      	movl	$0x71, %eax
     1a2:      	addq	0x80(%rsp), %rdx
     1aa:      	movl	$0x8, %esi
     1af:      	callq	*%rax
     1b1:      	movq	0x80(%rsp), %rcx
     1b9:      	testq	%rcx, %rcx
     1bc:      	je	0xf42 <event_wake_up_new_task+0xf42>
     1c2:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1c9:      	leaq	0x10(%rsp), %rdi
     1ce:      	movl	$0x4, %edx
     1d3:      	movl	$0x71, %eax
     1d8:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1dd:      	addq	0x80(%rsp), %rdx
     1e5:      	movl	$0x4, %esi
     1ea:      	callq	*%rax
     1ec:      	movl	0x10(%rsp), %eax
     1f0:      	movl	%eax, 0x40(%rsp)
     1f4:      	movq	(%rip), %rdi            # 0x1fb <event_wake_up_new_task+0x1fb>
     1fb:      	leaq	0x40(%rsp), %rsi
     200:      	movl	$0x1, %eax
     205:      	callq	*%rax
     207:      	testq	%rax, %rax
     20a:      	je	0x21a <event_wake_up_new_task+0x21a>
     20c:      	movq	%rax, %r15
     20f:      	cmpq	$0x0, 0x8(%rax)
     214:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
     21a:      	movl	$0xb00, %edx            # imm = 0xB00
     21f:      	movq	0x80(%rsp), %rcx
     227:      	addq	%rdx, %rcx
     22a:      	leaq	0x80(%rsp), %rdi
     232:      	movl	$0x8, %esi
     237:      	movl	$0x71, %eax
     23c:      	addq	0x80(%rsp), %rdx
     244:      	movl	$0x8, %esi
     249:      	callq	*%rax
     24b:      	movq	0x80(%rsp), %rcx
     253:      	testq	%rcx, %rcx
     256:      	je	0xf42 <event_wake_up_new_task+0xf42>
     25c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     263:      	leaq	0x10(%rsp), %rdi
     268:      	movl	$0x4, %edx
     26d:      	movl	$0x71, %eax
     272:      	movl	$0xaf4, %edx            # imm = 0xAF4
     277:      	addq	0x80(%rsp), %rdx
     27f:      	movl	$0x4, %esi
     284:      	callq	*%rax
     286:      	movl	0x10(%rsp), %eax
     28a:      	movl	%eax, 0x40(%rsp)
     28e:      	movq	(%rip), %rdi            # 0x295 <event_wake_up_new_task+0x295>
     295:      	leaq	0x40(%rsp), %rsi
     29a:      	movl	$0x1, %eax
     29f:      	callq	*%rax
     2a1:      	testq	%rax, %rax
     2a4:      	je	0xf42 <event_wake_up_new_task+0xf42>
     2aa:      	movq	%rax, %r15
     2ad:      	cmpq	$0x0, 0x8(%rax)
     2b2:      	je	0xf42 <event_wake_up_new_task+0xf42>
     2b8:      	movl	%ebp, 0x40(%rsp)
     2bc:      	movq	(%rip), %rdi            # 0x2c3 <event_wake_up_new_task+0x2c3>
     2c3:      	leaq	0x40(%rsp), %rsi
     2c8:      	movl	$0x1, %eax
     2cd:      	callq	*%rax
     2cf:      	testq	%rax, %rax
     2d2:      	je	0x5d9 <event_wake_up_new_task+0x5d9>
     2d8:      	movq	%rax, %r12
     2db:      	cmpq	$0x0, 0x8(%r12)
     2e1:      	jne	0xf42 <event_wake_up_new_task+0xf42>
     2e7:      	movl	$0x1, 0x20(%r12)
     2f0:      	movl	%ebp, (%r12)
     2f4:      	movl	$0x7d, %eax
     2f9:      	callq	*%rax
     2fb:      	movq	%rax, 0x8(%r12)
     300:      	leaq	0x60(%r14), %rdx
     304:      	leaq	0x40(%rsp), %rdi
     309:      	movl	$0x8, %ecx
     30e:      	movl	$0x71, %eax
     313:      	movl	$0x8, %esi
     318:      	callq	*%rax
     31a:      	movq	0x40(%rsp), %rcx
     31f:      	xorl	%ebx, %ebx
     321:      	testq	%rcx, %rcx
     324:      	movq	%r13, 0x110(%rsp)
     32c:      	je	0x3a1 <event_wake_up_new_task+0x3a1>
     32e:      	addq	$0x4, %rcx
     332:      	leaq	0x10(%rsp), %rdi
     337:      	movl	$0x4, %edx
     33c:      	movl	$0x71, %eax
     341:      	movq	0x40(%rsp), %rdx
     346:      	addq	$0x4, %rdx
     34a:      	movl	$0x4, %esi
     34f:      	callq	*%rax
     351:      	movl	0x10(%rsp), %eax
     355:      	testl	%eax, %eax
     357:      	je	0x3a1 <event_wake_up_new_task+0x3a1>
     359:      	movq	0x40(%rsp), %rcx
     35e:      	shll	$0x4, %eax
     361:      	addq	%rax, %rcx
     364:      	addq	$0x80, %rcx
     36b:      	leaq	0x80(%rsp), %rdi
     373:      	movl	$0x10, %edx
     378:      	movl	$0x71, %eax
     37d:      	movq	0x40(%rsp), %rcx
     382:      	movl	0x10(%rsp), %edx
     386:      	shll	$0x4, %edx
     389:      	addq	%rcx, %rdx
     38c:      	addq	$0x80, %rdx
     393:      	movl	$0x10, %esi
     398:      	callq	*%rax
     39a:      	movl	0x80(%rsp), %ebx
     3a1:      	movl	%ebx, 0x24(%r12)
     3a6:      	leaq	0x68(%r12), %rdi
     3ab:      	leaq	0x68(%r15), %rsi
     3af:      	movl	$0x318, %edx            # imm = 0x318
     3b4:      	callq	0x3b9 <event_wake_up_new_task+0x3b9>
     3b9:      	movq	(%r15), %rax
     3bc:      	movq	0x8(%r15), %rcx
     3c0:      	movq	%rax, 0x10(%r12)
     3c5:      	movq	%rcx, 0x18(%r12)
     3ca:      	leaq	0xd00(%r14), %rdx
     3d1:      	leaq	0x80(%rsp), %rdi
     3d9:      	movl	$0x8, %ecx
     3de:      	movl	$0x4, %eax
     3e3:      	leaq	0x50(%r12), %r13
     3e8:      	movl	$0x4, %ebx
     3ed:      	movl	$0x8, %esi
     3f2:      	callq	*%rax
     3f4:      	movq	0x80(%rsp), %rbp
     3fc:      	leaq	0x58(%r12), %rdi
     401:      	leaq	0x40(%rbp), %rdx
     405:      	movl	$0x8, %ecx
     40a:      	movl	$0x4, %eax
     40f:      	movl	$0x8, %esi
     414:      	callq	*%rax
     416:      	leaq	0x60(%r12), %rdi
     41b:      	leaq	0x30(%rbp), %rdx
     41f:      	movl	$0x8, %ecx
     424:      	movl	$0x4, %eax
     429:      	movl	$0x8, %esi
     42e:      	callq	*%rax
     430:      	addq	$0x38, %rbp
     434:      	movl	$0x8, %ecx
     439:      	movl	$0x4, %eax
     43e:      	movq	%r13, %rdi
     441:      	movl	$0x8, %esi
     446:      	movq	%rbp, %rdx
     449:      	callq	*%rax
     44b:      	leaq	0x28(%r12), %r13
     450:      	leaq	0xd70(%r14), %rdx
     457:      	leaq	0x10(%rsp), %rdi
     45c:      	movl	$0x8, %ecx
     461:      	movl	$0x4, %eax
     466:      	movl	$0x8, %esi
     46b:      	callq	*%rax
     46d:      	movq	0x10(%rsp), %rcx
     472:      	leaq	0x80(%rsp), %rdi
     47a:      	movl	$0x48, %edx
     47f:      	movl	$0x4, %eax
     484:      	movq	0x10(%rsp), %rdx
     489:      	movl	$0x48, %esi
     48e:      	callq	*%rax
     490:      	movl	$0x218, %edx            # imm = 0x218
     495:      	movq	0x88(%rsp), %rcx
     49d:      	addq	%rdx, %rcx
     4a0:      	movl	$0x4, %esi
     4a5:      	movl	$0x4, %eax
     4aa:      	addq	0x88(%rsp), %rdx
     4b2:      	movq	%r13, %rdi
     4b5:      	movl	$0x4, %esi
     4ba:      	callq	*%rax
     4bc:      	leaq	0x2c(%r12), %rdi
     4c1:      	movl	$0x4d8, %edx            # imm = 0x4D8
     4c6:      	movq	0x90(%rsp), %rcx
     4ce:      	addq	%rdx, %rcx
     4d1:      	movl	$0x4, %esi
     4d6:      	movl	$0x4, %eax
     4db:      	addq	0x90(%rsp), %rdx
     4e3:      	movl	$0x4, %esi
     4e8:      	callq	*%rax
     4ea:      	leaq	0x30(%r12), %rdi
     4ef:      	movq	0x98(%rsp), %rcx
     4f7:      	addq	$0x58, %rcx
     4fb:      	movl	$0x4, %edx
     500:      	movl	$0x4, %eax
     505:      	movq	0x98(%rsp), %rdx
     50d:      	addq	$0x58, %rdx
     511:      	movl	$0x4, %esi
     516:      	callq	*%rax
     518:      	movq	$0x0, (%rsp)
     520:      	leaq	0xb58(%r14), %rdx
     527:      	movq	%rsp, %rdi
     52a:      	movl	$0x8, %ecx
     52f:      	movl	$0x4, %eax
     534:      	movl	$0x8, %esi
     539:      	callq	*%rax
     53b:      	movq	(%rsp), %rcx
     53f:      	testq	%rcx, %rcx
     542:      	je	0x67e <event_wake_up_new_task+0x67e>
     548:      	movl	$0x0, 0x8(%rsp)
     550:      	addq	$0x4, %rcx
     554:      	leaq	0x8(%rsp), %rdi
     559:      	movl	$0x4, %eax
     55e:      	movq	(%rsp), %rdx
     562:      	addq	$0x4, %rdx
     566:      	movl	$0x4, %esi
     56b:      	callq	*%rax
     56d:      	movq	(%rsp), %rax
     571:      	movslq	0x8(%rsp), %rcx
     576:      	shlq	$0x4, %rcx
     57a:      	addq	%rax, %rcx
     57d:      	addq	$0x80, %rcx
     584:      	leaq	0x40(%rsp), %rdi
     589:      	movl	$0x10, %edx
     58e:      	movl	$0x4, %eax
     593:      	movq	(%rsp), %rcx
     597:      	movslq	0x8(%rsp), %rdx
     59c:      	shlq	$0x4, %rdx
     5a0:      	addq	%rcx, %rdx
     5a3:      	addq	$0x80, %rdx
     5aa:      	movl	$0x10, %esi
     5af:      	callq	*%rax
     5b1:      	leaq	0x34(%r12), %rdi
     5b6:      	movl	$0x158, %edx            # imm = 0x158
     5bb:      	movq	0x48(%rsp), %rcx
     5c0:      	addq	%rdx, %rcx
     5c3:      	movl	$0x4, %eax
     5c8:      	addq	0x48(%rsp), %rdx
     5cd:      	movl	$0x4, %esi
     5d2:      	callq	*%rax
     5d4:      	jmp	0x687 <event_wake_up_new_task+0x687>
     5d9:      	movl	$0x0, 0x10(%rsp)
     5e1:      	movq	(%rip), %rdi            # 0x5e8 <event_wake_up_new_task+0x5e8>
     5e8:      	leaq	0x10(%rsp), %rsi
     5ed:      	movl	$0x1, %eax
     5f2:      	callq	*%rax
     5f4:      	testq	%rax, %rax
     5f7:      	je	0xf42 <event_wake_up_new_task+0xf42>
     5fd:      	xorl	%ebx, %ebx
     5ff:      	movl	$0x380, %edx            # imm = 0x380
     604:      	movq	%rax, %rdi
     607:      	xorl	%esi, %esi
     609:      	movq	%rax, %r12
     60c:      	callq	0x611 <event_wake_up_new_task+0x611>
     611:      	movq	(%rip), %rdi            # 0x618 <event_wake_up_new_task+0x618>
     618:      	leaq	0x40(%rsp), %rsi
     61d:      	movl	$0x2, %eax
     622:      	movq	%r12, %rdx
     625:      	xorl	%ecx, %ecx
     627:      	callq	*%rax
     629:      	testl	%eax, %eax
     62b:      	je	0x9e1 <event_wake_up_new_task+0x9e1>
     631:      	movl	$0x1, 0x80(%rsp)
     63c:      	movq	(%rip), %rdi            # 0x643 <event_wake_up_new_task+0x643>
     643:      	leaq	0x80(%rsp), %rsi
     64b:      	movl	$0x1, %eax
     650:      	callq	*%rax
     652:      	testq	%rax, %rax
     655:      	je	0x65a <event_wake_up_new_task+0x65a>
     657:      	incq	(%rax)
     65a:      	movq	(%rip), %rdi            # 0x661 <event_wake_up_new_task+0x661>
     661:      	leaq	0x40(%rsp), %rsi
     666:      	movl	$0x1, %eax
     66b:      	callq	*%rax
     66d:      	movq	%rax, %r12
     670:      	testq	%rax, %rax
     673:      	jne	0x2db <event_wake_up_new_task+0x2db>
     679:      	jmp	0xf42 <event_wake_up_new_task+0xf42>
     67e:      	movl	$0x0, 0x34(%r12)
     687:      	leaq	0x38(%r12), %rdi
     68c:      	movl	$0x158, %r13d           # imm = 0x158
     692:      	movq	0xa0(%rsp), %rcx
     69a:      	addq	%r13, %rcx
     69d:      	movl	$0x4, %edx
     6a2:      	movl	$0x4, %eax
     6a7:      	leaq	0x10(%r12), %rbx
     6ac:      	movq	0xa0(%rsp), %rdx
     6b4:      	addq	%r13, %rdx
     6b7:      	movl	$0x4, %esi
     6bc:      	callq	*%rax
     6be:      	leaq	0x3c(%r12), %rdi
     6c3:      	movl	$0x118, %edx            # imm = 0x118
     6c8:      	movq	0xa8(%rsp), %rcx
     6d0:      	addq	%rdx, %rcx
     6d3:      	movl	$0x4, %esi
     6d8:      	movl	$0x4, %eax
     6dd:      	addq	0xa8(%rsp), %rdx
     6e5:      	movl	$0x4, %esi
     6ea:      	callq	*%rax
     6ec:      	leaq	0x40(%r12), %rdi
     6f1:      	movl	$0x98, %ebp
     6f6:      	movq	0xb0(%rsp), %rcx
     6fe:      	addq	%rbp, %rcx
     701:      	movl	$0x4, %edx
     706:      	movl	$0x4, %eax
     70b:      	movq	0xb0(%rsp), %rdx
     713:      	addq	%rbp, %rdx
     716:      	movl	$0x4, %esi
     71b:      	callq	*%rax
     71d:      	leaq	0x44(%r12), %rdi
     722:      	movq	0xb8(%rsp), %rcx
     72a:      	addq	%rbp, %rcx
     72d:      	movl	$0x4, %edx
     732:      	movl	$0x4, %eax
     737:      	addq	0xb8(%rsp), %rbp
     73f:      	movl	$0x4, %esi
     744:      	movq	%rbp, %rdx
     747:      	callq	*%rax
     749:      	leaq	0x48(%r12), %rdi
     74e:      	movq	0xc0(%rsp), %rcx
     756:      	addq	$0x58, %rcx
     75a:      	movl	$0x4, %edx
     75f:      	movl	$0x4, %eax
     764:      	movq	0xc0(%rsp), %rdx
     76c:      	addq	$0x58, %rdx
     770:      	movl	$0x4, %esi
     775:      	callq	*%rax
     777:      	movq	$0x0, 0x40(%rsp)
     780:      	leaq	0xa78(%r14), %rdx
     787:      	leaq	0x40(%rsp), %rdi
     78c:      	movl	$0x8, %ecx
     791:      	movl	$0x4, %eax
     796:      	movl	$0x8, %esi
     79b:      	callq	*%rax
     79d:      	movl	$0x5a0, %edx            # imm = 0x5A0
     7a2:      	movq	0x40(%rsp), %rcx
     7a7:      	addq	%rdx, %rcx
     7aa:      	movq	%rsp, %rdi
     7ad:      	movl	$0x8, %esi
     7b2:      	movl	$0x4, %eax
     7b7:      	addq	0x40(%rsp), %rdx
     7bc:      	movl	$0x8, %esi
     7c1:      	callq	*%rax
     7c3:      	leaq	0x4c(%r12), %rdi
     7c8:      	movq	(%rsp), %rcx
     7cc:      	addq	%r13, %rcx
     7cf:      	movl	$0x4, %edx
     7d4:      	movl	$0x4, %eax
     7d9:      	addq	(%rsp), %r13
     7dd:      	movl	$0x4, %esi
     7e2:      	movq	%r13, %rdx
     7e5:      	callq	*%rax
     7e7:      	testb	$0x2, 0x23(%r15)
     7ec:      	jne	0x7f6 <event_wake_up_new_task+0x7f6>
     7ee:      	cmpl	$0x1, 0x24(%r12)
     7f4:      	jne	0x7fc <event_wake_up_new_task+0x7fc>
     7f6:      	orb	$0x2, 0x23(%r12)
     7fc:      	movb	$0x17, 0x40(%rsp)
     801:      	movl	$0x38, 0x44(%rsp)
     809:      	movq	0x8(%r12), %rax
     80e:      	movq	%rax, 0x48(%rsp)
     813:      	movq	(%rbx), %rax
     816:      	movq	0x8(%rbx), %rcx
     81a:      	movq	%rax, 0x50(%rsp)
     81f:      	movq	%rcx, 0x58(%rsp)
     824:      	movl	(%r12), %eax
     828:      	movl	%eax, 0x60(%rsp)
     82c:      	leaq	0xaf0(%r14), %rdx
     833:      	leaq	0x80(%rsp), %rdi
     83b:      	movl	$0x4, %ecx
     840:      	movl	$0x4, %eax
     845:      	movl	$0x4, %esi
     84a:      	callq	*%rax
     84c:      	movl	0x80(%rsp), %eax
     853:      	movl	%eax, 0x64(%rsp)
     857:      	movq	0x8(%r12), %rax
     85c:      	movq	%rax, 0x70(%rsp)
     861:      	movl	0x24(%r12), %eax
     866:      	movl	%eax, 0x68(%rsp)
     86a:      	movl	0x20(%r12), %eax
     86f:      	movl	%eax, 0x6c(%rsp)
     873:      	movl	$0x0, 0x3c(%rsp)
     87b:      	leaq	0x80(%rsp), %rdi
     883:      	xorl	%r15d, %r15d
     886:      	movl	$0x90, %edx
     88b:      	xorl	%esi, %esi
     88d:      	callq	0x892 <event_wake_up_new_task+0x892>
     892:      	movq	(%rip), %rdi            # 0x899 <event_wake_up_new_task+0x899>
     899:      	leaq	0x3c(%rsp), %rsi
     89e:      	movl	$0x1, %eax
     8a3:      	callq	*%rax
     8a5:      	testq	%rax, %rax
     8a8:      	movq	0x110(%rsp), %r13
     8b0:      	je	0x8bc <event_wake_up_new_task+0x8bc>
     8b2:      	movq	0x20(%rax), %rbx
     8b6:      	movl	0x10(%rax), %r15d
     8ba:      	jmp	0x8be <event_wake_up_new_task+0x8be>
     8bc:      	xorl	%ebx, %ebx
     8be:      	movq	$0x0, 0x8(%rsp)
     8c7:      	addq	$0xf88, %r14            # imm = 0xF88
     8ce:      	movq	%rsp, %rdi
     8d1:      	movl	$0x8, %ecx
     8d6:      	movl	$0x71, %eax
     8db:      	movl	$0x8, %esi
     8e0:      	movq	%r14, %rdx
     8e3:      	callq	*%rax
     8e5:      	movq	(%rsp), %rcx
     8e9:      	testq	%rcx, %rcx
     8ec:      	je	0x964 <event_wake_up_new_task+0x964>
     8ee:      	cmpq	$0x63677270, %rbx       # imm = 0x63677270
     8f5:      	jne	0x914 <event_wake_up_new_task+0x914>
     8f7:      	addq	$0x78, %rcx
     8fb:      	leaq	0x8(%rsp), %rdi
     900:      	movl	$0x8, %edx
     905:      	movl	$0x71, %eax
     90a:      	movq	(%rsp), %rdx
     90e:      	addq	$0x78, %rdx
     912:      	jmp	0x95d <event_wake_up_new_task+0x95d>
     914:      	cmpl	$0xb, %r15d
     918:      	ja	0x964 <event_wake_up_new_task+0x964>
     91a:      	movl	%r15d, %edx
     91d:      	leaq	(%rcx,%rdx,8), %rcx
     921:      	leaq	0x10(%rsp), %rdi
     926:      	movl	$0x8, %esi
     92b:      	movl	$0x71, %eax
     930:      	shlq	$0x3, %rdx
     934:      	addq	(%rsp), %rdx
     938:      	movl	$0x8, %esi
     93d:      	callq	*%rax
     93f:      	movq	0x10(%rsp), %rcx
     944:      	testq	%rcx, %rcx
     947:      	je	0x964 <event_wake_up_new_task+0x964>
     949:      	leaq	0x8(%rsp), %rdi
     94e:      	movl	$0x8, %edx
     953:      	movl	$0x71, %eax
     958:      	movq	0x10(%rsp), %rdx
     95d:      	movl	$0x8, %esi
     962:      	callq	*%rax
     964:      	movq	0x8(%rsp), %r14
     969:      	testq	%r14, %r14
     96c:      	je	0xab7 <event_wake_up_new_task+0xab7>
     972:      	cmpq	$0x63677270, %rbx       # imm = 0x63677270
     979:      	jne	0x987 <event_wake_up_new_task+0x987>
     97b:      	movl	$0x50, %eax
     980:      	callq	*%rax
     982:      	jmp	0xa12 <event_wake_up_new_task+0xa12>
     987:      	movq	$0x0, 0x10(%rsp)
     990:      	leaq	0x100(%r14), %rdx
     997:      	leaq	0x10(%rsp), %rdi
     99c:      	movl	$0x8, %ecx
     9a1:      	movl	$0x71, %eax
     9a6:      	movl	$0x8, %esi
     9ab:      	callq	*%rax
     9ad:      	movq	0x10(%rsp), %rdx
     9b2:      	movq	$0x0, 0x10(%rsp)
     9bb:      	testq	%rdx, %rdx
     9be:      	je	0xa10 <event_wake_up_new_task+0xa10>
     9c0:      	addq	$0x60, %rdx
     9c4:      	leaq	0x10(%rsp), %rdi
     9c9:      	movl	$0x8, %ecx
     9ce:      	movl	$0x71, %eax
     9d3:      	movl	$0x8, %esi
     9d8:      	callq	*%rax
     9da:      	movq	0x10(%rsp), %rax
     9df:      	jmp	0xa12 <event_wake_up_new_task+0xa12>
     9e1:      	movl	$0x0, 0x80(%rsp)
     9ec:      	movq	(%rip), %rdi            # 0x9f3 <event_wake_up_new_task+0x9f3>
     9f3:      	leaq	0x80(%rsp), %rsi
     9fb:      	movl	$0x1, %eax
     a00:      	callq	*%rax
     a02:      	testq	%rax, %rax
     a05:      	jne	0x657 <event_wake_up_new_task+0x657>
     a0b:      	jmp	0x65a <event_wake_up_new_task+0x65a>
     a10:      	xorl	%eax, %eax
     a12:      	movq	%rax, 0x80(%rsp)
     a1a:      	testq	%rax, %rax
     a1d:      	je	0xa4b <event_wake_up_new_task+0xa4b>
     a1f:      	movq	%rax, 0x10(%rsp)
     a24:      	movq	(%rip), %rdi            # 0xa2b <event_wake_up_new_task+0xa2b>
     a2b:      	leaq	0x10(%rsp), %rsi
     a30:      	movl	$0x1, %eax
     a35:      	callq	*%rax
     a37:      	testq	%rax, %rax
     a3a:      	je	0xa41 <event_wake_up_new_task+0xa41>
     a3c:      	movq	(%rax), %rax
     a3f:      	jmp	0xa43 <event_wake_up_new_task+0xa43>
     a41:      	xorl	%eax, %eax
     a43:      	movq	%rax, 0x88(%rsp)
     a4b:      	addq	$0x100, %r14            # imm = 0x100
     a52:      	movq	%rsp, %rdi
     a55:      	movl	$0x8, %ecx
     a5a:      	movl	$0x4, %eax
     a5f:      	movl	$0x8, %esi
     a64:      	movq	%r14, %rdx
     a67:      	callq	*%rax
     a69:      	movq	(%rsp), %rcx
     a6d:      	addq	$0x10, %rcx
     a71:      	leaq	0x10(%rsp), %rdi
     a76:      	movl	$0x8, %edx
     a7b:      	movl	$0x4, %eax
     a80:      	movq	(%rsp), %rdx
     a84:      	addq	$0x10, %rdx
     a88:      	movl	$0x8, %esi
     a8d:      	callq	*%rax
     a8f:      	testq	%rax, %rax
     a92:      	jne	0xab7 <event_wake_up_new_task+0xab7>
     a94:      	movq	0x10(%rsp), %rdx
     a99:      	testq	%rdx, %rdx
     a9c:      	je	0xab7 <event_wake_up_new_task+0xab7>
     a9e:      	leaq	0x90(%rsp), %rdi
     aa6:      	movl	$0x80, %ecx
     aab:      	movl	$0x2d, %eax
     ab0:      	movl	$0x80, %esi
     ab5:      	callq	*%rax
     ab7:      	movq	0x70(%rsp), %r15
     abc:      	movq	0x80(%rsp), %rax
     ac4:      	movq	%rax, (%rsp)
     ac8:      	movl	$0x0, 0x78(%rsp)
     ad0:      	movq	(%rip), %rdi            # 0xad7 <event_wake_up_new_task+0xad7>
     ad7:      	leaq	0x78(%rsp), %rsi
     adc:      	movl	$0x1, %eax
     ae1:      	callq	*%rax
     ae3:      	testq	%rax, %rax
     ae6:      	je	0xdea <event_wake_up_new_task+0xdea>
     aec:      	movq	0x8(%rax), %rbx
     af0:      	testq	%rbx, %rbx
     af3:      	je	0xdea <event_wake_up_new_task+0xdea>
     af9:      	movq	%rax, %r12
     afc:      	movq	(%rip), %rdi            # 0xb03 <event_wake_up_new_task+0xb03>
     b03:      	movq	%rsp, %rsi
     b06:      	movl	$0x1, %eax
     b0b:      	callq	*%rax
     b0d:      	testq	%rax, %rax
     b10:      	je	0xb4a <event_wake_up_new_task+0xb4a>
     b12:      	movq	%rax, %r14
     b15:      	movq	0x10(%rax), %rsi
     b19:      	movq	%r15, %rax
     b1c:      	subq	%rsi, %rax
     b1f:      	cmpq	%rbx, %rax
     b22:      	jbe	0xb72 <event_wake_up_new_task+0xb72>
     b24:      	leaq	(%rbx,%rbx), %rcx
     b28:      	cmpq	%rcx, %rax
     b2b:      	jbe	0xb7b <event_wake_up_new_task+0xb7b>
     b2d:      	movq	%r15, %rax
     b30:      	orq	%rbx, %rax
     b33:      	shrq	$0x20, %rax
     b37:      	je	0xbc3 <event_wake_up_new_task+0xbc3>
     b3d:      	movq	%r15, %rax
     b40:      	xorl	%edx, %edx
     b42:      	divq	%rbx
     b45:      	jmp	0xbca <event_wake_up_new_task+0xbca>
     b4a:      	movq	$0x1, 0x10(%rsp)
     b53:      	movq	$0x0, 0x18(%rsp)
     b5c:      	movq	%r15, %rax
     b5f:      	orq	%rbx, %rax
     b62:      	shrq	$0x20, %rax
     b66:      	je	0xb83 <event_wake_up_new_task+0xb83>
     b68:      	movq	%r15, %rax
     b6b:      	xorl	%edx, %edx
     b6d:      	divq	%rbx
     b70:      	jmp	0xb8a <event_wake_up_new_task+0xb8a>
     b72:      	movq	(%r14), %rcx
     b75:      	movq	0x8(%r14), %rdx
     b79:      	jmp	0xbdc <event_wake_up_new_task+0xbdc>
     b7b:      	movq	(%r14), %rdx
     b7e:      	addq	%rbx, %rsi
     b81:      	jmp	0xbd2 <event_wake_up_new_task+0xbd2>
     b83:      	movl	%r15d, %eax
     b86:      	xorl	%edx, %edx
     b88:      	divl	%ebx
     b8a:      	subq	%rdx, %r15
     b8d:      	movq	%r15, 0x20(%rsp)
     b92:      	movq	$0x0, 0x28(%rsp)
     b9b:      	movq	$0x0, 0x30(%rsp)
     ba4:      	movq	(%rip), %rdi            # 0xbab <event_wake_up_new_task+0xbab>
     bab:      	xorl	%ecx, %ecx
     bad:      	movq	%rsp, %rsi
     bb0:      	leaq	0x10(%rsp), %rdx
     bb5:      	movl	$0x2, %eax
     bba:      	xorl	%ecx, %ecx
     bbc:      	callq	*%rax
     bbe:      	jmp	0xdea <event_wake_up_new_task+0xdea>
     bc3:      	movl	%r15d, %eax
     bc6:      	xorl	%edx, %edx
     bc8:      	divl	%ebx
     bca:      	movq	%r15, %rsi
     bcd:      	subq	%rdx, %rsi
     bd0:      	xorl	%edx, %edx
     bd2:      	movq	%rdx, 0x8(%r14)
     bd6:      	movq	%rsi, 0x10(%r14)
     bda:      	xorl	%ecx, %ecx
     bdc:      	incq	%rcx
     bdf:      	movq	%rcx, (%r14)
     be2:      	movq	%rbx, %rax
     be5:      	subq	%r15, %rax
     be8:      	addq	%rsi, %rax
     beb:      	imulq	%rdx, %rax
     bef:      	movq	%rax, %rdx
     bf2:      	orq	%rbx, %rdx
     bf5:      	shrq	$0x20, %rdx
     bf9:      	je	0xc02 <event_wake_up_new_task+0xc02>
     bfb:      	xorl	%edx, %edx
     bfd:      	divq	%rbx
     c00:      	jmp	0xc06 <event_wake_up_new_task+0xc06>
     c02:      	xorl	%edx, %edx
     c04:      	divl	%ebx
     c06:      	addq	%rcx, %rax
     c09:      	movq	%rax, 0x18(%r14)
     c0d:      	cmpq	$0x0, 0x20(%r14)
     c12:      	jne	0xf42 <event_wake_up_new_task+0xf42>
     c18:      	cmpq	(%r12), %rax
     c1c:      	jb	0xdea <event_wake_up_new_task+0xdea>
     c22:      	movq	%r15, 0x20(%r14)
     c26:      	movl	$0x0, 0x3c(%rsp)
     c2e:      	movq	(%rip), %rdi            # 0xc35 <event_wake_up_new_task+0xc35>
     c35:      	leaq	0x3c(%rsp), %rcx
     c3a:      	movl	$0x1, %eax
     c3f:      	movl	$0x0, 0x7c(%rsp)
     c47:      	leaq	0x7c(%rsp), %rsi
     c4c:      	callq	*%rax
     c4e:      	testq	%rax, %rax
     c51:      	je	0xddf <event_wake_up_new_task+0xddf>
     c57:      	movq	%rax, %r12
     c5a:      	movl	$0xa0, 0x4(%rax)
     c61:      	movq	%r15, 0x8(%rax)
     c65:      	movw	$0x1b, (%rax)
     c6a:      	movq	%rax, %rdi
     c6d:      	addq	$0x10, %rdi
     c71:      	leaq	0x80(%rsp), %rsi
     c79:      	movl	$0x90, %edx
     c7e:      	callq	0xc83 <event_wake_up_new_task+0xc83>
     c83:      	movl	$0x0, 0x8(%rsp)
     c8b:      	movq	(%rip), %rdi            # 0xc92 <event_wake_up_new_task+0xc92>
     c92:      	leaq	0x8(%rsp), %rsi
     c97:      	movl	$0x1, %eax
     c9c:      	callq	*%rax
     c9e:      	testq	%rax, %rax
     ca1:      	je	0xd2b <event_wake_up_new_task+0xd2b>
     ca7:      	cmpb	$0x0, 0x28(%rax)
     cab:      	je	0xd2b <event_wake_up_new_task+0xd2b>
     cad:      	movq	(%rip), %rsi            # 0xcb4 <event_wake_up_new_task+0xcb4>
     cb4:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     cb9:      	movl	$0xa0, %edx
     cbe:      	movl	$0x19, %eax
     cc3:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     cc8:      	movl	$0xa0, %r8d
     cce:      	movq	%r13, %rdi
     cd1:      	movq	%r12, %rcx
     cd4:      	callq	*%rax
     cd6:      	testq	%rax, %rax
     cd9:      	jns	0xddf <event_wake_up_new_task+0xddf>
     cdf:      	movq	%rax, %r15
     ce2:      	movl	$0x0, 0x10(%rsp)
     cea:      	movq	(%rip), %rdi            # 0xcf1 <event_wake_up_new_task+0xcf1>
     cf1:      	leaq	0x10(%rsp), %rsi
     cf6:      	movl	$0x1, %eax
     cfb:      	callq	*%rax
     cfd:      	testq	%rax, %rax
     d00:      	je	0xddf <event_wake_up_new_task+0xddf>
     d06:      	cmpq	$-0xc, %r15
     d0a:      	jg	0xdab <event_wake_up_new_task+0xdab>
     d10:      	cmpq	$-0x1c, %r15
     d14:      	je	0xdc5 <event_wake_up_new_task+0xdc5>
     d1a:      	cmpq	$-0x16, %r15
     d1e:      	jne	0xd83 <event_wake_up_new_task+0xd83>
     d20:      	addq	$0x608, %rax            # imm = 0x608
     d26:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     d2b:      	movq	(%rip), %rdi            # 0xd32 <event_wake_up_new_task+0xd32>
     d32:      	xorl	%ecx, %ecx
     d34:      	movl	$0xa0, %edx
     d39:      	movl	$0x82, %eax
     d3e:      	movq	%r12, %rsi
     d41:      	xorl	%ecx, %ecx
     d43:      	callq	*%rax
     d45:      	testq	%rax, %rax
     d48:      	jns	0xddf <event_wake_up_new_task+0xddf>
     d4e:      	movq	%rax, %r15
     d51:      	movl	$0x0, 0x10(%rsp)
     d59:      	movq	(%rip), %rdi            # 0xd60 <event_wake_up_new_task+0xd60>
     d60:      	leaq	0x10(%rsp), %rsi
     d65:      	movl	$0x1, %eax
     d6a:      	callq	*%rax
     d6c:      	testq	%rax, %rax
     d6f:      	je	0xddf <event_wake_up_new_task+0xddf>
     d71:      	cmpq	$-0xc, %r15
     d75:      	jg	0xd91 <event_wake_up_new_task+0xd91>
     d77:      	cmpq	$-0x1c, %r15
     d7b:      	je	0xdc5 <event_wake_up_new_task+0xdc5>
     d7d:      	cmpq	$-0x16, %r15
     d81:      	je	0xd20 <event_wake_up_new_task+0xd20>
     d83:      	cmpq	$-0x10, %r15
     d87:      	jne	0xdbd <event_wake_up_new_task+0xdbd>
     d89:      	addq	$0x600, %rax            # imm = 0x600
     d8f:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     d91:      	cmpq	$-0xb, %r15
     d95:      	je	0xdcd <event_wake_up_new_task+0xdcd>
     d97:      	cmpq	$-0x7, %r15
     d9b:      	je	0xdd5 <event_wake_up_new_task+0xdd5>
     d9d:      	cmpq	$-0x2, %r15
     da1:      	jne	0xdbd <event_wake_up_new_task+0xdbd>
     da3:      	addq	$0x5f0, %rax            # imm = 0x5F0
     da9:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dab:      	cmpq	$-0xb, %r15
     daf:      	je	0xdcd <event_wake_up_new_task+0xdcd>
     db1:      	cmpq	$-0x7, %r15
     db5:      	je	0xdd5 <event_wake_up_new_task+0xdd5>
     db7:      	cmpq	$-0x2, %r15
     dbb:      	je	0xda3 <event_wake_up_new_task+0xda3>
     dbd:      	addq	$0x5e8, %rax            # imm = 0x5E8
     dc3:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dc5:      	addq	$0x610, %rax            # imm = 0x610
     dcb:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dcd:      	addq	$0x618, %rax            # imm = 0x618
     dd3:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dd5:      	addq	$0x5f8, %rax            # imm = 0x5F8
     ddb:      	lock
     ddc:      	incq	(%rax)
     ddf:      	cmpq	$0x0, 0x20(%r14)
     de4:      	jne	0xf42 <event_wake_up_new_task+0xf42>
     dea:      	movl	$0x0, (%rsp)
     df1:      	movq	(%rip), %rdi            # 0xdf8 <event_wake_up_new_task+0xdf8>
     df8:      	movq	%rsp, %rsi
     dfb:      	movl	$0x1, %eax
     e00:      	callq	*%rax
     e02:      	testq	%rax, %rax
     e05:      	je	0xe8c <event_wake_up_new_task+0xe8c>
     e0b:      	cmpb	$0x0, 0x28(%rax)
     e0f:      	je	0xe8c <event_wake_up_new_task+0xe8c>
     e11:      	movq	(%rip), %rsi            # 0xe18 <event_wake_up_new_task+0xe18>
     e18:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     e1d:      	leaq	0x40(%rsp), %rcx
     e22:      	movl	$0x38, %edi
     e27:      	movl	$0x19, %eax
     e2c:      	movl	$0x38, %r8d
     e32:      	movq	%r13, %rdi
     e35:      	callq	*%rax
     e37:      	testq	%rax, %rax
     e3a:      	jns	0xf42 <event_wake_up_new_task+0xf42>
     e40:      	movq	%rax, %rbx
     e43:      	movl	$0x0, 0x10(%rsp)
     e4b:      	movq	(%rip), %rdi            # 0xe52 <event_wake_up_new_task+0xe52>
     e52:      	leaq	0x10(%rsp), %rsi
     e57:      	movl	$0x1, %eax
     e5c:      	callq	*%rax
     e5e:      	testq	%rax, %rax
     e61:      	je	0xf42 <event_wake_up_new_task+0xf42>
     e67:      	cmpq	$-0xc, %rbx
     e6b:      	jg	0xf0e <event_wake_up_new_task+0xf0e>
     e71:      	cmpq	$-0x1c, %rbx
     e75:      	je	0xf28 <event_wake_up_new_task+0xf28>
     e7b:      	cmpq	$-0x16, %rbx
     e7f:      	jne	0xee6 <event_wake_up_new_task+0xee6>
     e81:      	addq	$0x528, %rax            # imm = 0x528
     e87:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     e8c:      	movq	(%rip), %rdi            # 0xe93 <event_wake_up_new_task+0xe93>
     e93:      	xorl	%ecx, %ecx
     e95:      	leaq	0x40(%rsp), %rsi
     e9a:      	movl	$0x38, %edx
     e9f:      	movl	$0x82, %eax
     ea4:      	xorl	%ecx, %ecx
     ea6:      	callq	*%rax
     ea8:      	testq	%rax, %rax
     eab:      	jns	0xf42 <event_wake_up_new_task+0xf42>
     eb1:      	movq	%rax, %rbx
     eb4:      	movl	$0x0, 0x10(%rsp)
     ebc:      	movq	(%rip), %rdi            # 0xec3 <event_wake_up_new_task+0xec3>
     ec3:      	leaq	0x10(%rsp), %rsi
     ec8:      	movl	$0x1, %eax
     ecd:      	callq	*%rax
     ecf:      	testq	%rax, %rax
     ed2:      	je	0xf42 <event_wake_up_new_task+0xf42>
     ed4:      	cmpq	$-0xc, %rbx
     ed8:      	jg	0xef4 <event_wake_up_new_task+0xef4>
     eda:      	cmpq	$-0x1c, %rbx
     ede:      	je	0xf28 <event_wake_up_new_task+0xf28>
     ee0:      	cmpq	$-0x16, %rbx
     ee4:      	je	0xe81 <event_wake_up_new_task+0xe81>
     ee6:      	cmpq	$-0x10, %rbx
     eea:      	jne	0xf20 <event_wake_up_new_task+0xf20>
     eec:      	addq	$0x520, %rax            # imm = 0x520
     ef2:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     ef4:      	cmpq	$-0xb, %rbx
     ef8:      	je	0xf30 <event_wake_up_new_task+0xf30>
     efa:      	cmpq	$-0x7, %rbx
     efe:      	je	0xf38 <event_wake_up_new_task+0xf38>
     f00:      	cmpq	$-0x2, %rbx
     f04:      	jne	0xf20 <event_wake_up_new_task+0xf20>
     f06:      	addq	$0x510, %rax            # imm = 0x510
     f0c:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     f0e:      	cmpq	$-0xb, %rbx
     f12:      	je	0xf30 <event_wake_up_new_task+0xf30>
     f14:      	cmpq	$-0x7, %rbx
     f18:      	je	0xf38 <event_wake_up_new_task+0xf38>
     f1a:      	cmpq	$-0x2, %rbx
     f1e:      	je	0xf06 <event_wake_up_new_task+0xf06>
     f20:      	addq	$0x508, %rax            # imm = 0x508
     f26:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     f28:      	addq	$0x530, %rax            # imm = 0x530
     f2e:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     f30:      	addq	$0x538, %rax            # imm = 0x538
     f36:      	jmp	0xf3e <event_wake_up_new_task+0xf3e>
     f38:      	addq	$0x518, %rax            # imm = 0x518
     f3e:      	lock
     f3f:      	incq	(%rax)
     f42:      	xorl	%eax, %eax
     f44:      	addq	$0x118, %rsp            # imm = 0x118
     f4b:      	popq	%rbx
     f4c:      	popq	%r12
     f4e:      	popq	%r13
     f50:      	popq	%r14
     f52:      	popq	%r15
     f54:      	popq	%rbp
     f55:      	retq
