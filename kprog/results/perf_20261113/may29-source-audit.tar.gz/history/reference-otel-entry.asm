
/workspaces/kprog-raw/kprog-r-art/art/native-bpf/x86_64/otelcol-ebpf-profiler/otelcol-ebpf-profiler.native.o:	file format elf64-x86-64

Disassembly of section perf_event/native_tracer_entry:

0000000000000000 <native_tracer_entry>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r13
      1e:      	movq	%rax, %r12
      21:      	shrq	$0x20, %r12
      25:      	je	0x19a <native_tracer_entry+0x19a>
      2b:      	movl	$0x5, %eax
      30:      	callq	*%rax
      32:      	movq	%rax, %rbp
      35:      	movq	(%rip), %rax            # 0x3c <native_tracer_entry+0x3c>
      3c:      	cmpl	$0x0, (%rax)
      3f:      	jne	0xa38 <native_tracer_entry+0xa38>
      45:      	movl	$0x0, 0x10(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <native_tracer_entry+0x54>
      54:      	leaq	0x10(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
      66:      	testq	%rax, %rax
      69:      	je	0xc49 <native_tracer_entry+0xc49>
      6f:      	movq	%rax, %r15
      72:      	movq	$0x0, 0xf00(%rax)
      7d:      	movb	$0x0, 0xf30(%rax)
      84:      	movq	$0x0, 0xed0(%rax)
      8f:      	movq	$0x0, 0xed8(%rax)
      9a:      	movq	$0x0, 0xee0(%rax)
      a5:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      aa:      	movq	%rax, 0xf28(%r15)
      b1:      	movl	$0x0, 0x1380(%r15)
      bc:      	movw	$0x100, 0x1384(%r15)    # imm = 0x100
      c6:      	movq	$0x0, 0xf38(%r15)
      d1:      	movq	$0x0, 0xf40(%r15)
      dc:      	movq	$0x0, 0xf58(%r15)
      e7:      	movq	$0x0, 0xf60(%r15)
      f2:      	movq	$0x0, 0xf68(%r15)
      fd:      	movq	$0x0, 0xf70(%r15)
     108:      	movq	$0x0, 0xf78(%r15)
     113:      	movq	%rax, 0x2bc(%r15)
     11a:      	leaq	0x20(%r15), %rdi
     11e:      	movl	$0x29c, %edx            # imm = 0x29C
     123:      	xorl	%esi, %esi
     125:      	callq	0x12a <native_tracer_entry+0x12a>
     12a:      	movl	$0x1, 0x2c4(%r15)
     135:      	movl	%r12d, (%r15)
     138:      	movl	%r13d, 0x4(%r15)
     13c:      	movq	%rbp, 0x8(%r15)
     140:      	movq	$0x0, 0x2c8(%r15)
     14b:      	leaq	0x10(%r15), %rdi
     14f:      	movl	$0x10, %eax
     154:      	movl	$0x10, %ecx
     159:      	movl	$0x10, %esi
     15e:      	callq	*%rcx
     160:      	testl	%eax, %eax
     162:      	jns	0x32f <native_tracer_entry+0x32f>
     168:      	movl	$0x34, 0xd0(%rsp)
     173:      	movq	(%rip), %rdi            # 0x17a <native_tracer_entry+0x17a>
     17a:      	leaq	0xd0(%rsp), %rsi
     182:      	movl	$0x1, %eax
     187:      	callq	*%rax
     189:      	testq	%rax, %rax
     18c:      	je	0x31f <native_tracer_entry+0x31f>
     192:      	incq	(%rax)
     195:      	jmp	0x32f <native_tracer_entry+0x32f>
     19a:      	movq	(%rip), %rax            # 0x1a1 <native_tracer_entry+0x1a1>
     1a1:      	xorl	%r14d, %r14d
     1a4:      	cmpb	$0x0, (%rax)
     1a7:      	jne	0xc49 <native_tracer_entry+0xc49>
     1ad:      	movl	$0x5, %eax
     1b2:      	callq	*%rax
     1b4:      	movq	%rax, %r15
     1b7:      	movq	(%rip), %r12            # 0x1be <native_tracer_entry+0x1be>
     1be:      	cmpl	$0x0, (%r12)
     1c3:      	jne	0xe0e <native_tracer_entry+0xe0e>
     1c9:      	movl	$0x0, 0x10(%rsp)
     1d1:      	movq	(%rip), %rdi            # 0x1d8 <native_tracer_entry+0x1d8>
     1d8:      	leaq	0x10(%rsp), %rsi
     1dd:      	movl	$0x1, %eax
     1e2:      	callq	*%rax
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x480 <native_tracer_entry+0x480>
     1ed:      	movq	%rax, %r14
     1f0:      	movq	$0x0, 0xf00(%rax)
     1fb:      	movb	$0x0, 0xf30(%rax)
     202:      	movq	$0x0, 0xed0(%rax)
     20d:      	movq	$0x0, 0xed8(%rax)
     218:      	movq	$0x0, 0xee0(%rax)
     223:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     228:      	movq	%rax, 0xf28(%r14)
     22f:      	movl	$0x0, 0x1380(%r14)
     23a:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     244:      	movq	$0x0, 0xf38(%r14)
     24f:      	movq	$0x0, 0xf40(%r14)
     25a:      	movq	$0x0, 0xf58(%r14)
     265:      	movq	$0x0, 0xf60(%r14)
     270:      	movq	$0x0, 0xf68(%r14)
     27b:      	movq	$0x0, 0xf70(%r14)
     286:      	movq	$0x0, 0xf78(%r14)
     291:      	movq	%rax, 0x2bc(%r14)
     298:      	leaq	0x20(%r14), %rdi
     29c:      	movl	$0x29c, %edx            # imm = 0x29C
     2a1:      	xorl	%esi, %esi
     2a3:      	callq	0x2a8 <native_tracer_entry+0x2a8>
     2a8:      	movl	$0x1, 0x2c4(%r14)
     2b3:      	movl	$0x0, (%r14)
     2ba:      	movl	%r13d, 0x4(%r14)
     2be:      	movq	%r15, 0x8(%r14)
     2c2:      	movq	$0x0, 0x2c8(%r14)
     2cd:      	movq	%r14, %rdi
     2d0:      	addq	$0x10, %rdi
     2d4:      	movl	$0x10, %eax
     2d9:      	movl	$0x10, %ecx
     2de:      	movl	$0x10, %esi
     2e3:      	callq	*%rcx
     2e5:      	testl	%eax, %eax
     2e7:      	jns	0x64d <native_tracer_entry+0x64d>
     2ed:      	movl	$0x34, 0xd0(%rsp)
     2f8:      	movq	(%rip), %rdi            # 0x2ff <native_tracer_entry+0x2ff>
     2ff:      	leaq	0xd0(%rsp), %rsi
     307:      	movl	$0x1, %eax
     30c:      	callq	*%rax
     30e:      	testq	%rax, %rax
     311:      	je	0x642 <native_tracer_entry+0x642>
     317:      	incq	(%rax)
     31a:      	jmp	0x64d <native_tracer_entry+0x64d>
     31f:      	movq	(%rip), %rax            # 0x326 <native_tracer_entry+0x326>
     326:      	cmpl	$0x0, (%rax)
     329:      	jne	0xf3c <native_tracer_entry+0xf3c>
     32f:      	movq	(%rip), %rsi            # 0x336 <native_tracer_entry+0x336>
     336:      	movl	$0x400, %eax            # imm = 0x400
     33b:      	movl	$0x1b, %ecx
     340:      	movl	$0x400, %edx            # imm = 0x400
     345:      	movq	%rbx, %rdi
     348:      	callq	*%rcx
     34a:      	movl	%eax, 0x2bc(%r15)
     351:      	movq	(%rip), %rax            # 0x358 <native_tracer_entry+0x358>
     358:      	cmpl	$0x0, (%rax)
     35b:      	jne	0xa82 <native_tracer_entry+0xa82>
     361:      	cmpq	$0x2b, 0xa0(%rbx)
     369:      	jne	0xadc <native_tracer_entry+0xadc>
     36f:      	cmpq	$0x23, 0x88(%rbx)
     377:      	jne	0x383 <native_tracer_entry+0x383>
     379:      	movl	$0xfb1, %ebp            # imm = 0xFB1
     37e:      	jmp	0xb79 <native_tracer_entry+0xb79>
     383:      	movq	0x80(%rbx), %rax
     38a:      	movq	%rax, 0xed0(%r15)
     391:      	movq	0x98(%rbx), %rax
     398:      	movq	%rax, 0xed8(%r15)
     39f:      	movq	0x20(%rbx), %rax
     3a3:      	movq	%rax, 0xee0(%r15)
     3aa:      	movq	0x50(%rbx), %rax
     3ae:      	movq	%rax, 0xee8(%r15)
     3b5:      	movq	0x40(%rbx), %rax
     3b9:      	movq	%rax, 0xef0(%r15)
     3c0:      	movq	0x30(%rbx), %rax
     3c4:      	movq	%rax, 0xef8(%r15)
     3cb:      	movq	0x10(%rbx), %rax
     3cf:      	movq	%rax, 0xf00(%r15)
     3d6:      	movq	(%rbx), %rax
     3d9:      	movq	%rax, 0xf08(%r15)
     3e0:      	movb	$0x0, 0xf30(%r15)
     3e8:      	movq	(%rip), %rax            # 0x3ef <native_tracer_entry+0x3ef>
     3ef:      	cmpl	$0x0, (%rax)
     3f2:      	jne	0xd03 <native_tracer_entry+0xd03>
     3f8:      	movl	$0x60, 0x10(%rsp)
     400:      	movbel	%r12d, 0x14(%rsp)
     407:      	movq	$0x0, 0x18(%rsp)
     410:      	movq	(%rip), %rdi            # 0x417 <native_tracer_entry+0x417>
     417:      	leaq	0x10(%rsp), %rsi
     41c:      	movl	$0x1, %eax
     421:      	callq	*%rax
     423:      	testq	%rax, %rax
     426:      	je	0x48b <native_tracer_entry+0x48b>
     428:      	movq	%r15, %rax
     42b:      	addq	$0xed0, %rax            # imm = 0xED0
     431:      	movq	(%rax), %r13
     434:      	movq	(%rip), %rax            # 0x43b <native_tracer_entry+0x43b>
     43b:      	movl	(%rax), %eax
     43d:      	testq	%r13, %r13
     440:      	je	0x554 <native_tracer_entry+0x554>
     446:      	testl	%eax, %eax
     448:      	jne	0xfba <native_tracer_entry+0xfba>
     44e:      	movq	%r13, %rax
     451:      	shrq	$0x38, %rax
     455:      	je	0x104c <native_tracer_entry+0x104c>
     45b:      	movq	(%rip), %rax            # 0x462 <native_tracer_entry+0x462>
     462:      	cmpl	$0x0, (%rax)
     465:      	jne	0x136f <native_tracer_entry+0x136f>
     46b:      	movl	$0xb, 0xf28(%r15)
     476:      	movl	$0xfab, %ebp            # imm = 0xFAB
     47b:      	jmp	0xb79 <native_tracer_entry+0xb79>
     480:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
     486:      	jmp	0xc49 <native_tracer_entry+0xc49>
     48b:      	movq	%r13, 0xc8(%rsp)
     493:      	movl	%r12d, 0x8(%rsp)
     498:      	movq	(%rip), %rdi            # 0x49f <native_tracer_entry+0x49f>
     49f:      	leaq	0x8(%rsp), %rsi
     4a4:      	movl	$0x1, %eax
     4a9:      	callq	*%rax
     4ab:      	movq	%rax, %r14
     4ae:      	movl	$0x5, %eax
     4b3:      	callq	*%rax
     4b5:      	testq	%r14, %r14
     4b8:      	je	0x571 <native_tracer_entry+0x571>
     4be:      	movq	(%r14), %rcx
     4c1:      	movq	%rcx, %rsi
     4c4:      	andq	$-0x20, %rsi
     4c8:      	movq	%rax, %rdx
     4cb:      	subq	%rsi, %rdx
     4ce:      	movl	%ecx, %esi
     4d0:      	andb	$0xf, %sil
     4d4:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     4d9:      	shlxq	%rsi, %rdi, %rsi
     4de:      	cmpq	%rsi, %rdx
     4e1:      	jae	0x575 <native_tracer_entry+0x575>
     4e7:      	movq	(%rip), %rax            # 0x4ee <native_tracer_entry+0x4ee>
     4ee:      	cmpl	$0x0, (%rax)
     4f1:      	je	0xa30 <native_tracer_entry+0xa30>
     4f7:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     501:      	movq	%rax, 0x28(%rsp)
     506:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     510:      	movq	%rax, 0x20(%rsp)
     515:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     51f:      	movq	%rax, 0x18(%rsp)
     524:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     52e:      	movq	%rax, 0x10(%rsp)
     533:      	leaq	0x10(%rsp), %rdi
     538:      	movl	$0x20, %eax
     53d:      	movl	$0x6, %ecx
     542:      	movl	0x8(%rsp), %edx
     546:      	movl	$0x20, %esi
     54b:      	xorl	%eax, %eax
     54d:      	callq	*%rcx
     54f:      	jmp	0xa30 <native_tracer_entry+0xa30>
     554:      	testl	%eax, %eax
     556:      	jne	0x12f3 <native_tracer_entry+0x12f3>
     55c:      	movl	$0x1, 0xf28(%r15)
     567:      	movl	$0xfad, %ebp            # imm = 0xFAD
     56c:      	jmp	0xb79 <native_tracer_entry+0xb79>
     571:      	xorl	%ebp, %ebp
     573:      	jmp	0x5a8 <native_tracer_entry+0x5a8>
     575:      	movl	%ecx, %ebp
     577:      	andb	$0x10, %bpl
     57b:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     580:      	addq	%rdi, %rsi
     583:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     58a:      	cmpq	%rsi, %rdx
     58d:      	jae	0x5a8 <native_tracer_entry+0x5a8>
     58f:      	andl	$0xf, %ecx
     592:      	xorl	%edx, %edx
     594:      	testb	%bpl, %bpl
     597:      	sete	%dl
     59a:      	leal	0x4(,%rdx,4), %edx
     5a1:      	cmpl	%edx, %ecx
     5a3:      	adcb	$0x0, %cl
     5a6:      	jmp	0x5aa <native_tracer_entry+0x5aa>
     5a8:      	xorl	%ecx, %ecx
     5aa:      	movq	(%rip), %rdx            # 0x5b1 <native_tracer_entry+0x5b1>
     5b1:      	cmpl	$0x0, (%rdx)
     5b4:      	movzbl	%cl, %r14d
     5b8:      	jne	0x128b <native_tracer_entry+0x128b>
     5be:      	andq	$-0x20, %rax
     5c2:      	movzbl	%bpl, %ecx
     5c6:      	orq	%rax, %rcx
     5c9:      	orq	%rcx, %r14
     5cc:      	movq	%r14, 0xd0(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <native_tracer_entry+0x5db>
     5db:      	xorl	%eax, %eax
     5dd:      	leaq	0x8(%rsp), %rsi
     5e2:      	leaq	0xd0(%rsp), %rdx
     5ea:      	movl	$0x2, %r8d
     5f0:      	xorl	%ecx, %ecx
     5f2:      	callq	*%r8
     5f5:      	testl	%eax, %eax
     5f7:      	je	0x6fd <native_tracer_entry+0x6fd>
     5fd:      	movq	(%rip), %rcx            # 0x604 <native_tracer_entry+0x604>
     604:      	cmpl	$0x0, (%rcx)
     607:      	jne	0x13d2 <native_tracer_entry+0x13d2>
     60d:      	movl	$0x3d, 0xc4(%rsp)
     618:      	movq	(%rip), %rdi            # 0x61f <native_tracer_entry+0x61f>
     61f:      	leaq	0xc4(%rsp), %rsi
     627:      	movl	$0x1, %eax
     62c:      	callq	*%rax
     62e:      	testq	%rax, %rax
     631:      	je	0x7a6 <native_tracer_entry+0x7a6>
     637:      	incq	(%rax)
     63a:      	xorl	%r14d, %r14d
     63d:      	jmp	0xc49 <native_tracer_entry+0xc49>
     642:      	cmpl	$0x0, (%r12)
     647:      	jne	0x1433 <native_tracer_entry+0x1433>
     64d:      	movq	(%rip), %rsi            # 0x654 <native_tracer_entry+0x654>
     654:      	movl	$0x400, %eax            # imm = 0x400
     659:      	movl	$0x1b, %ecx
     65e:      	movl	$0x400, %edx            # imm = 0x400
     663:      	movq	%rbx, %rdi
     666:      	callq	*%rcx
     668:      	movl	%eax, 0x2bc(%r14)
     66f:      	cmpl	$0x0, (%r12)
     674:      	jne	0xe58 <native_tracer_entry+0xe58>
     67a:      	movl	$0x0, 0x10(%rsp)
     682:      	movq	(%rip), %rdi            # 0x689 <native_tracer_entry+0x689>
     689:      	leaq	0x10(%rsp), %rsi
     68e:      	movl	$0x1, %eax
     693:      	callq	*%rax
     695:      	testq	%rax, %rax
     698:      	je	0x6e9 <native_tracer_entry+0x6e9>
     69a:      	movzbl	0x1384(%rax), %ecx
     6a1:      	cmpb	$0x1d, %cl
     6a4:      	jb	0x783 <native_tracer_entry+0x783>
     6aa:      	movq	%rax, %r14
     6ad:      	movl	$0x5, 0xf2c(%rax)
     6b7:      	movl	$0x44, 0xd0(%rsp)
     6c2:      	movq	(%rip), %rdi            # 0x6c9 <native_tracer_entry+0x6c9>
     6c9:      	leaq	0xd0(%rsp), %rsi
     6d1:      	movl	$0x1, %eax
     6d6:      	callq	*%rax
     6d8:      	testq	%rax, %rax
     6db:      	je	0x76d <native_tracer_entry+0x76d>
     6e1:      	incq	(%rax)
     6e4:      	jmp	0x778 <native_tracer_entry+0x778>
     6e9:      	movq	(%rip), %rsi            # 0x6f0 <native_tracer_entry+0x6f0>
     6f0:      	xorl	%r14d, %r14d
     6f3:      	movl	$0xc, %eax
     6f8:      	jmp	0x79a <native_tracer_entry+0x79a>
     6fd:      	movb	$0x1, 0xf(%rsp)
     702:      	movq	(%rip), %rdi            # 0x709 <native_tracer_entry+0x709>
     709:      	xorl	%eax, %eax
     70b:      	leaq	0xc8(%rsp), %rsi
     713:      	leaq	0xf(%rsp), %rdx
     718:      	movl	$0x2, %r8d
     71e:      	xorl	%ecx, %ecx
     720:      	callq	*%r8
     723:      	testl	%eax, %eax
     725:      	je	0x834 <native_tracer_entry+0x834>
     72b:      	movq	(%rip), %rcx            # 0x732 <native_tracer_entry+0x732>
     732:      	cmpl	$0x0, (%rcx)
     735:      	jne	0x16a0 <native_tracer_entry+0x16a0>
     73b:      	movl	$0x3e, 0xd0(%rsp)
     746:      	movq	(%rip), %rdi            # 0x74d <native_tracer_entry+0x74d>
     74d:      	leaq	0xd0(%rsp), %rsi
     755:      	movl	$0x1, %eax
     75a:      	callq	*%rax
     75c:      	testq	%rax, %rax
     75f:      	je	0x8a5 <native_tracer_entry+0x8a5>
     765:      	incq	(%rax)
     768:      	jmp	0xa30 <native_tracer_entry+0xa30>
     76d:      	cmpl	$0x0, (%r12)
     772:      	jne	0x150d <native_tracer_entry+0x150d>
     778:      	movq	%r14, %rax
     77b:      	movzbl	0x1384(%r14), %ecx
     783:      	incb	%cl
     785:      	movb	%cl, 0x1384(%rax)
     78b:      	movq	(%rip), %rsi            # 0x792 <native_tracer_entry+0x792>
     792:      	xorl	%r14d, %r14d
     795:      	movl	$0xc, %eax
     79a:      	movq	%rbx, %rdi
     79d:      	xorl	%edx, %edx
     79f:      	callq	*%rax
     7a1:      	jmp	0xc49 <native_tracer_entry+0xc49>
     7a6:      	movq	(%rip), %rax            # 0x7ad <native_tracer_entry+0x7ad>
     7ad:      	cmpl	$0x0, (%rax)
     7b0:      	je	0xa30 <native_tracer_entry+0xa30>
     7b6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     7c0:      	movq	%rax, 0x36(%rsp)
     7c5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     7cf:      	movq	%rax, 0x30(%rsp)
     7d4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     7de:      	movq	%rax, 0x28(%rsp)
     7e3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     7ed:      	movq	%rax, 0x20(%rsp)
     7f2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     7fc:      	movq	%rax, 0x18(%rsp)
     801:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     80b:      	movq	%rax, 0x10(%rsp)
     810:      	leaq	0x10(%rsp), %rdi
     815:      	movl	$0x2e, %eax
     81a:      	movl	$0x6, %ecx
     81f:      	movl	0xc4(%rsp), %edx
     826:      	movl	$0x2e, %esi
     82b:      	xorl	%eax, %eax
     82d:      	callq	*%rcx
     82f:      	jmp	0xa30 <native_tracer_entry+0xa30>
     834:      	movl	$0x1, 0xc4(%rsp)
     83f:      	movb	$0x1, 0x8(%rsp)
     844:      	movq	(%rip), %rdi            # 0x84b <native_tracer_entry+0x84b>
     84b:      	leaq	0xc4(%rsp), %rsi
     853:      	leaq	0x8(%rsp), %rdx
     858:      	movl	$0x1, %eax
     85d:      	movl	$0x2, %r8d
     863:      	movl	$0x1, %ecx
     868:      	callq	*%r8
     86b:      	testl	%eax, %eax
     86d:      	js	0x936 <native_tracer_entry+0x936>
     873:      	movl	$0x42, 0xd0(%rsp)
     87e:      	movq	(%rip), %rdi            # 0x885 <native_tracer_entry+0x885>
     885:      	leaq	0xd0(%rsp), %rsi
     88d:      	movl	$0x1, %eax
     892:      	callq	*%rax
     894:      	testq	%rax, %rax
     897:      	je	0x997 <native_tracer_entry+0x997>
     89d:      	incq	(%rax)
     8a0:      	jmp	0x9a7 <native_tracer_entry+0x9a7>
     8a5:      	movq	(%rip), %rax            # 0x8ac <native_tracer_entry+0x8ac>
     8ac:      	cmpl	$0x0, (%rax)
     8af:      	je	0xa30 <native_tracer_entry+0xa30>
     8b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     8bf:      	movq	%rax, 0x36(%rsp)
     8c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     8ce:      	movq	%rax, 0x30(%rsp)
     8d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     8dd:      	movq	%rax, 0x28(%rsp)
     8e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     8ec:      	movq	%rax, 0x20(%rsp)
     8f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     8fb:      	movq	%rax, 0x18(%rsp)
     900:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     90a:      	movq	%rax, 0x10(%rsp)
     90f:      	leaq	0x10(%rsp), %rdi
     914:      	movl	$0x2e, %eax
     919:      	movl	$0x6, %ecx
     91e:      	movl	0xd0(%rsp), %edx
     925:      	movl	$0x2e, %esi
     92a:      	xorl	%eax, %eax
     92c:      	callq	*%rcx
     92e:      	xorl	%r14d, %r14d
     931:      	jmp	0xc49 <native_tracer_entry+0xc49>
     936:      	movq	(%rip), %rax            # 0x93d <native_tracer_entry+0x93d>
     93d:      	cmpl	$0x0, (%rax)
     940:      	je	0x9f6 <native_tracer_entry+0x9f6>
     946:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     950:      	movq	%rax, 0x20(%rsp)
     955:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     95f:      	movq	%rax, 0x18(%rsp)
     964:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     96e:      	movq	%rax, 0x10(%rsp)
     973:      	movb	$0x0, 0x28(%rsp)
     978:      	leaq	0x10(%rsp), %rdi
     97d:      	movl	$0x19, %eax
     982:      	movl	$0x6, %ecx
     987:      	movl	$0x19, %esi
     98c:      	movl	$0x1, %edx
     991:      	xorl	%eax, %eax
     993:      	callq	*%rcx
     995:      	jmp	0x9f6 <native_tracer_entry+0x9f6>
     997:      	movq	(%rip), %rax            # 0x99e <native_tracer_entry+0x99e>
     99e:      	cmpl	$0x0, (%rax)
     9a1:      	jne	0x18d0 <native_tracer_entry+0x18d0>
     9a7:      	movl	$0x1, 0xd0(%rsp)
     9b2:      	movq	(%rip), %rsi            # 0x9b9 <native_tracer_entry+0x9b9>
     9b9:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     9be:      	leaq	0xd0(%rsp), %rcx
     9c6:      	movl	$0x4, %edx
     9cb:      	movl	$0x19, %r9d
     9d1:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     9d6:      	movq	%rbx, %rdi
     9d9:      	movl	$0x4, %r8d
     9df:      	callq	*%r9
     9e2:      	testl	%eax, %eax
     9e4:      	jns	0x9f6 <native_tracer_entry+0x9f6>
     9e6:      	movq	(%rip), %rcx            # 0x9ed <native_tracer_entry+0x9ed>
     9ed:      	cmpl	$0x0, (%rcx)
     9f0:      	jne	0x1841 <native_tracer_entry+0x1841>
     9f6:      	movl	$0x3f, 0xd0(%rsp)
     a01:      	movq	(%rip), %rdi            # 0xa08 <native_tracer_entry+0xa08>
     a08:      	leaq	0xd0(%rsp), %rsi
     a10:      	movl	$0x1, %eax
     a15:      	callq	*%rax
     a17:      	testq	%rax, %rax
     a1a:      	jne	0x637 <native_tracer_entry+0x637>
     a20:      	movq	(%rip), %rax            # 0xa27 <native_tracer_entry+0xa27>
     a27:      	cmpl	$0x0, (%rax)
     a2a:      	jne	0x17c3 <native_tracer_entry+0x17c3>
     a30:      	xorl	%r14d, %r14d
     a33:      	jmp	0xc49 <native_tracer_entry+0xc49>
     a38:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     a42:      	movq	%rax, 0x1e(%rsp)
     a47:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     a51:      	movq	%rax, 0x18(%rsp)
     a56:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     a60:      	movq	%rax, 0x10(%rsp)
     a65:      	leaq	0x10(%rsp), %rdi
     a6a:      	movl	$0x16, %eax
     a6f:      	movl	$0x6, %ecx
     a74:      	movl	$0x16, %esi
     a79:      	xorl	%eax, %eax
     a7b:      	callq	*%rcx
     a7d:      	jmp	0x45 <native_tracer_entry+0x45>
     a82:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     a8c:      	movq	%rax, 0x1e(%rsp)
     a91:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     a9b:      	movq	%rax, 0x18(%rsp)
     aa0:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     aaa:      	movq	%rax, 0x10(%rsp)
     aaf:      	leaq	0x10(%rsp), %rdi
     ab4:      	movl	$0x16, %eax
     ab9:      	movl	$0x6, %ecx
     abe:      	movl	0x2bc(%r15), %edx
     ac5:      	movl	$0x16, %esi
     aca:      	xorl	%eax, %eax
     acc:      	callq	*%rcx
     ace:      	cmpq	$0x2b, 0xa0(%rbx)
     ad6:      	je	0x36f <native_tracer_entry+0x36f>
     adc:      	movl	$0x23, %eax
     ae1:      	callq	*%rax
     ae3:      	movq	(%rip), %rcx            # 0xaea <native_tracer_entry+0xaea>
     aea:      	movl	(%rcx), %edx
     aec:      	addq	%rax, %rdx
     aef:      	leaq	0x10(%rsp), %rdi
     af4:      	movl	$0x8, %eax
     af9:      	movl	$0x71, %ecx
     afe:      	movl	$0x8, %esi
     b03:      	callq	*%rcx
     b05:      	testq	%rax, %rax
     b08:      	jne	0xb39 <native_tracer_entry+0xb39>
     b0a:      	movq	(%rip), %rax            # 0xb11 <native_tracer_entry+0xb11>
     b11:      	movl	(%rax), %edx
     b13:      	addq	0x10(%rsp), %rdx
     b18:      	je	0xb39 <native_tracer_entry+0xb39>
     b1a:      	leaq	0x10(%rsp), %rdi
     b1f:      	movl	$0xa8, %eax
     b24:      	movl	$0x71, %ecx
     b29:      	movl	$0xa8, %esi
     b2e:      	callq	*%rcx
     b30:      	testq	%rax, %rax
     b33:      	je	0xc5e <native_tracer_entry+0xc5e>
     b39:      	movl	$0x52, 0xc8(%rsp)
     b44:      	movq	(%rip), %rdi            # 0xb4b <native_tracer_entry+0xb4b>
     b4b:      	leaq	0xc8(%rsp), %rsi
     b53:      	movl	$0x1, %eax
     b58:      	callq	*%rax
     b5a:      	testq	%rax, %rax
     b5d:      	je	0xb64 <native_tracer_entry+0xb64>
     b5f:      	incq	(%rax)
     b62:      	jmp	0xb74 <native_tracer_entry+0xb74>
     b64:      	movq	(%rip), %rax            # 0xb6b <native_tracer_entry+0xb6b>
     b6b:      	cmpl	$0x0, (%rax)
     b6e:      	jne	0xea9 <native_tracer_entry+0xea9>
     b74:      	movl	$0xfa9, %ebp            # imm = 0xFA9
     b79:      	xorl	%r12d, %r12d
     b7c:      	movl	%ebp, 0xf2c(%r15)
     b83:      	movl	$0x0, 0x10(%rsp)
     b8b:      	movq	(%rip), %rdi            # 0xb92 <native_tracer_entry+0xb92>
     b92:      	leaq	0x10(%rsp), %rsi
     b97:      	movl	$0x1, %eax
     b9c:      	callq	*%rax
     b9e:      	testq	%rax, %rax
     ba1:      	je	0xbea <native_tracer_entry+0xbea>
     ba3:      	movzbl	0x1384(%rax), %ecx
     baa:      	movl	%r12d, %edx
     bad:      	cmpb	$0x1d, %cl
     bb0:      	jb	0xc17 <native_tracer_entry+0xc17>
     bb2:      	movq	%rax, %r15
     bb5:      	movl	$0x5, 0xf2c(%rax)
     bbf:      	movl	$0x44, 0xd0(%rsp)
     bca:      	movq	(%rip), %rdi            # 0xbd1 <native_tracer_entry+0xbd1>
     bd1:      	leaq	0xd0(%rsp), %rsi
     bd9:      	movl	$0x1, %eax
     bde:      	callq	*%rax
     be0:      	testq	%rax, %rax
     be3:      	je	0xbfa <native_tracer_entry+0xbfa>
     be5:      	incq	(%rax)
     be8:      	jmp	0xc0a <native_tracer_entry+0xc0a>
     bea:      	movq	(%rip), %rcx            # 0xbf1 <native_tracer_entry+0xbf1>
     bf1:      	xorl	%edx, %edx
     bf3:      	movl	$0xc, %eax
     bf8:      	jmp	0xc2d <native_tracer_entry+0xc2d>
     bfa:      	movq	(%rip), %rax            # 0xc01 <native_tracer_entry+0xc01>
     c01:      	cmpl	$0x0, (%rax)
     c04:      	jne	0x120d <native_tracer_entry+0x120d>
     c0a:      	movq	%r15, %rax
     c0d:      	movzbl	0x1384(%r15), %ecx
     c15:      	xorl	%edx, %edx
     c17:      	incb	%cl
     c19:      	movb	%cl, 0x1384(%rax)
     c1f:      	movl	%edx, %ecx
     c21:      	movq	(%rip), %rsi            # 0xc28 <native_tracer_entry+0xc28>
     c28:      	movl	$0xc, %eax
     c2d:      	movq	(%rip), %rsi            # 0xc34 <native_tracer_entry+0xc34>
     c34:      	movq	%rbx, %rdi
     c37:      	callq	*%rax
     c39:      	movq	(%rip), %rax            # 0xc40 <native_tracer_entry+0xc40>
     c40:      	cmpl	$0x0, (%rax)
     c43:      	jne	0xd8c <native_tracer_entry+0xd8c>
     c49:      	movl	%r14d, %eax
     c4c:      	addq	$0x108, %rsp            # imm = 0x108
     c53:      	popq	%rbx
     c54:      	popq	%r12
     c56:      	popq	%r13
     c58:      	popq	%r14
     c5a:      	popq	%r15
     c5c:      	popq	%rbp
     c5d:      	retq
     c5e:      	cmpq	$0x2b, 0xb0(%rsp)
     c67:      	jne	0xd82 <native_tracer_entry+0xd82>
     c6d:      	cmpq	$0x23, 0x98(%rsp)
     c76:      	je	0x379 <native_tracer_entry+0x379>
     c7c:      	movq	0x90(%rsp), %rax
     c84:      	movq	%rax, 0xed0(%r15)
     c8b:      	movq	0xa8(%rsp), %rax
     c93:      	movq	%rax, 0xed8(%r15)
     c9a:      	movq	0x30(%rsp), %rax
     c9f:      	movq	%rax, 0xee0(%r15)
     ca6:      	movq	0x60(%rsp), %rax
     cab:      	movq	%rax, 0xee8(%r15)
     cb2:      	movq	0x50(%rsp), %rax
     cb7:      	movq	%rax, 0xef0(%r15)
     cbe:      	movq	0x40(%rsp), %rax
     cc3:      	movq	%rax, 0xef8(%r15)
     cca:      	movq	0x20(%rsp), %rax
     ccf:      	movq	%rax, 0xf00(%r15)
     cd6:      	movq	0x10(%rsp), %rax
     cdb:      	movq	%rax, 0xf08(%r15)
     ce2:      	cmpq	$-0x1, 0x88(%rsp)
     ceb:      	setne	0xf30(%r15)
     cf3:      	movq	(%rip), %rax            # 0xcfa <native_tracer_entry+0xcfa>
     cfa:      	cmpl	$0x0, (%rax)
     cfd:      	je	0x3f8 <native_tracer_entry+0x3f8>
     d03:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     d0d:      	movq	%rax, 0x2f(%rsp)
     d12:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     d1c:      	movq	%rax, 0x28(%rsp)
     d21:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     d2b:      	movq	%rax, 0x20(%rsp)
     d30:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     d3a:      	movq	%rax, 0x18(%rsp)
     d3f:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     d49:      	movq	%rax, 0x10(%rsp)
     d4e:      	leaq	0x10(%rsp), %rdi
     d53:      	movl	$0x27, %eax
     d58:      	movl	$0x6, %r9d
     d5e:      	movq	0xed0(%r15), %rdx
     d65:      	movq	0xed8(%r15), %rcx
     d6c:      	movq	0xee0(%r15), %r8
     d73:      	movl	$0x27, %esi
     d78:      	xorl	%eax, %eax
     d7a:      	callq	*%r9
     d7d:      	jmp	0x3f8 <native_tracer_entry+0x3f8>
     d82:      	xorl	%r12d, %r12d
     d85:      	xorl	%ebp, %ebp
     d87:      	jmp	0xb7c <native_tracer_entry+0xb7c>
     d8c:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     d96:      	movq	%rax, 0x38(%rsp)
     d9b:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     da5:      	movq	%rax, 0x30(%rsp)
     daa:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     db4:      	movq	%rax, 0x28(%rsp)
     db9:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     dc3:      	movq	%rax, 0x20(%rsp)
     dc8:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     dd2:      	movq	%rax, 0x18(%rsp)
     dd7:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     de1:      	movq	%rax, 0x10(%rsp)
     de6:      	movl	$0xa7972, 0x40(%rsp)    # imm = 0xA7972
     dee:      	leaq	0x10(%rsp), %rdi
     df3:      	movl	$0x34, %eax
     df8:      	movl	$0x6, %ecx
     dfd:      	movl	$0x34, %esi
     e02:      	movl	%r12d, %edx
     e05:      	xorl	%eax, %eax
     e07:      	callq	*%rcx
     e09:      	jmp	0xc49 <native_tracer_entry+0xc49>
     e0e:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     e18:      	movq	%rax, 0x1e(%rsp)
     e1d:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     e27:      	movq	%rax, 0x18(%rsp)
     e2c:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     e36:      	movq	%rax, 0x10(%rsp)
     e3b:      	leaq	0x10(%rsp), %rdi
     e40:      	movl	$0x16, %eax
     e45:      	movl	$0x6, %ecx
     e4a:      	movl	$0x16, %esi
     e4f:      	xorl	%eax, %eax
     e51:      	callq	*%rcx
     e53:      	jmp	0x1c9 <native_tracer_entry+0x1c9>
     e58:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     e62:      	movq	%rax, 0x1e(%rsp)
     e67:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     e71:      	movq	%rax, 0x18(%rsp)
     e76:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     e80:      	movq	%rax, 0x10(%rsp)
     e85:      	leaq	0x10(%rsp), %rdi
     e8a:      	movl	$0x16, %eax
     e8f:      	movl	$0x6, %ecx
     e94:      	movl	0x2bc(%r14), %edx
     e9b:      	movl	$0x16, %esi
     ea0:      	xorl	%eax, %eax
     ea2:      	callq	*%rcx
     ea4:      	jmp	0x67a <native_tracer_entry+0x67a>
     ea9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     eb3:      	movq	%rax, 0xf6(%rsp)
     ebb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ec5:      	movq	%rax, 0xf0(%rsp)
     ecd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ed7:      	movq	%rax, 0xe8(%rsp)
     edf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     ee9:      	movq	%rax, 0xe0(%rsp)
     ef1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     efb:      	movq	%rax, 0xd8(%rsp)
     f03:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f0d:      	movq	%rax, 0xd0(%rsp)
     f15:      	leaq	0xd0(%rsp), %rdi
     f1d:      	movl	$0x2e, %eax
     f22:      	movl	$0x6, %ecx
     f27:      	movl	0xc8(%rsp), %edx
     f2e:      	movl	$0x2e, %esi
     f33:      	xorl	%eax, %eax
     f35:      	callq	*%rcx
     f37:      	jmp	0xb74 <native_tracer_entry+0xb74>
     f3c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f46:      	movq	%rax, 0x36(%rsp)
     f4b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f55:      	movq	%rax, 0x30(%rsp)
     f5a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f64:      	movq	%rax, 0x28(%rsp)
     f69:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f73:      	movq	%rax, 0x20(%rsp)
     f78:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f82:      	movq	%rax, 0x18(%rsp)
     f87:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f91:      	movq	%rax, 0x10(%rsp)
     f96:      	leaq	0x10(%rsp), %rdi
     f9b:      	movl	$0x2e, %eax
     fa0:      	movl	$0x6, %ecx
     fa5:      	movl	0xd0(%rsp), %edx
     fac:      	movl	$0x2e, %esi
     fb1:      	xorl	%eax, %eax
     fb3:      	callq	*%rcx
     fb5:      	jmp	0x32f <native_tracer_entry+0x32f>
     fba:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     fc4:      	movq	%rax, 0x38(%rsp)
     fc9:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     fd3:      	movq	%rax, 0x30(%rsp)
     fd8:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     fe2:      	movq	%rax, 0x28(%rsp)
     fe7:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     ff1:      	movq	%rax, 0x20(%rsp)
     ff6:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    1000:      	movq	%rax, 0x18(%rsp)
    1005:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    100f:      	movq	%rax, 0x10(%rsp)
    1014:      	movb	$0x0, 0x40(%rsp)
    1019:      	leaq	0x10(%rsp), %rdi
    101e:      	movl	$0x31, %eax
    1023:      	movl	$0x6, %ecx
    1028:      	movl	0x2c0(%r15), %edx
    102f:      	movl	$0x31, %esi
    1034:      	xorl	%eax, %eax
    1036:      	callq	*%rcx
    1038:      	movq	0xed0(%r15), %r13
    103f:      	movq	%r13, %rax
    1042:      	shrq	$0x38, %rax
    1046:      	jne	0x45b <native_tracer_entry+0x45b>
    104c:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    1053:      	ja	0x107a <native_tracer_entry+0x107a>
    1055:      	movq	(%rip), %rax            # 0x105c <native_tracer_entry+0x105c>
    105c:      	cmpl	$0x0, (%rax)
    105f:      	jne	0x14b1 <native_tracer_entry+0x14b1>
    1065:      	movl	$0x31, 0xf28(%r15)
    1070:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1075:      	jmp	0xb79 <native_tracer_entry+0xb79>
    107a:      	movl	(%r15), %eax
    107d:      	movl	$0x60, 0xd0(%rsp)
    1088:      	movbel	%eax, 0xd4(%rsp)
    1091:      	movbeq	%r13, 0xd8(%rsp)
    109b:      	movq	(%rip), %rdi            # 0x10a2 <native_tracer_entry+0x10a2>
    10a2:      	leaq	0xd0(%rsp), %rsi
    10aa:      	movl	$0x1, %eax
    10af:      	callq	*%rax
    10b1:      	testq	%rax, %rax
    10b4:      	je	0x11e8 <native_tracer_entry+0x11e8>
    10ba:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    10c4:      	movq	0x8(%rax), %r12
    10c8:      	andq	%r12, %rcx
    10cb:      	movq	%rcx, 0xf20(%r15)
    10d2:      	movq	(%rax), %rax
    10d5:      	movq	%rax, 0xf10(%r15)
    10dc:      	shrq	$0x38, %r12
    10e0:      	movq	%r13, %rax
    10e3:      	subq	%rcx, %rax
    10e6:      	movq	%rax, 0xf18(%r15)
    10ed:      	movq	(%rip), %rax            # 0x10f4 <native_tracer_entry+0x10f4>
    10f4:      	cmpl	$0x0, (%rax)
    10f7:      	jne	0x158b <native_tracer_entry+0x158b>
    10fd:      	xorl	%ebp, %ebp
    10ff:      	cmpl	$0x1, %r12d
    1103:      	jne	0xb7c <native_tracer_entry+0xb7c>
    1109:      	movq	0xf10(%r15), %rax
    1110:      	movq	%rax, 0xd0(%rsp)
    1118:      	movq	0xf18(%r15), %r13
    111f:      	movq	(%rip), %rdi            # 0x1126 <native_tracer_entry+0x1126>
    1126:      	leaq	0xd0(%rsp), %rsi
    112e:      	movl	$0x1, %eax
    1133:      	callq	*%rax
    1135:      	movl	$0x1, %r12d
    113b:      	testq	%rax, %rax
    113e:      	je	0xb7c <native_tracer_entry+0xb7c>
    1144:      	cmpq	%r13, (%rax)
    1147:      	ja	0x114f <native_tracer_entry+0x114f>
    1149:      	cmpq	%r13, 0x8(%rax)
    114d:      	jae	0x1163 <native_tracer_entry+0x1163>
    114f:      	cmpq	%r13, 0x10(%rax)
    1153:      	ja	0xb7c <native_tracer_entry+0xb7c>
    1159:      	cmpq	%r13, 0x18(%rax)
    115d:      	jb	0xb7c <native_tracer_entry+0xb7c>
    1163:      	movq	(%rip), %rcx            # 0x116a <native_tracer_entry+0x116a>
    116a:      	cmpl	$0x0, (%rcx)
    116d:      	jne	0x194e <native_tracer_entry+0x194e>
    1173:      	movl	0x1380(%r15), %ecx
    117a:      	movl	0x20(%rax), %edx
    117d:      	btl	%edx, %ecx
    1180:      	jae	0x19c1 <native_tracer_entry+0x19c1>
    1186:      	movq	(%rip), %rax            # 0x118d <native_tracer_entry+0x118d>
    118d:      	cmpl	$0x0, (%rax)
    1190:      	je	0xb7c <native_tracer_entry+0xb7c>
    1196:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    11a0:      	movq	%rax, 0x20(%rsp)
    11a5:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    11af:      	movq	%rax, 0x18(%rsp)
    11b4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    11be:      	movq	%rax, 0x10(%rsp)
    11c3:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    11cb:      	leaq	0x10(%rsp), %rdi
    11d0:      	movl	$0x1b, %eax
    11d5:      	movl	$0x6, %ecx
    11da:      	movl	$0x1b, %esi
    11df:      	xorl	%eax, %eax
    11e1:      	callq	*%rcx
    11e3:      	jmp	0xb7c <native_tracer_entry+0xb7c>
    11e8:      	movq	(%rip), %rax            # 0x11ef <native_tracer_entry+0x11ef>
    11ef:      	cmpl	$0x0, (%rax)
    11f2:      	jne	0x1735 <native_tracer_entry+0x1735>
    11f8:      	movl	$0xc, 0xf28(%r15)
    1203:      	movl	$0xfac, %ebp            # imm = 0xFAC
    1208:      	jmp	0xb79 <native_tracer_entry+0xb79>
    120d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1217:      	movq	%rax, 0x36(%rsp)
    121c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1226:      	movq	%rax, 0x30(%rsp)
    122b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1235:      	movq	%rax, 0x28(%rsp)
    123a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1244:      	movq	%rax, 0x20(%rsp)
    1249:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1253:      	movq	%rax, 0x18(%rsp)
    1258:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1262:      	movq	%rax, 0x10(%rsp)
    1267:      	leaq	0x10(%rsp), %rdi
    126c:      	movl	$0x2e, %eax
    1271:      	movl	$0x6, %ecx
    1276:      	movl	0xd0(%rsp), %edx
    127d:      	movl	$0x2e, %esi
    1282:      	xorl	%eax, %eax
    1284:      	callq	*%rcx
    1286:      	jmp	0xc0a <native_tracer_entry+0xc0a>
    128b:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
    1295:      	movq	%rcx, 0x27(%rsp)
    129a:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
    12a4:      	movq	%rcx, 0x20(%rsp)
    12a9:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
    12b3:      	movq	%rcx, 0x18(%rsp)
    12b8:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
    12c2:      	movq	%rcx, 0x10(%rsp)
    12c7:      	leaq	0x10(%rsp), %rdi
    12cc:      	movl	$0x1f, %ecx
    12d1:      	movl	$0x6, %r8d
    12d7:      	movl	0x8(%rsp), %edx
    12db:      	movl	$0x1f, %esi
    12e0:      	movl	%r14d, %ecx
    12e3:      	movq	%rax, %r15
    12e6:      	xorl	%eax, %eax
    12e8:      	callq	*%r8
    12eb:      	movq	%r15, %rax
    12ee:      	jmp	0x5be <native_tracer_entry+0x5be>
    12f3:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    12fd:      	movq	%rax, 0x38(%rsp)
    1302:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    130c:      	movq	%rax, 0x30(%rsp)
    1311:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    131b:      	movq	%rax, 0x28(%rsp)
    1320:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    132a:      	movq	%rax, 0x20(%rsp)
    132f:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    1339:      	movq	%rax, 0x18(%rsp)
    133e:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    1348:      	movq	%rax, 0x10(%rsp)
    134d:      	movb	$0x0, 0x40(%rsp)
    1352:      	leaq	0x10(%rsp), %rdi
    1357:      	movl	$0x31, %eax
    135c:      	movl	$0x6, %ecx
    1361:      	movl	$0x31, %esi
    1366:      	xorl	%eax, %eax
    1368:      	callq	*%rcx
    136a:      	jmp	0x55c <native_tracer_entry+0x55c>
    136f:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1379:      	movq	%rax, 0x28(%rsp)
    137e:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    1388:      	movq	%rax, 0x20(%rsp)
    138d:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    1397:      	movq	%rax, 0x18(%rsp)
    139c:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    13a6:      	movq	%rax, 0x10(%rsp)
    13ab:      	movw	$0xa, 0x30(%rsp)
    13b2:      	leaq	0x10(%rsp), %rdi
    13b7:      	movl	$0x22, %eax
    13bc:      	movl	$0x6, %ecx
    13c1:      	movl	$0x22, %esi
    13c6:      	movq	%r13, %rdx
    13c9:      	xorl	%eax, %eax
    13cb:      	callq	*%rcx
    13cd:      	jmp	0x46b <native_tracer_entry+0x46b>
    13d2:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    13dc:      	movq	%rcx, 0x25(%rsp)
    13e1:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    13eb:      	movq	%rcx, 0x20(%rsp)
    13f0:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    13fa:      	movq	%rcx, 0x18(%rsp)
    13ff:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1409:      	movq	%rcx, 0x10(%rsp)
    140e:      	leaq	0x10(%rsp), %rdi
    1413:      	movl	$0x1d, %ecx
    1418:      	movl	$0x6, %r8d
    141e:      	movl	0x8(%rsp), %edx
    1422:      	movl	$0x1d, %esi
    1427:      	movl	%eax, %ecx
    1429:      	xorl	%eax, %eax
    142b:      	callq	*%r8
    142e:      	jmp	0x60d <native_tracer_entry+0x60d>
    1433:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    143d:      	movq	%rax, 0x36(%rsp)
    1442:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    144c:      	movq	%rax, 0x30(%rsp)
    1451:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    145b:      	movq	%rax, 0x28(%rsp)
    1460:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    146a:      	movq	%rax, 0x20(%rsp)
    146f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1479:      	movq	%rax, 0x18(%rsp)
    147e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1488:      	movq	%rax, 0x10(%rsp)
    148d:      	leaq	0x10(%rsp), %rdi
    1492:      	movl	$0x2e, %eax
    1497:      	movl	$0x6, %ecx
    149c:      	movl	0xd0(%rsp), %edx
    14a3:      	movl	$0x2e, %esi
    14a8:      	xorl	%eax, %eax
    14aa:      	callq	*%rcx
    14ac:      	jmp	0x64d <native_tracer_entry+0x64d>
    14b1:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    14bb:      	movq	%rax, 0x26(%rsp)
    14c0:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    14ca:      	movq	%rax, 0x20(%rsp)
    14cf:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    14d9:      	movq	%rax, 0x18(%rsp)
    14de:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    14e8:      	movq	%rax, 0x10(%rsp)
    14ed:      	leaq	0x10(%rsp), %rdi
    14f2:      	movl	$0x1e, %eax
    14f7:      	movl	$0x6, %ecx
    14fc:      	movl	$0x1e, %esi
    1501:      	movq	%r13, %rdx
    1504:      	xorl	%eax, %eax
    1506:      	callq	*%rcx
    1508:      	jmp	0x1065 <native_tracer_entry+0x1065>
    150d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1517:      	movq	%rax, 0x36(%rsp)
    151c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1526:      	movq	%rax, 0x30(%rsp)
    152b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1535:      	movq	%rax, 0x28(%rsp)
    153a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1544:      	movq	%rax, 0x20(%rsp)
    1549:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1553:      	movq	%rax, 0x18(%rsp)
    1558:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1562:      	movq	%rax, 0x10(%rsp)
    1567:      	leaq	0x10(%rsp), %rdi
    156c:      	movl	$0x2e, %eax
    1571:      	movl	$0x6, %ecx
    1576:      	movl	0xd0(%rsp), %edx
    157d:      	movl	$0x2e, %esi
    1582:      	xorl	%eax, %eax
    1584:      	callq	*%rcx
    1586:      	jmp	0x778 <native_tracer_entry+0x778>
    158b:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    1595:      	movq	%rax, 0x38(%rsp)
    159a:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    15a4:      	movq	%rax, 0x30(%rsp)
    15a9:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    15b3:      	movq	%rax, 0x28(%rsp)
    15b8:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    15c2:      	movq	%rax, 0x20(%rsp)
    15c7:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    15d1:      	movq	%rax, 0x18(%rsp)
    15d6:      	movabsq	$0x6365732074786554, %rbp # imm = 0x6365732074786554
    15e0:      	movq	%rbp, 0x10(%rsp)
    15e5:      	movw	$0xa, 0x40(%rsp)
    15ec:      	leaq	0x10(%rsp), %rdi
    15f1:      	movl	$0x32, %eax
    15f6:      	movl	$0x6, %r9d
    15fc:      	movq	0xf10(%r15), %rcx
    1603:      	movl	$0x32, %esi
    1608:      	movq	%r13, %rdx
    160b:      	movl	%r12d, %r8d
    160e:      	xorl	%eax, %eax
    1610:      	callq	*%r9
    1613:      	movq	(%rip), %rax            # 0x161a <native_tracer_entry+0x161a>
    161a:      	cmpl	$0x0, (%rax)
    161d:      	je	0x10fd <native_tracer_entry+0x10fd>
    1623:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    162d:      	movq	%rax, 0x37(%rsp)
    1632:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    163c:      	movq	%rax, 0x30(%rsp)
    1641:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    164b:      	movq	%rax, 0x28(%rsp)
    1650:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    165a:      	movq	%rax, 0x20(%rsp)
    165f:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1669:      	movq	%rax, 0x18(%rsp)
    166e:      	movq	%rbp, 0x10(%rsp)
    1673:      	leaq	0x10(%rsp), %rdi
    1678:      	movl	$0x2f, %eax
    167d:      	movl	$0x6, %r8d
    1683:      	movq	0xf18(%r15), %rcx
    168a:      	movq	0xf20(%r15), %rdx
    1691:      	movl	$0x2f, %esi
    1696:      	xorl	%eax, %eax
    1698:      	callq	*%r8
    169b:      	jmp	0x10fd <native_tracer_entry+0x10fd>
    16a0:      	movl	0xc8(%rsp), %ecx
    16a7:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    16b1:      	movq	%rdx, 0x3d(%rsp)
    16b6:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    16c0:      	movq	%rdx, 0x38(%rsp)
    16c5:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    16cf:      	movq	%rdx, 0x30(%rsp)
    16d4:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    16de:      	movq	%rdx, 0x28(%rsp)
    16e3:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    16ed:      	movq	%rdx, 0x20(%rsp)
    16f2:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    16fc:      	movq	%rdx, 0x18(%rsp)
    1701:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    170b:      	movq	%rdx, 0x10(%rsp)
    1710:      	leaq	0x10(%rsp), %rdi
    1715:      	movl	$0x35, %edx
    171a:      	movl	$0x6, %r9d
    1720:      	movl	$0x35, %esi
    1725:      	movl	%r12d, %edx
    1728:      	movl	%eax, %r8d
    172b:      	xorl	%eax, %eax
    172d:      	callq	*%r9
    1730:      	jmp	0x73b <native_tracer_entry+0x73b>
    1735:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    173f:      	movq	%rax, 0x40(%rsp)
    1744:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    174e:      	movq	%rax, 0x38(%rsp)
    1753:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    175d:      	movq	%rax, 0x30(%rsp)
    1762:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    176c:      	movq	%rax, 0x28(%rsp)
    1771:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    177b:      	movq	%rax, 0x20(%rsp)
    1780:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    178a:      	movq	%rax, 0x18(%rsp)
    178f:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1799:      	movq	%rax, 0x10(%rsp)
    179e:      	movb	$0x0, 0x48(%rsp)
    17a3:      	leaq	0x10(%rsp), %rdi
    17a8:      	movl	$0x39, %eax
    17ad:      	movl	$0x6, %ecx
    17b2:      	movl	$0x39, %esi
    17b7:      	movq	%r13, %rdx
    17ba:      	xorl	%eax, %eax
    17bc:      	callq	*%rcx
    17be:      	jmp	0x11f8 <native_tracer_entry+0x11f8>
    17c3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17cd:      	movq	%rax, 0x36(%rsp)
    17d2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17dc:      	movq	%rax, 0x30(%rsp)
    17e1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17eb:      	movq	%rax, 0x28(%rsp)
    17f0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17fa:      	movq	%rax, 0x20(%rsp)
    17ff:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1809:      	movq	%rax, 0x18(%rsp)
    180e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1818:      	movq	%rax, 0x10(%rsp)
    181d:      	leaq	0x10(%rsp), %rdi
    1822:      	movl	$0x2e, %eax
    1827:      	movl	$0x6, %ecx
    182c:      	movl	0xd0(%rsp), %edx
    1833:      	movl	$0x2e, %esi
    1838:      	xorl	%eax, %eax
    183a:      	callq	*%rcx
    183c:      	jmp	0xa30 <native_tracer_entry+0xa30>
    1841:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    184b:      	movq	%rcx, 0x3e(%rsp)
    1850:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    185a:      	movq	%rcx, 0x38(%rsp)
    185f:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    1869:      	movq	%rcx, 0x30(%rsp)
    186e:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    1878:      	movq	%rcx, 0x28(%rsp)
    187d:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    1887:      	movq	%rcx, 0x20(%rsp)
    188c:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    1896:      	movq	%rcx, 0x18(%rsp)
    189b:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    18a5:      	movq	%rcx, 0x10(%rsp)
    18aa:      	leaq	0x10(%rsp), %rdi
    18af:      	movl	$0x36, %ecx
    18b4:      	movl	$0x6, %r8d
    18ba:      	movl	$0x36, %esi
    18bf:      	movl	$0x1, %edx
    18c4:      	movl	%eax, %ecx
    18c6:      	xorl	%eax, %eax
    18c8:      	callq	*%r8
    18cb:      	jmp	0x9f6 <native_tracer_entry+0x9f6>
    18d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    18da:      	movq	%rax, 0x36(%rsp)
    18df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    18e9:      	movq	%rax, 0x30(%rsp)
    18ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    18f8:      	movq	%rax, 0x28(%rsp)
    18fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1907:      	movq	%rax, 0x20(%rsp)
    190c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1916:      	movq	%rax, 0x18(%rsp)
    191b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1925:      	movq	%rax, 0x10(%rsp)
    192a:      	leaq	0x10(%rsp), %rdi
    192f:      	movl	$0x2e, %eax
    1934:      	movl	$0x6, %ecx
    1939:      	movl	0xd0(%rsp), %edx
    1940:      	movl	$0x2e, %esi
    1945:      	xorl	%eax, %eax
    1947:      	callq	*%rcx
    1949:      	jmp	0x9a7 <native_tracer_entry+0x9a7>
    194e:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1958:      	movq	%rcx, 0x26(%rsp)
    195d:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1967:      	movq	%rcx, 0x20(%rsp)
    196c:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    1976:      	movq	%rcx, 0x18(%rsp)
    197b:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    1985:      	movq	%rcx, 0x10(%rsp)
    198a:      	leaq	0x10(%rsp), %rdi
    198f:      	movl	$0x1e, %ecx
    1994:      	movl	$0x6, %r8d
    199a:      	movzwl	0x20(%rax), %edx
    199e:      	movl	$0x1e, %esi
    19a3:      	movq	%rax, %r13
    19a6:      	xorl	%eax, %eax
    19a8:      	callq	*%r8
    19ab:      	movq	%r13, %rax
    19ae:      	movl	0x1380(%r15), %ecx
    19b5:      	movl	0x20(%rax), %edx
    19b8:      	btl	%edx, %ecx
    19bb:      	jb	0x1186 <native_tracer_entry+0x1186>
    19c1:      	movq	%rax, %r12
    19c4:      	movl	$0x0, 0xc8(%rsp)
    19cf:      	movq	(%rip), %rdi            # 0x19d6 <native_tracer_entry+0x19d6>
    19d6:      	leaq	0xc8(%rsp), %rsi
    19de:      	movl	$0x1, %eax
    19e3:      	callq	*%rax
    19e5:      	testq	%rax, %rax
    19e8:      	je	0x19f2 <native_tracer_entry+0x19f2>
    19ea:      	incq	(%rax)
    19ed:      	movq	%r12, %rax
    19f0:      	jmp	0x1a01 <native_tracer_entry+0x1a01>
    19f2:      	movq	(%rip), %rax            # 0x19f9 <native_tracer_entry+0x19f9>
    19f9:      	cmpl	$0x0, (%rax)
    19fc:      	movq	%r12, %rax
    19ff:      	jne	0x1a0b <native_tracer_entry+0x1a0b>
    1a01:      	movzwl	0x20(%rax), %r12d
    1a06:      	jmp	0xb7c <native_tracer_entry+0xb7c>
    1a0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a15:      	movq	%rax, 0x36(%rsp)
    1a1a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a24:      	movq	%rax, 0x30(%rsp)
    1a29:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a33:      	movq	%rax, 0x28(%rsp)
    1a38:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a42:      	movq	%rax, 0x20(%rsp)
    1a47:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a51:      	movq	%rax, 0x18(%rsp)
    1a56:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a60:      	movq	%rax, 0x10(%rsp)
    1a65:      	leaq	0x10(%rsp), %rdi
    1a6a:      	movl	$0x2e, %eax
    1a6f:      	movl	$0x6, %ecx
    1a74:      	movl	0xc8(%rsp), %edx
    1a7b:      	movl	$0x2e, %esi
    1a80:      	xorl	%eax, %eax
    1a82:      	callq	*%rcx
    1a84:      	jmp	0x19ed <native_tracer_entry+0x19ed>
