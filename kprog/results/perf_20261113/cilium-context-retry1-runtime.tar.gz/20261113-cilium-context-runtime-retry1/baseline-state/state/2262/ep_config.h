/*
 * This file is not using during compilation of endpoint programs.
 * Docker Network ID: 
 * Docker Endpoint ID: 
 * IPv4 address: invalid IP
 * Identity: 1
 * PolicyMap: cilium_policy_v2_02262
 * NodeMAC: 72:1a:74:09:8e:01
 */

/*
 * Labels:
 * - reserved:host
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define HOST_ENDPOINT 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#undef MONITOR_AGGREGATION
#define POLICY_AUDIT_MODE 1
#define POLICY_VERDICT_NOTIFY 1
#undef ENABLE_SIP_VERIFICATION
#define TRACE_NOTIFY 1
