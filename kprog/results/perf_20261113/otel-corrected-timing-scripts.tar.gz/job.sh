#!/bin/bash
set -uo pipefail
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-otel-corrected-combined-timing
exec > "$r/job.log" 2>&1
date -u +%FT%TZ > "$r/queued"
exec 8>>/workspaces/.agent-state/kprog-lanes/locks/timing
flock -x 8
exec 9>>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
date -u +%FT%TZ > "$r/started"
export PATH=/workspaces/repository/kprog/perf/may29-image/eqcodex-bin:$PATH
export EQCODEX_ALL_JIT_PROGRAMS=1
export EQCODEX_NATIVE_LINK_BINARY=/workspaces/repository/corpus/results/perf-combined-codegen-compatible-20261114/native-link-on
for stats in 1 0; do
 export EQCODEX_OUT=/workspaces/repository/corpus/results/perf-corrected-combined-timing-20261114/stats$stats
 taskset -c 0-7 make -f kprog/perf/one-image/Makefile rotate ORDER=otelcol-ebpf-profiler/profiling SAMPLES=3 WORKLOAD_DURATION=180 CPUS=0-7 VM_CPUS=8 VM_MEM=64G NATIVE_MANIFEST=/workspaces/repository/corpus/results/perf-combined-codegen-source-all-20261114/manifest-context.json STATE=/var/tmp/kprog-tmp/perf/corrected-combined-timing LOGS=/workspaces/kprog-raw/perf/20261114-otel-corrected-combined-timing/runs STATS=$stats
 echo "$?" > "$r/stats$stats.exit"
done
date -u +%FT%TZ > "$r/finished"
