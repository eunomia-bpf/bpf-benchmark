
/workspaces/kprog-raw/perf/20261113-loader-cpu-profile/expanded-symbols/usr/local/lib/bpfrejit/libnative_loader.so:     file format elf64-x86-64


Disassembly of section .text:

000000000003d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>:
   3d818:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
   3d81d:	e8 7e 9f fd ff       	call   177a0 <readdir@plt>
   3d822:	48 85 c0             	test   %rax,%rax
   3d825:	0f 84 7e 01 00 00    	je     3d9a9 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d999>
   3d82b:	0f b6 48 13          	movzbl 0x13(%rax),%ecx
   3d82f:	8d 51 d0             	lea    -0x30(%rcx),%edx
   3d832:	80 fa 09             	cmp    $0x9,%dl
   3d835:	77 e1                	ja     3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d837:	48 8d 78 13          	lea    0x13(%rax),%rdi
   3d83b:	ba 0a 00 00 00       	mov    $0xa,%edx
   3d840:	31 f6                	xor    %esi,%esi
   3d842:	e8 e9 a6 fd ff       	call   17f30 <__isoc23_strtol@plt>
   3d847:	89 44 24 60          	mov    %eax,0x60(%rsp)
   3d84b:	49 89 c6             	mov    %rax,%r14
   3d84e:	85 c0                	test   %eax,%eax
   3d850:	78 c6                	js     3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d852:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3d859:	00 
   3d85a:	41 89 c1             	mov    %eax,%r9d
   3d85d:	31 c0                	xor    %eax,%eax
   3d85f:	ba 02 00 00 00       	mov    $0x2,%edx
   3d864:	be 40 00 00 00       	mov    $0x40,%esi
   3d869:	b9 40 00 00 00       	mov    $0x40,%ecx
   3d86e:	4c 8d 05 a7 7f 04 00 	lea    0x47fa7(%rip),%r8        # 8581c <btf_relocate@@Base+0x15ec>
   3d875:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   3d87a:	e8 e1 8f fd ff       	call   16860 <__snprintf_chk@plt>
   3d87f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   3d884:	ba 3f 00 00 00       	mov    $0x3f,%edx
   3d889:	4c 8d bc 24 20 03 00 	lea    0x320(%rsp),%r15
   3d890:	00 
   3d891:	4c 89 fe             	mov    %r15,%rsi
   3d894:	e8 57 96 fd ff       	call   16ef0 <readlink@plt>
   3d899:	48 85 c0             	test   %rax,%rax
   3d89c:	0f 8e 76 ff ff ff    	jle    3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d8a2:	c6 84 04 20 03 00 00 	movb   $0x0,0x320(%rsp,%rax,1)
   3d8a9:	00 
   3d8aa:	48 ba 64 65 3a 62 70 	movabs $0x6d2d6670623a6564,%rdx
   3d8b1:	66 2d 6d 
   3d8b4:	48 b8 61 6e 6f 6e 5f 	movabs $0x6f6e695f6e6f6e61,%rax
   3d8bb:	69 6e 6f 
   3d8be:	48 33 94 24 28 03 00 	xor    0x328(%rsp),%rdx
   3d8c5:	00 
   3d8c6:	48 33 84 24 20 03 00 	xor    0x320(%rsp),%rax
   3d8cd:	00 
   3d8ce:	48 09 d0             	or     %rdx,%rax
   3d8d1:	0f 85 41 ff ff ff    	jne    3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d8d7:	81 bc 24 2f 03 00 00 	cmpl   $0x70616d,0x32f(%rsp)
   3d8de:	6d 61 70 00 
   3d8e2:	0f 85 30 ff ff ff    	jne    3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d8e8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   3d8ed:	31 c0                	xor    %eax,%eax
   3d8ef:	b9 0d 00 00 00       	mov    $0xd,%ecx
   3d8f4:	48 8d 94 24 a4 00 00 	lea    0xa4(%rsp),%rdx
   3d8fb:	00 
   3d8fc:	c7 84 24 a4 00 00 00 	movl   $0x68,0xa4(%rsp)
   3d903:	68 00 00 00 
   3d907:	f3 48 ab             	rep stos %rax,%es:(%rdi)
   3d90a:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
   3d911:	00 
   3d912:	8b 7c 24 60          	mov    0x60(%rsp),%edi
   3d916:	48 89 c6             	mov    %rax,%rsi
   3d919:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   3d91e:	e8 7d 8a fd ff       	call   163a0 <bpf_obj_get_info_by_fd@plt>
   3d923:	85 c0                	test   %eax,%eax
   3d925:	0f 85 ed fe ff ff    	jne    3d818 <_ZN13native_loader20close_loaded_programEPNS_13LoadedProgramE@@Base+0x1d808>
   3d92b:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
   3d932:	00 
   3d933:	4c 89 fe             	mov    %r15,%rsi
   3d936:	f3 0f 6f 94 24 88 02 	movdqu 0x288(%rsp),%xmm2
   3d93d:	00 00 
   3d93f:	c6                   	.byte 0xc6
