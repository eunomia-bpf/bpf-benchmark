/var/tmp/kprog-tmp/perf/tetragon-errno-store/bpf_generic_uprobe_v61/bpf_generic_uprobe_v61.direct.bpf.o: \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_generic_uprobe.c \
  include/vmlinux.h include/vmlinux_generated_x86.h include/api.h \
  include/bpf_elf.h include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/environ_conf.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/retprobe_map.h \
  libbpf/bpf_tracing.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/operations.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/basic.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/skb.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/tuple.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/sock.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/sockaddr.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/sockaddr_un.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/socket.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/net_device.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../bpf_process_event.h \
  lib/bpf_cgroup.h include/bpf_ktime.h cgroup/cgtracker.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/bpfattr.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/perfevent.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/bpfmap.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/capabilities.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/module.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../argfilter_maps.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../addr_lpm_maps.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../string_maps.h \
  process/data_event.h lib/data_msg.h process/bpf_enforcer.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../syscall64.h \
  process/ratelimit_maps.h process/heap.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../bpf_mbset.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/types/../cel_expr.h \
  process/event_config.h process/generic_maps.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/uprobe_offload.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/regs.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/user_preload.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/generic_maps.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/generic_arg.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/usdt_arg.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/generic_calls.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/pfilter.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_process_event.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/policy_filter.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/generic_path.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/event_config.h
