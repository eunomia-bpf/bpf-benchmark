
corpus/results/perf-context-20261113/otelcol-ebpf-profiler.native.o:	file format elf64-x86-64

Disassembly of section perf_event/native_tracer_entry:

0000000000000000 <native_tracer_entry>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r13
      1e:      	movq	%rax, %r12
      21:      	shrq	$0x20, %r12
      25:      	je	0x19a <native_tracer_entry+0x19a>
      2b:      	movl	$0x5, %eax
      30:      	callq	*%rax
      32:      	movq	%rax, %rbp
      35:      	movq	(%rip), %rax            # 0x3c <native_tracer_entry+0x3c>
      3c:      	cmpl	$0x0, (%rax)
      3f:      	jne	0xa50 <native_tracer_entry+0xa50>
      45:      	movl	$0x0, 0x10(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <native_tracer_entry+0x54>
      54:      	leaq	0x10(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
      66:      	testq	%rax, %rax
      69:      	je	0xc64 <native_tracer_entry+0xc64>
      6f:      	movq	%rax, %r15
      72:      	movq	$0x0, 0xf00(%rax)
      7d:      	movb	$0x0, 0xf30(%rax)
      84:      	movq	$0x0, 0xed0(%rax)
      8f:      	movq	$0x0, 0xed8(%rax)
      9a:      	movq	$0x0, 0xee0(%rax)
      a5:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      aa:      	movq	%rax, 0xf28(%r15)
      b1:      	movl	$0x0, 0x1380(%r15)
      bc:      	movw	$0x100, 0x1384(%r15)    # imm = 0x100
      c6:      	movq	$0x0, 0xf38(%r15)
      d1:      	movq	$0x0, 0xf40(%r15)
      dc:      	movq	$0x0, 0xf58(%r15)
      e7:      	movq	$0x0, 0xf60(%r15)
      f2:      	movq	$0x0, 0xf68(%r15)
      fd:      	movq	$0x0, 0xf70(%r15)
     108:      	movq	$0x0, 0xf78(%r15)
     113:      	movq	%rax, 0x2bc(%r15)
     11a:      	leaq	0x20(%r15), %rdi
     11e:      	movl	$0x29c, %edx            # imm = 0x29C
     123:      	xorl	%esi, %esi
     125:      	callq	0x12a <native_tracer_entry+0x12a>
     12a:      	movl	$0x1, 0x2c4(%r15)
     135:      	movl	%r12d, (%r15)
     138:      	movl	%r13d, 0x4(%r15)
     13c:      	movq	%rbp, 0x8(%r15)
     140:      	movq	$0x0, 0x2c8(%r15)
     14b:      	leaq	0x10(%r15), %rdi
     14f:      	movl	$0x10, %eax
     154:      	movl	$0x10, %ecx
     159:      	movl	$0x10, %esi
     15e:      	callq	*%rcx
     160:      	testl	%eax, %eax
     162:      	jns	0x32f <native_tracer_entry+0x32f>
     168:      	movl	$0x34, 0xd0(%rsp)
     173:      	movq	(%rip), %rdi            # 0x17a <native_tracer_entry+0x17a>
     17a:      	leaq	0xd0(%rsp), %rsi
     182:      	movl	$0x1, %eax
     187:      	callq	*%rax
     189:      	testq	%rax, %rax
     18c:      	je	0x31f <native_tracer_entry+0x31f>
     192:      	incq	(%rax)
     195:      	jmp	0x32f <native_tracer_entry+0x32f>
     19a:      	movq	(%rip), %rax            # 0x1a1 <native_tracer_entry+0x1a1>
     1a1:      	xorl	%r14d, %r14d
     1a4:      	cmpb	$0x0, (%rax)
     1a7:      	jne	0xc64 <native_tracer_entry+0xc64>
     1ad:      	movl	$0x5, %eax
     1b2:      	callq	*%rax
     1b4:      	movq	%rax, %r15
     1b7:      	movq	(%rip), %r12            # 0x1be <native_tracer_entry+0x1be>
     1be:      	cmpl	$0x0, (%r12)
     1c3:      	jne	0xe29 <native_tracer_entry+0xe29>
     1c9:      	movl	$0x0, 0x10(%rsp)
     1d1:      	movq	(%rip), %rdi            # 0x1d8 <native_tracer_entry+0x1d8>
     1d8:      	leaq	0x10(%rsp), %rsi
     1dd:      	movl	$0x1, %eax
     1e2:      	callq	*%rax
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x498 <native_tracer_entry+0x498>
     1ed:      	movq	%rax, %r14
     1f0:      	movq	$0x0, 0xf00(%rax)
     1fb:      	movb	$0x0, 0xf30(%rax)
     202:      	movq	$0x0, 0xed0(%rax)
     20d:      	movq	$0x0, 0xed8(%rax)
     218:      	movq	$0x0, 0xee0(%rax)
     223:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     228:      	movq	%rax, 0xf28(%r14)
     22f:      	movl	$0x0, 0x1380(%r14)
     23a:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     244:      	movq	$0x0, 0xf38(%r14)
     24f:      	movq	$0x0, 0xf40(%r14)
     25a:      	movq	$0x0, 0xf58(%r14)
     265:      	movq	$0x0, 0xf60(%r14)
     270:      	movq	$0x0, 0xf68(%r14)
     27b:      	movq	$0x0, 0xf70(%r14)
     286:      	movq	$0x0, 0xf78(%r14)
     291:      	movq	%rax, 0x2bc(%r14)
     298:      	leaq	0x20(%r14), %rdi
     29c:      	movl	$0x29c, %edx            # imm = 0x29C
     2a1:      	xorl	%esi, %esi
     2a3:      	callq	0x2a8 <native_tracer_entry+0x2a8>
     2a8:      	movl	$0x1, 0x2c4(%r14)
     2b3:      	movl	$0x0, (%r14)
     2ba:      	movl	%r13d, 0x4(%r14)
     2be:      	movq	%r15, 0x8(%r14)
     2c2:      	movq	$0x0, 0x2c8(%r14)
     2cd:      	movq	%r14, %rdi
     2d0:      	addq	$0x10, %rdi
     2d4:      	movl	$0x10, %eax
     2d9:      	movl	$0x10, %ecx
     2de:      	movl	$0x10, %esi
     2e3:      	callq	*%rcx
     2e5:      	testl	%eax, %eax
     2e7:      	jns	0x665 <native_tracer_entry+0x665>
     2ed:      	movl	$0x34, 0xd0(%rsp)
     2f8:      	movq	(%rip), %rdi            # 0x2ff <native_tracer_entry+0x2ff>
     2ff:      	leaq	0xd0(%rsp), %rsi
     307:      	movl	$0x1, %eax
     30c:      	callq	*%rax
     30e:      	testq	%rax, %rax
     311:      	je	0x65a <native_tracer_entry+0x65a>
     317:      	incq	(%rax)
     31a:      	jmp	0x665 <native_tracer_entry+0x665>
     31f:      	movq	(%rip), %rax            # 0x326 <native_tracer_entry+0x326>
     326:      	cmpl	$0x0, (%rax)
     329:      	jne	0xf57 <native_tracer_entry+0xf57>
     32f:      	movq	(%rip), %rsi            # 0x336 <native_tracer_entry+0x336>
     336:      	movl	$0x400, %eax            # imm = 0x400
     33b:      	movl	$0x1b, %ecx
     340:      	movl	$0x400, %edx            # imm = 0x400
     345:      	movq	%rbx, %rdi
     348:      	callq	*%rcx
     34a:      	movl	%eax, 0x2bc(%r15)
     351:      	movq	(%rip), %rax            # 0x358 <native_tracer_entry+0x358>
     358:      	cmpl	$0x0, (%rax)
     35b:      	jne	0xa9a <native_tracer_entry+0xa9a>
     361:      	movq	(%rbx), %rax
     364:      	cmpq	$0x2b, 0xa0(%rax)
     36c:      	jne	0xaf7 <native_tracer_entry+0xaf7>
     372:      	cmpq	$0x23, 0x88(%rax)
     37a:      	jne	0x386 <native_tracer_entry+0x386>
     37c:      	movl	$0xfb1, %ebp            # imm = 0xFB1
     381:      	jmp	0xb94 <native_tracer_entry+0xb94>
     386:      	movq	0x80(%rax), %rax
     38d:      	movq	%rax, 0xed0(%r15)
     394:      	movq	(%rbx), %rax
     397:      	movq	0x98(%rax), %rax
     39e:      	movq	%rax, 0xed8(%r15)
     3a5:      	movq	(%rbx), %rax
     3a8:      	movq	0x20(%rax), %rax
     3ac:      	movq	%rax, 0xee0(%r15)
     3b3:      	movq	(%rbx), %rax
     3b6:      	movq	0x50(%rax), %rax
     3ba:      	movq	%rax, 0xee8(%r15)
     3c1:      	movq	(%rbx), %rax
     3c4:      	movq	0x40(%rax), %rax
     3c8:      	movq	%rax, 0xef0(%r15)
     3cf:      	movq	(%rbx), %rax
     3d2:      	movq	0x30(%rax), %rax
     3d6:      	movq	%rax, 0xef8(%r15)
     3dd:      	movq	(%rbx), %rax
     3e0:      	movq	0x10(%rax), %rax
     3e4:      	movq	%rax, 0xf00(%r15)
     3eb:      	movq	(%rbx), %rax
     3ee:      	movq	(%rax), %rax
     3f1:      	movq	%rax, 0xf08(%r15)
     3f8:      	movb	$0x0, 0xf30(%r15)
     400:      	movq	(%rip), %rax            # 0x407 <native_tracer_entry+0x407>
     407:      	cmpl	$0x0, (%rax)
     40a:      	jne	0xd1e <native_tracer_entry+0xd1e>
     410:      	movl	$0x60, 0x10(%rsp)
     418:      	movbel	%r12d, 0x14(%rsp)
     41f:      	movq	$0x0, 0x18(%rsp)
     428:      	movq	(%rip), %rdi            # 0x42f <native_tracer_entry+0x42f>
     42f:      	leaq	0x10(%rsp), %rsi
     434:      	movl	$0x1, %eax
     439:      	callq	*%rax
     43b:      	testq	%rax, %rax
     43e:      	je	0x4a3 <native_tracer_entry+0x4a3>
     440:      	movq	%r15, %rax
     443:      	addq	$0xed0, %rax            # imm = 0xED0
     449:      	movq	(%rax), %r13
     44c:      	movq	(%rip), %rax            # 0x453 <native_tracer_entry+0x453>
     453:      	movl	(%rax), %eax
     455:      	testq	%r13, %r13
     458:      	je	0x56c <native_tracer_entry+0x56c>
     45e:      	testl	%eax, %eax
     460:      	jne	0xfd5 <native_tracer_entry+0xfd5>
     466:      	movq	%r13, %rax
     469:      	shrq	$0x38, %rax
     46d:      	je	0x1067 <native_tracer_entry+0x1067>
     473:      	movq	(%rip), %rax            # 0x47a <native_tracer_entry+0x47a>
     47a:      	cmpl	$0x0, (%rax)
     47d:      	jne	0x138a <native_tracer_entry+0x138a>
     483:      	movl	$0xb, 0xf28(%r15)
     48e:      	movl	$0xfab, %ebp            # imm = 0xFAB
     493:      	jmp	0xb94 <native_tracer_entry+0xb94>
     498:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
     49e:      	jmp	0xc64 <native_tracer_entry+0xc64>
     4a3:      	movq	%r13, 0xc8(%rsp)
     4ab:      	movl	%r12d, 0x8(%rsp)
     4b0:      	movq	(%rip), %rdi            # 0x4b7 <native_tracer_entry+0x4b7>
     4b7:      	leaq	0x8(%rsp), %rsi
     4bc:      	movl	$0x1, %eax
     4c1:      	callq	*%rax
     4c3:      	movq	%rax, %r14
     4c6:      	movl	$0x5, %eax
     4cb:      	callq	*%rax
     4cd:      	testq	%r14, %r14
     4d0:      	je	0x589 <native_tracer_entry+0x589>
     4d6:      	movq	(%r14), %rcx
     4d9:      	movq	%rcx, %rsi
     4dc:      	andq	$-0x20, %rsi
     4e0:      	movq	%rax, %rdx
     4e3:      	subq	%rsi, %rdx
     4e6:      	movl	%ecx, %esi
     4e8:      	andb	$0xf, %sil
     4ec:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     4f1:      	shlxq	%rsi, %rdi, %rsi
     4f6:      	cmpq	%rsi, %rdx
     4f9:      	jae	0x58d <native_tracer_entry+0x58d>
     4ff:      	movq	(%rip), %rax            # 0x506 <native_tracer_entry+0x506>
     506:      	cmpl	$0x0, (%rax)
     509:      	je	0xa48 <native_tracer_entry+0xa48>
     50f:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     519:      	movq	%rax, 0x28(%rsp)
     51e:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     528:      	movq	%rax, 0x20(%rsp)
     52d:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     537:      	movq	%rax, 0x18(%rsp)
     53c:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     546:      	movq	%rax, 0x10(%rsp)
     54b:      	leaq	0x10(%rsp), %rdi
     550:      	movl	$0x20, %eax
     555:      	movl	$0x6, %ecx
     55a:      	movl	0x8(%rsp), %edx
     55e:      	movl	$0x20, %esi
     563:      	xorl	%eax, %eax
     565:      	callq	*%rcx
     567:      	jmp	0xa48 <native_tracer_entry+0xa48>
     56c:      	testl	%eax, %eax
     56e:      	jne	0x130e <native_tracer_entry+0x130e>
     574:      	movl	$0x1, 0xf28(%r15)
     57f:      	movl	$0xfad, %ebp            # imm = 0xFAD
     584:      	jmp	0xb94 <native_tracer_entry+0xb94>
     589:      	xorl	%ebp, %ebp
     58b:      	jmp	0x5c0 <native_tracer_entry+0x5c0>
     58d:      	movl	%ecx, %ebp
     58f:      	andb	$0x10, %bpl
     593:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     598:      	addq	%rdi, %rsi
     59b:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     5a2:      	cmpq	%rsi, %rdx
     5a5:      	jae	0x5c0 <native_tracer_entry+0x5c0>
     5a7:      	andl	$0xf, %ecx
     5aa:      	xorl	%edx, %edx
     5ac:      	testb	%bpl, %bpl
     5af:      	sete	%dl
     5b2:      	leal	0x4(,%rdx,4), %edx
     5b9:      	cmpl	%edx, %ecx
     5bb:      	adcb	$0x0, %cl
     5be:      	jmp	0x5c2 <native_tracer_entry+0x5c2>
     5c0:      	xorl	%ecx, %ecx
     5c2:      	movq	(%rip), %rdx            # 0x5c9 <native_tracer_entry+0x5c9>
     5c9:      	cmpl	$0x0, (%rdx)
     5cc:      	movzbl	%cl, %r14d
     5d0:      	jne	0x12a6 <native_tracer_entry+0x12a6>
     5d6:      	andq	$-0x20, %rax
     5da:      	movzbl	%bpl, %ecx
     5de:      	orq	%rax, %rcx
     5e1:      	orq	%rcx, %r14
     5e4:      	movq	%r14, 0xd0(%rsp)
     5ec:      	movq	(%rip), %rdi            # 0x5f3 <native_tracer_entry+0x5f3>
     5f3:      	xorl	%eax, %eax
     5f5:      	leaq	0x8(%rsp), %rsi
     5fa:      	leaq	0xd0(%rsp), %rdx
     602:      	movl	$0x2, %r8d
     608:      	xorl	%ecx, %ecx
     60a:      	callq	*%r8
     60d:      	testl	%eax, %eax
     60f:      	je	0x715 <native_tracer_entry+0x715>
     615:      	movq	(%rip), %rcx            # 0x61c <native_tracer_entry+0x61c>
     61c:      	cmpl	$0x0, (%rcx)
     61f:      	jne	0x13ed <native_tracer_entry+0x13ed>
     625:      	movl	$0x3d, 0xc4(%rsp)
     630:      	movq	(%rip), %rdi            # 0x637 <native_tracer_entry+0x637>
     637:      	leaq	0xc4(%rsp), %rsi
     63f:      	movl	$0x1, %eax
     644:      	callq	*%rax
     646:      	testq	%rax, %rax
     649:      	je	0x7be <native_tracer_entry+0x7be>
     64f:      	incq	(%rax)
     652:      	xorl	%r14d, %r14d
     655:      	jmp	0xc64 <native_tracer_entry+0xc64>
     65a:      	cmpl	$0x0, (%r12)
     65f:      	jne	0x144e <native_tracer_entry+0x144e>
     665:      	movq	(%rip), %rsi            # 0x66c <native_tracer_entry+0x66c>
     66c:      	movl	$0x400, %eax            # imm = 0x400
     671:      	movl	$0x1b, %ecx
     676:      	movl	$0x400, %edx            # imm = 0x400
     67b:      	movq	%rbx, %rdi
     67e:      	callq	*%rcx
     680:      	movl	%eax, 0x2bc(%r14)
     687:      	cmpl	$0x0, (%r12)
     68c:      	jne	0xe73 <native_tracer_entry+0xe73>
     692:      	movl	$0x0, 0x10(%rsp)
     69a:      	movq	(%rip), %rdi            # 0x6a1 <native_tracer_entry+0x6a1>
     6a1:      	leaq	0x10(%rsp), %rsi
     6a6:      	movl	$0x1, %eax
     6ab:      	callq	*%rax
     6ad:      	testq	%rax, %rax
     6b0:      	je	0x701 <native_tracer_entry+0x701>
     6b2:      	movzbl	0x1384(%rax), %ecx
     6b9:      	cmpb	$0x1d, %cl
     6bc:      	jb	0x79b <native_tracer_entry+0x79b>
     6c2:      	movq	%rax, %r14
     6c5:      	movl	$0x5, 0xf2c(%rax)
     6cf:      	movl	$0x44, 0xd0(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <native_tracer_entry+0x6e1>
     6e1:      	leaq	0xd0(%rsp), %rsi
     6e9:      	movl	$0x1, %eax
     6ee:      	callq	*%rax
     6f0:      	testq	%rax, %rax
     6f3:      	je	0x785 <native_tracer_entry+0x785>
     6f9:      	incq	(%rax)
     6fc:      	jmp	0x790 <native_tracer_entry+0x790>
     701:      	movq	(%rip), %rsi            # 0x708 <native_tracer_entry+0x708>
     708:      	xorl	%r14d, %r14d
     70b:      	movl	$0xc, %eax
     710:      	jmp	0x7b2 <native_tracer_entry+0x7b2>
     715:      	movb	$0x1, 0xf(%rsp)
     71a:      	movq	(%rip), %rdi            # 0x721 <native_tracer_entry+0x721>
     721:      	xorl	%eax, %eax
     723:      	leaq	0xc8(%rsp), %rsi
     72b:      	leaq	0xf(%rsp), %rdx
     730:      	movl	$0x2, %r8d
     736:      	xorl	%ecx, %ecx
     738:      	callq	*%r8
     73b:      	testl	%eax, %eax
     73d:      	je	0x84c <native_tracer_entry+0x84c>
     743:      	movq	(%rip), %rcx            # 0x74a <native_tracer_entry+0x74a>
     74a:      	cmpl	$0x0, (%rcx)
     74d:      	jne	0x16bb <native_tracer_entry+0x16bb>
     753:      	movl	$0x3e, 0xd0(%rsp)
     75e:      	movq	(%rip), %rdi            # 0x765 <native_tracer_entry+0x765>
     765:      	leaq	0xd0(%rsp), %rsi
     76d:      	movl	$0x1, %eax
     772:      	callq	*%rax
     774:      	testq	%rax, %rax
     777:      	je	0x8bd <native_tracer_entry+0x8bd>
     77d:      	incq	(%rax)
     780:      	jmp	0xa48 <native_tracer_entry+0xa48>
     785:      	cmpl	$0x0, (%r12)
     78a:      	jne	0x1528 <native_tracer_entry+0x1528>
     790:      	movq	%r14, %rax
     793:      	movzbl	0x1384(%r14), %ecx
     79b:      	incb	%cl
     79d:      	movb	%cl, 0x1384(%rax)
     7a3:      	movq	(%rip), %rsi            # 0x7aa <native_tracer_entry+0x7aa>
     7aa:      	xorl	%r14d, %r14d
     7ad:      	movl	$0xc, %eax
     7b2:      	movq	%rbx, %rdi
     7b5:      	xorl	%edx, %edx
     7b7:      	callq	*%rax
     7b9:      	jmp	0xc64 <native_tracer_entry+0xc64>
     7be:      	movq	(%rip), %rax            # 0x7c5 <native_tracer_entry+0x7c5>
     7c5:      	cmpl	$0x0, (%rax)
     7c8:      	je	0xa48 <native_tracer_entry+0xa48>
     7ce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     7d8:      	movq	%rax, 0x36(%rsp)
     7dd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     7e7:      	movq	%rax, 0x30(%rsp)
     7ec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     7f6:      	movq	%rax, 0x28(%rsp)
     7fb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     805:      	movq	%rax, 0x20(%rsp)
     80a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     814:      	movq	%rax, 0x18(%rsp)
     819:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     823:      	movq	%rax, 0x10(%rsp)
     828:      	leaq	0x10(%rsp), %rdi
     82d:      	movl	$0x2e, %eax
     832:      	movl	$0x6, %ecx
     837:      	movl	0xc4(%rsp), %edx
     83e:      	movl	$0x2e, %esi
     843:      	xorl	%eax, %eax
     845:      	callq	*%rcx
     847:      	jmp	0xa48 <native_tracer_entry+0xa48>
     84c:      	movl	$0x1, 0xc4(%rsp)
     857:      	movb	$0x1, 0x8(%rsp)
     85c:      	movq	(%rip), %rdi            # 0x863 <native_tracer_entry+0x863>
     863:      	leaq	0xc4(%rsp), %rsi
     86b:      	leaq	0x8(%rsp), %rdx
     870:      	movl	$0x1, %eax
     875:      	movl	$0x2, %r8d
     87b:      	movl	$0x1, %ecx
     880:      	callq	*%r8
     883:      	testl	%eax, %eax
     885:      	js	0x94e <native_tracer_entry+0x94e>
     88b:      	movl	$0x42, 0xd0(%rsp)
     896:      	movq	(%rip), %rdi            # 0x89d <native_tracer_entry+0x89d>
     89d:      	leaq	0xd0(%rsp), %rsi
     8a5:      	movl	$0x1, %eax
     8aa:      	callq	*%rax
     8ac:      	testq	%rax, %rax
     8af:      	je	0x9af <native_tracer_entry+0x9af>
     8b5:      	incq	(%rax)
     8b8:      	jmp	0x9bf <native_tracer_entry+0x9bf>
     8bd:      	movq	(%rip), %rax            # 0x8c4 <native_tracer_entry+0x8c4>
     8c4:      	cmpl	$0x0, (%rax)
     8c7:      	je	0xa48 <native_tracer_entry+0xa48>
     8cd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     8d7:      	movq	%rax, 0x36(%rsp)
     8dc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     8e6:      	movq	%rax, 0x30(%rsp)
     8eb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     8f5:      	movq	%rax, 0x28(%rsp)
     8fa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     904:      	movq	%rax, 0x20(%rsp)
     909:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     913:      	movq	%rax, 0x18(%rsp)
     918:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     922:      	movq	%rax, 0x10(%rsp)
     927:      	leaq	0x10(%rsp), %rdi
     92c:      	movl	$0x2e, %eax
     931:      	movl	$0x6, %ecx
     936:      	movl	0xd0(%rsp), %edx
     93d:      	movl	$0x2e, %esi
     942:      	xorl	%eax, %eax
     944:      	callq	*%rcx
     946:      	xorl	%r14d, %r14d
     949:      	jmp	0xc64 <native_tracer_entry+0xc64>
     94e:      	movq	(%rip), %rax            # 0x955 <native_tracer_entry+0x955>
     955:      	cmpl	$0x0, (%rax)
     958:      	je	0xa0e <native_tracer_entry+0xa0e>
     95e:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     968:      	movq	%rax, 0x20(%rsp)
     96d:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     977:      	movq	%rax, 0x18(%rsp)
     97c:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     986:      	movq	%rax, 0x10(%rsp)
     98b:      	movb	$0x0, 0x28(%rsp)
     990:      	leaq	0x10(%rsp), %rdi
     995:      	movl	$0x19, %eax
     99a:      	movl	$0x6, %ecx
     99f:      	movl	$0x19, %esi
     9a4:      	movl	$0x1, %edx
     9a9:      	xorl	%eax, %eax
     9ab:      	callq	*%rcx
     9ad:      	jmp	0xa0e <native_tracer_entry+0xa0e>
     9af:      	movq	(%rip), %rax            # 0x9b6 <native_tracer_entry+0x9b6>
     9b6:      	cmpl	$0x0, (%rax)
     9b9:      	jne	0x18eb <native_tracer_entry+0x18eb>
     9bf:      	movl	$0x1, 0xd0(%rsp)
     9ca:      	movq	(%rip), %rsi            # 0x9d1 <native_tracer_entry+0x9d1>
     9d1:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     9d6:      	leaq	0xd0(%rsp), %rcx
     9de:      	movl	$0x4, %edx
     9e3:      	movl	$0x19, %r9d
     9e9:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     9ee:      	movq	%rbx, %rdi
     9f1:      	movl	$0x4, %r8d
     9f7:      	callq	*%r9
     9fa:      	testl	%eax, %eax
     9fc:      	jns	0xa0e <native_tracer_entry+0xa0e>
     9fe:      	movq	(%rip), %rcx            # 0xa05 <native_tracer_entry+0xa05>
     a05:      	cmpl	$0x0, (%rcx)
     a08:      	jne	0x185c <native_tracer_entry+0x185c>
     a0e:      	movl	$0x3f, 0xd0(%rsp)
     a19:      	movq	(%rip), %rdi            # 0xa20 <native_tracer_entry+0xa20>
     a20:      	leaq	0xd0(%rsp), %rsi
     a28:      	movl	$0x1, %eax
     a2d:      	callq	*%rax
     a2f:      	testq	%rax, %rax
     a32:      	jne	0x64f <native_tracer_entry+0x64f>
     a38:      	movq	(%rip), %rax            # 0xa3f <native_tracer_entry+0xa3f>
     a3f:      	cmpl	$0x0, (%rax)
     a42:      	jne	0x17de <native_tracer_entry+0x17de>
     a48:      	xorl	%r14d, %r14d
     a4b:      	jmp	0xc64 <native_tracer_entry+0xc64>
     a50:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     a5a:      	movq	%rax, 0x1e(%rsp)
     a5f:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     a69:      	movq	%rax, 0x18(%rsp)
     a6e:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     a78:      	movq	%rax, 0x10(%rsp)
     a7d:      	leaq	0x10(%rsp), %rdi
     a82:      	movl	$0x16, %eax
     a87:      	movl	$0x6, %ecx
     a8c:      	movl	$0x16, %esi
     a91:      	xorl	%eax, %eax
     a93:      	callq	*%rcx
     a95:      	jmp	0x45 <native_tracer_entry+0x45>
     a9a:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     aa4:      	movq	%rax, 0x1e(%rsp)
     aa9:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     ab3:      	movq	%rax, 0x18(%rsp)
     ab8:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     ac2:      	movq	%rax, 0x10(%rsp)
     ac7:      	leaq	0x10(%rsp), %rdi
     acc:      	movl	$0x16, %eax
     ad1:      	movl	$0x6, %ecx
     ad6:      	movl	0x2bc(%r15), %edx
     add:      	movl	$0x16, %esi
     ae2:      	xorl	%eax, %eax
     ae4:      	callq	*%rcx
     ae6:      	movq	(%rbx), %rax
     ae9:      	cmpq	$0x2b, 0xa0(%rax)
     af1:      	je	0x372 <native_tracer_entry+0x372>
     af7:      	movl	$0x23, %eax
     afc:      	callq	*%rax
     afe:      	movq	(%rip), %rcx            # 0xb05 <native_tracer_entry+0xb05>
     b05:      	movl	(%rcx), %edx
     b07:      	addq	%rax, %rdx
     b0a:      	leaq	0x10(%rsp), %rdi
     b0f:      	movl	$0x8, %eax
     b14:      	movl	$0x71, %ecx
     b19:      	movl	$0x8, %esi
     b1e:      	callq	*%rcx
     b20:      	testq	%rax, %rax
     b23:      	jne	0xb54 <native_tracer_entry+0xb54>
     b25:      	movq	(%rip), %rax            # 0xb2c <native_tracer_entry+0xb2c>
     b2c:      	movl	(%rax), %edx
     b2e:      	addq	0x10(%rsp), %rdx
     b33:      	je	0xb54 <native_tracer_entry+0xb54>
     b35:      	leaq	0x10(%rsp), %rdi
     b3a:      	movl	$0xa8, %eax
     b3f:      	movl	$0x71, %ecx
     b44:      	movl	$0xa8, %esi
     b49:      	callq	*%rcx
     b4b:      	testq	%rax, %rax
     b4e:      	je	0xc79 <native_tracer_entry+0xc79>
     b54:      	movl	$0x52, 0xc8(%rsp)
     b5f:      	movq	(%rip), %rdi            # 0xb66 <native_tracer_entry+0xb66>
     b66:      	leaq	0xc8(%rsp), %rsi
     b6e:      	movl	$0x1, %eax
     b73:      	callq	*%rax
     b75:      	testq	%rax, %rax
     b78:      	je	0xb7f <native_tracer_entry+0xb7f>
     b7a:      	incq	(%rax)
     b7d:      	jmp	0xb8f <native_tracer_entry+0xb8f>
     b7f:      	movq	(%rip), %rax            # 0xb86 <native_tracer_entry+0xb86>
     b86:      	cmpl	$0x0, (%rax)
     b89:      	jne	0xec4 <native_tracer_entry+0xec4>
     b8f:      	movl	$0xfa9, %ebp            # imm = 0xFA9
     b94:      	xorl	%r12d, %r12d
     b97:      	movl	%ebp, 0xf2c(%r15)
     b9e:      	movl	$0x0, 0x10(%rsp)
     ba6:      	movq	(%rip), %rdi            # 0xbad <native_tracer_entry+0xbad>
     bad:      	leaq	0x10(%rsp), %rsi
     bb2:      	movl	$0x1, %eax
     bb7:      	callq	*%rax
     bb9:      	testq	%rax, %rax
     bbc:      	je	0xc05 <native_tracer_entry+0xc05>
     bbe:      	movzbl	0x1384(%rax), %ecx
     bc5:      	movl	%r12d, %edx
     bc8:      	cmpb	$0x1d, %cl
     bcb:      	jb	0xc32 <native_tracer_entry+0xc32>
     bcd:      	movq	%rax, %r15
     bd0:      	movl	$0x5, 0xf2c(%rax)
     bda:      	movl	$0x44, 0xd0(%rsp)
     be5:      	movq	(%rip), %rdi            # 0xbec <native_tracer_entry+0xbec>
     bec:      	leaq	0xd0(%rsp), %rsi
     bf4:      	movl	$0x1, %eax
     bf9:      	callq	*%rax
     bfb:      	testq	%rax, %rax
     bfe:      	je	0xc15 <native_tracer_entry+0xc15>
     c00:      	incq	(%rax)
     c03:      	jmp	0xc25 <native_tracer_entry+0xc25>
     c05:      	movq	(%rip), %rcx            # 0xc0c <native_tracer_entry+0xc0c>
     c0c:      	xorl	%edx, %edx
     c0e:      	movl	$0xc, %eax
     c13:      	jmp	0xc48 <native_tracer_entry+0xc48>
     c15:      	movq	(%rip), %rax            # 0xc1c <native_tracer_entry+0xc1c>
     c1c:      	cmpl	$0x0, (%rax)
     c1f:      	jne	0x1228 <native_tracer_entry+0x1228>
     c25:      	movq	%r15, %rax
     c28:      	movzbl	0x1384(%r15), %ecx
     c30:      	xorl	%edx, %edx
     c32:      	incb	%cl
     c34:      	movb	%cl, 0x1384(%rax)
     c3a:      	movl	%edx, %ecx
     c3c:      	movq	(%rip), %rsi            # 0xc43 <native_tracer_entry+0xc43>
     c43:      	movl	$0xc, %eax
     c48:      	movq	(%rip), %rsi            # 0xc4f <native_tracer_entry+0xc4f>
     c4f:      	movq	%rbx, %rdi
     c52:      	callq	*%rax
     c54:      	movq	(%rip), %rax            # 0xc5b <native_tracer_entry+0xc5b>
     c5b:      	cmpl	$0x0, (%rax)
     c5e:      	jne	0xda7 <native_tracer_entry+0xda7>
     c64:      	movl	%r14d, %eax
     c67:      	addq	$0x108, %rsp            # imm = 0x108
     c6e:      	popq	%rbx
     c6f:      	popq	%r12
     c71:      	popq	%r13
     c73:      	popq	%r14
     c75:      	popq	%r15
     c77:      	popq	%rbp
     c78:      	retq
     c79:      	cmpq	$0x2b, 0xb0(%rsp)
     c82:      	jne	0xd9d <native_tracer_entry+0xd9d>
     c88:      	cmpq	$0x23, 0x98(%rsp)
     c91:      	je	0x37c <native_tracer_entry+0x37c>
     c97:      	movq	0x90(%rsp), %rax
     c9f:      	movq	%rax, 0xed0(%r15)
     ca6:      	movq	0xa8(%rsp), %rax
     cae:      	movq	%rax, 0xed8(%r15)
     cb5:      	movq	0x30(%rsp), %rax
     cba:      	movq	%rax, 0xee0(%r15)
     cc1:      	movq	0x60(%rsp), %rax
     cc6:      	movq	%rax, 0xee8(%r15)
     ccd:      	movq	0x50(%rsp), %rax
     cd2:      	movq	%rax, 0xef0(%r15)
     cd9:      	movq	0x40(%rsp), %rax
     cde:      	movq	%rax, 0xef8(%r15)
     ce5:      	movq	0x20(%rsp), %rax
     cea:      	movq	%rax, 0xf00(%r15)
     cf1:      	movq	0x10(%rsp), %rax
     cf6:      	movq	%rax, 0xf08(%r15)
     cfd:      	cmpq	$-0x1, 0x88(%rsp)
     d06:      	setne	0xf30(%r15)
     d0e:      	movq	(%rip), %rax            # 0xd15 <native_tracer_entry+0xd15>
     d15:      	cmpl	$0x0, (%rax)
     d18:      	je	0x410 <native_tracer_entry+0x410>
     d1e:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     d28:      	movq	%rax, 0x2f(%rsp)
     d2d:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     d37:      	movq	%rax, 0x28(%rsp)
     d3c:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     d46:      	movq	%rax, 0x20(%rsp)
     d4b:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     d55:      	movq	%rax, 0x18(%rsp)
     d5a:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     d64:      	movq	%rax, 0x10(%rsp)
     d69:      	leaq	0x10(%rsp), %rdi
     d6e:      	movl	$0x27, %eax
     d73:      	movl	$0x6, %r9d
     d79:      	movq	0xed0(%r15), %rdx
     d80:      	movq	0xed8(%r15), %rcx
     d87:      	movq	0xee0(%r15), %r8
     d8e:      	movl	$0x27, %esi
     d93:      	xorl	%eax, %eax
     d95:      	callq	*%r9
     d98:      	jmp	0x410 <native_tracer_entry+0x410>
     d9d:      	xorl	%r12d, %r12d
     da0:      	xorl	%ebp, %ebp
     da2:      	jmp	0xb97 <native_tracer_entry+0xb97>
     da7:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     db1:      	movq	%rax, 0x38(%rsp)
     db6:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     dc0:      	movq	%rax, 0x30(%rsp)
     dc5:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     dcf:      	movq	%rax, 0x28(%rsp)
     dd4:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     dde:      	movq	%rax, 0x20(%rsp)
     de3:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     ded:      	movq	%rax, 0x18(%rsp)
     df2:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     dfc:      	movq	%rax, 0x10(%rsp)
     e01:      	movl	$0xa7972, 0x40(%rsp)    # imm = 0xA7972
     e09:      	leaq	0x10(%rsp), %rdi
     e0e:      	movl	$0x34, %eax
     e13:      	movl	$0x6, %ecx
     e18:      	movl	$0x34, %esi
     e1d:      	movl	%r12d, %edx
     e20:      	xorl	%eax, %eax
     e22:      	callq	*%rcx
     e24:      	jmp	0xc64 <native_tracer_entry+0xc64>
     e29:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     e33:      	movq	%rax, 0x1e(%rsp)
     e38:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     e42:      	movq	%rax, 0x18(%rsp)
     e47:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     e51:      	movq	%rax, 0x10(%rsp)
     e56:      	leaq	0x10(%rsp), %rdi
     e5b:      	movl	$0x16, %eax
     e60:      	movl	$0x6, %ecx
     e65:      	movl	$0x16, %esi
     e6a:      	xorl	%eax, %eax
     e6c:      	callq	*%rcx
     e6e:      	jmp	0x1c9 <native_tracer_entry+0x1c9>
     e73:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     e7d:      	movq	%rax, 0x1e(%rsp)
     e82:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     e8c:      	movq	%rax, 0x18(%rsp)
     e91:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     e9b:      	movq	%rax, 0x10(%rsp)
     ea0:      	leaq	0x10(%rsp), %rdi
     ea5:      	movl	$0x16, %eax
     eaa:      	movl	$0x6, %ecx
     eaf:      	movl	0x2bc(%r14), %edx
     eb6:      	movl	$0x16, %esi
     ebb:      	xorl	%eax, %eax
     ebd:      	callq	*%rcx
     ebf:      	jmp	0x692 <native_tracer_entry+0x692>
     ec4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     ece:      	movq	%rax, 0xf6(%rsp)
     ed6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ee0:      	movq	%rax, 0xf0(%rsp)
     ee8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ef2:      	movq	%rax, 0xe8(%rsp)
     efa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f04:      	movq	%rax, 0xe0(%rsp)
     f0c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f16:      	movq	%rax, 0xd8(%rsp)
     f1e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f28:      	movq	%rax, 0xd0(%rsp)
     f30:      	leaq	0xd0(%rsp), %rdi
     f38:      	movl	$0x2e, %eax
     f3d:      	movl	$0x6, %ecx
     f42:      	movl	0xc8(%rsp), %edx
     f49:      	movl	$0x2e, %esi
     f4e:      	xorl	%eax, %eax
     f50:      	callq	*%rcx
     f52:      	jmp	0xb8f <native_tracer_entry+0xb8f>
     f57:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f61:      	movq	%rax, 0x36(%rsp)
     f66:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f70:      	movq	%rax, 0x30(%rsp)
     f75:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f7f:      	movq	%rax, 0x28(%rsp)
     f84:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f8e:      	movq	%rax, 0x20(%rsp)
     f93:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f9d:      	movq	%rax, 0x18(%rsp)
     fa2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     fac:      	movq	%rax, 0x10(%rsp)
     fb1:      	leaq	0x10(%rsp), %rdi
     fb6:      	movl	$0x2e, %eax
     fbb:      	movl	$0x6, %ecx
     fc0:      	movl	0xd0(%rsp), %edx
     fc7:      	movl	$0x2e, %esi
     fcc:      	xorl	%eax, %eax
     fce:      	callq	*%rcx
     fd0:      	jmp	0x32f <native_tracer_entry+0x32f>
     fd5:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     fdf:      	movq	%rax, 0x38(%rsp)
     fe4:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     fee:      	movq	%rax, 0x30(%rsp)
     ff3:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     ffd:      	movq	%rax, 0x28(%rsp)
    1002:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    100c:      	movq	%rax, 0x20(%rsp)
    1011:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    101b:      	movq	%rax, 0x18(%rsp)
    1020:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    102a:      	movq	%rax, 0x10(%rsp)
    102f:      	movb	$0x0, 0x40(%rsp)
    1034:      	leaq	0x10(%rsp), %rdi
    1039:      	movl	$0x31, %eax
    103e:      	movl	$0x6, %ecx
    1043:      	movl	0x2c0(%r15), %edx
    104a:      	movl	$0x31, %esi
    104f:      	xorl	%eax, %eax
    1051:      	callq	*%rcx
    1053:      	movq	0xed0(%r15), %r13
    105a:      	movq	%r13, %rax
    105d:      	shrq	$0x38, %rax
    1061:      	jne	0x473 <native_tracer_entry+0x473>
    1067:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    106e:      	ja	0x1095 <native_tracer_entry+0x1095>
    1070:      	movq	(%rip), %rax            # 0x1077 <native_tracer_entry+0x1077>
    1077:      	cmpl	$0x0, (%rax)
    107a:      	jne	0x14cc <native_tracer_entry+0x14cc>
    1080:      	movl	$0x31, 0xf28(%r15)
    108b:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1090:      	jmp	0xb94 <native_tracer_entry+0xb94>
    1095:      	movl	(%r15), %eax
    1098:      	movl	$0x60, 0xd0(%rsp)
    10a3:      	movbel	%eax, 0xd4(%rsp)
    10ac:      	movbeq	%r13, 0xd8(%rsp)
    10b6:      	movq	(%rip), %rdi            # 0x10bd <native_tracer_entry+0x10bd>
    10bd:      	leaq	0xd0(%rsp), %rsi
    10c5:      	movl	$0x1, %eax
    10ca:      	callq	*%rax
    10cc:      	testq	%rax, %rax
    10cf:      	je	0x1203 <native_tracer_entry+0x1203>
    10d5:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    10df:      	movq	0x8(%rax), %r12
    10e3:      	andq	%r12, %rcx
    10e6:      	movq	%rcx, 0xf20(%r15)
    10ed:      	movq	(%rax), %rax
    10f0:      	movq	%rax, 0xf10(%r15)
    10f7:      	shrq	$0x38, %r12
    10fb:      	movq	%r13, %rax
    10fe:      	subq	%rcx, %rax
    1101:      	movq	%rax, 0xf18(%r15)
    1108:      	movq	(%rip), %rax            # 0x110f <native_tracer_entry+0x110f>
    110f:      	cmpl	$0x0, (%rax)
    1112:      	jne	0x15a6 <native_tracer_entry+0x15a6>
    1118:      	xorl	%ebp, %ebp
    111a:      	cmpl	$0x1, %r12d
    111e:      	jne	0xb97 <native_tracer_entry+0xb97>
    1124:      	movq	0xf10(%r15), %rax
    112b:      	movq	%rax, 0xd0(%rsp)
    1133:      	movq	0xf18(%r15), %r13
    113a:      	movq	(%rip), %rdi            # 0x1141 <native_tracer_entry+0x1141>
    1141:      	leaq	0xd0(%rsp), %rsi
    1149:      	movl	$0x1, %eax
    114e:      	callq	*%rax
    1150:      	movl	$0x1, %r12d
    1156:      	testq	%rax, %rax
    1159:      	je	0xb97 <native_tracer_entry+0xb97>
    115f:      	cmpq	%r13, (%rax)
    1162:      	ja	0x116a <native_tracer_entry+0x116a>
    1164:      	cmpq	%r13, 0x8(%rax)
    1168:      	jae	0x117e <native_tracer_entry+0x117e>
    116a:      	cmpq	%r13, 0x10(%rax)
    116e:      	ja	0xb97 <native_tracer_entry+0xb97>
    1174:      	cmpq	%r13, 0x18(%rax)
    1178:      	jb	0xb97 <native_tracer_entry+0xb97>
    117e:      	movq	(%rip), %rcx            # 0x1185 <native_tracer_entry+0x1185>
    1185:      	cmpl	$0x0, (%rcx)
    1188:      	jne	0x1969 <native_tracer_entry+0x1969>
    118e:      	movl	0x1380(%r15), %ecx
    1195:      	movl	0x20(%rax), %edx
    1198:      	btl	%edx, %ecx
    119b:      	jae	0x19dc <native_tracer_entry+0x19dc>
    11a1:      	movq	(%rip), %rax            # 0x11a8 <native_tracer_entry+0x11a8>
    11a8:      	cmpl	$0x0, (%rax)
    11ab:      	je	0xb97 <native_tracer_entry+0xb97>
    11b1:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    11bb:      	movq	%rax, 0x20(%rsp)
    11c0:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    11ca:      	movq	%rax, 0x18(%rsp)
    11cf:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    11d9:      	movq	%rax, 0x10(%rsp)
    11de:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    11e6:      	leaq	0x10(%rsp), %rdi
    11eb:      	movl	$0x1b, %eax
    11f0:      	movl	$0x6, %ecx
    11f5:      	movl	$0x1b, %esi
    11fa:      	xorl	%eax, %eax
    11fc:      	callq	*%rcx
    11fe:      	jmp	0xb97 <native_tracer_entry+0xb97>
    1203:      	movq	(%rip), %rax            # 0x120a <native_tracer_entry+0x120a>
    120a:      	cmpl	$0x0, (%rax)
    120d:      	jne	0x1750 <native_tracer_entry+0x1750>
    1213:      	movl	$0xc, 0xf28(%r15)
    121e:      	movl	$0xfac, %ebp            # imm = 0xFAC
    1223:      	jmp	0xb94 <native_tracer_entry+0xb94>
    1228:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1232:      	movq	%rax, 0x36(%rsp)
    1237:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1241:      	movq	%rax, 0x30(%rsp)
    1246:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1250:      	movq	%rax, 0x28(%rsp)
    1255:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    125f:      	movq	%rax, 0x20(%rsp)
    1264:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    126e:      	movq	%rax, 0x18(%rsp)
    1273:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    127d:      	movq	%rax, 0x10(%rsp)
    1282:      	leaq	0x10(%rsp), %rdi
    1287:      	movl	$0x2e, %eax
    128c:      	movl	$0x6, %ecx
    1291:      	movl	0xd0(%rsp), %edx
    1298:      	movl	$0x2e, %esi
    129d:      	xorl	%eax, %eax
    129f:      	callq	*%rcx
    12a1:      	jmp	0xc25 <native_tracer_entry+0xc25>
    12a6:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
    12b0:      	movq	%rcx, 0x27(%rsp)
    12b5:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
    12bf:      	movq	%rcx, 0x20(%rsp)
    12c4:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
    12ce:      	movq	%rcx, 0x18(%rsp)
    12d3:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
    12dd:      	movq	%rcx, 0x10(%rsp)
    12e2:      	leaq	0x10(%rsp), %rdi
    12e7:      	movl	$0x1f, %ecx
    12ec:      	movl	$0x6, %r8d
    12f2:      	movl	0x8(%rsp), %edx
    12f6:      	movl	$0x1f, %esi
    12fb:      	movl	%r14d, %ecx
    12fe:      	movq	%rax, %r15
    1301:      	xorl	%eax, %eax
    1303:      	callq	*%r8
    1306:      	movq	%r15, %rax
    1309:      	jmp	0x5d6 <native_tracer_entry+0x5d6>
    130e:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    1318:      	movq	%rax, 0x38(%rsp)
    131d:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    1327:      	movq	%rax, 0x30(%rsp)
    132c:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    1336:      	movq	%rax, 0x28(%rsp)
    133b:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    1345:      	movq	%rax, 0x20(%rsp)
    134a:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    1354:      	movq	%rax, 0x18(%rsp)
    1359:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    1363:      	movq	%rax, 0x10(%rsp)
    1368:      	movb	$0x0, 0x40(%rsp)
    136d:      	leaq	0x10(%rsp), %rdi
    1372:      	movl	$0x31, %eax
    1377:      	movl	$0x6, %ecx
    137c:      	movl	$0x31, %esi
    1381:      	xorl	%eax, %eax
    1383:      	callq	*%rcx
    1385:      	jmp	0x574 <native_tracer_entry+0x574>
    138a:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1394:      	movq	%rax, 0x28(%rsp)
    1399:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    13a3:      	movq	%rax, 0x20(%rsp)
    13a8:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    13b2:      	movq	%rax, 0x18(%rsp)
    13b7:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    13c1:      	movq	%rax, 0x10(%rsp)
    13c6:      	movw	$0xa, 0x30(%rsp)
    13cd:      	leaq	0x10(%rsp), %rdi
    13d2:      	movl	$0x22, %eax
    13d7:      	movl	$0x6, %ecx
    13dc:      	movl	$0x22, %esi
    13e1:      	movq	%r13, %rdx
    13e4:      	xorl	%eax, %eax
    13e6:      	callq	*%rcx
    13e8:      	jmp	0x483 <native_tracer_entry+0x483>
    13ed:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    13f7:      	movq	%rcx, 0x25(%rsp)
    13fc:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    1406:      	movq	%rcx, 0x20(%rsp)
    140b:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    1415:      	movq	%rcx, 0x18(%rsp)
    141a:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1424:      	movq	%rcx, 0x10(%rsp)
    1429:      	leaq	0x10(%rsp), %rdi
    142e:      	movl	$0x1d, %ecx
    1433:      	movl	$0x6, %r8d
    1439:      	movl	0x8(%rsp), %edx
    143d:      	movl	$0x1d, %esi
    1442:      	movl	%eax, %ecx
    1444:      	xorl	%eax, %eax
    1446:      	callq	*%r8
    1449:      	jmp	0x625 <native_tracer_entry+0x625>
    144e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1458:      	movq	%rax, 0x36(%rsp)
    145d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1467:      	movq	%rax, 0x30(%rsp)
    146c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1476:      	movq	%rax, 0x28(%rsp)
    147b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1485:      	movq	%rax, 0x20(%rsp)
    148a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1494:      	movq	%rax, 0x18(%rsp)
    1499:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    14a3:      	movq	%rax, 0x10(%rsp)
    14a8:      	leaq	0x10(%rsp), %rdi
    14ad:      	movl	$0x2e, %eax
    14b2:      	movl	$0x6, %ecx
    14b7:      	movl	0xd0(%rsp), %edx
    14be:      	movl	$0x2e, %esi
    14c3:      	xorl	%eax, %eax
    14c5:      	callq	*%rcx
    14c7:      	jmp	0x665 <native_tracer_entry+0x665>
    14cc:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    14d6:      	movq	%rax, 0x26(%rsp)
    14db:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    14e5:      	movq	%rax, 0x20(%rsp)
    14ea:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    14f4:      	movq	%rax, 0x18(%rsp)
    14f9:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    1503:      	movq	%rax, 0x10(%rsp)
    1508:      	leaq	0x10(%rsp), %rdi
    150d:      	movl	$0x1e, %eax
    1512:      	movl	$0x6, %ecx
    1517:      	movl	$0x1e, %esi
    151c:      	movq	%r13, %rdx
    151f:      	xorl	%eax, %eax
    1521:      	callq	*%rcx
    1523:      	jmp	0x1080 <native_tracer_entry+0x1080>
    1528:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1532:      	movq	%rax, 0x36(%rsp)
    1537:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1541:      	movq	%rax, 0x30(%rsp)
    1546:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1550:      	movq	%rax, 0x28(%rsp)
    1555:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    155f:      	movq	%rax, 0x20(%rsp)
    1564:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    156e:      	movq	%rax, 0x18(%rsp)
    1573:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    157d:      	movq	%rax, 0x10(%rsp)
    1582:      	leaq	0x10(%rsp), %rdi
    1587:      	movl	$0x2e, %eax
    158c:      	movl	$0x6, %ecx
    1591:      	movl	0xd0(%rsp), %edx
    1598:      	movl	$0x2e, %esi
    159d:      	xorl	%eax, %eax
    159f:      	callq	*%rcx
    15a1:      	jmp	0x790 <native_tracer_entry+0x790>
    15a6:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    15b0:      	movq	%rax, 0x38(%rsp)
    15b5:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    15bf:      	movq	%rax, 0x30(%rsp)
    15c4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    15ce:      	movq	%rax, 0x28(%rsp)
    15d3:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    15dd:      	movq	%rax, 0x20(%rsp)
    15e2:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    15ec:      	movq	%rax, 0x18(%rsp)
    15f1:      	movabsq	$0x6365732074786554, %rbp # imm = 0x6365732074786554
    15fb:      	movq	%rbp, 0x10(%rsp)
    1600:      	movw	$0xa, 0x40(%rsp)
    1607:      	leaq	0x10(%rsp), %rdi
    160c:      	movl	$0x32, %eax
    1611:      	movl	$0x6, %r9d
    1617:      	movq	0xf10(%r15), %rcx
    161e:      	movl	$0x32, %esi
    1623:      	movq	%r13, %rdx
    1626:      	movl	%r12d, %r8d
    1629:      	xorl	%eax, %eax
    162b:      	callq	*%r9
    162e:      	movq	(%rip), %rax            # 0x1635 <native_tracer_entry+0x1635>
    1635:      	cmpl	$0x0, (%rax)
    1638:      	je	0x1118 <native_tracer_entry+0x1118>
    163e:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    1648:      	movq	%rax, 0x37(%rsp)
    164d:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    1657:      	movq	%rax, 0x30(%rsp)
    165c:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1666:      	movq	%rax, 0x28(%rsp)
    166b:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1675:      	movq	%rax, 0x20(%rsp)
    167a:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1684:      	movq	%rax, 0x18(%rsp)
    1689:      	movq	%rbp, 0x10(%rsp)
    168e:      	leaq	0x10(%rsp), %rdi
    1693:      	movl	$0x2f, %eax
    1698:      	movl	$0x6, %r8d
    169e:      	movq	0xf18(%r15), %rcx
    16a5:      	movq	0xf20(%r15), %rdx
    16ac:      	movl	$0x2f, %esi
    16b1:      	xorl	%eax, %eax
    16b3:      	callq	*%r8
    16b6:      	jmp	0x1118 <native_tracer_entry+0x1118>
    16bb:      	movl	0xc8(%rsp), %ecx
    16c2:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    16cc:      	movq	%rdx, 0x3d(%rsp)
    16d1:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    16db:      	movq	%rdx, 0x38(%rsp)
    16e0:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    16ea:      	movq	%rdx, 0x30(%rsp)
    16ef:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    16f9:      	movq	%rdx, 0x28(%rsp)
    16fe:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    1708:      	movq	%rdx, 0x20(%rsp)
    170d:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    1717:      	movq	%rdx, 0x18(%rsp)
    171c:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    1726:      	movq	%rdx, 0x10(%rsp)
    172b:      	leaq	0x10(%rsp), %rdi
    1730:      	movl	$0x35, %edx
    1735:      	movl	$0x6, %r9d
    173b:      	movl	$0x35, %esi
    1740:      	movl	%r12d, %edx
    1743:      	movl	%eax, %r8d
    1746:      	xorl	%eax, %eax
    1748:      	callq	*%r9
    174b:      	jmp	0x753 <native_tracer_entry+0x753>
    1750:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    175a:      	movq	%rax, 0x40(%rsp)
    175f:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    1769:      	movq	%rax, 0x38(%rsp)
    176e:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    1778:      	movq	%rax, 0x30(%rsp)
    177d:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    1787:      	movq	%rax, 0x28(%rsp)
    178c:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    1796:      	movq	%rax, 0x20(%rsp)
    179b:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    17a5:      	movq	%rax, 0x18(%rsp)
    17aa:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    17b4:      	movq	%rax, 0x10(%rsp)
    17b9:      	movb	$0x0, 0x48(%rsp)
    17be:      	leaq	0x10(%rsp), %rdi
    17c3:      	movl	$0x39, %eax
    17c8:      	movl	$0x6, %ecx
    17cd:      	movl	$0x39, %esi
    17d2:      	movq	%r13, %rdx
    17d5:      	xorl	%eax, %eax
    17d7:      	callq	*%rcx
    17d9:      	jmp	0x1213 <native_tracer_entry+0x1213>
    17de:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17e8:      	movq	%rax, 0x36(%rsp)
    17ed:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17f7:      	movq	%rax, 0x30(%rsp)
    17fc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1806:      	movq	%rax, 0x28(%rsp)
    180b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1815:      	movq	%rax, 0x20(%rsp)
    181a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1824:      	movq	%rax, 0x18(%rsp)
    1829:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1833:      	movq	%rax, 0x10(%rsp)
    1838:      	leaq	0x10(%rsp), %rdi
    183d:      	movl	$0x2e, %eax
    1842:      	movl	$0x6, %ecx
    1847:      	movl	0xd0(%rsp), %edx
    184e:      	movl	$0x2e, %esi
    1853:      	xorl	%eax, %eax
    1855:      	callq	*%rcx
    1857:      	jmp	0xa48 <native_tracer_entry+0xa48>
    185c:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    1866:      	movq	%rcx, 0x3e(%rsp)
    186b:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    1875:      	movq	%rcx, 0x38(%rsp)
    187a:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    1884:      	movq	%rcx, 0x30(%rsp)
    1889:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    1893:      	movq	%rcx, 0x28(%rsp)
    1898:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    18a2:      	movq	%rcx, 0x20(%rsp)
    18a7:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    18b1:      	movq	%rcx, 0x18(%rsp)
    18b6:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    18c0:      	movq	%rcx, 0x10(%rsp)
    18c5:      	leaq	0x10(%rsp), %rdi
    18ca:      	movl	$0x36, %ecx
    18cf:      	movl	$0x6, %r8d
    18d5:      	movl	$0x36, %esi
    18da:      	movl	$0x1, %edx
    18df:      	movl	%eax, %ecx
    18e1:      	xorl	%eax, %eax
    18e3:      	callq	*%r8
    18e6:      	jmp	0xa0e <native_tracer_entry+0xa0e>
    18eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    18f5:      	movq	%rax, 0x36(%rsp)
    18fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1904:      	movq	%rax, 0x30(%rsp)
    1909:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1913:      	movq	%rax, 0x28(%rsp)
    1918:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1922:      	movq	%rax, 0x20(%rsp)
    1927:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1931:      	movq	%rax, 0x18(%rsp)
    1936:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1940:      	movq	%rax, 0x10(%rsp)
    1945:      	leaq	0x10(%rsp), %rdi
    194a:      	movl	$0x2e, %eax
    194f:      	movl	$0x6, %ecx
    1954:      	movl	0xd0(%rsp), %edx
    195b:      	movl	$0x2e, %esi
    1960:      	xorl	%eax, %eax
    1962:      	callq	*%rcx
    1964:      	jmp	0x9bf <native_tracer_entry+0x9bf>
    1969:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1973:      	movq	%rcx, 0x26(%rsp)
    1978:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1982:      	movq	%rcx, 0x20(%rsp)
    1987:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    1991:      	movq	%rcx, 0x18(%rsp)
    1996:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    19a0:      	movq	%rcx, 0x10(%rsp)
    19a5:      	leaq	0x10(%rsp), %rdi
    19aa:      	movl	$0x1e, %ecx
    19af:      	movl	$0x6, %r8d
    19b5:      	movzwl	0x20(%rax), %edx
    19b9:      	movl	$0x1e, %esi
    19be:      	movq	%rax, %r13
    19c1:      	xorl	%eax, %eax
    19c3:      	callq	*%r8
    19c6:      	movq	%r13, %rax
    19c9:      	movl	0x1380(%r15), %ecx
    19d0:      	movl	0x20(%rax), %edx
    19d3:      	btl	%edx, %ecx
    19d6:      	jb	0x11a1 <native_tracer_entry+0x11a1>
    19dc:      	movq	%rax, %r12
    19df:      	movl	$0x0, 0xc8(%rsp)
    19ea:      	movq	(%rip), %rdi            # 0x19f1 <native_tracer_entry+0x19f1>
    19f1:      	leaq	0xc8(%rsp), %rsi
    19f9:      	movl	$0x1, %eax
    19fe:      	callq	*%rax
    1a00:      	testq	%rax, %rax
    1a03:      	je	0x1a0d <native_tracer_entry+0x1a0d>
    1a05:      	incq	(%rax)
    1a08:      	movq	%r12, %rax
    1a0b:      	jmp	0x1a1c <native_tracer_entry+0x1a1c>
    1a0d:      	movq	(%rip), %rax            # 0x1a14 <native_tracer_entry+0x1a14>
    1a14:      	cmpl	$0x0, (%rax)
    1a17:      	movq	%r12, %rax
    1a1a:      	jne	0x1a26 <native_tracer_entry+0x1a26>
    1a1c:      	movzwl	0x20(%rax), %r12d
    1a21:      	jmp	0xb97 <native_tracer_entry+0xb97>
    1a26:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a30:      	movq	%rax, 0x36(%rsp)
    1a35:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a3f:      	movq	%rax, 0x30(%rsp)
    1a44:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a4e:      	movq	%rax, 0x28(%rsp)
    1a53:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a5d:      	movq	%rax, 0x20(%rsp)
    1a62:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a6c:      	movq	%rax, 0x18(%rsp)
    1a71:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a7b:      	movq	%rax, 0x10(%rsp)
    1a80:      	leaq	0x10(%rsp), %rdi
    1a85:      	movl	$0x2e, %eax
    1a8a:      	movl	$0x6, %ecx
    1a8f:      	movl	0xc8(%rsp), %edx
    1a96:      	movl	$0x2e, %esi
    1a9b:      	xorl	%eax, %eax
    1a9d:      	callq	*%rcx
    1a9f:      	jmp	0x1a08 <native_tracer_entry+0x1a08>
