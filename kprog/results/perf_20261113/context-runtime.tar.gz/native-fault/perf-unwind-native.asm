
corpus/results/perf-context-20261113/otelcol-ebpf-profiler.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_native:

0000000000000000 <perf_unwind_native>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x168, %rsp            # imm = 0x168
      11:      	movq	%rdi, %rbp
      14:      	movl	$0x0, 0xa0(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <perf_unwind_native+0x26>
      26:      	leaq	0xa0(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x6092 <perf_unwind_native+0x6092>
      3e:      	movq	%rax, 0x98(%rsp)
      46:      	movq	%rax, %rbx
      49:      	movq	(%rip), %r13            # 0x50 <perf_unwind_native+0x50>
      50:      	cmpl	$0x0, (%r13)
      55:      	jne	0xebc <perf_unwind_native+0xebc>
      5b:      	movl	$0x5, 0x10(%rsp)
      63:      	movq	(%rip), %rdi            # 0x6a <perf_unwind_native+0x6a>
      6a:      	leaq	0x10(%rsp), %rsi
      6f:      	movl	$0x1, %eax
      74:      	callq	*%rax
      76:      	testq	%rax, %rax
      79:      	je	0x126 <perf_unwind_native+0x126>
      7f:      	incq	(%rax)
      82:      	cmpl	$0x0, (%r13)
      87:      	je	0x131 <perf_unwind_native+0x131>
      8d:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
      97:      	movq	%rax, 0xc0(%rsp)
      9f:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
      a9:      	movq	%rax, 0xb8(%rsp)
      b1:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
      bb:      	movq	%rax, 0xb0(%rsp)
      c3:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
      cd:      	movq	%rax, 0xa8(%rsp)
      d5:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
      df:      	movq	%rax, 0xa0(%rsp)
      e7:      	movl	$0xa6b63, 0xc7(%rsp)    # imm = 0xA6B63
      f2:      	leaq	0xa0(%rsp), %rdi
      fa:      	movl	$0x2b, %eax
      ff:      	movl	$0x6, %r9d
     105:      	movq	0xf10(%rbx), %rdx
     10c:      	movq	0xf18(%rbx), %rcx
     113:      	movl	0x2c0(%rbx), %r8d
     11a:      	movl	$0x2b, %esi
     11f:      	xorl	%eax, %eax
     121:      	callq	*%r9
     124:      	jmp	0x131 <perf_unwind_native+0x131>
     126:      	cmpl	$0x0, (%r13)
     12b:      	jne	0x100b <perf_unwind_native+0x100b>
     131:      	movl	0x2c0(%rbx), %eax
     137:      	cmpq	$0x7f, %rax
     13b:      	jb	0x1f2 <perf_unwind_native+0x1f2>
     141:      	cmpl	$0x0, (%r13)
     146:      	jne	0xf23 <perf_unwind_native+0xf23>
     14c:      	movl	$0x2, 0x10(%rsp)
     154:      	movq	(%rip), %rdi            # 0x15b <perf_unwind_native+0x15b>
     15b:      	leaq	0x10(%rsp), %rsi
     160:      	movl	$0x1, %eax
     165:      	callq	*%rax
     167:      	testq	%rax, %rax
     16a:      	je	0x2e8 <perf_unwind_native+0x2e8>
     170:      	incq	(%rax)
     173:      	xorl	%r12d, %r12d
     176:      	cmpl	$0x0, (%r13)
     17b:      	movl	$0x2, %r14d
     181:      	je	0x5fd4 <perf_unwind_native+0x5fd4>
     187:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     191:      	movq	%rax, 0xb5(%rsp)
     199:      	movabsq	$0x7266206576697461, %rax # imm = 0x7266206576697461
     1a3:      	movq	%rax, 0xb0(%rsp)
     1ab:      	movabsq	$0x6e2068737570206f, %rax # imm = 0x6E2068737570206F
     1b5:      	movq	%rax, 0xa8(%rsp)
     1bd:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     1c7:      	movq	%rax, 0xa0(%rsp)
     1cf:      	leaq	0xa0(%rsp), %rdi
     1d7:      	movl	$0x1d, %eax
     1dc:      	movl	$0x6, %ecx
     1e1:      	xorl	%r12d, %r12d
     1e4:      	movl	$0x1d, %esi
     1e9:      	xorl	%eax, %eax
     1eb:      	callq	*%rcx
     1ed:      	jmp	0x5fd4 <perf_unwind_native+0x5fd4>
     1f2:      	movzbl	0xf30(%rbx), %ecx
     1f9:      	movq	0xf10(%rbx), %rdx
     200:      	movq	0xf18(%rbx), %rsi
     207:      	leal	0x1(%rax), %edi
     20a:      	movl	%edi, 0x2c0(%rbx)
     210:      	leaq	(%rax,%rax,2), %rax
     214:      	movq	%rdx, 0x2d0(%rbx,%rax,8)
     21c:      	movq	%rsi, 0x2d8(%rbx,%rax,8)
     224:      	movb	$0x3, 0x2e0(%rbx,%rax,8)
     22c:      	movb	%cl, 0x2e1(%rbx,%rax,8)
     233:      	movl	$0x0, 0x2e2(%rbx,%rax,8)
     23e:      	movw	$0x0, 0x2e6(%rbx,%rax,8)
     248:      	movl	$0x0, 0x8c(%rsp)
     253:      	movq	0xf10(%rbx), %rax
     25a:      	movq	%rax, 0x160(%rsp)
     262:      	movq	%rax, 0x78(%rsp)
     267:      	movq	$-0x10000, %rax         # imm = 0xFFFF0000
     26e:      	andq	0xf18(%rbx), %rax
     275:      	movq	%rax, 0x80(%rsp)
     27d:      	cmpl	$0x0, (%r13)
     282:      	jne	0xf9d <perf_unwind_native+0xf9d>
     288:      	movq	(%rip), %rdi            # 0x28f <perf_unwind_native+0x28f>
     28f:      	leaq	0x78(%rsp), %rsi
     294:      	movl	$0x1, %eax
     299:      	callq	*%rax
     29b:      	testq	%rax, %rax
     29e:      	je	0x56e8 <perf_unwind_native+0x56e8>
     2a4:      	movq	%rax, %r14
     2a7:      	movq	%rbp, 0x68(%rsp)
     2ac:      	movq	%rax, %rbp
     2af:      	addq	$0x6, %rbp
     2b3:      	movzwl	0x6(%rax), %eax
     2b7:      	cmpl	$0xf, %eax
     2ba:      	jg	0x301 <perf_unwind_native+0x301>
     2bc:      	cmpl	$0xb, %eax
     2bf:      	jg	0x329 <perf_unwind_native+0x329>
     2c1:      	cmpl	$0x9, %eax
     2c4:      	jg	0x36f <perf_unwind_native+0x36f>
     2ca:      	cmpl	$0x8, %eax
     2cd:      	je	0x3ce <perf_unwind_native+0x3ce>
     2d3:      	cmpl	$0x9, %eax
     2d6:      	jne	0x586e <perf_unwind_native+0x586e>
     2dc:      	movq	(%rip), %rdi            # 0x2e3 <perf_unwind_native+0x2e3>
     2e3:      	jmp	0x414 <perf_unwind_native+0x414>
     2e8:      	cmpl	$0x0, (%r13)
     2ed:      	jne	0x10a6 <perf_unwind_native+0x10a6>
     2f3:      	movl	$0x2, %r14d
     2f9:      	xorl	%r12d, %r12d
     2fc:      	jmp	0x5fd4 <perf_unwind_native+0x5fd4>
     301:      	cmpl	$0x13, %eax
     304:      	jg	0x34c <perf_unwind_native+0x34c>
     306:      	cmpl	$0x11, %eax
     309:      	jg	0x389 <perf_unwind_native+0x389>
     30b:      	cmpl	$0x10, %eax
     30e:      	je	0x3d7 <perf_unwind_native+0x3d7>
     314:      	cmpl	$0x11, %eax
     317:      	jne	0x586e <perf_unwind_native+0x586e>
     31d:      	movq	(%rip), %rdi            # 0x324 <perf_unwind_native+0x324>
     324:      	jmp	0x414 <perf_unwind_native+0x414>
     329:      	cmpl	$0xd, %eax
     32c:      	jg	0x3a0 <perf_unwind_native+0x3a0>
     32e:      	cmpl	$0xc, %eax
     331:      	je	0x3e0 <perf_unwind_native+0x3e0>
     337:      	cmpl	$0xd, %eax
     33a:      	jne	0x586e <perf_unwind_native+0x586e>
     340:      	movq	(%rip), %rdi            # 0x347 <perf_unwind_native+0x347>
     347:      	jmp	0x414 <perf_unwind_native+0x414>
     34c:      	cmpl	$0x15, %eax
     34f:      	jg	0x3b7 <perf_unwind_native+0x3b7>
     351:      	cmpl	$0x14, %eax
     354:      	je	0x3e9 <perf_unwind_native+0x3e9>
     35a:      	cmpl	$0x15, %eax
     35d:      	jne	0x586e <perf_unwind_native+0x586e>
     363:      	movq	(%rip), %rdi            # 0x36a <perf_unwind_native+0x36a>
     36a:      	jmp	0x414 <perf_unwind_native+0x414>
     36f:      	cmpl	$0xa, %eax
     372:      	je	0x3f2 <perf_unwind_native+0x3f2>
     374:      	cmpl	$0xb, %eax
     377:      	jne	0x586e <perf_unwind_native+0x586e>
     37d:      	movq	(%rip), %rdi            # 0x384 <perf_unwind_native+0x384>
     384:      	jmp	0x414 <perf_unwind_native+0x414>
     389:      	cmpl	$0x12, %eax
     38c:      	je	0x3fb <perf_unwind_native+0x3fb>
     38e:      	cmpl	$0x13, %eax
     391:      	jne	0x586e <perf_unwind_native+0x586e>
     397:      	movq	(%rip), %rdi            # 0x39e <perf_unwind_native+0x39e>
     39e:      	jmp	0x414 <perf_unwind_native+0x414>
     3a0:      	cmpl	$0xe, %eax
     3a3:      	je	0x404 <perf_unwind_native+0x404>
     3a5:      	cmpl	$0xf, %eax
     3a8:      	jne	0x586e <perf_unwind_native+0x586e>
     3ae:      	movq	(%rip), %rdi            # 0x3b5 <perf_unwind_native+0x3b5>
     3b5:      	jmp	0x414 <perf_unwind_native+0x414>
     3b7:      	cmpl	$0x16, %eax
     3ba:      	je	0x40d <perf_unwind_native+0x40d>
     3bc:      	cmpl	$0x17, %eax
     3bf:      	jne	0x586e <perf_unwind_native+0x586e>
     3c5:      	movq	(%rip), %rdi            # 0x3cc <perf_unwind_native+0x3cc>
     3cc:      	jmp	0x414 <perf_unwind_native+0x414>
     3ce:      	movq	(%rip), %rdi            # 0x3d5 <perf_unwind_native+0x3d5>
     3d5:      	jmp	0x414 <perf_unwind_native+0x414>
     3d7:      	movq	(%rip), %rdi            # 0x3de <perf_unwind_native+0x3de>
     3de:      	jmp	0x414 <perf_unwind_native+0x414>
     3e0:      	movq	(%rip), %rdi            # 0x3e7 <perf_unwind_native+0x3e7>
     3e7:      	jmp	0x414 <perf_unwind_native+0x414>
     3e9:      	movq	(%rip), %rdi            # 0x3f0 <perf_unwind_native+0x3f0>
     3f0:      	jmp	0x414 <perf_unwind_native+0x414>
     3f2:      	movq	(%rip), %rdi            # 0x3f9 <perf_unwind_native+0x3f9>
     3f9:      	jmp	0x414 <perf_unwind_native+0x414>
     3fb:      	movq	(%rip), %rdi            # 0x402 <perf_unwind_native+0x402>
     402:      	jmp	0x414 <perf_unwind_native+0x414>
     404:      	movq	(%rip), %rdi            # 0x40b <perf_unwind_native+0x40b>
     40b:      	jmp	0x414 <perf_unwind_native+0x414>
     40d:      	movq	(%rip), %rdi            # 0x414 <perf_unwind_native+0x414>
     414:      	leaq	0x160(%rsp), %rsi
     41c:      	movl	$0x1, %eax
     421:      	callq	*%rax
     423:      	testq	%rax, %rax
     426:      	je	0x5f9f <perf_unwind_native+0x5f9f>
     42c:      	movq	%rax, %r15
     42f:      	movl	(%r14), %r12d
     432:      	movl	%r12d, 0x90(%rsp)
     43a:      	movq	0xf18(%rbx), %rax
     441:      	movq	%rax, 0x60(%rsp)
     446:      	movzwl	0x4(%r14), %r13d
     44b:      	testl	%r13d, %r13d
     44e:      	je	0x89d <perf_unwind_native+0x89d>
     454:      	addl	%r12d, %r13d
     457:      	movq	(%rip), %rax            # 0x45e <perf_unwind_native+0x45e>
     45e:      	cmpl	$0x0, (%rax)
     461:      	jne	0x114a <perf_unwind_native+0x114a>
     467:      	leal	(%r12,%r13), %eax
     46b:      	shrl	%eax
     46d:      	movl	%eax, 0x10(%rsp)
     471:      	leaq	0x10(%rsp), %rsi
     476:      	movl	$0x1, %eax
     47b:      	movq	%r15, %rdi
     47e:      	callq	*%rax
     480:      	testq	%rax, %rax
     483:      	je	0x961 <perf_unwind_native+0x961>
     489:      	movl	0x10(%rsp), %ecx
     48d:      	leal	0x1(%rcx), %ebp
     490:      	movq	0x60(%rsp), %rdx
     495:      	cmpw	%dx, (%rax)
     498:      	cmoval	%r12d, %ebp
     49c:      	cmoval	%ecx, %r13d
     4a0:      	cmpl	%r13d, %ebp
     4a3:      	jae	0x891 <perf_unwind_native+0x891>
     4a9:      	leal	(%rbp,%r13), %eax
     4ae:      	shrl	%eax
     4b0:      	movl	%eax, 0x10(%rsp)
     4b4:      	leaq	0x10(%rsp), %rsi
     4b9:      	movl	$0x1, %eax
     4be:      	movq	%r15, %rdi
     4c1:      	callq	*%rax
     4c3:      	testq	%rax, %rax
     4c6:      	je	0x961 <perf_unwind_native+0x961>
     4cc:      	movl	0x10(%rsp), %ecx
     4d0:      	leal	0x1(%rcx), %r12d
     4d4:      	movq	0x60(%rsp), %rdx
     4d9:      	cmpw	%dx, (%rax)
     4dc:      	cmoval	%ebp, %r12d
     4e0:      	cmoval	%ecx, %r13d
     4e4:      	cmpl	%r13d, %r12d
     4e7:      	jae	0x891 <perf_unwind_native+0x891>
     4ed:      	leal	(%r12,%r13), %eax
     4f1:      	shrl	%eax
     4f3:      	movl	%eax, 0x10(%rsp)
     4f7:      	leaq	0x10(%rsp), %rsi
     4fc:      	movl	$0x1, %eax
     501:      	movq	%r15, %rdi
     504:      	callq	*%rax
     506:      	testq	%rax, %rax
     509:      	je	0x961 <perf_unwind_native+0x961>
     50f:      	movl	0x10(%rsp), %ecx
     513:      	leal	0x1(%rcx), %ebp
     516:      	movq	0x60(%rsp), %rdx
     51b:      	cmpw	%dx, (%rax)
     51e:      	cmoval	%r12d, %ebp
     522:      	cmoval	%ecx, %r13d
     526:      	cmpl	%r13d, %ebp
     529:      	jae	0x891 <perf_unwind_native+0x891>
     52f:      	leal	(%rbp,%r13), %eax
     534:      	shrl	%eax
     536:      	movl	%eax, 0x10(%rsp)
     53a:      	leaq	0x10(%rsp), %rsi
     53f:      	movl	$0x1, %eax
     544:      	movq	%r15, %rdi
     547:      	callq	*%rax
     549:      	testq	%rax, %rax
     54c:      	je	0x961 <perf_unwind_native+0x961>
     552:      	movl	0x10(%rsp), %ecx
     556:      	leal	0x1(%rcx), %r12d
     55a:      	movq	0x60(%rsp), %rdx
     55f:      	cmpw	%dx, (%rax)
     562:      	cmoval	%ebp, %r12d
     566:      	cmoval	%ecx, %r13d
     56a:      	cmpl	%r13d, %r12d
     56d:      	jae	0x891 <perf_unwind_native+0x891>
     573:      	leal	(%r12,%r13), %eax
     577:      	shrl	%eax
     579:      	movl	%eax, 0x10(%rsp)
     57d:      	leaq	0x10(%rsp), %rsi
     582:      	movl	$0x1, %eax
     587:      	movq	%r15, %rdi
     58a:      	callq	*%rax
     58c:      	testq	%rax, %rax
     58f:      	je	0x961 <perf_unwind_native+0x961>
     595:      	movl	0x10(%rsp), %ecx
     599:      	leal	0x1(%rcx), %ebp
     59c:      	movq	0x60(%rsp), %rdx
     5a1:      	cmpw	%dx, (%rax)
     5a4:      	cmoval	%r12d, %ebp
     5a8:      	cmoval	%ecx, %r13d
     5ac:      	cmpl	%r13d, %ebp
     5af:      	jae	0x891 <perf_unwind_native+0x891>
     5b5:      	leal	(%rbp,%r13), %eax
     5ba:      	shrl	%eax
     5bc:      	movl	%eax, 0x10(%rsp)
     5c0:      	leaq	0x10(%rsp), %rsi
     5c5:      	movl	$0x1, %eax
     5ca:      	movq	%r15, %rdi
     5cd:      	callq	*%rax
     5cf:      	testq	%rax, %rax
     5d2:      	je	0x961 <perf_unwind_native+0x961>
     5d8:      	movl	0x10(%rsp), %ecx
     5dc:      	leal	0x1(%rcx), %r12d
     5e0:      	movq	0x60(%rsp), %rdx
     5e5:      	cmpw	%dx, (%rax)
     5e8:      	cmoval	%ebp, %r12d
     5ec:      	cmoval	%ecx, %r13d
     5f0:      	cmpl	%r13d, %r12d
     5f3:      	jae	0x891 <perf_unwind_native+0x891>
     5f9:      	leal	(%r12,%r13), %eax
     5fd:      	shrl	%eax
     5ff:      	movl	%eax, 0x10(%rsp)
     603:      	leaq	0x10(%rsp), %rsi
     608:      	movl	$0x1, %eax
     60d:      	movq	%r15, %rdi
     610:      	callq	*%rax
     612:      	testq	%rax, %rax
     615:      	je	0x961 <perf_unwind_native+0x961>
     61b:      	movl	0x10(%rsp), %ecx
     61f:      	leal	0x1(%rcx), %ebp
     622:      	movq	0x60(%rsp), %rdx
     627:      	cmpw	%dx, (%rax)
     62a:      	cmoval	%r12d, %ebp
     62e:      	cmoval	%ecx, %r13d
     632:      	cmpl	%r13d, %ebp
     635:      	jae	0x891 <perf_unwind_native+0x891>
     63b:      	leal	(%rbp,%r13), %eax
     640:      	shrl	%eax
     642:      	movl	%eax, 0x10(%rsp)
     646:      	leaq	0x10(%rsp), %rsi
     64b:      	movl	$0x1, %eax
     650:      	movq	%r15, %rdi
     653:      	callq	*%rax
     655:      	testq	%rax, %rax
     658:      	je	0x961 <perf_unwind_native+0x961>
     65e:      	movl	0x10(%rsp), %ecx
     662:      	leal	0x1(%rcx), %r12d
     666:      	movq	0x60(%rsp), %rdx
     66b:      	cmpw	%dx, (%rax)
     66e:      	cmoval	%ebp, %r12d
     672:      	cmoval	%ecx, %r13d
     676:      	cmpl	%r13d, %r12d
     679:      	jae	0x891 <perf_unwind_native+0x891>
     67f:      	leal	(%r12,%r13), %eax
     683:      	shrl	%eax
     685:      	movl	%eax, 0x10(%rsp)
     689:      	leaq	0x10(%rsp), %rsi
     68e:      	movl	$0x1, %eax
     693:      	movq	%r15, %rdi
     696:      	callq	*%rax
     698:      	testq	%rax, %rax
     69b:      	je	0x961 <perf_unwind_native+0x961>
     6a1:      	movl	0x10(%rsp), %ecx
     6a5:      	leal	0x1(%rcx), %ebp
     6a8:      	movq	0x60(%rsp), %rdx
     6ad:      	cmpw	%dx, (%rax)
     6b0:      	cmoval	%r12d, %ebp
     6b4:      	cmoval	%ecx, %r13d
     6b8:      	cmpl	%r13d, %ebp
     6bb:      	jae	0x891 <perf_unwind_native+0x891>
     6c1:      	leal	(%rbp,%r13), %eax
     6c6:      	shrl	%eax
     6c8:      	movl	%eax, 0x10(%rsp)
     6cc:      	leaq	0x10(%rsp), %rsi
     6d1:      	movl	$0x1, %eax
     6d6:      	movq	%r15, %rdi
     6d9:      	callq	*%rax
     6db:      	testq	%rax, %rax
     6de:      	je	0x961 <perf_unwind_native+0x961>
     6e4:      	movl	0x10(%rsp), %ecx
     6e8:      	leal	0x1(%rcx), %r12d
     6ec:      	movq	0x60(%rsp), %rdx
     6f1:      	cmpw	%dx, (%rax)
     6f4:      	cmoval	%ebp, %r12d
     6f8:      	cmoval	%ecx, %r13d
     6fc:      	cmpl	%r13d, %r12d
     6ff:      	jae	0x891 <perf_unwind_native+0x891>
     705:      	leal	(%r12,%r13), %eax
     709:      	shrl	%eax
     70b:      	movl	%eax, 0x10(%rsp)
     70f:      	leaq	0x10(%rsp), %rsi
     714:      	movl	$0x1, %eax
     719:      	movq	%r15, %rdi
     71c:      	callq	*%rax
     71e:      	testq	%rax, %rax
     721:      	je	0x961 <perf_unwind_native+0x961>
     727:      	movl	0x10(%rsp), %ecx
     72b:      	leal	0x1(%rcx), %ebp
     72e:      	movq	0x60(%rsp), %rdx
     733:      	cmpw	%dx, (%rax)
     736:      	cmoval	%r12d, %ebp
     73a:      	cmoval	%ecx, %r13d
     73e:      	cmpl	%r13d, %ebp
     741:      	jae	0x891 <perf_unwind_native+0x891>
     747:      	leal	(%rbp,%r13), %eax
     74c:      	shrl	%eax
     74e:      	movl	%eax, 0x10(%rsp)
     752:      	leaq	0x10(%rsp), %rsi
     757:      	movl	$0x1, %eax
     75c:      	movq	%r15, %rdi
     75f:      	callq	*%rax
     761:      	testq	%rax, %rax
     764:      	je	0x961 <perf_unwind_native+0x961>
     76a:      	movl	0x10(%rsp), %ecx
     76e:      	leal	0x1(%rcx), %r12d
     772:      	movq	0x60(%rsp), %rdx
     777:      	cmpw	%dx, (%rax)
     77a:      	cmoval	%ebp, %r12d
     77e:      	cmoval	%ecx, %r13d
     782:      	cmpl	%r13d, %r12d
     785:      	jae	0x891 <perf_unwind_native+0x891>
     78b:      	leal	(%r12,%r13), %eax
     78f:      	shrl	%eax
     791:      	movl	%eax, 0x10(%rsp)
     795:      	leaq	0x10(%rsp), %rsi
     79a:      	movl	$0x1, %eax
     79f:      	movq	%r15, %rdi
     7a2:      	callq	*%rax
     7a4:      	testq	%rax, %rax
     7a7:      	je	0x961 <perf_unwind_native+0x961>
     7ad:      	movl	0x10(%rsp), %ecx
     7b1:      	leal	0x1(%rcx), %ebp
     7b4:      	movq	0x60(%rsp), %rdx
     7b9:      	cmpw	%dx, (%rax)
     7bc:      	cmoval	%r12d, %ebp
     7c0:      	cmoval	%ecx, %r13d
     7c4:      	cmpl	%r13d, %ebp
     7c7:      	jae	0x891 <perf_unwind_native+0x891>
     7cd:      	leal	(%rbp,%r13), %eax
     7d2:      	shrl	%eax
     7d4:      	movl	%eax, 0x10(%rsp)
     7d8:      	leaq	0x10(%rsp), %rsi
     7dd:      	movl	$0x1, %eax
     7e2:      	movq	%r15, %rdi
     7e5:      	callq	*%rax
     7e7:      	testq	%rax, %rax
     7ea:      	je	0x961 <perf_unwind_native+0x961>
     7f0:      	movl	0x10(%rsp), %ecx
     7f4:      	leal	0x1(%rcx), %r12d
     7f8:      	movq	0x60(%rsp), %rdx
     7fd:      	cmpw	%dx, (%rax)
     800:      	cmoval	%ebp, %r12d
     804:      	cmoval	%ecx, %r13d
     808:      	cmpl	%r13d, %r12d
     80b:      	jae	0x891 <perf_unwind_native+0x891>
     811:      	leal	(%r12,%r13), %eax
     815:      	shrl	%eax
     817:      	movl	%eax, 0x10(%rsp)
     81b:      	leaq	0x10(%rsp), %rsi
     820:      	movl	$0x1, %eax
     825:      	movq	%r15, %rdi
     828:      	callq	*%rax
     82a:      	testq	%rax, %rax
     82d:      	je	0x961 <perf_unwind_native+0x961>
     833:      	movl	0x10(%rsp), %ecx
     837:      	leal	0x1(%rcx), %ebp
     83a:      	movq	0x60(%rsp), %rdx
     83f:      	cmpw	%dx, (%rax)
     842:      	cmoval	%r12d, %ebp
     846:      	cmoval	%ecx, %r13d
     84a:      	cmpl	%r13d, %ebp
     84d:      	jae	0x891 <perf_unwind_native+0x891>
     84f:      	leal	(%rbp,%r13), %eax
     854:      	shrl	%eax
     856:      	movl	%eax, 0x10(%rsp)
     85a:      	leaq	0x10(%rsp), %rsi
     85f:      	movl	$0x1, %eax
     864:      	movq	%r15, %rdi
     867:      	callq	*%rax
     869:      	testq	%rax, %rax
     86c:      	je	0x961 <perf_unwind_native+0x961>
     872:      	movl	0x10(%rsp), %ecx
     876:      	leal	0x1(%rcx), %edx
     879:      	movq	0x60(%rsp), %rsi
     87e:      	cmpw	%si, (%rax)
     881:      	cmoval	%ebp, %edx
     884:      	cmoval	%ecx, %r13d
     888:      	cmpl	%r13d, %edx
     88b:      	jb	0x961 <perf_unwind_native+0x961>
     891:      	movl	%r13d, %r12d
     894:      	testl	%r13d, %r13d
     897:      	je	0x961 <perf_unwind_native+0x961>
     89d:      	decl	%r12d
     8a0:      	movl	%r12d, 0x90(%rsp)
     8a8:      	leaq	0x90(%rsp), %rsi
     8b0:      	movl	$0x1, %eax
     8b5:      	movq	%r15, %rdi
     8b8:      	callq	*%rax
     8ba:      	movl	$0xfa4, %ecx            # imm = 0xFA4
     8bf:      	movl	$0xa, %edx
     8c4:      	testq	%rax, %rax
     8c7:      	je	0x4333 <perf_unwind_native+0x4333>
     8cd:      	movq	(%rip), %r13            # 0x8d4 <perf_unwind_native+0x8d4>
     8d4:      	cmpl	$0x0, (%r13)
     8d9:      	jne	0x11ce <perf_unwind_native+0x11ce>
     8df:      	movzwl	0x60(%rsp), %ecx
     8e4:      	movzwl	(%rax), %edx
     8e7:      	subl	%edx, %ecx
     8e9:      	movl	0x90(%rsp), %edx
     8f0:      	cmpl	(%r14), %edx
     8f3:      	leal	0x10000(%rcx), %ebp
     8f9:      	cmovael	%ecx, %ebp
     8fc:      	movzwl	0x2(%rax), %ecx
     900:      	movl	%ecx, 0x8c(%rsp)
     907:      	cmpl	$0x8000, %ecx           # imm = 0x8000
     90d:      	movq	0x98(%rsp), %rax
     915:      	je	0x4329 <perf_unwind_native+0x4329>
     91b:      	cmpl	$0x8001, %ecx           # imm = 0x8001
     921:      	jne	0xa0f <perf_unwind_native+0xa0f>
     927:      	movl	$0x7, 0x94(%rsp)
     932:      	movq	(%rip), %rdi            # 0x939 <perf_unwind_native+0x939>
     939:      	leaq	0x94(%rsp), %rsi
     941:      	movl	$0x1, %eax
     946:      	callq	*%rax
     948:      	testq	%rax, %rax
     94b:      	je	0x9f5 <perf_unwind_native+0x9f5>
     951:      	incq	(%rax)
     954:      	movq	0x98(%rsp), %rax
     95c:      	jmp	0xa08 <perf_unwind_native+0xa08>
     961:      	movl	$0xfa3, %ecx            # imm = 0xFA3
     966:      	movl	$0x9, %edx
     96b:      	movq	(%rip), %rax            # 0x972 <perf_unwind_native+0x972>
     972:      	cmpl	$0x0, (%rax)
     975:      	je	0x4333 <perf_unwind_native+0x4333>
     97b:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
     985:      	movq	%rax, 0x30(%rsp)
     98a:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
     994:      	movq	%rax, 0x28(%rsp)
     999:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
     9a3:      	movq	%rax, 0x20(%rsp)
     9a8:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
     9b2:      	movq	%rax, 0x18(%rsp)
     9b7:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
     9c1:      	movq	%rax, 0x10(%rsp)
     9c6:      	movl	$0xa3f61, 0x37(%rsp)    # imm = 0xA3F61
     9ce:      	leaq	0x10(%rsp), %rdi
     9d3:      	movl	$0x2b, %eax
     9d8:      	movl	$0x6, %ecx
     9dd:      	movl	$0x2b, %esi
     9e2:      	xorl	%eax, %eax
     9e4:      	callq	*%rcx
     9e6:      	movl	$0x9, %edx
     9eb:      	movl	$0xfa3, %ecx            # imm = 0xFA3
     9f0:      	jmp	0x4333 <perf_unwind_native+0x4333>
     9f5:      	cmpl	$0x0, (%r13)
     9fa:      	movq	0x98(%rsp), %rax
     a02:      	jne	0x12cd <perf_unwind_native+0x12cd>
     a08:      	movl	0x8c(%rsp), %ecx
     a0f:      	leaq	0xed0(%rax), %r12
     a16:      	leaq	0xee0(%rax), %rdx
     a1d:      	leaq	0xed8(%rax), %r15
     a24:      	leaq	0xee8(%rax), %rsi
     a2b:      	leaq	0xef0(%rax), %rdi
     a32:      	leaq	0xef8(%rax), %r8
     a39:      	addq	$0xf08, %rax            # imm = 0xF08
     a3f:      	testw	%cx, %cx
     a42:      	movq	%rdx, 0x60(%rsp)
     a47:      	js	0xaf7 <perf_unwind_native+0xaf7>
     a4d:      	movq	%r8, 0x150(%rsp)
     a55:      	movq	%rdi, 0x148(%rsp)
     a5d:      	movq	%rsi, 0x138(%rsp)
     a65:      	movq	%rax, 0x98(%rsp)
     a6d:      	movq	(%rip), %rdi            # 0xa74 <perf_unwind_native+0xa74>
     a74:      	leaq	0x8c(%rsp), %rsi
     a7c:      	movl	$0x1, %eax
     a81:      	callq	*%rax
     a83:      	testq	%rax, %rax
     a86:      	je	0x6393 <perf_unwind_native+0x6393>
     a8c:      	movl	0x4(%rax), %r13d
     a90:      	movzbl	0x2(%rax), %edx
     a94:      	testb	%dl, %dl
     a96:      	movq	%r15, 0x158(%rsp)
     a9e:      	je	0xc59 <perf_unwind_native+0xc59>
     aa4:      	movq	(%rip), %rcx            # 0xaab <perf_unwind_native+0xaab>
     aab:      	cmpl	$0x0, (%rcx)
     aae:      	jne	0x125c <perf_unwind_native+0x125c>
     ab4:      	movl	%edx, %ecx
     ab6:      	andb	$0x7f, %cl
     ab9:      	movzbl	%cl, %ecx
     abc:      	cmpl	%ecx, %ebp
     abe:      	movq	0x98(%rsp), %rcx
     ac6:      	movq	0x60(%rsp), %rdi
     acb:      	jl	0xaef <perf_unwind_native+0xaef>
     acd:      	xorl	%esi, %esi
     acf:      	testb	%dl, %dl
     ad1:      	setns	%sil
     ad5:      	shll	$0x4, %esi
     ad8:      	addl	%esi, %r13d
     adb:      	addl	$-0x8, %r13d
     adf:      	movq	(%rip), %rdx            # 0xae6 <perf_unwind_native+0xae6>
     ae6:      	cmpl	$0x0, (%rdx)
     ae9:      	jne	0x134b <perf_unwind_native+0x134b>
     aef:      	movq	%r12, %r15
     af2:      	jmp	0xc69 <perf_unwind_native+0xc69>
     af7:      	andl	$0xffff7fff, %ecx       # imm = 0xFFFF7FFF
     afd:      	movl	$0x1, %r13d
     b03:      	cmpl	$0x2, %ecx
     b06:      	jg	0xbb6 <perf_unwind_native+0xbb6>
     b0c:      	cmpl	$0x1, %ecx
     b0f:      	movq	0x68(%rsp), %rbp
     b14:      	je	0x64f2 <perf_unwind_native+0x64f2>
     b1a:      	cmpl	$0x2, %ecx
     b1d:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
     b23:      	movq	%r8, 0x150(%rsp)
     b2b:      	movq	%rdi, 0x148(%rsp)
     b33:      	movq	%rsi, 0x138(%rsp)
     b3b:      	movq	%rax, 0x98(%rsp)
     b43:      	movq	%r15, 0x158(%rsp)
     b4b:      	movq	(%r15), %rax
     b4e:      	movq	%r12, %r15
     b51:      	movl	(%r12), %ecx
     b55:      	andl	$0xf, %ecx
     b58:      	xorl	%edx, %edx
     b5a:      	cmpl	$0xb, %ecx
     b5d:      	setae	%dl
     b60:      	leaq	(%rax,%rdx,8), %r12
     b64:      	addq	$0x8, %r12
     b68:      	movq	(%rip), %rax            # 0xb6f <perf_unwind_native+0xb6f>
     b6f:      	cmpl	$0x0, (%rax)
     b72:      	je	0x1618 <perf_unwind_native+0x1618>
     b78:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
     b82:      	movq	%rax, 0x18(%rsp)
     b87:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
     b91:      	movq	%rax, 0x10(%rsp)
     b96:      	leaq	0x10(%rsp), %rdi
     b9b:      	movl	$0x10, %eax
     ba0:      	movl	$0x6, %ecx
     ba5:      	movl	$0x10, %esi
     baa:      	movq	%r12, %rdx
     bad:      	xorl	%eax, %eax
     baf:      	callq	*%rcx
     bb1:      	jmp	0x1618 <perf_unwind_native+0x1618>
     bb6:      	cmpl	$0x3, %ecx
     bb9:      	movq	0x68(%rsp), %rbp
     bbe:      	je	0xd72 <perf_unwind_native+0xd72>
     bc4:      	cmpl	$0x4, %ecx
     bc7:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
     bcd:      	movq	%r8, 0x150(%rsp)
     bd5:      	movq	%rdi, 0x148(%rsp)
     bdd:      	movq	%rsi, 0x138(%rsp)
     be5:      	movq	%rax, 0x98(%rsp)
     bed:      	movq	(%rdx), %rax
     bf0:      	leaq	0x10(%rsp), %rdi
     bf5:      	movl	$0x10, %ecx
     bfa:      	movl	$0x70, %r8d
     c00:      	movq	(%rdx), %rdx
     c03:      	movl	$0x10, %esi
     c08:      	callq	*%r8
     c0b:      	testq	%rax, %rax
     c0e:      	jne	0x163b <perf_unwind_native+0x163b>
     c14:      	movq	%r15, 0x158(%rsp)
     c1c:      	movq	0xee0(%rbx), %rax
     c23:      	addq	$0x10, %rax
     c27:      	movq	%rax, 0xed8(%rbx)
     c2e:      	movq	0x10(%rsp), %rax
     c33:      	movq	%rax, 0xee0(%rbx)
     c3a:      	movq	0x18(%rsp), %rax
     c3f:      	movq	%rax, 0xed0(%rbx)
     c46:      	movb	$0x1, 0xf30(%rbx)
     c4d:      	movq	(%rip), %r14            # 0xc54 <perf_unwind_native+0xc54>
     c54:      	jmp	0x169c <perf_unwind_native+0x169c>
     c59:      	movq	%r12, %r15
     c5c:      	movq	0x98(%rsp), %rcx
     c64:      	movq	0x60(%rsp), %rdi
     c69:      	movzbl	(%rax), %edx
     c6c:      	movl	%r13d, %esi
     c6f:      	andl	$-0x8, %esi
     c72:      	testb	%dl, %dl
     c74:      	cmovnsl	%r13d, %esi
     c78:      	movl	%edx, %r9d
     c7b:      	andl	$0x7f, %r9d
     c7f:      	xorl	%r12d, %r12d
     c82:      	cmpl	$0x2, %r9d
     c86:      	jg	0xca5 <perf_unwind_native+0xca5>
     c88:      	cmpl	$0x1, %r9d
     c8c:      	je	0xd14 <perf_unwind_native+0xd14>
     c92:      	movq	0x158(%rsp), %r8
     c9a:      	cmpl	$0x2, %r9d
     c9e:      	je	0xd11 <perf_unwind_native+0xd11>
     ca0:      	jmp	0x1450 <perf_unwind_native+0x1450>
     ca5:      	movq	%rdi, %r8
     ca8:      	cmpl	$0x3, %r9d
     cac:      	je	0xd11 <perf_unwind_native+0xd11>
     cae:      	cmpl	$0x5, %r9d
     cb2:      	jne	0x1450 <perf_unwind_native+0x1450>
     cb8:      	movl	%r13d, %edx
     cbb:      	sarl	%edx
     cbd:      	andl	$-0x8, %edx
     cc0:      	movslq	%edx, %rdx
     cc3:      	movq	%rdx, 0x78(%rsp)
     cc8:      	movq	(%rip), %rdx            # 0xccf <perf_unwind_native+0xccf>
     ccf:      	cmpl	$0x0, (%rdx)
     cd2:      	jne	0x13c8 <perf_unwind_native+0x13c8>
     cd8:      	andl	$0xf, %r13d
     cdc:      	xorl	%r12d, %r12d
     cdf:      	cmpl	$0xa, %r13d
     ce3:      	jg	0x1431 <perf_unwind_native+0x1431>
     ce9:      	movq	0x138(%rsp), %rdx
     cf1:      	testl	%r13d, %r13d
     cf4:      	je	0x1448 <perf_unwind_native+0x1448>
     cfa:      	movq	0x148(%rsp), %rdx
     d02:      	cmpl	$0x9, %r13d
     d06:      	je	0x1448 <perf_unwind_native+0x1448>
     d0c:      	jmp	0x1450 <perf_unwind_native+0x1450>
     d11:      	movq	(%r8), %r12
     d14:      	movq	%r12, %r8
     d17:      	movslq	%esi, %r12
     d1a:      	addq	%r8, %r12
     d1d:      	testb	%dl, %dl
     d1f:      	jns	0x1450 <perf_unwind_native+0x1450>
     d25:      	movq	%rax, %r14
     d28:      	leaq	0x78(%rsp), %rdi
     d2d:      	movl	$0x8, %eax
     d32:      	movl	$0x70, %ecx
     d37:      	movl	$0x8, %esi
     d3c:      	movq	%r12, %rdx
     d3f:      	callq	*%rcx
     d41:      	testq	%rax, %rax
     d44:      	je	0xe97 <perf_unwind_native+0xe97>
     d4a:      	movq	(%rip), %rax            # 0xd51 <perf_unwind_native+0xd51>
     d51:      	cmpl	$0x0, (%rax)
     d54:      	movq	0x98(%rsp), %rcx
     d5c:      	movq	0x60(%rsp), %rdi
     d61:      	jne	0x1af8 <perf_unwind_native+0x1af8>
     d67:      	movq	%r14, %rax
     d6a:      	xorl	%r12d, %r12d
     d6d:      	jmp	0x1450 <perf_unwind_native+0x1450>
     d72:      	movq	%r8, 0x150(%rsp)
     d7a:      	movq	%rdi, 0x148(%rsp)
     d82:      	movq	%rsi, 0x138(%rsp)
     d8a:      	movq	%rax, 0x98(%rsp)
     d92:      	movq	(%r15), %rax
     d95:      	addq	$0x28, %rax
     d99:      	leaq	0xa0(%rsp), %rdi
     da1:      	movl	$0x90, %ecx
     da6:      	movl	$0x70, %r8d
     dac:      	movq	%r15, 0x158(%rsp)
     db4:      	movq	(%r15), %rdx
     db7:      	addq	$0x28, %rdx
     dbb:      	movl	$0x90, %esi
     dc0:      	callq	*%r8
     dc3:      	testq	%rax, %rax
     dc6:      	jne	0x163b <perf_unwind_native+0x163b>
     dcc:      	movq	0x108(%rsp), %rax
     dd4:      	movq	%rax, 0xee8(%rbx)
     ddb:      	movq	0xa8(%rsp), %rax
     de3:      	movq	%rax, 0xef0(%rbx)
     dea:      	movq	0xb8(%rsp), %rax
     df2:      	movq	%rax, 0xef8(%rbx)
     df9:      	movq	0xc8(%rsp), %rax
     e01:      	movq	%rax, 0xf00(%rbx)
     e08:      	movq	0xd8(%rsp), %rax
     e10:      	movq	%rax, 0xf08(%rbx)
     e17:      	movq	0xf0(%rsp), %rax
     e1f:      	movq	%rax, 0xee0(%rbx)
     e26:      	movq	0x118(%rsp), %rax
     e2e:      	movq	%rax, 0xed8(%rbx)
     e35:      	movq	0x120(%rsp), %rax
     e3d:      	movq	%rax, 0xed0(%rbx)
     e44:      	movb	$0x0, 0xf30(%rbx)
     e4b:      	movq	(%rip), %r14            # 0xe52 <perf_unwind_native+0xe52>
     e52:      	cmpl	$0x0, (%r14)
     e56:      	je	0x169c <perf_unwind_native+0x169c>
     e5c:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     e66:      	movq	%rax, 0x16(%rsp)
     e6b:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
     e75:      	movq	%rax, 0x10(%rsp)
     e7a:      	leaq	0x10(%rsp), %rdi
     e7f:      	movl	$0xe, %eax
     e84:      	movl	$0x6, %ecx
     e89:      	movl	$0xe, %esi
     e8e:      	xorl	%eax, %eax
     e90:      	callq	*%rcx
     e92:      	jmp	0x169c <perf_unwind_native+0x169c>
     e97:      	shll	$0x3, %r13d
     e9b:      	andl	$0x38, %r13d
     e9f:      	addq	0x78(%rsp), %r13
     ea4:      	movq	%r13, %r12
     ea7:      	movq	0x98(%rsp), %rcx
     eaf:      	movq	%r14, %rax
     eb2:      	movq	0x60(%rsp), %rdi
     eb7:      	jmp	0x1450 <perf_unwind_native+0x1450>
     ebc:      	movl	0x2c0(%rbx), %edx
     ec2:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
     ecc:      	movq	%rax, 0xb0(%rsp)
     ed4:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
     ede:      	movq	%rax, 0xa8(%rsp)
     ee6:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     ef0:      	movq	%rax, 0xa0(%rsp)
     ef8:      	movl	$0xa3d3d, 0xb8(%rsp)    # imm = 0xA3D3D
     f03:      	leaq	0xa0(%rsp), %rdi
     f0b:      	movl	$0x1c, %eax
     f10:      	movl	$0x6, %ecx
     f15:      	movl	$0x1c, %esi
     f1a:      	xorl	%eax, %eax
     f1c:      	callq	*%rcx
     f1e:      	jmp	0x5b <perf_unwind_native+0x5b>
     f23:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
     f2d:      	movq	%rax, 0xbd(%rsp)
     f35:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
     f3f:      	movq	%rax, 0xb8(%rsp)
     f47:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
     f51:      	movq	%rax, 0xb0(%rsp)
     f59:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
     f63:      	movq	%rax, 0xa8(%rsp)
     f6b:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
     f75:      	movq	%rax, 0xa0(%rsp)
     f7d:      	leaq	0xa0(%rsp), %rdi
     f85:      	movl	$0x25, %eax
     f8a:      	movl	$0x6, %ecx
     f8f:      	movl	$0x25, %esi
     f94:      	xorl	%eax, %eax
     f96:      	callq	*%rcx
     f98:      	jmp	0x14c <perf_unwind_native+0x14c>
     f9d:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
     fa7:      	movq	%rax, 0x28(%rsp)
     fac:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
     fb6:      	movq	%rax, 0x20(%rsp)
     fbb:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
     fc5:      	movq	%rax, 0x18(%rsp)
     fca:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
     fd4:      	movq	%rax, 0x10(%rsp)
     fd9:      	movb	$0x0, 0x30(%rsp)
     fde:      	leaq	0x10(%rsp), %rdi
     fe3:      	movl	$0x21, %eax
     fe8:      	movl	$0x6, %r8d
     fee:      	movq	0xf10(%rbx), %rdx
     ff5:      	movq	0xf18(%rbx), %rcx
     ffc:      	movl	$0x21, %esi
    1001:      	xorl	%eax, %eax
    1003:      	callq	*%r8
    1006:      	jmp	0x288 <perf_unwind_native+0x288>
    100b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1015:      	movq	%rax, 0xc6(%rsp)
    101d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1027:      	movq	%rax, 0xc0(%rsp)
    102f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1039:      	movq	%rax, 0xb8(%rsp)
    1041:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    104b:      	movq	%rax, 0xb0(%rsp)
    1053:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    105d:      	movq	%rax, 0xa8(%rsp)
    1065:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    106f:      	movq	%rax, 0xa0(%rsp)
    1077:      	leaq	0xa0(%rsp), %rdi
    107f:      	movl	$0x2e, %eax
    1084:      	movl	$0x6, %ecx
    1089:      	movl	0x10(%rsp), %edx
    108d:      	movl	$0x2e, %esi
    1092:      	xorl	%eax, %eax
    1094:      	callq	*%rcx
    1096:      	cmpl	$0x0, (%r13)
    109b:      	je	0x131 <perf_unwind_native+0x131>
    10a1:      	jmp	0x8d <perf_unwind_native+0x8d>
    10a6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10b0:      	movq	%rax, 0xc6(%rsp)
    10b8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10c2:      	movq	%rax, 0xc0(%rsp)
    10ca:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10d4:      	movq	%rax, 0xb8(%rsp)
    10dc:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    10e6:      	movq	%rax, 0xb0(%rsp)
    10ee:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    10f8:      	movq	%rax, 0xa8(%rsp)
    1100:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    110a:      	movq	%rax, 0xa0(%rsp)
    1112:      	leaq	0xa0(%rsp), %rdi
    111a:      	movl	$0x2e, %eax
    111f:      	movl	$0x6, %ecx
    1124:      	movl	0x10(%rsp), %edx
    1128:      	movl	$0x2e, %esi
    112d:      	xorl	%eax, %eax
    112f:      	callq	*%rcx
    1131:      	xorl	%r12d, %r12d
    1134:      	cmpl	$0x0, (%r13)
    1139:      	movl	$0x2, %r14d
    113f:      	je	0x5fd4 <perf_unwind_native+0x5fd4>
    1145:      	jmp	0x187 <perf_unwind_native+0x187>
    114a:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
    1154:      	movq	%rax, 0x38(%rsp)
    1159:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
    1163:      	movq	%rax, 0x30(%rsp)
    1168:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
    1172:      	movq	%rax, 0x28(%rsp)
    1177:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
    1181:      	movq	%rax, 0x20(%rsp)
    1186:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
    1190:      	movq	%rax, 0x18(%rsp)
    1195:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
    119f:      	movq	%rax, 0x10(%rsp)
    11a4:      	leaq	0x10(%rsp), %rdi
    11a9:      	movl	$0x30, %eax
    11ae:      	movl	$0x6, %r9d
    11b4:      	movl	%r13d, %ecx
    11b7:      	movzwl	(%rbp), %r8d
    11bc:      	movl	$0x30, %esi
    11c1:      	movq	%r12, %rdx
    11c4:      	xorl	%eax, %eax
    11c6:      	callq	*%r9
    11c9:      	jmp	0x467 <perf_unwind_native+0x467>
    11ce:      	movabsq	$0xa6425206f666e, %rcx  # imm = 0xA6425206F666E
    11d8:      	movq	%rcx, 0x35(%rsp)
    11dd:      	movabsq	$0x6f666e49646e6977, %rcx # imm = 0x6F666E49646E6977
    11e7:      	movq	%rcx, 0x30(%rsp)
    11ec:      	movabsq	$0x6e75202c78257830, %rcx # imm = 0x6E75202C78257830
    11f6:      	movq	%rcx, 0x28(%rsp)
    11fb:      	movabsq	$0x20776f4c72646461, %rcx # imm = 0x20776F4C72646461
    1205:      	movq	%rcx, 0x20(%rsp)
    120a:      	movabsq	$0x202c642520786564, %rcx # imm = 0x202C642520786564
    1214:      	movq	%rcx, 0x18(%rsp)
    1219:      	movabsq	$0x6e692061746c6564, %rcx # imm = 0x6E692061746C6564
    1223:      	movq	%rcx, 0x10(%rsp)
    1228:      	leaq	0x10(%rsp), %rdi
    122d:      	movl	$0x2d, %ecx
    1232:      	movl	$0x6, %r9d
    1238:      	movl	0x90(%rsp), %edx
    123f:      	movzwl	(%rax), %ecx
    1242:      	movzwl	0x2(%rax), %r8d
    1247:      	movl	$0x2d, %esi
    124c:      	movq	%rax, %r12
    124f:      	xorl	%eax, %eax
    1251:      	callq	*%r9
    1254:      	movq	%r12, %rax
    1257:      	jmp	0x8df <perf_unwind_native+0x8df>
    125c:      	movabsq	$0xa78323023252061, %rcx # imm = 0xA78323023252061
    1266:      	movq	%rcx, 0x28(%rsp)
    126b:      	movabsq	$0x746c656420646567, %rcx # imm = 0x746C656420646567
    1275:      	movq	%rcx, 0x20(%rsp)
    127a:      	movabsq	$0x72656d202c642520, %rcx # imm = 0x72656D202C642520
    1284:      	movq	%rcx, 0x18(%rsp)
    1289:      	movabsq	$0x6666694472646441, %rcx # imm = 0x6666694472646441
    1293:      	movq	%rcx, 0x10(%rsp)
    1298:      	movb	$0x0, 0x30(%rsp)
    129d:      	leaq	0x10(%rsp), %rdi
    12a2:      	movl	$0x21, %ecx
    12a7:      	movl	$0x6, %r8d
    12ad:      	movzbl	0x2(%rax), %ecx
    12b1:      	movl	$0x21, %esi
    12b6:      	movl	%ebp, %edx
    12b8:      	movq	%rax, %r14
    12bb:      	xorl	%eax, %eax
    12bd:      	callq	*%r8
    12c0:      	movq	%r14, %rax
    12c3:      	movzbl	0x2(%r14), %edx
    12c8:      	jmp	0xab4 <perf_unwind_native+0xab4>
    12cd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    12d7:      	movq	%rax, 0x36(%rsp)
    12dc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    12e6:      	movq	%rax, 0x30(%rsp)
    12eb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    12f5:      	movq	%rax, 0x28(%rsp)
    12fa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1304:      	movq	%rax, 0x20(%rsp)
    1309:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1313:      	movq	%rax, 0x18(%rsp)
    1318:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1322:      	movq	%rax, 0x10(%rsp)
    1327:      	leaq	0x10(%rsp), %rdi
    132c:      	movl	$0x2e, %eax
    1331:      	movl	$0x6, %ecx
    1336:      	movl	0x94(%rsp), %edx
    133d:      	movl	$0x2e, %esi
    1342:      	xorl	%eax, %eax
    1344:      	callq	*%rcx
    1346:      	jmp	0x954 <perf_unwind_native+0x954>
    134b:      	movq	%r12, %r15
    134e:      	movabsq	$0xa64253d61746c65, %rcx # imm = 0xA64253D61746C65
    1358:      	movq	%rcx, 0x28(%rsp)
    135d:      	movabsq	$0x44616663203a6863, %rcx # imm = 0x44616663203A6863
    1367:      	movq	%rcx, 0x20(%rsp)
    136c:      	movabsq	$0x74616d2061746c65, %rcx # imm = 0x74616D2061746C65
    1376:      	movq	%rcx, 0x18(%rsp)
    137b:      	movabsq	$0x642064656772654d, %rcx # imm = 0x642064656772654D
    1385:      	movq	%rcx, 0x10(%rsp)
    138a:      	movb	$0x0, 0x30(%rsp)
    138f:      	leaq	0x10(%rsp), %rdi
    1394:      	movl	$0x21, %ecx
    1399:      	movl	$0x6, %r8d
    139f:      	movl	0x8c(%rsp), %edx
    13a6:      	movl	$0x21, %esi
    13ab:      	movq	%rax, %r14
    13ae:      	xorl	%eax, %eax
    13b0:      	callq	*%r8
    13b3:      	movq	0x60(%rsp), %rdi
    13b8:      	movq	%r14, %rax
    13bb:      	movq	0x98(%rsp), %rcx
    13c3:      	jmp	0xc69 <perf_unwind_native+0xc69>
    13c8:      	movabsq	$0xa756c252b642572, %rcx # imm = 0xA756C252B642572
    13d2:      	movq	%rcx, 0x18(%rsp)
    13d7:      	movabsq	$0x203a646e69776e75, %rcx # imm = 0x203A646E69776E75
    13e1:      	movq	%rcx, 0x10(%rsp)
    13e6:      	movb	$0x0, 0x20(%rsp)
    13eb:      	leaq	0x10(%rsp), %rdi
    13f0:      	movl	$0x11, %ecx
    13f5:      	movl	$0x6, %r8d
    13fb:      	andl	$0xf, %r13d
    13ff:      	movq	0x78(%rsp), %rcx
    1404:      	movl	$0x11, %esi
    1409:      	movl	%r13d, %edx
    140c:      	movq	%rax, %r14
    140f:      	xorl	%eax, %eax
    1411:      	callq	*%r8
    1414:      	movq	0x60(%rsp), %rdi
    1419:      	movq	%r14, %rax
    141c:      	movq	0x98(%rsp), %rcx
    1424:      	xorl	%r12d, %r12d
    1427:      	cmpl	$0xa, %r13d
    142b:      	jle	0xce9 <perf_unwind_native+0xce9>
    1431:      	movq	0x150(%rsp), %rdx
    1439:      	cmpl	$0xb, %r13d
    143d:      	je	0x1448 <perf_unwind_native+0x1448>
    143f:      	cmpl	$0xf, %r13d
    1443:      	jne	0x1450 <perf_unwind_native+0x1450>
    1445:      	movq	%rcx, %rdx
    1448:      	movq	0x78(%rsp), %r12
    144d:      	addq	(%rdx), %r12
    1450:      	movzbl	0x1(%rax), %esi
    1454:      	movl	0x8(%rax), %r13d
    1458:      	movl	%r13d, %edx
    145b:      	andl	$-0x8, %edx
    145e:      	testb	%sil, %sil
    1461:      	cmovnsl	%r13d, %edx
    1465:      	movl	%esi, %r9d
    1468:      	andl	$0x7f, %r9d
    146c:      	cmpl	$0x2, %r9d
    1470:      	jg	0x148e <perf_unwind_native+0x148e>
    1472:      	movq	%r12, %rcx
    1475:      	cmpl	$0x1, %r9d
    1479:      	je	0x14f7 <perf_unwind_native+0x14f7>
    147b:      	movq	0x158(%rsp), %r8
    1483:      	cmpl	$0x2, %r9d
    1487:      	je	0x14f4 <perf_unwind_native+0x14f4>
    1489:      	jmp	0x153f <perf_unwind_native+0x153f>
    148e:      	movq	%rdi, %r8
    1491:      	cmpl	$0x3, %r9d
    1495:      	je	0x14f4 <perf_unwind_native+0x14f4>
    1497:      	cmpl	$0x5, %r9d
    149b:      	jne	0x153f <perf_unwind_native+0x153f>
    14a1:      	movl	%r13d, %edx
    14a4:      	sarl	%edx
    14a6:      	andl	$-0x8, %edx
    14a9:      	movslq	%edx, %rdx
    14ac:      	movq	%rdx, 0x78(%rsp)
    14b1:      	movq	(%rip), %rdx            # 0x14b8 <perf_unwind_native+0x14b8>
    14b8:      	cmpl	$0x0, (%rdx)
    14bb:      	jne	0x1566 <perf_unwind_native+0x1566>
    14c1:      	andl	$0xf, %r13d
    14c5:      	cmpl	$0xa, %r13d
    14c9:      	jg	0x15cc <perf_unwind_native+0x15cc>
    14cf:      	movq	0x138(%rsp), %rsi
    14d7:      	testl	%r13d, %r13d
    14da:      	je	0x15e7 <perf_unwind_native+0x15e7>
    14e0:      	movq	0x148(%rsp), %rsi
    14e8:      	cmpl	$0x9, %r13d
    14ec:      	je	0x15e7 <perf_unwind_native+0x15e7>
    14f2:      	jmp	0x153f <perf_unwind_native+0x153f>
    14f4:      	movq	(%r8), %rcx
    14f7:      	movslq	%edx, %rdx
    14fa:      	addq	%rcx, %rdx
    14fd:      	testb	%sil, %sil
    1500:      	jns	0x15ef <perf_unwind_native+0x15ef>
    1506:      	movq	%rax, %r14
    1509:      	leaq	0x78(%rsp), %rdi
    150e:      	movl	$0x8, %eax
    1513:      	movl	$0x70, %ecx
    1518:      	movl	$0x8, %esi
    151d:      	movq	%rdx, %rbp
    1520:      	callq	*%rcx
    1522:      	testq	%rax, %rax
    1525:      	je	0x1549 <perf_unwind_native+0x1549>
    1527:      	movq	(%rip), %rax            # 0x152e <perf_unwind_native+0x152e>
    152e:      	cmpl	$0x0, (%rax)
    1531:      	movq	%r14, %rax
    1534:      	movq	0x60(%rsp), %rdi
    1539:      	jne	0x1b7e <perf_unwind_native+0x1b7e>
    153f:      	movq	0x68(%rsp), %rbp
    1544:      	jmp	0x160c <perf_unwind_native+0x160c>
    1549:      	shll	$0x3, %r13d
    154d:      	andl	$0x38, %r13d
    1551:      	addq	0x78(%rsp), %r13
    1556:      	movq	%r13, %rdx
    1559:      	movq	%r14, %rax
    155c:      	movq	0x60(%rsp), %rdi
    1561:      	jmp	0x15ef <perf_unwind_native+0x15ef>
    1566:      	movabsq	$0xa756c252b642572, %rcx # imm = 0xA756C252B642572
    1570:      	movq	%rcx, 0x18(%rsp)
    1575:      	movabsq	$0x203a646e69776e75, %rcx # imm = 0x203A646E69776E75
    157f:      	movq	%rcx, 0x10(%rsp)
    1584:      	movb	$0x0, 0x20(%rsp)
    1589:      	leaq	0x10(%rsp), %rdi
    158e:      	movl	$0x11, %ecx
    1593:      	movl	$0x6, %r8d
    1599:      	andl	$0xf, %r13d
    159d:      	movq	0x78(%rsp), %rcx
    15a2:      	movl	$0x11, %esi
    15a7:      	movl	%r13d, %edx
    15aa:      	movq	%rax, %r14
    15ad:      	xorl	%eax, %eax
    15af:      	callq	*%r8
    15b2:      	movq	0x60(%rsp), %rdi
    15b7:      	movq	%r14, %rax
    15ba:      	movq	0x98(%rsp), %rcx
    15c2:      	cmpl	$0xa, %r13d
    15c6:      	jle	0x14cf <perf_unwind_native+0x14cf>
    15cc:      	movq	0x150(%rsp), %rsi
    15d4:      	cmpl	$0xb, %r13d
    15d8:      	je	0x15e7 <perf_unwind_native+0x15e7>
    15da:      	cmpl	$0xf, %r13d
    15de:      	jne	0x153f <perf_unwind_native+0x153f>
    15e4:      	movq	%rcx, %rsi
    15e7:      	movq	0x78(%rsp), %rdx
    15ec:      	addq	(%rsi), %rdx
    15ef:      	testq	%rdx, %rdx
    15f2:      	movq	0x68(%rsp), %rbp
    15f7:      	je	0x160c <perf_unwind_native+0x160c>
    15f9:      	movl	$0x8, %eax
    15fe:      	movl	$0x70, %ecx
    1603:      	movl	$0x8, %esi
    1608:      	callq	*%rcx
    160a:      	jmp	0x1618 <perf_unwind_native+0x1618>
    160c:      	cmpb	$0x3, (%rax)
    160f:      	jne	0x1618 <perf_unwind_native+0x1618>
    1611:      	movq	$0x0, (%rdi)
    1618:      	testq	%r12, %r12
    161b:      	je	0x163b <perf_unwind_native+0x163b>
    161d:      	leaq	-0x8(%r12), %rdx
    1622:      	movl	$0x8, %eax
    1627:      	movl	$0x70, %ecx
    162c:      	movq	%r15, %rdi
    162f:      	movl	$0x8, %esi
    1634:      	callq	*%rcx
    1636:      	testq	%rax, %rax
    1639:      	je	0x1684 <perf_unwind_native+0x1684>
    163b:      	movl	$0xe, 0x78(%rsp)
    1643:      	movq	(%rip), %rdi            # 0x164a <perf_unwind_native+0x164a>
    164a:      	leaq	0x78(%rsp), %rsi
    164f:      	movl	$0x1, %eax
    1654:      	callq	*%rax
    1656:      	testq	%rax, %rax
    1659:      	je	0x1669 <perf_unwind_native+0x1669>
    165b:      	incq	(%rax)
    165e:      	movl	$0xfa7, %r13d           # imm = 0xFA7
    1664:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    1669:      	movq	(%rip), %rax            # 0x1670 <perf_unwind_native+0x1670>
    1670:      	cmpl	$0x0, (%rax)
    1673:      	jne	0x17a9 <perf_unwind_native+0x17a9>
    1679:      	movl	$0xfa7, %r13d           # imm = 0xFA7
    167f:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    1684:      	movq	%r12, 0xed8(%rbx)
    168b:      	movb	$0x1, 0xf30(%rbx)
    1692:      	movq	(%rip), %r14            # 0x1699 <perf_unwind_native+0x1699>
    1699:      	movq	%r15, %r12
    169c:      	movl	$0x6, 0x78(%rsp)
    16a4:      	movq	(%rip), %rdi            # 0x16ab <perf_unwind_native+0x16ab>
    16ab:      	leaq	0x78(%rsp), %rsi
    16b0:      	movl	$0x1, %eax
    16b5:      	callq	*%rax
    16b7:      	testq	%rax, %rax
    16ba:      	je	0x1756 <perf_unwind_native+0x1756>
    16c0:      	incq	(%rax)
    16c3:      	xorl	%eax, %eax
    16c5:      	cmpl	$0x0, (%r14)
    16c9:      	je	0x1762 <perf_unwind_native+0x1762>
    16cf:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    16d9:      	movq	%rax, 0xb5(%rsp)
    16e1:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    16eb:      	movq	%rax, 0xb0(%rsp)
    16f3:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    16fd:      	movq	%rax, 0xa8(%rsp)
    1705:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    170f:      	movq	%rax, 0xa0(%rsp)
    1717:      	leaq	0xa0(%rsp), %rdi
    171f:      	movl	$0x1d, %eax
    1724:      	movl	$0x6, %r9d
    172a:      	movq	(%r12), %rdx
    172e:      	movq	0x158(%rsp), %rax
    1736:      	movq	(%rax), %rcx
    1739:      	movq	0x60(%rsp), %rax
    173e:      	movq	(%rax), %r8
    1741:      	movl	$0x1d, %esi
    1746:      	xorl	%eax, %eax
    1748:      	callq	*%r9
    174b:      	movq	(%rip), %rax            # 0x1752 <perf_unwind_native+0x1752>
    1752:      	movl	(%rax), %eax
    1754:      	jmp	0x1762 <perf_unwind_native+0x1762>
    1756:      	cmpl	$0x0, (%r14)
    175a:      	jne	0x1a71 <perf_unwind_native+0x1a71>
    1760:      	xorl	%eax, %eax
    1762:      	movq	(%r12), %r13
    1766:      	testq	%r13, %r13
    1769:      	je	0x70ee <perf_unwind_native+0x70ee>
    176f:      	testl	%eax, %eax
    1771:      	jne	0x1824 <perf_unwind_native+0x1824>
    1777:      	movq	%r13, %rax
    177a:      	shrq	$0x38, %rax
    177e:      	je	0x18cd <perf_unwind_native+0x18cd>
    1784:      	movq	(%rip), %rax            # 0x178b <perf_unwind_native+0x178b>
    178b:      	cmpl	$0x0, (%rax)
    178e:      	jne	0x33cf <perf_unwind_native+0x33cf>
    1794:      	movl	$0xb, 0xf28(%rbx)
    179e:      	movl	$0xfab, %r14d           # imm = 0xFAB
    17a4:      	jmp	0x71c6 <perf_unwind_native+0x71c6>
    17a9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17b3:      	movq	%rax, 0x36(%rsp)
    17b8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17c2:      	movq	%rax, 0x30(%rsp)
    17c7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17d1:      	movq	%rax, 0x28(%rsp)
    17d6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17e0:      	movq	%rax, 0x20(%rsp)
    17e5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17ef:      	movq	%rax, 0x18(%rsp)
    17f4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    17fe:      	movq	%rax, 0x10(%rsp)
    1803:      	leaq	0x10(%rsp), %rdi
    1808:      	movl	$0x2e, %eax
    180d:      	movl	$0x6, %ecx
    1812:      	movl	0x78(%rsp), %edx
    1816:      	movl	$0x2e, %esi
    181b:      	xorl	%eax, %eax
    181d:      	callq	*%rcx
    181f:      	jmp	0x1679 <perf_unwind_native+0x1679>
    1824:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    182e:      	movq	%rax, 0xc8(%rsp)
    1836:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    1840:      	movq	%rax, 0xc0(%rsp)
    1848:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    1852:      	movq	%rax, 0xb8(%rsp)
    185a:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    1864:      	movq	%rax, 0xb0(%rsp)
    186c:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    1876:      	movq	%rax, 0xa8(%rsp)
    187e:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    1888:      	movq	%rax, 0xa0(%rsp)
    1890:      	movb	$0x0, 0xd0(%rsp)
    1898:      	leaq	0xa0(%rsp), %rdi
    18a0:      	movl	$0x31, %eax
    18a5:      	movl	$0x6, %ecx
    18aa:      	movl	0x2c0(%rbx), %edx
    18b0:      	movl	$0x31, %esi
    18b5:      	xorl	%eax, %eax
    18b7:      	callq	*%rcx
    18b9:      	movq	0xed0(%rbx), %r13
    18c0:      	movq	%r13, %rax
    18c3:      	shrq	$0x38, %rax
    18c7:      	jne	0x1784 <perf_unwind_native+0x1784>
    18cd:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    18d4:      	ja	0x18fb <perf_unwind_native+0x18fb>
    18d6:      	movq	(%rip), %rax            # 0x18dd <perf_unwind_native+0x18dd>
    18dd:      	cmpl	$0x0, (%rax)
    18e0:      	jne	0x3515 <perf_unwind_native+0x3515>
    18e6:      	movl	$0x31, 0xf28(%rbx)
    18f0:      	movl	$0xfae, %r14d           # imm = 0xFAE
    18f6:      	jmp	0x71c6 <perf_unwind_native+0x71c6>
    18fb:      	movl	(%rbx), %eax
    18fd:      	movl	$0x60, 0x10(%rsp)
    1905:      	movbel	%eax, 0x14(%rsp)
    190b:      	movbeq	%r13, 0x18(%rsp)
    1912:      	movq	(%rip), %rdi            # 0x1919 <perf_unwind_native+0x1919>
    1919:      	leaq	0x10(%rsp), %rsi
    191e:      	movl	$0x1, %eax
    1923:      	callq	*%rax
    1925:      	testq	%rax, %rax
    1928:      	je	0x71aa <perf_unwind_native+0x71aa>
    192e:      	movq	%r12, 0x140(%rsp)
    1936:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    1940:      	movq	0x8(%rax), %r12
    1944:      	movq	%r12, %rcx
    1947:      	andq	%rdx, %rcx
    194a:      	movq	%rcx, 0xf20(%rbx)
    1951:      	movq	(%rax), %rax
    1954:      	movq	%rax, 0xf10(%rbx)
    195b:      	shrq	$0x38, %r12
    195f:      	movq	%r13, %rax
    1962:      	subq	%rcx, %rax
    1965:      	movq	%rax, 0xf18(%rbx)
    196c:      	movq	(%rip), %rax            # 0x1973 <perf_unwind_native+0x1973>
    1973:      	cmpl	$0x0, (%rax)
    1976:      	jne	0x1bf9 <perf_unwind_native+0x1bf9>
    197c:      	cmpl	$0x1, %r12d
    1980:      	jne	0x1df5 <perf_unwind_native+0x1df5>
    1986:      	movq	0xf10(%rbx), %rax
    198d:      	movq	%rax, 0x10(%rsp)
    1992:      	movq	0xf18(%rbx), %r14
    1999:      	movq	(%rip), %rdi            # 0x19a0 <perf_unwind_native+0x19a0>
    19a0:      	leaq	0x10(%rsp), %rsi
    19a5:      	movl	$0x1, %eax
    19aa:      	callq	*%rax
    19ac:      	movl	$0x1, %r12d
    19b2:      	testq	%rax, %rax
    19b5:      	je	0x1df5 <perf_unwind_native+0x1df5>
    19bb:      	movq	%rax, %r13
    19be:      	cmpq	%r14, (%rax)
    19c1:      	ja	0x19c9 <perf_unwind_native+0x19c9>
    19c3:      	cmpq	%r14, 0x8(%r13)
    19c7:      	jae	0x19dd <perf_unwind_native+0x19dd>
    19c9:      	cmpq	%r14, 0x10(%r13)
    19cd:      	ja	0x1df5 <perf_unwind_native+0x1df5>
    19d3:      	cmpq	%r14, 0x18(%r13)
    19d7:      	jb	0x1df5 <perf_unwind_native+0x1df5>
    19dd:      	movq	(%rip), %rax            # 0x19e4 <perf_unwind_native+0x19e4>
    19e4:      	cmpl	$0x0, (%rax)
    19e7:      	jne	0x1d3b <perf_unwind_native+0x1d3b>
    19ed:      	movl	0x1380(%rbx), %eax
    19f3:      	movl	0x20(%r13), %ecx
    19f7:      	btl	%ecx, %eax
    19fa:      	jae	0x1db6 <perf_unwind_native+0x1db6>
    1a00:      	movq	(%rip), %rax            # 0x1a07 <perf_unwind_native+0x1a07>
    1a07:      	cmpl	$0x0, (%rax)
    1a0a:      	je	0x1df0 <perf_unwind_native+0x1df0>
    1a10:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    1a1a:      	movq	%rax, 0xb0(%rsp)
    1a22:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    1a2c:      	movq	%rax, 0xa8(%rsp)
    1a34:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1a3e:      	movq	%rax, 0xa0(%rsp)
    1a46:      	movl	$0xa656e, 0xb7(%rsp)    # imm = 0xA656E
    1a51:      	leaq	0xa0(%rsp), %rdi
    1a59:      	movl	$0x1b, %eax
    1a5e:      	movl	$0x6, %ecx
    1a63:      	movl	$0x1b, %esi
    1a68:      	xorl	%eax, %eax
    1a6a:      	callq	*%rcx
    1a6c:      	jmp	0x1df0 <perf_unwind_native+0x1df0>
    1a71:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a7b:      	movq	%rax, 0x36(%rsp)
    1a80:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a8a:      	movq	%rax, 0x30(%rsp)
    1a8f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a99:      	movq	%rax, 0x28(%rsp)
    1a9e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1aa8:      	movq	%rax, 0x20(%rsp)
    1aad:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1ab7:      	movq	%rax, 0x18(%rsp)
    1abc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1ac6:      	movq	%rax, 0x10(%rsp)
    1acb:      	leaq	0x10(%rsp), %rdi
    1ad0:      	movl	$0x2e, %eax
    1ad5:      	movl	$0x6, %ecx
    1ada:      	movl	0x78(%rsp), %edx
    1ade:      	movl	$0x2e, %esi
    1ae3:      	xorl	%eax, %eax
    1ae5:      	callq	*%rcx
    1ae7:      	xorl	%eax, %eax
    1ae9:      	cmpl	$0x0, (%r14)
    1aed:      	je	0x1762 <perf_unwind_native+0x1762>
    1af3:      	jmp	0x16cf <perf_unwind_native+0x16cf>
    1af8:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    1b02:      	movq	%rax, 0x30(%rsp)
    1b07:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    1b11:      	movq	%rax, 0x28(%rsp)
    1b16:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    1b20:      	movq	%rax, 0x20(%rsp)
    1b25:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    1b2f:      	movq	%rax, 0x18(%rsp)
    1b34:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    1b3e:      	movq	%rax, 0x10(%rsp)
    1b43:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    1b4b:      	leaq	0x10(%rsp), %rdi
    1b50:      	movl	$0x2c, %eax
    1b55:      	movl	$0x6, %ecx
    1b5a:      	movl	$0x2c, %esi
    1b5f:      	movq	%r12, %rdx
    1b62:      	xorl	%eax, %eax
    1b64:      	callq	*%rcx
    1b66:      	movq	0x60(%rsp), %rdi
    1b6b:      	movq	%r14, %rax
    1b6e:      	movq	0x98(%rsp), %rcx
    1b76:      	xorl	%r12d, %r12d
    1b79:      	jmp	0x1450 <perf_unwind_native+0x1450>
    1b7e:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    1b88:      	movq	%rax, 0x30(%rsp)
    1b8d:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    1b97:      	movq	%rax, 0x28(%rsp)
    1b9c:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    1ba6:      	movq	%rax, 0x20(%rsp)
    1bab:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    1bb5:      	movq	%rax, 0x18(%rsp)
    1bba:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    1bc4:      	movq	%rax, 0x10(%rsp)
    1bc9:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    1bd1:      	leaq	0x10(%rsp), %rdi
    1bd6:      	movl	$0x2c, %eax
    1bdb:      	movl	$0x6, %ecx
    1be0:      	movl	$0x2c, %esi
    1be5:      	movq	%rbp, %rdx
    1be8:      	xorl	%eax, %eax
    1bea:      	callq	*%rcx
    1bec:      	movq	0x60(%rsp), %rdi
    1bf1:      	movq	%r14, %rax
    1bf4:      	jmp	0x153f <perf_unwind_native+0x153f>
    1bf9:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    1c03:      	movq	%rax, 0xc8(%rsp)
    1c0b:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    1c15:      	movq	%rax, 0xc0(%rsp)
    1c1d:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    1c27:      	movq	%rax, 0xb8(%rsp)
    1c2f:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    1c39:      	movq	%rax, 0xb0(%rsp)
    1c41:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    1c4b:      	movq	%rax, 0xa8(%rsp)
    1c53:      	movabsq	$0x6365732074786554, %r14 # imm = 0x6365732074786554
    1c5d:      	movq	%r14, 0xa0(%rsp)
    1c65:      	movw	$0xa, 0xd0(%rsp)
    1c6f:      	leaq	0xa0(%rsp), %rdi
    1c77:      	movl	$0x32, %eax
    1c7c:      	movl	$0x6, %r9d
    1c82:      	movq	0xf10(%rbx), %rcx
    1c89:      	movl	$0x32, %esi
    1c8e:      	movq	%r13, %rdx
    1c91:      	movl	%r12d, %r8d
    1c94:      	xorl	%eax, %eax
    1c96:      	callq	*%r9
    1c99:      	movq	(%rip), %rax            # 0x1ca0 <perf_unwind_native+0x1ca0>
    1ca0:      	cmpl	$0x0, (%rax)
    1ca3:      	je	0x197c <perf_unwind_native+0x197c>
    1ca9:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    1cb3:      	movq	%rax, 0xc7(%rsp)
    1cbb:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    1cc5:      	movq	%rax, 0xc0(%rsp)
    1ccd:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1cd7:      	movq	%rax, 0xb8(%rsp)
    1cdf:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1ce9:      	movq	%rax, 0xb0(%rsp)
    1cf1:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1cfb:      	movq	%rax, 0xa8(%rsp)
    1d03:      	movq	%r14, 0xa0(%rsp)
    1d0b:      	leaq	0xa0(%rsp), %rdi
    1d13:      	movl	$0x2f, %eax
    1d18:      	movl	$0x6, %r8d
    1d1e:      	movq	0xf18(%rbx), %rcx
    1d25:      	movq	0xf20(%rbx), %rdx
    1d2c:      	movl	$0x2f, %esi
    1d31:      	xorl	%eax, %eax
    1d33:      	callq	*%r8
    1d36:      	jmp	0x197c <perf_unwind_native+0x197c>
    1d3b:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    1d45:      	movq	%rax, 0xb6(%rsp)
    1d4d:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    1d57:      	movq	%rax, 0xb0(%rsp)
    1d5f:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    1d69:      	movq	%rax, 0xa8(%rsp)
    1d71:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1d7b:      	movq	%rax, 0xa0(%rsp)
    1d83:      	leaq	0xa0(%rsp), %rdi
    1d8b:      	movl	$0x1e, %eax
    1d90:      	movl	$0x6, %ecx
    1d95:      	movzwl	0x20(%r13), %edx
    1d9a:      	movl	$0x1e, %esi
    1d9f:      	xorl	%eax, %eax
    1da1:      	callq	*%rcx
    1da3:      	movl	0x1380(%rbx), %eax
    1da9:      	movl	0x20(%r13), %ecx
    1dad:      	btl	%ecx, %eax
    1db0:      	jb	0x1a00 <perf_unwind_native+0x1a00>
    1db6:      	movl	$0x0, 0x78(%rsp)
    1dbe:      	movq	(%rip), %rdi            # 0x1dc5 <perf_unwind_native+0x1dc5>
    1dc5:      	leaq	0x78(%rsp), %rsi
    1dca:      	movl	$0x1, %eax
    1dcf:      	callq	*%rax
    1dd1:      	testq	%rax, %rax
    1dd4:      	je	0x1ddb <perf_unwind_native+0x1ddb>
    1dd6:      	incq	(%rax)
    1dd9:      	jmp	0x1deb <perf_unwind_native+0x1deb>
    1ddb:      	movq	(%rip), %rax            # 0x1de2 <perf_unwind_native+0x1de2>
    1de2:      	cmpl	$0x0, (%rax)
    1de5:      	jne	0x2e07 <perf_unwind_native+0x2e07>
    1deb:      	movzwl	0x20(%r13), %r12d
    1df0:      	movq	0x68(%rsp), %rbp
    1df5:      	xorl	%r14d, %r14d
    1df8:      	cmpl	$0x1, %r12d
    1dfc:      	movq	(%rip), %r13            # 0x1e03 <perf_unwind_native+0x1e03>
    1e03:      	jne	0x5fd4 <perf_unwind_native+0x5fd4>
    1e09:      	cmpl	$0x0, (%r13)
    1e0e:      	jne	0x2b1a <perf_unwind_native+0x2b1a>
    1e14:      	movl	$0x5, 0x10(%rsp)
    1e1c:      	movq	(%rip), %rdi            # 0x1e23 <perf_unwind_native+0x1e23>
    1e23:      	leaq	0x10(%rsp), %rsi
    1e28:      	movl	$0x1, %eax
    1e2d:      	callq	*%rax
    1e2f:      	testq	%rax, %rax
    1e32:      	je	0x1edf <perf_unwind_native+0x1edf>
    1e38:      	incq	(%rax)
    1e3b:      	cmpl	$0x0, (%r13)
    1e40:      	je	0x1eea <perf_unwind_native+0x1eea>
    1e46:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
    1e50:      	movq	%rax, 0xc0(%rsp)
    1e58:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
    1e62:      	movq	%rax, 0xb8(%rsp)
    1e6a:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
    1e74:      	movq	%rax, 0xb0(%rsp)
    1e7c:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
    1e86:      	movq	%rax, 0xa8(%rsp)
    1e8e:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    1e98:      	movq	%rax, 0xa0(%rsp)
    1ea0:      	movl	$0xa6b63, 0xc7(%rsp)    # imm = 0xA6B63
    1eab:      	leaq	0xa0(%rsp), %rdi
    1eb3:      	movl	$0x2b, %eax
    1eb8:      	movl	$0x6, %r9d
    1ebe:      	movq	0xf10(%rbx), %rdx
    1ec5:      	movq	0xf18(%rbx), %rcx
    1ecc:      	movl	0x2c0(%rbx), %r8d
    1ed3:      	movl	$0x2b, %esi
    1ed8:      	xorl	%eax, %eax
    1eda:      	callq	*%r9
    1edd:      	jmp	0x1eea <perf_unwind_native+0x1eea>
    1edf:      	cmpl	$0x0, (%r13)
    1ee4:      	jne	0x2bef <perf_unwind_native+0x2bef>
    1eea:      	movl	0x2c0(%rbx), %eax
    1ef0:      	cmpq	$0x7e, %rax
    1ef4:      	ja	0x141 <perf_unwind_native+0x141>
    1efa:      	movzbl	0xf30(%rbx), %ecx
    1f01:      	movq	0xf10(%rbx), %rdx
    1f08:      	movq	0xf18(%rbx), %rsi
    1f0f:      	leal	0x1(%rax), %edi
    1f12:      	movl	%edi, 0x2c0(%rbx)
    1f18:      	leaq	(%rax,%rax,2), %rax
    1f1c:      	movq	%rdx, 0x2d0(%rbx,%rax,8)
    1f24:      	movq	%rsi, 0x2d8(%rbx,%rax,8)
    1f2c:      	movb	$0x3, 0x2e0(%rbx,%rax,8)
    1f34:      	movb	%cl, 0x2e1(%rbx,%rax,8)
    1f3b:      	movl	$0x0, 0x2e2(%rbx,%rax,8)
    1f46:      	movw	$0x0, 0x2e6(%rbx,%rax,8)
    1f50:      	movl	$0x0, 0x8c(%rsp)
    1f5b:      	movq	0xf10(%rbx), %rax
    1f62:      	movq	%rax, 0x160(%rsp)
    1f6a:      	movq	%rax, 0x78(%rsp)
    1f6f:      	movq	$-0x10000, %rax         # imm = 0xFFFF0000
    1f76:      	andq	0xf18(%rbx), %rax
    1f7d:      	movq	%rax, 0x80(%rsp)
    1f85:      	cmpl	$0x0, (%r13)
    1f8a:      	jne	0x2b81 <perf_unwind_native+0x2b81>
    1f90:      	movq	(%rip), %rdi            # 0x1f97 <perf_unwind_native+0x1f97>
    1f97:      	leaq	0x78(%rsp), %rsi
    1f9c:      	movl	$0x1, %eax
    1fa1:      	callq	*%rax
    1fa3:      	testq	%rax, %rax
    1fa6:      	je	0x56e8 <perf_unwind_native+0x56e8>
    1fac:      	movq	%rax, %r12
    1faf:      	movq	%rax, %rbp
    1fb2:      	addq	$0x6, %rbp
    1fb6:      	movzwl	0x6(%rax), %eax
    1fba:      	cmpl	$0xf, %eax
    1fbd:      	jg	0x1feb <perf_unwind_native+0x1feb>
    1fbf:      	cmpl	$0xb, %eax
    1fc2:      	jg	0x2013 <perf_unwind_native+0x2013>
    1fc4:      	cmpl	$0x9, %eax
    1fc7:      	jg	0x2059 <perf_unwind_native+0x2059>
    1fcd:      	cmpl	$0x8, %eax
    1fd0:      	je	0x20b8 <perf_unwind_native+0x20b8>
    1fd6:      	cmpl	$0x9, %eax
    1fd9:      	jne	0x586e <perf_unwind_native+0x586e>
    1fdf:      	movq	(%rip), %rdi            # 0x1fe6 <perf_unwind_native+0x1fe6>
    1fe6:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    1feb:      	cmpl	$0x13, %eax
    1fee:      	jg	0x2036 <perf_unwind_native+0x2036>
    1ff0:      	cmpl	$0x11, %eax
    1ff3:      	jg	0x2073 <perf_unwind_native+0x2073>
    1ff5:      	cmpl	$0x10, %eax
    1ff8:      	je	0x20c1 <perf_unwind_native+0x20c1>
    1ffe:      	cmpl	$0x11, %eax
    2001:      	jne	0x586e <perf_unwind_native+0x586e>
    2007:      	movq	(%rip), %rdi            # 0x200e <perf_unwind_native+0x200e>
    200e:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    2013:      	cmpl	$0xd, %eax
    2016:      	jg	0x208a <perf_unwind_native+0x208a>
    2018:      	cmpl	$0xc, %eax
    201b:      	je	0x20ca <perf_unwind_native+0x20ca>
    2021:      	cmpl	$0xd, %eax
    2024:      	jne	0x586e <perf_unwind_native+0x586e>
    202a:      	movq	(%rip), %rdi            # 0x2031 <perf_unwind_native+0x2031>
    2031:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    2036:      	cmpl	$0x15, %eax
    2039:      	jg	0x20a1 <perf_unwind_native+0x20a1>
    203b:      	cmpl	$0x14, %eax
    203e:      	je	0x20d3 <perf_unwind_native+0x20d3>
    2044:      	cmpl	$0x15, %eax
    2047:      	jne	0x586e <perf_unwind_native+0x586e>
    204d:      	movq	(%rip), %rdi            # 0x2054 <perf_unwind_native+0x2054>
    2054:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    2059:      	cmpl	$0xa, %eax
    205c:      	je	0x20dc <perf_unwind_native+0x20dc>
    205e:      	cmpl	$0xb, %eax
    2061:      	jne	0x586e <perf_unwind_native+0x586e>
    2067:      	movq	(%rip), %rdi            # 0x206e <perf_unwind_native+0x206e>
    206e:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    2073:      	cmpl	$0x12, %eax
    2076:      	je	0x20e5 <perf_unwind_native+0x20e5>
    2078:      	cmpl	$0x13, %eax
    207b:      	jne	0x586e <perf_unwind_native+0x586e>
    2081:      	movq	(%rip), %rdi            # 0x2088 <perf_unwind_native+0x2088>
    2088:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    208a:      	cmpl	$0xe, %eax
    208d:      	je	0x20ee <perf_unwind_native+0x20ee>
    208f:      	cmpl	$0xf, %eax
    2092:      	jne	0x586e <perf_unwind_native+0x586e>
    2098:      	movq	(%rip), %rdi            # 0x209f <perf_unwind_native+0x209f>
    209f:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20a1:      	cmpl	$0x16, %eax
    20a4:      	je	0x20f7 <perf_unwind_native+0x20f7>
    20a6:      	cmpl	$0x17, %eax
    20a9:      	jne	0x586e <perf_unwind_native+0x586e>
    20af:      	movq	(%rip), %rdi            # 0x20b6 <perf_unwind_native+0x20b6>
    20b6:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20b8:      	movq	(%rip), %rdi            # 0x20bf <perf_unwind_native+0x20bf>
    20bf:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20c1:      	movq	(%rip), %rdi            # 0x20c8 <perf_unwind_native+0x20c8>
    20c8:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20ca:      	movq	(%rip), %rdi            # 0x20d1 <perf_unwind_native+0x20d1>
    20d1:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20d3:      	movq	(%rip), %rdi            # 0x20da <perf_unwind_native+0x20da>
    20da:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20dc:      	movq	(%rip), %rdi            # 0x20e3 <perf_unwind_native+0x20e3>
    20e3:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20e5:      	movq	(%rip), %rdi            # 0x20ec <perf_unwind_native+0x20ec>
    20ec:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20ee:      	movq	(%rip), %rdi            # 0x20f5 <perf_unwind_native+0x20f5>
    20f5:      	jmp	0x20fe <perf_unwind_native+0x20fe>
    20f7:      	movq	(%rip), %rdi            # 0x20fe <perf_unwind_native+0x20fe>
    20fe:      	leaq	0x160(%rsp), %rsi
    2106:      	movl	$0x1, %eax
    210b:      	callq	*%rax
    210d:      	movq	%rax, 0x70(%rsp)
    2112:      	testq	%rax, %rax
    2115:      	je	0x5f9f <perf_unwind_native+0x5f9f>
    211b:      	movl	(%r12), %r13d
    211f:      	movl	%r13d, 0x90(%rsp)
    2127:      	movq	0xf18(%rbx), %rax
    212e:      	movq	%rax, 0x58(%rsp)
    2133:      	movzwl	0x4(%r12), %eax
    2139:      	testl	%eax, %eax
    213b:      	je	0x2691 <perf_unwind_native+0x2691>
    2141:      	movq	%rax, %r15
    2144:      	addl	%r13d, %r15d
    2147:      	movq	(%rip), %rax            # 0x214e <perf_unwind_native+0x214e>
    214e:      	cmpl	$0x0, (%rax)
    2151:      	jne	0x2c8a <perf_unwind_native+0x2c8a>
    2157:      	leal	(%r15,%r13), %eax
    215b:      	shrl	%eax
    215d:      	movl	%eax, 0x10(%rsp)
    2161:      	leaq	0x10(%rsp), %rsi
    2166:      	movl	$0x1, %eax
    216b:      	movq	0x70(%rsp), %rdi
    2170:      	callq	*%rax
    2172:      	testq	%rax, %rax
    2175:      	je	0x2735 <perf_unwind_native+0x2735>
    217b:      	movl	0x10(%rsp), %ecx
    217f:      	leal	0x1(%rcx), %ebp
    2182:      	movq	0x58(%rsp), %rdx
    2187:      	cmpw	%dx, (%rax)
    218a:      	cmoval	%r13d, %ebp
    218e:      	cmoval	%ecx, %r15d
    2192:      	movq	%r15, %rax
    2195:      	movq	%r15, 0x8(%rsp)
    219a:      	cmpl	%r15d, %ebp
    219d:      	jae	0x2681 <perf_unwind_native+0x2681>
    21a3:      	movq	0x8(%rsp), %rax
    21a8:      	addl	%ebp, %eax
    21aa:      	shrl	%eax
    21ac:      	movl	%eax, 0x10(%rsp)
    21b0:      	leaq	0x10(%rsp), %rsi
    21b5:      	movl	$0x1, %eax
    21ba:      	movq	0x70(%rsp), %rdi
    21bf:      	callq	*%rax
    21c1:      	testq	%rax, %rax
    21c4:      	je	0x2735 <perf_unwind_native+0x2735>
    21ca:      	movl	0x10(%rsp), %ecx
    21ce:      	leal	0x1(%rcx), %r13d
    21d2:      	movq	0x58(%rsp), %rdx
    21d7:      	cmpw	%dx, (%rax)
    21da:      	cmoval	%ebp, %r13d
    21de:      	movq	0x8(%rsp), %rdx
    21e3:      	cmoval	%ecx, %edx
    21e6:      	movq	%rdx, %rax
    21e9:      	movq	%rdx, 0x8(%rsp)
    21ee:      	cmpl	%edx, %r13d
    21f1:      	jae	0x2681 <perf_unwind_native+0x2681>
    21f7:      	movq	0x8(%rsp), %rax
    21fc:      	addl	%r13d, %eax
    21ff:      	shrl	%eax
    2201:      	movl	%eax, 0x10(%rsp)
    2205:      	leaq	0x10(%rsp), %rsi
    220a:      	movl	$0x1, %eax
    220f:      	movq	0x70(%rsp), %rdi
    2214:      	callq	*%rax
    2216:      	testq	%rax, %rax
    2219:      	je	0x2735 <perf_unwind_native+0x2735>
    221f:      	movl	0x10(%rsp), %ecx
    2223:      	leal	0x1(%rcx), %ebp
    2226:      	movq	0x58(%rsp), %rdx
    222b:      	cmpw	%dx, (%rax)
    222e:      	cmoval	%r13d, %ebp
    2232:      	movq	0x8(%rsp), %rdx
    2237:      	cmoval	%ecx, %edx
    223a:      	movq	%rdx, %rax
    223d:      	movq	%rdx, 0x8(%rsp)
    2242:      	cmpl	%edx, %ebp
    2244:      	jae	0x2681 <perf_unwind_native+0x2681>
    224a:      	movq	0x8(%rsp), %rax
    224f:      	addl	%ebp, %eax
    2251:      	shrl	%eax
    2253:      	movl	%eax, 0x10(%rsp)
    2257:      	leaq	0x10(%rsp), %rsi
    225c:      	movl	$0x1, %eax
    2261:      	movq	0x70(%rsp), %rdi
    2266:      	callq	*%rax
    2268:      	testq	%rax, %rax
    226b:      	je	0x2735 <perf_unwind_native+0x2735>
    2271:      	movl	0x10(%rsp), %ecx
    2275:      	leal	0x1(%rcx), %r13d
    2279:      	movq	0x58(%rsp), %rdx
    227e:      	cmpw	%dx, (%rax)
    2281:      	cmoval	%ebp, %r13d
    2285:      	movq	0x8(%rsp), %rdx
    228a:      	cmoval	%ecx, %edx
    228d:      	movq	%rdx, %rax
    2290:      	movq	%rdx, 0x8(%rsp)
    2295:      	cmpl	%edx, %r13d
    2298:      	jae	0x2681 <perf_unwind_native+0x2681>
    229e:      	movq	0x8(%rsp), %rax
    22a3:      	addl	%r13d, %eax
    22a6:      	shrl	%eax
    22a8:      	movl	%eax, 0x10(%rsp)
    22ac:      	leaq	0x10(%rsp), %rsi
    22b1:      	movl	$0x1, %eax
    22b6:      	movq	0x70(%rsp), %rdi
    22bb:      	callq	*%rax
    22bd:      	testq	%rax, %rax
    22c0:      	je	0x2735 <perf_unwind_native+0x2735>
    22c6:      	movl	0x10(%rsp), %ecx
    22ca:      	leal	0x1(%rcx), %ebp
    22cd:      	movq	0x58(%rsp), %rdx
    22d2:      	cmpw	%dx, (%rax)
    22d5:      	cmoval	%r13d, %ebp
    22d9:      	movq	0x8(%rsp), %rdx
    22de:      	cmoval	%ecx, %edx
    22e1:      	movq	%rdx, %rax
    22e4:      	movq	%rdx, 0x8(%rsp)
    22e9:      	cmpl	%edx, %ebp
    22eb:      	jae	0x2681 <perf_unwind_native+0x2681>
    22f1:      	movq	0x8(%rsp), %rax
    22f6:      	addl	%ebp, %eax
    22f8:      	shrl	%eax
    22fa:      	movl	%eax, 0x10(%rsp)
    22fe:      	leaq	0x10(%rsp), %rsi
    2303:      	movl	$0x1, %eax
    2308:      	movq	0x70(%rsp), %rdi
    230d:      	callq	*%rax
    230f:      	testq	%rax, %rax
    2312:      	je	0x2735 <perf_unwind_native+0x2735>
    2318:      	movl	0x10(%rsp), %ecx
    231c:      	leal	0x1(%rcx), %r13d
    2320:      	movq	0x58(%rsp), %rdx
    2325:      	cmpw	%dx, (%rax)
    2328:      	cmoval	%ebp, %r13d
    232c:      	movq	0x8(%rsp), %rdx
    2331:      	cmoval	%ecx, %edx
    2334:      	movq	%rdx, %rax
    2337:      	movq	%rdx, 0x8(%rsp)
    233c:      	cmpl	%edx, %r13d
    233f:      	jae	0x2681 <perf_unwind_native+0x2681>
    2345:      	movq	0x8(%rsp), %rax
    234a:      	addl	%r13d, %eax
    234d:      	shrl	%eax
    234f:      	movl	%eax, 0x10(%rsp)
    2353:      	leaq	0x10(%rsp), %rsi
    2358:      	movl	$0x1, %eax
    235d:      	movq	0x70(%rsp), %rdi
    2362:      	callq	*%rax
    2364:      	testq	%rax, %rax
    2367:      	je	0x2735 <perf_unwind_native+0x2735>
    236d:      	movl	0x10(%rsp), %ecx
    2371:      	leal	0x1(%rcx), %ebp
    2374:      	movq	0x58(%rsp), %rdx
    2379:      	cmpw	%dx, (%rax)
    237c:      	cmoval	%r13d, %ebp
    2380:      	movq	0x8(%rsp), %rdx
    2385:      	cmoval	%ecx, %edx
    2388:      	movq	%rdx, %rax
    238b:      	movq	%rdx, 0x8(%rsp)
    2390:      	cmpl	%edx, %ebp
    2392:      	jae	0x2681 <perf_unwind_native+0x2681>
    2398:      	movq	0x8(%rsp), %rax
    239d:      	addl	%ebp, %eax
    239f:      	shrl	%eax
    23a1:      	movl	%eax, 0x10(%rsp)
    23a5:      	leaq	0x10(%rsp), %rsi
    23aa:      	movl	$0x1, %eax
    23af:      	movq	0x70(%rsp), %rdi
    23b4:      	callq	*%rax
    23b6:      	testq	%rax, %rax
    23b9:      	je	0x2735 <perf_unwind_native+0x2735>
    23bf:      	movl	0x10(%rsp), %ecx
    23c3:      	leal	0x1(%rcx), %r13d
    23c7:      	movq	0x58(%rsp), %rdx
    23cc:      	cmpw	%dx, (%rax)
    23cf:      	cmoval	%ebp, %r13d
    23d3:      	movq	0x8(%rsp), %rdx
    23d8:      	cmoval	%ecx, %edx
    23db:      	movq	%rdx, %rax
    23de:      	movq	%rdx, 0x8(%rsp)
    23e3:      	cmpl	%edx, %r13d
    23e6:      	jae	0x2681 <perf_unwind_native+0x2681>
    23ec:      	movq	0x8(%rsp), %rax
    23f1:      	addl	%r13d, %eax
    23f4:      	shrl	%eax
    23f6:      	movl	%eax, 0x10(%rsp)
    23fa:      	leaq	0x10(%rsp), %rsi
    23ff:      	movl	$0x1, %eax
    2404:      	movq	0x70(%rsp), %rdi
    2409:      	callq	*%rax
    240b:      	testq	%rax, %rax
    240e:      	je	0x2735 <perf_unwind_native+0x2735>
    2414:      	movl	0x10(%rsp), %ecx
    2418:      	leal	0x1(%rcx), %ebp
    241b:      	movq	0x58(%rsp), %rdx
    2420:      	cmpw	%dx, (%rax)
    2423:      	cmoval	%r13d, %ebp
    2427:      	movq	0x8(%rsp), %rdx
    242c:      	cmoval	%ecx, %edx
    242f:      	movq	%rdx, %rax
    2432:      	movq	%rdx, 0x8(%rsp)
    2437:      	cmpl	%edx, %ebp
    2439:      	jae	0x2681 <perf_unwind_native+0x2681>
    243f:      	movq	0x8(%rsp), %rax
    2444:      	addl	%ebp, %eax
    2446:      	shrl	%eax
    2448:      	movl	%eax, 0x10(%rsp)
    244c:      	leaq	0x10(%rsp), %rsi
    2451:      	movl	$0x1, %eax
    2456:      	movq	0x70(%rsp), %rdi
    245b:      	callq	*%rax
    245d:      	testq	%rax, %rax
    2460:      	je	0x2735 <perf_unwind_native+0x2735>
    2466:      	movl	0x10(%rsp), %ecx
    246a:      	leal	0x1(%rcx), %r13d
    246e:      	movq	0x58(%rsp), %rdx
    2473:      	cmpw	%dx, (%rax)
    2476:      	cmoval	%ebp, %r13d
    247a:      	movq	0x8(%rsp), %rdx
    247f:      	cmoval	%ecx, %edx
    2482:      	movq	%rdx, %rax
    2485:      	movq	%rdx, 0x8(%rsp)
    248a:      	cmpl	%edx, %r13d
    248d:      	jae	0x2681 <perf_unwind_native+0x2681>
    2493:      	movq	0x8(%rsp), %rax
    2498:      	addl	%r13d, %eax
    249b:      	shrl	%eax
    249d:      	movl	%eax, 0x10(%rsp)
    24a1:      	leaq	0x10(%rsp), %rsi
    24a6:      	movl	$0x1, %eax
    24ab:      	movq	0x70(%rsp), %rdi
    24b0:      	callq	*%rax
    24b2:      	testq	%rax, %rax
    24b5:      	je	0x2735 <perf_unwind_native+0x2735>
    24bb:      	movl	0x10(%rsp), %ecx
    24bf:      	leal	0x1(%rcx), %ebp
    24c2:      	movq	0x58(%rsp), %rdx
    24c7:      	cmpw	%dx, (%rax)
    24ca:      	cmoval	%r13d, %ebp
    24ce:      	movq	0x8(%rsp), %rdx
    24d3:      	cmoval	%ecx, %edx
    24d6:      	movq	%rdx, %rax
    24d9:      	movq	%rdx, 0x8(%rsp)
    24de:      	cmpl	%edx, %ebp
    24e0:      	jae	0x2681 <perf_unwind_native+0x2681>
    24e6:      	movq	0x8(%rsp), %rax
    24eb:      	addl	%ebp, %eax
    24ed:      	shrl	%eax
    24ef:      	movl	%eax, 0x10(%rsp)
    24f3:      	leaq	0x10(%rsp), %rsi
    24f8:      	movl	$0x1, %eax
    24fd:      	movq	0x70(%rsp), %rdi
    2502:      	callq	*%rax
    2504:      	testq	%rax, %rax
    2507:      	je	0x2735 <perf_unwind_native+0x2735>
    250d:      	movl	0x10(%rsp), %ecx
    2511:      	leal	0x1(%rcx), %r13d
    2515:      	movq	0x58(%rsp), %rdx
    251a:      	cmpw	%dx, (%rax)
    251d:      	cmoval	%ebp, %r13d
    2521:      	movq	0x8(%rsp), %rdx
    2526:      	cmoval	%ecx, %edx
    2529:      	movq	%rdx, %rax
    252c:      	movq	%rdx, 0x8(%rsp)
    2531:      	cmpl	%edx, %r13d
    2534:      	jae	0x2681 <perf_unwind_native+0x2681>
    253a:      	movq	0x8(%rsp), %rax
    253f:      	addl	%r13d, %eax
    2542:      	shrl	%eax
    2544:      	movl	%eax, 0x10(%rsp)
    2548:      	leaq	0x10(%rsp), %rsi
    254d:      	movl	$0x1, %eax
    2552:      	movq	0x70(%rsp), %rdi
    2557:      	callq	*%rax
    2559:      	testq	%rax, %rax
    255c:      	je	0x2735 <perf_unwind_native+0x2735>
    2562:      	movl	0x10(%rsp), %ecx
    2566:      	leal	0x1(%rcx), %ebp
    2569:      	movq	0x58(%rsp), %rdx
    256e:      	cmpw	%dx, (%rax)
    2571:      	cmoval	%r13d, %ebp
    2575:      	movq	0x8(%rsp), %rdx
    257a:      	cmoval	%ecx, %edx
    257d:      	movq	%rdx, %rax
    2580:      	movq	%rdx, 0x8(%rsp)
    2585:      	cmpl	%edx, %ebp
    2587:      	jae	0x2681 <perf_unwind_native+0x2681>
    258d:      	movq	0x8(%rsp), %rax
    2592:      	addl	%ebp, %eax
    2594:      	shrl	%eax
    2596:      	movl	%eax, 0x10(%rsp)
    259a:      	leaq	0x10(%rsp), %rsi
    259f:      	movl	$0x1, %eax
    25a4:      	movq	0x70(%rsp), %rdi
    25a9:      	callq	*%rax
    25ab:      	testq	%rax, %rax
    25ae:      	je	0x2735 <perf_unwind_native+0x2735>
    25b4:      	movl	0x10(%rsp), %ecx
    25b8:      	leal	0x1(%rcx), %r13d
    25bc:      	movq	0x58(%rsp), %rdx
    25c1:      	cmpw	%dx, (%rax)
    25c4:      	cmoval	%ebp, %r13d
    25c8:      	movq	0x8(%rsp), %rdx
    25cd:      	cmoval	%ecx, %edx
    25d0:      	movq	%rdx, %rax
    25d3:      	movq	%rdx, 0x8(%rsp)
    25d8:      	cmpl	%edx, %r13d
    25db:      	jae	0x2681 <perf_unwind_native+0x2681>
    25e1:      	movq	0x8(%rsp), %rax
    25e6:      	addl	%r13d, %eax
    25e9:      	shrl	%eax
    25eb:      	movl	%eax, 0x10(%rsp)
    25ef:      	leaq	0x10(%rsp), %rsi
    25f4:      	movl	$0x1, %eax
    25f9:      	movq	0x70(%rsp), %rdi
    25fe:      	callq	*%rax
    2600:      	testq	%rax, %rax
    2603:      	je	0x2735 <perf_unwind_native+0x2735>
    2609:      	movl	0x10(%rsp), %ecx
    260d:      	leal	0x1(%rcx), %ebp
    2610:      	movq	0x58(%rsp), %rdx
    2615:      	cmpw	%dx, (%rax)
    2618:      	cmoval	%r13d, %ebp
    261c:      	movq	0x8(%rsp), %rdx
    2621:      	cmoval	%ecx, %edx
    2624:      	movq	%rdx, %rax
    2627:      	movq	%rdx, 0x8(%rsp)
    262c:      	cmpl	%edx, %ebp
    262e:      	jae	0x2681 <perf_unwind_native+0x2681>
    2630:      	movq	0x8(%rsp), %rax
    2635:      	addl	%ebp, %eax
    2637:      	shrl	%eax
    2639:      	movl	%eax, 0x10(%rsp)
    263d:      	leaq	0x10(%rsp), %rsi
    2642:      	movl	$0x1, %eax
    2647:      	movq	0x70(%rsp), %rdi
    264c:      	callq	*%rax
    264e:      	testq	%rax, %rax
    2651:      	je	0x2735 <perf_unwind_native+0x2735>
    2657:      	movl	0x10(%rsp), %ecx
    265b:      	leal	0x1(%rcx), %edx
    265e:      	movq	0x58(%rsp), %rsi
    2663:      	cmpw	%si, (%rax)
    2666:      	cmoval	%ebp, %edx
    2669:      	movq	0x8(%rsp), %rsi
    266e:      	cmoval	%ecx, %esi
    2671:      	movq	%rsi, %rax
    2674:      	movq	%rsi, 0x8(%rsp)
    2679:      	cmpl	%esi, %edx
    267b:      	jb	0x2735 <perf_unwind_native+0x2735>
    2681:      	movq	0x8(%rsp), %rax
    2686:      	movl	%eax, %r13d
    2689:      	testl	%eax, %eax
    268b:      	je	0x2735 <perf_unwind_native+0x2735>
    2691:      	decl	%r13d
    2694:      	movl	%r13d, 0x90(%rsp)
    269c:      	leaq	0x90(%rsp), %rsi
    26a4:      	movl	$0x1, %eax
    26a9:      	movq	0x70(%rsp), %rdi
    26ae:      	callq	*%rax
    26b0:      	testq	%rax, %rax
    26b3:      	je	0x4346 <perf_unwind_native+0x4346>
    26b9:      	movq	%rax, %rbp
    26bc:      	movq	(%rip), %rax            # 0x26c3 <perf_unwind_native+0x26c3>
    26c3:      	cmpl	$0x0, (%rax)
    26c6:      	jne	0x2d7e <perf_unwind_native+0x2d7e>
    26cc:      	movzwl	0x58(%rsp), %eax
    26d1:      	movzwl	(%rbp), %ecx
    26d5:      	subl	%ecx, %eax
    26d7:      	movl	0x90(%rsp), %ecx
    26de:      	cmpl	(%r12), %ecx
    26e2:      	leal	0x10000(%rax), %r13d
    26e9:      	cmovael	%eax, %r13d
    26ed:      	movzwl	0x2(%rbp), %eax
    26f1:      	movl	%eax, 0x8c(%rsp)
    26f8:      	cmpl	$0x8000, %eax           # imm = 0x8000
    26fd:      	je	0x4329 <perf_unwind_native+0x4329>
    2703:      	cmpl	$0x8001, %eax           # imm = 0x8001
    2708:      	jne	0x276b <perf_unwind_native+0x276b>
    270a:      	movl	$0x7, 0x94(%rsp)
    2715:      	movq	(%rip), %rdi            # 0x271c <perf_unwind_native+0x271c>
    271c:      	leaq	0x94(%rsp), %rsi
    2724:      	movl	$0x1, %eax
    2729:      	callq	*%rax
    272b:      	testq	%rax, %rax
    272e:      	je	0x2754 <perf_unwind_native+0x2754>
    2730:      	incq	(%rax)
    2733:      	jmp	0x2764 <perf_unwind_native+0x2764>
    2735:      	movq	(%rip), %rax            # 0x273c <perf_unwind_native+0x273c>
    273c:      	cmpl	$0x0, (%rax)
    273f:      	jne	0x2d0e <perf_unwind_native+0x2d0e>
    2745:      	movl	$0xfa3, %ecx            # imm = 0xFA3
    274a:      	movl	$0x9, %edx
    274f:      	jmp	0x4333 <perf_unwind_native+0x4333>
    2754:      	movq	(%rip), %rax            # 0x275b <perf_unwind_native+0x275b>
    275b:      	cmpl	$0x0, (%rax)
    275e:      	jne	0x2f0b <perf_unwind_native+0x2f0b>
    2764:      	movl	0x8c(%rsp), %eax
    276b:      	testw	%ax, %ax
    276e:      	js	0x2829 <perf_unwind_native+0x2829>
    2774:      	movq	(%rip), %rdi            # 0x277b <perf_unwind_native+0x277b>
    277b:      	leaq	0x8c(%rsp), %rsi
    2783:      	movl	$0x1, %eax
    2788:      	callq	*%rax
    278a:      	movq	%rax, 0x70(%rsp)
    278f:      	testq	%rax, %rax
    2792:      	movq	0x158(%rsp), %r15
    279a:      	je	0x6393 <perf_unwind_native+0x6393>
    27a0:      	movq	0x70(%rsp), %rax
    27a5:      	movl	0x4(%rax), %ebp
    27a8:      	movzbl	0x2(%rax), %eax
    27ac:      	testb	%al, %al
    27ae:      	je	0x27ec <perf_unwind_native+0x27ec>
    27b0:      	movq	(%rip), %rcx            # 0x27b7 <perf_unwind_native+0x27b7>
    27b7:      	cmpl	$0x0, (%rcx)
    27ba:      	jne	0x2e97 <perf_unwind_native+0x2e97>
    27c0:      	movl	%eax, %ecx
    27c2:      	andb	$0x7f, %cl
    27c5:      	movzbl	%cl, %ecx
    27c8:      	cmpl	%ecx, %r13d
    27cb:      	jl	0x27ec <perf_unwind_native+0x27ec>
    27cd:      	xorl	%ecx, %ecx
    27cf:      	testb	%al, %al
    27d1:      	setns	%cl
    27d4:      	shll	$0x4, %ecx
    27d7:      	addl	%ecx, %ebp
    27d9:      	addl	$-0x8, %ebp
    27dc:      	movq	(%rip), %rax            # 0x27e3 <perf_unwind_native+0x27e3>
    27e3:      	cmpl	$0x0, (%rax)
    27e6:      	jne	0x2f89 <perf_unwind_native+0x2f89>
    27ec:      	movq	0x70(%rsp), %rax
    27f1:      	movzbl	(%rax), %eax
    27f4:      	movl	%ebp, %ecx
    27f6:      	andl	$-0x8, %ecx
    27f9:      	testb	%al, %al
    27fb:      	cmovnsl	%ebp, %ecx
    27fe:      	movl	%eax, %edx
    2800:      	andl	$0x7f, %edx
    2803:      	xorl	%r13d, %r13d
    2806:      	cmpl	$0x2, %edx
    2809:      	jg	0x2947 <perf_unwind_native+0x2947>
    280f:      	cmpl	$0x1, %edx
    2812:      	je	0x2ac0 <perf_unwind_native+0x2ac0>
    2818:      	movq	%r15, %rsi
    281b:      	cmpl	$0x2, %edx
    281e:      	je	0x2abd <perf_unwind_native+0x2abd>
    2824:      	jmp	0x3063 <perf_unwind_native+0x3063>
    2829:      	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    282e:      	movl	$0x1, %r13d
    2834:      	cmpl	$0x2, %eax
    2837:      	jg	0x28cd <perf_unwind_native+0x28cd>
    283d:      	cmpl	$0x1, %eax
    2840:      	movq	0x68(%rsp), %rbp
    2845:      	movq	0x140(%rsp), %rcx
    284d:      	movq	0x158(%rsp), %rdx
    2855:      	je	0x64f2 <perf_unwind_native+0x64f2>
    285b:      	cmpl	$0x2, %eax
    285e:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    2864:      	movq	%rdx, %r15
    2867:      	movq	(%rdx), %rax
    286a:      	movl	(%rcx), %ecx
    286c:      	andl	$0xf, %ecx
    286f:      	xorl	%edx, %edx
    2871:      	cmpl	$0xb, %ecx
    2874:      	setae	%dl
    2877:      	leaq	(%rax,%rdx,8), %r13
    287b:      	addq	$0x8, %r13
    287f:      	movq	(%rip), %rax            # 0x2886 <perf_unwind_native+0x2886>
    2886:      	cmpl	$0x0, (%rax)
    2889:      	je	0x3278 <perf_unwind_native+0x3278>
    288f:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    2899:      	movq	%rax, 0x18(%rsp)
    289e:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
    28a8:      	movq	%rax, 0x10(%rsp)
    28ad:      	leaq	0x10(%rsp), %rdi
    28b2:      	movl	$0x10, %eax
    28b7:      	movl	$0x6, %ecx
    28bc:      	movl	$0x10, %esi
    28c1:      	movq	%r13, %rdx
    28c4:      	xorl	%eax, %eax
    28c6:      	callq	*%rcx
    28c8:      	jmp	0x3278 <perf_unwind_native+0x3278>
    28cd:      	cmpl	$0x3, %eax
    28d0:      	je	0x29ac <perf_unwind_native+0x29ac>
    28d6:      	cmpl	$0x4, %eax
    28d9:      	movq	0x68(%rsp), %rbp
    28de:      	movq	0x60(%rsp), %rdx
    28e3:      	movq	0x158(%rsp), %r15
    28eb:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    28f1:      	movq	(%rdx), %rax
    28f4:      	leaq	0x10(%rsp), %rdi
    28f9:      	movl	$0x10, %ecx
    28fe:      	movl	$0x70, %r8d
    2904:      	movq	(%rdx), %rdx
    2907:      	movl	$0x10, %esi
    290c:      	callq	*%r8
    290f:      	testq	%rax, %rax
    2912:      	jne	0x163b <perf_unwind_native+0x163b>
    2918:      	movq	0xee0(%rbx), %rax
    291f:      	addq	$0x10, %rax
    2923:      	movq	%rax, 0xed8(%rbx)
    292a:      	movq	0x10(%rsp), %rax
    292f:      	movq	%rax, 0xee0(%rbx)
    2936:      	movq	0x18(%rsp), %rax
    293b:      	movq	%rax, 0xed0(%rbx)
    2942:      	jmp	0x32b3 <perf_unwind_native+0x32b3>
    2947:      	cmpl	$0x3, %edx
    294a:      	je	0x2ab8 <perf_unwind_native+0x2ab8>
    2950:      	cmpl	$0x5, %edx
    2953:      	jne	0x3063 <perf_unwind_native+0x3063>
    2959:      	movl	%ebp, %eax
    295b:      	sarl	%eax
    295d:      	andl	$-0x8, %eax
    2960:      	cltq
    2962:      	movq	%rax, 0x78(%rsp)
    2967:      	movq	(%rip), %rax            # 0x296e <perf_unwind_native+0x296e>
    296e:      	cmpl	$0x0, (%rax)
    2971:      	jne	0x2fee <perf_unwind_native+0x2fee>
    2977:      	andl	$0xf, %ebp
    297a:      	xorl	%r13d, %r13d
    297d:      	cmpl	$0xa, %ebp
    2980:      	jg	0x3041 <perf_unwind_native+0x3041>
    2986:      	movq	0x138(%rsp), %rax
    298e:      	testl	%ebp, %ebp
    2990:      	je	0x305b <perf_unwind_native+0x305b>
    2996:      	cmpl	$0x9, %ebp
    2999:      	jne	0x3063 <perf_unwind_native+0x3063>
    299f:      	movq	0x148(%rsp), %rax
    29a7:      	jmp	0x305b <perf_unwind_native+0x305b>
    29ac:      	movq	0x158(%rsp), %rdx
    29b4:      	movq	(%rdx), %rax
    29b7:      	addq	$0x28, %rax
    29bb:      	leaq	0xa0(%rsp), %rdi
    29c3:      	movl	$0x90, %ecx
    29c8:      	movl	$0x70, %r8d
    29ce:      	movq	%rdx, %r15
    29d1:      	movq	(%rdx), %rdx
    29d4:      	addq	$0x28, %rdx
    29d8:      	movl	$0x90, %esi
    29dd:      	callq	*%r8
    29e0:      	testq	%rax, %rax
    29e3:      	movq	0x68(%rsp), %rbp
    29e8:      	jne	0x163b <perf_unwind_native+0x163b>
    29ee:      	movq	0x108(%rsp), %rax
    29f6:      	movq	%rax, 0xee8(%rbx)
    29fd:      	movq	0xa8(%rsp), %rax
    2a05:      	movq	%rax, 0xef0(%rbx)
    2a0c:      	movq	0xb8(%rsp), %rax
    2a14:      	movq	%rax, 0xef8(%rbx)
    2a1b:      	movq	0xc8(%rsp), %rax
    2a23:      	movq	%rax, 0xf00(%rbx)
    2a2a:      	movq	0xd8(%rsp), %rax
    2a32:      	movq	%rax, 0xf08(%rbx)
    2a39:      	movq	0xf0(%rsp), %rax
    2a41:      	movq	%rax, 0xee0(%rbx)
    2a48:      	movq	0x118(%rsp), %rax
    2a50:      	movq	%rax, 0xed8(%rbx)
    2a57:      	movq	0x120(%rsp), %rax
    2a5f:      	movq	%rax, 0xed0(%rbx)
    2a66:      	movb	$0x0, 0xf30(%rbx)
    2a6d:      	movq	(%rip), %rax            # 0x2a74 <perf_unwind_native+0x2a74>
    2a74:      	cmpl	$0x0, (%rax)
    2a77:      	je	0x32ba <perf_unwind_native+0x32ba>
    2a7d:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    2a87:      	movq	%rax, 0x16(%rsp)
    2a8c:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
    2a96:      	movq	%rax, 0x10(%rsp)
    2a9b:      	leaq	0x10(%rsp), %rdi
    2aa0:      	movl	$0xe, %eax
    2aa5:      	movl	$0x6, %ecx
    2aaa:      	movl	$0xe, %esi
    2aaf:      	xorl	%eax, %eax
    2ab1:      	callq	*%rcx
    2ab3:      	jmp	0x32ba <perf_unwind_native+0x32ba>
    2ab8:      	movq	0x60(%rsp), %rsi
    2abd:      	movq	(%rsi), %r13
    2ac0:      	movq	%r13, %rdx
    2ac3:      	movslq	%ecx, %r13
    2ac6:      	addq	%rdx, %r13
    2ac9:      	testb	%al, %al
    2acb:      	jns	0x3063 <perf_unwind_native+0x3063>
    2ad1:      	leaq	0x78(%rsp), %rdi
    2ad6:      	movl	$0x8, %eax
    2adb:      	movl	$0x70, %ecx
    2ae0:      	movl	$0x8, %esi
    2ae5:      	movq	%r13, %rdx
    2ae8:      	callq	*%rcx
    2aea:      	testq	%rax, %rax
    2aed:      	je	0x2b07 <perf_unwind_native+0x2b07>
    2aef:      	movq	(%rip), %rax            # 0x2af6 <perf_unwind_native+0x2af6>
    2af6:      	cmpl	$0x0, (%rax)
    2af9:      	jne	0x377b <perf_unwind_native+0x377b>
    2aff:      	xorl	%r13d, %r13d
    2b02:      	jmp	0x3063 <perf_unwind_native+0x3063>
    2b07:      	shll	$0x3, %ebp
    2b0a:      	andl	$0x38, %ebp
    2b0d:      	addq	0x78(%rsp), %rbp
    2b12:      	movq	%rbp, %r13
    2b15:      	jmp	0x3063 <perf_unwind_native+0x3063>
    2b1a:      	movl	0x2c0(%rbx), %edx
    2b20:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
    2b2a:      	movq	%rax, 0xb0(%rsp)
    2b32:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
    2b3c:      	movq	%rax, 0xa8(%rsp)
    2b44:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
    2b4e:      	movq	%rax, 0xa0(%rsp)
    2b56:      	movl	$0xa3d3d, 0xb8(%rsp)    # imm = 0xA3D3D
    2b61:      	leaq	0xa0(%rsp), %rdi
    2b69:      	movl	$0x1c, %eax
    2b6e:      	movl	$0x6, %ecx
    2b73:      	movl	$0x1c, %esi
    2b78:      	xorl	%eax, %eax
    2b7a:      	callq	*%rcx
    2b7c:      	jmp	0x1e14 <perf_unwind_native+0x1e14>
    2b81:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
    2b8b:      	movq	%rax, 0x28(%rsp)
    2b90:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
    2b9a:      	movq	%rax, 0x20(%rsp)
    2b9f:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
    2ba9:      	movq	%rax, 0x18(%rsp)
    2bae:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
    2bb8:      	movq	%rax, 0x10(%rsp)
    2bbd:      	movb	$0x0, 0x30(%rsp)
    2bc2:      	leaq	0x10(%rsp), %rdi
    2bc7:      	movl	$0x21, %eax
    2bcc:      	movl	$0x6, %r8d
    2bd2:      	movq	0xf10(%rbx), %rdx
    2bd9:      	movq	0xf18(%rbx), %rcx
    2be0:      	movl	$0x21, %esi
    2be5:      	xorl	%eax, %eax
    2be7:      	callq	*%r8
    2bea:      	jmp	0x1f90 <perf_unwind_native+0x1f90>
    2bef:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2bf9:      	movq	%rax, 0xc6(%rsp)
    2c01:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2c0b:      	movq	%rax, 0xc0(%rsp)
    2c13:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2c1d:      	movq	%rax, 0xb8(%rsp)
    2c25:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2c2f:      	movq	%rax, 0xb0(%rsp)
    2c37:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2c41:      	movq	%rax, 0xa8(%rsp)
    2c49:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2c53:      	movq	%rax, 0xa0(%rsp)
    2c5b:      	leaq	0xa0(%rsp), %rdi
    2c63:      	movl	$0x2e, %eax
    2c68:      	movl	$0x6, %ecx
    2c6d:      	movl	0x10(%rsp), %edx
    2c71:      	movl	$0x2e, %esi
    2c76:      	xorl	%eax, %eax
    2c78:      	callq	*%rcx
    2c7a:      	cmpl	$0x0, (%r13)
    2c7f:      	je	0x1eea <perf_unwind_native+0x1eea>
    2c85:      	jmp	0x1e46 <perf_unwind_native+0x1e46>
    2c8a:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
    2c94:      	movq	%rax, 0x38(%rsp)
    2c99:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
    2ca3:      	movq	%rax, 0x30(%rsp)
    2ca8:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
    2cb2:      	movq	%rax, 0x28(%rsp)
    2cb7:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
    2cc1:      	movq	%rax, 0x20(%rsp)
    2cc6:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
    2cd0:      	movq	%rax, 0x18(%rsp)
    2cd5:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
    2cdf:      	movq	%rax, 0x10(%rsp)
    2ce4:      	leaq	0x10(%rsp), %rdi
    2ce9:      	movl	$0x30, %eax
    2cee:      	movl	$0x6, %r9d
    2cf4:      	movl	%r15d, %ecx
    2cf7:      	movzwl	(%rbp), %r8d
    2cfc:      	movl	$0x30, %esi
    2d01:      	movq	%r13, %rdx
    2d04:      	xorl	%eax, %eax
    2d06:      	callq	*%r9
    2d09:      	jmp	0x2157 <perf_unwind_native+0x2157>
    2d0e:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
    2d18:      	movq	%rax, 0x30(%rsp)
    2d1d:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
    2d27:      	movq	%rax, 0x28(%rsp)
    2d2c:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
    2d36:      	movq	%rax, 0x20(%rsp)
    2d3b:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
    2d45:      	movq	%rax, 0x18(%rsp)
    2d4a:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
    2d54:      	movq	%rax, 0x10(%rsp)
    2d59:      	movl	$0xa3f61, 0x37(%rsp)    # imm = 0xA3F61
    2d61:      	leaq	0x10(%rsp), %rdi
    2d66:      	movl	$0x2b, %eax
    2d6b:      	movl	$0x6, %ecx
    2d70:      	movl	$0x2b, %esi
    2d75:      	xorl	%eax, %eax
    2d77:      	callq	*%rcx
    2d79:      	jmp	0x2745 <perf_unwind_native+0x2745>
    2d7e:      	movabsq	$0xa6425206f666e, %rax  # imm = 0xA6425206F666E
    2d88:      	movq	%rax, 0x35(%rsp)
    2d8d:      	movabsq	$0x6f666e49646e6977, %rax # imm = 0x6F666E49646E6977
    2d97:      	movq	%rax, 0x30(%rsp)
    2d9c:      	movabsq	$0x6e75202c78257830, %rax # imm = 0x6E75202C78257830
    2da6:      	movq	%rax, 0x28(%rsp)
    2dab:      	movabsq	$0x20776f4c72646461, %rax # imm = 0x20776F4C72646461
    2db5:      	movq	%rax, 0x20(%rsp)
    2dba:      	movabsq	$0x202c642520786564, %rax # imm = 0x202C642520786564
    2dc4:      	movq	%rax, 0x18(%rsp)
    2dc9:      	movabsq	$0x6e692061746c6564, %rax # imm = 0x6E692061746C6564
    2dd3:      	movq	%rax, 0x10(%rsp)
    2dd8:      	leaq	0x10(%rsp), %rdi
    2ddd:      	movl	$0x2d, %eax
    2de2:      	movl	$0x6, %r9d
    2de8:      	movl	0x90(%rsp), %edx
    2def:      	movzwl	(%rbp), %ecx
    2df3:      	movzwl	0x2(%rbp), %r8d
    2df8:      	movl	$0x2d, %esi
    2dfd:      	xorl	%eax, %eax
    2dff:      	callq	*%r9
    2e02:      	jmp	0x26cc <perf_unwind_native+0x26cc>
    2e07:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2e11:      	movq	%rax, 0xc6(%rsp)
    2e19:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2e23:      	movq	%rax, 0xc0(%rsp)
    2e2b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2e35:      	movq	%rax, 0xb8(%rsp)
    2e3d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2e47:      	movq	%rax, 0xb0(%rsp)
    2e4f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2e59:      	movq	%rax, 0xa8(%rsp)
    2e61:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2e6b:      	movq	%rax, 0xa0(%rsp)
    2e73:      	leaq	0xa0(%rsp), %rdi
    2e7b:      	movl	$0x2e, %eax
    2e80:      	movl	$0x6, %ecx
    2e85:      	movl	0x78(%rsp), %edx
    2e89:      	movl	$0x2e, %esi
    2e8e:      	xorl	%eax, %eax
    2e90:      	callq	*%rcx
    2e92:      	jmp	0x1deb <perf_unwind_native+0x1deb>
    2e97:      	movabsq	$0xa78323023252061, %rax # imm = 0xA78323023252061
    2ea1:      	movq	%rax, 0x28(%rsp)
    2ea6:      	movabsq	$0x746c656420646567, %rax # imm = 0x746C656420646567
    2eb0:      	movq	%rax, 0x20(%rsp)
    2eb5:      	movabsq	$0x72656d202c642520, %rax # imm = 0x72656D202C642520
    2ebf:      	movq	%rax, 0x18(%rsp)
    2ec4:      	movabsq	$0x6666694472646441, %rax # imm = 0x6666694472646441
    2ece:      	movq	%rax, 0x10(%rsp)
    2ed3:      	movb	$0x0, 0x30(%rsp)
    2ed8:      	leaq	0x10(%rsp), %rdi
    2edd:      	movl	$0x21, %eax
    2ee2:      	movl	$0x6, %r8d
    2ee8:      	movq	0x70(%rsp), %r12
    2eed:      	movzbl	0x2(%r12), %ecx
    2ef3:      	movl	$0x21, %esi
    2ef8:      	movl	%r13d, %edx
    2efb:      	xorl	%eax, %eax
    2efd:      	callq	*%r8
    2f00:      	movzbl	0x2(%r12), %eax
    2f06:      	jmp	0x27c0 <perf_unwind_native+0x27c0>
    2f0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2f15:      	movq	%rax, 0x36(%rsp)
    2f1a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2f24:      	movq	%rax, 0x30(%rsp)
    2f29:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2f33:      	movq	%rax, 0x28(%rsp)
    2f38:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2f42:      	movq	%rax, 0x20(%rsp)
    2f47:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2f51:      	movq	%rax, 0x18(%rsp)
    2f56:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f60:      	movq	%rax, 0x10(%rsp)
    2f65:      	leaq	0x10(%rsp), %rdi
    2f6a:      	movl	$0x2e, %eax
    2f6f:      	movl	$0x6, %ecx
    2f74:      	movl	0x94(%rsp), %edx
    2f7b:      	movl	$0x2e, %esi
    2f80:      	xorl	%eax, %eax
    2f82:      	callq	*%rcx
    2f84:      	jmp	0x2764 <perf_unwind_native+0x2764>
    2f89:      	movabsq	$0xa64253d61746c65, %rax # imm = 0xA64253D61746C65
    2f93:      	movq	%rax, 0x28(%rsp)
    2f98:      	movabsq	$0x44616663203a6863, %rax # imm = 0x44616663203A6863
    2fa2:      	movq	%rax, 0x20(%rsp)
    2fa7:      	movabsq	$0x74616d2061746c65, %rax # imm = 0x74616D2061746C65
    2fb1:      	movq	%rax, 0x18(%rsp)
    2fb6:      	movabsq	$0x642064656772654d, %rax # imm = 0x642064656772654D
    2fc0:      	movq	%rax, 0x10(%rsp)
    2fc5:      	movb	$0x0, 0x30(%rsp)
    2fca:      	leaq	0x10(%rsp), %rdi
    2fcf:      	movl	$0x21, %eax
    2fd4:      	movl	$0x6, %ecx
    2fd9:      	movl	0x8c(%rsp), %edx
    2fe0:      	movl	$0x21, %esi
    2fe5:      	xorl	%eax, %eax
    2fe7:      	callq	*%rcx
    2fe9:      	jmp	0x27ec <perf_unwind_native+0x27ec>
    2fee:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    2ff8:      	movq	%rax, 0x18(%rsp)
    2ffd:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    3007:      	movq	%rax, 0x10(%rsp)
    300c:      	movb	$0x0, 0x20(%rsp)
    3011:      	leaq	0x10(%rsp), %rdi
    3016:      	movl	$0x11, %eax
    301b:      	movl	$0x6, %r8d
    3021:      	andl	$0xf, %ebp
    3024:      	movq	0x78(%rsp), %rcx
    3029:      	movl	$0x11, %esi
    302e:      	movl	%ebp, %edx
    3030:      	xorl	%eax, %eax
    3032:      	callq	*%r8
    3035:      	xorl	%r13d, %r13d
    3038:      	cmpl	$0xa, %ebp
    303b:      	jle	0x2986 <perf_unwind_native+0x2986>
    3041:      	movq	0x150(%rsp), %rax
    3049:      	cmpl	$0xb, %ebp
    304c:      	je	0x305b <perf_unwind_native+0x305b>
    304e:      	movq	0x98(%rsp), %rax
    3056:      	cmpl	$0xf, %ebp
    3059:      	jne	0x3063 <perf_unwind_native+0x3063>
    305b:      	movq	0x78(%rsp), %r13
    3060:      	addq	(%rax), %r13
    3063:      	movq	0x70(%rsp), %rcx
    3068:      	movzbl	0x1(%rcx), %eax
    306c:      	movl	0x8(%rcx), %r12d
    3070:      	movl	%r12d, %ecx
    3073:      	andl	$-0x8, %ecx
    3076:      	testb	%al, %al
    3078:      	cmovnsl	%r12d, %ecx
    307c:      	movl	%eax, %edx
    307e:      	andl	$0x7f, %edx
    3081:      	cmpl	$0x2, %edx
    3084:      	jg	0x309b <perf_unwind_native+0x309b>
    3086:      	movq	%r13, %rsi
    3089:      	cmpl	$0x1, %edx
    308c:      	je	0x3106 <perf_unwind_native+0x3106>
    308e:      	movq	%r15, %rsi
    3091:      	cmpl	$0x2, %edx
    3094:      	je	0x3103 <perf_unwind_native+0x3103>
    3096:      	jmp	0x3262 <perf_unwind_native+0x3262>
    309b:      	cmpl	$0x3, %edx
    309e:      	je	0x30fe <perf_unwind_native+0x30fe>
    30a0:      	cmpl	$0x5, %edx
    30a3:      	jne	0x3262 <perf_unwind_native+0x3262>
    30a9:      	movl	%r12d, %eax
    30ac:      	sarl	%eax
    30ae:      	andl	$-0x8, %eax
    30b1:      	cltq
    30b3:      	movq	%rax, 0x78(%rsp)
    30b8:      	movq	(%rip), %rax            # 0x30bf <perf_unwind_native+0x30bf>
    30bf:      	cmpl	$0x0, (%rax)
    30c2:      	jne	0x31cb <perf_unwind_native+0x31cb>
    30c8:      	andl	$0xf, %r12d
    30cc:      	cmpl	$0xa, %r12d
    30d0:      	jg	0x321e <perf_unwind_native+0x321e>
    30d6:      	movq	0x138(%rsp), %rax
    30de:      	testl	%r12d, %r12d
    30e1:      	je	0x323a <perf_unwind_native+0x323a>
    30e7:      	cmpl	$0x9, %r12d
    30eb:      	jne	0x3262 <perf_unwind_native+0x3262>
    30f1:      	movq	0x148(%rsp), %rax
    30f9:      	jmp	0x323a <perf_unwind_native+0x323a>
    30fe:      	movq	0x60(%rsp), %rsi
    3103:      	movq	(%rsi), %rsi
    3106:      	movslq	%ecx, %rbp
    3109:      	addq	%rsi, %rbp
    310c:      	testb	%al, %al
    310e:      	jns	0x3242 <perf_unwind_native+0x3242>
    3114:      	leaq	0x78(%rsp), %rdi
    3119:      	movl	$0x8, %eax
    311e:      	movl	$0x70, %ecx
    3123:      	movl	$0x8, %esi
    3128:      	movq	%rbp, %rdx
    312b:      	callq	*%rcx
    312d:      	testq	%rax, %rax
    3130:      	je	0x31b9 <perf_unwind_native+0x31b9>
    3136:      	movq	(%rip), %rax            # 0x313d <perf_unwind_native+0x313d>
    313d:      	cmpl	$0x0, (%rax)
    3140:      	je	0x3262 <perf_unwind_native+0x3262>
    3146:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    3150:      	movq	%rax, 0x30(%rsp)
    3155:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    315f:      	movq	%rax, 0x28(%rsp)
    3164:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    316e:      	movq	%rax, 0x20(%rsp)
    3173:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    317d:      	movq	%rax, 0x18(%rsp)
    3182:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    318c:      	movq	%rax, 0x10(%rsp)
    3191:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    3199:      	leaq	0x10(%rsp), %rdi
    319e:      	movl	$0x2c, %eax
    31a3:      	movl	$0x6, %ecx
    31a8:      	movl	$0x2c, %esi
    31ad:      	movq	%rbp, %rdx
    31b0:      	xorl	%eax, %eax
    31b2:      	callq	*%rcx
    31b4:      	jmp	0x3262 <perf_unwind_native+0x3262>
    31b9:      	shll	$0x3, %r12d
    31bd:      	andl	$0x38, %r12d
    31c1:      	addq	0x78(%rsp), %r12
    31c6:      	movq	%r12, %rbp
    31c9:      	jmp	0x3242 <perf_unwind_native+0x3242>
    31cb:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    31d5:      	movq	%rax, 0x18(%rsp)
    31da:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    31e4:      	movq	%rax, 0x10(%rsp)
    31e9:      	movb	$0x0, 0x20(%rsp)
    31ee:      	leaq	0x10(%rsp), %rdi
    31f3:      	movl	$0x11, %eax
    31f8:      	movl	$0x6, %r8d
    31fe:      	andl	$0xf, %r12d
    3202:      	movq	0x78(%rsp), %rcx
    3207:      	movl	$0x11, %esi
    320c:      	movl	%r12d, %edx
    320f:      	xorl	%eax, %eax
    3211:      	callq	*%r8
    3214:      	cmpl	$0xa, %r12d
    3218:      	jle	0x30d6 <perf_unwind_native+0x30d6>
    321e:      	movq	0x150(%rsp), %rax
    3226:      	cmpl	$0xb, %r12d
    322a:      	je	0x323a <perf_unwind_native+0x323a>
    322c:      	movq	0x98(%rsp), %rax
    3234:      	cmpl	$0xf, %r12d
    3238:      	jne	0x3262 <perf_unwind_native+0x3262>
    323a:      	movq	0x78(%rsp), %rbp
    323f:      	addq	(%rax), %rbp
    3242:      	testq	%rbp, %rbp
    3245:      	je	0x3262 <perf_unwind_native+0x3262>
    3247:      	movl	$0x8, %eax
    324c:      	movl	$0x70, %ecx
    3251:      	movq	0x60(%rsp), %rdi
    3256:      	movl	$0x8, %esi
    325b:      	movq	%rbp, %rdx
    325e:      	callq	*%rcx
    3260:      	jmp	0x3278 <perf_unwind_native+0x3278>
    3262:      	movq	0x70(%rsp), %rax
    3267:      	cmpb	$0x3, (%rax)
    326a:      	jne	0x3278 <perf_unwind_native+0x3278>
    326c:      	movq	0x60(%rsp), %rax
    3271:      	movq	$0x0, (%rax)
    3278:      	testq	%r13, %r13
    327b:      	movq	0x68(%rsp), %rbp
    3280:      	je	0x163b <perf_unwind_native+0x163b>
    3286:      	leaq	-0x8(%r13), %rdx
    328a:      	movl	$0x8, %eax
    328f:      	movl	$0x70, %ecx
    3294:      	movq	0x140(%rsp), %rdi
    329c:      	movl	$0x8, %esi
    32a1:      	callq	*%rcx
    32a3:      	testq	%rax, %rax
    32a6:      	jne	0x163b <perf_unwind_native+0x163b>
    32ac:      	movq	%r13, 0xed8(%rbx)
    32b3:      	movb	$0x1, 0xf30(%rbx)
    32ba:      	movl	$0x6, 0x78(%rsp)
    32c2:      	movq	(%rip), %rdi            # 0x32c9 <perf_unwind_native+0x32c9>
    32c9:      	leaq	0x78(%rsp), %rsi
    32ce:      	movl	$0x1, %eax
    32d3:      	callq	*%rax
    32d5:      	testq	%rax, %rax
    32d8:      	je	0x3379 <perf_unwind_native+0x3379>
    32de:      	incq	(%rax)
    32e1:      	xorl	%eax, %eax
    32e3:      	movq	(%rip), %rcx            # 0x32ea <perf_unwind_native+0x32ea>
    32ea:      	cmpl	$0x0, (%rcx)
    32ed:      	je	0x338b <perf_unwind_native+0x338b>
    32f3:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    32fd:      	movq	%rax, 0xb5(%rsp)
    3305:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    330f:      	movq	%rax, 0xb0(%rsp)
    3317:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    3321:      	movq	%rax, 0xa8(%rsp)
    3329:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    3333:      	movq	%rax, 0xa0(%rsp)
    333b:      	leaq	0xa0(%rsp), %rdi
    3343:      	movl	$0x1d, %eax
    3348:      	movl	$0x6, %r9d
    334e:      	movq	0x140(%rsp), %rax
    3356:      	movq	(%rax), %rdx
    3359:      	movq	(%r15), %rcx
    335c:      	movq	0x60(%rsp), %rax
    3361:      	movq	(%rax), %r8
    3364:      	movl	$0x1d, %esi
    3369:      	xorl	%eax, %eax
    336b:      	callq	*%r9
    336e:      	movq	(%rip), %rax            # 0x3375 <perf_unwind_native+0x3375>
    3375:      	movl	(%rax), %eax
    3377:      	jmp	0x338b <perf_unwind_native+0x338b>
    3379:      	movq	(%rip), %rax            # 0x3380 <perf_unwind_native+0x3380>
    3380:      	cmpl	$0x0, (%rax)
    3383:      	jne	0x36ee <perf_unwind_native+0x36ee>
    3389:      	xorl	%eax, %eax
    338b:      	movq	0x140(%rsp), %rcx
    3393:      	movq	(%rcx), %r13
    3396:      	testq	%r13, %r13
    3399:      	je	0x70e9 <perf_unwind_native+0x70e9>
    339f:      	testl	%eax, %eax
    33a1:      	jne	0x3444 <perf_unwind_native+0x3444>
    33a7:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    33b1:      	cmpq	%rax, %r13
    33b4:      	jbe	0x34f3 <perf_unwind_native+0x34f3>
    33ba:      	movq	0x68(%rsp), %rbp
    33bf:      	movq	(%rip), %rax            # 0x33c6 <perf_unwind_native+0x33c6>
    33c6:      	cmpl	$0x0, (%rax)
    33c9:      	je	0x1794 <perf_unwind_native+0x1794>
    33cf:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    33d9:      	movq	%rax, 0xb8(%rsp)
    33e1:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    33eb:      	movq	%rax, 0xb0(%rsp)
    33f3:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    33fd:      	movq	%rax, 0xa8(%rsp)
    3405:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    340f:      	movq	%rax, 0xa0(%rsp)
    3417:      	movw	$0xa, 0xc0(%rsp)
    3421:      	leaq	0xa0(%rsp), %rdi
    3429:      	movl	$0x22, %eax
    342e:      	movl	$0x6, %ecx
    3433:      	movl	$0x22, %esi
    3438:      	movq	%r13, %rdx
    343b:      	xorl	%eax, %eax
    343d:      	callq	*%rcx
    343f:      	jmp	0x1794 <perf_unwind_native+0x1794>
    3444:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    344e:      	movq	%rax, 0xc8(%rsp)
    3456:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    3460:      	movq	%rax, 0xc0(%rsp)
    3468:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    3472:      	movq	%rax, 0xb8(%rsp)
    347a:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    3484:      	movq	%rax, 0xb0(%rsp)
    348c:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    3496:      	movq	%rax, 0xa8(%rsp)
    349e:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    34a8:      	movq	%rax, 0xa0(%rsp)
    34b0:      	movb	$0x0, 0xd0(%rsp)
    34b8:      	leaq	0xa0(%rsp), %rdi
    34c0:      	movl	$0x31, %eax
    34c5:      	movl	$0x6, %ecx
    34ca:      	movl	0x2c0(%rbx), %edx
    34d0:      	movl	$0x31, %esi
    34d5:      	xorl	%eax, %eax
    34d7:      	callq	*%rcx
    34d9:      	movq	0xed0(%rbx), %r13
    34e0:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    34ea:      	cmpq	%rax, %r13
    34ed:      	ja	0x33ba <perf_unwind_native+0x33ba>
    34f3:      	cmpq	$0x1000, %r13           # imm = 0x1000
    34fa:      	jae	0x3580 <perf_unwind_native+0x3580>
    3500:      	movq	0x68(%rsp), %rbp
    3505:      	movq	(%rip), %rax            # 0x350c <perf_unwind_native+0x350c>
    350c:      	cmpl	$0x0, (%rax)
    350f:      	je	0x18e6 <perf_unwind_native+0x18e6>
    3515:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    351f:      	movq	%rax, 0xb6(%rsp)
    3527:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    3531:      	movq	%rax, 0xb0(%rsp)
    3539:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    3543:      	movq	%rax, 0xa8(%rsp)
    354b:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    3555:      	movq	%rax, 0xa0(%rsp)
    355d:      	leaq	0xa0(%rsp), %rdi
    3565:      	movl	$0x1e, %eax
    356a:      	movl	$0x6, %ecx
    356f:      	movl	$0x1e, %esi
    3574:      	movq	%r13, %rdx
    3577:      	xorl	%eax, %eax
    3579:      	callq	*%rcx
    357b:      	jmp	0x18e6 <perf_unwind_native+0x18e6>
    3580:      	movl	(%rbx), %eax
    3582:      	movl	$0x60, 0x10(%rsp)
    358a:      	movbel	%eax, 0x14(%rsp)
    3590:      	movbeq	%r13, 0x18(%rsp)
    3597:      	movq	(%rip), %rdi            # 0x359e <perf_unwind_native+0x359e>
    359e:      	leaq	0x10(%rsp), %rsi
    35a3:      	movl	$0x1, %eax
    35a8:      	callq	*%rax
    35aa:      	testq	%rax, %rax
    35ad:      	je	0x71a5 <perf_unwind_native+0x71a5>
    35b3:      	movq	0x8(%rax), %r12
    35b7:      	movq	%r12, %rcx
    35ba:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    35c4:      	andq	%rdx, %rcx
    35c7:      	movq	%rcx, 0xf20(%rbx)
    35ce:      	movq	(%rax), %rax
    35d1:      	movq	%rax, 0xf10(%rbx)
    35d8:      	shrq	$0x38, %r12
    35dc:      	movq	%r13, %rax
    35df:      	subq	%rcx, %rax
    35e2:      	movq	%rax, 0xf18(%rbx)
    35e9:      	movq	(%rip), %rax            # 0x35f0 <perf_unwind_native+0x35f0>
    35f0:      	cmpl	$0x0, (%rax)
    35f3:      	jne	0x37f1 <perf_unwind_native+0x37f1>
    35f9:      	cmpl	$0x1, %r12d
    35fd:      	jne	0x39e8 <perf_unwind_native+0x39e8>
    3603:      	movq	0xf10(%rbx), %rax
    360a:      	movq	%rax, 0x10(%rsp)
    360f:      	movq	0xf18(%rbx), %rbp
    3616:      	movq	(%rip), %rdi            # 0x361d <perf_unwind_native+0x361d>
    361d:      	leaq	0x10(%rsp), %rsi
    3622:      	movl	$0x1, %eax
    3627:      	callq	*%rax
    3629:      	movl	$0x1, %r12d
    362f:      	testq	%rax, %rax
    3632:      	je	0x39e8 <perf_unwind_native+0x39e8>
    3638:      	movq	%rax, %r13
    363b:      	cmpq	%rbp, (%rax)
    363e:      	ja	0x3646 <perf_unwind_native+0x3646>
    3640:      	cmpq	%rbp, 0x8(%r13)
    3644:      	jae	0x365a <perf_unwind_native+0x365a>
    3646:      	cmpq	%rbp, 0x10(%r13)
    364a:      	ja	0x39e8 <perf_unwind_native+0x39e8>
    3650:      	cmpq	%rbp, 0x18(%r13)
    3654:      	jb	0x39e8 <perf_unwind_native+0x39e8>
    365a:      	movq	(%rip), %rax            # 0x3661 <perf_unwind_native+0x3661>
    3661:      	cmpl	$0x0, (%rax)
    3664:      	jne	0x3933 <perf_unwind_native+0x3933>
    366a:      	movl	0x1380(%rbx), %eax
    3670:      	movl	0x20(%r13), %ecx
    3674:      	btl	%ecx, %eax
    3677:      	jae	0x39ae <perf_unwind_native+0x39ae>
    367d:      	movq	(%rip), %rax            # 0x3684 <perf_unwind_native+0x3684>
    3684:      	cmpl	$0x0, (%rax)
    3687:      	je	0x39e8 <perf_unwind_native+0x39e8>
    368d:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    3697:      	movq	%rax, 0xb0(%rsp)
    369f:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    36a9:      	movq	%rax, 0xa8(%rsp)
    36b1:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    36bb:      	movq	%rax, 0xa0(%rsp)
    36c3:      	movl	$0xa656e, 0xb7(%rsp)    # imm = 0xA656E
    36ce:      	leaq	0xa0(%rsp), %rdi
    36d6:      	movl	$0x1b, %eax
    36db:      	movl	$0x6, %ecx
    36e0:      	movl	$0x1b, %esi
    36e5:      	xorl	%eax, %eax
    36e7:      	callq	*%rcx
    36e9:      	jmp	0x39e8 <perf_unwind_native+0x39e8>
    36ee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    36f8:      	movq	%rax, 0x36(%rsp)
    36fd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3707:      	movq	%rax, 0x30(%rsp)
    370c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3716:      	movq	%rax, 0x28(%rsp)
    371b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3725:      	movq	%rax, 0x20(%rsp)
    372a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3734:      	movq	%rax, 0x18(%rsp)
    3739:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3743:      	movq	%rax, 0x10(%rsp)
    3748:      	leaq	0x10(%rsp), %rdi
    374d:      	movl	$0x2e, %eax
    3752:      	movl	$0x6, %ecx
    3757:      	movl	0x78(%rsp), %edx
    375b:      	movl	$0x2e, %esi
    3760:      	xorl	%eax, %eax
    3762:      	callq	*%rcx
    3764:      	xorl	%eax, %eax
    3766:      	movq	(%rip), %rcx            # 0x376d <perf_unwind_native+0x376d>
    376d:      	cmpl	$0x0, (%rcx)
    3770:      	je	0x338b <perf_unwind_native+0x338b>
    3776:      	jmp	0x32f3 <perf_unwind_native+0x32f3>
    377b:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    3785:      	movq	%rax, 0x30(%rsp)
    378a:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    3794:      	movq	%rax, 0x28(%rsp)
    3799:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    37a3:      	movq	%rax, 0x20(%rsp)
    37a8:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    37b2:      	movq	%rax, 0x18(%rsp)
    37b7:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    37c1:      	movq	%rax, 0x10(%rsp)
    37c6:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    37ce:      	leaq	0x10(%rsp), %rdi
    37d3:      	movl	$0x2c, %eax
    37d8:      	movl	$0x6, %ecx
    37dd:      	movl	$0x2c, %esi
    37e2:      	movq	%r13, %rdx
    37e5:      	xorl	%eax, %eax
    37e7:      	callq	*%rcx
    37e9:      	xorl	%r13d, %r13d
    37ec:      	jmp	0x3063 <perf_unwind_native+0x3063>
    37f1:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    37fb:      	movq	%rax, 0xc8(%rsp)
    3803:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    380d:      	movq	%rax, 0xc0(%rsp)
    3815:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    381f:      	movq	%rax, 0xb8(%rsp)
    3827:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    3831:      	movq	%rax, 0xb0(%rsp)
    3839:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    3843:      	movq	%rax, 0xa8(%rsp)
    384b:      	movabsq	$0x6365732074786554, %rbp # imm = 0x6365732074786554
    3855:      	movq	%rbp, 0xa0(%rsp)
    385d:      	movw	$0xa, 0xd0(%rsp)
    3867:      	leaq	0xa0(%rsp), %rdi
    386f:      	movl	$0x32, %eax
    3874:      	movl	$0x6, %r9d
    387a:      	movq	0xf10(%rbx), %rcx
    3881:      	movl	$0x32, %esi
    3886:      	movq	%r13, %rdx
    3889:      	movl	%r12d, %r8d
    388c:      	xorl	%eax, %eax
    388e:      	callq	*%r9
    3891:      	movq	(%rip), %rax            # 0x3898 <perf_unwind_native+0x3898>
    3898:      	cmpl	$0x0, (%rax)
    389b:      	je	0x35f9 <perf_unwind_native+0x35f9>
    38a1:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    38ab:      	movq	%rax, 0xc7(%rsp)
    38b3:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    38bd:      	movq	%rax, 0xc0(%rsp)
    38c5:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    38cf:      	movq	%rax, 0xb8(%rsp)
    38d7:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    38e1:      	movq	%rax, 0xb0(%rsp)
    38e9:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    38f3:      	movq	%rax, 0xa8(%rsp)
    38fb:      	movq	%rbp, 0xa0(%rsp)
    3903:      	leaq	0xa0(%rsp), %rdi
    390b:      	movl	$0x2f, %eax
    3910:      	movl	$0x6, %r8d
    3916:      	movq	0xf18(%rbx), %rcx
    391d:      	movq	0xf20(%rbx), %rdx
    3924:      	movl	$0x2f, %esi
    3929:      	xorl	%eax, %eax
    392b:      	callq	*%r8
    392e:      	jmp	0x35f9 <perf_unwind_native+0x35f9>
    3933:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    393d:      	movq	%rax, 0xb6(%rsp)
    3945:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    394f:      	movq	%rax, 0xb0(%rsp)
    3957:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    3961:      	movq	%rax, 0xa8(%rsp)
    3969:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3973:      	movq	%rax, 0xa0(%rsp)
    397b:      	leaq	0xa0(%rsp), %rdi
    3983:      	movl	$0x1e, %eax
    3988:      	movl	$0x6, %ecx
    398d:      	movzwl	0x20(%r13), %edx
    3992:      	movl	$0x1e, %esi
    3997:      	xorl	%eax, %eax
    3999:      	callq	*%rcx
    399b:      	movl	0x1380(%rbx), %eax
    39a1:      	movl	0x20(%r13), %ecx
    39a5:      	btl	%ecx, %eax
    39a8:      	jb	0x367d <perf_unwind_native+0x367d>
    39ae:      	movl	$0x0, 0x78(%rsp)
    39b6:      	movq	(%rip), %rdi            # 0x39bd <perf_unwind_native+0x39bd>
    39bd:      	leaq	0x78(%rsp), %rsi
    39c2:      	movl	$0x1, %eax
    39c7:      	callq	*%rax
    39c9:      	testq	%rax, %rax
    39cc:      	je	0x39d3 <perf_unwind_native+0x39d3>
    39ce:      	incq	(%rax)
    39d1:      	jmp	0x39e3 <perf_unwind_native+0x39e3>
    39d3:      	movq	(%rip), %rax            # 0x39da <perf_unwind_native+0x39da>
    39da:      	cmpl	$0x0, (%rax)
    39dd:      	jne	0x49ee <perf_unwind_native+0x49ee>
    39e3:      	movzwl	0x20(%r13), %r12d
    39e8:      	cmpl	$0x1, %r12d
    39ec:      	jne	0x762f <perf_unwind_native+0x762f>
    39f2:      	movq	(%rip), %rax            # 0x39f9 <perf_unwind_native+0x39f9>
    39f9:      	cmpl	$0x0, (%rax)
    39fc:      	jne	0x476c <perf_unwind_native+0x476c>
    3a02:      	movl	$0x5, 0x10(%rsp)
    3a0a:      	movq	(%rip), %rdi            # 0x3a11 <perf_unwind_native+0x3a11>
    3a11:      	leaq	0x10(%rsp), %rsi
    3a16:      	movl	$0x1, %eax
    3a1b:      	callq	*%rax
    3a1d:      	testq	%rax, %rax
    3a20:      	je	0x3ad2 <perf_unwind_native+0x3ad2>
    3a26:      	incq	(%rax)
    3a29:      	movq	(%rip), %rax            # 0x3a30 <perf_unwind_native+0x3a30>
    3a30:      	cmpl	$0x0, (%rax)
    3a33:      	je	0x3ae2 <perf_unwind_native+0x3ae2>
    3a39:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
    3a43:      	movq	%rax, 0xc0(%rsp)
    3a4b:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
    3a55:      	movq	%rax, 0xb8(%rsp)
    3a5d:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
    3a67:      	movq	%rax, 0xb0(%rsp)
    3a6f:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
    3a79:      	movq	%rax, 0xa8(%rsp)
    3a81:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3a8b:      	movq	%rax, 0xa0(%rsp)
    3a93:      	movl	$0xa6b63, 0xc7(%rsp)    # imm = 0xA6B63
    3a9e:      	leaq	0xa0(%rsp), %rdi
    3aa6:      	movl	$0x2b, %eax
    3aab:      	movl	$0x6, %r9d
    3ab1:      	movq	0xf10(%rbx), %rdx
    3ab8:      	movq	0xf18(%rbx), %rcx
    3abf:      	movl	0x2c0(%rbx), %r8d
    3ac6:      	movl	$0x2b, %esi
    3acb:      	xorl	%eax, %eax
    3acd:      	callq	*%r9
    3ad0:      	jmp	0x3ae2 <perf_unwind_native+0x3ae2>
    3ad2:      	movq	(%rip), %rax            # 0x3ad9 <perf_unwind_native+0x3ad9>
    3ad9:      	cmpl	$0x0, (%rax)
    3adc:      	jne	0x4841 <perf_unwind_native+0x4841>
    3ae2:      	movl	0x2c0(%rbx), %eax
    3ae8:      	cmpq	$0x7e, %rax
    3aec:      	movq	0x68(%rsp), %rbp
    3af1:      	movq	(%rip), %r13            # 0x3af8 <perf_unwind_native+0x3af8>
    3af8:      	ja	0x141 <perf_unwind_native+0x141>
    3afe:      	movzbl	0xf30(%rbx), %ecx
    3b05:      	movq	0xf10(%rbx), %rdx
    3b0c:      	movq	0xf18(%rbx), %rsi
    3b13:      	leal	0x1(%rax), %edi
    3b16:      	movl	%edi, 0x2c0(%rbx)
    3b1c:      	leaq	(%rax,%rax,2), %rax
    3b20:      	movq	%rdx, 0x2d0(%rbx,%rax,8)
    3b28:      	movq	%rsi, 0x2d8(%rbx,%rax,8)
    3b30:      	movb	$0x3, 0x2e0(%rbx,%rax,8)
    3b38:      	movb	%cl, 0x2e1(%rbx,%rax,8)
    3b3f:      	movl	$0x0, 0x2e2(%rbx,%rax,8)
    3b4a:      	movw	$0x0, 0x2e6(%rbx,%rax,8)
    3b54:      	movl	$0x0, 0x8c(%rsp)
    3b5f:      	movq	0xf10(%rbx), %rax
    3b66:      	movq	%rax, 0x160(%rsp)
    3b6e:      	movq	%rax, 0x78(%rsp)
    3b73:      	movq	$-0x10000, %rax         # imm = 0xFFFF0000
    3b7a:      	andq	0xf18(%rbx), %rax
    3b81:      	movq	%rax, 0x80(%rsp)
    3b89:      	cmpl	$0x0, (%r13)
    3b8e:      	jne	0x47d3 <perf_unwind_native+0x47d3>
    3b94:      	movq	(%rip), %rdi            # 0x3b9b <perf_unwind_native+0x3b9b>
    3b9b:      	leaq	0x78(%rsp), %rsi
    3ba0:      	movl	$0x1, %eax
    3ba5:      	callq	*%rax
    3ba7:      	movq	%rax, 0x70(%rsp)
    3bac:      	testq	%rax, %rax
    3baf:      	movq	0x68(%rsp), %rbp
    3bb4:      	movq	(%rip), %r13            # 0x3bbb <perf_unwind_native+0x3bbb>
    3bbb:      	je	0x56e8 <perf_unwind_native+0x56e8>
    3bc1:      	movq	0x70(%rsp), %rax
    3bc6:      	movq	%rax, %rbp
    3bc9:      	addq	$0x6, %rbp
    3bcd:      	movzwl	0x6(%rax), %eax
    3bd1:      	cmpl	$0xf, %eax
    3bd4:      	jg	0x3c02 <perf_unwind_native+0x3c02>
    3bd6:      	cmpl	$0xb, %eax
    3bd9:      	jg	0x3c2a <perf_unwind_native+0x3c2a>
    3bdb:      	cmpl	$0x9, %eax
    3bde:      	jg	0x3c70 <perf_unwind_native+0x3c70>
    3be4:      	cmpl	$0x8, %eax
    3be7:      	je	0x3ccf <perf_unwind_native+0x3ccf>
    3bed:      	cmpl	$0x9, %eax
    3bf0:      	jne	0x586e <perf_unwind_native+0x586e>
    3bf6:      	movq	(%rip), %rdi            # 0x3bfd <perf_unwind_native+0x3bfd>
    3bfd:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3c02:      	cmpl	$0x13, %eax
    3c05:      	jg	0x3c4d <perf_unwind_native+0x3c4d>
    3c07:      	cmpl	$0x11, %eax
    3c0a:      	jg	0x3c8a <perf_unwind_native+0x3c8a>
    3c0c:      	cmpl	$0x10, %eax
    3c0f:      	je	0x3cd8 <perf_unwind_native+0x3cd8>
    3c15:      	cmpl	$0x11, %eax
    3c18:      	jne	0x586e <perf_unwind_native+0x586e>
    3c1e:      	movq	(%rip), %rdi            # 0x3c25 <perf_unwind_native+0x3c25>
    3c25:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3c2a:      	cmpl	$0xd, %eax
    3c2d:      	jg	0x3ca1 <perf_unwind_native+0x3ca1>
    3c2f:      	cmpl	$0xc, %eax
    3c32:      	je	0x3ce1 <perf_unwind_native+0x3ce1>
    3c38:      	cmpl	$0xd, %eax
    3c3b:      	jne	0x586e <perf_unwind_native+0x586e>
    3c41:      	movq	(%rip), %rdi            # 0x3c48 <perf_unwind_native+0x3c48>
    3c48:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3c4d:      	cmpl	$0x15, %eax
    3c50:      	jg	0x3cb8 <perf_unwind_native+0x3cb8>
    3c52:      	cmpl	$0x14, %eax
    3c55:      	je	0x3cea <perf_unwind_native+0x3cea>
    3c5b:      	cmpl	$0x15, %eax
    3c5e:      	jne	0x586e <perf_unwind_native+0x586e>
    3c64:      	movq	(%rip), %rdi            # 0x3c6b <perf_unwind_native+0x3c6b>
    3c6b:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3c70:      	cmpl	$0xa, %eax
    3c73:      	je	0x3cf3 <perf_unwind_native+0x3cf3>
    3c75:      	cmpl	$0xb, %eax
    3c78:      	jne	0x586e <perf_unwind_native+0x586e>
    3c7e:      	movq	(%rip), %rdi            # 0x3c85 <perf_unwind_native+0x3c85>
    3c85:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3c8a:      	cmpl	$0x12, %eax
    3c8d:      	je	0x3cfc <perf_unwind_native+0x3cfc>
    3c8f:      	cmpl	$0x13, %eax
    3c92:      	jne	0x586e <perf_unwind_native+0x586e>
    3c98:      	movq	(%rip), %rdi            # 0x3c9f <perf_unwind_native+0x3c9f>
    3c9f:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3ca1:      	cmpl	$0xe, %eax
    3ca4:      	je	0x3d05 <perf_unwind_native+0x3d05>
    3ca6:      	cmpl	$0xf, %eax
    3ca9:      	jne	0x586e <perf_unwind_native+0x586e>
    3caf:      	movq	(%rip), %rdi            # 0x3cb6 <perf_unwind_native+0x3cb6>
    3cb6:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3cb8:      	cmpl	$0x16, %eax
    3cbb:      	je	0x3d0e <perf_unwind_native+0x3d0e>
    3cbd:      	cmpl	$0x17, %eax
    3cc0:      	jne	0x586e <perf_unwind_native+0x586e>
    3cc6:      	movq	(%rip), %rdi            # 0x3ccd <perf_unwind_native+0x3ccd>
    3ccd:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3ccf:      	movq	(%rip), %rdi            # 0x3cd6 <perf_unwind_native+0x3cd6>
    3cd6:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3cd8:      	movq	(%rip), %rdi            # 0x3cdf <perf_unwind_native+0x3cdf>
    3cdf:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3ce1:      	movq	(%rip), %rdi            # 0x3ce8 <perf_unwind_native+0x3ce8>
    3ce8:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3cea:      	movq	(%rip), %rdi            # 0x3cf1 <perf_unwind_native+0x3cf1>
    3cf1:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3cf3:      	movq	(%rip), %rdi            # 0x3cfa <perf_unwind_native+0x3cfa>
    3cfa:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3cfc:      	movq	(%rip), %rdi            # 0x3d03 <perf_unwind_native+0x3d03>
    3d03:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3d05:      	movq	(%rip), %rdi            # 0x3d0c <perf_unwind_native+0x3d0c>
    3d0c:      	jmp	0x3d15 <perf_unwind_native+0x3d15>
    3d0e:      	movq	(%rip), %rdi            # 0x3d15 <perf_unwind_native+0x3d15>
    3d15:      	leaq	0x160(%rsp), %rsi
    3d1d:      	movl	$0x1, %eax
    3d22:      	callq	*%rax
    3d24:      	movq	%rax, 0x58(%rsp)
    3d29:      	testq	%rax, %rax
    3d2c:      	je	0x5f9f <perf_unwind_native+0x5f9f>
    3d32:      	movq	0x70(%rsp), %rcx
    3d37:      	movl	(%rcx), %r13d
    3d3a:      	movl	%r13d, 0x90(%rsp)
    3d42:      	movq	0xf18(%rbx), %rax
    3d49:      	movq	%rax, 0x8(%rsp)
    3d4e:      	movzwl	0x4(%rcx), %eax
    3d52:      	testl	%eax, %eax
    3d54:      	je	0x427b <perf_unwind_native+0x427b>
    3d5a:      	movq	%rax, %r12
    3d5d:      	addl	%r13d, %r12d
    3d60:      	movq	(%rip), %rax            # 0x3d67 <perf_unwind_native+0x3d67>
    3d67:      	cmpl	$0x0, (%rax)
    3d6a:      	jne	0x48e1 <perf_unwind_native+0x48e1>
    3d70:      	leal	(%r12,%r13), %eax
    3d74:      	shrl	%eax
    3d76:      	movl	%eax, 0x10(%rsp)
    3d7a:      	leaq	0x10(%rsp), %rsi
    3d7f:      	movl	$0x1, %eax
    3d84:      	movq	0x58(%rsp), %rdi
    3d89:      	callq	*%rax
    3d8b:      	testq	%rax, %rax
    3d8e:      	je	0x4352 <perf_unwind_native+0x4352>
    3d94:      	movl	0x10(%rsp), %ecx
    3d98:      	leal	0x1(%rcx), %ebp
    3d9b:      	movq	0x8(%rsp), %rdx
    3da0:      	cmpw	%dx, (%rax)
    3da3:      	cmoval	%r13d, %ebp
    3da7:      	cmoval	%ecx, %r12d
    3dab:      	movq	%r12, %rax
    3dae:      	movq	%r12, (%rsp)
    3db2:      	cmpl	%r12d, %ebp
    3db5:      	jae	0x426c <perf_unwind_native+0x426c>
    3dbb:      	movq	(%rsp), %rax
    3dbf:      	addl	%ebp, %eax
    3dc1:      	shrl	%eax
    3dc3:      	movl	%eax, 0x10(%rsp)
    3dc7:      	leaq	0x10(%rsp), %rsi
    3dcc:      	movl	$0x1, %eax
    3dd1:      	movq	0x58(%rsp), %rdi
    3dd6:      	callq	*%rax
    3dd8:      	testq	%rax, %rax
    3ddb:      	je	0x4352 <perf_unwind_native+0x4352>
    3de1:      	movl	0x10(%rsp), %ecx
    3de5:      	leal	0x1(%rcx), %r13d
    3de9:      	movq	0x8(%rsp), %rdx
    3dee:      	cmpw	%dx, (%rax)
    3df1:      	cmoval	%ebp, %r13d
    3df5:      	movq	(%rsp), %rdx
    3df9:      	cmoval	%ecx, %edx
    3dfc:      	movq	%rdx, %rax
    3dff:      	movq	%rdx, (%rsp)
    3e03:      	cmpl	%edx, %r13d
    3e06:      	jae	0x426c <perf_unwind_native+0x426c>
    3e0c:      	movq	(%rsp), %rax
    3e10:      	addl	%r13d, %eax
    3e13:      	shrl	%eax
    3e15:      	movl	%eax, 0x10(%rsp)
    3e19:      	leaq	0x10(%rsp), %rsi
    3e1e:      	movl	$0x1, %eax
    3e23:      	movq	0x58(%rsp), %rdi
    3e28:      	callq	*%rax
    3e2a:      	testq	%rax, %rax
    3e2d:      	je	0x4352 <perf_unwind_native+0x4352>
    3e33:      	movl	0x10(%rsp), %ecx
    3e37:      	leal	0x1(%rcx), %ebp
    3e3a:      	movq	0x8(%rsp), %rdx
    3e3f:      	cmpw	%dx, (%rax)
    3e42:      	cmoval	%r13d, %ebp
    3e46:      	movq	(%rsp), %rdx
    3e4a:      	cmoval	%ecx, %edx
    3e4d:      	movq	%rdx, %rax
    3e50:      	movq	%rdx, (%rsp)
    3e54:      	cmpl	%edx, %ebp
    3e56:      	jae	0x426c <perf_unwind_native+0x426c>
    3e5c:      	movq	(%rsp), %rax
    3e60:      	addl	%ebp, %eax
    3e62:      	shrl	%eax
    3e64:      	movl	%eax, 0x10(%rsp)
    3e68:      	leaq	0x10(%rsp), %rsi
    3e6d:      	movl	$0x1, %eax
    3e72:      	movq	0x58(%rsp), %rdi
    3e77:      	callq	*%rax
    3e79:      	testq	%rax, %rax
    3e7c:      	je	0x4352 <perf_unwind_native+0x4352>
    3e82:      	movl	0x10(%rsp), %ecx
    3e86:      	leal	0x1(%rcx), %r13d
    3e8a:      	movq	0x8(%rsp), %rdx
    3e8f:      	cmpw	%dx, (%rax)
    3e92:      	cmoval	%ebp, %r13d
    3e96:      	movq	(%rsp), %rdx
    3e9a:      	cmoval	%ecx, %edx
    3e9d:      	movq	%rdx, %rax
    3ea0:      	movq	%rdx, (%rsp)
    3ea4:      	cmpl	%edx, %r13d
    3ea7:      	jae	0x426c <perf_unwind_native+0x426c>
    3ead:      	movq	(%rsp), %rax
    3eb1:      	addl	%r13d, %eax
    3eb4:      	shrl	%eax
    3eb6:      	movl	%eax, 0x10(%rsp)
    3eba:      	leaq	0x10(%rsp), %rsi
    3ebf:      	movl	$0x1, %eax
    3ec4:      	movq	0x58(%rsp), %rdi
    3ec9:      	callq	*%rax
    3ecb:      	testq	%rax, %rax
    3ece:      	je	0x4352 <perf_unwind_native+0x4352>
    3ed4:      	movl	0x10(%rsp), %ecx
    3ed8:      	leal	0x1(%rcx), %ebp
    3edb:      	movq	0x8(%rsp), %rdx
    3ee0:      	cmpw	%dx, (%rax)
    3ee3:      	cmoval	%r13d, %ebp
    3ee7:      	movq	(%rsp), %rdx
    3eeb:      	cmoval	%ecx, %edx
    3eee:      	movq	%rdx, %rax
    3ef1:      	movq	%rdx, (%rsp)
    3ef5:      	cmpl	%edx, %ebp
    3ef7:      	jae	0x426c <perf_unwind_native+0x426c>
    3efd:      	movq	(%rsp), %rax
    3f01:      	addl	%ebp, %eax
    3f03:      	shrl	%eax
    3f05:      	movl	%eax, 0x10(%rsp)
    3f09:      	leaq	0x10(%rsp), %rsi
    3f0e:      	movl	$0x1, %eax
    3f13:      	movq	0x58(%rsp), %rdi
    3f18:      	callq	*%rax
    3f1a:      	testq	%rax, %rax
    3f1d:      	je	0x4352 <perf_unwind_native+0x4352>
    3f23:      	movl	0x10(%rsp), %ecx
    3f27:      	leal	0x1(%rcx), %r13d
    3f2b:      	movq	0x8(%rsp), %rdx
    3f30:      	cmpw	%dx, (%rax)
    3f33:      	cmoval	%ebp, %r13d
    3f37:      	movq	(%rsp), %rdx
    3f3b:      	cmoval	%ecx, %edx
    3f3e:      	movq	%rdx, %rax
    3f41:      	movq	%rdx, (%rsp)
    3f45:      	cmpl	%edx, %r13d
    3f48:      	jae	0x426c <perf_unwind_native+0x426c>
    3f4e:      	movq	(%rsp), %rax
    3f52:      	addl	%r13d, %eax
    3f55:      	shrl	%eax
    3f57:      	movl	%eax, 0x10(%rsp)
    3f5b:      	leaq	0x10(%rsp), %rsi
    3f60:      	movl	$0x1, %eax
    3f65:      	movq	0x58(%rsp), %rdi
    3f6a:      	callq	*%rax
    3f6c:      	testq	%rax, %rax
    3f6f:      	je	0x4352 <perf_unwind_native+0x4352>
    3f75:      	movl	0x10(%rsp), %ecx
    3f79:      	leal	0x1(%rcx), %ebp
    3f7c:      	movq	0x8(%rsp), %rdx
    3f81:      	cmpw	%dx, (%rax)
    3f84:      	cmoval	%r13d, %ebp
    3f88:      	movq	(%rsp), %rdx
    3f8c:      	cmoval	%ecx, %edx
    3f8f:      	movq	%rdx, %rax
    3f92:      	movq	%rdx, (%rsp)
    3f96:      	cmpl	%edx, %ebp
    3f98:      	jae	0x426c <perf_unwind_native+0x426c>
    3f9e:      	movq	(%rsp), %rax
    3fa2:      	addl	%ebp, %eax
    3fa4:      	shrl	%eax
    3fa6:      	movl	%eax, 0x10(%rsp)
    3faa:      	leaq	0x10(%rsp), %rsi
    3faf:      	movl	$0x1, %eax
    3fb4:      	movq	0x58(%rsp), %rdi
    3fb9:      	callq	*%rax
    3fbb:      	testq	%rax, %rax
    3fbe:      	je	0x4352 <perf_unwind_native+0x4352>
    3fc4:      	movl	0x10(%rsp), %ecx
    3fc8:      	leal	0x1(%rcx), %r13d
    3fcc:      	movq	0x8(%rsp), %rdx
    3fd1:      	cmpw	%dx, (%rax)
    3fd4:      	cmoval	%ebp, %r13d
    3fd8:      	movq	(%rsp), %rdx
    3fdc:      	cmoval	%ecx, %edx
    3fdf:      	movq	%rdx, %rax
    3fe2:      	movq	%rdx, (%rsp)
    3fe6:      	cmpl	%edx, %r13d
    3fe9:      	jae	0x426c <perf_unwind_native+0x426c>
    3fef:      	movq	(%rsp), %rax
    3ff3:      	addl	%r13d, %eax
    3ff6:      	shrl	%eax
    3ff8:      	movl	%eax, 0x10(%rsp)
    3ffc:      	leaq	0x10(%rsp), %rsi
    4001:      	movl	$0x1, %eax
    4006:      	movq	0x58(%rsp), %rdi
    400b:      	callq	*%rax
    400d:      	testq	%rax, %rax
    4010:      	je	0x4352 <perf_unwind_native+0x4352>
    4016:      	movl	0x10(%rsp), %ecx
    401a:      	leal	0x1(%rcx), %ebp
    401d:      	movq	0x8(%rsp), %rdx
    4022:      	cmpw	%dx, (%rax)
    4025:      	cmoval	%r13d, %ebp
    4029:      	movq	(%rsp), %rdx
    402d:      	cmoval	%ecx, %edx
    4030:      	movq	%rdx, %rax
    4033:      	movq	%rdx, (%rsp)
    4037:      	cmpl	%edx, %ebp
    4039:      	jae	0x426c <perf_unwind_native+0x426c>
    403f:      	movq	(%rsp), %rax
    4043:      	addl	%ebp, %eax
    4045:      	shrl	%eax
    4047:      	movl	%eax, 0x10(%rsp)
    404b:      	leaq	0x10(%rsp), %rsi
    4050:      	movl	$0x1, %eax
    4055:      	movq	0x58(%rsp), %rdi
    405a:      	callq	*%rax
    405c:      	testq	%rax, %rax
    405f:      	je	0x4352 <perf_unwind_native+0x4352>
    4065:      	movl	0x10(%rsp), %ecx
    4069:      	leal	0x1(%rcx), %r13d
    406d:      	movq	0x8(%rsp), %rdx
    4072:      	cmpw	%dx, (%rax)
    4075:      	cmoval	%ebp, %r13d
    4079:      	movq	(%rsp), %rdx
    407d:      	cmoval	%ecx, %edx
    4080:      	movq	%rdx, %rax
    4083:      	movq	%rdx, (%rsp)
    4087:      	cmpl	%edx, %r13d
    408a:      	jae	0x426c <perf_unwind_native+0x426c>
    4090:      	movq	(%rsp), %rax
    4094:      	addl	%r13d, %eax
    4097:      	shrl	%eax
    4099:      	movl	%eax, 0x10(%rsp)
    409d:      	leaq	0x10(%rsp), %rsi
    40a2:      	movl	$0x1, %eax
    40a7:      	movq	0x58(%rsp), %rdi
    40ac:      	callq	*%rax
    40ae:      	testq	%rax, %rax
    40b1:      	je	0x4352 <perf_unwind_native+0x4352>
    40b7:      	movl	0x10(%rsp), %ecx
    40bb:      	leal	0x1(%rcx), %ebp
    40be:      	movq	0x8(%rsp), %rdx
    40c3:      	cmpw	%dx, (%rax)
    40c6:      	cmoval	%r13d, %ebp
    40ca:      	movq	(%rsp), %rdx
    40ce:      	cmoval	%ecx, %edx
    40d1:      	movq	%rdx, %rax
    40d4:      	movq	%rdx, (%rsp)
    40d8:      	cmpl	%edx, %ebp
    40da:      	jae	0x426c <perf_unwind_native+0x426c>
    40e0:      	movq	(%rsp), %rax
    40e4:      	addl	%ebp, %eax
    40e6:      	shrl	%eax
    40e8:      	movl	%eax, 0x10(%rsp)
    40ec:      	leaq	0x10(%rsp), %rsi
    40f1:      	movl	$0x1, %eax
    40f6:      	movq	0x58(%rsp), %rdi
    40fb:      	callq	*%rax
    40fd:      	testq	%rax, %rax
    4100:      	je	0x4352 <perf_unwind_native+0x4352>
    4106:      	movl	0x10(%rsp), %ecx
    410a:      	leal	0x1(%rcx), %r13d
    410e:      	movq	0x8(%rsp), %rdx
    4113:      	cmpw	%dx, (%rax)
    4116:      	cmoval	%ebp, %r13d
    411a:      	movq	(%rsp), %rdx
    411e:      	cmoval	%ecx, %edx
    4121:      	movq	%rdx, %rax
    4124:      	movq	%rdx, (%rsp)
    4128:      	cmpl	%edx, %r13d
    412b:      	jae	0x426c <perf_unwind_native+0x426c>
    4131:      	movq	(%rsp), %rax
    4135:      	addl	%r13d, %eax
    4138:      	shrl	%eax
    413a:      	movl	%eax, 0x10(%rsp)
    413e:      	leaq	0x10(%rsp), %rsi
    4143:      	movl	$0x1, %eax
    4148:      	movq	0x58(%rsp), %rdi
    414d:      	callq	*%rax
    414f:      	testq	%rax, %rax
    4152:      	je	0x4352 <perf_unwind_native+0x4352>
    4158:      	movl	0x10(%rsp), %ecx
    415c:      	leal	0x1(%rcx), %ebp
    415f:      	movq	0x8(%rsp), %rdx
    4164:      	cmpw	%dx, (%rax)
    4167:      	cmoval	%r13d, %ebp
    416b:      	movq	(%rsp), %rdx
    416f:      	cmoval	%ecx, %edx
    4172:      	movq	%rdx, %rax
    4175:      	movq	%rdx, (%rsp)
    4179:      	cmpl	%edx, %ebp
    417b:      	jae	0x426c <perf_unwind_native+0x426c>
    4181:      	movq	(%rsp), %rax
    4185:      	addl	%ebp, %eax
    4187:      	shrl	%eax
    4189:      	movl	%eax, 0x10(%rsp)
    418d:      	leaq	0x10(%rsp), %rsi
    4192:      	movl	$0x1, %eax
    4197:      	movq	0x58(%rsp), %rdi
    419c:      	callq	*%rax
    419e:      	testq	%rax, %rax
    41a1:      	je	0x4352 <perf_unwind_native+0x4352>
    41a7:      	movl	0x10(%rsp), %ecx
    41ab:      	leal	0x1(%rcx), %r13d
    41af:      	movq	0x8(%rsp), %rdx
    41b4:      	cmpw	%dx, (%rax)
    41b7:      	cmoval	%ebp, %r13d
    41bb:      	movq	(%rsp), %rdx
    41bf:      	cmoval	%ecx, %edx
    41c2:      	movq	%rdx, %rax
    41c5:      	movq	%rdx, (%rsp)
    41c9:      	cmpl	%edx, %r13d
    41cc:      	jae	0x426c <perf_unwind_native+0x426c>
    41d2:      	movq	(%rsp), %rax
    41d6:      	addl	%r13d, %eax
    41d9:      	shrl	%eax
    41db:      	movl	%eax, 0x10(%rsp)
    41df:      	leaq	0x10(%rsp), %rsi
    41e4:      	movl	$0x1, %eax
    41e9:      	movq	0x58(%rsp), %rdi
    41ee:      	callq	*%rax
    41f0:      	testq	%rax, %rax
    41f3:      	je	0x4352 <perf_unwind_native+0x4352>
    41f9:      	movl	0x10(%rsp), %ecx
    41fd:      	leal	0x1(%rcx), %ebp
    4200:      	movq	0x8(%rsp), %rdx
    4205:      	cmpw	%dx, (%rax)
    4208:      	cmoval	%r13d, %ebp
    420c:      	movq	(%rsp), %rdx
    4210:      	cmoval	%ecx, %edx
    4213:      	movq	%rdx, %rax
    4216:      	movq	%rdx, (%rsp)
    421a:      	cmpl	%edx, %ebp
    421c:      	jae	0x426c <perf_unwind_native+0x426c>
    421e:      	movq	(%rsp), %rax
    4222:      	addl	%ebp, %eax
    4224:      	shrl	%eax
    4226:      	movl	%eax, 0x10(%rsp)
    422a:      	leaq	0x10(%rsp), %rsi
    422f:      	movl	$0x1, %eax
    4234:      	movq	0x58(%rsp), %rdi
    4239:      	callq	*%rax
    423b:      	testq	%rax, %rax
    423e:      	je	0x4352 <perf_unwind_native+0x4352>
    4244:      	movl	0x10(%rsp), %ecx
    4248:      	leal	0x1(%rcx), %edx
    424b:      	movq	0x8(%rsp), %rsi
    4250:      	cmpw	%si, (%rax)
    4253:      	cmoval	%ebp, %edx
    4256:      	movq	(%rsp), %rsi
    425a:      	cmoval	%ecx, %esi
    425d:      	movq	%rsi, %rax
    4260:      	movq	%rsi, (%rsp)
    4264:      	cmpl	%esi, %edx
    4266:      	jb	0x4352 <perf_unwind_native+0x4352>
    426c:      	movq	(%rsp), %rax
    4270:      	movl	%eax, %r13d
    4273:      	testl	%eax, %eax
    4275:      	je	0x4352 <perf_unwind_native+0x4352>
    427b:      	decl	%r13d
    427e:      	movl	%r13d, 0x90(%rsp)
    4286:      	leaq	0x90(%rsp), %rsi
    428e:      	movl	$0x1, %eax
    4293:      	movq	0x58(%rsp), %rdi
    4298:      	callq	*%rax
    429a:      	testq	%rax, %rax
    429d:      	je	0x4346 <perf_unwind_native+0x4346>
    42a3:      	movq	%rax, %rbp
    42a6:      	movq	(%rip), %rax            # 0x42ad <perf_unwind_native+0x42ad>
    42ad:      	cmpl	$0x0, (%rax)
    42b0:      	jne	0x4965 <perf_unwind_native+0x4965>
    42b6:      	movzwl	0x8(%rsp), %eax
    42bb:      	movzwl	(%rbp), %ecx
    42bf:      	subl	%ecx, %eax
    42c1:      	movl	0x90(%rsp), %ecx
    42c8:      	movq	0x70(%rsp), %rdx
    42cd:      	cmpl	(%rdx), %ecx
    42cf:      	leal	0x10000(%rax), %r13d
    42d6:      	cmovael	%eax, %r13d
    42da:      	movzwl	0x2(%rbp), %eax
    42de:      	movl	%eax, 0x8c(%rsp)
    42e5:      	cmpl	$0x8000, %eax           # imm = 0x8000
    42ea:      	je	0x4329 <perf_unwind_native+0x4329>
    42ec:      	cmpl	$0x8001, %eax           # imm = 0x8001
    42f1:      	jne	0x43e0 <perf_unwind_native+0x43e0>
    42f7:      	movl	$0x7, 0x94(%rsp)
    4302:      	movq	(%rip), %rdi            # 0x4309 <perf_unwind_native+0x4309>
    4309:      	leaq	0x94(%rsp), %rsi
    4311:      	movl	$0x1, %eax
    4316:      	callq	*%rax
    4318:      	testq	%rax, %rax
    431b:      	je	0x43c9 <perf_unwind_native+0x43c9>
    4321:      	incq	(%rax)
    4324:      	jmp	0x43d9 <perf_unwind_native+0x43d9>
    4329:      	movl	$0xd, %edx
    432e:      	movl	$0xfa5, %ecx            # imm = 0xFA5
    4333:      	movl	%edx, 0xf28(%rbx)
    4339:      	movl	%ecx, %r13d
    433c:      	movq	0x68(%rsp), %rbp
    4341:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    4346:      	movl	$0xfa4, %ecx            # imm = 0xFA4
    434b:      	movl	$0xa, %edx
    4350:      	jmp	0x4333 <perf_unwind_native+0x4333>
    4352:      	movq	(%rip), %rax            # 0x4359 <perf_unwind_native+0x4359>
    4359:      	cmpl	$0x0, (%rax)
    435c:      	je	0x2745 <perf_unwind_native+0x2745>
    4362:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
    436c:      	movq	%rax, 0x30(%rsp)
    4371:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
    437b:      	movq	%rax, 0x28(%rsp)
    4380:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
    438a:      	movq	%rax, 0x20(%rsp)
    438f:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
    4399:      	movq	%rax, 0x18(%rsp)
    439e:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
    43a8:      	movq	%rax, 0x10(%rsp)
    43ad:      	movl	$0xa3f61, 0x37(%rsp)    # imm = 0xA3F61
    43b5:      	leaq	0x10(%rsp), %rdi
    43ba:      	movl	$0x2b, %eax
    43bf:      	movl	$0x6, %ecx
    43c4:      	jmp	0x2d70 <perf_unwind_native+0x2d70>
    43c9:      	movq	(%rip), %rax            # 0x43d0 <perf_unwind_native+0x43d0>
    43d0:      	cmpl	$0x0, (%rax)
    43d3:      	jne	0x4af2 <perf_unwind_native+0x4af2>
    43d9:      	movl	0x8c(%rsp), %eax
    43e0:      	testw	%ax, %ax
    43e3:      	js	0x4496 <perf_unwind_native+0x4496>
    43e9:      	movq	(%rip), %rdi            # 0x43f0 <perf_unwind_native+0x43f0>
    43f0:      	leaq	0x8c(%rsp), %rsi
    43f8:      	movl	$0x1, %eax
    43fd:      	callq	*%rax
    43ff:      	movq	%rax, 0x70(%rsp)
    4404:      	testq	%rax, %rax
    4407:      	je	0x6393 <perf_unwind_native+0x6393>
    440d:      	movq	0x70(%rsp), %rax
    4412:      	movl	0x4(%rax), %ebp
    4415:      	movzbl	0x2(%rax), %eax
    4419:      	testb	%al, %al
    441b:      	je	0x4459 <perf_unwind_native+0x4459>
    441d:      	movq	(%rip), %rcx            # 0x4424 <perf_unwind_native+0x4424>
    4424:      	cmpl	$0x0, (%rcx)
    4427:      	jne	0x4a7e <perf_unwind_native+0x4a7e>
    442d:      	movl	%eax, %ecx
    442f:      	andb	$0x7f, %cl
    4432:      	movzbl	%cl, %ecx
    4435:      	cmpl	%ecx, %r13d
    4438:      	jl	0x4459 <perf_unwind_native+0x4459>
    443a:      	xorl	%ecx, %ecx
    443c:      	testb	%al, %al
    443e:      	setns	%cl
    4441:      	shll	$0x4, %ecx
    4444:      	addl	%ecx, %ebp
    4446:      	addl	$-0x8, %ebp
    4449:      	movq	(%rip), %rax            # 0x4450 <perf_unwind_native+0x4450>
    4450:      	cmpl	$0x0, (%rax)
    4453:      	jne	0x4b70 <perf_unwind_native+0x4b70>
    4459:      	movq	0x70(%rsp), %rax
    445e:      	movzbl	(%rax), %eax
    4461:      	movl	%ebp, %ecx
    4463:      	andl	$-0x8, %ecx
    4466:      	testb	%al, %al
    4468:      	cmovnsl	%ebp, %ecx
    446b:      	movl	%eax, %edx
    446d:      	andl	$0x7f, %edx
    4470:      	xorl	%r13d, %r13d
    4473:      	cmpl	$0x2, %edx
    4476:      	jg	0x45a4 <perf_unwind_native+0x45a4>
    447c:      	cmpl	$0x1, %edx
    447f:      	je	0x4712 <perf_unwind_native+0x4712>
    4485:      	movq	%r15, %rsi
    4488:      	cmpl	$0x2, %edx
    448b:      	je	0x470f <perf_unwind_native+0x470f>
    4491:      	jmp	0x4c4a <perf_unwind_native+0x4c4a>
    4496:      	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    449b:      	movl	$0x1, %r13d
    44a1:      	cmpl	$0x2, %eax
    44a4:      	jg	0x4532 <perf_unwind_native+0x4532>
    44aa:      	cmpl	$0x1, %eax
    44ad:      	movq	0x68(%rsp), %rbp
    44b2:      	movq	0x140(%rsp), %rcx
    44ba:      	je	0x64f2 <perf_unwind_native+0x64f2>
    44c0:      	cmpl	$0x2, %eax
    44c3:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    44c9:      	movq	%r15, %rdx
    44cc:      	movq	(%r15), %rax
    44cf:      	movl	(%rcx), %ecx
    44d1:      	andl	$0xf, %ecx
    44d4:      	xorl	%edx, %edx
    44d6:      	cmpl	$0xb, %ecx
    44d9:      	setae	%dl
    44dc:      	leaq	(%rax,%rdx,8), %r13
    44e0:      	addq	$0x8, %r13
    44e4:      	movq	(%rip), %rax            # 0x44eb <perf_unwind_native+0x44eb>
    44eb:      	cmpl	$0x0, (%rax)
    44ee:      	je	0x4e5f <perf_unwind_native+0x4e5f>
    44f4:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    44fe:      	movq	%rax, 0x18(%rsp)
    4503:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
    450d:      	movq	%rax, 0x10(%rsp)
    4512:      	leaq	0x10(%rsp), %rdi
    4517:      	movl	$0x10, %eax
    451c:      	movl	$0x6, %ecx
    4521:      	movl	$0x10, %esi
    4526:      	movq	%r13, %rdx
    4529:      	xorl	%eax, %eax
    452b:      	callq	*%rcx
    452d:      	jmp	0x4e5f <perf_unwind_native+0x4e5f>
    4532:      	cmpl	$0x3, %eax
    4535:      	je	0x4609 <perf_unwind_native+0x4609>
    453b:      	cmpl	$0x4, %eax
    453e:      	movq	0x68(%rsp), %rbp
    4543:      	movq	0x60(%rsp), %rdx
    4548:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    454e:      	movq	(%rdx), %rax
    4551:      	leaq	0x10(%rsp), %rdi
    4556:      	movl	$0x10, %ecx
    455b:      	movl	$0x70, %r8d
    4561:      	movq	(%rdx), %rdx
    4564:      	movl	$0x10, %esi
    4569:      	callq	*%r8
    456c:      	testq	%rax, %rax
    456f:      	jne	0x163b <perf_unwind_native+0x163b>
    4575:      	movq	0xee0(%rbx), %rax
    457c:      	addq	$0x10, %rax
    4580:      	movq	%rax, 0xed8(%rbx)
    4587:      	movq	0x10(%rsp), %rax
    458c:      	movq	%rax, 0xee0(%rbx)
    4593:      	movq	0x18(%rsp), %rax
    4598:      	movq	%rax, 0xed0(%rbx)
    459f:      	jmp	0x4e9a <perf_unwind_native+0x4e9a>
    45a4:      	cmpl	$0x3, %edx
    45a7:      	je	0x470a <perf_unwind_native+0x470a>
    45ad:      	cmpl	$0x5, %edx
    45b0:      	jne	0x4c4a <perf_unwind_native+0x4c4a>
    45b6:      	movl	%ebp, %eax
    45b8:      	sarl	%eax
    45ba:      	andl	$-0x8, %eax
    45bd:      	cltq
    45bf:      	movq	%rax, 0x78(%rsp)
    45c4:      	movq	(%rip), %rax            # 0x45cb <perf_unwind_native+0x45cb>
    45cb:      	cmpl	$0x0, (%rax)
    45ce:      	jne	0x4bd5 <perf_unwind_native+0x4bd5>
    45d4:      	andl	$0xf, %ebp
    45d7:      	xorl	%r13d, %r13d
    45da:      	cmpl	$0xa, %ebp
    45dd:      	jg	0x4c28 <perf_unwind_native+0x4c28>
    45e3:      	movq	0x138(%rsp), %rax
    45eb:      	testl	%ebp, %ebp
    45ed:      	je	0x4c42 <perf_unwind_native+0x4c42>
    45f3:      	cmpl	$0x9, %ebp
    45f6:      	jne	0x4c4a <perf_unwind_native+0x4c4a>
    45fc:      	movq	0x148(%rsp), %rax
    4604:      	jmp	0x4c42 <perf_unwind_native+0x4c42>
    4609:      	movq	(%r15), %rax
    460c:      	addq	$0x28, %rax
    4610:      	leaq	0xa0(%rsp), %rdi
    4618:      	movl	$0x90, %ecx
    461d:      	movl	$0x70, %r8d
    4623:      	movq	(%r15), %rdx
    4626:      	addq	$0x28, %rdx
    462a:      	movl	$0x90, %esi
    462f:      	callq	*%r8
    4632:      	testq	%rax, %rax
    4635:      	movq	0x68(%rsp), %rbp
    463a:      	jne	0x163b <perf_unwind_native+0x163b>
    4640:      	movq	0x108(%rsp), %rax
    4648:      	movq	%rax, 0xee8(%rbx)
    464f:      	movq	0xa8(%rsp), %rax
    4657:      	movq	%rax, 0xef0(%rbx)
    465e:      	movq	0xb8(%rsp), %rax
    4666:      	movq	%rax, 0xef8(%rbx)
    466d:      	movq	0xc8(%rsp), %rax
    4675:      	movq	%rax, 0xf00(%rbx)
    467c:      	movq	0xd8(%rsp), %rax
    4684:      	movq	%rax, 0xf08(%rbx)
    468b:      	movq	0xf0(%rsp), %rax
    4693:      	movq	%rax, 0xee0(%rbx)
    469a:      	movq	0x118(%rsp), %rax
    46a2:      	movq	%rax, 0xed8(%rbx)
    46a9:      	movq	0x120(%rsp), %rax
    46b1:      	movq	%rax, 0xed0(%rbx)
    46b8:      	movb	$0x0, 0xf30(%rbx)
    46bf:      	movq	(%rip), %rax            # 0x46c6 <perf_unwind_native+0x46c6>
    46c6:      	cmpl	$0x0, (%rax)
    46c9:      	je	0x4ea1 <perf_unwind_native+0x4ea1>
    46cf:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    46d9:      	movq	%rax, 0x16(%rsp)
    46de:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
    46e8:      	movq	%rax, 0x10(%rsp)
    46ed:      	leaq	0x10(%rsp), %rdi
    46f2:      	movl	$0xe, %eax
    46f7:      	movl	$0x6, %ecx
    46fc:      	movl	$0xe, %esi
    4701:      	xorl	%eax, %eax
    4703:      	callq	*%rcx
    4705:      	jmp	0x4ea1 <perf_unwind_native+0x4ea1>
    470a:      	movq	0x60(%rsp), %rsi
    470f:      	movq	(%rsi), %r13
    4712:      	movq	%r13, %rdx
    4715:      	movslq	%ecx, %r13
    4718:      	addq	%rdx, %r13
    471b:      	testb	%al, %al
    471d:      	jns	0x4c4a <perf_unwind_native+0x4c4a>
    4723:      	leaq	0x78(%rsp), %rdi
    4728:      	movl	$0x8, %eax
    472d:      	movl	$0x70, %ecx
    4732:      	movl	$0x8, %esi
    4737:      	movq	%r13, %rdx
    473a:      	callq	*%rcx
    473c:      	testq	%rax, %rax
    473f:      	je	0x4759 <perf_unwind_native+0x4759>
    4741:      	movq	(%rip), %rax            # 0x4748 <perf_unwind_native+0x4748>
    4748:      	cmpl	$0x0, (%rax)
    474b:      	jne	0x525d <perf_unwind_native+0x525d>
    4751:      	xorl	%r13d, %r13d
    4754:      	jmp	0x4c4a <perf_unwind_native+0x4c4a>
    4759:      	shll	$0x3, %ebp
    475c:      	andl	$0x38, %ebp
    475f:      	addq	0x78(%rsp), %rbp
    4764:      	movq	%rbp, %r13
    4767:      	jmp	0x4c4a <perf_unwind_native+0x4c4a>
    476c:      	movl	0x2c0(%rbx), %edx
    4772:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
    477c:      	movq	%rax, 0xb0(%rsp)
    4784:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
    478e:      	movq	%rax, 0xa8(%rsp)
    4796:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
    47a0:      	movq	%rax, 0xa0(%rsp)
    47a8:      	movl	$0xa3d3d, 0xb8(%rsp)    # imm = 0xA3D3D
    47b3:      	leaq	0xa0(%rsp), %rdi
    47bb:      	movl	$0x1c, %eax
    47c0:      	movl	$0x6, %ecx
    47c5:      	movl	$0x1c, %esi
    47ca:      	xorl	%eax, %eax
    47cc:      	callq	*%rcx
    47ce:      	jmp	0x3a02 <perf_unwind_native+0x3a02>
    47d3:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
    47dd:      	movq	%rax, 0x28(%rsp)
    47e2:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
    47ec:      	movq	%rax, 0x20(%rsp)
    47f1:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
    47fb:      	movq	%rax, 0x18(%rsp)
    4800:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
    480a:      	movq	%rax, 0x10(%rsp)
    480f:      	movb	$0x0, 0x30(%rsp)
    4814:      	leaq	0x10(%rsp), %rdi
    4819:      	movl	$0x21, %eax
    481e:      	movl	$0x6, %r8d
    4824:      	movq	0xf10(%rbx), %rdx
    482b:      	movq	0xf18(%rbx), %rcx
    4832:      	movl	$0x21, %esi
    4837:      	xorl	%eax, %eax
    4839:      	callq	*%r8
    483c:      	jmp	0x3b94 <perf_unwind_native+0x3b94>
    4841:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    484b:      	movq	%rax, 0xc6(%rsp)
    4853:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    485d:      	movq	%rax, 0xc0(%rsp)
    4865:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    486f:      	movq	%rax, 0xb8(%rsp)
    4877:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4881:      	movq	%rax, 0xb0(%rsp)
    4889:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4893:      	movq	%rax, 0xa8(%rsp)
    489b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    48a5:      	movq	%rax, 0xa0(%rsp)
    48ad:      	leaq	0xa0(%rsp), %rdi
    48b5:      	movl	$0x2e, %eax
    48ba:      	movl	$0x6, %ecx
    48bf:      	movl	0x10(%rsp), %edx
    48c3:      	movl	$0x2e, %esi
    48c8:      	xorl	%eax, %eax
    48ca:      	callq	*%rcx
    48cc:      	movq	(%rip), %rax            # 0x48d3 <perf_unwind_native+0x48d3>
    48d3:      	cmpl	$0x0, (%rax)
    48d6:      	je	0x3ae2 <perf_unwind_native+0x3ae2>
    48dc:      	jmp	0x3a39 <perf_unwind_native+0x3a39>
    48e1:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
    48eb:      	movq	%rax, 0x38(%rsp)
    48f0:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
    48fa:      	movq	%rax, 0x30(%rsp)
    48ff:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
    4909:      	movq	%rax, 0x28(%rsp)
    490e:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
    4918:      	movq	%rax, 0x20(%rsp)
    491d:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
    4927:      	movq	%rax, 0x18(%rsp)
    492c:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
    4936:      	movq	%rax, 0x10(%rsp)
    493b:      	leaq	0x10(%rsp), %rdi
    4940:      	movl	$0x30, %eax
    4945:      	movl	$0x6, %r9d
    494b:      	movl	%r12d, %ecx
    494e:      	movzwl	(%rbp), %r8d
    4953:      	movl	$0x30, %esi
    4958:      	movq	%r13, %rdx
    495b:      	xorl	%eax, %eax
    495d:      	callq	*%r9
    4960:      	jmp	0x3d70 <perf_unwind_native+0x3d70>
    4965:      	movabsq	$0xa6425206f666e, %rax  # imm = 0xA6425206F666E
    496f:      	movq	%rax, 0x35(%rsp)
    4974:      	movabsq	$0x6f666e49646e6977, %rax # imm = 0x6F666E49646E6977
    497e:      	movq	%rax, 0x30(%rsp)
    4983:      	movabsq	$0x6e75202c78257830, %rax # imm = 0x6E75202C78257830
    498d:      	movq	%rax, 0x28(%rsp)
    4992:      	movabsq	$0x20776f4c72646461, %rax # imm = 0x20776F4C72646461
    499c:      	movq	%rax, 0x20(%rsp)
    49a1:      	movabsq	$0x202c642520786564, %rax # imm = 0x202C642520786564
    49ab:      	movq	%rax, 0x18(%rsp)
    49b0:      	movabsq	$0x6e692061746c6564, %rax # imm = 0x6E692061746C6564
    49ba:      	movq	%rax, 0x10(%rsp)
    49bf:      	leaq	0x10(%rsp), %rdi
    49c4:      	movl	$0x2d, %eax
    49c9:      	movl	$0x6, %r9d
    49cf:      	movl	0x90(%rsp), %edx
    49d6:      	movzwl	(%rbp), %ecx
    49da:      	movzwl	0x2(%rbp), %r8d
    49df:      	movl	$0x2d, %esi
    49e4:      	xorl	%eax, %eax
    49e6:      	callq	*%r9
    49e9:      	jmp	0x42b6 <perf_unwind_native+0x42b6>
    49ee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    49f8:      	movq	%rax, 0xc6(%rsp)
    4a00:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4a0a:      	movq	%rax, 0xc0(%rsp)
    4a12:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4a1c:      	movq	%rax, 0xb8(%rsp)
    4a24:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4a2e:      	movq	%rax, 0xb0(%rsp)
    4a36:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4a40:      	movq	%rax, 0xa8(%rsp)
    4a48:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a52:      	movq	%rax, 0xa0(%rsp)
    4a5a:      	leaq	0xa0(%rsp), %rdi
    4a62:      	movl	$0x2e, %eax
    4a67:      	movl	$0x6, %ecx
    4a6c:      	movl	0x78(%rsp), %edx
    4a70:      	movl	$0x2e, %esi
    4a75:      	xorl	%eax, %eax
    4a77:      	callq	*%rcx
    4a79:      	jmp	0x39e3 <perf_unwind_native+0x39e3>
    4a7e:      	movabsq	$0xa78323023252061, %rax # imm = 0xA78323023252061
    4a88:      	movq	%rax, 0x28(%rsp)
    4a8d:      	movabsq	$0x746c656420646567, %rax # imm = 0x746C656420646567
    4a97:      	movq	%rax, 0x20(%rsp)
    4a9c:      	movabsq	$0x72656d202c642520, %rax # imm = 0x72656D202C642520
    4aa6:      	movq	%rax, 0x18(%rsp)
    4aab:      	movabsq	$0x6666694472646441, %rax # imm = 0x6666694472646441
    4ab5:      	movq	%rax, 0x10(%rsp)
    4aba:      	movb	$0x0, 0x30(%rsp)
    4abf:      	leaq	0x10(%rsp), %rdi
    4ac4:      	movl	$0x21, %eax
    4ac9:      	movl	$0x6, %r8d
    4acf:      	movq	0x70(%rsp), %r12
    4ad4:      	movzbl	0x2(%r12), %ecx
    4ada:      	movl	$0x21, %esi
    4adf:      	movl	%r13d, %edx
    4ae2:      	xorl	%eax, %eax
    4ae4:      	callq	*%r8
    4ae7:      	movzbl	0x2(%r12), %eax
    4aed:      	jmp	0x442d <perf_unwind_native+0x442d>
    4af2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4afc:      	movq	%rax, 0x36(%rsp)
    4b01:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4b0b:      	movq	%rax, 0x30(%rsp)
    4b10:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4b1a:      	movq	%rax, 0x28(%rsp)
    4b1f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4b29:      	movq	%rax, 0x20(%rsp)
    4b2e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4b38:      	movq	%rax, 0x18(%rsp)
    4b3d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4b47:      	movq	%rax, 0x10(%rsp)
    4b4c:      	leaq	0x10(%rsp), %rdi
    4b51:      	movl	$0x2e, %eax
    4b56:      	movl	$0x6, %ecx
    4b5b:      	movl	0x94(%rsp), %edx
    4b62:      	movl	$0x2e, %esi
    4b67:      	xorl	%eax, %eax
    4b69:      	callq	*%rcx
    4b6b:      	jmp	0x43d9 <perf_unwind_native+0x43d9>
    4b70:      	movabsq	$0xa64253d61746c65, %rax # imm = 0xA64253D61746C65
    4b7a:      	movq	%rax, 0x28(%rsp)
    4b7f:      	movabsq	$0x44616663203a6863, %rax # imm = 0x44616663203A6863
    4b89:      	movq	%rax, 0x20(%rsp)
    4b8e:      	movabsq	$0x74616d2061746c65, %rax # imm = 0x74616D2061746C65
    4b98:      	movq	%rax, 0x18(%rsp)
    4b9d:      	movabsq	$0x642064656772654d, %rax # imm = 0x642064656772654D
    4ba7:      	movq	%rax, 0x10(%rsp)
    4bac:      	movb	$0x0, 0x30(%rsp)
    4bb1:      	leaq	0x10(%rsp), %rdi
    4bb6:      	movl	$0x21, %eax
    4bbb:      	movl	$0x6, %ecx
    4bc0:      	movl	0x8c(%rsp), %edx
    4bc7:      	movl	$0x21, %esi
    4bcc:      	xorl	%eax, %eax
    4bce:      	callq	*%rcx
    4bd0:      	jmp	0x4459 <perf_unwind_native+0x4459>
    4bd5:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    4bdf:      	movq	%rax, 0x18(%rsp)
    4be4:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    4bee:      	movq	%rax, 0x10(%rsp)
    4bf3:      	movb	$0x0, 0x20(%rsp)
    4bf8:      	leaq	0x10(%rsp), %rdi
    4bfd:      	movl	$0x11, %eax
    4c02:      	movl	$0x6, %r8d
    4c08:      	andl	$0xf, %ebp
    4c0b:      	movq	0x78(%rsp), %rcx
    4c10:      	movl	$0x11, %esi
    4c15:      	movl	%ebp, %edx
    4c17:      	xorl	%eax, %eax
    4c19:      	callq	*%r8
    4c1c:      	xorl	%r13d, %r13d
    4c1f:      	cmpl	$0xa, %ebp
    4c22:      	jle	0x45e3 <perf_unwind_native+0x45e3>
    4c28:      	movq	0x150(%rsp), %rax
    4c30:      	cmpl	$0xb, %ebp
    4c33:      	je	0x4c42 <perf_unwind_native+0x4c42>
    4c35:      	movq	0x98(%rsp), %rax
    4c3d:      	cmpl	$0xf, %ebp
    4c40:      	jne	0x4c4a <perf_unwind_native+0x4c4a>
    4c42:      	movq	0x78(%rsp), %r13
    4c47:      	addq	(%rax), %r13
    4c4a:      	movq	0x70(%rsp), %rcx
    4c4f:      	movzbl	0x1(%rcx), %eax
    4c53:      	movl	0x8(%rcx), %r12d
    4c57:      	movl	%r12d, %ecx
    4c5a:      	andl	$-0x8, %ecx
    4c5d:      	testb	%al, %al
    4c5f:      	cmovnsl	%r12d, %ecx
    4c63:      	movl	%eax, %edx
    4c65:      	andl	$0x7f, %edx
    4c68:      	cmpl	$0x2, %edx
    4c6b:      	jg	0x4c82 <perf_unwind_native+0x4c82>
    4c6d:      	movq	%r13, %rsi
    4c70:      	cmpl	$0x1, %edx
    4c73:      	je	0x4ced <perf_unwind_native+0x4ced>
    4c75:      	movq	%r15, %rsi
    4c78:      	cmpl	$0x2, %edx
    4c7b:      	je	0x4cea <perf_unwind_native+0x4cea>
    4c7d:      	jmp	0x4e49 <perf_unwind_native+0x4e49>
    4c82:      	cmpl	$0x3, %edx
    4c85:      	je	0x4ce5 <perf_unwind_native+0x4ce5>
    4c87:      	cmpl	$0x5, %edx
    4c8a:      	jne	0x4e49 <perf_unwind_native+0x4e49>
    4c90:      	movl	%r12d, %eax
    4c93:      	sarl	%eax
    4c95:      	andl	$-0x8, %eax
    4c98:      	cltq
    4c9a:      	movq	%rax, 0x78(%rsp)
    4c9f:      	movq	(%rip), %rax            # 0x4ca6 <perf_unwind_native+0x4ca6>
    4ca6:      	cmpl	$0x0, (%rax)
    4ca9:      	jne	0x4db2 <perf_unwind_native+0x4db2>
    4caf:      	andl	$0xf, %r12d
    4cb3:      	cmpl	$0xa, %r12d
    4cb7:      	jg	0x4e05 <perf_unwind_native+0x4e05>
    4cbd:      	movq	0x138(%rsp), %rax
    4cc5:      	testl	%r12d, %r12d
    4cc8:      	je	0x4e21 <perf_unwind_native+0x4e21>
    4cce:      	cmpl	$0x9, %r12d
    4cd2:      	jne	0x4e49 <perf_unwind_native+0x4e49>
    4cd8:      	movq	0x148(%rsp), %rax
    4ce0:      	jmp	0x4e21 <perf_unwind_native+0x4e21>
    4ce5:      	movq	0x60(%rsp), %rsi
    4cea:      	movq	(%rsi), %rsi
    4ced:      	movslq	%ecx, %rbp
    4cf0:      	addq	%rsi, %rbp
    4cf3:      	testb	%al, %al
    4cf5:      	jns	0x4e29 <perf_unwind_native+0x4e29>
    4cfb:      	leaq	0x78(%rsp), %rdi
    4d00:      	movl	$0x8, %eax
    4d05:      	movl	$0x70, %ecx
    4d0a:      	movl	$0x8, %esi
    4d0f:      	movq	%rbp, %rdx
    4d12:      	callq	*%rcx
    4d14:      	testq	%rax, %rax
    4d17:      	je	0x4da0 <perf_unwind_native+0x4da0>
    4d1d:      	movq	(%rip), %rax            # 0x4d24 <perf_unwind_native+0x4d24>
    4d24:      	cmpl	$0x0, (%rax)
    4d27:      	je	0x4e49 <perf_unwind_native+0x4e49>
    4d2d:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    4d37:      	movq	%rax, 0x30(%rsp)
    4d3c:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    4d46:      	movq	%rax, 0x28(%rsp)
    4d4b:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    4d55:      	movq	%rax, 0x20(%rsp)
    4d5a:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    4d64:      	movq	%rax, 0x18(%rsp)
    4d69:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    4d73:      	movq	%rax, 0x10(%rsp)
    4d78:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    4d80:      	leaq	0x10(%rsp), %rdi
    4d85:      	movl	$0x2c, %eax
    4d8a:      	movl	$0x6, %ecx
    4d8f:      	movl	$0x2c, %esi
    4d94:      	movq	%rbp, %rdx
    4d97:      	xorl	%eax, %eax
    4d99:      	callq	*%rcx
    4d9b:      	jmp	0x4e49 <perf_unwind_native+0x4e49>
    4da0:      	shll	$0x3, %r12d
    4da4:      	andl	$0x38, %r12d
    4da8:      	addq	0x78(%rsp), %r12
    4dad:      	movq	%r12, %rbp
    4db0:      	jmp	0x4e29 <perf_unwind_native+0x4e29>
    4db2:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    4dbc:      	movq	%rax, 0x18(%rsp)
    4dc1:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    4dcb:      	movq	%rax, 0x10(%rsp)
    4dd0:      	movb	$0x0, 0x20(%rsp)
    4dd5:      	leaq	0x10(%rsp), %rdi
    4dda:      	movl	$0x11, %eax
    4ddf:      	movl	$0x6, %r8d
    4de5:      	andl	$0xf, %r12d
    4de9:      	movq	0x78(%rsp), %rcx
    4dee:      	movl	$0x11, %esi
    4df3:      	movl	%r12d, %edx
    4df6:      	xorl	%eax, %eax
    4df8:      	callq	*%r8
    4dfb:      	cmpl	$0xa, %r12d
    4dff:      	jle	0x4cbd <perf_unwind_native+0x4cbd>
    4e05:      	movq	0x150(%rsp), %rax
    4e0d:      	cmpl	$0xb, %r12d
    4e11:      	je	0x4e21 <perf_unwind_native+0x4e21>
    4e13:      	movq	0x98(%rsp), %rax
    4e1b:      	cmpl	$0xf, %r12d
    4e1f:      	jne	0x4e49 <perf_unwind_native+0x4e49>
    4e21:      	movq	0x78(%rsp), %rbp
    4e26:      	addq	(%rax), %rbp
    4e29:      	testq	%rbp, %rbp
    4e2c:      	je	0x4e49 <perf_unwind_native+0x4e49>
    4e2e:      	movl	$0x8, %eax
    4e33:      	movl	$0x70, %ecx
    4e38:      	movq	0x60(%rsp), %rdi
    4e3d:      	movl	$0x8, %esi
    4e42:      	movq	%rbp, %rdx
    4e45:      	callq	*%rcx
    4e47:      	jmp	0x4e5f <perf_unwind_native+0x4e5f>
    4e49:      	movq	0x70(%rsp), %rax
    4e4e:      	cmpb	$0x3, (%rax)
    4e51:      	jne	0x4e5f <perf_unwind_native+0x4e5f>
    4e53:      	movq	0x60(%rsp), %rax
    4e58:      	movq	$0x0, (%rax)
    4e5f:      	testq	%r13, %r13
    4e62:      	movq	0x68(%rsp), %rbp
    4e67:      	je	0x163b <perf_unwind_native+0x163b>
    4e6d:      	leaq	-0x8(%r13), %rdx
    4e71:      	movl	$0x8, %eax
    4e76:      	movl	$0x70, %ecx
    4e7b:      	movq	0x140(%rsp), %rdi
    4e83:      	movl	$0x8, %esi
    4e88:      	callq	*%rcx
    4e8a:      	testq	%rax, %rax
    4e8d:      	jne	0x163b <perf_unwind_native+0x163b>
    4e93:      	movq	%r13, 0xed8(%rbx)
    4e9a:      	movb	$0x1, 0xf30(%rbx)
    4ea1:      	movl	$0x6, 0x78(%rsp)
    4ea9:      	movq	(%rip), %rdi            # 0x4eb0 <perf_unwind_native+0x4eb0>
    4eb0:      	leaq	0x78(%rsp), %rsi
    4eb5:      	movl	$0x1, %eax
    4eba:      	callq	*%rax
    4ebc:      	testq	%rax, %rax
    4ebf:      	je	0x4f60 <perf_unwind_native+0x4f60>
    4ec5:      	incq	(%rax)
    4ec8:      	xorl	%eax, %eax
    4eca:      	movq	(%rip), %rcx            # 0x4ed1 <perf_unwind_native+0x4ed1>
    4ed1:      	cmpl	$0x0, (%rcx)
    4ed4:      	je	0x4f72 <perf_unwind_native+0x4f72>
    4eda:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    4ee4:      	movq	%rax, 0xb5(%rsp)
    4eec:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    4ef6:      	movq	%rax, 0xb0(%rsp)
    4efe:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    4f08:      	movq	%rax, 0xa8(%rsp)
    4f10:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    4f1a:      	movq	%rax, 0xa0(%rsp)
    4f22:      	leaq	0xa0(%rsp), %rdi
    4f2a:      	movl	$0x1d, %eax
    4f2f:      	movl	$0x6, %r9d
    4f35:      	movq	0x140(%rsp), %rax
    4f3d:      	movq	(%rax), %rdx
    4f40:      	movq	(%r15), %rcx
    4f43:      	movq	0x60(%rsp), %rax
    4f48:      	movq	(%rax), %r8
    4f4b:      	movl	$0x1d, %esi
    4f50:      	xorl	%eax, %eax
    4f52:      	callq	*%r9
    4f55:      	movq	(%rip), %rax            # 0x4f5c <perf_unwind_native+0x4f5c>
    4f5c:      	movl	(%rax), %eax
    4f5e:      	jmp	0x4f72 <perf_unwind_native+0x4f72>
    4f60:      	movq	(%rip), %rax            # 0x4f67 <perf_unwind_native+0x4f67>
    4f67:      	cmpl	$0x0, (%rax)
    4f6a:      	jne	0x51d0 <perf_unwind_native+0x51d0>
    4f70:      	xorl	%eax, %eax
    4f72:      	movq	0x140(%rsp), %rcx
    4f7a:      	movq	(%rcx), %r13
    4f7d:      	testq	%r13, %r13
    4f80:      	je	0x70e9 <perf_unwind_native+0x70e9>
    4f86:      	testl	%eax, %eax
    4f88:      	jne	0x511c <perf_unwind_native+0x511c>
    4f8e:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    4f98:      	cmpq	%rax, %r13
    4f9b:      	ja	0x33ba <perf_unwind_native+0x33ba>
    4fa1:      	cmpq	$0x1000, %r13           # imm = 0x1000
    4fa8:      	jb	0x3500 <perf_unwind_native+0x3500>
    4fae:      	movl	(%rbx), %eax
    4fb0:      	movl	$0x60, 0x10(%rsp)
    4fb8:      	movbel	%eax, 0x14(%rsp)
    4fbe:      	movbeq	%r13, 0x18(%rsp)
    4fc5:      	movq	(%rip), %rdi            # 0x4fcc <perf_unwind_native+0x4fcc>
    4fcc:      	leaq	0x10(%rsp), %rsi
    4fd1:      	movl	$0x1, %eax
    4fd6:      	callq	*%rax
    4fd8:      	testq	%rax, %rax
    4fdb:      	je	0x71a5 <perf_unwind_native+0x71a5>
    4fe1:      	movq	0x8(%rax), %r12
    4fe5:      	movq	%r12, %rcx
    4fe8:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    4ff2:      	andq	%rdx, %rcx
    4ff5:      	movq	%rcx, 0xf20(%rbx)
    4ffc:      	movq	(%rax), %rax
    4fff:      	movq	%rax, 0xf10(%rbx)
    5006:      	shrq	$0x38, %r12
    500a:      	movq	%r13, %rax
    500d:      	subq	%rcx, %rax
    5010:      	movq	%rax, 0xf18(%rbx)
    5017:      	movq	(%rip), %rax            # 0x501e <perf_unwind_native+0x501e>
    501e:      	cmpl	$0x0, (%rax)
    5021:      	jne	0x52d3 <perf_unwind_native+0x52d3>
    5027:      	cmpl	$0x1, %r12d
    502b:      	jne	0x54ca <perf_unwind_native+0x54ca>
    5031:      	movq	0xf10(%rbx), %rax
    5038:      	movq	%rax, 0x10(%rsp)
    503d:      	movq	0xf18(%rbx), %rbp
    5044:      	movq	(%rip), %rdi            # 0x504b <perf_unwind_native+0x504b>
    504b:      	leaq	0x10(%rsp), %rsi
    5050:      	movl	$0x1, %eax
    5055:      	callq	*%rax
    5057:      	movl	$0x1, %r12d
    505d:      	testq	%rax, %rax
    5060:      	je	0x54ca <perf_unwind_native+0x54ca>
    5066:      	movq	%rax, %r13
    5069:      	cmpq	%rbp, (%rax)
    506c:      	ja	0x5074 <perf_unwind_native+0x5074>
    506e:      	cmpq	%rbp, 0x8(%r13)
    5072:      	jae	0x5088 <perf_unwind_native+0x5088>
    5074:      	cmpq	%rbp, 0x10(%r13)
    5078:      	ja	0x54ca <perf_unwind_native+0x54ca>
    507e:      	cmpq	%rbp, 0x18(%r13)
    5082:      	jb	0x54ca <perf_unwind_native+0x54ca>
    5088:      	movq	(%rip), %rax            # 0x508f <perf_unwind_native+0x508f>
    508f:      	cmpl	$0x0, (%rax)
    5092:      	jne	0x5415 <perf_unwind_native+0x5415>
    5098:      	movl	0x1380(%rbx), %eax
    509e:      	movl	0x20(%r13), %ecx
    50a2:      	btl	%ecx, %eax
    50a5:      	jae	0x5490 <perf_unwind_native+0x5490>
    50ab:      	movq	(%rip), %rax            # 0x50b2 <perf_unwind_native+0x50b2>
    50b2:      	cmpl	$0x0, (%rax)
    50b5:      	je	0x54ca <perf_unwind_native+0x54ca>
    50bb:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    50c5:      	movq	%rax, 0xb0(%rsp)
    50cd:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    50d7:      	movq	%rax, 0xa8(%rsp)
    50df:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    50e9:      	movq	%rax, 0xa0(%rsp)
    50f1:      	movl	$0xa656e, 0xb7(%rsp)    # imm = 0xA656E
    50fc:      	leaq	0xa0(%rsp), %rdi
    5104:      	movl	$0x1b, %eax
    5109:      	movl	$0x6, %ecx
    510e:      	movl	$0x1b, %esi
    5113:      	xorl	%eax, %eax
    5115:      	callq	*%rcx
    5117:      	jmp	0x54ca <perf_unwind_native+0x54ca>
    511c:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    5126:      	movq	%rax, 0xc8(%rsp)
    512e:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    5138:      	movq	%rax, 0xc0(%rsp)
    5140:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    514a:      	movq	%rax, 0xb8(%rsp)
    5152:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    515c:      	movq	%rax, 0xb0(%rsp)
    5164:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    516e:      	movq	%rax, 0xa8(%rsp)
    5176:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    5180:      	movq	%rax, 0xa0(%rsp)
    5188:      	movb	$0x0, 0xd0(%rsp)
    5190:      	leaq	0xa0(%rsp), %rdi
    5198:      	movl	$0x31, %eax
    519d:      	movl	$0x6, %ecx
    51a2:      	movl	0x2c0(%rbx), %edx
    51a8:      	movl	$0x31, %esi
    51ad:      	xorl	%eax, %eax
    51af:      	callq	*%rcx
    51b1:      	movq	0xed0(%rbx), %r13
    51b8:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    51c2:      	cmpq	%rax, %r13
    51c5:      	ja	0x33ba <perf_unwind_native+0x33ba>
    51cb:      	jmp	0x4fa1 <perf_unwind_native+0x4fa1>
    51d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    51da:      	movq	%rax, 0x36(%rsp)
    51df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    51e9:      	movq	%rax, 0x30(%rsp)
    51ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    51f8:      	movq	%rax, 0x28(%rsp)
    51fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5207:      	movq	%rax, 0x20(%rsp)
    520c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5216:      	movq	%rax, 0x18(%rsp)
    521b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5225:      	movq	%rax, 0x10(%rsp)
    522a:      	leaq	0x10(%rsp), %rdi
    522f:      	movl	$0x2e, %eax
    5234:      	movl	$0x6, %ecx
    5239:      	movl	0x78(%rsp), %edx
    523d:      	movl	$0x2e, %esi
    5242:      	xorl	%eax, %eax
    5244:      	callq	*%rcx
    5246:      	xorl	%eax, %eax
    5248:      	movq	(%rip), %rcx            # 0x524f <perf_unwind_native+0x524f>
    524f:      	cmpl	$0x0, (%rcx)
    5252:      	je	0x4f72 <perf_unwind_native+0x4f72>
    5258:      	jmp	0x4eda <perf_unwind_native+0x4eda>
    525d:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    5267:      	movq	%rax, 0x30(%rsp)
    526c:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    5276:      	movq	%rax, 0x28(%rsp)
    527b:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    5285:      	movq	%rax, 0x20(%rsp)
    528a:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    5294:      	movq	%rax, 0x18(%rsp)
    5299:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    52a3:      	movq	%rax, 0x10(%rsp)
    52a8:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    52b0:      	leaq	0x10(%rsp), %rdi
    52b5:      	movl	$0x2c, %eax
    52ba:      	movl	$0x6, %ecx
    52bf:      	movl	$0x2c, %esi
    52c4:      	movq	%r13, %rdx
    52c7:      	xorl	%eax, %eax
    52c9:      	callq	*%rcx
    52cb:      	xorl	%r13d, %r13d
    52ce:      	jmp	0x4c4a <perf_unwind_native+0x4c4a>
    52d3:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    52dd:      	movq	%rax, 0xc8(%rsp)
    52e5:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    52ef:      	movq	%rax, 0xc0(%rsp)
    52f7:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    5301:      	movq	%rax, 0xb8(%rsp)
    5309:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    5313:      	movq	%rax, 0xb0(%rsp)
    531b:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    5325:      	movq	%rax, 0xa8(%rsp)
    532d:      	movabsq	$0x6365732074786554, %rbp # imm = 0x6365732074786554
    5337:      	movq	%rbp, 0xa0(%rsp)
    533f:      	movw	$0xa, 0xd0(%rsp)
    5349:      	leaq	0xa0(%rsp), %rdi
    5351:      	movl	$0x32, %eax
    5356:      	movl	$0x6, %r9d
    535c:      	movq	0xf10(%rbx), %rcx
    5363:      	movl	$0x32, %esi
    5368:      	movq	%r13, %rdx
    536b:      	movl	%r12d, %r8d
    536e:      	xorl	%eax, %eax
    5370:      	callq	*%r9
    5373:      	movq	(%rip), %rax            # 0x537a <perf_unwind_native+0x537a>
    537a:      	cmpl	$0x0, (%rax)
    537d:      	je	0x5027 <perf_unwind_native+0x5027>
    5383:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    538d:      	movq	%rax, 0xc7(%rsp)
    5395:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    539f:      	movq	%rax, 0xc0(%rsp)
    53a7:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    53b1:      	movq	%rax, 0xb8(%rsp)
    53b9:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    53c3:      	movq	%rax, 0xb0(%rsp)
    53cb:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    53d5:      	movq	%rax, 0xa8(%rsp)
    53dd:      	movq	%rbp, 0xa0(%rsp)
    53e5:      	leaq	0xa0(%rsp), %rdi
    53ed:      	movl	$0x2f, %eax
    53f2:      	movl	$0x6, %r8d
    53f8:      	movq	0xf18(%rbx), %rcx
    53ff:      	movq	0xf20(%rbx), %rdx
    5406:      	movl	$0x2f, %esi
    540b:      	xorl	%eax, %eax
    540d:      	callq	*%r8
    5410:      	jmp	0x5027 <perf_unwind_native+0x5027>
    5415:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    541f:      	movq	%rax, 0xb6(%rsp)
    5427:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    5431:      	movq	%rax, 0xb0(%rsp)
    5439:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    5443:      	movq	%rax, 0xa8(%rsp)
    544b:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5455:      	movq	%rax, 0xa0(%rsp)
    545d:      	leaq	0xa0(%rsp), %rdi
    5465:      	movl	$0x1e, %eax
    546a:      	movl	$0x6, %ecx
    546f:      	movzwl	0x20(%r13), %edx
    5474:      	movl	$0x1e, %esi
    5479:      	xorl	%eax, %eax
    547b:      	callq	*%rcx
    547d:      	movl	0x1380(%rbx), %eax
    5483:      	movl	0x20(%r13), %ecx
    5487:      	btl	%ecx, %eax
    548a:      	jb	0x50ab <perf_unwind_native+0x50ab>
    5490:      	movl	$0x0, 0x78(%rsp)
    5498:      	movq	(%rip), %rdi            # 0x549f <perf_unwind_native+0x549f>
    549f:      	leaq	0x78(%rsp), %rsi
    54a4:      	movl	$0x1, %eax
    54a9:      	callq	*%rax
    54ab:      	testq	%rax, %rax
    54ae:      	je	0x54b5 <perf_unwind_native+0x54b5>
    54b0:      	incq	(%rax)
    54b3:      	jmp	0x54c5 <perf_unwind_native+0x54c5>
    54b5:      	movq	(%rip), %rax            # 0x54bc <perf_unwind_native+0x54bc>
    54bc:      	cmpl	$0x0, (%rax)
    54bf:      	jne	0x69b6 <perf_unwind_native+0x69b6>
    54c5:      	movzwl	0x20(%r13), %r12d
    54ca:      	cmpl	$0x1, %r12d
    54ce:      	jne	0x762f <perf_unwind_native+0x762f>
    54d4:      	movq	(%rip), %rax            # 0x54db <perf_unwind_native+0x54db>
    54db:      	cmpl	$0x0, (%rax)
    54de:      	jne	0x6734 <perf_unwind_native+0x6734>
    54e4:      	movl	$0x5, 0x10(%rsp)
    54ec:      	movq	(%rip), %rdi            # 0x54f3 <perf_unwind_native+0x54f3>
    54f3:      	leaq	0x10(%rsp), %rsi
    54f8:      	movl	$0x1, %eax
    54fd:      	callq	*%rax
    54ff:      	testq	%rax, %rax
    5502:      	je	0x55b4 <perf_unwind_native+0x55b4>
    5508:      	incq	(%rax)
    550b:      	movq	(%rip), %rax            # 0x5512 <perf_unwind_native+0x5512>
    5512:      	cmpl	$0x0, (%rax)
    5515:      	je	0x55c4 <perf_unwind_native+0x55c4>
    551b:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
    5525:      	movq	%rax, 0xc0(%rsp)
    552d:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
    5537:      	movq	%rax, 0xb8(%rsp)
    553f:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
    5549:      	movq	%rax, 0xb0(%rsp)
    5551:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
    555b:      	movq	%rax, 0xa8(%rsp)
    5563:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    556d:      	movq	%rax, 0xa0(%rsp)
    5575:      	movl	$0xa6b63, 0xc7(%rsp)    # imm = 0xA6B63
    5580:      	leaq	0xa0(%rsp), %rdi
    5588:      	movl	$0x2b, %eax
    558d:      	movl	$0x6, %r9d
    5593:      	movq	0xf10(%rbx), %rdx
    559a:      	movq	0xf18(%rbx), %rcx
    55a1:      	movl	0x2c0(%rbx), %r8d
    55a8:      	movl	$0x2b, %esi
    55ad:      	xorl	%eax, %eax
    55af:      	callq	*%r9
    55b2:      	jmp	0x55c4 <perf_unwind_native+0x55c4>
    55b4:      	movq	(%rip), %rax            # 0x55bb <perf_unwind_native+0x55bb>
    55bb:      	cmpl	$0x0, (%rax)
    55be:      	jne	0x6809 <perf_unwind_native+0x6809>
    55c4:      	movl	0x2c0(%rbx), %eax
    55ca:      	cmpq	$0x7e, %rax
    55ce:      	movq	0x68(%rsp), %rbp
    55d3:      	movq	(%rip), %r13            # 0x55da <perf_unwind_native+0x55da>
    55da:      	ja	0x141 <perf_unwind_native+0x141>
    55e0:      	movzbl	0xf30(%rbx), %ecx
    55e7:      	movq	0xf10(%rbx), %rdx
    55ee:      	movq	0xf18(%rbx), %rsi
    55f5:      	leal	0x1(%rax), %edi
    55f8:      	movl	%edi, 0x2c0(%rbx)
    55fe:      	leaq	(%rax,%rax,2), %rax
    5602:      	movq	%rdx, 0x2d0(%rbx,%rax,8)
    560a:      	movq	%rsi, 0x2d8(%rbx,%rax,8)
    5612:      	movb	$0x3, 0x2e0(%rbx,%rax,8)
    561a:      	movb	%cl, 0x2e1(%rbx,%rax,8)
    5621:      	movl	$0x0, 0x2e2(%rbx,%rax,8)
    562c:      	movw	$0x0, 0x2e6(%rbx,%rax,8)
    5636:      	movl	$0x0, 0x8c(%rsp)
    5641:      	movq	0xf10(%rbx), %rax
    5648:      	movq	%rax, 0x160(%rsp)
    5650:      	movq	%rax, 0x78(%rsp)
    5655:      	movq	$-0x10000, %rax         # imm = 0xFFFF0000
    565c:      	andq	0xf18(%rbx), %rax
    5663:      	movq	%rax, 0x80(%rsp)
    566b:      	cmpl	$0x0, (%r13)
    5670:      	jne	0x679b <perf_unwind_native+0x679b>
    5676:      	movq	(%rip), %rdi            # 0x567d <perf_unwind_native+0x567d>
    567d:      	leaq	0x78(%rsp), %rsi
    5682:      	movl	$0x1, %eax
    5687:      	callq	*%rax
    5689:      	movq	%rax, 0x70(%rsp)
    568e:      	testq	%rax, %rax
    5691:      	movq	0x68(%rsp), %rbp
    5696:      	movq	(%rip), %r13            # 0x569d <perf_unwind_native+0x569d>
    569d:      	je	0x56e8 <perf_unwind_native+0x56e8>
    569f:      	movq	0x70(%rsp), %rax
    56a4:      	movq	%rax, %rbp
    56a7:      	addq	$0x6, %rbp
    56ab:      	movzwl	0x6(%rax), %eax
    56af:      	cmpl	$0xf, %eax
    56b2:      	jg	0x579c <perf_unwind_native+0x579c>
    56b8:      	cmpl	$0xb, %eax
    56bb:      	jg	0x57c4 <perf_unwind_native+0x57c4>
    56c1:      	cmpl	$0x9, %eax
    56c4:      	jg	0x5806 <perf_unwind_native+0x5806>
    56ca:      	cmpl	$0x8, %eax
    56cd:      	je	0x592d <perf_unwind_native+0x592d>
    56d3:      	cmpl	$0x9, %eax
    56d6:      	jne	0x586e <perf_unwind_native+0x586e>
    56dc:      	movq	(%rip), %rdi            # 0x56e3 <perf_unwind_native+0x56e3>
    56e3:      	jmp	0x5973 <perf_unwind_native+0x5973>
    56e8:      	movq	%r13, %rax
    56eb:      	movl	$0xfa0, %r13d           # imm = 0xFA0
    56f1:      	movl	$0x8, %r14d
    56f7:      	cmpl	$0x0, (%rax)
    56fa:      	je	0x5fc0 <perf_unwind_native+0x5fc0>
    5700:      	movabsq	$0x786c252065676170, %rax # imm = 0x786C252065676170
    570a:      	movq	%rax, 0x40(%rsp)
    570f:      	movabsq	$0x202c786c25204449, %rax # imm = 0x202C786C25204449
    5719:      	movq	%rax, 0x38(%rsp)
    571e:      	movabsq	$0x656c696620656761, %rax # imm = 0x656C696620656761
    5728:      	movq	%rax, 0x30(%rsp)
    572d:      	movabsq	$0x702061746c656420, %rax # imm = 0x702061746C656420
    5737:      	movq	%rax, 0x28(%rsp)
    573c:      	movabsq	$0x6b63617473207075, %rax # imm = 0x6B63617473207075
    5746:      	movq	%rax, 0x20(%rsp)
    574b:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    5755:      	movq	%rax, 0x18(%rsp)
    575a:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    5764:      	movq	%rax, 0x10(%rsp)
    5769:      	movw	$0xa, 0x48(%rsp)
    5770:      	leaq	0x10(%rsp), %rdi
    5775:      	movl	$0x3a, %eax
    577a:      	movl	$0x6, %r8d
    5780:      	movq	0x78(%rsp), %rdx
    5785:      	movq	0x80(%rsp), %rcx
    578d:      	movl	$0x3a, %esi
    5792:      	xorl	%eax, %eax
    5794:      	callq	*%r8
    5797:      	jmp	0x5fc0 <perf_unwind_native+0x5fc0>
    579c:      	cmpl	$0x13, %eax
    579f:      	jg	0x57e7 <perf_unwind_native+0x57e7>
    57a1:      	cmpl	$0x11, %eax
    57a4:      	jg	0x5820 <perf_unwind_native+0x5820>
    57a6:      	cmpl	$0x10, %eax
    57a9:      	je	0x5936 <perf_unwind_native+0x5936>
    57af:      	cmpl	$0x11, %eax
    57b2:      	jne	0x586e <perf_unwind_native+0x586e>
    57b8:      	movq	(%rip), %rdi            # 0x57bf <perf_unwind_native+0x57bf>
    57bf:      	jmp	0x5973 <perf_unwind_native+0x5973>
    57c4:      	cmpl	$0xd, %eax
    57c7:      	jg	0x583a <perf_unwind_native+0x583a>
    57c9:      	cmpl	$0xc, %eax
    57cc:      	je	0x593f <perf_unwind_native+0x593f>
    57d2:      	cmpl	$0xd, %eax
    57d5:      	jne	0x586e <perf_unwind_native+0x586e>
    57db:      	movq	(%rip), %rdi            # 0x57e2 <perf_unwind_native+0x57e2>
    57e2:      	jmp	0x5973 <perf_unwind_native+0x5973>
    57e7:      	cmpl	$0x15, %eax
    57ea:      	jg	0x5854 <perf_unwind_native+0x5854>
    57ec:      	cmpl	$0x14, %eax
    57ef:      	je	0x5948 <perf_unwind_native+0x5948>
    57f5:      	cmpl	$0x15, %eax
    57f8:      	jne	0x586e <perf_unwind_native+0x586e>
    57fa:      	movq	(%rip), %rdi            # 0x5801 <perf_unwind_native+0x5801>
    5801:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5806:      	cmpl	$0xa, %eax
    5809:      	je	0x5951 <perf_unwind_native+0x5951>
    580f:      	cmpl	$0xb, %eax
    5812:      	jne	0x586e <perf_unwind_native+0x586e>
    5814:      	movq	(%rip), %rdi            # 0x581b <perf_unwind_native+0x581b>
    581b:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5820:      	cmpl	$0x12, %eax
    5823:      	je	0x595a <perf_unwind_native+0x595a>
    5829:      	cmpl	$0x13, %eax
    582c:      	jne	0x586e <perf_unwind_native+0x586e>
    582e:      	movq	(%rip), %rdi            # 0x5835 <perf_unwind_native+0x5835>
    5835:      	jmp	0x5973 <perf_unwind_native+0x5973>
    583a:      	cmpl	$0xe, %eax
    583d:      	je	0x5963 <perf_unwind_native+0x5963>
    5843:      	cmpl	$0xf, %eax
    5846:      	jne	0x586e <perf_unwind_native+0x586e>
    5848:      	movq	(%rip), %rdi            # 0x584f <perf_unwind_native+0x584f>
    584f:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5854:      	cmpl	$0x16, %eax
    5857:      	je	0x596c <perf_unwind_native+0x596c>
    585d:      	cmpl	$0x17, %eax
    5860:      	jne	0x586e <perf_unwind_native+0x586e>
    5862:      	movq	(%rip), %rdi            # 0x5869 <perf_unwind_native+0x5869>
    5869:      	jmp	0x5973 <perf_unwind_native+0x5973>
    586e:      	movl	$0xfa1, %r13d           # imm = 0xFA1
    5874:      	movl	$0x33, %r14d
    587a:      	movq	(%rip), %rax            # 0x5881 <perf_unwind_native+0x5881>
    5881:      	cmpl	$0x0, (%rax)
    5884:      	je	0x5fbb <perf_unwind_native+0x5fbb>
    588a:      	movabsq	$0xa642520444970, %rax  # imm = 0xA642520444970
    5894:      	movq	%rax, 0x47(%rsp)
    5899:      	movabsq	$0x70616d206e692078, %rax # imm = 0x70616D206E692078
    58a3:      	movq	%rax, 0x40(%rsp)
    58a8:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    58b2:      	movq	%rax, 0x38(%rsp)
    58b7:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    58c1:      	movq	%rax, 0x30(%rsp)
    58c6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    58d0:      	movq	%rax, 0x28(%rsp)
    58d5:      	movabsq	$0x726574756f207075, %rax # imm = 0x726574756F207075
    58df:      	movq	%rax, 0x20(%rsp)
    58e4:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    58ee:      	movq	%rax, 0x18(%rsp)
    58f3:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    58fd:      	movq	%rax, 0x10(%rsp)
    5902:      	leaq	0x10(%rsp), %rdi
    5907:      	movl	$0x3f, %eax
    590c:      	movl	$0x6, %r8d
    5912:      	movq	0x160(%rsp), %rdx
    591a:      	movzwl	(%rbp), %ecx
    591e:      	movl	$0x3f, %esi
    5923:      	xorl	%eax, %eax
    5925:      	callq	*%r8
    5928:      	jmp	0x5fbb <perf_unwind_native+0x5fbb>
    592d:      	movq	(%rip), %rdi            # 0x5934 <perf_unwind_native+0x5934>
    5934:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5936:      	movq	(%rip), %rdi            # 0x593d <perf_unwind_native+0x593d>
    593d:      	jmp	0x5973 <perf_unwind_native+0x5973>
    593f:      	movq	(%rip), %rdi            # 0x5946 <perf_unwind_native+0x5946>
    5946:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5948:      	movq	(%rip), %rdi            # 0x594f <perf_unwind_native+0x594f>
    594f:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5951:      	movq	(%rip), %rdi            # 0x5958 <perf_unwind_native+0x5958>
    5958:      	jmp	0x5973 <perf_unwind_native+0x5973>
    595a:      	movq	(%rip), %rdi            # 0x5961 <perf_unwind_native+0x5961>
    5961:      	jmp	0x5973 <perf_unwind_native+0x5973>
    5963:      	movq	(%rip), %rdi            # 0x596a <perf_unwind_native+0x596a>
    596a:      	jmp	0x5973 <perf_unwind_native+0x5973>
    596c:      	movq	(%rip), %rdi            # 0x5973 <perf_unwind_native+0x5973>
    5973:      	leaq	0x160(%rsp), %rsi
    597b:      	movl	$0x1, %eax
    5980:      	callq	*%rax
    5982:      	movq	%rax, 0x58(%rsp)
    5987:      	testq	%rax, %rax
    598a:      	je	0x5f9f <perf_unwind_native+0x5f9f>
    5990:      	movq	0x70(%rsp), %rcx
    5995:      	movl	(%rcx), %r13d
    5998:      	movl	%r13d, 0x90(%rsp)
    59a0:      	movq	0xf18(%rbx), %rax
    59a7:      	movq	%rax, 0x8(%rsp)
    59ac:      	movzwl	0x4(%rcx), %eax
    59b0:      	testl	%eax, %eax
    59b2:      	je	0x5ed9 <perf_unwind_native+0x5ed9>
    59b8:      	movq	%rax, %r12
    59bb:      	addl	%r13d, %r12d
    59be:      	movq	(%rip), %rax            # 0x59c5 <perf_unwind_native+0x59c5>
    59c5:      	cmpl	$0x0, (%rax)
    59c8:      	jne	0x68a9 <perf_unwind_native+0x68a9>
    59ce:      	leal	(%r12,%r13), %eax
    59d2:      	shrl	%eax
    59d4:      	movl	%eax, 0x10(%rsp)
    59d8:      	leaq	0x10(%rsp), %rsi
    59dd:      	movl	$0x1, %eax
    59e2:      	movq	0x58(%rsp), %rdi
    59e7:      	callq	*%rax
    59e9:      	testq	%rax, %rax
    59ec:      	je	0x624f <perf_unwind_native+0x624f>
    59f2:      	movl	0x10(%rsp), %ecx
    59f6:      	leal	0x1(%rcx), %ebp
    59f9:      	movq	0x8(%rsp), %rdx
    59fe:      	cmpw	%dx, (%rax)
    5a01:      	cmoval	%r13d, %ebp
    5a05:      	cmoval	%ecx, %r12d
    5a09:      	movq	%r12, %rax
    5a0c:      	movq	%r12, (%rsp)
    5a10:      	cmpl	%r12d, %ebp
    5a13:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5a19:      	movq	(%rsp), %rax
    5a1d:      	addl	%ebp, %eax
    5a1f:      	shrl	%eax
    5a21:      	movl	%eax, 0x10(%rsp)
    5a25:      	leaq	0x10(%rsp), %rsi
    5a2a:      	movl	$0x1, %eax
    5a2f:      	movq	0x58(%rsp), %rdi
    5a34:      	callq	*%rax
    5a36:      	testq	%rax, %rax
    5a39:      	je	0x624f <perf_unwind_native+0x624f>
    5a3f:      	movl	0x10(%rsp), %ecx
    5a43:      	leal	0x1(%rcx), %r13d
    5a47:      	movq	0x8(%rsp), %rdx
    5a4c:      	cmpw	%dx, (%rax)
    5a4f:      	cmoval	%ebp, %r13d
    5a53:      	movq	(%rsp), %rdx
    5a57:      	cmoval	%ecx, %edx
    5a5a:      	movq	%rdx, %rax
    5a5d:      	movq	%rdx, (%rsp)
    5a61:      	cmpl	%edx, %r13d
    5a64:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5a6a:      	movq	(%rsp), %rax
    5a6e:      	addl	%r13d, %eax
    5a71:      	shrl	%eax
    5a73:      	movl	%eax, 0x10(%rsp)
    5a77:      	leaq	0x10(%rsp), %rsi
    5a7c:      	movl	$0x1, %eax
    5a81:      	movq	0x58(%rsp), %rdi
    5a86:      	callq	*%rax
    5a88:      	testq	%rax, %rax
    5a8b:      	je	0x624f <perf_unwind_native+0x624f>
    5a91:      	movl	0x10(%rsp), %ecx
    5a95:      	leal	0x1(%rcx), %ebp
    5a98:      	movq	0x8(%rsp), %rdx
    5a9d:      	cmpw	%dx, (%rax)
    5aa0:      	cmoval	%r13d, %ebp
    5aa4:      	movq	(%rsp), %rdx
    5aa8:      	cmoval	%ecx, %edx
    5aab:      	movq	%rdx, %rax
    5aae:      	movq	%rdx, (%rsp)
    5ab2:      	cmpl	%edx, %ebp
    5ab4:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5aba:      	movq	(%rsp), %rax
    5abe:      	addl	%ebp, %eax
    5ac0:      	shrl	%eax
    5ac2:      	movl	%eax, 0x10(%rsp)
    5ac6:      	leaq	0x10(%rsp), %rsi
    5acb:      	movl	$0x1, %eax
    5ad0:      	movq	0x58(%rsp), %rdi
    5ad5:      	callq	*%rax
    5ad7:      	testq	%rax, %rax
    5ada:      	je	0x624f <perf_unwind_native+0x624f>
    5ae0:      	movl	0x10(%rsp), %ecx
    5ae4:      	leal	0x1(%rcx), %r13d
    5ae8:      	movq	0x8(%rsp), %rdx
    5aed:      	cmpw	%dx, (%rax)
    5af0:      	cmoval	%ebp, %r13d
    5af4:      	movq	(%rsp), %rdx
    5af8:      	cmoval	%ecx, %edx
    5afb:      	movq	%rdx, %rax
    5afe:      	movq	%rdx, (%rsp)
    5b02:      	cmpl	%edx, %r13d
    5b05:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5b0b:      	movq	(%rsp), %rax
    5b0f:      	addl	%r13d, %eax
    5b12:      	shrl	%eax
    5b14:      	movl	%eax, 0x10(%rsp)
    5b18:      	leaq	0x10(%rsp), %rsi
    5b1d:      	movl	$0x1, %eax
    5b22:      	movq	0x58(%rsp), %rdi
    5b27:      	callq	*%rax
    5b29:      	testq	%rax, %rax
    5b2c:      	je	0x624f <perf_unwind_native+0x624f>
    5b32:      	movl	0x10(%rsp), %ecx
    5b36:      	leal	0x1(%rcx), %ebp
    5b39:      	movq	0x8(%rsp), %rdx
    5b3e:      	cmpw	%dx, (%rax)
    5b41:      	cmoval	%r13d, %ebp
    5b45:      	movq	(%rsp), %rdx
    5b49:      	cmoval	%ecx, %edx
    5b4c:      	movq	%rdx, %rax
    5b4f:      	movq	%rdx, (%rsp)
    5b53:      	cmpl	%edx, %ebp
    5b55:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5b5b:      	movq	(%rsp), %rax
    5b5f:      	addl	%ebp, %eax
    5b61:      	shrl	%eax
    5b63:      	movl	%eax, 0x10(%rsp)
    5b67:      	leaq	0x10(%rsp), %rsi
    5b6c:      	movl	$0x1, %eax
    5b71:      	movq	0x58(%rsp), %rdi
    5b76:      	callq	*%rax
    5b78:      	testq	%rax, %rax
    5b7b:      	je	0x624f <perf_unwind_native+0x624f>
    5b81:      	movl	0x10(%rsp), %ecx
    5b85:      	leal	0x1(%rcx), %r13d
    5b89:      	movq	0x8(%rsp), %rdx
    5b8e:      	cmpw	%dx, (%rax)
    5b91:      	cmoval	%ebp, %r13d
    5b95:      	movq	(%rsp), %rdx
    5b99:      	cmoval	%ecx, %edx
    5b9c:      	movq	%rdx, %rax
    5b9f:      	movq	%rdx, (%rsp)
    5ba3:      	cmpl	%edx, %r13d
    5ba6:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5bac:      	movq	(%rsp), %rax
    5bb0:      	addl	%r13d, %eax
    5bb3:      	shrl	%eax
    5bb5:      	movl	%eax, 0x10(%rsp)
    5bb9:      	leaq	0x10(%rsp), %rsi
    5bbe:      	movl	$0x1, %eax
    5bc3:      	movq	0x58(%rsp), %rdi
    5bc8:      	callq	*%rax
    5bca:      	testq	%rax, %rax
    5bcd:      	je	0x624f <perf_unwind_native+0x624f>
    5bd3:      	movl	0x10(%rsp), %ecx
    5bd7:      	leal	0x1(%rcx), %ebp
    5bda:      	movq	0x8(%rsp), %rdx
    5bdf:      	cmpw	%dx, (%rax)
    5be2:      	cmoval	%r13d, %ebp
    5be6:      	movq	(%rsp), %rdx
    5bea:      	cmoval	%ecx, %edx
    5bed:      	movq	%rdx, %rax
    5bf0:      	movq	%rdx, (%rsp)
    5bf4:      	cmpl	%edx, %ebp
    5bf6:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5bfc:      	movq	(%rsp), %rax
    5c00:      	addl	%ebp, %eax
    5c02:      	shrl	%eax
    5c04:      	movl	%eax, 0x10(%rsp)
    5c08:      	leaq	0x10(%rsp), %rsi
    5c0d:      	movl	$0x1, %eax
    5c12:      	movq	0x58(%rsp), %rdi
    5c17:      	callq	*%rax
    5c19:      	testq	%rax, %rax
    5c1c:      	je	0x624f <perf_unwind_native+0x624f>
    5c22:      	movl	0x10(%rsp), %ecx
    5c26:      	leal	0x1(%rcx), %r13d
    5c2a:      	movq	0x8(%rsp), %rdx
    5c2f:      	cmpw	%dx, (%rax)
    5c32:      	cmoval	%ebp, %r13d
    5c36:      	movq	(%rsp), %rdx
    5c3a:      	cmoval	%ecx, %edx
    5c3d:      	movq	%rdx, %rax
    5c40:      	movq	%rdx, (%rsp)
    5c44:      	cmpl	%edx, %r13d
    5c47:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5c4d:      	movq	(%rsp), %rax
    5c51:      	addl	%r13d, %eax
    5c54:      	shrl	%eax
    5c56:      	movl	%eax, 0x10(%rsp)
    5c5a:      	leaq	0x10(%rsp), %rsi
    5c5f:      	movl	$0x1, %eax
    5c64:      	movq	0x58(%rsp), %rdi
    5c69:      	callq	*%rax
    5c6b:      	testq	%rax, %rax
    5c6e:      	je	0x624f <perf_unwind_native+0x624f>
    5c74:      	movl	0x10(%rsp), %ecx
    5c78:      	leal	0x1(%rcx), %ebp
    5c7b:      	movq	0x8(%rsp), %rdx
    5c80:      	cmpw	%dx, (%rax)
    5c83:      	cmoval	%r13d, %ebp
    5c87:      	movq	(%rsp), %rdx
    5c8b:      	cmoval	%ecx, %edx
    5c8e:      	movq	%rdx, %rax
    5c91:      	movq	%rdx, (%rsp)
    5c95:      	cmpl	%edx, %ebp
    5c97:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5c9d:      	movq	(%rsp), %rax
    5ca1:      	addl	%ebp, %eax
    5ca3:      	shrl	%eax
    5ca5:      	movl	%eax, 0x10(%rsp)
    5ca9:      	leaq	0x10(%rsp), %rsi
    5cae:      	movl	$0x1, %eax
    5cb3:      	movq	0x58(%rsp), %rdi
    5cb8:      	callq	*%rax
    5cba:      	testq	%rax, %rax
    5cbd:      	je	0x624f <perf_unwind_native+0x624f>
    5cc3:      	movl	0x10(%rsp), %ecx
    5cc7:      	leal	0x1(%rcx), %r13d
    5ccb:      	movq	0x8(%rsp), %rdx
    5cd0:      	cmpw	%dx, (%rax)
    5cd3:      	cmoval	%ebp, %r13d
    5cd7:      	movq	(%rsp), %rdx
    5cdb:      	cmoval	%ecx, %edx
    5cde:      	movq	%rdx, %rax
    5ce1:      	movq	%rdx, (%rsp)
    5ce5:      	cmpl	%edx, %r13d
    5ce8:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5cee:      	movq	(%rsp), %rax
    5cf2:      	addl	%r13d, %eax
    5cf5:      	shrl	%eax
    5cf7:      	movl	%eax, 0x10(%rsp)
    5cfb:      	leaq	0x10(%rsp), %rsi
    5d00:      	movl	$0x1, %eax
    5d05:      	movq	0x58(%rsp), %rdi
    5d0a:      	callq	*%rax
    5d0c:      	testq	%rax, %rax
    5d0f:      	je	0x624f <perf_unwind_native+0x624f>
    5d15:      	movl	0x10(%rsp), %ecx
    5d19:      	leal	0x1(%rcx), %ebp
    5d1c:      	movq	0x8(%rsp), %rdx
    5d21:      	cmpw	%dx, (%rax)
    5d24:      	cmoval	%r13d, %ebp
    5d28:      	movq	(%rsp), %rdx
    5d2c:      	cmoval	%ecx, %edx
    5d2f:      	movq	%rdx, %rax
    5d32:      	movq	%rdx, (%rsp)
    5d36:      	cmpl	%edx, %ebp
    5d38:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5d3e:      	movq	(%rsp), %rax
    5d42:      	addl	%ebp, %eax
    5d44:      	shrl	%eax
    5d46:      	movl	%eax, 0x10(%rsp)
    5d4a:      	leaq	0x10(%rsp), %rsi
    5d4f:      	movl	$0x1, %eax
    5d54:      	movq	0x58(%rsp), %rdi
    5d59:      	callq	*%rax
    5d5b:      	testq	%rax, %rax
    5d5e:      	je	0x624f <perf_unwind_native+0x624f>
    5d64:      	movl	0x10(%rsp), %ecx
    5d68:      	leal	0x1(%rcx), %r13d
    5d6c:      	movq	0x8(%rsp), %rdx
    5d71:      	cmpw	%dx, (%rax)
    5d74:      	cmoval	%ebp, %r13d
    5d78:      	movq	(%rsp), %rdx
    5d7c:      	cmoval	%ecx, %edx
    5d7f:      	movq	%rdx, %rax
    5d82:      	movq	%rdx, (%rsp)
    5d86:      	cmpl	%edx, %r13d
    5d89:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5d8f:      	movq	(%rsp), %rax
    5d93:      	addl	%r13d, %eax
    5d96:      	shrl	%eax
    5d98:      	movl	%eax, 0x10(%rsp)
    5d9c:      	leaq	0x10(%rsp), %rsi
    5da1:      	movl	$0x1, %eax
    5da6:      	movq	0x58(%rsp), %rdi
    5dab:      	callq	*%rax
    5dad:      	testq	%rax, %rax
    5db0:      	je	0x624f <perf_unwind_native+0x624f>
    5db6:      	movl	0x10(%rsp), %ecx
    5dba:      	leal	0x1(%rcx), %ebp
    5dbd:      	movq	0x8(%rsp), %rdx
    5dc2:      	cmpw	%dx, (%rax)
    5dc5:      	cmoval	%r13d, %ebp
    5dc9:      	movq	(%rsp), %rdx
    5dcd:      	cmoval	%ecx, %edx
    5dd0:      	movq	%rdx, %rax
    5dd3:      	movq	%rdx, (%rsp)
    5dd7:      	cmpl	%edx, %ebp
    5dd9:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5ddf:      	movq	(%rsp), %rax
    5de3:      	addl	%ebp, %eax
    5de5:      	shrl	%eax
    5de7:      	movl	%eax, 0x10(%rsp)
    5deb:      	leaq	0x10(%rsp), %rsi
    5df0:      	movl	$0x1, %eax
    5df5:      	movq	0x58(%rsp), %rdi
    5dfa:      	callq	*%rax
    5dfc:      	testq	%rax, %rax
    5dff:      	je	0x624f <perf_unwind_native+0x624f>
    5e05:      	movl	0x10(%rsp), %ecx
    5e09:      	leal	0x1(%rcx), %r13d
    5e0d:      	movq	0x8(%rsp), %rdx
    5e12:      	cmpw	%dx, (%rax)
    5e15:      	cmoval	%ebp, %r13d
    5e19:      	movq	(%rsp), %rdx
    5e1d:      	cmoval	%ecx, %edx
    5e20:      	movq	%rdx, %rax
    5e23:      	movq	%rdx, (%rsp)
    5e27:      	cmpl	%edx, %r13d
    5e2a:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5e30:      	movq	(%rsp), %rax
    5e34:      	addl	%r13d, %eax
    5e37:      	shrl	%eax
    5e39:      	movl	%eax, 0x10(%rsp)
    5e3d:      	leaq	0x10(%rsp), %rsi
    5e42:      	movl	$0x1, %eax
    5e47:      	movq	0x58(%rsp), %rdi
    5e4c:      	callq	*%rax
    5e4e:      	testq	%rax, %rax
    5e51:      	je	0x624f <perf_unwind_native+0x624f>
    5e57:      	movl	0x10(%rsp), %ecx
    5e5b:      	leal	0x1(%rcx), %ebp
    5e5e:      	movq	0x8(%rsp), %rdx
    5e63:      	cmpw	%dx, (%rax)
    5e66:      	cmoval	%r13d, %ebp
    5e6a:      	movq	(%rsp), %rdx
    5e6e:      	cmoval	%ecx, %edx
    5e71:      	movq	%rdx, %rax
    5e74:      	movq	%rdx, (%rsp)
    5e78:      	cmpl	%edx, %ebp
    5e7a:      	jae	0x5eca <perf_unwind_native+0x5eca>
    5e7c:      	movq	(%rsp), %rax
    5e80:      	addl	%ebp, %eax
    5e82:      	shrl	%eax
    5e84:      	movl	%eax, 0x10(%rsp)
    5e88:      	leaq	0x10(%rsp), %rsi
    5e8d:      	movl	$0x1, %eax
    5e92:      	movq	0x58(%rsp), %rdi
    5e97:      	callq	*%rax
    5e99:      	testq	%rax, %rax
    5e9c:      	je	0x624f <perf_unwind_native+0x624f>
    5ea2:      	movl	0x10(%rsp), %ecx
    5ea6:      	leal	0x1(%rcx), %edx
    5ea9:      	movq	0x8(%rsp), %rsi
    5eae:      	cmpw	%si, (%rax)
    5eb1:      	cmoval	%ebp, %edx
    5eb4:      	movq	(%rsp), %rsi
    5eb8:      	cmoval	%ecx, %esi
    5ebb:      	movq	%rsi, %rax
    5ebe:      	movq	%rsi, (%rsp)
    5ec2:      	cmpl	%esi, %edx
    5ec4:      	jb	0x624f <perf_unwind_native+0x624f>
    5eca:      	movq	(%rsp), %rax
    5ece:      	movl	%eax, %r13d
    5ed1:      	testl	%eax, %eax
    5ed3:      	je	0x624f <perf_unwind_native+0x624f>
    5ed9:      	decl	%r13d
    5edc:      	movl	%r13d, 0x90(%rsp)
    5ee4:      	leaq	0x90(%rsp), %rsi
    5eec:      	movl	$0x1, %eax
    5ef1:      	movq	0x58(%rsp), %rdi
    5ef6:      	callq	*%rax
    5ef8:      	testq	%rax, %rax
    5efb:      	movl	$0xfa4, %ecx            # imm = 0xFA4
    5f00:      	movl	$0xa, %edx
    5f05:      	je	0x4333 <perf_unwind_native+0x4333>
    5f0b:      	movq	%rax, %rbp
    5f0e:      	movq	(%rip), %rax            # 0x5f15 <perf_unwind_native+0x5f15>
    5f15:      	cmpl	$0x0, (%rax)
    5f18:      	jne	0x692d <perf_unwind_native+0x692d>
    5f1e:      	movzwl	0x8(%rsp), %eax
    5f23:      	movzwl	(%rbp), %ecx
    5f27:      	subl	%ecx, %eax
    5f29:      	movl	0x90(%rsp), %ecx
    5f30:      	leal	0x10000(%rax), %r13d
    5f37:      	movq	0x70(%rsp), %rdx
    5f3c:      	cmpl	(%rdx), %ecx
    5f3e:      	cmovael	%eax, %r13d
    5f42:      	movzwl	0x2(%rbp), %eax
    5f46:      	movl	%eax, 0x8c(%rsp)
    5f4d:      	movl	$0xd, %edx
    5f52:      	movl	$0xfa5, %ecx            # imm = 0xFA5
    5f57:      	cmpl	$0x8000, %eax           # imm = 0x8000
    5f5c:      	je	0x4333 <perf_unwind_native+0x4333>
    5f62:      	cmpl	$0x8001, %eax           # imm = 0x8001
    5f67:      	jne	0x62dd <perf_unwind_native+0x62dd>
    5f6d:      	movl	$0x7, 0x94(%rsp)
    5f78:      	movq	(%rip), %rdi            # 0x5f7f <perf_unwind_native+0x5f7f>
    5f7f:      	leaq	0x94(%rsp), %rsi
    5f87:      	movl	$0x1, %eax
    5f8c:      	callq	*%rax
    5f8e:      	testq	%rax, %rax
    5f91:      	je	0x62c6 <perf_unwind_native+0x62c6>
    5f97:      	incq	(%rax)
    5f9a:      	jmp	0x62d6 <perf_unwind_native+0x62d6>
    5f9f:      	movl	$0xfa2, %r13d           # imm = 0xFA2
    5fa5:      	movl	$0x32, %r14d
    5fab:      	movq	(%rip), %rax            # 0x5fb2 <perf_unwind_native+0x5fb2>
    5fb2:      	cmpl	$0x0, (%rax)
    5fb5:      	jne	0x61c8 <perf_unwind_native+0x61c8>
    5fbb:      	movq	0x68(%rsp), %rbp
    5fc0:      	movl	%r14d, 0xf28(%rbx)
    5fc7:      	xorl	%r12d, %r12d
    5fca:      	movl	%r13d, %r14d
    5fcd:      	movq	(%rip), %r13            # 0x5fd4 <perf_unwind_native+0x5fd4>
    5fd4:      	movl	%r14d, 0xf2c(%rbx)
    5fdb:      	movl	$0x0, 0xa0(%rsp)
    5fe6:      	movq	(%rip), %rdi            # 0x5fed <perf_unwind_native+0x5fed>
    5fed:      	leaq	0xa0(%rsp), %rsi
    5ff5:      	movl	$0x1, %eax
    5ffa:      	callq	*%rax
    5ffc:      	testq	%rax, %rax
    5fff:      	je	0x6042 <perf_unwind_native+0x6042>
    6001:      	movzbl	0x1384(%rax), %ecx
    6008:      	movl	%r12d, %edx
    600b:      	cmpb	$0x1d, %cl
    600e:      	jb	0x6069 <perf_unwind_native+0x6069>
    6010:      	movq	%rax, %rbx
    6013:      	movl	$0x5, 0xf2c(%rax)
    601d:      	movl	$0x44, 0x10(%rsp)
    6025:      	movq	(%rip), %rdi            # 0x602c <perf_unwind_native+0x602c>
    602c:      	leaq	0x10(%rsp), %rsi
    6031:      	movl	$0x1, %eax
    6036:      	callq	*%rax
    6038:      	testq	%rax, %rax
    603b:      	je	0x6052 <perf_unwind_native+0x6052>
    603d:      	incq	(%rax)
    6040:      	jmp	0x605d <perf_unwind_native+0x605d>
    6042:      	movq	(%rip), %rcx            # 0x6049 <perf_unwind_native+0x6049>
    6049:      	xorl	%edx, %edx
    604b:      	movl	$0xc, %eax
    6050:      	jmp	0x607f <perf_unwind_native+0x607f>
    6052:      	cmpl	$0x0, (%r13)
    6057:      	jne	0x6138 <perf_unwind_native+0x6138>
    605d:      	movq	%rbx, %rax
    6060:      	movzbl	0x1384(%rbx), %ecx
    6067:      	xorl	%edx, %edx
    6069:      	incb	%cl
    606b:      	movb	%cl, 0x1384(%rax)
    6071:      	movl	%edx, %ecx
    6073:      	movq	(%rip), %rsi            # 0x607a <perf_unwind_native+0x607a>
    607a:      	movl	$0xc, %eax
    607f:      	movq	(%rip), %rsi            # 0x6086 <perf_unwind_native+0x6086>
    6086:      	movq	%rbp, %rdi
    6089:      	callq	*%rax
    608b:      	cmpl	$0x0, (%r13)
    6090:      	jne	0x60a9 <perf_unwind_native+0x60a9>
    6092:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    6097:      	addq	$0x168, %rsp            # imm = 0x168
    609e:      	popq	%rbx
    609f:      	popq	%r12
    60a1:      	popq	%r13
    60a3:      	popq	%r14
    60a5:      	popq	%r15
    60a7:      	popq	%rbp
    60a8:      	retq
    60a9:      	movabsq	$0xa65766974616e, %rax  # imm = 0xA65766974616E
    60b3:      	movq	%rax, 0xc6(%rsp)
    60bb:      	movabsq	$0x616e5f646e69776e, %rax # imm = 0x616E5F646E69776E
    60c5:      	movq	%rax, 0xc0(%rsp)
    60cd:      	movabsq	$0x75206e6920642520, %rax # imm = 0x75206E6920642520
    60d7:      	movq	%rax, 0xb8(%rsp)
    60df:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
    60e9:      	movq	%rax, 0xb0(%rsp)
    60f1:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
    60fb:      	movq	%rax, 0xa8(%rsp)
    6103:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
    610d:      	movq	%rax, 0xa0(%rsp)
    6115:      	leaq	0xa0(%rsp), %rdi
    611d:      	movl	$0x2e, %eax
    6122:      	movl	$0x6, %ecx
    6127:      	movl	$0x2e, %esi
    612c:      	movl	%r12d, %edx
    612f:      	xorl	%eax, %eax
    6131:      	callq	*%rcx
    6133:      	jmp	0x6092 <perf_unwind_native+0x6092>
    6138:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6142:      	movq	%rax, 0xc6(%rsp)
    614a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6154:      	movq	%rax, 0xc0(%rsp)
    615c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6166:      	movq	%rax, 0xb8(%rsp)
    616e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6178:      	movq	%rax, 0xb0(%rsp)
    6180:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    618a:      	movq	%rax, 0xa8(%rsp)
    6192:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    619c:      	movq	%rax, 0xa0(%rsp)
    61a4:      	leaq	0xa0(%rsp), %rdi
    61ac:      	movl	$0x2e, %eax
    61b1:      	movl	$0x6, %ecx
    61b6:      	movl	0x10(%rsp), %edx
    61ba:      	movl	$0x2e, %esi
    61bf:      	xorl	%eax, %eax
    61c1:      	callq	*%rcx
    61c3:      	jmp	0x605d <perf_unwind_native+0x605d>
    61c8:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    61d2:      	movq	%rax, 0x38(%rsp)
    61d7:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    61e1:      	movq	%rax, 0x30(%rsp)
    61e6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    61f0:      	movq	%rax, 0x28(%rsp)
    61f5:      	movabsq	$0x72656e6e69207075, %rax # imm = 0x72656E6E69207075
    61ff:      	movq	%rax, 0x20(%rsp)
    6204:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    620e:      	movq	%rax, 0x18(%rsp)
    6213:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    621d:      	movq	%rax, 0x10(%rsp)
    6222:      	movl	$0xa786c, 0x3f(%rsp)    # imm = 0xA786C
    622a:      	leaq	0x10(%rsp), %rdi
    622f:      	movl	$0x33, %eax
    6234:      	movl	$0x6, %ecx
    6239:      	movq	0x160(%rsp), %rdx
    6241:      	movl	$0x33, %esi
    6246:      	xorl	%eax, %eax
    6248:      	callq	*%rcx
    624a:      	jmp	0x5fbb <perf_unwind_native+0x5fbb>
    624f:      	movq	(%rip), %rax            # 0x6256 <perf_unwind_native+0x6256>
    6256:      	cmpl	$0x0, (%rax)
    6259:      	je	0x2745 <perf_unwind_native+0x2745>
    625f:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
    6269:      	movq	%rax, 0x30(%rsp)
    626e:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
    6278:      	movq	%rax, 0x28(%rsp)
    627d:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
    6287:      	movq	%rax, 0x20(%rsp)
    628c:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
    6296:      	movq	%rax, 0x18(%rsp)
    629b:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
    62a5:      	movq	%rax, 0x10(%rsp)
    62aa:      	movl	$0xa3f61, 0x37(%rsp)    # imm = 0xA3F61
    62b2:      	leaq	0x10(%rsp), %rdi
    62b7:      	movl	$0x2b, %eax
    62bc:      	movl	$0x6, %ecx
    62c1:      	jmp	0x2d70 <perf_unwind_native+0x2d70>
    62c6:      	movq	(%rip), %rax            # 0x62cd <perf_unwind_native+0x62cd>
    62cd:      	cmpl	$0x0, (%rax)
    62d0:      	jne	0x6aba <perf_unwind_native+0x6aba>
    62d6:      	movl	0x8c(%rsp), %eax
    62dd:      	testw	%ax, %ax
    62e0:      	js	0x645a <perf_unwind_native+0x645a>
    62e6:      	movq	(%rip), %rdi            # 0x62ed <perf_unwind_native+0x62ed>
    62ed:      	leaq	0x8c(%rsp), %rsi
    62f5:      	movl	$0x1, %eax
    62fa:      	callq	*%rax
    62fc:      	movq	%rax, 0x70(%rsp)
    6301:      	testq	%rax, %rax
    6304:      	je	0x6393 <perf_unwind_native+0x6393>
    630a:      	movq	0x70(%rsp), %rax
    630f:      	movl	0x4(%rax), %ebp
    6312:      	movzbl	0x2(%rax), %eax
    6316:      	testb	%al, %al
    6318:      	je	0x6356 <perf_unwind_native+0x6356>
    631a:      	movq	(%rip), %rcx            # 0x6321 <perf_unwind_native+0x6321>
    6321:      	cmpl	$0x0, (%rcx)
    6324:      	jne	0x6a46 <perf_unwind_native+0x6a46>
    632a:      	movl	%eax, %ecx
    632c:      	andb	$0x7f, %cl
    632f:      	movzbl	%cl, %ecx
    6332:      	cmpl	%ecx, %r13d
    6335:      	jl	0x6356 <perf_unwind_native+0x6356>
    6337:      	xorl	%ecx, %ecx
    6339:      	testb	%al, %al
    633b:      	setns	%cl
    633e:      	shll	$0x4, %ecx
    6341:      	addl	%ecx, %ebp
    6343:      	addl	$-0x8, %ebp
    6346:      	movq	(%rip), %rax            # 0x634d <perf_unwind_native+0x634d>
    634d:      	cmpl	$0x0, (%rax)
    6350:      	jne	0x6b38 <perf_unwind_native+0x6b38>
    6356:      	movq	0x70(%rsp), %rax
    635b:      	movzbl	(%rax), %eax
    635e:      	movl	%ebp, %ecx
    6360:      	andl	$-0x8, %ecx
    6363:      	testb	%al, %al
    6365:      	cmovnsl	%ebp, %ecx
    6368:      	movl	%eax, %edx
    636a:      	andl	$0x7f, %edx
    636d:      	xorl	%r13d, %r13d
    6370:      	cmpl	$0x2, %edx
    6373:      	jg	0x656c <perf_unwind_native+0x656c>
    6379:      	cmpl	$0x1, %edx
    637c:      	je	0x66da <perf_unwind_native+0x66da>
    6382:      	movq	%r15, %rsi
    6385:      	cmpl	$0x2, %edx
    6388:      	je	0x66d7 <perf_unwind_native+0x66d7>
    638e:      	jmp	0x6c12 <perf_unwind_native+0x6c12>
    6393:      	movl	$0x55, 0x78(%rsp)
    639b:      	movq	(%rip), %rdi            # 0x63a2 <perf_unwind_native+0x63a2>
    63a2:      	leaq	0x78(%rsp), %rsi
    63a7:      	movl	$0x1, %eax
    63ac:      	callq	*%rax
    63ae:      	testq	%rax, %rax
    63b1:      	je	0x63bd <perf_unwind_native+0x63bd>
    63b3:      	incq	(%rax)
    63b6:      	movq	0x68(%rsp), %rbp
    63bb:      	jmp	0x63ce <perf_unwind_native+0x63ce>
    63bd:      	movq	(%rip), %rax            # 0x63c4 <perf_unwind_native+0x63c4>
    63c4:      	cmpl	$0x0, (%rax)
    63c7:      	movq	0x68(%rsp), %rbp
    63cc:      	jne	0x63d9 <perf_unwind_native+0x63d9>
    63ce:      	movl	$0xfaf, %r13d           # imm = 0xFAF
    63d4:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    63d9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    63e3:      	movq	%rax, 0x36(%rsp)
    63e8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    63f2:      	movq	%rax, 0x30(%rsp)
    63f7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6401:      	movq	%rax, 0x28(%rsp)
    6406:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6410:      	movq	%rax, 0x20(%rsp)
    6415:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    641f:      	movq	%rax, 0x18(%rsp)
    6424:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    642e:      	movq	%rax, 0x10(%rsp)
    6433:      	leaq	0x10(%rsp), %rdi
    6438:      	movl	$0x2e, %eax
    643d:      	movl	$0x6, %ecx
    6442:      	movl	0x78(%rsp), %edx
    6446:      	movl	$0x2e, %esi
    644b:      	xorl	%eax, %eax
    644d:      	callq	*%rcx
    644f:      	movl	$0xfaf, %r13d           # imm = 0xFAF
    6455:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    645a:      	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    645f:      	movl	$0x1, %r13d
    6465:      	cmpl	$0x2, %eax
    6468:      	jg	0x64fa <perf_unwind_native+0x64fa>
    646e:      	cmpl	$0x1, %eax
    6471:      	movq	0x68(%rsp), %rbp
    6476:      	movq	0x140(%rsp), %rcx
    647e:      	je	0x64f2 <perf_unwind_native+0x64f2>
    6480:      	cmpl	$0x2, %eax
    6483:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    6489:      	movq	%r15, %rdx
    648c:      	movq	(%r15), %rax
    648f:      	movl	(%rcx), %ecx
    6491:      	andl	$0xf, %ecx
    6494:      	xorl	%edx, %edx
    6496:      	cmpl	$0xb, %ecx
    6499:      	setae	%dl
    649c:      	leaq	(%rax,%rdx,8), %r13
    64a0:      	addq	$0x8, %r13
    64a4:      	movq	(%rip), %rax            # 0x64ab <perf_unwind_native+0x64ab>
    64ab:      	cmpl	$0x0, (%rax)
    64ae:      	je	0x6eb8 <perf_unwind_native+0x6eb8>
    64b4:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    64be:      	movq	%rax, 0x18(%rsp)
    64c3:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
    64cd:      	movq	%rax, 0x10(%rsp)
    64d2:      	leaq	0x10(%rsp), %rdi
    64d7:      	movl	$0x10, %eax
    64dc:      	movl	$0x6, %ecx
    64e1:      	movl	$0x10, %esi
    64e6:      	movq	%r13, %rdx
    64e9:      	xorl	%eax, %eax
    64eb:      	callq	*%rcx
    64ed:      	jmp	0x6eb8 <perf_unwind_native+0x6eb8>
    64f2:      	xorl	%r13d, %r13d
    64f5:      	jmp	0x5fc7 <perf_unwind_native+0x5fc7>
    64fa:      	cmpl	$0x3, %eax
    64fd:      	je	0x65d1 <perf_unwind_native+0x65d1>
    6503:      	cmpl	$0x4, %eax
    6506:      	movq	0x68(%rsp), %rbp
    650b:      	movq	0x60(%rsp), %rdx
    6510:      	jne	0x5fc7 <perf_unwind_native+0x5fc7>
    6516:      	movq	(%rdx), %rax
    6519:      	leaq	0x10(%rsp), %rdi
    651e:      	movl	$0x10, %ecx
    6523:      	movl	$0x70, %r8d
    6529:      	movq	(%rdx), %rdx
    652c:      	movl	$0x10, %esi
    6531:      	callq	*%r8
    6534:      	testq	%rax, %rax
    6537:      	jne	0x163b <perf_unwind_native+0x163b>
    653d:      	movq	0xee0(%rbx), %rax
    6544:      	addq	$0x10, %rax
    6548:      	movq	%rax, 0xed8(%rbx)
    654f:      	movq	0x10(%rsp), %rax
    6554:      	movq	%rax, 0xee0(%rbx)
    655b:      	movq	0x18(%rsp), %rax
    6560:      	movq	%rax, 0xed0(%rbx)
    6567:      	jmp	0x6ef3 <perf_unwind_native+0x6ef3>
    656c:      	cmpl	$0x3, %edx
    656f:      	je	0x66d2 <perf_unwind_native+0x66d2>
    6575:      	cmpl	$0x5, %edx
    6578:      	jne	0x6c12 <perf_unwind_native+0x6c12>
    657e:      	movl	%ebp, %eax
    6580:      	sarl	%eax
    6582:      	andl	$-0x8, %eax
    6585:      	cltq
    6587:      	movq	%rax, 0x78(%rsp)
    658c:      	movq	(%rip), %rax            # 0x6593 <perf_unwind_native+0x6593>
    6593:      	cmpl	$0x0, (%rax)
    6596:      	jne	0x6b9d <perf_unwind_native+0x6b9d>
    659c:      	andl	$0xf, %ebp
    659f:      	xorl	%r13d, %r13d
    65a2:      	cmpl	$0xa, %ebp
    65a5:      	jg	0x6bf0 <perf_unwind_native+0x6bf0>
    65ab:      	movq	0x138(%rsp), %rax
    65b3:      	testl	%ebp, %ebp
    65b5:      	je	0x6c0a <perf_unwind_native+0x6c0a>
    65bb:      	cmpl	$0x9, %ebp
    65be:      	jne	0x6c12 <perf_unwind_native+0x6c12>
    65c4:      	movq	0x148(%rsp), %rax
    65cc:      	jmp	0x6c0a <perf_unwind_native+0x6c0a>
    65d1:      	movq	(%r15), %rax
    65d4:      	addq	$0x28, %rax
    65d8:      	leaq	0xa0(%rsp), %rdi
    65e0:      	movl	$0x90, %ecx
    65e5:      	movl	$0x70, %r8d
    65eb:      	movq	(%r15), %rdx
    65ee:      	addq	$0x28, %rdx
    65f2:      	movl	$0x90, %esi
    65f7:      	callq	*%r8
    65fa:      	testq	%rax, %rax
    65fd:      	movq	0x68(%rsp), %rbp
    6602:      	jne	0x163b <perf_unwind_native+0x163b>
    6608:      	movq	0x108(%rsp), %rax
    6610:      	movq	%rax, 0xee8(%rbx)
    6617:      	movq	0xa8(%rsp), %rax
    661f:      	movq	%rax, 0xef0(%rbx)
    6626:      	movq	0xb8(%rsp), %rax
    662e:      	movq	%rax, 0xef8(%rbx)
    6635:      	movq	0xc8(%rsp), %rax
    663d:      	movq	%rax, 0xf00(%rbx)
    6644:      	movq	0xd8(%rsp), %rax
    664c:      	movq	%rax, 0xf08(%rbx)
    6653:      	movq	0xf0(%rsp), %rax
    665b:      	movq	%rax, 0xee0(%rbx)
    6662:      	movq	0x118(%rsp), %rax
    666a:      	movq	%rax, 0xed8(%rbx)
    6671:      	movq	0x120(%rsp), %rax
    6679:      	movq	%rax, 0xed0(%rbx)
    6680:      	movb	$0x0, 0xf30(%rbx)
    6687:      	movq	(%rip), %rax            # 0x668e <perf_unwind_native+0x668e>
    668e:      	cmpl	$0x0, (%rax)
    6691:      	je	0x6efa <perf_unwind_native+0x6efa>
    6697:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    66a1:      	movq	%rax, 0x16(%rsp)
    66a6:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
    66b0:      	movq	%rax, 0x10(%rsp)
    66b5:      	leaq	0x10(%rsp), %rdi
    66ba:      	movl	$0xe, %eax
    66bf:      	movl	$0x6, %ecx
    66c4:      	movl	$0xe, %esi
    66c9:      	xorl	%eax, %eax
    66cb:      	callq	*%rcx
    66cd:      	jmp	0x6efa <perf_unwind_native+0x6efa>
    66d2:      	movq	0x60(%rsp), %rsi
    66d7:      	movq	(%rsi), %r13
    66da:      	movq	%r13, %rdx
    66dd:      	movslq	%ecx, %r13
    66e0:      	addq	%rdx, %r13
    66e3:      	testb	%al, %al
    66e5:      	jns	0x6c12 <perf_unwind_native+0x6c12>
    66eb:      	leaq	0x78(%rsp), %rdi
    66f0:      	movl	$0x8, %eax
    66f5:      	movl	$0x70, %ecx
    66fa:      	movl	$0x8, %esi
    66ff:      	movq	%r13, %rdx
    6702:      	callq	*%rcx
    6704:      	testq	%rax, %rax
    6707:      	je	0x6721 <perf_unwind_native+0x6721>
    6709:      	movq	(%rip), %rax            # 0x6710 <perf_unwind_native+0x6710>
    6710:      	cmpl	$0x0, (%rax)
    6713:      	jne	0x6d7d <perf_unwind_native+0x6d7d>
    6719:      	xorl	%r13d, %r13d
    671c:      	jmp	0x6c12 <perf_unwind_native+0x6c12>
    6721:      	shll	$0x3, %ebp
    6724:      	andl	$0x38, %ebp
    6727:      	addq	0x78(%rsp), %rbp
    672c:      	movq	%rbp, %r13
    672f:      	jmp	0x6c12 <perf_unwind_native+0x6c12>
    6734:      	movl	0x2c0(%rbx), %edx
    673a:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
    6744:      	movq	%rax, 0xb0(%rsp)
    674c:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
    6756:      	movq	%rax, 0xa8(%rsp)
    675e:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
    6768:      	movq	%rax, 0xa0(%rsp)
    6770:      	movl	$0xa3d3d, 0xb8(%rsp)    # imm = 0xA3D3D
    677b:      	leaq	0xa0(%rsp), %rdi
    6783:      	movl	$0x1c, %eax
    6788:      	movl	$0x6, %ecx
    678d:      	movl	$0x1c, %esi
    6792:      	xorl	%eax, %eax
    6794:      	callq	*%rcx
    6796:      	jmp	0x54e4 <perf_unwind_native+0x54e4>
    679b:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
    67a5:      	movq	%rax, 0x28(%rsp)
    67aa:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
    67b4:      	movq	%rax, 0x20(%rsp)
    67b9:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
    67c3:      	movq	%rax, 0x18(%rsp)
    67c8:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
    67d2:      	movq	%rax, 0x10(%rsp)
    67d7:      	movb	$0x0, 0x30(%rsp)
    67dc:      	leaq	0x10(%rsp), %rdi
    67e1:      	movl	$0x21, %eax
    67e6:      	movl	$0x6, %r8d
    67ec:      	movq	0xf10(%rbx), %rdx
    67f3:      	movq	0xf18(%rbx), %rcx
    67fa:      	movl	$0x21, %esi
    67ff:      	xorl	%eax, %eax
    6801:      	callq	*%r8
    6804:      	jmp	0x5676 <perf_unwind_native+0x5676>
    6809:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6813:      	movq	%rax, 0xc6(%rsp)
    681b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6825:      	movq	%rax, 0xc0(%rsp)
    682d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6837:      	movq	%rax, 0xb8(%rsp)
    683f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6849:      	movq	%rax, 0xb0(%rsp)
    6851:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    685b:      	movq	%rax, 0xa8(%rsp)
    6863:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    686d:      	movq	%rax, 0xa0(%rsp)
    6875:      	leaq	0xa0(%rsp), %rdi
    687d:      	movl	$0x2e, %eax
    6882:      	movl	$0x6, %ecx
    6887:      	movl	0x10(%rsp), %edx
    688b:      	movl	$0x2e, %esi
    6890:      	xorl	%eax, %eax
    6892:      	callq	*%rcx
    6894:      	movq	(%rip), %rax            # 0x689b <perf_unwind_native+0x689b>
    689b:      	cmpl	$0x0, (%rax)
    689e:      	je	0x55c4 <perf_unwind_native+0x55c4>
    68a4:      	jmp	0x551b <perf_unwind_native+0x551b>
    68a9:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
    68b3:      	movq	%rax, 0x38(%rsp)
    68b8:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
    68c2:      	movq	%rax, 0x30(%rsp)
    68c7:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
    68d1:      	movq	%rax, 0x28(%rsp)
    68d6:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
    68e0:      	movq	%rax, 0x20(%rsp)
    68e5:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
    68ef:      	movq	%rax, 0x18(%rsp)
    68f4:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
    68fe:      	movq	%rax, 0x10(%rsp)
    6903:      	leaq	0x10(%rsp), %rdi
    6908:      	movl	$0x30, %eax
    690d:      	movl	$0x6, %r9d
    6913:      	movl	%r12d, %ecx
    6916:      	movzwl	(%rbp), %r8d
    691b:      	movl	$0x30, %esi
    6920:      	movq	%r13, %rdx
    6923:      	xorl	%eax, %eax
    6925:      	callq	*%r9
    6928:      	jmp	0x59ce <perf_unwind_native+0x59ce>
    692d:      	movabsq	$0xa6425206f666e, %rax  # imm = 0xA6425206F666E
    6937:      	movq	%rax, 0x35(%rsp)
    693c:      	movabsq	$0x6f666e49646e6977, %rax # imm = 0x6F666E49646E6977
    6946:      	movq	%rax, 0x30(%rsp)
    694b:      	movabsq	$0x6e75202c78257830, %rax # imm = 0x6E75202C78257830
    6955:      	movq	%rax, 0x28(%rsp)
    695a:      	movabsq	$0x20776f4c72646461, %rax # imm = 0x20776F4C72646461
    6964:      	movq	%rax, 0x20(%rsp)
    6969:      	movabsq	$0x202c642520786564, %rax # imm = 0x202C642520786564
    6973:      	movq	%rax, 0x18(%rsp)
    6978:      	movabsq	$0x6e692061746c6564, %rax # imm = 0x6E692061746C6564
    6982:      	movq	%rax, 0x10(%rsp)
    6987:      	leaq	0x10(%rsp), %rdi
    698c:      	movl	$0x2d, %eax
    6991:      	movl	$0x6, %r9d
    6997:      	movl	0x90(%rsp), %edx
    699e:      	movzwl	(%rbp), %ecx
    69a2:      	movzwl	0x2(%rbp), %r8d
    69a7:      	movl	$0x2d, %esi
    69ac:      	xorl	%eax, %eax
    69ae:      	callq	*%r9
    69b1:      	jmp	0x5f1e <perf_unwind_native+0x5f1e>
    69b6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    69c0:      	movq	%rax, 0xc6(%rsp)
    69c8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    69d2:      	movq	%rax, 0xc0(%rsp)
    69da:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    69e4:      	movq	%rax, 0xb8(%rsp)
    69ec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    69f6:      	movq	%rax, 0xb0(%rsp)
    69fe:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6a08:      	movq	%rax, 0xa8(%rsp)
    6a10:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6a1a:      	movq	%rax, 0xa0(%rsp)
    6a22:      	leaq	0xa0(%rsp), %rdi
    6a2a:      	movl	$0x2e, %eax
    6a2f:      	movl	$0x6, %ecx
    6a34:      	movl	0x78(%rsp), %edx
    6a38:      	movl	$0x2e, %esi
    6a3d:      	xorl	%eax, %eax
    6a3f:      	callq	*%rcx
    6a41:      	jmp	0x54c5 <perf_unwind_native+0x54c5>
    6a46:      	movabsq	$0xa78323023252061, %rax # imm = 0xA78323023252061
    6a50:      	movq	%rax, 0x28(%rsp)
    6a55:      	movabsq	$0x746c656420646567, %rax # imm = 0x746C656420646567
    6a5f:      	movq	%rax, 0x20(%rsp)
    6a64:      	movabsq	$0x72656d202c642520, %rax # imm = 0x72656D202C642520
    6a6e:      	movq	%rax, 0x18(%rsp)
    6a73:      	movabsq	$0x6666694472646441, %rax # imm = 0x6666694472646441
    6a7d:      	movq	%rax, 0x10(%rsp)
    6a82:      	movb	$0x0, 0x30(%rsp)
    6a87:      	leaq	0x10(%rsp), %rdi
    6a8c:      	movl	$0x21, %eax
    6a91:      	movl	$0x6, %r8d
    6a97:      	movq	0x70(%rsp), %r12
    6a9c:      	movzbl	0x2(%r12), %ecx
    6aa2:      	movl	$0x21, %esi
    6aa7:      	movl	%r13d, %edx
    6aaa:      	xorl	%eax, %eax
    6aac:      	callq	*%r8
    6aaf:      	movzbl	0x2(%r12), %eax
    6ab5:      	jmp	0x632a <perf_unwind_native+0x632a>
    6aba:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6ac4:      	movq	%rax, 0x36(%rsp)
    6ac9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6ad3:      	movq	%rax, 0x30(%rsp)
    6ad8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6ae2:      	movq	%rax, 0x28(%rsp)
    6ae7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6af1:      	movq	%rax, 0x20(%rsp)
    6af6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6b00:      	movq	%rax, 0x18(%rsp)
    6b05:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6b0f:      	movq	%rax, 0x10(%rsp)
    6b14:      	leaq	0x10(%rsp), %rdi
    6b19:      	movl	$0x2e, %eax
    6b1e:      	movl	$0x6, %ecx
    6b23:      	movl	0x94(%rsp), %edx
    6b2a:      	movl	$0x2e, %esi
    6b2f:      	xorl	%eax, %eax
    6b31:      	callq	*%rcx
    6b33:      	jmp	0x62d6 <perf_unwind_native+0x62d6>
    6b38:      	movabsq	$0xa64253d61746c65, %rax # imm = 0xA64253D61746C65
    6b42:      	movq	%rax, 0x28(%rsp)
    6b47:      	movabsq	$0x44616663203a6863, %rax # imm = 0x44616663203A6863
    6b51:      	movq	%rax, 0x20(%rsp)
    6b56:      	movabsq	$0x74616d2061746c65, %rax # imm = 0x74616D2061746C65
    6b60:      	movq	%rax, 0x18(%rsp)
    6b65:      	movabsq	$0x642064656772654d, %rax # imm = 0x642064656772654D
    6b6f:      	movq	%rax, 0x10(%rsp)
    6b74:      	movb	$0x0, 0x30(%rsp)
    6b79:      	leaq	0x10(%rsp), %rdi
    6b7e:      	movl	$0x21, %eax
    6b83:      	movl	$0x6, %ecx
    6b88:      	movl	0x8c(%rsp), %edx
    6b8f:      	movl	$0x21, %esi
    6b94:      	xorl	%eax, %eax
    6b96:      	callq	*%rcx
    6b98:      	jmp	0x6356 <perf_unwind_native+0x6356>
    6b9d:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    6ba7:      	movq	%rax, 0x18(%rsp)
    6bac:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    6bb6:      	movq	%rax, 0x10(%rsp)
    6bbb:      	movb	$0x0, 0x20(%rsp)
    6bc0:      	leaq	0x10(%rsp), %rdi
    6bc5:      	movl	$0x11, %eax
    6bca:      	movl	$0x6, %r8d
    6bd0:      	andl	$0xf, %ebp
    6bd3:      	movq	0x78(%rsp), %rcx
    6bd8:      	movl	$0x11, %esi
    6bdd:      	movl	%ebp, %edx
    6bdf:      	xorl	%eax, %eax
    6be1:      	callq	*%r8
    6be4:      	xorl	%r13d, %r13d
    6be7:      	cmpl	$0xa, %ebp
    6bea:      	jle	0x65ab <perf_unwind_native+0x65ab>
    6bf0:      	movq	0x150(%rsp), %rax
    6bf8:      	cmpl	$0xb, %ebp
    6bfb:      	je	0x6c0a <perf_unwind_native+0x6c0a>
    6bfd:      	movq	0x98(%rsp), %rax
    6c05:      	cmpl	$0xf, %ebp
    6c08:      	jne	0x6c12 <perf_unwind_native+0x6c12>
    6c0a:      	movq	0x78(%rsp), %r13
    6c0f:      	addq	(%rax), %r13
    6c12:      	movq	0x70(%rsp), %rcx
    6c17:      	movzbl	0x1(%rcx), %eax
    6c1b:      	movl	0x8(%rcx), %r12d
    6c1f:      	movl	%r12d, %ecx
    6c22:      	andl	$-0x8, %ecx
    6c25:      	testb	%al, %al
    6c27:      	cmovnsl	%r12d, %ecx
    6c2b:      	movl	%eax, %edx
    6c2d:      	andl	$0x7f, %edx
    6c30:      	cmpl	$0x2, %edx
    6c33:      	jg	0x6c4a <perf_unwind_native+0x6c4a>
    6c35:      	movq	%r13, %rsi
    6c38:      	cmpl	$0x1, %edx
    6c3b:      	je	0x6cb5 <perf_unwind_native+0x6cb5>
    6c3d:      	movq	%r15, %rsi
    6c40:      	cmpl	$0x2, %edx
    6c43:      	je	0x6cb2 <perf_unwind_native+0x6cb2>
    6c45:      	jmp	0x6ea2 <perf_unwind_native+0x6ea2>
    6c4a:      	cmpl	$0x3, %edx
    6c4d:      	je	0x6cad <perf_unwind_native+0x6cad>
    6c4f:      	cmpl	$0x5, %edx
    6c52:      	jne	0x6ea2 <perf_unwind_native+0x6ea2>
    6c58:      	movl	%r12d, %eax
    6c5b:      	sarl	%eax
    6c5d:      	andl	$-0x8, %eax
    6c60:      	cltq
    6c62:      	movq	%rax, 0x78(%rsp)
    6c67:      	movq	(%rip), %rax            # 0x6c6e <perf_unwind_native+0x6c6e>
    6c6e:      	cmpl	$0x0, (%rax)
    6c71:      	jne	0x6df3 <perf_unwind_native+0x6df3>
    6c77:      	andl	$0xf, %r12d
    6c7b:      	cmpl	$0xa, %r12d
    6c7f:      	jg	0x6e46 <perf_unwind_native+0x6e46>
    6c85:      	testl	%r12d, %r12d
    6c88:      	je	0x6e72 <perf_unwind_native+0x6e72>
    6c8e:      	cmpl	$0x9, %r12d
    6c92:      	jne	0x6ea2 <perf_unwind_native+0x6ea2>
    6c98:      	movq	0x148(%rsp), %rax
    6ca0:      	movq	%rax, 0x138(%rsp)
    6ca8:      	jmp	0x6e72 <perf_unwind_native+0x6e72>
    6cad:      	movq	0x60(%rsp), %rsi
    6cb2:      	movq	(%rsi), %rsi
    6cb5:      	movslq	%ecx, %rbp
    6cb8:      	addq	%rsi, %rbp
    6cbb:      	testb	%al, %al
    6cbd:      	jns	0x6e82 <perf_unwind_native+0x6e82>
    6cc3:      	leaq	0x78(%rsp), %rdi
    6cc8:      	movl	$0x8, %eax
    6ccd:      	movl	$0x70, %ecx
    6cd2:      	movl	$0x8, %esi
    6cd7:      	movq	%rbp, %rdx
    6cda:      	callq	*%rcx
    6cdc:      	testq	%rax, %rax
    6cdf:      	je	0x6d68 <perf_unwind_native+0x6d68>
    6ce5:      	movq	(%rip), %rax            # 0x6cec <perf_unwind_native+0x6cec>
    6cec:      	cmpl	$0x0, (%rax)
    6cef:      	je	0x6ea2 <perf_unwind_native+0x6ea2>
    6cf5:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    6cff:      	movq	%rax, 0x30(%rsp)
    6d04:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    6d0e:      	movq	%rax, 0x28(%rsp)
    6d13:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    6d1d:      	movq	%rax, 0x20(%rsp)
    6d22:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    6d2c:      	movq	%rax, 0x18(%rsp)
    6d31:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    6d3b:      	movq	%rax, 0x10(%rsp)
    6d40:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    6d48:      	leaq	0x10(%rsp), %rdi
    6d4d:      	movl	$0x2c, %eax
    6d52:      	movl	$0x6, %ecx
    6d57:      	movl	$0x2c, %esi
    6d5c:      	movq	%rbp, %rdx
    6d5f:      	xorl	%eax, %eax
    6d61:      	callq	*%rcx
    6d63:      	jmp	0x6ea2 <perf_unwind_native+0x6ea2>
    6d68:      	shll	$0x3, %r12d
    6d6c:      	andl	$0x38, %r12d
    6d70:      	addq	0x78(%rsp), %r12
    6d75:      	movq	%r12, %rbp
    6d78:      	jmp	0x6e82 <perf_unwind_native+0x6e82>
    6d7d:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    6d87:      	movq	%rax, 0x30(%rsp)
    6d8c:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    6d96:      	movq	%rax, 0x28(%rsp)
    6d9b:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    6da5:      	movq	%rax, 0x20(%rsp)
    6daa:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    6db4:      	movq	%rax, 0x18(%rsp)
    6db9:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    6dc3:      	movq	%rax, 0x10(%rsp)
    6dc8:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    6dd0:      	leaq	0x10(%rsp), %rdi
    6dd5:      	movl	$0x2c, %eax
    6dda:      	movl	$0x6, %ecx
    6ddf:      	movl	$0x2c, %esi
    6de4:      	movq	%r13, %rdx
    6de7:      	xorl	%eax, %eax
    6de9:      	callq	*%rcx
    6deb:      	xorl	%r13d, %r13d
    6dee:      	jmp	0x6c12 <perf_unwind_native+0x6c12>
    6df3:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    6dfd:      	movq	%rax, 0x18(%rsp)
    6e02:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    6e0c:      	movq	%rax, 0x10(%rsp)
    6e11:      	movb	$0x0, 0x20(%rsp)
    6e16:      	leaq	0x10(%rsp), %rdi
    6e1b:      	movl	$0x11, %eax
    6e20:      	movl	$0x6, %r8d
    6e26:      	andl	$0xf, %r12d
    6e2a:      	movq	0x78(%rsp), %rcx
    6e2f:      	movl	$0x11, %esi
    6e34:      	movl	%r12d, %edx
    6e37:      	xorl	%eax, %eax
    6e39:      	callq	*%r8
    6e3c:      	cmpl	$0xa, %r12d
    6e40:      	jle	0x6c85 <perf_unwind_native+0x6c85>
    6e46:      	movq	0x150(%rsp), %rax
    6e4e:      	movq	%rax, 0x138(%rsp)
    6e56:      	cmpl	$0xb, %r12d
    6e5a:      	je	0x6e72 <perf_unwind_native+0x6e72>
    6e5c:      	movq	0x98(%rsp), %rax
    6e64:      	movq	%rax, 0x138(%rsp)
    6e6c:      	cmpl	$0xf, %r12d
    6e70:      	jne	0x6ea2 <perf_unwind_native+0x6ea2>
    6e72:      	movq	0x78(%rsp), %rbp
    6e77:      	movq	0x138(%rsp), %rax
    6e7f:      	addq	(%rax), %rbp
    6e82:      	testq	%rbp, %rbp
    6e85:      	je	0x6ea2 <perf_unwind_native+0x6ea2>
    6e87:      	movl	$0x8, %eax
    6e8c:      	movl	$0x70, %ecx
    6e91:      	movq	0x60(%rsp), %rdi
    6e96:      	movl	$0x8, %esi
    6e9b:      	movq	%rbp, %rdx
    6e9e:      	callq	*%rcx
    6ea0:      	jmp	0x6eb8 <perf_unwind_native+0x6eb8>
    6ea2:      	movq	0x70(%rsp), %rax
    6ea7:      	cmpb	$0x3, (%rax)
    6eaa:      	jne	0x6eb8 <perf_unwind_native+0x6eb8>
    6eac:      	movq	0x60(%rsp), %rax
    6eb1:      	movq	$0x0, (%rax)
    6eb8:      	testq	%r13, %r13
    6ebb:      	movq	0x68(%rsp), %rbp
    6ec0:      	je	0x163b <perf_unwind_native+0x163b>
    6ec6:      	leaq	-0x8(%r13), %rdx
    6eca:      	movl	$0x8, %eax
    6ecf:      	movl	$0x70, %ecx
    6ed4:      	movq	0x140(%rsp), %rdi
    6edc:      	movl	$0x8, %esi
    6ee1:      	callq	*%rcx
    6ee3:      	testq	%rax, %rax
    6ee6:      	jne	0x163b <perf_unwind_native+0x163b>
    6eec:      	movq	%r13, 0xed8(%rbx)
    6ef3:      	movb	$0x1, 0xf30(%rbx)
    6efa:      	movl	$0x6, 0x78(%rsp)
    6f02:      	movq	(%rip), %rdi            # 0x6f09 <perf_unwind_native+0x6f09>
    6f09:      	leaq	0x78(%rsp), %rsi
    6f0e:      	movl	$0x1, %eax
    6f13:      	callq	*%rax
    6f15:      	testq	%rax, %rax
    6f18:      	je	0x6f30 <perf_unwind_native+0x6f30>
    6f1a:      	incq	(%rax)
    6f1d:      	xorl	%eax, %eax
    6f1f:      	movq	(%rip), %rcx            # 0x6f26 <perf_unwind_native+0x6f26>
    6f26:      	cmpl	$0x0, (%rcx)
    6f29:      	je	0x6f42 <perf_unwind_native+0x6f42>
    6f2b:      	jmp	0x72ff <perf_unwind_native+0x72ff>
    6f30:      	movq	(%rip), %rax            # 0x6f37 <perf_unwind_native+0x6f37>
    6f37:      	cmpl	$0x0, (%rax)
    6f3a:      	jne	0x7277 <perf_unwind_native+0x7277>
    6f40:      	xorl	%eax, %eax
    6f42:      	movq	0x140(%rsp), %rcx
    6f4a:      	movq	(%rcx), %r13
    6f4d:      	testq	%r13, %r13
    6f50:      	je	0x70e9 <perf_unwind_native+0x70e9>
    6f56:      	testl	%eax, %eax
    6f58:      	jne	0x7388 <perf_unwind_native+0x7388>
    6f5e:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    6f68:      	cmpq	%rax, %r13
    6f6b:      	ja	0x33ba <perf_unwind_native+0x33ba>
    6f71:      	cmpq	$0x1000, %r13           # imm = 0x1000
    6f78:      	jb	0x3500 <perf_unwind_native+0x3500>
    6f7e:      	movl	(%rbx), %eax
    6f80:      	movl	$0x60, 0x10(%rsp)
    6f88:      	movbel	%eax, 0x14(%rsp)
    6f8e:      	movbeq	%r13, 0x18(%rsp)
    6f95:      	movq	(%rip), %rdi            # 0x6f9c <perf_unwind_native+0x6f9c>
    6f9c:      	leaq	0x10(%rsp), %rsi
    6fa1:      	movl	$0x1, %eax
    6fa6:      	callq	*%rax
    6fa8:      	testq	%rax, %rax
    6fab:      	je	0x71a5 <perf_unwind_native+0x71a5>
    6fb1:      	movq	0x8(%rax), %r12
    6fb5:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    6fbf:      	andq	%r12, %rcx
    6fc2:      	movq	%rcx, 0xf20(%rbx)
    6fc9:      	movq	(%rax), %rax
    6fcc:      	movq	%rax, 0xf10(%rbx)
    6fd3:      	shrq	$0x38, %r12
    6fd7:      	movq	%r13, %rax
    6fda:      	subq	%rcx, %rax
    6fdd:      	movq	%rax, 0xf18(%rbx)
    6fe4:      	movq	(%rip), %rax            # 0x6feb <perf_unwind_native+0x6feb>
    6feb:      	cmpl	$0x0, (%rax)
    6fee:      	jne	0x743c <perf_unwind_native+0x743c>
    6ff4:      	cmpl	$0x1, %r12d
    6ff8:      	jne	0x762f <perf_unwind_native+0x762f>
    6ffe:      	movq	0xf10(%rbx), %rax
    7005:      	movq	%rax, 0x10(%rsp)
    700a:      	movq	0xf18(%rbx), %r13
    7011:      	movq	(%rip), %rdi            # 0x7018 <perf_unwind_native+0x7018>
    7018:      	leaq	0x10(%rsp), %rsi
    701d:      	movl	$0x1, %eax
    7022:      	callq	*%rax
    7024:      	movl	$0x1, %r12d
    702a:      	testq	%rax, %rax
    702d:      	je	0x762f <perf_unwind_native+0x762f>
    7033:      	movq	%rax, %r15
    7036:      	cmpq	%r13, (%rax)
    7039:      	ja	0x7041 <perf_unwind_native+0x7041>
    703b:      	cmpq	%r13, 0x8(%r15)
    703f:      	jae	0x7055 <perf_unwind_native+0x7055>
    7041:      	cmpq	%r13, 0x10(%r15)
    7045:      	ja	0x762f <perf_unwind_native+0x762f>
    704b:      	cmpq	%r13, 0x18(%r15)
    704f:      	jb	0x762f <perf_unwind_native+0x762f>
    7055:      	movq	(%rip), %rax            # 0x705c <perf_unwind_native+0x705c>
    705c:      	cmpl	$0x0, (%rax)
    705f:      	jne	0x757e <perf_unwind_native+0x757e>
    7065:      	movl	0x1380(%rbx), %eax
    706b:      	movl	0x20(%r15), %ecx
    706f:      	btl	%ecx, %eax
    7072:      	jae	0x75f9 <perf_unwind_native+0x75f9>
    7078:      	movq	(%rip), %rax            # 0x707f <perf_unwind_native+0x707f>
    707f:      	cmpl	$0x0, (%rax)
    7082:      	je	0x762f <perf_unwind_native+0x762f>
    7088:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    7092:      	movq	%rax, 0xb0(%rsp)
    709a:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    70a4:      	movq	%rax, 0xa8(%rsp)
    70ac:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    70b6:      	movq	%rax, 0xa0(%rsp)
    70be:      	movl	$0xa656e, 0xb7(%rsp)    # imm = 0xA656E
    70c9:      	leaq	0xa0(%rsp), %rdi
    70d1:      	movl	$0x1b, %eax
    70d6:      	movl	$0x6, %ecx
    70db:      	movl	$0x1b, %esi
    70e0:      	xorl	%eax, %eax
    70e2:      	callq	*%rcx
    70e4:      	jmp	0x762f <perf_unwind_native+0x762f>
    70e9:      	movq	0x68(%rsp), %rbp
    70ee:      	testl	%eax, %eax
    70f0:      	movq	(%rip), %r13            # 0x70f7 <perf_unwind_native+0x70f7>
    70f7:      	jne	0x7111 <perf_unwind_native+0x7111>
    70f9:      	movl	$0x1, 0xf28(%rbx)
    7103:      	movl	$0xfad, %r14d           # imm = 0xFAD
    7109:      	xorl	%r12d, %r12d
    710c:      	jmp	0x5fd4 <perf_unwind_native+0x5fd4>
    7111:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    711b:      	movq	%rax, 0xc8(%rsp)
    7123:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    712d:      	movq	%rax, 0xc0(%rsp)
    7135:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    713f:      	movq	%rax, 0xb8(%rsp)
    7147:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    7151:      	movq	%rax, 0xb0(%rsp)
    7159:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    7163:      	movq	%rax, 0xa8(%rsp)
    716b:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    7175:      	movq	%rax, 0xa0(%rsp)
    717d:      	movb	$0x0, 0xd0(%rsp)
    7185:      	leaq	0xa0(%rsp), %rdi
    718d:      	movl	$0x31, %eax
    7192:      	movl	$0x6, %ecx
    7197:      	movl	$0x31, %esi
    719c:      	xorl	%eax, %eax
    719e:      	callq	*%rcx
    71a0:      	jmp	0x70f9 <perf_unwind_native+0x70f9>
    71a5:      	movq	0x68(%rsp), %rbp
    71aa:      	movq	(%rip), %rax            # 0x71b1 <perf_unwind_native+0x71b1>
    71b1:      	cmpl	$0x0, (%rax)
    71b4:      	jne	0x71ce <perf_unwind_native+0x71ce>
    71b6:      	movl	$0xc, 0xf28(%rbx)
    71c0:      	movl	$0xfac, %r14d           # imm = 0xFAC
    71c6:      	xorl	%r12d, %r12d
    71c9:      	jmp	0x5fcd <perf_unwind_native+0x5fcd>
    71ce:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    71d8:      	movq	%rax, 0xd0(%rsp)
    71e0:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    71ea:      	movq	%rax, 0xc8(%rsp)
    71f2:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    71fc:      	movq	%rax, 0xc0(%rsp)
    7204:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    720e:      	movq	%rax, 0xb8(%rsp)
    7216:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    7220:      	movq	%rax, 0xb0(%rsp)
    7228:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    7232:      	movq	%rax, 0xa8(%rsp)
    723a:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    7244:      	movq	%rax, 0xa0(%rsp)
    724c:      	movb	$0x0, 0xd8(%rsp)
    7254:      	leaq	0xa0(%rsp), %rdi
    725c:      	movl	$0x39, %eax
    7261:      	movl	$0x6, %ecx
    7266:      	movl	$0x39, %esi
    726b:      	movq	%r13, %rdx
    726e:      	xorl	%eax, %eax
    7270:      	callq	*%rcx
    7272:      	jmp	0x71b6 <perf_unwind_native+0x71b6>
    7277:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7281:      	movq	%rax, 0x36(%rsp)
    7286:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7290:      	movq	%rax, 0x30(%rsp)
    7295:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    729f:      	movq	%rax, 0x28(%rsp)
    72a4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    72ae:      	movq	%rax, 0x20(%rsp)
    72b3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    72bd:      	movq	%rax, 0x18(%rsp)
    72c2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    72cc:      	movq	%rax, 0x10(%rsp)
    72d1:      	leaq	0x10(%rsp), %rdi
    72d6:      	movl	$0x2e, %eax
    72db:      	movl	$0x6, %ecx
    72e0:      	movl	0x78(%rsp), %edx
    72e4:      	movl	$0x2e, %esi
    72e9:      	xorl	%eax, %eax
    72eb:      	callq	*%rcx
    72ed:      	xorl	%eax, %eax
    72ef:      	movq	(%rip), %rcx            # 0x72f6 <perf_unwind_native+0x72f6>
    72f6:      	cmpl	$0x0, (%rcx)
    72f9:      	je	0x6f42 <perf_unwind_native+0x6f42>
    72ff:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    7309:      	movq	%rax, 0xb5(%rsp)
    7311:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    731b:      	movq	%rax, 0xb0(%rsp)
    7323:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    732d:      	movq	%rax, 0xa8(%rsp)
    7335:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    733f:      	movq	%rax, 0xa0(%rsp)
    7347:      	leaq	0xa0(%rsp), %rdi
    734f:      	movl	$0x1d, %eax
    7354:      	movl	$0x6, %r9d
    735a:      	movq	0x140(%rsp), %rax
    7362:      	movq	(%rax), %rdx
    7365:      	movq	(%r15), %rcx
    7368:      	movq	0x60(%rsp), %rax
    736d:      	movq	(%rax), %r8
    7370:      	movl	$0x1d, %esi
    7375:      	xorl	%eax, %eax
    7377:      	callq	*%r9
    737a:      	movq	(%rip), %rax            # 0x7381 <perf_unwind_native+0x7381>
    7381:      	movl	(%rax), %eax
    7383:      	jmp	0x6f42 <perf_unwind_native+0x6f42>
    7388:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    7392:      	movq	%rax, 0xc8(%rsp)
    739a:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    73a4:      	movq	%rax, 0xc0(%rsp)
    73ac:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    73b6:      	movq	%rax, 0xb8(%rsp)
    73be:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    73c8:      	movq	%rax, 0xb0(%rsp)
    73d0:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    73da:      	movq	%rax, 0xa8(%rsp)
    73e2:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    73ec:      	movq	%rax, 0xa0(%rsp)
    73f4:      	movb	$0x0, 0xd0(%rsp)
    73fc:      	leaq	0xa0(%rsp), %rdi
    7404:      	movl	$0x31, %eax
    7409:      	movl	$0x6, %ecx
    740e:      	movl	0x2c0(%rbx), %edx
    7414:      	movl	$0x31, %esi
    7419:      	xorl	%eax, %eax
    741b:      	callq	*%rcx
    741d:      	movq	0xed0(%rbx), %r13
    7424:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    742e:      	cmpq	%rax, %r13
    7431:      	ja	0x33ba <perf_unwind_native+0x33ba>
    7437:      	jmp	0x6f71 <perf_unwind_native+0x6f71>
    743c:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    7446:      	movq	%rax, 0xc8(%rsp)
    744e:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    7458:      	movq	%rax, 0xc0(%rsp)
    7460:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    746a:      	movq	%rax, 0xb8(%rsp)
    7472:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    747c:      	movq	%rax, 0xb0(%rsp)
    7484:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    748e:      	movq	%rax, 0xa8(%rsp)
    7496:      	movabsq	$0x6365732074786554, %r15 # imm = 0x6365732074786554
    74a0:      	movq	%r15, 0xa0(%rsp)
    74a8:      	movw	$0xa, 0xd0(%rsp)
    74b2:      	leaq	0xa0(%rsp), %rdi
    74ba:      	movl	$0x32, %eax
    74bf:      	movl	$0x6, %r9d
    74c5:      	movq	0xf10(%rbx), %rcx
    74cc:      	movl	$0x32, %esi
    74d1:      	movq	%r13, %rdx
    74d4:      	movl	%r12d, %r8d
    74d7:      	xorl	%eax, %eax
    74d9:      	callq	*%r9
    74dc:      	movq	(%rip), %rax            # 0x74e3 <perf_unwind_native+0x74e3>
    74e3:      	cmpl	$0x0, (%rax)
    74e6:      	je	0x6ff4 <perf_unwind_native+0x6ff4>
    74ec:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    74f6:      	movq	%rax, 0xc7(%rsp)
    74fe:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    7508:      	movq	%rax, 0xc0(%rsp)
    7510:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    751a:      	movq	%rax, 0xb8(%rsp)
    7522:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    752c:      	movq	%rax, 0xb0(%rsp)
    7534:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    753e:      	movq	%rax, 0xa8(%rsp)
    7546:      	movq	%r15, 0xa0(%rsp)
    754e:      	leaq	0xa0(%rsp), %rdi
    7556:      	movl	$0x2f, %eax
    755b:      	movl	$0x6, %r8d
    7561:      	movq	0xf18(%rbx), %rcx
    7568:      	movq	0xf20(%rbx), %rdx
    756f:      	movl	$0x2f, %esi
    7574:      	xorl	%eax, %eax
    7576:      	callq	*%r8
    7579:      	jmp	0x6ff4 <perf_unwind_native+0x6ff4>
    757e:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    7588:      	movq	%rax, 0xb6(%rsp)
    7590:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    759a:      	movq	%rax, 0xb0(%rsp)
    75a2:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    75ac:      	movq	%rax, 0xa8(%rsp)
    75b4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    75be:      	movq	%rax, 0xa0(%rsp)
    75c6:      	leaq	0xa0(%rsp), %rdi
    75ce:      	movl	$0x1e, %eax
    75d3:      	movl	$0x6, %ecx
    75d8:      	movzwl	0x20(%r15), %edx
    75dd:      	movl	$0x1e, %esi
    75e2:      	xorl	%eax, %eax
    75e4:      	callq	*%rcx
    75e6:      	movl	0x1380(%rbx), %eax
    75ec:      	movl	0x20(%r15), %ecx
    75f0:      	btl	%ecx, %eax
    75f3:      	jb	0x7078 <perf_unwind_native+0x7078>
    75f9:      	movl	$0x0, 0x78(%rsp)
    7601:      	movq	(%rip), %rdi            # 0x7608 <perf_unwind_native+0x7608>
    7608:      	leaq	0x78(%rsp), %rsi
    760d:      	movl	$0x1, %eax
    7612:      	callq	*%rax
    7614:      	testq	%rax, %rax
    7617:      	je	0x761e <perf_unwind_native+0x761e>
    7619:      	incq	(%rax)
    761c:      	jmp	0x762a <perf_unwind_native+0x762a>
    761e:      	movq	(%rip), %rax            # 0x7625 <perf_unwind_native+0x7625>
    7625:      	cmpl	$0x0, (%rax)
    7628:      	jne	0x7639 <perf_unwind_native+0x7639>
    762a:      	movzwl	0x20(%r15), %r12d
    762f:      	movq	0x68(%rsp), %rbp
    7634:      	jmp	0x5fcd <perf_unwind_native+0x5fcd>
    7639:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7643:      	movq	%rax, 0xc6(%rsp)
    764b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7655:      	movq	%rax, 0xc0(%rsp)
    765d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7667:      	movq	%rax, 0xb8(%rsp)
    766f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7679:      	movq	%rax, 0xb0(%rsp)
    7681:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    768b:      	movq	%rax, 0xa8(%rsp)
    7693:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    769d:      	movq	%rax, 0xa0(%rsp)
    76a5:      	leaq	0xa0(%rsp), %rdi
    76ad:      	movl	$0x2e, %eax
    76b2:      	movl	$0x6, %ecx
    76b7:      	movl	0x78(%rsp), %edx
    76bb:      	movl	$0x2e, %esi
    76c0:      	xorl	%eax, %eax
    76c2:      	callq	*%rcx
    76c4:      	jmp	0x762a <perf_unwind_native+0x762a>
