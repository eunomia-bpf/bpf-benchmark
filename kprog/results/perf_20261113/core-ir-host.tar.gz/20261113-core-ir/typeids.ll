; ModuleID = 'kprog/perf/native-context/test-core-ir-ids.c'
source_filename = "kprog/perf/native-context/test-core-ir-ids.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

@"llvm.btf_type_id.0$6" = external global i64, !llvm.preserve.access.index !0 #0
@"llvm.btf_type_id.1$7" = external global i64, !llvm.preserve.access.index !0 #0

; Function Attrs: nofree nosync nounwind memory(read, argmem: none, inaccessiblemem: none)
define dso_local i32 @core_local_id() local_unnamed_addr #1 section "test" !dbg !11 {
  %1 = load i64, ptr @"llvm.btf_type_id.0$6", align 8
  %2 = tail call i64 @llvm.bpf.passthrough.i64.i64(i32 0, i64 %1)
  %3 = trunc i64 %2 to i32, !dbg !15
  ret i32 %3, !dbg !16
}

; Function Attrs: nofree nosync nounwind memory(read, argmem: none, inaccessiblemem: none)
define dso_local i32 @core_target_id() local_unnamed_addr #1 section "test" !dbg !17 {
  %1 = load i64, ptr @"llvm.btf_type_id.1$7", align 8
  %2 = tail call i64 @llvm.bpf.passthrough.i64.i64(i32 1, i64 %1)
  %3 = trunc i64 %2 to i32, !dbg !18
  ret i32 %3, !dbg !19
}

; Function Attrs: nofree nosync nounwind memory(none)
declare i64 @llvm.bpf.passthrough.i64.i64(i32, i64) #2

attributes #0 = { "btf_type_id" }
attributes #1 = { nofree nosync nounwind memory(read, argmem: none, inaccessiblemem: none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #2 = { nofree nosync nounwind memory(none) }

!llvm.dbg.cu = !{!5}
!llvm.module.flags = !{!6, !7, !8, !9}
!llvm.ident = !{!10}

!0 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "task_struct___core_ids", file: !1, line: 19, size: 32, elements: !2)
!1 = !DIFile(filename: "kprog/perf/native-context/test-core-ir-ids.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "e7f8b36b1775412215f9624bdaf21815")
!2 = !{!3}
!3 = !DIDerivedType(tag: DW_TAG_member, name: "pid", scope: !0, file: !1, line: 19, baseType: !4, size: 32)
!4 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!5 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!6 = !{i32 7, !"Dwarf Version", i32 5}
!7 = !{i32 2, !"Debug Info Version", i32 3}
!8 = !{i32 1, !"wchar_size", i32 4}
!9 = !{i32 7, !"frame-pointer", i32 2}
!10 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!11 = distinct !DISubprogram(name: "core_local_id", scope: !1, file: !1, line: 20, type: !12, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !5)
!12 = !DISubroutineType(types: !13)
!13 = !{!14}
!14 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!15 = !DILocation(line: 21, column: 12, scope: !11)
!16 = !DILocation(line: 21, column: 5, scope: !11)
!17 = distinct !DISubprogram(name: "core_target_id", scope: !1, file: !1, line: 23, type: !12, scopeLine: 23, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !5)
!18 = !DILocation(line: 24, column: 12, scope: !17)
!19 = !DILocation(line: 24, column: 5, scope: !17)
