/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: bpfbench-cepb
 * Container Interface: eth0
 * IPv4 address: 10.244.0.6
 * Identity: 15281
 * PolicyMap: cilium_policy_v2_00883
 * NodeMAC: 4e:c0:10:40:1a:70
 */

/*
 * Labels:
 * - container:app=bpfbench-cilium
 * - container:instance=b
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#undef MONITOR_AGGREGATION
#define POLICY_AUDIT_MODE 1
#define POLICY_VERDICT_NOTIFY 1
#undef ENABLE_SIP_VERIFICATION
#define TRACE_NOTIFY 1
