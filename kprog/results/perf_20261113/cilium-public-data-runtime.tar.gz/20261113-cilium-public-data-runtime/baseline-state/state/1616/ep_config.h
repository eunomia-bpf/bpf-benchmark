/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: bpfbench-cepa
 * Container Interface: eth0
 * IPv4 address: 10.244.0.216
 * Identity: 31584
 * PolicyMap: cilium_policy_v2_01616
 * NodeMAC: 46:a1:b6:f8:da:97
 */

/*
 * Labels:
 * - container:instance=a
 * - container:app=bpfbench-cilium
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#undef MONITOR_AGGREGATION
#define POLICY_AUDIT_MODE 1
#define POLICY_VERDICT_NOTIFY 1
#undef ENABLE_SIP_VERIFICATION
#define TRACE_NOTIFY 1
