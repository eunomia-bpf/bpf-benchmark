/var/tmp/kprog-tmp/perf/native-frame-event/bpf_execve_event_v61.bc: \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_execve_event.c \
  include/vmlinux.h include/vmlinux_generated_x86.h include/api.h \
  include/bpf_elf.h include/compiler.h lib/bpf_event.h lib/bpf_helpers.h \
  libbpf/bpf_core_read.h lib/bpf_task.h lib/generic.h lib/common.h \
  lib/msg_types.h lib/process.h lib/bpf_cred.h lib/bpf_d_path.h \
  lib/config.h lib/../process/string_maps.h lib/policy_stats.h \
  lib/policy_conf.h lib/errmetrics.h lib/err.h include/errno.h \
  errmetrics/get_fileid.h errmetrics/fileids.h lib/environ_conf.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_process_event.h \
  lib/bpf_cgroup.h libbpf/bpf_tracing.h include/bpf_ktime.h \
  cgroup/cgtracker.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_rate.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/bpf_mbset.h \
  /workspaces/repository/vendor/repos/tetragon/bpf/process/data_event.h \
  lib/data_msg.h
