from pathlib import Path
import tarfile,io,json,hashlib
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
r=Path(__file__).resolve().parent;old=Path('/workspaces/kprog-raw/perf/20261114-otel-combined-codegen/checked/control/state/session-sbpz0fqm/requests');new=next((r/'checked-kernel/control/state').glob('session-*/requests'));out=[]
def code(data):
 e=ELFFile(io.BytesIO(data));sections={s.name:hashlib.sha256(s.data()).hexdigest() for s in e.iter_sections() if s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS'};rel=[]
 for s in e.iter_sections():
  if not isinstance(s,RelocationSection) or not e.get_section(s['sh_info'])['sh_flags']&2:continue
  symbols=e.get_section(s['sh_link'])
  rel +=[(e.get_section(s['sh_info']).name,v['r_offset'],v['r_info_type'],symbols.get_symbol(v['r_info_sym']).name,v.entry.get('r_addend')) for v in s.iter_relocations()]
 return sections,sorted(rel)
for n in (1,2):
 a=old/f'{n}.success.tar.gz';b=new/f'{n}.success.tar.gz'
 with tarfile.open(a) as x,tarfile.open(b) as y:
  verify=json.load(y.extractfile('request/checked-simulator-verification.json'));assert verify['status']==0
  d=dict(request=n,actual_new_stock_verify_status=verify['status'])
  for name in ('trusted_x86.bpf.o','checked-simulator.native.o'):
   ca,cb=code(x.extractfile('request/generated/'+name).read()),code(y.extractfile('request/generated/'+name).read());d[name]=dict(allocated_bytes_equal=ca[0]==cb[0],allocated_relocations_equal=ca[1]==cb[1])
  for ent in y:
   if ent.name.endswith('spill-layout.json'):
    layout=json.load(y.extractfile(ent));d['packed_scalar_slots']=layout['changed_scalar_slots']
  out.append(d)
(r/'installed-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
