#!/bin/bash
set -euo pipefail
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-static-helper-dispatch/checked-kernel
exec > "$r/job.log" 2>&1
exec 9>>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
date -u +%FT%TZ > "$r/started"
mkdir -p "$r/control" "$r/var-tmp"
set +e
taskset -c 16-17 prlimit --as=85899345920 -- vng --run /workspaces/.agent-state/kprog-ck/build-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/kprog-raw --overlay-rwdir /tmp --overlay-rwdir /run --overlay-rwdir /usr/local --rwdir /var/tmp="$r/var-tmp" --disable-monitor --cpus 2 --memory 48G --append 'loglevel=4 panic=30 oops=panic' --exec 'bash /workspaces/kprog-raw/perf/20261114-static-helper-dispatch/checked-kernel/guest.sh'
status=$?
echo "$status" > "$r/exit-code";date -u +%FT%TZ > "$r/finished";exit "$status"
