from pathlib import Path
import sys,json,re,hashlib
sys.path[:0]=['kprog','kprog/x86/micro-prog']
import generate_micro_sim_proofs as g
from trusted_generation import context_kind
r=Path(__file__).resolve().parent;old=Path('/workspaces/kprog-raw/perf/20261114-mul-u64/cilium-replay');results=[]
for p in sorted(old.glob('*/rendered.c')):
 d=p.parent;ins,funcs,end,rodata=g.parse_native_linked_program('trusted_x86',d);m=json.load(open(d/'metadata.json'));text=g.render_program('trusted_x86',ins,funcs,kind=context_kind(m['prog_type']),exit_addr=end,rodata16=rodata,program_section=m['section'],trusted_map_bindings=[dict(native_symbol=v['name'],value_offset=v.get('value_offset')) for v in m['maps']],kernel_functions=json.load(open(d/'kernel-functions.json')))
 expected,n=re.subn(r'X86_SIM_BPF_CALL_ID\(X86_SIM_HELPER_([A-Za-z0-9_]+)\);',lambda v:g.STATIC_HELPER_CALLS.get(v[1],v[0][:-1])+';',p.read_text())
 assert text==expected,d
 out=r/d.name;out.mkdir(exist_ok=True);(out/'rendered.c').write_text(text)
 results.append(dict(request=int(d.name),literal_calls=n,only_selected_helper_spelling_changed=True,source_sha256=hashlib.sha256(text.encode()).hexdigest()))
(r/'render-results.json').write_text(json.dumps(results,indent=2)+'\n');print('all actual Cilium renders exact:',len(results),'literal calls',sum(x['literal_calls'] for x in results),flush=True)
