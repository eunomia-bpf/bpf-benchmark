#!/bin/bash
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-static-helper-dispatch
date -u +%FT%TZ > "$r/host-started"
taskset -c 16-17 make -C kprog/libnativeloader checked-sim-check CHECKED_SIM_BUILD=/workspaces/kprog-raw/perf/20261114-mul-u64/host-build CHECKED_SIM_OUTPUT="$r/host-check" FRAME_LINKER=/workspaces/repository/corpus/results/perf-combined-codegen-compatible-20261114/native-link.real > "$r/host-check.log" 2>&1
echo $? > "$r/host-exit"
date -u +%FT%TZ > "$r/host-finished"
