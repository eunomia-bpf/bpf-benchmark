/*
 * This file is not using during compilation of endpoint programs.
 * Container ID: bpfbench-cepb
 * Container Interface: eth0
 * IPv4 address: 10.244.0.83
 * Identity: 63780
 * PolicyMap: cilium_policy_v2_01367
 * NodeMAC: 7a:3a:9f:33:bb:05
 */

/*
 * Labels:
 * - container:instance=b
 * - container:app=bpfbench-cilium
 */

#include "lib/utils.h"

#define ENABLE_ROUTING 1
#define LOCAL_DELIVERY_METRICS 1
#undef DEBUG
#undef POLICY_DEBUG
#define DROP_NOTIFY 1
#undef MONITOR_AGGREGATION
#define POLICY_AUDIT_MODE 1
#define POLICY_VERDICT_NOTIFY 1
#undef ENABLE_SIP_VERIFICATION
#define TRACE_NOTIFY 1
