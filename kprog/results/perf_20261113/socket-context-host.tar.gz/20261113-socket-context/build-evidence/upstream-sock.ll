; ModuleID = '/var/tmp/kprog-tmp/perf/socket-context/upstream-sock.bc'
source_filename = "/workspaces/repository/vendor/repos/cilium/bpf/bpf_sock.c"
target datalayout = "e-m:e-p:64:64-i64:64-i128:128-n32:64-S128"
target triple = "bpf"

%union.macaddr = type { i64 }
%union.v4addr = type { i32 }
%union.v6addr = type { %struct.anon.0 }
%struct.anon.0 = type { i64, i64 }
%struct.anon.1 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.2 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.3 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.4 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.5 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.6 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.7 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.8 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.9 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.10 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.11 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.12 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.13 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.14 = type { ptr, ptr, ptr, ptr, ptr, ptr, [0 x ptr] }
%struct.anon.15 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.16 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.17 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.18 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.19 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.20 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.21 = type { ptr, ptr, ptr, ptr, ptr, ptr, [0 x ptr] }
%struct.anon.22 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.23 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.24 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.25 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.26 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.27 = type { ptr, ptr, ptr, ptr, ptr, ptr }
%struct.anon.28 = type { ptr, ptr, ptr, ptr }
%struct.lb4_affinity_key = type { %union.lb4_affinity_client_id, i16, i8, i8, i32 }
%union.lb4_affinity_client_id = type { i64 }
%struct.lb_affinity_val = type { i64, i32, i32 }
%struct.lb_affinity_match = type { i32, i16, i16 }
%struct.ipcache_key = type { %struct.bpf_lpm_trie_key, i16, i8, i8, %union.anon.31 }
%struct.bpf_lpm_trie_key = type { i32, [0 x i8] }
%union.anon.31 = type { %union.v6addr }
%struct.ipv4_revnat_entry = type { i32, i16, i16 }
%struct.ipv4_revnat_tuple = type { i64, i32, i16, i16 }
%struct.skip_lb4_key = type { i64, i32, i16, i16 }
%struct.metrics_value = type { i64, i64 }
%struct.metrics_key = type { i8, i8, i16, i8, [3 x i8] }
%struct.lb4_key = type { i32, i16, i16, i8, i8, [2 x i8] }
%struct.bpf_sock_addr = type { i32, i32, [4 x i32], i32, i32, i32, i32, i32, [4 x i32], %union.anon.29 }
%union.anon.29 = type { ptr }
%struct.lb4_service = type { %union.anon.30, i16, i16, i8, i8, i16 }
%union.anon.30 = type { i32 }
%struct.lb4_backend = type { i32, i16, i8, i8, i16, i8, i8 }
%struct.bpf_sock = type { i32, i32, i32, i32, i32, i32, i32, [4 x i32], i32, i16, i16, i32, [4 x i32], i32, i32 }

@__config_cluster_id_bits = dso_local constant i32 8, section ".rodata.config", align 4, !dbg !0
@____license = dso_local global [13 x i8] c"Dual BSD/GPL\00", section "license", align 1, !dbg !109
@__config_cilium_net_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !114
@__config_cilium_net_mac = dso_local constant %union.macaddr zeroinitializer, section ".rodata.config", align 8, !dbg !120
@__config_cilium_host_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !134
@__config_cilium_host_mac = dso_local constant %union.macaddr zeroinitializer, section ".rodata.config", align 8, !dbg !138
@__config_service_loopback_ipv4 = dso_local constant %union.v4addr zeroinitializer, section ".rodata.config", align 4, !dbg !142
@__config_service_loopback_ipv6 = dso_local constant %union.v6addr zeroinitializer, section ".rodata.config", align 1, !dbg !156
@__config_router_ipv6 = dso_local constant %union.v6addr zeroinitializer, section ".rodata.config", align 1, !dbg !181
@__config_trace_payload_len = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !185
@__config_trace_payload_len_overlay = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !189
@__config_direct_routing_dev_ifindex = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !193
@__config_supports_fib_lookup_skip_neigh = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !197
@__config_supports_fib_lookup_src = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !201
@__config_enable_nodeport_source_lookup = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !205
@__config_tracing_ip_option_type = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !209
@__config_policy_deny_response_enabled = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !215
@__config_cluster_id = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !219
@__config_enable_conntrack_accounting = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !223
@__config_debug_lb = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !227
@__config_nodeport_port_min = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !231
@__config_nodeport_port_max = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !237
@__config_hash_init4_seed = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !241
@__config_hash_init6_seed = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !245
@__config_nat_46x64_prefix = dso_local constant %union.v4addr zeroinitializer, section ".rodata.config", align 4, !dbg !249
@__config_enable_tproxy = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !253
@__config_events_map_rate_limit = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !257
@__config_events_map_burst_limit = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !261
@__config_enable_endpoint_routes = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !265
@__config_enable_identity_mark = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !269
@__config_enable_no_service_endpoints_routable = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !273
@__config_tunnel_protocol = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !279
@__config_tunnel_port = dso_local constant i16 0, section ".rodata.config", align 2, !dbg !284
@__config_enable_jiffies = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !288
@__config_kernel_hz = dso_local constant i32 0, section ".rodata.config", align 4, !dbg !293
@cilium_metrics = dso_local global %struct.anon.1 zeroinitializer, section ".maps", align 8, !dbg !297
@cilium_ipv4_frag_datagrams = dso_local global %struct.anon.2 zeroinitializer, section ".maps", align 8, !dbg !338
@__config_enable_ipv4_fragments = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !374
@cilium_ipv6_frag_datagrams = dso_local global %struct.anon.3 zeroinitializer, section ".maps", align 8, !dbg !378
@__config_enable_ipv6_fragments = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !402
@__config_enable_extended_ip_protocols = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !406
@cilium_lxc = dso_local global %struct.anon.4 zeroinitializer, section ".maps", align 8, !dbg !411
@cilium_ipcache_v2 = dso_local global %struct.anon.5 zeroinitializer, section ".maps", align 8, !dbg !454
@cilium_ratelimit = dso_local global %struct.anon.6 zeroinitializer, section ".maps", align 8, !dbg !504
@cilium_ratelimit_metrics = dso_local global %struct.anon.7 zeroinitializer, section ".maps", align 8, !dbg !535
@cilium_lb6_reverse_nat = dso_local global %struct.anon.8 zeroinitializer, section ".maps", align 8, !dbg !557
@cilium_lb6_services_v2 = dso_local global %struct.anon.9 zeroinitializer, section ".maps", align 8, !dbg !572
@cilium_lb6_backends_v3 = dso_local global %struct.anon.10 zeroinitializer, section ".maps", align 8, !dbg !606
@cilium_lb6_affinity = dso_local global %struct.anon.11 zeroinitializer, section ".maps", align 8, !dbg !626
@cilium_lb6_source_range = dso_local global %struct.anon.12 zeroinitializer, section ".maps", align 8, !dbg !656
@cilium_lb6_health = dso_local global %struct.anon.13 zeroinitializer, section ".maps", align 8, !dbg !677
@cilium_lb6_maglev = dso_local global %struct.anon.14 zeroinitializer, section ".maps", align 8, !dbg !693
@cilium_lb4_reverse_nat = dso_local global %struct.anon.15 zeroinitializer, section ".maps", align 8, !dbg !724
@cilium_lb4_services_v2 = dso_local global %struct.anon.16 zeroinitializer, section ".maps", align 8, !dbg !739
@cilium_lb4_backends_v3 = dso_local global %struct.anon.17 zeroinitializer, section ".maps", align 8, !dbg !772
@cilium_lb4_affinity = dso_local global %struct.anon.18 zeroinitializer, section ".maps", align 8, !dbg !792
@cilium_lb4_source_range = dso_local global %struct.anon.19 zeroinitializer, section ".maps", align 8, !dbg !815
@cilium_lb4_health = dso_local global %struct.anon.20 zeroinitializer, section ".maps", align 8, !dbg !832
@cilium_lb4_maglev = dso_local global %struct.anon.21 zeroinitializer, section ".maps", align 8, !dbg !846
@cilium_lb_affinity_match = dso_local global %struct.anon.22 zeroinitializer, section ".maps", align 8, !dbg !865
@cilium_lb_act = dso_local global %struct.anon.23 zeroinitializer, section ".maps", align 8, !dbg !881
@cilium_skip_lb6 = dso_local global %struct.anon.24 zeroinitializer, section ".maps", align 8, !dbg !903
@cilium_skip_lb4 = dso_local global %struct.anon.25 zeroinitializer, section ".maps", align 8, !dbg !926
@__config_enable_lrp = dso_local constant i8 0, section ".rodata.config", align 1, !dbg !943
@cilium_lb4_reverse_sk = dso_local global %struct.anon.26 zeroinitializer, section ".maps", align 8, !dbg !947
@cilium_lb6_reverse_sk = dso_local global %struct.anon.27 zeroinitializer, section ".maps", align 8, !dbg !975
@cilium_events = dso_local global %struct.anon.28 zeroinitializer, section ".maps", align 8, !dbg !998
@llvm.compiler.used = appending global [74 x ptr] [ptr @____license, ptr @__config_cilium_host_ifindex, ptr @__config_cilium_host_mac, ptr @__config_cilium_net_ifindex, ptr @__config_cilium_net_mac, ptr @__config_cluster_id, ptr @__config_cluster_id_bits, ptr @__config_debug_lb, ptr @__config_direct_routing_dev_ifindex, ptr @__config_enable_conntrack_accounting, ptr @__config_enable_endpoint_routes, ptr @__config_enable_extended_ip_protocols, ptr @__config_enable_identity_mark, ptr @__config_enable_ipv4_fragments, ptr @__config_enable_ipv6_fragments, ptr @__config_enable_jiffies, ptr @__config_enable_lrp, ptr @__config_enable_no_service_endpoints_routable, ptr @__config_enable_nodeport_source_lookup, ptr @__config_enable_tproxy, ptr @__config_events_map_burst_limit, ptr @__config_events_map_rate_limit, ptr @__config_hash_init4_seed, ptr @__config_hash_init6_seed, ptr @__config_kernel_hz, ptr @__config_nat_46x64_prefix, ptr @__config_nodeport_port_max, ptr @__config_nodeport_port_min, ptr @__config_policy_deny_response_enabled, ptr @__config_router_ipv6, ptr @__config_service_loopback_ipv4, ptr @__config_service_loopback_ipv6, ptr @__config_supports_fib_lookup_skip_neigh, ptr @__config_supports_fib_lookup_src, ptr @__config_trace_payload_len, ptr @__config_trace_payload_len_overlay, ptr @__config_tracing_ip_option_type, ptr @__config_tunnel_port, ptr @__config_tunnel_protocol, ptr @cil_sock4_connect, ptr @cil_sock4_recvmsg, ptr @cil_sock4_sendmsg, ptr @cil_sock6_connect, ptr @cil_sock6_recvmsg, ptr @cil_sock6_sendmsg, ptr @cil_sock_release, ptr @cilium_events, ptr @cilium_ipcache_v2, ptr @cilium_ipv4_frag_datagrams, ptr @cilium_ipv6_frag_datagrams, ptr @cilium_lb4_affinity, ptr @cilium_lb4_backends_v3, ptr @cilium_lb4_health, ptr @cilium_lb4_maglev, ptr @cilium_lb4_reverse_nat, ptr @cilium_lb4_reverse_sk, ptr @cilium_lb4_services_v2, ptr @cilium_lb4_source_range, ptr @cilium_lb6_affinity, ptr @cilium_lb6_backends_v3, ptr @cilium_lb6_health, ptr @cilium_lb6_maglev, ptr @cilium_lb6_reverse_nat, ptr @cilium_lb6_reverse_sk, ptr @cilium_lb6_services_v2, ptr @cilium_lb6_source_range, ptr @cilium_lb_act, ptr @cilium_lb_affinity_match, ptr @cilium_lxc, ptr @cilium_metrics, ptr @cilium_ratelimit, ptr @cilium_ratelimit_metrics, ptr @cilium_skip_lb4, ptr @cilium_skip_lb6], section "llvm.metadata"

; Function Attrs: nounwind
define dso_local void @__check_cluster_id_bits() local_unnamed_addr #0 !dbg !1119 {
  %1 = tail call ptr asm sideeffect "$0 = __config_cluster_id_bits ll", "=r"() #5, !dbg !1125, !srcloc !1126
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !1123, metadata !DIExpression()), !dbg !1127
  %2 = load volatile i32, ptr %1, align 4, !dbg !1128, !tbaa !1129
  ret void, !dbg !1128
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_connect(ptr noundef %0) #0 section "cgroup/connect4" !dbg !1133 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !1174
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !1175
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !1176
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !1177
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !1178
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !1179
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !1180
  %9 = alloca i32, align 4, !DIAssignID !1181
  %10 = alloca i32, align 4, !DIAssignID !1182
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !1183
  %12 = alloca i32, align 4, !DIAssignID !1184
  %13 = alloca %struct.metrics_value, align 8, !DIAssignID !1185
  %14 = alloca %struct.metrics_key, align 8, !DIAssignID !1186
  %15 = alloca %struct.metrics_value, align 8, !DIAssignID !1187
  %16 = alloca %struct.metrics_key, align 8, !DIAssignID !1188
  %17 = alloca %struct.metrics_value, align 8, !DIAssignID !1189
  %18 = alloca %struct.metrics_key, align 8, !DIAssignID !1190
  %19 = alloca %struct.lb4_key, align 4, !DIAssignID !1191
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !1172, metadata !DIExpression()), !dbg !1192
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !1191, metadata ptr %19, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1199, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i1 false, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.value(metadata i1 true, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !1235
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !1235
  %20 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #5, !dbg !1237
  call void @llvm.dbg.value(metadata i64 %20, metadata !1234, metadata !DIExpression()), !dbg !1235
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !1203, metadata !DIExpression()), !dbg !1225
  %21 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !1238
  call void @llvm.dbg.value(metadata !DIArgList(i64 %20, i64 %21), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1225
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !1184, metadata ptr %12, metadata !DIExpression()), !dbg !1247
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !1247
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !1249
  %22 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !1250
  %23 = load i32, ptr %22, align 8, !dbg !1250, !tbaa !1251
  store volatile i32 %23, ptr %12, align 4, !dbg !1253, !tbaa !1129, !DIAssignID !1254
  call void @llvm.dbg.assign(metadata i32 %23, metadata !1239, metadata !DIExpression(), metadata !1254, metadata ptr %12, metadata !DIExpression()), !dbg !1247
  %24 = load volatile i32, ptr %12, align 4, !dbg !1255, !tbaa !1129
  %25 = trunc i32 %24 to i16, !dbg !1256
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !1257
  call void @llvm.dbg.value(metadata i16 %25, metadata !1211, metadata !DIExpression()), !dbg !1225
  %26 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !1258
  %27 = load i32, ptr %26, align 4, !dbg !1258, !tbaa !1259
  %28 = trunc i32 %27 to i8, !dbg !1258
  call void @llvm.dbg.value(metadata i8 %28, metadata !1212, metadata !DIExpression()), !dbg !1225
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !1260
  %30 = load i32, ptr %29, align 4, !dbg !1260, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %30, metadata !1213, metadata !DIExpression()), !dbg !1225
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %19) #5, !dbg !1262
  store i32 %30, ptr %19, align 4, !dbg !1263, !tbaa !1264, !DIAssignID !1267
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1267, metadata ptr %19, metadata !DIExpression()), !dbg !1225
  %31 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 1, !dbg !1263
  store i16 %25, ptr %31, align 4, !dbg !1263, !tbaa !1268, !DIAssignID !1269
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1269, metadata ptr %31, metadata !DIExpression()), !dbg !1225
  %32 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 2, !dbg !1263
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1270, metadata ptr %32, metadata !DIExpression()), !dbg !1225
  %33 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 3, !dbg !1263
  store i8 %28, ptr %33, align 4, !dbg !1263, !tbaa !1271, !DIAssignID !1272
  call void @llvm.dbg.assign(metadata i8 %28, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !1272, metadata ptr %33, metadata !DIExpression()), !dbg !1225
  %34 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 4, !dbg !1263
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !1273, metadata ptr %34, metadata !DIExpression()), !dbg !1225
  %35 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 5, !dbg !1263
  store i16 0, ptr %35, align 2, !dbg !1263, !DIAssignID !1274
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !1274, metadata ptr %35, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  tail call void @llvm.dbg.value(metadata i8 %28, metadata !1275, metadata !DIExpression()), !dbg !1280
  switch i8 %28, label %282 [
    i8 6, label %36
    i8 -120, label %36
    i8 17, label %36
  ], !dbg !1283

36:                                               ; preds = %1, %1, %1
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !1293, metadata ptr undef, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !1296, metadata ptr undef, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.value(metadata ptr %19, metadata !1289, metadata !DIExpression()), !dbg !1294
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !1294
  store i16 0, ptr %32, align 2, !dbg !1297, !tbaa !1298
  store i8 0, ptr %34, align 1, !dbg !1299, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1306
  %37 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !1308
  call void @llvm.dbg.value(metadata ptr %37, metadata !1291, metadata !DIExpression()), !dbg !1294
  %38 = icmp eq ptr %37, null, !dbg !1309
  br i1 %38, label %282, label %39, !dbg !1311

39:                                               ; preds = %36
  tail call void @llvm.dbg.value(metadata ptr %37, metadata !1312, metadata !DIExpression()), !dbg !1317
  %40 = getelementptr inbounds %struct.lb4_service, ptr %37, i64 0, i32 4, !dbg !1320
  %41 = load i8, ptr %40, align 1, !dbg !1320, !tbaa !1321
  %42 = and i8 %41, 32, !dbg !1323
  %43 = icmp eq i8 %42, 0, !dbg !1324
  br i1 %43, label %47, label %44, !dbg !1325

44:                                               ; preds = %39
  store i8 1, ptr %34, align 1, !dbg !1326, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1327
  %45 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !1329
  call void @llvm.dbg.value(metadata ptr %45, metadata !1208, metadata !DIExpression()), !dbg !1225
  %46 = icmp eq ptr %45, null, !dbg !1330
  br i1 %46, label %282, label %47, !dbg !1332

47:                                               ; preds = %39, %44
  %48 = phi ptr [ %45, %44 ], [ %37, %39 ]
  call void @llvm.dbg.value(metadata ptr %48, metadata !1208, metadata !DIExpression()), !dbg !1225
  %49 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 1, !dbg !1333
  %50 = load i16, ptr %49, align 4, !dbg !1333, !tbaa !1334
  %51 = icmp eq i16 %50, 0, !dbg !1335
  br i1 %51, label %52, label %70, !dbg !1336

52:                                               ; preds = %47
  %53 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #5, !dbg !1337, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %53, metadata !1217, metadata !DIExpression()), !dbg !1339
  %54 = load volatile i8, ptr %53, align 1, !dbg !1340, !tbaa !1341, !range !1343, !noundef !1344
  %55 = icmp eq i8 %54, 0, !dbg !1340
  br i1 %55, label %56, label %282, !dbg !1345

56:                                               ; preds = %52
  call void @llvm.dbg.value(metadata ptr %48, metadata !1346, metadata !DIExpression()), !dbg !1351
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1354, metadata !DIExpression()), !dbg !1357
  %57 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 3, !dbg !1360
  %58 = load i8, ptr %57, align 4, !dbg !1360, !tbaa !1361
  %59 = and i8 %58, 35, !dbg !1362
  %60 = icmp eq i8 %59, 0, !dbg !1363
  br i1 %60, label %64, label %61, !dbg !1364

61:                                               ; preds = %56
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1365, metadata !DIExpression()), !dbg !1368
  %62 = and i8 %58, 4, !dbg !1370
  %63 = icmp eq i8 %62, 0, !dbg !1371
  br i1 %63, label %282, label %69, !dbg !1372

64:                                               ; preds = %56
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1354, metadata !DIExpression()), !dbg !1373
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1375, metadata !DIExpression()), !dbg !1378
  %65 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1380
  %66 = load i8, ptr %65, align 1, !dbg !1380, !tbaa !1321
  %67 = and i8 %66, 16, !dbg !1381
  %68 = icmp eq i8 %67, 0, !dbg !1382
  br i1 %68, label %282, label %69, !dbg !1383

69:                                               ; preds = %64, %61
  br label %282, !dbg !1384

70:                                               ; preds = %47
  call void @llvm.dbg.value(metadata ptr %48, metadata !1385, metadata !DIExpression()), !dbg !1388
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1391, metadata !DIExpression()), !dbg !1394
  %71 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 3, !dbg !1396
  %72 = load i8, ptr %71, align 4, !dbg !1396, !tbaa !1361
  %73 = and i8 %72, 8, !dbg !1397
  %74 = icmp eq i8 %73, 0, !dbg !1398
  br i1 %74, label %75, label %80, !dbg !1399

75:                                               ; preds = %70
  %76 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1400
  %77 = load i8, ptr %76, align 1, !dbg !1400, !tbaa !1321
  %78 = and i8 %77, 8, !dbg !1401
  %79 = icmp eq i8 %78, 0, !dbg !1399
  br i1 %79, label %86, label %282, !dbg !1402

80:                                               ; preds = %70
  call void @llvm.dbg.value(metadata ptr %48, metadata !1403, metadata !DIExpression()), !dbg !1414
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1417, metadata !DIExpression()), !dbg !1420
  %81 = and i8 %72, 1, !dbg !1422
  %82 = icmp eq i8 %81, 0, !dbg !1423
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1391, metadata !DIExpression()), !dbg !1424
  %83 = and i32 %30, 255
  %84 = icmp eq i32 %83, 127
  %85 = select i1 %82, i1 %84, i1 false, !dbg !1426
  br i1 %85, label %99, label %89, !dbg !1426

86:                                               ; preds = %75
  call void @llvm.dbg.value(metadata ptr %48, metadata !1403, metadata !DIExpression()), !dbg !1414
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1417, metadata !DIExpression()), !dbg !1420
  %87 = and i8 %72, 1, !dbg !1422
  %88 = icmp eq i8 %87, 0, !dbg !1423
  br i1 %88, label %99, label %89, !dbg !1426

89:                                               ; preds = %86, %80
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !1178, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 %30, metadata !1433, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !1436
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #5, !dbg !1438
  %90 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !1439
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %90, i8 0, i64 18, i1 false), !dbg !1439, !DIAssignID !1440
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !1440, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !1441, metadata ptr undef, metadata !DIExpression()), !dbg !1436
  store i32 64, ptr %6, align 4, !dbg !1442, !tbaa.struct !1443, !DIAssignID !1445
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1445, metadata ptr %6, metadata !DIExpression()), !dbg !1436
  %91 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !1446
  store i8 1, ptr %91, align 1, !dbg !1447, !tbaa !1448, !DIAssignID !1451
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !1451, metadata ptr %91, metadata !DIExpression()), !dbg !1436
  %92 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !1452
  store i32 %30, ptr %92, align 4, !dbg !1453, !tbaa !1444, !DIAssignID !1454
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1454, metadata ptr %92, metadata !DIExpression()), !dbg !1436
  %93 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !1455
  store i16 0, ptr %93, align 4, !dbg !1456, !tbaa !1457, !DIAssignID !1458
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1458, metadata ptr %93, metadata !DIExpression()), !dbg !1436
  %94 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #5, !dbg !1459
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #5, !dbg !1460
  call void @llvm.dbg.value(metadata ptr %94, metadata !1409, metadata !DIExpression()), !dbg !1461
  %95 = icmp eq ptr %94, null, !dbg !1462
  br i1 %95, label %282, label %96, !dbg !1464

96:                                               ; preds = %89
  %97 = load i32, ptr %94, align 4, !dbg !1465, !tbaa !1466
  %98 = icmp eq i32 %97, 1, !dbg !1468
  br i1 %98, label %99, label %282, !dbg !1469

99:                                               ; preds = %80, %86, %96
  %100 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #5, !dbg !1470, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %100, metadata !1222, metadata !DIExpression()), !dbg !1472
  %101 = load volatile i8, ptr %100, align 1, !dbg !1473, !tbaa !1341, !range !1343, !noundef !1344
  %102 = icmp eq i8 %101, 0, !dbg !1473
  br i1 %102, label %114, label %103, !dbg !1474

103:                                              ; preds = %99
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1475, metadata !DIExpression()), !dbg !1478
  %104 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 4, !dbg !1480
  %105 = load i8, ptr %104, align 1, !dbg !1480, !tbaa !1321
  %106 = and i8 %105, 1, !dbg !1481
  %107 = icmp eq i8 %106, 0, !dbg !1482
  br i1 %107, label %114, label %108, !dbg !1483

108:                                              ; preds = %103
  %109 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !1484
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !1183, metadata ptr %11, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i64 %109, metadata !1490, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i32 %30, metadata !1491, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata i16 %25, metadata !1492, metadata !DIExpression()), !dbg !1494
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #5, !dbg !1496
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !1494
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !1505
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !1529
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !1529
  call void @llvm.dbg.label(metadata !1527), !dbg !1532
  %110 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !1533
  call void @llvm.dbg.value(metadata ptr %110, metadata !1512, metadata !DIExpression()), !dbg !1529
  store i64 0, ptr %110, align 8, !dbg !1533, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !1536
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !1529
  store i64 %109, ptr %11, align 8, !dbg !1537, !tbaa !1538, !DIAssignID !1540
  call void @llvm.dbg.assign(metadata i64 %109, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1540, metadata ptr %11, metadata !DIExpression()), !dbg !1494
  store i32 %30, ptr %110, align 8, !dbg !1541, !tbaa !1542, !DIAssignID !1543
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1543, metadata ptr %110, metadata !DIExpression()), !dbg !1494
  %111 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !1544
  store i16 %25, ptr %111, align 4, !dbg !1545, !tbaa !1546, !DIAssignID !1547
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !1547, metadata ptr %111, metadata !DIExpression()), !dbg !1494
  %112 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #5, !dbg !1548
  call void @llvm.dbg.value(metadata ptr %112, metadata !1493, metadata !DIExpression()), !dbg !1494
  %113 = icmp eq ptr %112, null, !dbg !1549
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #5, !dbg !1551
  br i1 %113, label %114, label %282, !dbg !1552

114:                                              ; preds = %108, %103, %99
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1553, metadata !DIExpression()), !dbg !1556
  %115 = load i8, ptr %71, align 4, !dbg !1559, !tbaa !1361
  %116 = and i8 %115, 16, !dbg !1560
  %117 = icmp eq i8 %116, 0, !dbg !1561
  br i1 %117, label %173, label %118, !dbg !1562

118:                                              ; preds = %114
  call void @llvm.dbg.value(metadata ptr %48, metadata !1563, metadata !DIExpression()), !dbg !1570
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !1570
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !1176, metadata ptr %4, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !1177, metadata ptr %5, metadata !DIExpression()), !dbg !1595
  call void @llvm.dbg.value(metadata ptr %48, metadata !1580, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !1593
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !1593
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !1596
  store i64 %20, ptr %4, align 8, !dbg !1597, !DIAssignID !1598
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1598, metadata ptr %4, metadata !DIExpression()), !dbg !1593
  %119 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !1599
  %120 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1600
  %121 = load i16, ptr %120, align 2, !dbg !1600, !tbaa !1601
  store i16 %121, ptr %119, align 8, !dbg !1599, !tbaa !1602, !DIAssignID !1604
  call void @llvm.dbg.assign(metadata i16 %121, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !1604, metadata ptr %119, metadata !DIExpression()), !dbg !1593
  %122 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !1599
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !1605, metadata ptr %122, metadata !DIExpression()), !dbg !1593
  store i8 1, ptr %122, align 2, !dbg !1599, !DIAssignID !1606
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !1606, metadata ptr %122, metadata !DIExpression()), !dbg !1593
  %123 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !1599
  store i8 0, ptr %123, align 1, !dbg !1599, !tbaa !1607, !DIAssignID !1608
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !1608, metadata ptr %123, metadata !DIExpression()), !dbg !1593
  %124 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !1599
  store i32 0, ptr %124, align 4, !dbg !1599, !tbaa !1609, !DIAssignID !1610
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1610, metadata ptr %124, metadata !DIExpression()), !dbg !1593
  %125 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !1611
  call void @llvm.dbg.value(metadata ptr %125, metadata !1583, metadata !DIExpression()), !dbg !1593
  %126 = icmp eq ptr %125, null, !dbg !1612
  br i1 %126, label %127, label %128, !dbg !1613

127:                                              ; preds = %118
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !1614
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  br label %173, !dbg !1615

128:                                              ; preds = %118
  %129 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !1616, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %129, metadata !1623, metadata !DIExpression()), !dbg !1626
  %130 = load volatile i8, ptr %129, align 1, !dbg !1627, !tbaa !1341, !range !1343, !noundef !1344
  %131 = icmp eq i8 %130, 0, !dbg !1627
  br i1 %131, label %135, label %132, !dbg !1628

132:                                              ; preds = %128
  %133 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !1629
  %134 = lshr i64 %133, 8, !dbg !1630
  br label %138, !dbg !1631

135:                                              ; preds = %128
  %136 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !1632
  %137 = udiv i64 %136, 1000000000, !dbg !1635
  br label %138, !dbg !1636

138:                                              ; preds = %132, %135
  %139 = phi i64 [ %134, %132 ], [ %137, %135 ], !dbg !1637
  call void @llvm.dbg.value(metadata i64 %139, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1595
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #5, !dbg !1638
  %140 = getelementptr inbounds %struct.lb_affinity_val, ptr %125, i64 0, i32 1, !dbg !1639
  %141 = load i32, ptr %140, align 1, !dbg !1639, !tbaa !1640
  store i32 %141, ptr %5, align 4, !dbg !1642, !tbaa !1643, !DIAssignID !1645
  call void @llvm.dbg.assign(metadata i32 %141, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1645, metadata ptr %5, metadata !DIExpression()), !dbg !1595
  %142 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !1642
  %143 = load i16, ptr %120, align 2, !dbg !1646, !tbaa !1601
  store i16 %143, ptr %142, align 4, !dbg !1642, !tbaa !1647, !DIAssignID !1648
  call void @llvm.dbg.assign(metadata i16 %143, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1648, metadata ptr %142, metadata !DIExpression()), !dbg !1595
  %144 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !1642
  store i16 0, ptr %144, align 2, !dbg !1642, !tbaa !1649, !DIAssignID !1650
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1650, metadata ptr %144, metadata !DIExpression()), !dbg !1595
  %145 = load volatile i64, ptr %125, align 1, !dbg !1651, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %145, metadata !1588, metadata !DIExpression()), !dbg !1652
  call void asm sideeffect "", "~{memory}"() #5, !dbg !1653, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1658, metadata !DIExpression()), !dbg !1663
  %146 = load i32, ptr %48, align 4, !dbg !1665, !tbaa !1444
  %147 = and i32 %146, 16777215, !dbg !1666
  call void @llvm.dbg.value(metadata i32 %147, metadata !1667, metadata !DIExpression()), !dbg !1677
  %148 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !1679, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %148, metadata !1672, metadata !DIExpression()), !dbg !1681
  %149 = load volatile i8, ptr %148, align 1, !dbg !1682, !tbaa !1341, !range !1343, !noundef !1344
  %150 = icmp eq i8 %149, 0, !dbg !1682
  br i1 %150, label %156, label %151, !dbg !1683

151:                                              ; preds = %138
  %152 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #5, !dbg !1684, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %152, metadata !1675, metadata !DIExpression()), !dbg !1686
  %153 = load volatile i32, ptr %152, align 4, !dbg !1687, !tbaa !1129
  %154 = mul i32 %153, %147, !dbg !1688
  %155 = lshr i32 %154, 8, !dbg !1689
  br label %156, !dbg !1690

156:                                              ; preds = %138, %151
  %157 = phi i32 [ %155, %151 ], [ %147, %138 ], !dbg !1677
  %158 = zext nneg i32 %157 to i64, !dbg !1691
  %159 = add i64 %145, %158, !dbg !1692
  %160 = and i64 %139, 4294967295, !dbg !1693
  %161 = icmp ugt i64 %159, %160, !dbg !1694
  br i1 %161, label %162, label %165, !dbg !1695

162:                                              ; preds = %156
  %163 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #5, !dbg !1696
  %164 = icmp eq ptr %163, null, !dbg !1696
  br i1 %164, label %165, label %167, !dbg !1698

165:                                              ; preds = %162, %156
  %166 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !1595
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !1699
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !1614
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  br label %173, !dbg !1615

167:                                              ; preds = %162
  call void @llvm.dbg.value(metadata i64 %160, metadata !1591, metadata !DIExpression()), !dbg !1700
  store volatile i64 %160, ptr %125, align 1, !dbg !1701, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #5, !dbg !1702, !srcloc !1657
  %168 = load i32, ptr %140, align 1, !dbg !1704, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !1699
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !1614
  call void @llvm.dbg.value(metadata i32 %168, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !1225
  %169 = icmp eq i32 %168, 0, !dbg !1705
  br i1 %169, label %173, label %170, !dbg !1615

170:                                              ; preds = %167
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !1182, metadata ptr %10, metadata !DIExpression()), !dbg !1712
  store i32 %168, ptr %10, align 4, !tbaa !1129, !DIAssignID !1715
  call void @llvm.dbg.assign(metadata i32 %168, metadata !1707, metadata !DIExpression(), metadata !1715, metadata ptr %10, metadata !DIExpression()), !dbg !1712
  %171 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #5, !dbg !1716
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !1717
  call void @llvm.dbg.value(metadata ptr %171, metadata !1205, metadata !DIExpression()), !dbg !1225
  %172 = icmp eq ptr %171, null, !dbg !1718
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void asm sideeffect "", "~{memory}"() #5, !dbg !1720, !srcloc !1721
  br i1 %172, label %173, label %215, !dbg !1722

173:                                              ; preds = %170, %167, %114, %127, %165
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !1728
  %174 = load i32, ptr %26, align 4, !dbg !1732, !tbaa !1259
  %175 = and i32 %174, 255, !dbg !1732
  %176 = icmp eq i32 %175, 6, !dbg !1733
  br i1 %176, label %177, label %180, !dbg !1732

177:                                              ; preds = %173
  %178 = call i32 inttoptr (i64 7 to ptr)() #5, !dbg !1734
  %179 = zext i32 %178 to i64, !dbg !1734
  br label %182, !dbg !1732

180:                                              ; preds = %173
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !1740
  %181 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !1742
  br label %182, !dbg !1732

182:                                              ; preds = %177, %180
  %183 = phi i64 [ %179, %177 ], [ %181, %180 ], !dbg !1732
  %184 = load i16, ptr %49, align 4, !dbg !1743, !tbaa !1334
  %185 = zext i16 %184 to i64, !dbg !1744
  %186 = urem i64 %183, %185, !dbg !1745
  %187 = trunc i64 %186 to i16, !dbg !1746
  %188 = add nuw i16 %187, 1, !dbg !1746
  store i16 %188, ptr %32, align 2, !dbg !1747, !tbaa !1298, !DIAssignID !1748
  call void @llvm.dbg.assign(metadata i16 %188, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1748, metadata ptr %32, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata ptr %19, metadata !1749, metadata !DIExpression()), !dbg !1752
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !1754
  %189 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !1756
  call void @llvm.dbg.value(metadata ptr %189, metadata !1214, metadata !DIExpression()), !dbg !1225
  %190 = icmp eq ptr %189, null, !dbg !1757
  br i1 %190, label %191, label %201, !dbg !1759

191:                                              ; preds = %182
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1189, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1190, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !1772
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %17) #5, !dbg !1775
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !1776, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %18) #5, !dbg !1777
  store i64 21502558725, ptr %18, align 8, !dbg !1778, !DIAssignID !1779
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !1779, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1780, metadata ptr %18, metadata !DIExpression()), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1781, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !1772
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !1782, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !1772
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !1783, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !1772
  %192 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18) #5, !dbg !1784
  call void @llvm.dbg.value(metadata ptr %192, metadata !1770, metadata !DIExpression()), !dbg !1772
  %193 = icmp eq ptr %192, null, !dbg !1785
  br i1 %193, label %197, label %194, !dbg !1787

194:                                              ; preds = %191
  %195 = load i64, ptr %192, align 8, !dbg !1788, !tbaa !1790
  %196 = add i64 %195, 1, !dbg !1788
  store i64 %196, ptr %192, align 8, !dbg !1788, !tbaa !1790
  br label %200, !dbg !1792

197:                                              ; preds = %191
  store i64 1, ptr %17, align 8, !dbg !1793, !tbaa !1790, !DIAssignID !1795
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1795, metadata ptr %17, metadata !DIExpression()), !dbg !1772
  %198 = getelementptr inbounds %struct.metrics_value, ptr %17, i64 0, i32 1, !dbg !1796
  store i64 0, ptr %198, align 8, !dbg !1797, !tbaa !1798, !DIAssignID !1799
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !1799, metadata ptr %198, metadata !DIExpression()), !dbg !1772
  %199 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #5, !dbg !1800
  br label %200

200:                                              ; preds = %194, %197
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %18) #5, !dbg !1801
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %17) #5, !dbg !1801
  br label %282, !dbg !1802

201:                                              ; preds = %182
  %202 = load i32, ptr %189, align 4, !dbg !1803, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %202, metadata !1216, metadata !DIExpression()), !dbg !1225
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !1181, metadata ptr %9, metadata !DIExpression()), !dbg !1804
  store i32 %202, ptr %9, align 4, !tbaa !1129, !DIAssignID !1806
  call void @llvm.dbg.assign(metadata i32 %202, metadata !1707, metadata !DIExpression(), metadata !1806, metadata ptr %9, metadata !DIExpression()), !dbg !1804
  %203 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #5, !dbg !1807
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !1808
  call void @llvm.dbg.value(metadata ptr %203, metadata !1205, metadata !DIExpression()), !dbg !1225
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !1225
  %204 = icmp eq ptr %203, null, !dbg !1809
  br i1 %204, label %205, label %215, !dbg !1811

205:                                              ; preds = %201
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1187, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1188, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !1812
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %15) #5, !dbg !1815
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !1816, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %16) #5, !dbg !1817
  store i64 21503148550, ptr %16, align 8, !dbg !1818, !DIAssignID !1819
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !1819, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !1820, metadata ptr %16, metadata !DIExpression()), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !1821, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !1812
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !1822, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !1812
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !1823, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !1812
  %206 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16) #5, !dbg !1824
  call void @llvm.dbg.value(metadata ptr %206, metadata !1770, metadata !DIExpression()), !dbg !1812
  %207 = icmp eq ptr %206, null, !dbg !1825
  br i1 %207, label %211, label %208, !dbg !1826

208:                                              ; preds = %205
  %209 = load i64, ptr %206, align 8, !dbg !1827, !tbaa !1790
  %210 = add i64 %209, 1, !dbg !1827
  store i64 %210, ptr %206, align 8, !dbg !1827, !tbaa !1790
  br label %214, !dbg !1828

211:                                              ; preds = %205
  store i64 1, ptr %15, align 8, !dbg !1829, !tbaa !1790, !DIAssignID !1830
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1830, metadata ptr %15, metadata !DIExpression()), !dbg !1812
  %212 = getelementptr inbounds %struct.metrics_value, ptr %15, i64 0, i32 1, !dbg !1831
  store i64 0, ptr %212, align 8, !dbg !1832, !tbaa !1798, !DIAssignID !1833
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !1833, metadata ptr %212, metadata !DIExpression()), !dbg !1812
  %213 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16, ptr noundef nonnull %15, i32 noundef 0) #5, !dbg !1834
  br label %214

214:                                              ; preds = %208, %211
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %16) #5, !dbg !1835
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %15) #5, !dbg !1835
  br label %282, !dbg !1836

215:                                              ; preds = %170, %201
  %216 = phi ptr [ %203, %201 ], [ %171, %170 ]
  %217 = phi i1 [ false, %201 ], [ true, %170 ]
  %218 = phi i32 [ %202, %201 ], [ %168, %170 ]
  call void asm sideeffect "", "~{memory}"() #5, !dbg !1837, !srcloc !1838
  tail call void @llvm.dbg.value(metadata ptr %48, metadata !1553, metadata !DIExpression()), !dbg !1839
  %219 = load i8, ptr %71, align 4, !dbg !1842, !tbaa !1361
  %220 = and i8 %219, 16, !dbg !1843
  %221 = icmp eq i8 %220, 0, !dbg !1844
  %222 = or i1 %217, %221, !dbg !1845
  br i1 %222, label %245, label %223, !dbg !1845

223:                                              ; preds = %215
  call void @llvm.dbg.value(metadata ptr %48, metadata !1846, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.value(metadata i32 %218, metadata !1852, metadata !DIExpression()), !dbg !1853
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !1174, metadata ptr %2, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !1175, metadata ptr %3, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata ptr %48, metadata !1860, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !1866
  call void @llvm.dbg.value(metadata i32 %218, metadata !1863, metadata !DIExpression()), !dbg !1866
  %224 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !1868, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %224, metadata !1623, metadata !DIExpression()), !dbg !1870
  %225 = load volatile i8, ptr %224, align 1, !dbg !1871, !tbaa !1341, !range !1343, !noundef !1344
  %226 = icmp eq i8 %225, 0, !dbg !1871
  br i1 %226, label %230, label %227, !dbg !1872

227:                                              ; preds = %223
  %228 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !1873
  %229 = lshr i64 %228, 8, !dbg !1874
  br label %233, !dbg !1875

230:                                              ; preds = %223
  %231 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !1876
  %232 = udiv i64 %231, 1000000000, !dbg !1878
  br label %233, !dbg !1879

233:                                              ; preds = %227, %230
  %234 = phi i64 [ %229, %227 ], [ %232, %230 ], !dbg !1880
  call void @llvm.dbg.value(metadata i64 %234, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1866
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #5, !dbg !1881
  store i64 %20, ptr %2, align 8, !dbg !1882, !DIAssignID !1883
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1883, metadata ptr %2, metadata !DIExpression()), !dbg !1866
  %235 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !1884
  %236 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1885
  %237 = load i16, ptr %236, align 2, !dbg !1885, !tbaa !1601
  store i16 %237, ptr %235, align 8, !dbg !1884, !tbaa !1602, !DIAssignID !1886
  call void @llvm.dbg.assign(metadata i16 %237, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !1886, metadata ptr %235, metadata !DIExpression()), !dbg !1866
  %238 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !1884
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !1887, metadata ptr %238, metadata !DIExpression()), !dbg !1866
  store i8 1, ptr %238, align 2, !dbg !1884, !DIAssignID !1888
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !1888, metadata ptr %238, metadata !DIExpression()), !dbg !1866
  %239 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !1884
  store i8 0, ptr %239, align 1, !dbg !1884, !tbaa !1607, !DIAssignID !1889
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !1889, metadata ptr %239, metadata !DIExpression()), !dbg !1866
  %240 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !1884
  store i32 0, ptr %240, align 4, !dbg !1884, !tbaa !1609, !DIAssignID !1890
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1890, metadata ptr %240, metadata !DIExpression()), !dbg !1866
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #5, !dbg !1891
  %241 = and i64 %234, 4294967295, !dbg !1892
  store i64 %241, ptr %3, align 8, !dbg !1893, !tbaa !1894, !DIAssignID !1895
  call void @llvm.dbg.assign(metadata i64 %241, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1895, metadata ptr %3, metadata !DIExpression()), !dbg !1866
  %242 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !1893
  store i32 %218, ptr %242, align 8, !dbg !1893, !tbaa !1640, !DIAssignID !1896
  call void @llvm.dbg.assign(metadata i32 %218, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1896, metadata ptr %242, metadata !DIExpression()), !dbg !1866
  %243 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !1893
  store i32 0, ptr %243, align 4, !dbg !1893, !tbaa !1897, !DIAssignID !1898
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !1898, metadata ptr %243, metadata !DIExpression()), !dbg !1866
  %244 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #5, !dbg !1899
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #5, !dbg !1900
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #5, !dbg !1900
  br label %245, !dbg !1901

245:                                              ; preds = %233, %215
  %246 = getelementptr inbounds %struct.lb4_backend, ptr %216, i64 0, i32 1, !dbg !1902
  %247 = getelementptr inbounds %struct.lb4_service, ptr %48, i64 0, i32 2, !dbg !1903
  %248 = load i16, ptr %247, align 2, !dbg !1903, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !1179, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !1180, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %216, metadata !1911, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i32 %30, metadata !1912, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i16 %25, metadata !1913, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i16 %248, metadata !1914, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #5, !dbg !1920
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !1921, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #5, !dbg !1922
  %249 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !1923
  store i64 0, ptr %249, align 8, !dbg !1923, !DIAssignID !1924
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !1924, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1925, metadata ptr undef, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !1926
  %250 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !1928
  store i64 %250, ptr %8, align 8, !dbg !1929, !tbaa !1930, !DIAssignID !1932
  call void @llvm.dbg.assign(metadata i64 %250, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !1932, metadata ptr %8, metadata !DIExpression()), !dbg !1918
  %251 = load i32, ptr %216, align 4, !dbg !1933, !tbaa !1934
  %252 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !1936
  store i32 %251, ptr %252, align 8, !dbg !1937, !tbaa !1938, !DIAssignID !1939
  call void @llvm.dbg.assign(metadata i32 %251, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !1939, metadata ptr %252, metadata !DIExpression()), !dbg !1918
  %253 = load i16, ptr %246, align 4, !dbg !1940, !tbaa !1941
  %254 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !1942
  store i16 %253, ptr %254, align 4, !dbg !1943, !tbaa !1944, !DIAssignID !1945
  call void @llvm.dbg.assign(metadata i16 %253, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !1945, metadata ptr %254, metadata !DIExpression()), !dbg !1918
  store i32 %30, ptr %7, align 4, !dbg !1946, !tbaa !1947, !DIAssignID !1949
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !1949, metadata ptr %7, metadata !DIExpression()), !dbg !1918
  %255 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !1950
  store i16 %25, ptr %255, align 4, !dbg !1951, !tbaa !1952, !DIAssignID !1953
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !1953, metadata ptr %255, metadata !DIExpression()), !dbg !1918
  %256 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !1954
  store i16 %248, ptr %256, align 2, !dbg !1955, !tbaa !1956, !DIAssignID !1957
  call void @llvm.dbg.assign(metadata i16 %248, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !1957, metadata ptr %256, metadata !DIExpression()), !dbg !1918
  %257 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #5, !dbg !1958
  call void @llvm.dbg.value(metadata ptr %257, metadata !1915, metadata !DIExpression()), !dbg !1918
  %258 = icmp eq ptr %257, null, !dbg !1959
  br i1 %258, label %264, label %259, !dbg !1961

259:                                              ; preds = %245
  call void @llvm.dbg.value(metadata ptr %257, metadata !1962, metadata !DIExpression()), !dbg !1969
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !1969
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !1969
  tail call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !1993
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !1993
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !1993
  tail call void @llvm.dbg.value(metadata ptr %257, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !1993
  call void @llvm.dbg.label(metadata !1992), !dbg !1995
  tail call void @llvm.dbg.value(metadata ptr %257, metadata !1974, metadata !DIExpression()), !dbg !1993
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !1993
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !1993
  %260 = load i64, ptr %257, align 8, !dbg !1996, !tbaa !1534
  %261 = load i64, ptr %7, align 8, !dbg !1996, !tbaa !1534
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %260, i64 %261), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !1993
  %262 = icmp eq i64 %260, %261, !dbg !1997
  br i1 %262, label %263, label %264, !dbg !1998

263:                                              ; preds = %259
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !1999
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !1999
  br label %278, !dbg !2000

264:                                              ; preds = %245, %259
  %265 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #5, !dbg !2001
  call void @llvm.dbg.value(metadata i32 %265, metadata !1917, metadata !DIExpression()), !dbg !1918
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !1999
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !1999
  %266 = icmp slt i32 %265, 0, !dbg !2002
  br i1 %266, label %267, label %278, !dbg !2000

267:                                              ; preds = %264
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !1185, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !1186, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2003
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #5, !dbg !2006
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2007, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %14) #5, !dbg !2008
  store i64 21504197127, ptr %14, align 8, !dbg !2009, !DIAssignID !2010
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2010, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2011, metadata ptr %14, metadata !DIExpression()), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2012, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2003
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2013, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2003
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2014, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2003
  %268 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14) #5, !dbg !2015
  call void @llvm.dbg.value(metadata ptr %268, metadata !1770, metadata !DIExpression()), !dbg !2003
  %269 = icmp eq ptr %268, null, !dbg !2016
  br i1 %269, label %273, label %270, !dbg !2017

270:                                              ; preds = %267
  %271 = load i64, ptr %268, align 8, !dbg !2018, !tbaa !1790
  %272 = add i64 %271, 1, !dbg !2018
  store i64 %272, ptr %268, align 8, !dbg !2018, !tbaa !1790
  br label %276, !dbg !2019

273:                                              ; preds = %267
  store i64 1, ptr %13, align 8, !dbg !2020, !tbaa !1790, !DIAssignID !2021
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2021, metadata ptr %13, metadata !DIExpression()), !dbg !2003
  %274 = getelementptr inbounds %struct.metrics_value, ptr %13, i64 0, i32 1, !dbg !2022
  store i64 0, ptr %274, align 8, !dbg !2023, !tbaa !1798, !DIAssignID !2024
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2024, metadata ptr %274, metadata !DIExpression()), !dbg !2003
  %275 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14, ptr noundef nonnull %13, i32 noundef 0) #5, !dbg !2025
  br label %276

276:                                              ; preds = %273, %270
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %14) #5, !dbg !2026
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #5, !dbg !2026
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #5, !dbg !2027
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !1173, metadata !DIExpression()), !dbg !1192
  %277 = call i1 @llvm.bpf.passthrough.i1.i1(i32 0, i1 false)
  br label %285, !dbg !2028

278:                                              ; preds = %263, %264
  %279 = load i32, ptr %216, align 4, !dbg !2030, !tbaa !1934
  store i32 %279, ptr %29, align 4, !dbg !2031, !tbaa !1261
  %280 = load i16, ptr %246, align 4, !dbg !2032, !tbaa !1941
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2039
  tail call void @llvm.dbg.value(metadata i16 %280, metadata !2038, metadata !DIExpression()), !dbg !2039
  %281 = zext i16 %280 to i32, !dbg !2041
  store i32 %281, ptr %22, align 8, !dbg !2042, !tbaa !1251
  br label %282, !dbg !2043

282:                                              ; preds = %61, %36, %89, %96, %69, %64, %44, %1, %52, %75, %108, %200, %214, %278
  %283 = phi i1 [ false, %278 ], [ true, %214 ], [ true, %200 ], [ true, %52 ], [ false, %75 ], [ false, %108 ], [ false, %1 ], [ false, %44 ], [ true, %69 ], [ false, %64 ], [ false, %96 ], [ false, %89 ], [ false, %36 ], [ false, %61 ], !dbg !1225
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #5, !dbg !2027
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !1173, metadata !DIExpression()), !dbg !1192
  %284 = call i1 @llvm.bpf.passthrough.i1.i1(i32 0, i1 %283)
  br i1 %284, label %285, label %286, !dbg !2028

285:                                              ; preds = %276, %282
  br label %286, !dbg !2044

286:                                              ; preds = %282, %285
  %287 = phi i32 [ 0, %285 ], [ 1, %282 ], !dbg !1192
  ret i32 %287, !dbg !2046
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_sendmsg(ptr noundef %0) #0 section "cgroup/sendmsg4" !dbg !2047 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2051
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !2052
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2053
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !2054
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !2055
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !2056
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2057
  %9 = alloca i32, align 4, !DIAssignID !2058
  %10 = alloca i32, align 4, !DIAssignID !2059
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !2060
  %12 = alloca i32, align 4, !DIAssignID !2061
  %13 = alloca %struct.metrics_value, align 8, !DIAssignID !2062
  %14 = alloca %struct.metrics_key, align 8, !DIAssignID !2063
  %15 = alloca %struct.metrics_value, align 8, !DIAssignID !2064
  %16 = alloca %struct.metrics_key, align 8, !DIAssignID !2065
  %17 = alloca %struct.metrics_value, align 8, !DIAssignID !2066
  %18 = alloca %struct.metrics_key, align 8, !DIAssignID !2067
  %19 = alloca %struct.lb4_key, align 4, !DIAssignID !2068
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2049, metadata !DIExpression()), !dbg !2069
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !2068, metadata ptr %19, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1199, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i1 true, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.value(metadata i1 false, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2072
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !2072
  %20 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef %0) #5, !dbg !2074
  call void @llvm.dbg.value(metadata i64 %20, metadata !1234, metadata !DIExpression()), !dbg !2072
  tail call void @llvm.dbg.value(metadata i64 %20, metadata !1203, metadata !DIExpression()), !dbg !2070
  %21 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !2075
  call void @llvm.dbg.value(metadata !DIArgList(i64 %20, i64 %21), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2070
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2061, metadata ptr %12, metadata !DIExpression()), !dbg !2076
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2076
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !2078
  %22 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2079
  %23 = load i32, ptr %22, align 8, !dbg !2079, !tbaa !1251
  store volatile i32 %23, ptr %12, align 4, !dbg !2080, !tbaa !1129, !DIAssignID !2081
  call void @llvm.dbg.assign(metadata i32 %23, metadata !1239, metadata !DIExpression(), metadata !2081, metadata ptr %12, metadata !DIExpression()), !dbg !2076
  %24 = load volatile i32, ptr %12, align 4, !dbg !2082, !tbaa !1129
  %25 = trunc i32 %24 to i16, !dbg !2083
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !2084
  call void @llvm.dbg.value(metadata i16 %25, metadata !1211, metadata !DIExpression()), !dbg !2070
  %26 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2085
  %27 = load i32, ptr %26, align 4, !dbg !2085, !tbaa !1259
  %28 = trunc i32 %27 to i8, !dbg !2085
  call void @llvm.dbg.value(metadata i8 %28, metadata !1212, metadata !DIExpression()), !dbg !2070
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !2086
  %30 = load i32, ptr %29, align 4, !dbg !2086, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %30, metadata !1213, metadata !DIExpression()), !dbg !2070
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %19) #5, !dbg !2087
  store i32 %30, ptr %19, align 4, !dbg !2088, !tbaa !1264, !DIAssignID !2089
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2089, metadata ptr %19, metadata !DIExpression()), !dbg !2070
  %31 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 1, !dbg !2088
  store i16 %25, ptr %31, align 4, !dbg !2088, !tbaa !1268, !DIAssignID !2090
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2090, metadata ptr %31, metadata !DIExpression()), !dbg !2070
  %32 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 2, !dbg !2088
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2091, metadata ptr %32, metadata !DIExpression()), !dbg !2070
  %33 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 3, !dbg !2088
  store i8 %28, ptr %33, align 4, !dbg !2088, !tbaa !1271, !DIAssignID !2092
  call void @llvm.dbg.assign(metadata i8 %28, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2092, metadata ptr %33, metadata !DIExpression()), !dbg !2070
  %34 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 4, !dbg !2088
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2093, metadata ptr %34, metadata !DIExpression()), !dbg !2070
  %35 = getelementptr inbounds %struct.lb4_key, ptr %19, i64 0, i32 5, !dbg !2088
  store i16 0, ptr %35, align 2, !dbg !2088, !DIAssignID !2094
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2094, metadata ptr %35, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %19, metadata !1289, metadata !DIExpression()), !dbg !2095
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2095
  store i16 0, ptr %32, align 2, !dbg !2097, !tbaa !1298
  store i8 0, ptr %34, align 1, !dbg !2098, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2099
  %36 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !2101
  call void @llvm.dbg.value(metadata ptr %36, metadata !1291, metadata !DIExpression()), !dbg !2095
  %37 = icmp eq ptr %36, null, !dbg !2102
  br i1 %37, label %281, label %38, !dbg !2103

38:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata ptr %36, metadata !1312, metadata !DIExpression()), !dbg !2104
  %39 = getelementptr inbounds %struct.lb4_service, ptr %36, i64 0, i32 4, !dbg !2106
  %40 = load i8, ptr %39, align 1, !dbg !2106, !tbaa !1321
  %41 = and i8 %40, 32, !dbg !2107
  %42 = icmp eq i8 %41, 0, !dbg !2108
  br i1 %42, label %46, label %43, !dbg !2109

43:                                               ; preds = %38
  store i8 1, ptr %34, align 1, !dbg !2110, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2111
  %44 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !2113
  call void @llvm.dbg.value(metadata ptr %44, metadata !1208, metadata !DIExpression()), !dbg !2070
  %45 = icmp eq ptr %44, null, !dbg !2114
  br i1 %45, label %281, label %46, !dbg !2115

46:                                               ; preds = %38, %43
  %47 = phi ptr [ %44, %43 ], [ %36, %38 ]
  call void @llvm.dbg.value(metadata ptr %47, metadata !1208, metadata !DIExpression()), !dbg !2070
  %48 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 1, !dbg !2116
  %49 = load i16, ptr %48, align 4, !dbg !2116, !tbaa !1334
  %50 = icmp eq i16 %49, 0, !dbg !2117
  br i1 %50, label %51, label %69, !dbg !2118

51:                                               ; preds = %46
  %52 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #5, !dbg !2119, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %52, metadata !1217, metadata !DIExpression()), !dbg !2120
  %53 = load volatile i8, ptr %52, align 1, !dbg !2121, !tbaa !1341, !range !1343, !noundef !1344
  %54 = icmp eq i8 %53, 0, !dbg !2121
  br i1 %54, label %55, label %281, !dbg !2122

55:                                               ; preds = %51
  call void @llvm.dbg.value(metadata ptr %47, metadata !1346, metadata !DIExpression()), !dbg !2123
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1354, metadata !DIExpression()), !dbg !2125
  %56 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 3, !dbg !2127
  %57 = load i8, ptr %56, align 4, !dbg !2127, !tbaa !1361
  %58 = and i8 %57, 35, !dbg !2128
  %59 = icmp eq i8 %58, 0, !dbg !2129
  br i1 %59, label %63, label %60, !dbg !2130

60:                                               ; preds = %55
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1365, metadata !DIExpression()), !dbg !2131
  %61 = and i8 %57, 4, !dbg !2133
  %62 = icmp eq i8 %61, 0, !dbg !2134
  br i1 %62, label %281, label %68, !dbg !2135

63:                                               ; preds = %55
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1354, metadata !DIExpression()), !dbg !2136
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1375, metadata !DIExpression()), !dbg !2138
  %64 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2140
  %65 = load i8, ptr %64, align 1, !dbg !2140, !tbaa !1321
  %66 = and i8 %65, 16, !dbg !2141
  %67 = icmp eq i8 %66, 0, !dbg !2142
  br i1 %67, label %281, label %68, !dbg !2143

68:                                               ; preds = %63, %60
  br label %281, !dbg !2144

69:                                               ; preds = %46
  call void @llvm.dbg.value(metadata ptr %47, metadata !1385, metadata !DIExpression()), !dbg !2145
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1391, metadata !DIExpression()), !dbg !2147
  %70 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 3, !dbg !2149
  %71 = load i8, ptr %70, align 4, !dbg !2149, !tbaa !1361
  %72 = and i8 %71, 8, !dbg !2150
  %73 = icmp eq i8 %72, 0, !dbg !2151
  br i1 %73, label %74, label %79, !dbg !2152

74:                                               ; preds = %69
  %75 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2153
  %76 = load i8, ptr %75, align 1, !dbg !2153, !tbaa !1321
  %77 = and i8 %76, 8, !dbg !2154
  %78 = icmp eq i8 %77, 0, !dbg !2152
  br i1 %78, label %85, label %281, !dbg !2155

79:                                               ; preds = %69
  call void @llvm.dbg.value(metadata ptr %47, metadata !1403, metadata !DIExpression()), !dbg !2156
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !2156
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1417, metadata !DIExpression()), !dbg !2158
  %80 = and i8 %71, 1, !dbg !2160
  %81 = icmp eq i8 %80, 0, !dbg !2161
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1391, metadata !DIExpression()), !dbg !2162
  %82 = and i32 %30, 255
  %83 = icmp eq i32 %82, 127
  %84 = select i1 %81, i1 %83, i1 false, !dbg !2164
  br i1 %84, label %98, label %88, !dbg !2164

85:                                               ; preds = %74
  call void @llvm.dbg.value(metadata ptr %47, metadata !1403, metadata !DIExpression()), !dbg !2156
  call void @llvm.dbg.value(metadata i32 %30, metadata !1408, metadata !DIExpression()), !dbg !2156
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1417, metadata !DIExpression()), !dbg !2158
  %86 = and i8 %71, 1, !dbg !2160
  %87 = icmp eq i8 %86, 0, !dbg !2161
  br i1 %87, label %98, label %88, !dbg !2164

88:                                               ; preds = %85, %79
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !2055, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 %30, metadata !1433, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !2165
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #5, !dbg !2167
  %89 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !2168
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %89, i8 0, i64 18, i1 false), !dbg !2168, !DIAssignID !2169
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !2169, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !2170, metadata ptr undef, metadata !DIExpression()), !dbg !2165
  store i32 64, ptr %6, align 4, !dbg !2171, !tbaa.struct !1443, !DIAssignID !2172
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2172, metadata ptr %6, metadata !DIExpression()), !dbg !2165
  %90 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !2173
  store i8 1, ptr %90, align 1, !dbg !2174, !tbaa !1448, !DIAssignID !2175
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !2175, metadata ptr %90, metadata !DIExpression()), !dbg !2165
  %91 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !2176
  store i32 %30, ptr %91, align 4, !dbg !2177, !tbaa !1444, !DIAssignID !2178
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2178, metadata ptr %91, metadata !DIExpression()), !dbg !2165
  %92 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !2179
  store i16 0, ptr %92, align 4, !dbg !2180, !tbaa !1457, !DIAssignID !2181
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2181, metadata ptr %92, metadata !DIExpression()), !dbg !2165
  %93 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #5, !dbg !2182
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #5, !dbg !2183
  call void @llvm.dbg.value(metadata ptr %93, metadata !1409, metadata !DIExpression()), !dbg !2184
  %94 = icmp eq ptr %93, null, !dbg !2185
  br i1 %94, label %281, label %95, !dbg !2186

95:                                               ; preds = %88
  %96 = load i32, ptr %93, align 4, !dbg !2187, !tbaa !1466
  %97 = icmp eq i32 %96, 1, !dbg !2188
  br i1 %97, label %98, label %281, !dbg !2189

98:                                               ; preds = %79, %85, %95
  %99 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #5, !dbg !2190, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %99, metadata !1222, metadata !DIExpression()), !dbg !2191
  %100 = load volatile i8, ptr %99, align 1, !dbg !2192, !tbaa !1341, !range !1343, !noundef !1344
  %101 = icmp eq i8 %100, 0, !dbg !2192
  br i1 %101, label %113, label %102, !dbg !2193

102:                                              ; preds = %98
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1475, metadata !DIExpression()), !dbg !2194
  %103 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 4, !dbg !2196
  %104 = load i8, ptr %103, align 1, !dbg !2196, !tbaa !1321
  %105 = and i8 %104, 1, !dbg !2197
  %106 = icmp eq i8 %105, 0, !dbg !2198
  br i1 %106, label %113, label %107, !dbg !2199

107:                                              ; preds = %102
  %108 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !2200
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !2060, metadata ptr %11, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i64 %108, metadata !1490, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i32 %30, metadata !1491, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata i16 %25, metadata !1492, metadata !DIExpression()), !dbg !2201
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #5, !dbg !2203
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !2201
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !2204
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !2206
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2206
  call void @llvm.dbg.label(metadata !1527), !dbg !2208
  %109 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !2209
  call void @llvm.dbg.value(metadata ptr %109, metadata !1512, metadata !DIExpression()), !dbg !2206
  store i64 0, ptr %109, align 8, !dbg !2209, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !2210
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !2206
  store i64 %108, ptr %11, align 8, !dbg !2211, !tbaa !1538, !DIAssignID !2212
  call void @llvm.dbg.assign(metadata i64 %108, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2212, metadata ptr %11, metadata !DIExpression()), !dbg !2201
  store i32 %30, ptr %109, align 8, !dbg !2213, !tbaa !1542, !DIAssignID !2214
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2214, metadata ptr %109, metadata !DIExpression()), !dbg !2201
  %110 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !2215
  store i16 %25, ptr %110, align 4, !dbg !2216, !tbaa !1546, !DIAssignID !2217
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2217, metadata ptr %110, metadata !DIExpression()), !dbg !2201
  %111 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #5, !dbg !2218
  call void @llvm.dbg.value(metadata ptr %111, metadata !1493, metadata !DIExpression()), !dbg !2201
  %112 = icmp eq ptr %111, null, !dbg !2219
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #5, !dbg !2220
  br i1 %112, label %113, label %281, !dbg !2221

113:                                              ; preds = %107, %102, %98
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1553, metadata !DIExpression()), !dbg !2222
  %114 = load i8, ptr %70, align 4, !dbg !2224, !tbaa !1361
  %115 = and i8 %114, 16, !dbg !2225
  %116 = icmp eq i8 %115, 0, !dbg !2226
  br i1 %116, label %172, label %117, !dbg !2227

117:                                              ; preds = %113
  call void @llvm.dbg.value(metadata ptr %47, metadata !1563, metadata !DIExpression()), !dbg !2228
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !2228
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !2053, metadata ptr %4, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !2054, metadata ptr %5, metadata !DIExpression()), !dbg !2232
  call void @llvm.dbg.value(metadata ptr %47, metadata !1580, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !2230
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !2230
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !2233
  store i64 %20, ptr %4, align 8, !dbg !2234, !DIAssignID !2235
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2235, metadata ptr %4, metadata !DIExpression()), !dbg !2230
  %118 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !2236
  %119 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2237
  %120 = load i16, ptr %119, align 2, !dbg !2237, !tbaa !1601
  store i16 %120, ptr %118, align 8, !dbg !2236, !tbaa !1602, !DIAssignID !2238
  call void @llvm.dbg.assign(metadata i16 %120, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !2238, metadata ptr %118, metadata !DIExpression()), !dbg !2230
  %121 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !2236
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !2239, metadata ptr %121, metadata !DIExpression()), !dbg !2230
  store i8 1, ptr %121, align 2, !dbg !2236, !DIAssignID !2240
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !2240, metadata ptr %121, metadata !DIExpression()), !dbg !2230
  %122 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !2236
  store i8 0, ptr %122, align 1, !dbg !2236, !tbaa !1607, !DIAssignID !2241
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !2241, metadata ptr %122, metadata !DIExpression()), !dbg !2230
  %123 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !2236
  store i32 0, ptr %123, align 4, !dbg !2236, !tbaa !1609, !DIAssignID !2242
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2242, metadata ptr %123, metadata !DIExpression()), !dbg !2230
  %124 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !2243
  call void @llvm.dbg.value(metadata ptr %124, metadata !1583, metadata !DIExpression()), !dbg !2230
  %125 = icmp eq ptr %124, null, !dbg !2244
  br i1 %125, label %126, label %127, !dbg !2245

126:                                              ; preds = %117
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2246
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  br label %172, !dbg !2247

127:                                              ; preds = %117
  %128 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !2248, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %128, metadata !1623, metadata !DIExpression()), !dbg !2250
  %129 = load volatile i8, ptr %128, align 1, !dbg !2251, !tbaa !1341, !range !1343, !noundef !1344
  %130 = icmp eq i8 %129, 0, !dbg !2251
  br i1 %130, label %134, label %131, !dbg !2252

131:                                              ; preds = %127
  %132 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !2253
  %133 = lshr i64 %132, 8, !dbg !2254
  br label %137, !dbg !2255

134:                                              ; preds = %127
  %135 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !2256
  %136 = udiv i64 %135, 1000000000, !dbg !2258
  br label %137, !dbg !2259

137:                                              ; preds = %131, %134
  %138 = phi i64 [ %133, %131 ], [ %136, %134 ], !dbg !2260
  call void @llvm.dbg.value(metadata i64 %138, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2232
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #5, !dbg !2261
  %139 = getelementptr inbounds %struct.lb_affinity_val, ptr %124, i64 0, i32 1, !dbg !2262
  %140 = load i32, ptr %139, align 1, !dbg !2262, !tbaa !1640
  store i32 %140, ptr %5, align 4, !dbg !2263, !tbaa !1643, !DIAssignID !2264
  call void @llvm.dbg.assign(metadata i32 %140, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2264, metadata ptr %5, metadata !DIExpression()), !dbg !2232
  %141 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !2263
  %142 = load i16, ptr %119, align 2, !dbg !2265, !tbaa !1601
  store i16 %142, ptr %141, align 4, !dbg !2263, !tbaa !1647, !DIAssignID !2266
  call void @llvm.dbg.assign(metadata i16 %142, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2266, metadata ptr %141, metadata !DIExpression()), !dbg !2232
  %143 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !2263
  store i16 0, ptr %143, align 2, !dbg !2263, !tbaa !1649, !DIAssignID !2267
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2267, metadata ptr %143, metadata !DIExpression()), !dbg !2232
  %144 = load volatile i64, ptr %124, align 1, !dbg !2268, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %144, metadata !1588, metadata !DIExpression()), !dbg !2269
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2270, !srcloc !1657
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1658, metadata !DIExpression()), !dbg !2272
  %145 = load i32, ptr %47, align 4, !dbg !2274, !tbaa !1444
  %146 = and i32 %145, 16777215, !dbg !2275
  call void @llvm.dbg.value(metadata i32 %146, metadata !1667, metadata !DIExpression()), !dbg !2276
  %147 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !2278, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %147, metadata !1672, metadata !DIExpression()), !dbg !2279
  %148 = load volatile i8, ptr %147, align 1, !dbg !2280, !tbaa !1341, !range !1343, !noundef !1344
  %149 = icmp eq i8 %148, 0, !dbg !2280
  br i1 %149, label %155, label %150, !dbg !2281

150:                                              ; preds = %137
  %151 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #5, !dbg !2282, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %151, metadata !1675, metadata !DIExpression()), !dbg !2283
  %152 = load volatile i32, ptr %151, align 4, !dbg !2284, !tbaa !1129
  %153 = mul i32 %152, %146, !dbg !2285
  %154 = lshr i32 %153, 8, !dbg !2286
  br label %155, !dbg !2287

155:                                              ; preds = %137, %150
  %156 = phi i32 [ %154, %150 ], [ %146, %137 ], !dbg !2276
  %157 = zext nneg i32 %156 to i64, !dbg !2288
  %158 = add i64 %144, %157, !dbg !2289
  %159 = and i64 %138, 4294967295, !dbg !2290
  %160 = icmp ugt i64 %158, %159, !dbg !2291
  br i1 %160, label %161, label %164, !dbg !2292

161:                                              ; preds = %155
  %162 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #5, !dbg !2293
  %163 = icmp eq ptr %162, null, !dbg !2293
  br i1 %163, label %164, label %166, !dbg !2294

164:                                              ; preds = %161, %155
  %165 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !2232
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2246
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  br label %172, !dbg !2247

166:                                              ; preds = %161
  call void @llvm.dbg.value(metadata i64 %159, metadata !1591, metadata !DIExpression()), !dbg !2296
  store volatile i64 %159, ptr %124, align 1, !dbg !2297, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2298, !srcloc !1657
  %167 = load i32, ptr %139, align 1, !dbg !2300, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2246
  call void @llvm.dbg.value(metadata i32 %167, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2070
  %168 = icmp eq i32 %167, 0, !dbg !2301
  br i1 %168, label %172, label %169, !dbg !2247

169:                                              ; preds = %166
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2059, metadata ptr %10, metadata !DIExpression()), !dbg !2302
  store i32 %167, ptr %10, align 4, !tbaa !1129, !DIAssignID !2304
  call void @llvm.dbg.assign(metadata i32 %167, metadata !1707, metadata !DIExpression(), metadata !2304, metadata ptr %10, metadata !DIExpression()), !dbg !2302
  %170 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #5, !dbg !2305
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !2306
  call void @llvm.dbg.value(metadata ptr %170, metadata !1205, metadata !DIExpression()), !dbg !2070
  %171 = icmp eq ptr %170, null, !dbg !2307
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2308, !srcloc !1721
  br i1 %171, label %172, label %214, !dbg !2309

172:                                              ; preds = %169, %166, %113, %126, %164
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !2310
  %173 = load i32, ptr %26, align 4, !dbg !2312, !tbaa !1259
  %174 = and i32 %173, 255, !dbg !2312
  %175 = icmp eq i32 %174, 6, !dbg !2313
  br i1 %175, label %176, label %179, !dbg !2312

176:                                              ; preds = %172
  %177 = call i32 inttoptr (i64 7 to ptr)() #5, !dbg !2314
  %178 = zext i32 %177 to i64, !dbg !2314
  br label %181, !dbg !2312

179:                                              ; preds = %172
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2315
  %180 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !2317
  br label %181, !dbg !2312

181:                                              ; preds = %176, %179
  %182 = phi i64 [ %178, %176 ], [ %180, %179 ], !dbg !2312
  %183 = load i16, ptr %48, align 4, !dbg !2318, !tbaa !1334
  %184 = zext i16 %183 to i64, !dbg !2319
  %185 = urem i64 %182, %184, !dbg !2320
  %186 = trunc i64 %185 to i16, !dbg !2321
  %187 = add nuw i16 %186, 1, !dbg !2321
  store i16 %187, ptr %32, align 2, !dbg !2322, !tbaa !1298, !DIAssignID !2323
  call void @llvm.dbg.assign(metadata i16 %187, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2323, metadata ptr %32, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata ptr %19, metadata !1749, metadata !DIExpression()), !dbg !2324
  call void @llvm.dbg.value(metadata ptr %19, metadata !1301, metadata !DIExpression()), !dbg !2326
  %188 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %19) #5, !dbg !2328
  call void @llvm.dbg.value(metadata ptr %188, metadata !1214, metadata !DIExpression()), !dbg !2070
  %189 = icmp eq ptr %188, null, !dbg !2329
  br i1 %189, label %190, label %200, !dbg !2330

190:                                              ; preds = %181
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2066, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2067, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2331
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %17) #5, !dbg !2333
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2334, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %18) #5, !dbg !2335
  store i64 21502558725, ptr %18, align 8, !dbg !2336, !DIAssignID !2337
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2337, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2338, metadata ptr %18, metadata !DIExpression()), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2339, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2331
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2340, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2331
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2341, metadata ptr %18, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2331
  %191 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18) #5, !dbg !2342
  call void @llvm.dbg.value(metadata ptr %191, metadata !1770, metadata !DIExpression()), !dbg !2331
  %192 = icmp eq ptr %191, null, !dbg !2343
  br i1 %192, label %196, label %193, !dbg !2344

193:                                              ; preds = %190
  %194 = load i64, ptr %191, align 8, !dbg !2345, !tbaa !1790
  %195 = add i64 %194, 1, !dbg !2345
  store i64 %195, ptr %191, align 8, !dbg !2345, !tbaa !1790
  br label %199, !dbg !2346

196:                                              ; preds = %190
  store i64 1, ptr %17, align 8, !dbg !2347, !tbaa !1790, !DIAssignID !2348
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2348, metadata ptr %17, metadata !DIExpression()), !dbg !2331
  %197 = getelementptr inbounds %struct.metrics_value, ptr %17, i64 0, i32 1, !dbg !2349
  store i64 0, ptr %197, align 8, !dbg !2350, !tbaa !1798, !DIAssignID !2351
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2351, metadata ptr %197, metadata !DIExpression()), !dbg !2331
  %198 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %18, ptr noundef nonnull %17, i32 noundef 0) #5, !dbg !2352
  br label %199

199:                                              ; preds = %193, %196
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %18) #5, !dbg !2353
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %17) #5, !dbg !2353
  br label %281, !dbg !2354

200:                                              ; preds = %181
  %201 = load i32, ptr %188, align 4, !dbg !2355, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %201, metadata !1216, metadata !DIExpression()), !dbg !2070
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2058, metadata ptr %9, metadata !DIExpression()), !dbg !2356
  store i32 %201, ptr %9, align 4, !tbaa !1129, !DIAssignID !2358
  call void @llvm.dbg.assign(metadata i32 %201, metadata !1707, metadata !DIExpression(), metadata !2358, metadata ptr %9, metadata !DIExpression()), !dbg !2356
  %202 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #5, !dbg !2359
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !2360
  call void @llvm.dbg.value(metadata ptr %202, metadata !1205, metadata !DIExpression()), !dbg !2070
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !2070
  %203 = icmp eq ptr %202, null, !dbg !2361
  br i1 %203, label %204, label %214, !dbg !2362

204:                                              ; preds = %200
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2064, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2065, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2363
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %15) #5, !dbg !2365
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2366, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %16) #5, !dbg !2367
  store i64 21503148550, ptr %16, align 8, !dbg !2368, !DIAssignID !2369
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2369, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2370, metadata ptr %16, metadata !DIExpression()), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2371, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2363
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2372, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2363
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2373, metadata ptr %16, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2363
  %205 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16) #5, !dbg !2374
  call void @llvm.dbg.value(metadata ptr %205, metadata !1770, metadata !DIExpression()), !dbg !2363
  %206 = icmp eq ptr %205, null, !dbg !2375
  br i1 %206, label %210, label %207, !dbg !2376

207:                                              ; preds = %204
  %208 = load i64, ptr %205, align 8, !dbg !2377, !tbaa !1790
  %209 = add i64 %208, 1, !dbg !2377
  store i64 %209, ptr %205, align 8, !dbg !2377, !tbaa !1790
  br label %213, !dbg !2378

210:                                              ; preds = %204
  store i64 1, ptr %15, align 8, !dbg !2379, !tbaa !1790, !DIAssignID !2380
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2380, metadata ptr %15, metadata !DIExpression()), !dbg !2363
  %211 = getelementptr inbounds %struct.metrics_value, ptr %15, i64 0, i32 1, !dbg !2381
  store i64 0, ptr %211, align 8, !dbg !2382, !tbaa !1798, !DIAssignID !2383
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2383, metadata ptr %211, metadata !DIExpression()), !dbg !2363
  %212 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %16, ptr noundef nonnull %15, i32 noundef 0) #5, !dbg !2384
  br label %213

213:                                              ; preds = %207, %210
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %16) #5, !dbg !2385
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %15) #5, !dbg !2385
  br label %281, !dbg !2386

214:                                              ; preds = %169, %200
  %215 = phi ptr [ %202, %200 ], [ %170, %169 ]
  %216 = phi i1 [ false, %200 ], [ true, %169 ]
  %217 = phi i32 [ %201, %200 ], [ %167, %169 ]
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2387, !srcloc !1838
  tail call void @llvm.dbg.value(metadata ptr %47, metadata !1553, metadata !DIExpression()), !dbg !2388
  %218 = load i8, ptr %70, align 4, !dbg !2390, !tbaa !1361
  %219 = and i8 %218, 16, !dbg !2391
  %220 = icmp eq i8 %219, 0, !dbg !2392
  %221 = or i1 %216, %220, !dbg !2393
  br i1 %221, label %244, label %222, !dbg !2393

222:                                              ; preds = %214
  call void @llvm.dbg.value(metadata ptr %47, metadata !1846, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.value(metadata i32 %217, metadata !1852, metadata !DIExpression()), !dbg !2394
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !2051, metadata ptr %2, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !2052, metadata ptr %3, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata ptr %47, metadata !1860, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !2396
  call void @llvm.dbg.value(metadata i32 %217, metadata !1863, metadata !DIExpression()), !dbg !2396
  %223 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !2398, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %223, metadata !1623, metadata !DIExpression()), !dbg !2400
  %224 = load volatile i8, ptr %223, align 1, !dbg !2401, !tbaa !1341, !range !1343, !noundef !1344
  %225 = icmp eq i8 %224, 0, !dbg !2401
  br i1 %225, label %229, label %226, !dbg !2402

226:                                              ; preds = %222
  %227 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !2403
  %228 = lshr i64 %227, 8, !dbg !2404
  br label %232, !dbg !2405

229:                                              ; preds = %222
  %230 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !2406
  %231 = udiv i64 %230, 1000000000, !dbg !2408
  br label %232, !dbg !2409

232:                                              ; preds = %226, %229
  %233 = phi i64 [ %228, %226 ], [ %231, %229 ], !dbg !2410
  call void @llvm.dbg.value(metadata i64 %233, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2396
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #5, !dbg !2411
  store i64 %20, ptr %2, align 8, !dbg !2412, !DIAssignID !2413
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2413, metadata ptr %2, metadata !DIExpression()), !dbg !2396
  %234 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !2414
  %235 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2415
  %236 = load i16, ptr %235, align 2, !dbg !2415, !tbaa !1601
  store i16 %236, ptr %234, align 8, !dbg !2414, !tbaa !1602, !DIAssignID !2416
  call void @llvm.dbg.assign(metadata i16 %236, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !2416, metadata ptr %234, metadata !DIExpression()), !dbg !2396
  %237 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !2414
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !2417, metadata ptr %237, metadata !DIExpression()), !dbg !2396
  store i8 1, ptr %237, align 2, !dbg !2414, !DIAssignID !2418
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !2418, metadata ptr %237, metadata !DIExpression()), !dbg !2396
  %238 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !2414
  store i8 0, ptr %238, align 1, !dbg !2414, !tbaa !1607, !DIAssignID !2419
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !2419, metadata ptr %238, metadata !DIExpression()), !dbg !2396
  %239 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !2414
  store i32 0, ptr %239, align 4, !dbg !2414, !tbaa !1609, !DIAssignID !2420
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2420, metadata ptr %239, metadata !DIExpression()), !dbg !2396
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #5, !dbg !2421
  %240 = and i64 %233, 4294967295, !dbg !2422
  store i64 %240, ptr %3, align 8, !dbg !2423, !tbaa !1894, !DIAssignID !2424
  call void @llvm.dbg.assign(metadata i64 %240, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2424, metadata ptr %3, metadata !DIExpression()), !dbg !2396
  %241 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !2423
  store i32 %217, ptr %241, align 8, !dbg !2423, !tbaa !1640, !DIAssignID !2425
  call void @llvm.dbg.assign(metadata i32 %217, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2425, metadata ptr %241, metadata !DIExpression()), !dbg !2396
  %242 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !2423
  store i32 0, ptr %242, align 4, !dbg !2423, !tbaa !1897, !DIAssignID !2426
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2426, metadata ptr %242, metadata !DIExpression()), !dbg !2396
  %243 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #5, !dbg !2427
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #5, !dbg !2428
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #5, !dbg !2428
  br label %244, !dbg !2429

244:                                              ; preds = %232, %214
  %245 = getelementptr inbounds %struct.lb4_backend, ptr %215, i64 0, i32 1, !dbg !2430
  %246 = getelementptr inbounds %struct.lb4_service, ptr %47, i64 0, i32 2, !dbg !2431
  %247 = load i16, ptr %246, align 2, !dbg !2431, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !2056, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !2057, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %215, metadata !1911, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i32 %30, metadata !1912, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i16 %25, metadata !1913, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i16 %247, metadata !1914, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #5, !dbg !2434
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !2435, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #5, !dbg !2436
  %248 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !2437
  store i64 0, ptr %248, align 8, !dbg !2437, !DIAssignID !2438
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !2438, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2439, metadata ptr undef, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2440
  %249 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !2442
  store i64 %249, ptr %8, align 8, !dbg !2443, !tbaa !1930, !DIAssignID !2444
  call void @llvm.dbg.assign(metadata i64 %249, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2444, metadata ptr %8, metadata !DIExpression()), !dbg !2432
  %250 = load i32, ptr %215, align 4, !dbg !2445, !tbaa !1934
  %251 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !2446
  store i32 %250, ptr %251, align 8, !dbg !2447, !tbaa !1938, !DIAssignID !2448
  call void @llvm.dbg.assign(metadata i32 %250, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2448, metadata ptr %251, metadata !DIExpression()), !dbg !2432
  %252 = load i16, ptr %245, align 4, !dbg !2449, !tbaa !1941
  %253 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !2450
  store i16 %252, ptr %253, align 4, !dbg !2451, !tbaa !1944, !DIAssignID !2452
  call void @llvm.dbg.assign(metadata i16 %252, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2452, metadata ptr %253, metadata !DIExpression()), !dbg !2432
  store i32 %30, ptr %7, align 4, !dbg !2453, !tbaa !1947, !DIAssignID !2454
  call void @llvm.dbg.assign(metadata i32 %30, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2454, metadata ptr %7, metadata !DIExpression()), !dbg !2432
  %254 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !2455
  store i16 %25, ptr %254, align 4, !dbg !2456, !tbaa !1952, !DIAssignID !2457
  call void @llvm.dbg.assign(metadata i16 %25, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2457, metadata ptr %254, metadata !DIExpression()), !dbg !2432
  %255 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !2458
  store i16 %247, ptr %255, align 2, !dbg !2459, !tbaa !1956, !DIAssignID !2460
  call void @llvm.dbg.assign(metadata i16 %247, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2460, metadata ptr %255, metadata !DIExpression()), !dbg !2432
  %256 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #5, !dbg !2461
  call void @llvm.dbg.value(metadata ptr %256, metadata !1915, metadata !DIExpression()), !dbg !2432
  %257 = icmp eq ptr %256, null, !dbg !2462
  br i1 %257, label %263, label %258, !dbg !2463

258:                                              ; preds = %244
  call void @llvm.dbg.value(metadata ptr %256, metadata !1962, metadata !DIExpression()), !dbg !2464
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !2464
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !2464
  tail call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !2466
  tail call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !2466
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !2466
  tail call void @llvm.dbg.value(metadata ptr %256, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !2466
  call void @llvm.dbg.label(metadata !1992), !dbg !2468
  tail call void @llvm.dbg.value(metadata ptr %256, metadata !1974, metadata !DIExpression()), !dbg !2466
  tail call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !2466
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !2466
  %259 = load i64, ptr %256, align 8, !dbg !2469, !tbaa !1534
  %260 = load i64, ptr %7, align 8, !dbg !2469, !tbaa !1534
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %259, i64 %260), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !2466
  %261 = icmp eq i64 %259, %260, !dbg !2470
  br i1 %261, label %262, label %263, !dbg !2471

262:                                              ; preds = %258
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !2472
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !2472
  br label %277, !dbg !2473

263:                                              ; preds = %244, %258
  %264 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #5, !dbg !2474
  call void @llvm.dbg.value(metadata i32 %264, metadata !1917, metadata !DIExpression()), !dbg !2432
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !2472
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !2472
  %265 = icmp slt i32 %264, 0, !dbg !2475
  br i1 %265, label %266, label %277, !dbg !2473

266:                                              ; preds = %263
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2062, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2063, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2476
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %13) #5, !dbg !2478
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2479, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %14) #5, !dbg !2480
  store i64 21504197127, ptr %14, align 8, !dbg !2481, !DIAssignID !2482
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2482, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2483, metadata ptr %14, metadata !DIExpression()), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2484, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2476
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2485, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2476
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2486, metadata ptr %14, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2476
  %267 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14) #5, !dbg !2487
  call void @llvm.dbg.value(metadata ptr %267, metadata !1770, metadata !DIExpression()), !dbg !2476
  %268 = icmp eq ptr %267, null, !dbg !2488
  br i1 %268, label %272, label %269, !dbg !2489

269:                                              ; preds = %266
  %270 = load i64, ptr %267, align 8, !dbg !2490, !tbaa !1790
  %271 = add i64 %270, 1, !dbg !2490
  store i64 %271, ptr %267, align 8, !dbg !2490, !tbaa !1790
  br label %275, !dbg !2491

272:                                              ; preds = %266
  store i64 1, ptr %13, align 8, !dbg !2492, !tbaa !1790, !DIAssignID !2493
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2493, metadata ptr %13, metadata !DIExpression()), !dbg !2476
  %273 = getelementptr inbounds %struct.metrics_value, ptr %13, i64 0, i32 1, !dbg !2494
  store i64 0, ptr %273, align 8, !dbg !2495, !tbaa !1798, !DIAssignID !2496
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2496, metadata ptr %273, metadata !DIExpression()), !dbg !2476
  %274 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %14, ptr noundef nonnull %13, i32 noundef 0) #5, !dbg !2497
  br label %275

275:                                              ; preds = %272, %269
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %14) #5, !dbg !2498
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %13) #5, !dbg !2498
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #5, !dbg !2499
  tail call void @llvm.dbg.value(metadata i32 -12, metadata !2050, metadata !DIExpression()), !dbg !2069
  %276 = call i1 @llvm.bpf.passthrough.i1.i1(i32 1, i1 false)
  br label %284, !dbg !2500

277:                                              ; preds = %262, %263
  %278 = load i32, ptr %215, align 4, !dbg !2502, !tbaa !1934
  store i32 %278, ptr %29, align 4, !dbg !2503, !tbaa !1261
  %279 = load i16, ptr %245, align 4, !dbg !2504, !tbaa !1941
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2505
  tail call void @llvm.dbg.value(metadata i16 %279, metadata !2038, metadata !DIExpression()), !dbg !2505
  %280 = zext i16 %279 to i32, !dbg !2507
  store i32 %280, ptr %22, align 8, !dbg !2508, !tbaa !1251
  br label %281, !dbg !2509

281:                                              ; preds = %60, %1, %88, %95, %68, %63, %43, %51, %74, %107, %199, %213, %277
  %282 = phi i1 [ false, %277 ], [ true, %213 ], [ true, %199 ], [ true, %51 ], [ false, %74 ], [ false, %107 ], [ false, %43 ], [ true, %68 ], [ false, %63 ], [ false, %95 ], [ false, %88 ], [ false, %1 ], [ false, %60 ], !dbg !2070
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %19) #5, !dbg !2499
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !2050, metadata !DIExpression()), !dbg !2069
  %283 = call i1 @llvm.bpf.passthrough.i1.i1(i32 1, i1 %282)
  br i1 %283, label %284, label %285, !dbg !2500

284:                                              ; preds = %275, %281
  br label %285, !dbg !2510

285:                                              ; preds = %281, %284
  %286 = phi i32 [ 0, %284 ], [ 1, %281 ], !dbg !2069
  ret i32 %286, !dbg !2512
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock4_recvmsg(ptr noundef %0) #0 section "cgroup/recvmsg4" !dbg !2513 {
  %2 = alloca i32, align 4, !DIAssignID !2516
  %3 = alloca %struct.metrics_value, align 8, !DIAssignID !2517
  %4 = alloca %struct.metrics_key, align 8, !DIAssignID !2518
  %5 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2519
  %6 = alloca %struct.lb4_key, align 4, !DIAssignID !2520
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2515, metadata !DIExpression()), !dbg !2521
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2522, metadata !DIExpression(), metadata !2519, metadata ptr %5, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2536, metadata !DIExpression(), metadata !2520, metadata ptr %6, metadata !DIExpression()), !dbg !2539
  call void @llvm.dbg.value(metadata ptr %0, metadata !2527, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.value(metadata ptr %0, metadata !2528, metadata !DIExpression()), !dbg !2537
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2516, metadata ptr %2, metadata !DIExpression()), !dbg !2540
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2540
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2), !dbg !2542
  %7 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2543
  %8 = load i32, ptr %7, align 8, !dbg !2543, !tbaa !1251
  store volatile i32 %8, ptr %2, align 4, !dbg !2544, !tbaa !1129, !DIAssignID !2545
  call void @llvm.dbg.assign(metadata i32 %8, metadata !1239, metadata !DIExpression(), metadata !2545, metadata ptr %2, metadata !DIExpression()), !dbg !2540
  %9 = load volatile i32, ptr %2, align 4, !dbg !2546, !tbaa !1129
  %10 = trunc i32 %9 to i16, !dbg !2547
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2), !dbg !2548
  call void @llvm.dbg.value(metadata i16 %10, metadata !2530, metadata !DIExpression()), !dbg !2537
  %11 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2549
  %12 = load i32, ptr %11, align 4, !dbg !2549, !tbaa !1259
  call void @llvm.dbg.value(metadata i32 %12, metadata !2531, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2537
  %13 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 1, !dbg !2550
  %14 = load i32, ptr %13, align 4, !dbg !2550, !tbaa !1261
  call void @llvm.dbg.value(metadata i32 %14, metadata !2532, metadata !DIExpression()), !dbg !2537
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %5) #5, !dbg !2551
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !2552
  %15 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef %0) #5, !dbg !2554
  store i64 %15, ptr %5, align 8, !dbg !2555, !tbaa !1930, !DIAssignID !2556
  call void @llvm.dbg.assign(metadata i64 %15, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2556, metadata ptr %5, metadata !DIExpression()), !dbg !2537
  %16 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 1, !dbg !2555
  store i32 %14, ptr %16, align 8, !dbg !2555, !tbaa !1938, !DIAssignID !2557
  call void @llvm.dbg.assign(metadata i32 %14, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2557, metadata ptr %16, metadata !DIExpression()), !dbg !2537
  %17 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 2, !dbg !2555
  store i16 %10, ptr %17, align 4, !dbg !2555, !tbaa !1944, !DIAssignID !2558
  call void @llvm.dbg.assign(metadata i16 %10, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2558, metadata ptr %17, metadata !DIExpression()), !dbg !2537
  %18 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %5, i64 0, i32 3, !dbg !2555
  store i16 0, ptr %18, align 2, !dbg !2555, !tbaa !2559, !DIAssignID !2560
  call void @llvm.dbg.assign(metadata i16 0, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 112, 16), metadata !2560, metadata ptr %18, metadata !DIExpression()), !dbg !2537
  %19 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %5) #5, !dbg !2561
  call void @llvm.dbg.value(metadata ptr %19, metadata !2529, metadata !DIExpression()), !dbg !2537
  %20 = icmp eq ptr %19, null, !dbg !2562
  br i1 %20, label %71, label %21, !dbg !2563

21:                                               ; preds = %1
  %22 = trunc i32 %12 to i8, !dbg !2549
  call void @llvm.dbg.value(metadata i8 %22, metadata !2531, metadata !DIExpression()), !dbg !2537
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %6) #5, !dbg !2564
  %23 = load i32, ptr %19, align 4, !dbg !2565, !tbaa !1947
  store i32 %23, ptr %6, align 4, !dbg !2566, !tbaa !1264, !DIAssignID !2567
  call void @llvm.dbg.assign(metadata i32 %23, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2567, metadata ptr %6, metadata !DIExpression()), !dbg !2539
  %24 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 1, !dbg !2566
  %25 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %19, i64 0, i32 1, !dbg !2568
  %26 = load i16, ptr %25, align 4, !dbg !2568, !tbaa !1952
  store i16 %26, ptr %24, align 4, !dbg !2566, !tbaa !1268, !DIAssignID !2569
  call void @llvm.dbg.assign(metadata i16 %26, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2569, metadata ptr %24, metadata !DIExpression()), !dbg !2539
  %27 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 2, !dbg !2566
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2570, metadata ptr %27, metadata !DIExpression()), !dbg !2539
  %28 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 3, !dbg !2566
  store i8 %22, ptr %28, align 4, !dbg !2566, !tbaa !1271, !DIAssignID !2571
  call void @llvm.dbg.assign(metadata i8 %22, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2571, metadata ptr %28, metadata !DIExpression()), !dbg !2539
  %29 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 4, !dbg !2566
  call void @llvm.dbg.assign(metadata i8 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2572, metadata ptr %29, metadata !DIExpression()), !dbg !2539
  %30 = getelementptr inbounds %struct.lb4_key, ptr %6, i64 0, i32 5, !dbg !2566
  store i16 0, ptr %30, align 2, !dbg !2566, !DIAssignID !2573
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2573, metadata ptr %30, metadata !DIExpression()), !dbg !2539
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !2574, metadata ptr undef, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !2577, metadata ptr undef, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.value(metadata ptr %6, metadata !1289, metadata !DIExpression()), !dbg !2575
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2575
  store i16 0, ptr %27, align 2, !dbg !2578, !tbaa !1298
  store i8 0, ptr %29, align 1, !dbg !2579, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %6, metadata !1301, metadata !DIExpression()), !dbg !2580
  %31 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %6) #5, !dbg !2582
  call void @llvm.dbg.value(metadata ptr %31, metadata !1291, metadata !DIExpression()), !dbg !2575
  %32 = icmp eq ptr %31, null, !dbg !2583
  br i1 %32, label %41, label %33, !dbg !2584

33:                                               ; preds = %21
  tail call void @llvm.dbg.value(metadata ptr %31, metadata !1312, metadata !DIExpression()), !dbg !2585
  %34 = getelementptr inbounds %struct.lb4_service, ptr %31, i64 0, i32 4, !dbg !2587
  %35 = load i8, ptr %34, align 1, !dbg !2587, !tbaa !1321
  %36 = and i8 %35, 32, !dbg !2588
  %37 = icmp eq i8 %36, 0, !dbg !2589
  br i1 %37, label %44, label %38, !dbg !2590

38:                                               ; preds = %33
  store i8 1, ptr %29, align 1, !dbg !2591, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %6, metadata !1301, metadata !DIExpression()), !dbg !2592
  %39 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %6) #5, !dbg !2594
  call void @llvm.dbg.value(metadata ptr %39, metadata !2533, metadata !DIExpression()), !dbg !2539
  %40 = icmp eq ptr %39, null, !dbg !2595
  br i1 %40, label %41, label %44, !dbg !2597

41:                                               ; preds = %21, %38
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2598
  call void @llvm.dbg.value(metadata ptr null, metadata !1233, metadata !DIExpression()), !dbg !2598
  %42 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !2601
  call void @llvm.dbg.value(metadata i64 %42, metadata !1234, metadata !DIExpression()), !dbg !2598
  %43 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !2602
  br label %55, !dbg !2603

44:                                               ; preds = %33, %38
  %45 = phi ptr [ %39, %38 ], [ %31, %33 ]
  call void @llvm.dbg.value(metadata ptr %45, metadata !2533, metadata !DIExpression()), !dbg !2539
  %46 = getelementptr inbounds %struct.lb4_service, ptr %45, i64 0, i32 2, !dbg !2604
  %47 = load i16, ptr %46, align 2, !dbg !2604, !tbaa !1601
  %48 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %19, i64 0, i32 2, !dbg !2606
  %49 = load i16, ptr %48, align 2, !dbg !2606, !tbaa !1956
  %50 = icmp eq i16 %47, %49, !dbg !2607
  br i1 %50, label %51, label %55, !dbg !2608

51:                                               ; preds = %44
  %52 = getelementptr inbounds %struct.lb4_service, ptr %45, i64 0, i32 1, !dbg !2609
  %53 = load i16, ptr %52, align 4, !dbg !2609, !tbaa !1334
  %54 = icmp eq i16 %53, 0, !dbg !2610
  br i1 %54, label %55, label %66, !dbg !2611

55:                                               ; preds = %41, %51, %44
  %56 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %5) #5, !dbg !2612
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2517, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2518, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 1, metadata !1766, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 8, metadata !1767, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i16 612, metadata !1768, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !2614
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #5, !dbg !2616
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !2617, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4) #5, !dbg !2618
  store i64 21514944776, ptr %4, align 8, !dbg !2619, !DIAssignID !2620
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !2620, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 8, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !2621, metadata ptr %4, metadata !DIExpression()), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 1, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !2622, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !2614
  call void @llvm.dbg.assign(metadata i16 612, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !2623, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !2614
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !2624, metadata ptr %4, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !2614
  %57 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4) #5, !dbg !2625
  call void @llvm.dbg.value(metadata ptr %57, metadata !1770, metadata !DIExpression()), !dbg !2614
  %58 = icmp eq ptr %57, null, !dbg !2626
  br i1 %58, label %62, label %59, !dbg !2627

59:                                               ; preds = %55
  %60 = load i64, ptr %57, align 8, !dbg !2628, !tbaa !1790
  %61 = add i64 %60, 1, !dbg !2628
  store i64 %61, ptr %57, align 8, !dbg !2628, !tbaa !1790
  br label %65, !dbg !2629

62:                                               ; preds = %55
  store i64 1, ptr %3, align 8, !dbg !2630, !tbaa !1790, !DIAssignID !2631
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2631, metadata ptr %3, metadata !DIExpression()), !dbg !2614
  %63 = getelementptr inbounds %struct.metrics_value, ptr %3, i64 0, i32 1, !dbg !2632
  store i64 0, ptr %63, align 8, !dbg !2633, !tbaa !1798, !DIAssignID !2634
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !2634, metadata ptr %63, metadata !DIExpression()), !dbg !2614
  %64 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %4, ptr noundef nonnull %3, i32 noundef 0) #5, !dbg !2635
  br label %65

65:                                               ; preds = %59, %62
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4) #5, !dbg !2636
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #5, !dbg !2636
  br label %70, !dbg !2637

66:                                               ; preds = %51
  %67 = load i32, ptr %19, align 4, !dbg !2638, !tbaa !1947
  store i32 %67, ptr %13, align 4, !dbg !2639, !tbaa !1261
  %68 = load i16, ptr %25, align 4, !dbg !2640, !tbaa !1952
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !2641
  tail call void @llvm.dbg.value(metadata i16 %68, metadata !2038, metadata !DIExpression()), !dbg !2641
  %69 = zext i16 %68 to i32, !dbg !2643
  store i32 %69, ptr %7, align 8, !dbg !2644, !tbaa !1251
  br label %70, !dbg !2645

70:                                               ; preds = %66, %65
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %6) #5, !dbg !2646
  br label %71

71:                                               ; preds = %1, %70
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %5) #5, !dbg !2647
  ret i32 1, !dbg !2648
}

; Function Attrs: nounwind
define dso_local i32 @cil_sock6_connect(ptr noundef %0) #0 section "cgroup/connect6" !dbg !2649 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2653
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !2654
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !2655
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !2656
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !2657
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !2658
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !2659
  %9 = alloca i32, align 4, !DIAssignID !2660
  %10 = alloca i32, align 4, !DIAssignID !2661
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !2662
  %12 = alloca i32, align 4, !DIAssignID !2663
  %13 = alloca i32, align 4, !DIAssignID !2664
  %14 = alloca %struct.metrics_value, align 8, !DIAssignID !2665
  %15 = alloca %struct.metrics_key, align 8, !DIAssignID !2666
  %16 = alloca %struct.metrics_value, align 8, !DIAssignID !2667
  %17 = alloca %struct.metrics_key, align 8, !DIAssignID !2668
  %18 = alloca %struct.metrics_value, align 8, !DIAssignID !2669
  %19 = alloca %struct.metrics_key, align 8, !DIAssignID !2670
  %20 = alloca %struct.lb4_key, align 4, !DIAssignID !2671
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !2651, metadata !DIExpression()), !dbg !2672
  call void @llvm.dbg.value(metadata ptr %0, metadata !2673, metadata !DIExpression()), !dbg !2680
  call void @llvm.dbg.value(metadata i1 false, metadata !2678, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2680
  call void @llvm.dbg.value(metadata i1 true, metadata !2679, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2680
  call void @llvm.dbg.value(metadata ptr %0, metadata !2682, metadata !DIExpression()), !dbg !2690
  call void @llvm.dbg.value(metadata i1 false, metadata !2685, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2690
  call void @llvm.dbg.value(metadata i1 true, metadata !2686, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2690
  call void @llvm.dbg.value(metadata ptr %0, metadata !2692, metadata !DIExpression()), !dbg !2699
  call void @llvm.dbg.value(metadata ptr undef, metadata !2698, metadata !DIExpression()), !dbg !2699
  %21 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !2701
  %22 = load i32, ptr %21, align 8, !dbg !2702, !tbaa !1129
  %23 = zext i32 %22 to i64, !dbg !2703
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !2704, !srcloc !2705
  %24 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !2706
  %25 = load i32, ptr %24, align 4, !dbg !2706, !tbaa !1129
  %26 = zext i32 %25 to i64, !dbg !2707
  %27 = shl nuw i64 %26, 32, !dbg !2707
  %28 = or disjoint i64 %27, %23, !dbg !2707
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !2708, !srcloc !2709
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !2710
  %30 = load i32, ptr %29, align 8, !dbg !2710, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !2688, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !2711, !srcloc !2712
  %31 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !2713
  %32 = load i32, ptr %31, align 4, !dbg !2713, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2688, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !2714, !srcloc !2715
  call void @llvm.dbg.value(metadata ptr undef, metadata !2716, metadata !DIExpression()), !dbg !2726
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2726
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2726
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2726
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2726
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !2725, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !2726
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2729, metadata !DIExpression()), !dbg !2735
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2734, metadata !DIExpression()), !dbg !2735
  %33 = icmp eq i64 %28, 0, !dbg !2737
  %34 = icmp eq i32 %30, -65536
  %35 = select i1 %33, i1 %34, i1 false, !dbg !2739
  br i1 %35, label %36, label %302, !dbg !2739

36:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2688, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !2740
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !2740
  call void @llvm.dbg.value(metadata i64 72, metadata !1504, metadata !DIExpression()), !dbg !2740
  call void @llvm.dbg.value(metadata i64 72, metadata !1507, metadata !DIExpression()), !dbg !2742
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !2742
  call void @llvm.dbg.label(metadata !1520), !dbg !2744
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1521), !dbg !2745
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1522), !dbg !2746
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1523), !dbg !2747
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1524), !dbg !2748
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1525), !dbg !2749
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1526), !dbg !2750
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1527), !dbg !2751
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1528), !dbg !2752
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  %37 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !2753
  %38 = load i32, ptr %37, align 4, !dbg !2753, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %38, metadata !2687, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !2690
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !2690
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2663, metadata ptr %12, metadata !DIExpression()), !dbg !2754
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !2754
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !2756
  %39 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !2757
  %40 = load i32, ptr %39, align 8, !dbg !2757, !tbaa !1251
  store volatile i32 %40, ptr %12, align 4, !dbg !2758, !tbaa !1129, !DIAssignID !2759
  call void @llvm.dbg.assign(metadata i32 %40, metadata !1239, metadata !DIExpression(), metadata !2759, metadata ptr %12, metadata !DIExpression()), !dbg !2754
  %41 = load volatile i32, ptr %12, align 4, !dbg !2760, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !2761
  %42 = and i32 %41, 65535, !dbg !2762
  tail call void @llvm.dbg.value(metadata i32 %42, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !2690
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !2671, metadata ptr %20, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata ptr undef, metadata !1199, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i1 false, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2763
  call void @llvm.dbg.value(metadata i1 true, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2763
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !2765
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !2765
  %43 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !2767
  call void @llvm.dbg.value(metadata i64 %43, metadata !1234, metadata !DIExpression()), !dbg !2765
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !1203, metadata !DIExpression()), !dbg !2763
  %44 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !2768
  call void @llvm.dbg.value(metadata !DIArgList(i64 %43, i64 %44), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2763
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !2664, metadata ptr %13, metadata !DIExpression()), !dbg !2769
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !2769
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13), !dbg !2771
  store volatile i32 %42, ptr %13, align 4, !dbg !2772, !tbaa !1129, !DIAssignID !2773
  call void @llvm.dbg.assign(metadata i32 %42, metadata !1239, metadata !DIExpression(), metadata !2773, metadata ptr %13, metadata !DIExpression()), !dbg !2769
  %45 = load volatile i32, ptr %13, align 4, !dbg !2774, !tbaa !1129
  %46 = trunc i32 %45 to i16, !dbg !2775
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13), !dbg !2776
  call void @llvm.dbg.value(metadata i16 %46, metadata !1211, metadata !DIExpression()), !dbg !2763
  %47 = trunc i32 %38 to i8, !dbg !2777
  call void @llvm.dbg.value(metadata i8 %47, metadata !1212, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i32 %32, metadata !1213, metadata !DIExpression()), !dbg !2763
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %20) #5, !dbg !2778
  store i32 %32, ptr %20, align 4, !dbg !2779, !tbaa !1264, !DIAssignID !2780
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2780, metadata ptr %20, metadata !DIExpression()), !dbg !2763
  %48 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 1, !dbg !2779
  store i16 %46, ptr %48, align 4, !dbg !2779, !tbaa !1268, !DIAssignID !2781
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2781, metadata ptr %48, metadata !DIExpression()), !dbg !2763
  %49 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 2, !dbg !2779
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2782, metadata ptr %49, metadata !DIExpression()), !dbg !2763
  %50 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 3, !dbg !2779
  store i8 %47, ptr %50, align 4, !dbg !2779, !tbaa !1271, !DIAssignID !2783
  call void @llvm.dbg.assign(metadata i8 %47, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !2783, metadata ptr %50, metadata !DIExpression()), !dbg !2763
  %51 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 4, !dbg !2779
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !2784, metadata ptr %51, metadata !DIExpression()), !dbg !2763
  %52 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 5, !dbg !2779
  store i16 0, ptr %52, align 2, !dbg !2779, !DIAssignID !2785
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !2785, metadata ptr %52, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 %47, metadata !1275, metadata !DIExpression()), !dbg !2786
  switch i8 %47, label %297 [
    i8 6, label %53
    i8 -120, label %53
    i8 17, label %53
  ], !dbg !2788

53:                                               ; preds = %36, %36, %36
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !2789, metadata ptr undef, metadata !DIExpression()), !dbg !2790
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !2792, metadata ptr undef, metadata !DIExpression()), !dbg !2790
  call void @llvm.dbg.value(metadata ptr %20, metadata !1289, metadata !DIExpression()), !dbg !2790
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !2790
  store i16 0, ptr %49, align 2, !dbg !2793, !tbaa !1298
  store i8 0, ptr %51, align 1, !dbg !2794, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !2795
  %54 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !2797
  call void @llvm.dbg.value(metadata ptr %54, metadata !1291, metadata !DIExpression()), !dbg !2790
  %55 = icmp eq ptr %54, null, !dbg !2798
  br i1 %55, label %297, label %56, !dbg !2799

56:                                               ; preds = %53
  call void @llvm.dbg.value(metadata ptr %54, metadata !1312, metadata !DIExpression()), !dbg !2800
  %57 = getelementptr inbounds %struct.lb4_service, ptr %54, i64 0, i32 4, !dbg !2802
  %58 = load i8, ptr %57, align 1, !dbg !2802, !tbaa !1321
  %59 = and i8 %58, 32, !dbg !2803
  %60 = icmp eq i8 %59, 0, !dbg !2804
  br i1 %60, label %64, label %61, !dbg !2805

61:                                               ; preds = %56
  store i8 1, ptr %51, align 1, !dbg !2806, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !2807
  %62 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !2809
  call void @llvm.dbg.value(metadata ptr %62, metadata !1208, metadata !DIExpression()), !dbg !2763
  %63 = icmp eq ptr %62, null, !dbg !2810
  br i1 %63, label %297, label %64, !dbg !2811

64:                                               ; preds = %56, %61
  %65 = phi ptr [ %62, %61 ], [ %54, %56 ]
  call void @llvm.dbg.value(metadata ptr %65, metadata !1208, metadata !DIExpression()), !dbg !2763
  %66 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 1, !dbg !2812
  %67 = load i16, ptr %66, align 4, !dbg !2812, !tbaa !1334
  %68 = icmp eq i16 %67, 0, !dbg !2813
  br i1 %68, label %69, label %86, !dbg !2814

69:                                               ; preds = %64
  %70 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #5, !dbg !2815, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %70, metadata !1217, metadata !DIExpression()), !dbg !2816
  %71 = load volatile i8, ptr %70, align 1, !dbg !2817, !tbaa !1341, !range !1343, !noundef !1344
  %72 = icmp eq i8 %71, 0, !dbg !2817
  br i1 %72, label %73, label %297, !dbg !2818

73:                                               ; preds = %69
  call void @llvm.dbg.value(metadata ptr %65, metadata !1346, metadata !DIExpression()), !dbg !2819
  call void @llvm.dbg.value(metadata ptr %65, metadata !1354, metadata !DIExpression()), !dbg !2821
  %74 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 3, !dbg !2823
  %75 = load i8, ptr %74, align 4, !dbg !2823, !tbaa !1361
  %76 = and i8 %75, 35, !dbg !2824
  %77 = icmp eq i8 %76, 0, !dbg !2825
  br i1 %77, label %81, label %78, !dbg !2826

78:                                               ; preds = %73
  call void @llvm.dbg.value(metadata ptr %65, metadata !1365, metadata !DIExpression()), !dbg !2827
  %79 = and i8 %75, 4, !dbg !2829
  %80 = icmp eq i8 %79, 0, !dbg !2830
  br i1 %80, label %299, label %297, !dbg !2831

81:                                               ; preds = %73
  call void @llvm.dbg.value(metadata ptr %65, metadata !1354, metadata !DIExpression()), !dbg !2832
  call void @llvm.dbg.value(metadata ptr %65, metadata !1375, metadata !DIExpression()), !dbg !2834
  %82 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 4, !dbg !2836
  %83 = load i8, ptr %82, align 1, !dbg !2836, !tbaa !1321
  %84 = and i8 %83, 16, !dbg !2837
  %85 = icmp eq i8 %84, 0, !dbg !2838
  br i1 %85, label %299, label %297, !dbg !2839

86:                                               ; preds = %64
  call void @llvm.dbg.value(metadata ptr %65, metadata !1385, metadata !DIExpression()), !dbg !2840
  call void @llvm.dbg.value(metadata ptr %65, metadata !1391, metadata !DIExpression()), !dbg !2842
  %87 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 3, !dbg !2844
  %88 = load i8, ptr %87, align 4, !dbg !2844, !tbaa !1361
  %89 = and i8 %88, 8, !dbg !2845
  %90 = icmp eq i8 %89, 0, !dbg !2846
  br i1 %90, label %91, label %96, !dbg !2847

91:                                               ; preds = %86
  %92 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 4, !dbg !2848
  %93 = load i8, ptr %92, align 1, !dbg !2848, !tbaa !1321
  %94 = and i8 %93, 8, !dbg !2849
  %95 = icmp eq i8 %94, 0, !dbg !2847
  br i1 %95, label %102, label %299, !dbg !2850

96:                                               ; preds = %86
  call void @llvm.dbg.value(metadata ptr %65, metadata !1403, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata i32 %32, metadata !1408, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata ptr %65, metadata !1417, metadata !DIExpression()), !dbg !2853
  %97 = and i8 %88, 1, !dbg !2855
  %98 = icmp eq i8 %97, 0, !dbg !2856
  call void @llvm.dbg.value(metadata ptr %65, metadata !1391, metadata !DIExpression()), !dbg !2857
  %99 = and i32 %32, 255
  %100 = icmp eq i32 %99, 127
  %101 = select i1 %98, i1 %100, i1 false, !dbg !2859
  br i1 %101, label %115, label %105, !dbg !2859

102:                                              ; preds = %91
  call void @llvm.dbg.value(metadata ptr %65, metadata !1403, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata i32 %32, metadata !1408, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata ptr %65, metadata !1417, metadata !DIExpression()), !dbg !2853
  %103 = and i8 %88, 1, !dbg !2855
  %104 = icmp eq i8 %103, 0, !dbg !2856
  br i1 %104, label %115, label %105, !dbg !2859

105:                                              ; preds = %102, %96
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !2657, metadata ptr %6, metadata !DIExpression()), !dbg !2860
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !2860
  call void @llvm.dbg.value(metadata i32 %32, metadata !1433, metadata !DIExpression()), !dbg !2860
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !2860
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !2860
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #5, !dbg !2862
  %106 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !2863
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %106, i8 0, i64 18, i1 false), !dbg !2863, !DIAssignID !2864
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !2864, metadata ptr %6, metadata !DIExpression()), !dbg !2860
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !2865, metadata ptr undef, metadata !DIExpression()), !dbg !2860
  store i32 64, ptr %6, align 4, !dbg !2866, !tbaa.struct !1443, !DIAssignID !2867
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2867, metadata ptr %6, metadata !DIExpression()), !dbg !2860
  %107 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !2868
  store i8 1, ptr %107, align 1, !dbg !2869, !tbaa !1448, !DIAssignID !2870
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !2870, metadata ptr %107, metadata !DIExpression()), !dbg !2860
  %108 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !2871
  store i32 %32, ptr %108, align 4, !dbg !2872, !tbaa !1444, !DIAssignID !2873
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2873, metadata ptr %108, metadata !DIExpression()), !dbg !2860
  %109 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !2874
  store i16 0, ptr %109, align 4, !dbg !2875, !tbaa !1457, !DIAssignID !2876
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2876, metadata ptr %109, metadata !DIExpression()), !dbg !2860
  %110 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #5, !dbg !2877
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #5, !dbg !2878
  call void @llvm.dbg.value(metadata ptr %110, metadata !1409, metadata !DIExpression()), !dbg !2879
  %111 = icmp eq ptr %110, null, !dbg !2880
  br i1 %111, label %297, label %112, !dbg !2881

112:                                              ; preds = %105
  %113 = load i32, ptr %110, align 4, !dbg !2882, !tbaa !1466
  %114 = icmp eq i32 %113, 1, !dbg !2883
  br i1 %114, label %115, label %297, !dbg !2884

115:                                              ; preds = %96, %102, %112
  %116 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #5, !dbg !2885, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %116, metadata !1222, metadata !DIExpression()), !dbg !2886
  %117 = load volatile i8, ptr %116, align 1, !dbg !2887, !tbaa !1341, !range !1343, !noundef !1344
  %118 = icmp eq i8 %117, 0, !dbg !2887
  br i1 %118, label %130, label %119, !dbg !2888

119:                                              ; preds = %115
  call void @llvm.dbg.value(metadata ptr %65, metadata !1475, metadata !DIExpression()), !dbg !2889
  %120 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 4, !dbg !2891
  %121 = load i8, ptr %120, align 1, !dbg !2891, !tbaa !1321
  %122 = and i8 %121, 1, !dbg !2892
  %123 = icmp eq i8 %122, 0, !dbg !2893
  br i1 %123, label %130, label %124, !dbg !2894

124:                                              ; preds = %119
  %125 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !2895
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !2662, metadata ptr %11, metadata !DIExpression()), !dbg !2896
  call void @llvm.dbg.value(metadata i64 %125, metadata !1490, metadata !DIExpression()), !dbg !2896
  call void @llvm.dbg.value(metadata i32 %32, metadata !1491, metadata !DIExpression()), !dbg !2896
  call void @llvm.dbg.value(metadata i16 %46, metadata !1492, metadata !DIExpression()), !dbg !2896
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #5, !dbg !2898
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !2896
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !2899
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !2899
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !2899
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !2901
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !2901
  call void @llvm.dbg.label(metadata !1527), !dbg !2903
  %126 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !2904
  call void @llvm.dbg.value(metadata ptr %126, metadata !1512, metadata !DIExpression()), !dbg !2901
  store i64 0, ptr %126, align 8, !dbg !2904, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !2905
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !2901
  store i64 %125, ptr %11, align 8, !dbg !2906, !tbaa !1538, !DIAssignID !2907
  call void @llvm.dbg.assign(metadata i64 %125, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2907, metadata ptr %11, metadata !DIExpression()), !dbg !2896
  store i32 %32, ptr %126, align 8, !dbg !2908, !tbaa !1542, !DIAssignID !2909
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !2909, metadata ptr %126, metadata !DIExpression()), !dbg !2896
  %127 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !2910
  store i16 %46, ptr %127, align 4, !dbg !2911, !tbaa !1546, !DIAssignID !2912
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !2912, metadata ptr %127, metadata !DIExpression()), !dbg !2896
  %128 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #5, !dbg !2913
  call void @llvm.dbg.value(metadata ptr %128, metadata !1493, metadata !DIExpression()), !dbg !2896
  %129 = icmp eq ptr %128, null, !dbg !2914
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #5, !dbg !2915
  br i1 %129, label %130, label %297, !dbg !2916

130:                                              ; preds = %124, %119, %115
  call void @llvm.dbg.value(metadata ptr %65, metadata !1553, metadata !DIExpression()), !dbg !2917
  %131 = load i8, ptr %87, align 4, !dbg !2919, !tbaa !1361
  %132 = and i8 %131, 16, !dbg !2920
  %133 = icmp eq i8 %132, 0, !dbg !2921
  br i1 %133, label %189, label %134, !dbg !2922

134:                                              ; preds = %130
  call void @llvm.dbg.value(metadata ptr %65, metadata !1563, metadata !DIExpression()), !dbg !2923
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !2923
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !2655, metadata ptr %4, metadata !DIExpression()), !dbg !2925
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !2656, metadata ptr %5, metadata !DIExpression()), !dbg !2927
  call void @llvm.dbg.value(metadata ptr %65, metadata !1580, metadata !DIExpression()), !dbg !2925
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !2925
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !2925
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !2928
  store i64 %43, ptr %4, align 8, !dbg !2929, !DIAssignID !2930
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !2930, metadata ptr %4, metadata !DIExpression()), !dbg !2925
  %135 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !2931
  %136 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 2, !dbg !2932
  %137 = load i16, ptr %136, align 2, !dbg !2932, !tbaa !1601
  store i16 %137, ptr %135, align 8, !dbg !2931, !tbaa !1602, !DIAssignID !2933
  call void @llvm.dbg.assign(metadata i16 %137, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !2933, metadata ptr %135, metadata !DIExpression()), !dbg !2925
  %138 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !2931
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !2934, metadata ptr %138, metadata !DIExpression()), !dbg !2925
  store i8 1, ptr %138, align 2, !dbg !2931, !DIAssignID !2935
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !2935, metadata ptr %138, metadata !DIExpression()), !dbg !2925
  %139 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !2931
  store i8 0, ptr %139, align 1, !dbg !2931, !tbaa !1607, !DIAssignID !2936
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !2936, metadata ptr %139, metadata !DIExpression()), !dbg !2925
  %140 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !2931
  store i32 0, ptr %140, align 4, !dbg !2931, !tbaa !1609, !DIAssignID !2937
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !2937, metadata ptr %140, metadata !DIExpression()), !dbg !2925
  %141 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !2938
  call void @llvm.dbg.value(metadata ptr %141, metadata !1583, metadata !DIExpression()), !dbg !2925
  %142 = icmp eq ptr %141, null, !dbg !2939
  br i1 %142, label %143, label %144, !dbg !2940

143:                                              ; preds = %134
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2941
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2763
  br label %189, !dbg !2942

144:                                              ; preds = %134
  %145 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !2943, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %145, metadata !1623, metadata !DIExpression()), !dbg !2945
  %146 = load volatile i8, ptr %145, align 1, !dbg !2946, !tbaa !1341, !range !1343, !noundef !1344
  %147 = icmp eq i8 %146, 0, !dbg !2946
  br i1 %147, label %151, label %148, !dbg !2947

148:                                              ; preds = %144
  %149 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !2948
  %150 = lshr i64 %149, 8, !dbg !2949
  br label %154, !dbg !2950

151:                                              ; preds = %144
  %152 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !2951
  %153 = udiv i64 %152, 1000000000, !dbg !2953
  br label %154, !dbg !2954

154:                                              ; preds = %151, %148
  %155 = phi i64 [ %150, %148 ], [ %153, %151 ], !dbg !2955
  call void @llvm.dbg.value(metadata i64 %155, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2927
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #5, !dbg !2956
  %156 = getelementptr inbounds %struct.lb_affinity_val, ptr %141, i64 0, i32 1, !dbg !2957
  %157 = load i32, ptr %156, align 1, !dbg !2957, !tbaa !1640
  store i32 %157, ptr %5, align 4, !dbg !2958, !tbaa !1643, !DIAssignID !2959
  call void @llvm.dbg.assign(metadata i32 %157, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !2959, metadata ptr %5, metadata !DIExpression()), !dbg !2927
  %158 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !2958
  %159 = load i16, ptr %136, align 2, !dbg !2960, !tbaa !1601
  store i16 %159, ptr %158, align 4, !dbg !2958, !tbaa !1647, !DIAssignID !2961
  call void @llvm.dbg.assign(metadata i16 %159, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !2961, metadata ptr %158, metadata !DIExpression()), !dbg !2927
  %160 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !2958
  store i16 0, ptr %160, align 2, !dbg !2958, !tbaa !1649, !DIAssignID !2962
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !2962, metadata ptr %160, metadata !DIExpression()), !dbg !2927
  %161 = load volatile i64, ptr %141, align 1, !dbg !2963, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %161, metadata !1588, metadata !DIExpression()), !dbg !2964
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2965, !srcloc !1657
  call void @llvm.dbg.value(metadata ptr %65, metadata !1658, metadata !DIExpression()), !dbg !2967
  %162 = load i32, ptr %65, align 4, !dbg !2969, !tbaa !1444
  %163 = and i32 %162, 16777215, !dbg !2970
  call void @llvm.dbg.value(metadata i32 %163, metadata !1667, metadata !DIExpression()), !dbg !2971
  %164 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !2973, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %164, metadata !1672, metadata !DIExpression()), !dbg !2974
  %165 = load volatile i8, ptr %164, align 1, !dbg !2975, !tbaa !1341, !range !1343, !noundef !1344
  %166 = icmp eq i8 %165, 0, !dbg !2975
  br i1 %166, label %172, label %167, !dbg !2976

167:                                              ; preds = %154
  %168 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #5, !dbg !2977, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %168, metadata !1675, metadata !DIExpression()), !dbg !2978
  %169 = load volatile i32, ptr %168, align 4, !dbg !2979, !tbaa !1129
  %170 = mul i32 %169, %163, !dbg !2980
  %171 = lshr i32 %170, 8, !dbg !2981
  br label %172, !dbg !2982

172:                                              ; preds = %167, %154
  %173 = phi i32 [ %171, %167 ], [ %163, %154 ], !dbg !2971
  %174 = zext nneg i32 %173 to i64, !dbg !2983
  %175 = add i64 %161, %174, !dbg !2984
  %176 = and i64 %155, 4294967295, !dbg !2985
  %177 = icmp ugt i64 %175, %176, !dbg !2986
  br i1 %177, label %178, label %181, !dbg !2987

178:                                              ; preds = %172
  %179 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #5, !dbg !2988
  %180 = icmp eq ptr %179, null, !dbg !2988
  br i1 %180, label %181, label %183, !dbg !2989

181:                                              ; preds = %178, %172
  %182 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !2927
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !2990
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2941
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2763
  br label %189, !dbg !2942

183:                                              ; preds = %178
  call void @llvm.dbg.value(metadata i64 %176, metadata !1591, metadata !DIExpression()), !dbg !2991
  store volatile i64 %176, ptr %141, align 1, !dbg !2992, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #5, !dbg !2993, !srcloc !1657
  %184 = load i32, ptr %156, align 1, !dbg !2995, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !2990
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !2941
  call void @llvm.dbg.value(metadata i32 %184, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !2763
  %185 = icmp eq i32 %184, 0, !dbg !2996
  br i1 %185, label %189, label %186, !dbg !2942

186:                                              ; preds = %183
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2661, metadata ptr %10, metadata !DIExpression()), !dbg !2997
  store i32 %184, ptr %10, align 4, !tbaa !1129, !DIAssignID !2999
  call void @llvm.dbg.assign(metadata i32 %184, metadata !1707, metadata !DIExpression(), metadata !2999, metadata ptr %10, metadata !DIExpression()), !dbg !2997
  %187 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #5, !dbg !3000
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !3001
  call void @llvm.dbg.value(metadata ptr %187, metadata !1205, metadata !DIExpression()), !dbg !2763
  %188 = icmp eq ptr %187, null, !dbg !3002
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3003, !srcloc !1721
  br i1 %188, label %189, label %231, !dbg !3004

189:                                              ; preds = %186, %183, %130, %143, %181
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !3005
  %190 = load i32, ptr %37, align 4, !dbg !3007, !tbaa !1259
  %191 = and i32 %190, 255, !dbg !3007
  %192 = icmp eq i32 %191, 6, !dbg !3008
  br i1 %192, label %193, label %196, !dbg !3007

193:                                              ; preds = %189
  %194 = call i32 inttoptr (i64 7 to ptr)() #5, !dbg !3009
  %195 = zext i32 %194 to i64, !dbg !3009
  br label %198, !dbg !3007

196:                                              ; preds = %189
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3010
  %197 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3012
  br label %198, !dbg !3007

198:                                              ; preds = %196, %193
  %199 = phi i64 [ %195, %193 ], [ %197, %196 ], !dbg !3007
  %200 = load i16, ptr %66, align 4, !dbg !3013, !tbaa !1334
  %201 = zext i16 %200 to i64, !dbg !3014
  %202 = urem i64 %199, %201, !dbg !3015
  %203 = trunc i64 %202 to i16, !dbg !3016
  %204 = add nuw i16 %203, 1, !dbg !3016
  store i16 %204, ptr %49, align 2, !dbg !3017, !tbaa !1298, !DIAssignID !3018
  call void @llvm.dbg.assign(metadata i16 %204, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3018, metadata ptr %49, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata ptr %20, metadata !1749, metadata !DIExpression()), !dbg !3019
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !3021
  %205 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !3023
  call void @llvm.dbg.value(metadata ptr %205, metadata !1214, metadata !DIExpression()), !dbg !2763
  %206 = icmp eq ptr %205, null, !dbg !3024
  br i1 %206, label %207, label %217, !dbg !3025

207:                                              ; preds = %198
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2669, metadata ptr %18, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2670, metadata ptr %19, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3026
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %18) #5, !dbg !3028
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3029, metadata ptr %18, metadata !DIExpression()), !dbg !3026
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %19) #5, !dbg !3030
  store i64 21502558725, ptr %19, align 8, !dbg !3031, !DIAssignID !3032
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3032, metadata ptr %19, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3033, metadata ptr %19, metadata !DIExpression()), !dbg !3026
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3034, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3026
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3035, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3026
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3036, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3026
  %208 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %19) #5, !dbg !3037
  call void @llvm.dbg.value(metadata ptr %208, metadata !1770, metadata !DIExpression()), !dbg !3026
  %209 = icmp eq ptr %208, null, !dbg !3038
  br i1 %209, label %213, label %210, !dbg !3039

210:                                              ; preds = %207
  %211 = load i64, ptr %208, align 8, !dbg !3040, !tbaa !1790
  %212 = add i64 %211, 1, !dbg !3040
  store i64 %212, ptr %208, align 8, !dbg !3040, !tbaa !1790
  br label %216, !dbg !3041

213:                                              ; preds = %207
  store i64 1, ptr %18, align 8, !dbg !3042, !tbaa !1790, !DIAssignID !3043
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3043, metadata ptr %18, metadata !DIExpression()), !dbg !3026
  %214 = getelementptr inbounds %struct.metrics_value, ptr %18, i64 0, i32 1, !dbg !3044
  store i64 0, ptr %214, align 8, !dbg !3045, !tbaa !1798, !DIAssignID !3046
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3046, metadata ptr %214, metadata !DIExpression()), !dbg !3026
  %215 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %19, ptr noundef nonnull %18, i32 noundef 0) #5, !dbg !3047
  br label %216

216:                                              ; preds = %213, %210
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %19) #5, !dbg !3048
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #5, !dbg !3048
  br label %297, !dbg !3049

217:                                              ; preds = %198
  %218 = load i32, ptr %205, align 4, !dbg !3050, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %218, metadata !1216, metadata !DIExpression()), !dbg !2763
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !2660, metadata ptr %9, metadata !DIExpression()), !dbg !3051
  store i32 %218, ptr %9, align 4, !tbaa !1129, !DIAssignID !3053
  call void @llvm.dbg.assign(metadata i32 %218, metadata !1707, metadata !DIExpression(), metadata !3053, metadata ptr %9, metadata !DIExpression()), !dbg !3051
  %219 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #5, !dbg !3054
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !3055
  call void @llvm.dbg.value(metadata ptr %219, metadata !1205, metadata !DIExpression()), !dbg !2763
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !2763
  %220 = icmp eq ptr %219, null, !dbg !3056
  br i1 %220, label %221, label %231, !dbg !3057

221:                                              ; preds = %217
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2667, metadata ptr %16, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2668, metadata ptr %17, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3058
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %16) #5, !dbg !3060
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3061, metadata ptr %16, metadata !DIExpression()), !dbg !3058
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %17) #5, !dbg !3062
  store i64 21503148550, ptr %17, align 8, !dbg !3063, !DIAssignID !3064
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3064, metadata ptr %17, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3065, metadata ptr %17, metadata !DIExpression()), !dbg !3058
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3066, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3058
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3067, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3058
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3068, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3058
  %222 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %17) #5, !dbg !3069
  call void @llvm.dbg.value(metadata ptr %222, metadata !1770, metadata !DIExpression()), !dbg !3058
  %223 = icmp eq ptr %222, null, !dbg !3070
  br i1 %223, label %227, label %224, !dbg !3071

224:                                              ; preds = %221
  %225 = load i64, ptr %222, align 8, !dbg !3072, !tbaa !1790
  %226 = add i64 %225, 1, !dbg !3072
  store i64 %226, ptr %222, align 8, !dbg !3072, !tbaa !1790
  br label %230, !dbg !3073

227:                                              ; preds = %221
  store i64 1, ptr %16, align 8, !dbg !3074, !tbaa !1790, !DIAssignID !3075
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3075, metadata ptr %16, metadata !DIExpression()), !dbg !3058
  %228 = getelementptr inbounds %struct.metrics_value, ptr %16, i64 0, i32 1, !dbg !3076
  store i64 0, ptr %228, align 8, !dbg !3077, !tbaa !1798, !DIAssignID !3078
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3078, metadata ptr %228, metadata !DIExpression()), !dbg !3058
  %229 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %17, ptr noundef nonnull %16, i32 noundef 0) #5, !dbg !3079
  br label %230

230:                                              ; preds = %227, %224
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #5, !dbg !3080
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %16) #5, !dbg !3080
  br label %297, !dbg !3081

231:                                              ; preds = %186, %217
  %232 = phi ptr [ %219, %217 ], [ %187, %186 ]
  %233 = phi i1 [ false, %217 ], [ true, %186 ]
  %234 = phi i32 [ %218, %217 ], [ %184, %186 ]
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3082, !srcloc !1838
  call void @llvm.dbg.value(metadata ptr %65, metadata !1553, metadata !DIExpression()), !dbg !3083
  %235 = load i8, ptr %87, align 4, !dbg !3085, !tbaa !1361
  %236 = and i8 %235, 16, !dbg !3086
  %237 = icmp eq i8 %236, 0, !dbg !3087
  %238 = or i1 %233, %237, !dbg !3088
  br i1 %238, label %261, label %239, !dbg !3088

239:                                              ; preds = %231
  call void @llvm.dbg.value(metadata ptr %65, metadata !1846, metadata !DIExpression()), !dbg !3089
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !3089
  call void @llvm.dbg.value(metadata i32 %234, metadata !1852, metadata !DIExpression()), !dbg !3089
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !2653, metadata ptr %2, metadata !DIExpression()), !dbg !3091
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !2654, metadata ptr %3, metadata !DIExpression()), !dbg !3091
  call void @llvm.dbg.value(metadata ptr %65, metadata !1860, metadata !DIExpression()), !dbg !3091
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !3091
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !3091
  call void @llvm.dbg.value(metadata i32 %234, metadata !1863, metadata !DIExpression()), !dbg !3091
  %240 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !3093, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %240, metadata !1623, metadata !DIExpression()), !dbg !3095
  %241 = load volatile i8, ptr %240, align 1, !dbg !3096, !tbaa !1341, !range !1343, !noundef !1344
  %242 = icmp eq i8 %241, 0, !dbg !3096
  br i1 %242, label %246, label %243, !dbg !3097

243:                                              ; preds = %239
  %244 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !3098
  %245 = lshr i64 %244, 8, !dbg !3099
  br label %249, !dbg !3100

246:                                              ; preds = %239
  %247 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !3101
  %248 = udiv i64 %247, 1000000000, !dbg !3103
  br label %249, !dbg !3104

249:                                              ; preds = %246, %243
  %250 = phi i64 [ %245, %243 ], [ %248, %246 ], !dbg !3105
  call void @llvm.dbg.value(metadata i64 %250, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3091
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #5, !dbg !3106
  store i64 %43, ptr %2, align 8, !dbg !3107, !DIAssignID !3108
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3108, metadata ptr %2, metadata !DIExpression()), !dbg !3091
  %251 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !3109
  %252 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 2, !dbg !3110
  %253 = load i16, ptr %252, align 2, !dbg !3110, !tbaa !1601
  store i16 %253, ptr %251, align 8, !dbg !3109, !tbaa !1602, !DIAssignID !3111
  call void @llvm.dbg.assign(metadata i16 %253, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !3111, metadata ptr %251, metadata !DIExpression()), !dbg !3091
  %254 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !3109
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !3112, metadata ptr %254, metadata !DIExpression()), !dbg !3091
  store i8 1, ptr %254, align 2, !dbg !3109, !DIAssignID !3113
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !3113, metadata ptr %254, metadata !DIExpression()), !dbg !3091
  %255 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !3109
  store i8 0, ptr %255, align 1, !dbg !3109, !tbaa !1607, !DIAssignID !3114
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !3114, metadata ptr %255, metadata !DIExpression()), !dbg !3091
  %256 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !3109
  store i32 0, ptr %256, align 4, !dbg !3109, !tbaa !1609, !DIAssignID !3115
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3115, metadata ptr %256, metadata !DIExpression()), !dbg !3091
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #5, !dbg !3116
  %257 = and i64 %250, 4294967295, !dbg !3117
  store i64 %257, ptr %3, align 8, !dbg !3118, !tbaa !1894, !DIAssignID !3119
  call void @llvm.dbg.assign(metadata i64 %257, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3119, metadata ptr %3, metadata !DIExpression()), !dbg !3091
  %258 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !3118
  store i32 %234, ptr %258, align 8, !dbg !3118, !tbaa !1640, !DIAssignID !3120
  call void @llvm.dbg.assign(metadata i32 %234, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3120, metadata ptr %258, metadata !DIExpression()), !dbg !3091
  %259 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !3118
  store i32 0, ptr %259, align 4, !dbg !3118, !tbaa !1897, !DIAssignID !3121
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3121, metadata ptr %259, metadata !DIExpression()), !dbg !3091
  %260 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #5, !dbg !3122
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #5, !dbg !3123
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #5, !dbg !3123
  br label %261, !dbg !3124

261:                                              ; preds = %249, %231
  %262 = getelementptr inbounds %struct.lb4_backend, ptr %232, i64 0, i32 1, !dbg !3125
  %263 = getelementptr inbounds %struct.lb4_service, ptr %65, i64 0, i32 2, !dbg !3126
  %264 = load i16, ptr %263, align 2, !dbg !3126, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !2658, metadata ptr %7, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !2659, metadata ptr %8, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata ptr %232, metadata !1911, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata i32 %32, metadata !1912, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata i16 %46, metadata !1913, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata i16 %264, metadata !1914, metadata !DIExpression()), !dbg !3127
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #5, !dbg !3129
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !3130, metadata ptr %7, metadata !DIExpression()), !dbg !3127
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #5, !dbg !3131
  %265 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !3132
  store i64 0, ptr %265, align 8, !dbg !3132, !DIAssignID !3133
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !3133, metadata ptr %8, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3134, metadata ptr undef, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3127
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3135
  %266 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3137
  store i64 %266, ptr %8, align 8, !dbg !3138, !tbaa !1930, !DIAssignID !3139
  call void @llvm.dbg.assign(metadata i64 %266, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3139, metadata ptr %8, metadata !DIExpression()), !dbg !3127
  %267 = load i32, ptr %232, align 4, !dbg !3140, !tbaa !1934
  %268 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !3141
  store i32 %267, ptr %268, align 8, !dbg !3142, !tbaa !1938, !DIAssignID !3143
  call void @llvm.dbg.assign(metadata i32 %267, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3143, metadata ptr %268, metadata !DIExpression()), !dbg !3127
  %269 = load i16, ptr %262, align 4, !dbg !3144, !tbaa !1941
  %270 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !3145
  store i16 %269, ptr %270, align 4, !dbg !3146, !tbaa !1944, !DIAssignID !3147
  call void @llvm.dbg.assign(metadata i16 %269, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3147, metadata ptr %270, metadata !DIExpression()), !dbg !3127
  store i32 %32, ptr %7, align 4, !dbg !3148, !tbaa !1947, !DIAssignID !3149
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3149, metadata ptr %7, metadata !DIExpression()), !dbg !3127
  %271 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !3150
  store i16 %46, ptr %271, align 4, !dbg !3151, !tbaa !1952, !DIAssignID !3152
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3152, metadata ptr %271, metadata !DIExpression()), !dbg !3127
  %272 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !3153
  store i16 %264, ptr %272, align 2, !dbg !3154, !tbaa !1956, !DIAssignID !3155
  call void @llvm.dbg.assign(metadata i16 %264, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3155, metadata ptr %272, metadata !DIExpression()), !dbg !3127
  %273 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #5, !dbg !3156
  call void @llvm.dbg.value(metadata ptr %273, metadata !1915, metadata !DIExpression()), !dbg !3127
  %274 = icmp eq ptr %273, null, !dbg !3157
  br i1 %274, label %280, label %275, !dbg !3158

275:                                              ; preds = %261
  call void @llvm.dbg.value(metadata ptr %273, metadata !1962, metadata !DIExpression()), !dbg !3159
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !3159
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !3159
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !3161
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !3161
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3161
  call void @llvm.dbg.value(metadata ptr %273, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3161
  call void @llvm.dbg.label(metadata !1992), !dbg !3163
  call void @llvm.dbg.value(metadata ptr %273, metadata !1974, metadata !DIExpression()), !dbg !3161
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !3161
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !3161
  %276 = load i64, ptr %273, align 8, !dbg !3164, !tbaa !1534
  %277 = load i64, ptr %7, align 8, !dbg !3164, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %276, i64 %277), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !3161
  %278 = icmp eq i64 %276, %277, !dbg !3165
  br i1 %278, label %279, label %280, !dbg !3166

279:                                              ; preds = %275
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3127
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !3167
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !3167
  br label %293, !dbg !3168

280:                                              ; preds = %261, %275
  %281 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #5, !dbg !3169
  call void @llvm.dbg.value(metadata i32 %281, metadata !1917, metadata !DIExpression()), !dbg !3127
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !3167
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !3167
  %282 = icmp slt i32 %281, 0, !dbg !3170
  br i1 %282, label %283, label %293, !dbg !3168

283:                                              ; preds = %280
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !2665, metadata ptr %14, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !2666, metadata ptr %15, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3171
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %14) #5, !dbg !3173
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3174, metadata ptr %14, metadata !DIExpression()), !dbg !3171
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %15) #5, !dbg !3175
  store i64 21504197127, ptr %15, align 8, !dbg !3176, !DIAssignID !3177
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3177, metadata ptr %15, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3178, metadata ptr %15, metadata !DIExpression()), !dbg !3171
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3179, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3171
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3180, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3171
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3181, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3171
  %284 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %15) #5, !dbg !3182
  call void @llvm.dbg.value(metadata ptr %284, metadata !1770, metadata !DIExpression()), !dbg !3171
  %285 = icmp eq ptr %284, null, !dbg !3183
  br i1 %285, label %289, label %286, !dbg !3184

286:                                              ; preds = %283
  %287 = load i64, ptr %284, align 8, !dbg !3185, !tbaa !1790
  %288 = add i64 %287, 1, !dbg !3185
  store i64 %288, ptr %284, align 8, !dbg !3185, !tbaa !1790
  br label %292, !dbg !3186

289:                                              ; preds = %283
  store i64 1, ptr %14, align 8, !dbg !3187, !tbaa !1790, !DIAssignID !3188
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3188, metadata ptr %14, metadata !DIExpression()), !dbg !3171
  %290 = getelementptr inbounds %struct.metrics_value, ptr %14, i64 0, i32 1, !dbg !3189
  store i64 0, ptr %290, align 8, !dbg !3190, !tbaa !1798, !DIAssignID !3191
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3191, metadata ptr %290, metadata !DIExpression()), !dbg !3171
  %291 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %15, ptr noundef nonnull %14, i32 noundef 0) #5, !dbg !3192
  br label %292

292:                                              ; preds = %289, %286
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #5, !dbg !3193
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #5, !dbg !3193
  br label %297, !dbg !3194

293:                                              ; preds = %279, %280
  %294 = load i32, ptr %232, align 4, !dbg !3195, !tbaa !1934
  tail call void @llvm.dbg.value(metadata i32 %294, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !2690
  %295 = load i16, ptr %262, align 4, !dbg !3196, !tbaa !1941
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !3197
  call void @llvm.dbg.value(metadata i16 %295, metadata !2038, metadata !DIExpression()), !dbg !3197
  %296 = zext i16 %295 to i32, !dbg !3199
  tail call void @llvm.dbg.value(metadata i16 %295, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !2690
  br label %299, !dbg !3200

297:                                              ; preds = %292, %230, %216, %69, %124, %36, %61, %112, %105, %53, %81, %78
  %298 = phi i32 [ -1, %105 ], [ -1, %112 ], [ -6, %61 ], [ -95, %36 ], [ -6, %124 ], [ -113, %69 ], [ -113, %216 ], [ -113, %230 ], [ -12, %292 ], [ -6, %53 ], [ -113, %81 ], [ -113, %78 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2690
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %20) #5, !dbg !3201
  call void @llvm.dbg.value(metadata i32 %298, metadata !2689, metadata !DIExpression()), !dbg !2690
  br label %302, !dbg !3202

299:                                              ; preds = %78, %91, %293, %81
  %300 = phi i32 [ %42, %91 ], [ %296, %293 ], [ %42, %81 ], [ %42, %78 ], !dbg !2690
  %301 = phi i32 [ %32, %91 ], [ %294, %293 ], [ %32, %81 ], [ %32, %78 ]
  tail call void @llvm.dbg.value(metadata i32 %301, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !2690
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %20) #5, !dbg !3201
  call void @llvm.dbg.value(metadata i32 poison, metadata !2689, metadata !DIExpression()), !dbg !2690
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !3203
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3203
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !3203
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !3212
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !3212
  call void @llvm.dbg.label(metadata !1527), !dbg !3214
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  call void @llvm.dbg.label(metadata !1528), !dbg !3215
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !2690
  tail call void @llvm.dbg.value(metadata i32 %301, metadata !2688, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !2690
  call void @llvm.dbg.value(metadata ptr %0, metadata !3216, metadata !DIExpression()), !dbg !3222
  call void @llvm.dbg.value(metadata ptr undef, metadata !3221, metadata !DIExpression()), !dbg !3222
  store i32 0, ptr %21, align 8, !dbg !3224, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3225, !srcloc !3226
  store i32 0, ptr %24, align 4, !dbg !3227, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3228, !srcloc !3229
  store i32 -65536, ptr %29, align 8, !dbg !3230, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3231, !srcloc !3232
  store i32 %301, ptr %31, align 4, !dbg !3233, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3234, !srcloc !3235
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !3236
  call void @llvm.dbg.value(metadata i32 %300, metadata !2038, metadata !DIExpression()), !dbg !3236
  store i32 %300, ptr %39, align 8, !dbg !3238, !tbaa !1251
  br label %302, !dbg !3239

302:                                              ; preds = %1, %297, %299
  %303 = phi i32 [ 0, %299 ], [ %298, %297 ], [ -6, %1 ], !dbg !2690
  tail call void @llvm.dbg.value(metadata i32 %303, metadata !2652, metadata !DIExpression()), !dbg !2672
  %304 = icmp eq i32 %303, -113, !dbg !3240
  %305 = icmp eq i32 %303, -12
  %306 = call i1 @llvm.bpf.passthrough.i1.i1(i32 2, i1 %304)
  %307 = or i1 %306, %305, !dbg !3242
  %308 = xor i1 %307, true, !dbg !3242
  %309 = zext i1 %308 to i32, !dbg !3242
  ret i32 %309, !dbg !3243
}

; Function Attrs: nounwind
define dso_local i32 @cil_sock6_sendmsg(ptr noundef %0) #0 section "cgroup/sendmsg6" !dbg !3244 {
  %2 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !3248
  %3 = alloca %struct.lb_affinity_val, align 8, !DIAssignID !3249
  %4 = alloca %struct.lb4_affinity_key, align 8, !DIAssignID !3250
  %5 = alloca %struct.lb_affinity_match, align 4, !DIAssignID !3251
  %6 = alloca %struct.ipcache_key, align 4, !DIAssignID !3252
  %7 = alloca %struct.ipv4_revnat_entry, align 4, !DIAssignID !3253
  %8 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !3254
  %9 = alloca i32, align 4, !DIAssignID !3255
  %10 = alloca i32, align 4, !DIAssignID !3256
  %11 = alloca %struct.skip_lb4_key, align 8, !DIAssignID !3257
  %12 = alloca i32, align 4, !DIAssignID !3258
  %13 = alloca i32, align 4, !DIAssignID !3259
  %14 = alloca %struct.metrics_value, align 8, !DIAssignID !3260
  %15 = alloca %struct.metrics_key, align 8, !DIAssignID !3261
  %16 = alloca %struct.metrics_value, align 8, !DIAssignID !3262
  %17 = alloca %struct.metrics_key, align 8, !DIAssignID !3263
  %18 = alloca %struct.metrics_value, align 8, !DIAssignID !3264
  %19 = alloca %struct.metrics_key, align 8, !DIAssignID !3265
  %20 = alloca %struct.lb4_key, align 4, !DIAssignID !3266
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3246, metadata !DIExpression()), !dbg !3267
  call void @llvm.dbg.value(metadata ptr %0, metadata !2673, metadata !DIExpression()), !dbg !3268
  call void @llvm.dbg.value(metadata i1 true, metadata !2678, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3268
  call void @llvm.dbg.value(metadata i1 false, metadata !2679, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3268
  call void @llvm.dbg.value(metadata ptr %0, metadata !2682, metadata !DIExpression()), !dbg !3270
  call void @llvm.dbg.value(metadata i1 true, metadata !2685, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3270
  call void @llvm.dbg.value(metadata i1 false, metadata !2686, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3270
  call void @llvm.dbg.value(metadata ptr %0, metadata !2692, metadata !DIExpression()), !dbg !3272
  call void @llvm.dbg.value(metadata ptr undef, metadata !2698, metadata !DIExpression()), !dbg !3272
  %21 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !3274
  %22 = load i32, ptr %21, align 8, !dbg !3275, !tbaa !1129
  %23 = zext i32 %22 to i64, !dbg !3276
  tail call void @llvm.dbg.value(metadata i64 %23, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3277, !srcloc !2705
  %24 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !3278
  %25 = load i32, ptr %24, align 4, !dbg !3278, !tbaa !1129
  %26 = zext i32 %25 to i64, !dbg !3279
  %27 = shl nuw i64 %26, 32, !dbg !3279
  %28 = or disjoint i64 %27, %23, !dbg !3279
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3280, !srcloc !2709
  %29 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !3281
  %30 = load i32, ptr %29, align 8, !dbg !3281, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !2688, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3282, !srcloc !2712
  %31 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !3283
  %32 = load i32, ptr %31, align 4, !dbg !3283, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2688, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3284, !srcloc !2715
  call void @llvm.dbg.value(metadata ptr undef, metadata !2716, metadata !DIExpression()), !dbg !3285
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3285
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3285
  tail call void @llvm.dbg.value(metadata i64 %28, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3285
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3285
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !2725, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !3285
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2729, metadata !DIExpression()), !dbg !3287
  tail call void @llvm.dbg.value(metadata ptr undef, metadata !2734, metadata !DIExpression()), !dbg !3287
  %33 = icmp eq i64 %28, 0, !dbg !3289
  %34 = icmp eq i32 %30, -65536
  %35 = select i1 %33, i1 %34, i1 false, !dbg !3290
  br i1 %35, label %36, label %301, !dbg !3290

36:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !2688, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !3291
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3291
  call void @llvm.dbg.value(metadata i64 72, metadata !1504, metadata !DIExpression()), !dbg !3291
  call void @llvm.dbg.value(metadata i64 72, metadata !1507, metadata !DIExpression()), !dbg !3293
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !3293
  call void @llvm.dbg.label(metadata !1520), !dbg !3295
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1521), !dbg !3296
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1522), !dbg !3297
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1523), !dbg !3298
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1524), !dbg !3299
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1525), !dbg !3300
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1526), !dbg !3301
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1527), !dbg !3302
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1528), !dbg !3303
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  %37 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !3304
  %38 = load i32, ptr %37, align 4, !dbg !3304, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %38, metadata !2687, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !3270
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !3270
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !3258, metadata ptr %12, metadata !DIExpression()), !dbg !3305
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !3305
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12), !dbg !3307
  %39 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !3308
  %40 = load i32, ptr %39, align 8, !dbg !3308, !tbaa !1251
  store volatile i32 %40, ptr %12, align 4, !dbg !3309, !tbaa !1129, !DIAssignID !3310
  call void @llvm.dbg.assign(metadata i32 %40, metadata !1239, metadata !DIExpression(), metadata !3310, metadata ptr %12, metadata !DIExpression()), !dbg !3305
  %41 = load volatile i32, ptr %12, align 4, !dbg !3311, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12), !dbg !3312
  %42 = and i32 %41, 65535, !dbg !3313
  tail call void @llvm.dbg.value(metadata i32 %42, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !3270
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1193, metadata !DIExpression(), metadata !3266, metadata ptr %20, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata ptr undef, metadata !1199, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata ptr %0, metadata !1200, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i1 true, metadata !1201, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3314
  call void @llvm.dbg.value(metadata i1 false, metadata !1202, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3314
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !3316
  call void @llvm.dbg.value(metadata ptr undef, metadata !1233, metadata !DIExpression()), !dbg !3316
  %43 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !3318
  call void @llvm.dbg.value(metadata i64 %43, metadata !1234, metadata !DIExpression()), !dbg !3316
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !1203, metadata !DIExpression()), !dbg !3314
  %44 = tail call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !3319
  call void @llvm.dbg.value(metadata !DIArgList(i64 %43, i64 %44), metadata !1204, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3314
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !3259, metadata ptr %13, metadata !DIExpression()), !dbg !3320
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !3320
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13), !dbg !3322
  store volatile i32 %42, ptr %13, align 4, !dbg !3323, !tbaa !1129, !DIAssignID !3324
  call void @llvm.dbg.assign(metadata i32 %42, metadata !1239, metadata !DIExpression(), metadata !3324, metadata ptr %13, metadata !DIExpression()), !dbg !3320
  %45 = load volatile i32, ptr %13, align 4, !dbg !3325, !tbaa !1129
  %46 = trunc i32 %45 to i16, !dbg !3326
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13), !dbg !3327
  call void @llvm.dbg.value(metadata i16 %46, metadata !1211, metadata !DIExpression()), !dbg !3314
  %47 = trunc i32 %38 to i8, !dbg !3328
  call void @llvm.dbg.value(metadata i8 %47, metadata !1212, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i32 %32, metadata !1213, metadata !DIExpression()), !dbg !3314
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %20) #5, !dbg !3329
  store i32 %32, ptr %20, align 4, !dbg !3330, !tbaa !1264, !DIAssignID !3331
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3331, metadata ptr %20, metadata !DIExpression()), !dbg !3314
  %48 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 1, !dbg !3330
  store i16 %46, ptr %48, align 4, !dbg !3330, !tbaa !1268, !DIAssignID !3332
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3332, metadata ptr %48, metadata !DIExpression()), !dbg !3314
  %49 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 2, !dbg !3330
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3333, metadata ptr %49, metadata !DIExpression()), !dbg !3314
  %50 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 3, !dbg !3330
  store i8 %47, ptr %50, align 4, !dbg !3330, !tbaa !1271, !DIAssignID !3334
  call void @llvm.dbg.assign(metadata i8 %47, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !3334, metadata ptr %50, metadata !DIExpression()), !dbg !3314
  %51 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 4, !dbg !3330
  call void @llvm.dbg.assign(metadata i8 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !3335, metadata ptr %51, metadata !DIExpression()), !dbg !3314
  %52 = getelementptr inbounds %struct.lb4_key, ptr %20, i64 0, i32 5, !dbg !3330
  store i16 0, ptr %52, align 2, !dbg !3330, !DIAssignID !3336
  call void @llvm.dbg.assign(metadata i16 0, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !3336, metadata ptr %52, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !3337, metadata ptr undef, metadata !DIExpression()), !dbg !3338
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !3340, metadata ptr undef, metadata !DIExpression()), !dbg !3338
  call void @llvm.dbg.value(metadata ptr %20, metadata !1289, metadata !DIExpression()), !dbg !3338
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !3338
  store i16 0, ptr %49, align 2, !dbg !3341, !tbaa !1298
  store i8 0, ptr %51, align 1, !dbg !3342, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !3343
  %53 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !3345
  call void @llvm.dbg.value(metadata ptr %53, metadata !1291, metadata !DIExpression()), !dbg !3338
  %54 = icmp eq ptr %53, null, !dbg !3346
  br i1 %54, label %296, label %55, !dbg !3347

55:                                               ; preds = %36
  call void @llvm.dbg.value(metadata ptr %53, metadata !1312, metadata !DIExpression()), !dbg !3348
  %56 = getelementptr inbounds %struct.lb4_service, ptr %53, i64 0, i32 4, !dbg !3350
  %57 = load i8, ptr %56, align 1, !dbg !3350, !tbaa !1321
  %58 = and i8 %57, 32, !dbg !3351
  %59 = icmp eq i8 %58, 0, !dbg !3352
  br i1 %59, label %63, label %60, !dbg !3353

60:                                               ; preds = %55
  store i8 1, ptr %51, align 1, !dbg !3354, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !3355
  %61 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !3357
  call void @llvm.dbg.value(metadata ptr %61, metadata !1208, metadata !DIExpression()), !dbg !3314
  %62 = icmp eq ptr %61, null, !dbg !3358
  br i1 %62, label %296, label %63, !dbg !3359

63:                                               ; preds = %55, %60
  %64 = phi ptr [ %61, %60 ], [ %53, %55 ]
  call void @llvm.dbg.value(metadata ptr %64, metadata !1208, metadata !DIExpression()), !dbg !3314
  %65 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 1, !dbg !3360
  %66 = load i16, ptr %65, align 4, !dbg !3360, !tbaa !1334
  %67 = icmp eq i16 %66, 0, !dbg !3361
  br i1 %67, label %68, label %85, !dbg !3362

68:                                               ; preds = %63
  %69 = call ptr asm sideeffect "$0 = __config_enable_no_service_endpoints_routable ll", "=r"() #5, !dbg !3363, !srcloc !1338
  call void @llvm.dbg.value(metadata ptr %69, metadata !1217, metadata !DIExpression()), !dbg !3364
  %70 = load volatile i8, ptr %69, align 1, !dbg !3365, !tbaa !1341, !range !1343, !noundef !1344
  %71 = icmp eq i8 %70, 0, !dbg !3365
  br i1 %71, label %72, label %296, !dbg !3366

72:                                               ; preds = %68
  call void @llvm.dbg.value(metadata ptr %64, metadata !1346, metadata !DIExpression()), !dbg !3367
  call void @llvm.dbg.value(metadata ptr %64, metadata !1354, metadata !DIExpression()), !dbg !3369
  %73 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 3, !dbg !3371
  %74 = load i8, ptr %73, align 4, !dbg !3371, !tbaa !1361
  %75 = and i8 %74, 35, !dbg !3372
  %76 = icmp eq i8 %75, 0, !dbg !3373
  br i1 %76, label %80, label %77, !dbg !3374

77:                                               ; preds = %72
  call void @llvm.dbg.value(metadata ptr %64, metadata !1365, metadata !DIExpression()), !dbg !3375
  %78 = and i8 %74, 4, !dbg !3377
  %79 = icmp eq i8 %78, 0, !dbg !3378
  br i1 %79, label %298, label %296, !dbg !3379

80:                                               ; preds = %72
  call void @llvm.dbg.value(metadata ptr %64, metadata !1354, metadata !DIExpression()), !dbg !3380
  call void @llvm.dbg.value(metadata ptr %64, metadata !1375, metadata !DIExpression()), !dbg !3382
  %81 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 4, !dbg !3384
  %82 = load i8, ptr %81, align 1, !dbg !3384, !tbaa !1321
  %83 = and i8 %82, 16, !dbg !3385
  %84 = icmp eq i8 %83, 0, !dbg !3386
  br i1 %84, label %298, label %296, !dbg !3387

85:                                               ; preds = %63
  call void @llvm.dbg.value(metadata ptr %64, metadata !1385, metadata !DIExpression()), !dbg !3388
  call void @llvm.dbg.value(metadata ptr %64, metadata !1391, metadata !DIExpression()), !dbg !3390
  %86 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 3, !dbg !3392
  %87 = load i8, ptr %86, align 4, !dbg !3392, !tbaa !1361
  %88 = and i8 %87, 8, !dbg !3393
  %89 = icmp eq i8 %88, 0, !dbg !3394
  br i1 %89, label %90, label %95, !dbg !3395

90:                                               ; preds = %85
  %91 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 4, !dbg !3396
  %92 = load i8, ptr %91, align 1, !dbg !3396, !tbaa !1321
  %93 = and i8 %92, 8, !dbg !3397
  %94 = icmp eq i8 %93, 0, !dbg !3395
  br i1 %94, label %101, label %298, !dbg !3398

95:                                               ; preds = %85
  call void @llvm.dbg.value(metadata ptr %64, metadata !1403, metadata !DIExpression()), !dbg !3399
  call void @llvm.dbg.value(metadata i32 %32, metadata !1408, metadata !DIExpression()), !dbg !3399
  call void @llvm.dbg.value(metadata ptr %64, metadata !1417, metadata !DIExpression()), !dbg !3401
  %96 = and i8 %87, 1, !dbg !3403
  %97 = icmp eq i8 %96, 0, !dbg !3404
  call void @llvm.dbg.value(metadata ptr %64, metadata !1391, metadata !DIExpression()), !dbg !3405
  %98 = and i32 %32, 255
  %99 = icmp eq i32 %98, 127
  %100 = select i1 %97, i1 %99, i1 false, !dbg !3407
  br i1 %100, label %114, label %104, !dbg !3407

101:                                              ; preds = %90
  call void @llvm.dbg.value(metadata ptr %64, metadata !1403, metadata !DIExpression()), !dbg !3399
  call void @llvm.dbg.value(metadata i32 %32, metadata !1408, metadata !DIExpression()), !dbg !3399
  call void @llvm.dbg.value(metadata ptr %64, metadata !1417, metadata !DIExpression()), !dbg !3401
  %102 = and i8 %87, 1, !dbg !3403
  %103 = icmp eq i8 %102, 0, !dbg !3404
  br i1 %103, label %114, label %104, !dbg !3407

104:                                              ; preds = %101, %95
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1427, metadata !DIExpression(), metadata !3252, metadata ptr %6, metadata !DIExpression()), !dbg !3408
  call void @llvm.dbg.value(metadata ptr @cilium_ipcache_v2, metadata !1432, metadata !DIExpression()), !dbg !3408
  call void @llvm.dbg.value(metadata i32 %32, metadata !1433, metadata !DIExpression()), !dbg !3408
  call void @llvm.dbg.value(metadata i32 32, metadata !1434, metadata !DIExpression()), !dbg !3408
  call void @llvm.dbg.value(metadata i32 0, metadata !1435, metadata !DIExpression()), !dbg !3408
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %6) #5, !dbg !3410
  %105 = getelementptr inbounds i8, ptr %6, i64 6, !dbg !3411
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 2 dereferenceable(24) %105, i8 0, i64 18, i1 false), !dbg !3411, !DIAssignID !3412
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(), metadata !3412, metadata ptr %6, metadata !DIExpression()), !dbg !3408
  call void @llvm.dbg.assign(metadata i8 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 48), metadata !3413, metadata ptr undef, metadata !DIExpression()), !dbg !3408
  store i32 64, ptr %6, align 4, !dbg !3414, !tbaa.struct !1443, !DIAssignID !3415
  call void @llvm.dbg.assign(metadata i32 64, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3415, metadata ptr %6, metadata !DIExpression()), !dbg !3408
  %106 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 3, !dbg !3416
  store i8 1, ptr %106, align 1, !dbg !3417, !tbaa !1448, !DIAssignID !3418
  call void @llvm.dbg.assign(metadata i8 1, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 56, 8), metadata !3418, metadata ptr %106, metadata !DIExpression()), !dbg !3408
  %107 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 4, !dbg !3419
  store i32 %32, ptr %107, align 4, !dbg !3420, !tbaa !1444, !DIAssignID !3421
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3421, metadata ptr %107, metadata !DIExpression()), !dbg !3408
  %108 = getelementptr inbounds %struct.ipcache_key, ptr %6, i64 0, i32 1, !dbg !3422
  store i16 0, ptr %108, align 4, !dbg !3423, !tbaa !1457, !DIAssignID !3424
  call void @llvm.dbg.assign(metadata i16 0, metadata !1427, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3424, metadata ptr %108, metadata !DIExpression()), !dbg !3408
  %109 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_ipcache_v2, ptr noundef nonnull %6) #5, !dbg !3425
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %6) #5, !dbg !3426
  call void @llvm.dbg.value(metadata ptr %109, metadata !1409, metadata !DIExpression()), !dbg !3427
  %110 = icmp eq ptr %109, null, !dbg !3428
  br i1 %110, label %296, label %111, !dbg !3429

111:                                              ; preds = %104
  %112 = load i32, ptr %109, align 4, !dbg !3430, !tbaa !1466
  %113 = icmp eq i32 %112, 1, !dbg !3431
  br i1 %113, label %114, label %296, !dbg !3432

114:                                              ; preds = %95, %101, %111
  %115 = call ptr asm sideeffect "$0 = __config_enable_lrp ll", "=r"() #5, !dbg !3433, !srcloc !1471
  call void @llvm.dbg.value(metadata ptr %115, metadata !1222, metadata !DIExpression()), !dbg !3434
  %116 = load volatile i8, ptr %115, align 1, !dbg !3435, !tbaa !1341, !range !1343, !noundef !1344
  %117 = icmp eq i8 %116, 0, !dbg !3435
  br i1 %117, label %129, label %118, !dbg !3436

118:                                              ; preds = %114
  call void @llvm.dbg.value(metadata ptr %64, metadata !1475, metadata !DIExpression()), !dbg !3437
  %119 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 4, !dbg !3439
  %120 = load i8, ptr %119, align 1, !dbg !3439, !tbaa !1321
  %121 = and i8 %120, 1, !dbg !3440
  %122 = icmp eq i8 %121, 0, !dbg !3441
  br i1 %122, label %129, label %123, !dbg !3442

123:                                              ; preds = %118
  %124 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !3443
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1485, metadata !DIExpression(), metadata !3257, metadata ptr %11, metadata !DIExpression()), !dbg !3444
  call void @llvm.dbg.value(metadata i64 %124, metadata !1490, metadata !DIExpression()), !dbg !3444
  call void @llvm.dbg.value(metadata i32 %32, metadata !1491, metadata !DIExpression()), !dbg !3444
  call void @llvm.dbg.value(metadata i16 %46, metadata !1492, metadata !DIExpression()), !dbg !3444
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %11) #5, !dbg !3446
  call void @llvm.dbg.value(metadata ptr null, metadata !1493, metadata !DIExpression()), !dbg !3444
  call void @llvm.dbg.value(metadata ptr %11, metadata !1497, metadata !DIExpression()), !dbg !3447
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3447
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !3447
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !3449
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression(DW_OP_plus_uconst, 16, DW_OP_stack_value)), !dbg !3449
  call void @llvm.dbg.label(metadata !1527), !dbg !3451
  %125 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !3452
  call void @llvm.dbg.value(metadata ptr %125, metadata !1512, metadata !DIExpression()), !dbg !3449
  store i64 0, ptr %125, align 8, !dbg !3452, !tbaa !1534
  call void @llvm.dbg.label(metadata !1528), !dbg !3453
  call void @llvm.dbg.value(metadata ptr %11, metadata !1512, metadata !DIExpression()), !dbg !3449
  store i64 %124, ptr %11, align 8, !dbg !3454, !tbaa !1538, !DIAssignID !3455
  call void @llvm.dbg.assign(metadata i64 %124, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3455, metadata ptr %11, metadata !DIExpression()), !dbg !3444
  store i32 %32, ptr %125, align 8, !dbg !3456, !tbaa !1542, !DIAssignID !3457
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3457, metadata ptr %125, metadata !DIExpression()), !dbg !3444
  %126 = getelementptr inbounds %struct.skip_lb4_key, ptr %11, i64 0, i32 2, !dbg !3458
  store i16 %46, ptr %126, align 4, !dbg !3459, !tbaa !1546, !DIAssignID !3460
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1485, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3460, metadata ptr %126, metadata !DIExpression()), !dbg !3444
  %127 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_skip_lb4, ptr noundef nonnull %11) #5, !dbg !3461
  call void @llvm.dbg.value(metadata ptr %127, metadata !1493, metadata !DIExpression()), !dbg !3444
  %128 = icmp eq ptr %127, null, !dbg !3462
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %11) #5, !dbg !3463
  br i1 %128, label %129, label %296, !dbg !3464

129:                                              ; preds = %123, %118, %114
  call void @llvm.dbg.value(metadata ptr %64, metadata !1553, metadata !DIExpression()), !dbg !3465
  %130 = load i8, ptr %86, align 4, !dbg !3467, !tbaa !1361
  %131 = and i8 %130, 16, !dbg !3468
  %132 = icmp eq i8 %131, 0, !dbg !3469
  br i1 %132, label %188, label %133, !dbg !3470

133:                                              ; preds = %129
  call void @llvm.dbg.value(metadata ptr %64, metadata !1563, metadata !DIExpression()), !dbg !3471
  call void @llvm.dbg.value(metadata ptr undef, metadata !1569, metadata !DIExpression()), !dbg !3471
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(), metadata !3250, metadata ptr %4, metadata !DIExpression()), !dbg !3473
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1587, metadata !DIExpression(), metadata !3251, metadata ptr %5, metadata !DIExpression()), !dbg !3475
  call void @llvm.dbg.value(metadata ptr %64, metadata !1580, metadata !DIExpression()), !dbg !3473
  call void @llvm.dbg.value(metadata i8 1, metadata !1581, metadata !DIExpression()), !dbg !3473
  call void @llvm.dbg.value(metadata ptr undef, metadata !1582, metadata !DIExpression()), !dbg !3473
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !3476
  store i64 %43, ptr %4, align 8, !dbg !3477, !DIAssignID !3478
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3478, metadata ptr %4, metadata !DIExpression()), !dbg !3473
  %134 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 1, !dbg !3479
  %135 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 2, !dbg !3480
  %136 = load i16, ptr %135, align 2, !dbg !3480, !tbaa !1601
  store i16 %136, ptr %134, align 8, !dbg !3479, !tbaa !1602, !DIAssignID !3481
  call void @llvm.dbg.assign(metadata i16 %136, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !3481, metadata ptr %134, metadata !DIExpression()), !dbg !3473
  %137 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 2, !dbg !3479
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1573, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !3482, metadata ptr %137, metadata !DIExpression()), !dbg !3473
  store i8 1, ptr %137, align 2, !dbg !3479, !DIAssignID !3483
  call void @llvm.dbg.assign(metadata i8 1, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !3483, metadata ptr %137, metadata !DIExpression()), !dbg !3473
  %138 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 3, !dbg !3479
  store i8 0, ptr %138, align 1, !dbg !3479, !tbaa !1607, !DIAssignID !3484
  call void @llvm.dbg.assign(metadata i8 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !3484, metadata ptr %138, metadata !DIExpression()), !dbg !3473
  %139 = getelementptr inbounds %struct.lb4_affinity_key, ptr %4, i64 0, i32 4, !dbg !3479
  store i32 0, ptr %139, align 4, !dbg !3479, !tbaa !1609, !DIAssignID !3485
  call void @llvm.dbg.assign(metadata i32 0, metadata !1573, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3485, metadata ptr %139, metadata !DIExpression()), !dbg !3473
  %140 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !3486
  call void @llvm.dbg.value(metadata ptr %140, metadata !1583, metadata !DIExpression()), !dbg !3473
  %141 = icmp eq ptr %140, null, !dbg !3487
  br i1 %141, label %142, label %143, !dbg !3488

142:                                              ; preds = %133
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !3489
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !3314
  br label %188, !dbg !3490

143:                                              ; preds = %133
  %144 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !3491, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %144, metadata !1623, metadata !DIExpression()), !dbg !3493
  %145 = load volatile i8, ptr %144, align 1, !dbg !3494, !tbaa !1341, !range !1343, !noundef !1344
  %146 = icmp eq i8 %145, 0, !dbg !3494
  br i1 %146, label %150, label %147, !dbg !3495

147:                                              ; preds = %143
  %148 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !3496
  %149 = lshr i64 %148, 8, !dbg !3497
  br label %153, !dbg !3498

150:                                              ; preds = %143
  %151 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !3499
  %152 = udiv i64 %151, 1000000000, !dbg !3501
  br label %153, !dbg !3502

153:                                              ; preds = %150, %147
  %154 = phi i64 [ %149, %147 ], [ %152, %150 ], !dbg !3503
  call void @llvm.dbg.value(metadata i64 %154, metadata !1584, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3475
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #5, !dbg !3504
  %155 = getelementptr inbounds %struct.lb_affinity_val, ptr %140, i64 0, i32 1, !dbg !3505
  %156 = load i32, ptr %155, align 1, !dbg !3505, !tbaa !1640
  store i32 %156, ptr %5, align 4, !dbg !3506, !tbaa !1643, !DIAssignID !3507
  call void @llvm.dbg.assign(metadata i32 %156, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3507, metadata ptr %5, metadata !DIExpression()), !dbg !3475
  %157 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 1, !dbg !3506
  %158 = load i16, ptr %135, align 2, !dbg !3508, !tbaa !1601
  store i16 %158, ptr %157, align 4, !dbg !3506, !tbaa !1647, !DIAssignID !3509
  call void @llvm.dbg.assign(metadata i16 %158, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3509, metadata ptr %157, metadata !DIExpression()), !dbg !3475
  %159 = getelementptr inbounds %struct.lb_affinity_match, ptr %5, i64 0, i32 2, !dbg !3506
  store i16 0, ptr %159, align 2, !dbg !3506, !tbaa !1649, !DIAssignID !3510
  call void @llvm.dbg.assign(metadata i16 0, metadata !1587, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3510, metadata ptr %159, metadata !DIExpression()), !dbg !3475
  %160 = load volatile i64, ptr %140, align 1, !dbg !3511, !tbaa !1534
  call void @llvm.dbg.value(metadata i64 %160, metadata !1588, metadata !DIExpression()), !dbg !3512
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3513, !srcloc !1657
  call void @llvm.dbg.value(metadata ptr %64, metadata !1658, metadata !DIExpression()), !dbg !3515
  %161 = load i32, ptr %64, align 4, !dbg !3517, !tbaa !1444
  %162 = and i32 %161, 16777215, !dbg !3518
  call void @llvm.dbg.value(metadata i32 %162, metadata !1667, metadata !DIExpression()), !dbg !3519
  %163 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !3521, !srcloc !1680
  call void @llvm.dbg.value(metadata ptr %163, metadata !1672, metadata !DIExpression()), !dbg !3522
  %164 = load volatile i8, ptr %163, align 1, !dbg !3523, !tbaa !1341, !range !1343, !noundef !1344
  %165 = icmp eq i8 %164, 0, !dbg !3523
  br i1 %165, label %171, label %166, !dbg !3524

166:                                              ; preds = %153
  %167 = call ptr asm sideeffect "$0 = __config_kernel_hz ll", "=r"() #5, !dbg !3525, !srcloc !1685
  call void @llvm.dbg.value(metadata ptr %167, metadata !1675, metadata !DIExpression()), !dbg !3526
  %168 = load volatile i32, ptr %167, align 4, !dbg !3527, !tbaa !1129
  %169 = mul i32 %168, %162, !dbg !3528
  %170 = lshr i32 %169, 8, !dbg !3529
  br label %171, !dbg !3530

171:                                              ; preds = %166, %153
  %172 = phi i32 [ %170, %166 ], [ %162, %153 ], !dbg !3519
  %173 = zext nneg i32 %172 to i64, !dbg !3531
  %174 = add i64 %160, %173, !dbg !3532
  %175 = and i64 %154, 4294967295, !dbg !3533
  %176 = icmp ugt i64 %174, %175, !dbg !3534
  br i1 %176, label %177, label %180, !dbg !3535

177:                                              ; preds = %171
  %178 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb_affinity_match, ptr noundef nonnull %5) #5, !dbg !3536
  %179 = icmp eq ptr %178, null, !dbg !3536
  br i1 %179, label %180, label %182, !dbg !3537

180:                                              ; preds = %177, %171
  %181 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %4) #5, !dbg !3475
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !3538
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !3489
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !3314
  br label %188, !dbg !3490

182:                                              ; preds = %177
  call void @llvm.dbg.value(metadata i64 %175, metadata !1591, metadata !DIExpression()), !dbg !3539
  store volatile i64 %175, ptr %140, align 1, !dbg !3540, !tbaa !1534
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3541, !srcloc !1657
  %183 = load i32, ptr %155, align 1, !dbg !3543, !tbaa !1640
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !3538
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !3489
  call void @llvm.dbg.value(metadata i32 %183, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 1, metadata !1215, metadata !DIExpression()), !dbg !3314
  %184 = icmp eq i32 %183, 0, !dbg !3544
  br i1 %184, label %188, label %185, !dbg !3490

185:                                              ; preds = %182
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !3256, metadata ptr %10, metadata !DIExpression()), !dbg !3545
  store i32 %183, ptr %10, align 4, !tbaa !1129, !DIAssignID !3547
  call void @llvm.dbg.assign(metadata i32 %183, metadata !1707, metadata !DIExpression(), metadata !3547, metadata ptr %10, metadata !DIExpression()), !dbg !3545
  %186 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %10) #5, !dbg !3548
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10), !dbg !3549
  call void @llvm.dbg.value(metadata ptr %186, metadata !1205, metadata !DIExpression()), !dbg !3314
  %187 = icmp eq ptr %186, null, !dbg !3550
  call void @llvm.dbg.value(metadata i32 undef, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3551, !srcloc !1721
  br i1 %187, label %188, label %230, !dbg !3552

188:                                              ; preds = %185, %182, %129, %142, %180
  call void @llvm.dbg.value(metadata ptr poison, metadata !1205, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i32 0, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 0, metadata !1215, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata ptr %0, metadata !1723, metadata !DIExpression()), !dbg !3553
  %189 = load i32, ptr %37, align 4, !dbg !3555, !tbaa !1259
  %190 = and i32 %189, 255, !dbg !3555
  %191 = icmp eq i32 %190, 6, !dbg !3556
  br i1 %191, label %192, label %195, !dbg !3555

192:                                              ; preds = %188
  %193 = call i32 inttoptr (i64 7 to ptr)() #5, !dbg !3557
  %194 = zext i32 %193 to i64, !dbg !3557
  br label %197, !dbg !3555

195:                                              ; preds = %188
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3558
  %196 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3560
  br label %197, !dbg !3555

197:                                              ; preds = %195, %192
  %198 = phi i64 [ %194, %192 ], [ %196, %195 ], !dbg !3555
  %199 = load i16, ptr %65, align 4, !dbg !3561, !tbaa !1334
  %200 = zext i16 %199 to i64, !dbg !3562
  %201 = urem i64 %198, %200, !dbg !3563
  %202 = trunc i64 %201 to i16, !dbg !3564
  %203 = add nuw i16 %202, 1, !dbg !3564
  store i16 %203, ptr %49, align 2, !dbg !3565, !tbaa !1298, !DIAssignID !3566
  call void @llvm.dbg.assign(metadata i16 %203, metadata !1193, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3566, metadata ptr %49, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata ptr %20, metadata !1749, metadata !DIExpression()), !dbg !3567
  call void @llvm.dbg.value(metadata ptr %20, metadata !1301, metadata !DIExpression()), !dbg !3569
  %204 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %20) #5, !dbg !3571
  call void @llvm.dbg.value(metadata ptr %204, metadata !1214, metadata !DIExpression()), !dbg !3314
  %205 = icmp eq ptr %204, null, !dbg !3572
  br i1 %205, label %206, label %216, !dbg !3573

206:                                              ; preds = %197
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !3264, metadata ptr %18, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !3265, metadata ptr %19, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.value(metadata i8 5, metadata !1767, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.value(metadata i16 423, metadata !1768, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3574
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %18) #5, !dbg !3576
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3577, metadata ptr %18, metadata !DIExpression()), !dbg !3574
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %19) #5, !dbg !3578
  store i64 21502558725, ptr %19, align 8, !dbg !3579, !DIAssignID !3580
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3580, metadata ptr %19, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3581, metadata ptr %19, metadata !DIExpression()), !dbg !3574
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3582, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3574
  call void @llvm.dbg.assign(metadata i16 423, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3583, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3574
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3584, metadata ptr %19, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3574
  %207 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %19) #5, !dbg !3585
  call void @llvm.dbg.value(metadata ptr %207, metadata !1770, metadata !DIExpression()), !dbg !3574
  %208 = icmp eq ptr %207, null, !dbg !3586
  br i1 %208, label %212, label %209, !dbg !3587

209:                                              ; preds = %206
  %210 = load i64, ptr %207, align 8, !dbg !3588, !tbaa !1790
  %211 = add i64 %210, 1, !dbg !3588
  store i64 %211, ptr %207, align 8, !dbg !3588, !tbaa !1790
  br label %215, !dbg !3589

212:                                              ; preds = %206
  store i64 1, ptr %18, align 8, !dbg !3590, !tbaa !1790, !DIAssignID !3591
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3591, metadata ptr %18, metadata !DIExpression()), !dbg !3574
  %213 = getelementptr inbounds %struct.metrics_value, ptr %18, i64 0, i32 1, !dbg !3592
  store i64 0, ptr %213, align 8, !dbg !3593, !tbaa !1798, !DIAssignID !3594
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3594, metadata ptr %213, metadata !DIExpression()), !dbg !3574
  %214 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %19, ptr noundef nonnull %18, i32 noundef 0) #5, !dbg !3595
  br label %215

215:                                              ; preds = %212, %209
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %19) #5, !dbg !3596
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %18) #5, !dbg !3596
  br label %296, !dbg !3597

216:                                              ; preds = %197
  %217 = load i32, ptr %204, align 4, !dbg !3598, !tbaa !1444
  call void @llvm.dbg.value(metadata i32 %217, metadata !1216, metadata !DIExpression()), !dbg !3314
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9)
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1707, metadata !DIExpression(), metadata !3255, metadata ptr %9, metadata !DIExpression()), !dbg !3599
  store i32 %217, ptr %9, align 4, !tbaa !1129, !DIAssignID !3601
  call void @llvm.dbg.assign(metadata i32 %217, metadata !1707, metadata !DIExpression(), metadata !3601, metadata ptr %9, metadata !DIExpression()), !dbg !3599
  %218 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_backends_v3, ptr noundef nonnull %9) #5, !dbg !3602
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9), !dbg !3603
  call void @llvm.dbg.value(metadata ptr %218, metadata !1205, metadata !DIExpression()), !dbg !3314
  call void @llvm.dbg.value(metadata i8 poison, metadata !1215, metadata !DIExpression()), !dbg !3314
  %219 = icmp eq ptr %218, null, !dbg !3604
  br i1 %219, label %220, label %230, !dbg !3605

220:                                              ; preds = %216
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !3262, metadata ptr %16, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !3263, metadata ptr %17, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.value(metadata i8 6, metadata !1767, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.value(metadata i16 432, metadata !1768, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3606
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %16) #5, !dbg !3608
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3609, metadata ptr %16, metadata !DIExpression()), !dbg !3606
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %17) #5, !dbg !3610
  store i64 21503148550, ptr %17, align 8, !dbg !3611, !DIAssignID !3612
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3612, metadata ptr %17, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.assign(metadata i8 6, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3613, metadata ptr %17, metadata !DIExpression()), !dbg !3606
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3614, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3606
  call void @llvm.dbg.assign(metadata i16 432, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3615, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3606
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3616, metadata ptr %17, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3606
  %221 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %17) #5, !dbg !3617
  call void @llvm.dbg.value(metadata ptr %221, metadata !1770, metadata !DIExpression()), !dbg !3606
  %222 = icmp eq ptr %221, null, !dbg !3618
  br i1 %222, label %226, label %223, !dbg !3619

223:                                              ; preds = %220
  %224 = load i64, ptr %221, align 8, !dbg !3620, !tbaa !1790
  %225 = add i64 %224, 1, !dbg !3620
  store i64 %225, ptr %221, align 8, !dbg !3620, !tbaa !1790
  br label %229, !dbg !3621

226:                                              ; preds = %220
  store i64 1, ptr %16, align 8, !dbg !3622, !tbaa !1790, !DIAssignID !3623
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3623, metadata ptr %16, metadata !DIExpression()), !dbg !3606
  %227 = getelementptr inbounds %struct.metrics_value, ptr %16, i64 0, i32 1, !dbg !3624
  store i64 0, ptr %227, align 8, !dbg !3625, !tbaa !1798, !DIAssignID !3626
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3626, metadata ptr %227, metadata !DIExpression()), !dbg !3606
  %228 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %17, ptr noundef nonnull %16, i32 noundef 0) #5, !dbg !3627
  br label %229

229:                                              ; preds = %226, %223
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %17) #5, !dbg !3628
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %16) #5, !dbg !3628
  br label %296, !dbg !3629

230:                                              ; preds = %185, %216
  %231 = phi ptr [ %218, %216 ], [ %186, %185 ]
  %232 = phi i1 [ false, %216 ], [ true, %185 ]
  %233 = phi i32 [ %217, %216 ], [ %183, %185 ]
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3630, !srcloc !1838
  call void @llvm.dbg.value(metadata ptr %64, metadata !1553, metadata !DIExpression()), !dbg !3631
  %234 = load i8, ptr %86, align 4, !dbg !3633, !tbaa !1361
  %235 = and i8 %234, 16, !dbg !3634
  %236 = icmp eq i8 %235, 0, !dbg !3635
  %237 = or i1 %232, %236, !dbg !3636
  br i1 %237, label %260, label %238, !dbg !3636

238:                                              ; preds = %230
  call void @llvm.dbg.value(metadata ptr %64, metadata !1846, metadata !DIExpression()), !dbg !3637
  call void @llvm.dbg.value(metadata ptr undef, metadata !1851, metadata !DIExpression()), !dbg !3637
  call void @llvm.dbg.value(metadata i32 %233, metadata !1852, metadata !DIExpression()), !dbg !3637
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(), metadata !3248, metadata ptr %2, metadata !DIExpression()), !dbg !3639
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1865, metadata !DIExpression(), metadata !3249, metadata ptr %3, metadata !DIExpression()), !dbg !3639
  call void @llvm.dbg.value(metadata ptr %64, metadata !1860, metadata !DIExpression()), !dbg !3639
  call void @llvm.dbg.value(metadata i8 1, metadata !1861, metadata !DIExpression()), !dbg !3639
  call void @llvm.dbg.value(metadata ptr undef, metadata !1862, metadata !DIExpression()), !dbg !3639
  call void @llvm.dbg.value(metadata i32 %233, metadata !1863, metadata !DIExpression()), !dbg !3639
  %239 = call ptr asm sideeffect "$0 = __config_enable_jiffies ll", "=r"() #5, !dbg !3641, !srcloc !1625
  call void @llvm.dbg.value(metadata ptr %239, metadata !1623, metadata !DIExpression()), !dbg !3643
  %240 = load volatile i8, ptr %239, align 1, !dbg !3644, !tbaa !1341, !range !1343, !noundef !1344
  %241 = icmp eq i8 %240, 0, !dbg !3644
  br i1 %241, label %245, label %242, !dbg !3645

242:                                              ; preds = %238
  %243 = call i64 inttoptr (i64 118 to ptr)() #5, !dbg !3646
  %244 = lshr i64 %243, 8, !dbg !3647
  br label %248, !dbg !3648

245:                                              ; preds = %238
  %246 = call i64 inttoptr (i64 5 to ptr)() #5, !dbg !3649
  %247 = udiv i64 %246, 1000000000, !dbg !3651
  br label %248, !dbg !3652

248:                                              ; preds = %245, %242
  %249 = phi i64 [ %244, %242 ], [ %247, %245 ], !dbg !3653
  call void @llvm.dbg.value(metadata i64 %249, metadata !1864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3639
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #5, !dbg !3654
  store i64 %43, ptr %2, align 8, !dbg !3655, !DIAssignID !3656
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3656, metadata ptr %2, metadata !DIExpression()), !dbg !3639
  %250 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 1, !dbg !3657
  %251 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 2, !dbg !3658
  %252 = load i16, ptr %251, align 2, !dbg !3658, !tbaa !1601
  store i16 %252, ptr %250, align 8, !dbg !3657, !tbaa !1602, !DIAssignID !3659
  call void @llvm.dbg.assign(metadata i16 %252, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 16), metadata !3659, metadata ptr %250, metadata !DIExpression()), !dbg !3639
  %253 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 2, !dbg !3657
  call void @llvm.dbg.assign(metadata i8 poison, metadata !1855, metadata !DIExpression(DW_OP_constu, 18446744073709551614, DW_OP_and, DW_OP_constu, 1, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 80, 8), metadata !3660, metadata ptr %253, metadata !DIExpression()), !dbg !3639
  store i8 1, ptr %253, align 2, !dbg !3657, !DIAssignID !3661
  call void @llvm.dbg.assign(metadata i8 1, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8), metadata !3661, metadata ptr %253, metadata !DIExpression()), !dbg !3639
  %254 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 3, !dbg !3657
  store i8 0, ptr %254, align 1, !dbg !3657, !tbaa !1607, !DIAssignID !3662
  call void @llvm.dbg.assign(metadata i8 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8), metadata !3662, metadata ptr %254, metadata !DIExpression()), !dbg !3639
  %255 = getelementptr inbounds %struct.lb4_affinity_key, ptr %2, i64 0, i32 4, !dbg !3657
  store i32 0, ptr %255, align 4, !dbg !3657, !tbaa !1609, !DIAssignID !3663
  call void @llvm.dbg.assign(metadata i32 0, metadata !1855, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3663, metadata ptr %255, metadata !DIExpression()), !dbg !3639
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %3) #5, !dbg !3664
  %256 = and i64 %249, 4294967295, !dbg !3665
  store i64 %256, ptr %3, align 8, !dbg !3666, !tbaa !1894, !DIAssignID !3667
  call void @llvm.dbg.assign(metadata i64 %256, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3667, metadata ptr %3, metadata !DIExpression()), !dbg !3639
  %257 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 1, !dbg !3666
  store i32 %233, ptr %257, align 8, !dbg !3666, !tbaa !1640, !DIAssignID !3668
  call void @llvm.dbg.assign(metadata i32 %233, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3668, metadata ptr %257, metadata !DIExpression()), !dbg !3639
  %258 = getelementptr inbounds %struct.lb_affinity_val, ptr %3, i64 0, i32 2, !dbg !3666
  store i32 0, ptr %258, align 4, !dbg !3666, !tbaa !1897, !DIAssignID !3669
  call void @llvm.dbg.assign(metadata i32 0, metadata !1865, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 32), metadata !3669, metadata ptr %258, metadata !DIExpression()), !dbg !3639
  %259 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_affinity, ptr noundef nonnull %2, ptr noundef nonnull %3, i32 noundef 0) #5, !dbg !3670
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %3) #5, !dbg !3671
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #5, !dbg !3671
  br label %260, !dbg !3672

260:                                              ; preds = %248, %230
  %261 = getelementptr inbounds %struct.lb4_backend, ptr %231, i64 0, i32 1, !dbg !3673
  %262 = getelementptr inbounds %struct.lb4_service, ptr %64, i64 0, i32 2, !dbg !3674
  %263 = load i16, ptr %262, align 2, !dbg !3674, !tbaa !1601
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1905, metadata !DIExpression(), metadata !3253, metadata ptr %7, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1916, metadata !DIExpression(), metadata !3254, metadata ptr %8, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata ptr %0, metadata !1910, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata ptr %231, metadata !1911, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata i32 %32, metadata !1912, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata i16 %46, metadata !1913, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata i16 %263, metadata !1914, metadata !DIExpression()), !dbg !3675
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %7) #5, !dbg !3677
  call void @llvm.dbg.assign(metadata i64 0, metadata !1905, metadata !DIExpression(), metadata !3678, metadata ptr %7, metadata !DIExpression()), !dbg !3675
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %8) #5, !dbg !3679
  %264 = getelementptr inbounds i8, ptr %8, i64 8, !dbg !3680
  store i64 0, ptr %264, align 8, !dbg !3680, !DIAssignID !3681
  call void @llvm.dbg.assign(metadata i64 0, metadata !1916, metadata !DIExpression(), metadata !3681, metadata ptr %8, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.assign(metadata i8 0, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3682, metadata ptr undef, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3675
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3683
  %265 = call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3685
  store i64 %265, ptr %8, align 8, !dbg !3686, !tbaa !1930, !DIAssignID !3687
  call void @llvm.dbg.assign(metadata i64 %265, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3687, metadata ptr %8, metadata !DIExpression()), !dbg !3675
  %266 = load i32, ptr %231, align 4, !dbg !3688, !tbaa !1934
  %267 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 1, !dbg !3689
  store i32 %266, ptr %267, align 8, !dbg !3690, !tbaa !1938, !DIAssignID !3691
  call void @llvm.dbg.assign(metadata i32 %266, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3691, metadata ptr %267, metadata !DIExpression()), !dbg !3675
  %268 = load i16, ptr %261, align 4, !dbg !3692, !tbaa !1941
  %269 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %8, i64 0, i32 2, !dbg !3693
  store i16 %268, ptr %269, align 4, !dbg !3694, !tbaa !1944, !DIAssignID !3695
  call void @llvm.dbg.assign(metadata i16 %268, metadata !1916, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3695, metadata ptr %269, metadata !DIExpression()), !dbg !3675
  store i32 %32, ptr %7, align 4, !dbg !3696, !tbaa !1947, !DIAssignID !3697
  call void @llvm.dbg.assign(metadata i32 %32, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3697, metadata ptr %7, metadata !DIExpression()), !dbg !3675
  %270 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 1, !dbg !3698
  store i16 %46, ptr %270, align 4, !dbg !3699, !tbaa !1952, !DIAssignID !3700
  call void @llvm.dbg.assign(metadata i16 %46, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3700, metadata ptr %270, metadata !DIExpression()), !dbg !3675
  %271 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %7, i64 0, i32 2, !dbg !3701
  store i16 %263, ptr %271, align 2, !dbg !3702, !tbaa !1956, !DIAssignID !3703
  call void @llvm.dbg.assign(metadata i16 %263, metadata !1905, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3703, metadata ptr %271, metadata !DIExpression()), !dbg !3675
  %272 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8) #5, !dbg !3704
  call void @llvm.dbg.value(metadata ptr %272, metadata !1915, metadata !DIExpression()), !dbg !3675
  %273 = icmp eq ptr %272, null, !dbg !3705
  br i1 %273, label %279, label %274, !dbg !3706

274:                                              ; preds = %260
  call void @llvm.dbg.value(metadata ptr %272, metadata !1962, metadata !DIExpression()), !dbg !3707
  call void @llvm.dbg.value(metadata ptr %7, metadata !1967, metadata !DIExpression()), !dbg !3707
  call void @llvm.dbg.value(metadata i64 8, metadata !1968, metadata !DIExpression()), !dbg !3707
  call void @llvm.dbg.value(metadata i64 8, metadata !1971, metadata !DIExpression()), !dbg !3709
  call void @llvm.dbg.value(metadata i64 0, metadata !1976, metadata !DIExpression()), !dbg !3709
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3709
  call void @llvm.dbg.value(metadata ptr %272, metadata !1974, metadata !DIExpression(DW_OP_plus_uconst, 8, DW_OP_stack_value)), !dbg !3709
  call void @llvm.dbg.label(metadata !1992), !dbg !3711
  call void @llvm.dbg.value(metadata ptr %272, metadata !1974, metadata !DIExpression()), !dbg !3709
  call void @llvm.dbg.value(metadata ptr %7, metadata !1975, metadata !DIExpression()), !dbg !3709
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_or, DW_OP_stack_value)), !dbg !3709
  %275 = load i64, ptr %272, align 8, !dbg !3712, !tbaa !1534
  %276 = load i64, ptr %7, align 8, !dbg !3712, !tbaa !1534
  call void @llvm.dbg.value(metadata !DIArgList(i64 %275, i64 %276), metadata !1976, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !3709
  %277 = icmp eq i64 %275, %276, !dbg !3713
  br i1 %277, label %278, label %279, !dbg !3714

278:                                              ; preds = %274
  call void @llvm.dbg.value(metadata i32 0, metadata !1917, metadata !DIExpression()), !dbg !3675
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !3715
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !3715
  br label %292, !dbg !3716

279:                                              ; preds = %260, %274
  %280 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %8, ptr noundef nonnull %7, i32 noundef 0) #5, !dbg !3717
  call void @llvm.dbg.value(metadata i32 %280, metadata !1917, metadata !DIExpression()), !dbg !3675
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %8) #5, !dbg !3715
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %7) #5, !dbg !3715
  %281 = icmp slt i32 %280, 0, !dbg !3718
  br i1 %281, label %282, label %292, !dbg !3716

282:                                              ; preds = %279
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !3260, metadata ptr %14, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !3261, metadata ptr %15, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.value(metadata i8 7, metadata !1767, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.value(metadata i16 448, metadata !1768, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3719
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %14) #5, !dbg !3721
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3722, metadata ptr %14, metadata !DIExpression()), !dbg !3719
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %15) #5, !dbg !3723
  store i64 21504197127, ptr %15, align 8, !dbg !3724, !DIAssignID !3725
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3725, metadata ptr %15, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.assign(metadata i8 7, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3726, metadata ptr %15, metadata !DIExpression()), !dbg !3719
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3727, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3719
  call void @llvm.dbg.assign(metadata i16 448, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3728, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3719
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3729, metadata ptr %15, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3719
  %283 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %15) #5, !dbg !3730
  call void @llvm.dbg.value(metadata ptr %283, metadata !1770, metadata !DIExpression()), !dbg !3719
  %284 = icmp eq ptr %283, null, !dbg !3731
  br i1 %284, label %288, label %285, !dbg !3732

285:                                              ; preds = %282
  %286 = load i64, ptr %283, align 8, !dbg !3733, !tbaa !1790
  %287 = add i64 %286, 1, !dbg !3733
  store i64 %287, ptr %283, align 8, !dbg !3733, !tbaa !1790
  br label %291, !dbg !3734

288:                                              ; preds = %282
  store i64 1, ptr %14, align 8, !dbg !3735, !tbaa !1790, !DIAssignID !3736
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3736, metadata ptr %14, metadata !DIExpression()), !dbg !3719
  %289 = getelementptr inbounds %struct.metrics_value, ptr %14, i64 0, i32 1, !dbg !3737
  store i64 0, ptr %289, align 8, !dbg !3738, !tbaa !1798, !DIAssignID !3739
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3739, metadata ptr %289, metadata !DIExpression()), !dbg !3719
  %290 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %15, ptr noundef nonnull %14, i32 noundef 0) #5, !dbg !3740
  br label %291

291:                                              ; preds = %288, %285
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %15) #5, !dbg !3741
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %14) #5, !dbg !3741
  br label %296, !dbg !3742

292:                                              ; preds = %278, %279
  %293 = load i32, ptr %231, align 4, !dbg !3743, !tbaa !1934
  tail call void @llvm.dbg.value(metadata i32 %293, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !3270
  %294 = load i16, ptr %261, align 4, !dbg !3744, !tbaa !1941
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !3745
  call void @llvm.dbg.value(metadata i16 %294, metadata !2038, metadata !DIExpression()), !dbg !3745
  %295 = zext i16 %294 to i32, !dbg !3747
  tail call void @llvm.dbg.value(metadata i16 %294, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !3270
  br label %298, !dbg !3748

296:                                              ; preds = %291, %229, %215, %68, %123, %60, %111, %104, %36, %80, %77
  %297 = phi i32 [ -1, %104 ], [ -1, %111 ], [ -6, %60 ], [ -6, %123 ], [ -113, %68 ], [ -113, %215 ], [ -113, %229 ], [ -12, %291 ], [ -6, %36 ], [ -113, %80 ], [ -113, %77 ]
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3270
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %20) #5, !dbg !3749
  call void @llvm.dbg.value(metadata i32 %297, metadata !2689, metadata !DIExpression()), !dbg !3270
  br label %301, !dbg !3750

298:                                              ; preds = %77, %90, %292, %80
  %299 = phi i32 [ %42, %90 ], [ %295, %292 ], [ %42, %80 ], [ %42, %77 ], !dbg !3270
  %300 = phi i32 [ %32, %90 ], [ %293, %292 ], [ %32, %80 ], [ %32, %77 ]
  tail call void @llvm.dbg.value(metadata i32 %300, metadata !2687, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !2687, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3270
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %20) #5, !dbg !3749
  call void @llvm.dbg.value(metadata i32 poison, metadata !2689, metadata !DIExpression()), !dbg !3270
  call void @llvm.dbg.value(metadata ptr undef, metadata !1497, metadata !DIExpression()), !dbg !3751
  call void @llvm.dbg.value(metadata i32 0, metadata !1503, metadata !DIExpression()), !dbg !3751
  call void @llvm.dbg.value(metadata i64 16, metadata !1504, metadata !DIExpression()), !dbg !3751
  call void @llvm.dbg.value(metadata i64 16, metadata !1507, metadata !DIExpression()), !dbg !3754
  call void @llvm.dbg.value(metadata ptr undef, metadata !1512, metadata !DIExpression()), !dbg !3754
  call void @llvm.dbg.label(metadata !1527), !dbg !3756
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  call void @llvm.dbg.label(metadata !1528), !dbg !3757
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2688, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3270
  tail call void @llvm.dbg.value(metadata i32 %300, metadata !2688, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 64)), !dbg !3270
  call void @llvm.dbg.value(metadata ptr %0, metadata !3216, metadata !DIExpression()), !dbg !3758
  call void @llvm.dbg.value(metadata ptr undef, metadata !3221, metadata !DIExpression()), !dbg !3758
  store i32 0, ptr %21, align 8, !dbg !3760, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3761, !srcloc !3226
  store i32 0, ptr %24, align 4, !dbg !3762, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3763, !srcloc !3229
  store i32 -65536, ptr %29, align 8, !dbg !3764, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3765, !srcloc !3232
  store i32 %300, ptr %31, align 4, !dbg !3766, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3767, !srcloc !3235
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !3768
  call void @llvm.dbg.value(metadata i32 %299, metadata !2038, metadata !DIExpression()), !dbg !3768
  store i32 %299, ptr %39, align 8, !dbg !3770, !tbaa !1251
  br label %301, !dbg !3771

301:                                              ; preds = %1, %296, %298
  %302 = phi i32 [ 0, %298 ], [ %297, %296 ], [ -6, %1 ], !dbg !3270
  tail call void @llvm.dbg.value(metadata i32 %302, metadata !3247, metadata !DIExpression()), !dbg !3267
  %303 = icmp eq i32 %302, -113, !dbg !3772
  %304 = icmp eq i32 %302, -12
  %305 = call i1 @llvm.bpf.passthrough.i1.i1(i32 3, i1 %303)
  %306 = or i1 %305, %304, !dbg !3774
  %307 = xor i1 %306, true, !dbg !3774
  %308 = zext i1 %307 to i32, !dbg !3774
  ret i32 %308, !dbg !3775
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock6_recvmsg(ptr noundef %0) #0 section "cgroup/recvmsg6" !dbg !3776 {
  %2 = alloca i32, align 4, !DIAssignID !3779
  %3 = alloca i32, align 4, !DIAssignID !3780
  %4 = alloca %struct.metrics_value, align 8, !DIAssignID !3781
  %5 = alloca %struct.metrics_key, align 8, !DIAssignID !3782
  %6 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !3783
  %7 = alloca %struct.lb4_key, align 4, !DIAssignID !3784
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3778, metadata !DIExpression()), !dbg !3785
  call void @llvm.dbg.value(metadata ptr %0, metadata !3786, metadata !DIExpression()), !dbg !3789
  call void @llvm.dbg.value(metadata ptr %0, metadata !3791, metadata !DIExpression()), !dbg !3797
  call void @llvm.dbg.value(metadata ptr %0, metadata !2692, metadata !DIExpression()), !dbg !3799
  call void @llvm.dbg.value(metadata ptr undef, metadata !2698, metadata !DIExpression()), !dbg !3799
  %8 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, !dbg !3801
  %9 = load i32, ptr %8, align 8, !dbg !3802, !tbaa !1129
  %10 = zext i32 %9 to i64, !dbg !3803
  tail call void @llvm.dbg.value(metadata i64 %10, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32)), !dbg !3797
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3804, !srcloc !2705
  %11 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 1, !dbg !3805
  %12 = load i32, ptr %11, align 4, !dbg !3805, !tbaa !1129
  %13 = zext i32 %12 to i64, !dbg !3806
  %14 = shl nuw i64 %13, 32, !dbg !3806
  %15 = or disjoint i64 %14, %10, !dbg !3806
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 32)), !dbg !3797
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3807, !srcloc !2709
  %16 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 2, !dbg !3808
  %17 = load i32, ptr %16, align 8, !dbg !3808, !tbaa !1129
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !3795, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !3797
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3809, !srcloc !2712
  %18 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 2, i64 3, !dbg !3810
  %19 = load i32, ptr %18, align 4, !dbg !3810, !tbaa !1129
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !3795, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !3797
  tail call void asm sideeffect "", "~{memory}"() #5, !dbg !3811, !srcloc !2715
  call void @llvm.dbg.value(metadata ptr undef, metadata !2716, metadata !DIExpression()), !dbg !3812
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3812
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !2724, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3812
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3812
  tail call void @llvm.dbg.value(metadata i64 0, metadata !2725, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3812
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !2725, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !3812
  call void @llvm.dbg.value(metadata ptr undef, metadata !2729, metadata !DIExpression()), !dbg !3815
  call void @llvm.dbg.value(metadata ptr undef, metadata !2734, metadata !DIExpression()), !dbg !3815
  %20 = icmp eq i64 %15, 0, !dbg !3817
  %21 = icmp eq i32 %17, -65536
  %22 = select i1 %20, i1 %21, i1 false, !dbg !3818
  br i1 %22, label %23, label %88, !dbg !3818

23:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !3795, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32)), !dbg !3797
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 poison, i32 poison), metadata !3795, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  %24 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 6, !dbg !3819
  %25 = load i32, ptr %24, align 4, !dbg !3819, !tbaa !1259
  tail call void @llvm.dbg.value(metadata i32 %25, metadata !3794, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 288, 32)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3794, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !3797
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !3779, metadata ptr %2, metadata !DIExpression()), !dbg !3820
  call void @llvm.dbg.value(metadata ptr %0, metadata !1246, metadata !DIExpression()), !dbg !3820
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2), !dbg !3822
  %26 = getelementptr inbounds %struct.bpf_sock_addr, ptr %0, i64 0, i32 3, !dbg !3823
  %27 = load i32, ptr %26, align 8, !dbg !3823, !tbaa !1251
  store volatile i32 %27, ptr %2, align 4, !dbg !3824, !tbaa !1129, !DIAssignID !3825
  call void @llvm.dbg.assign(metadata i32 %27, metadata !1239, metadata !DIExpression(), metadata !3825, metadata ptr %2, metadata !DIExpression()), !dbg !3820
  %28 = load volatile i32, ptr %2, align 4, !dbg !3826, !tbaa !1129
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2), !dbg !3827
  %29 = and i32 %28, 65535, !dbg !3828
  tail call void @llvm.dbg.value(metadata i32 undef, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !3797
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2522, metadata !DIExpression(), metadata !3783, metadata ptr %6, metadata !DIExpression()), !dbg !3829
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2536, metadata !DIExpression(), metadata !3784, metadata ptr %7, metadata !DIExpression()), !dbg !3831
  call void @llvm.dbg.value(metadata ptr undef, metadata !2527, metadata !DIExpression()), !dbg !3829
  call void @llvm.dbg.value(metadata ptr %0, metadata !2528, metadata !DIExpression()), !dbg !3829
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1239, metadata !DIExpression(), metadata !3780, metadata ptr %3, metadata !DIExpression()), !dbg !3832
  call void @llvm.dbg.value(metadata ptr undef, metadata !1246, metadata !DIExpression()), !dbg !3832
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %3), !dbg !3834
  store volatile i32 %29, ptr %3, align 4, !dbg !3835, !tbaa !1129, !DIAssignID !3836
  call void @llvm.dbg.assign(metadata i32 %29, metadata !1239, metadata !DIExpression(DW_OP_constu, 65535, DW_OP_and, DW_OP_stack_value), metadata !3836, metadata ptr %3, metadata !DIExpression()), !dbg !3832
  %30 = load volatile i32, ptr %3, align 4, !dbg !3837, !tbaa !1129
  %31 = trunc i32 %30 to i16, !dbg !3838
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %3), !dbg !3839
  call void @llvm.dbg.value(metadata i16 %31, metadata !2530, metadata !DIExpression()), !dbg !3829
  call void @llvm.dbg.value(metadata i32 %25, metadata !2531, metadata !DIExpression(DW_OP_constu, 255, DW_OP_and, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !3829
  call void @llvm.dbg.value(metadata i32 poison, metadata !2532, metadata !DIExpression()), !dbg !3829
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %6) #5, !dbg !3840
  call void @llvm.dbg.value(metadata ptr %0, metadata !1735, metadata !DIExpression()), !dbg !3841
  %32 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3843
  store i64 %32, ptr %6, align 8, !dbg !3844, !tbaa !1930, !DIAssignID !3845
  call void @llvm.dbg.assign(metadata i64 %32, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3845, metadata ptr %6, metadata !DIExpression()), !dbg !3829
  %33 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 1, !dbg !3844
  store i32 %19, ptr %33, align 8, !dbg !3844, !tbaa !1938, !DIAssignID !3846
  call void @llvm.dbg.assign(metadata i32 poison, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3846, metadata ptr %33, metadata !DIExpression()), !dbg !3829
  %34 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 2, !dbg !3844
  store i16 %31, ptr %34, align 4, !dbg !3844, !tbaa !1944, !DIAssignID !3847
  call void @llvm.dbg.assign(metadata i16 %31, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3847, metadata ptr %34, metadata !DIExpression()), !dbg !3829
  %35 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %6, i64 0, i32 3, !dbg !3844
  store i16 0, ptr %35, align 2, !dbg !3844, !tbaa !2559, !DIAssignID !3848
  call void @llvm.dbg.assign(metadata i16 0, metadata !2522, metadata !DIExpression(DW_OP_LLVM_fragment, 112, 16), metadata !3848, metadata ptr %35, metadata !DIExpression()), !dbg !3829
  %36 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %6) #5, !dbg !3849
  call void @llvm.dbg.value(metadata ptr %36, metadata !2529, metadata !DIExpression()), !dbg !3829
  %37 = icmp eq ptr %36, null, !dbg !3850
  br i1 %37, label %38, label %39, !dbg !3851

38:                                               ; preds = %23
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #5, !dbg !3852
  call void @llvm.dbg.value(metadata i32 -6, metadata !3796, metadata !DIExpression()), !dbg !3797
  br label %88, !dbg !3853

39:                                               ; preds = %23
  %40 = trunc i32 %25 to i8, !dbg !3854
  call void @llvm.dbg.value(metadata i8 %40, metadata !2531, metadata !DIExpression()), !dbg !3829
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %7) #5, !dbg !3855
  %41 = load i32, ptr %36, align 4, !dbg !3856, !tbaa !1947
  store i32 %41, ptr %7, align 4, !dbg !3857, !tbaa !1264, !DIAssignID !3858
  call void @llvm.dbg.assign(metadata i32 %41, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 32), metadata !3858, metadata ptr %7, metadata !DIExpression()), !dbg !3831
  %42 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 1, !dbg !3857
  %43 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %36, i64 0, i32 1, !dbg !3859
  %44 = load i16, ptr %43, align 4, !dbg !3859, !tbaa !1952
  store i16 %44, ptr %42, align 4, !dbg !3857, !tbaa !1268, !DIAssignID !3860
  call void @llvm.dbg.assign(metadata i16 %44, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 16), metadata !3860, metadata ptr %42, metadata !DIExpression()), !dbg !3831
  %45 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 2, !dbg !3857
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 48, 16), metadata !3861, metadata ptr %45, metadata !DIExpression()), !dbg !3831
  %46 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 3, !dbg !3857
  store i8 %40, ptr %46, align 4, !dbg !3857, !tbaa !1271, !DIAssignID !3862
  call void @llvm.dbg.assign(metadata i8 %40, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8), metadata !3862, metadata ptr %46, metadata !DIExpression()), !dbg !3831
  %47 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 4, !dbg !3857
  call void @llvm.dbg.assign(metadata i8 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 72, 8), metadata !3863, metadata ptr %47, metadata !DIExpression()), !dbg !3831
  %48 = getelementptr inbounds %struct.lb4_key, ptr %7, i64 0, i32 5, !dbg !3857
  store i16 0, ptr %48, align 2, !dbg !3857, !DIAssignID !3864
  call void @llvm.dbg.assign(metadata i16 0, metadata !2536, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 16), metadata !3864, metadata ptr %48, metadata !DIExpression()), !dbg !3831
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1284, metadata !DIExpression(), metadata !3865, metadata ptr undef, metadata !DIExpression()), !dbg !3866
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1292, metadata !DIExpression(), metadata !3868, metadata ptr undef, metadata !DIExpression()), !dbg !3866
  call void @llvm.dbg.value(metadata ptr %7, metadata !1289, metadata !DIExpression()), !dbg !3866
  call void @llvm.dbg.value(metadata i8 1, metadata !1290, metadata !DIExpression()), !dbg !3866
  store i16 0, ptr %45, align 2, !dbg !3869, !tbaa !1298
  store i8 0, ptr %47, align 1, !dbg !3870, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %7, metadata !1301, metadata !DIExpression()), !dbg !3871
  %49 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %7) #5, !dbg !3873
  call void @llvm.dbg.value(metadata ptr %49, metadata !1291, metadata !DIExpression()), !dbg !3866
  %50 = icmp eq ptr %49, null, !dbg !3874
  br i1 %50, label %59, label %51, !dbg !3875

51:                                               ; preds = %39
  call void @llvm.dbg.value(metadata ptr %49, metadata !1312, metadata !DIExpression()), !dbg !3876
  %52 = getelementptr inbounds %struct.lb4_service, ptr %49, i64 0, i32 4, !dbg !3878
  %53 = load i8, ptr %52, align 1, !dbg !3878, !tbaa !1321
  %54 = and i8 %53, 32, !dbg !3879
  %55 = icmp eq i8 %54, 0, !dbg !3880
  br i1 %55, label %62, label %56, !dbg !3881

56:                                               ; preds = %51
  store i8 1, ptr %47, align 1, !dbg !3882, !tbaa !1300
  call void @llvm.dbg.value(metadata ptr %7, metadata !1301, metadata !DIExpression()), !dbg !3883
  %57 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_lb4_services_v2, ptr noundef nonnull %7) #5, !dbg !3885
  call void @llvm.dbg.value(metadata ptr %57, metadata !2533, metadata !DIExpression()), !dbg !3831
  %58 = icmp eq ptr %57, null, !dbg !3886
  br i1 %58, label %59, label %62, !dbg !3887

59:                                               ; preds = %39, %56
  call void @llvm.dbg.value(metadata ptr %0, metadata !1227, metadata !DIExpression()), !dbg !3888
  call void @llvm.dbg.value(metadata ptr null, metadata !1233, metadata !DIExpression()), !dbg !3888
  %60 = call i64 inttoptr (i64 122 to ptr)(ptr noundef nonnull %0) #5, !dbg !3890
  call void @llvm.dbg.value(metadata i64 %60, metadata !1234, metadata !DIExpression()), !dbg !3888
  %61 = call i64 inttoptr (i64 122 to ptr)(ptr noundef null) #5, !dbg !3891
  br label %73, !dbg !3892

62:                                               ; preds = %51, %56
  %63 = phi ptr [ %57, %56 ], [ %49, %51 ]
  call void @llvm.dbg.value(metadata ptr %63, metadata !2533, metadata !DIExpression()), !dbg !3831
  %64 = getelementptr inbounds %struct.lb4_service, ptr %63, i64 0, i32 2, !dbg !3893
  %65 = load i16, ptr %64, align 2, !dbg !3893, !tbaa !1601
  %66 = getelementptr inbounds %struct.ipv4_revnat_entry, ptr %36, i64 0, i32 2, !dbg !3894
  %67 = load i16, ptr %66, align 2, !dbg !3894, !tbaa !1956
  %68 = icmp eq i16 %65, %67, !dbg !3895
  br i1 %68, label %69, label %73, !dbg !3896

69:                                               ; preds = %62
  %70 = getelementptr inbounds %struct.lb4_service, ptr %63, i64 0, i32 1, !dbg !3897
  %71 = load i16, ptr %70, align 4, !dbg !3897, !tbaa !1334
  %72 = icmp eq i16 %71, 0, !dbg !3898
  br i1 %72, label %73, label %84, !dbg !3899

73:                                               ; preds = %59, %69, %62
  %74 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %6) #5, !dbg !3900
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !3781, metadata ptr %4, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !3782, metadata ptr %5, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.value(metadata i8 1, metadata !1766, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.value(metadata i8 8, metadata !1767, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.value(metadata i16 612, metadata !1768, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3901
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !3903
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3904, metadata ptr %4, metadata !DIExpression()), !dbg !3901
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5) #5, !dbg !3905
  store i64 21514944776, ptr %5, align 8, !dbg !3906, !DIAssignID !3907
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !3907, metadata ptr %5, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.assign(metadata i8 8, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !3908, metadata ptr %5, metadata !DIExpression()), !dbg !3901
  call void @llvm.dbg.assign(metadata i8 1, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !3909, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3901
  call void @llvm.dbg.assign(metadata i16 612, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !3910, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3901
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !3911, metadata ptr %5, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3901
  %75 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %5) #5, !dbg !3912
  call void @llvm.dbg.value(metadata ptr %75, metadata !1770, metadata !DIExpression()), !dbg !3901
  %76 = icmp eq ptr %75, null, !dbg !3913
  br i1 %76, label %80, label %77, !dbg !3914

77:                                               ; preds = %73
  %78 = load i64, ptr %75, align 8, !dbg !3915, !tbaa !1790
  %79 = add i64 %78, 1, !dbg !3915
  store i64 %79, ptr %75, align 8, !dbg !3915, !tbaa !1790
  br label %83, !dbg !3916

80:                                               ; preds = %73
  store i64 1, ptr %4, align 8, !dbg !3917, !tbaa !1790, !DIAssignID !3918
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3918, metadata ptr %4, metadata !DIExpression()), !dbg !3901
  %81 = getelementptr inbounds %struct.metrics_value, ptr %4, i64 0, i32 1, !dbg !3919
  store i64 0, ptr %81, align 8, !dbg !3920, !tbaa !1798, !DIAssignID !3921
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !3921, metadata ptr %81, metadata !DIExpression()), !dbg !3901
  %82 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %5, ptr noundef nonnull %4, i32 noundef 0) #5, !dbg !3922
  br label %83

83:                                               ; preds = %77, %80
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5) #5, !dbg !3923
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !3923
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %7) #5, !dbg !3924
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #5, !dbg !3852
  call void @llvm.dbg.value(metadata i32 -2, metadata !3796, metadata !DIExpression()), !dbg !3797
  br label %88, !dbg !3853

84:                                               ; preds = %69
  %85 = load i32, ptr %36, align 4, !dbg !3925, !tbaa !1947
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32)), !dbg !3797
  %86 = load i16, ptr %43, align 4, !dbg !3926, !tbaa !1952
  call void @llvm.dbg.value(metadata ptr undef, metadata !2033, metadata !DIExpression()), !dbg !3927
  call void @llvm.dbg.value(metadata i16 poison, metadata !2038, metadata !DIExpression()), !dbg !3927
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 32)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %7) #5, !dbg !3924
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i16 poison, metadata !3794, metadata !DIExpression(DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 192, 64)), !dbg !3797
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %6) #5, !dbg !3852
  call void @llvm.dbg.value(metadata i32 0, metadata !3796, metadata !DIExpression()), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 16711680, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 80, 8)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i64 4294901760, metadata !3795, metadata !DIExpression(DW_OP_LLVM_fragment, 88, 8)), !dbg !3797
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !3795, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_constu, 4294901760, DW_OP_or, DW_OP_stack_value, DW_OP_LLVM_fragment, 96, 32)), !dbg !3797
  call void @llvm.dbg.value(metadata ptr %0, metadata !3216, metadata !DIExpression()), !dbg !3929
  call void @llvm.dbg.value(metadata ptr undef, metadata !3221, metadata !DIExpression()), !dbg !3929
  store i32 0, ptr %8, align 8, !dbg !3931, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3932, !srcloc !3226
  store i32 0, ptr %11, align 4, !dbg !3933, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3934, !srcloc !3229
  store i32 -65536, ptr %16, align 8, !dbg !3935, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3936, !srcloc !3232
  store i32 %85, ptr %18, align 4, !dbg !3937, !tbaa !1129
  call void asm sideeffect "", "~{memory}"() #5, !dbg !3938, !srcloc !3235
  call void @llvm.dbg.value(metadata ptr %0, metadata !2033, metadata !DIExpression()), !dbg !3939
  call void @llvm.dbg.value(metadata i16 %86, metadata !2038, metadata !DIExpression()), !dbg !3939
  %87 = zext i16 %86 to i32, !dbg !3941
  store i32 %87, ptr %26, align 8, !dbg !3942, !tbaa !1251
  br label %88, !dbg !3943

88:                                               ; preds = %1, %83, %38, %84
  ret i32 1, !dbg !3944
}

; Function Attrs: nounwind
define dso_local noundef i32 @cil_sock_release(ptr noundef %0) #0 section "cgroup/sock_release" !dbg !3945 {
  %2 = alloca %struct.metrics_value, align 8, !DIAssignID !3950
  %3 = alloca %struct.metrics_key, align 8, !DIAssignID !3951
  %4 = alloca %struct.ipv4_revnat_tuple, align 8, !DIAssignID !3952
  tail call void @llvm.dbg.value(metadata ptr %0, metadata !3949, metadata !DIExpression()), !dbg !3953
  %5 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 1, !dbg !3954
  %6 = load i32, ptr %5, align 4, !dbg !3954, !tbaa !3956
  %7 = icmp eq i32 %6, 2, !dbg !3958
  br i1 %7, label %8, label %29, !dbg !3959

8:                                                ; preds = %1
  call void @llvm.dbg.assign(metadata i1 undef, metadata !3960, metadata !DIExpression(), metadata !3952, metadata ptr %4, metadata !DIExpression()), !dbg !3970
  call void @llvm.dbg.value(metadata ptr %0, metadata !3967, metadata !DIExpression()), !dbg !3970
  call void @llvm.dbg.value(metadata ptr %0, metadata !3968, metadata !DIExpression()), !dbg !3970
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %4) #5, !dbg !3974
  %9 = getelementptr inbounds i8, ptr %4, i64 8, !dbg !3975
  store i64 0, ptr %9, align 8, !dbg !3975, !DIAssignID !3976
  call void @llvm.dbg.assign(metadata i64 0, metadata !3960, metadata !DIExpression(), metadata !3976, metadata ptr %4, metadata !DIExpression()), !dbg !3970
  call void @llvm.dbg.assign(metadata i8 0, metadata !3960, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3977, metadata ptr undef, metadata !DIExpression()), !dbg !3970
  call void @llvm.dbg.value(metadata i32 0, metadata !3969, metadata !DIExpression()), !dbg !3970
  %10 = tail call i64 inttoptr (i64 46 to ptr)(ptr noundef nonnull %0) #5, !dbg !3978
  store i64 %10, ptr %4, align 8, !dbg !3979, !tbaa !1930, !DIAssignID !3980
  call void @llvm.dbg.assign(metadata i64 %10, metadata !3960, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !3980, metadata ptr %4, metadata !DIExpression()), !dbg !3970
  %11 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 11, !dbg !3981
  %12 = load i32, ptr %11, align 4, !dbg !3981, !tbaa !3982
  %13 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %4, i64 0, i32 1, !dbg !3983
  store i32 %12, ptr %13, align 8, !dbg !3984, !tbaa !1938, !DIAssignID !3985
  call void @llvm.dbg.assign(metadata i32 %12, metadata !3960, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 32), metadata !3985, metadata ptr %13, metadata !DIExpression()), !dbg !3970
  %14 = getelementptr inbounds %struct.bpf_sock, ptr %0, i64 0, i32 9, !dbg !3986
  %15 = load i16, ptr %14, align 4, !dbg !3986, !tbaa !3987
  %16 = getelementptr inbounds %struct.ipv4_revnat_tuple, ptr %4, i64 0, i32 2, !dbg !3988
  store i16 %15, ptr %16, align 4, !dbg !3989, !tbaa !1944, !DIAssignID !3990
  call void @llvm.dbg.assign(metadata i16 %15, metadata !3960, metadata !DIExpression(DW_OP_LLVM_fragment, 96, 16), metadata !3990, metadata ptr %16, metadata !DIExpression()), !dbg !3970
  %17 = call i32 inttoptr (i64 3 to ptr)(ptr noundef nonnull @cilium_lb4_reverse_sk, ptr noundef nonnull %4) #5, !dbg !3991
  call void @llvm.dbg.value(metadata i32 %17, metadata !3969, metadata !DIExpression()), !dbg !3970
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %4) #5, !dbg !3992
  %18 = icmp eq i32 %17, 0, !dbg !3993
  br i1 %18, label %19, label %29, !dbg !3994

19:                                               ; preds = %8
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1760, metadata !DIExpression(), metadata !3950, metadata ptr %2, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1771, metadata !DIExpression(), metadata !3951, metadata ptr %3, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata i64 0, metadata !1765, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata i8 2, metadata !1766, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata i8 14, metadata !1767, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata i16 1294, metadata !1768, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.value(metadata i8 5, metadata !1769, metadata !DIExpression()), !dbg !3995
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #5, !dbg !3997
  call void @llvm.dbg.assign(metadata i8 0, metadata !1760, metadata !DIExpression(), metadata !3998, metadata ptr %2, metadata !DIExpression()), !dbg !3995
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3) #5, !dbg !3999
  store i64 21559640590, ptr %3, align 8, !dbg !4000, !DIAssignID !4001
  call void @llvm.dbg.assign(metadata i64 0, metadata !1771, metadata !DIExpression(), metadata !4001, metadata ptr %3, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.assign(metadata i8 14, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 8), metadata !4002, metadata ptr %3, metadata !DIExpression()), !dbg !3995
  call void @llvm.dbg.assign(metadata i8 2, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 8, 8), metadata !4003, metadata ptr %3, metadata !DIExpression(DW_OP_plus_uconst, 1)), !dbg !3995
  call void @llvm.dbg.assign(metadata i16 1294, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 16, 16), metadata !4004, metadata ptr %3, metadata !DIExpression(DW_OP_plus_uconst, 2)), !dbg !3995
  call void @llvm.dbg.assign(metadata i8 5, metadata !1771, metadata !DIExpression(DW_OP_LLVM_fragment, 32, 8), metadata !4005, metadata ptr %3, metadata !DIExpression(DW_OP_plus_uconst, 4)), !dbg !3995
  %20 = call ptr inttoptr (i64 1 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %3) #5, !dbg !4006
  call void @llvm.dbg.value(metadata ptr %20, metadata !1770, metadata !DIExpression()), !dbg !3995
  %21 = icmp eq ptr %20, null, !dbg !4007
  br i1 %21, label %25, label %22, !dbg !4008

22:                                               ; preds = %19
  %23 = load i64, ptr %20, align 8, !dbg !4009, !tbaa !1790
  %24 = add i64 %23, 1, !dbg !4009
  store i64 %24, ptr %20, align 8, !dbg !4009, !tbaa !1790
  br label %28, !dbg !4010

25:                                               ; preds = %19
  store i64 1, ptr %2, align 8, !dbg !4011, !tbaa !1790, !DIAssignID !4012
  call void @llvm.dbg.assign(metadata i64 1, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !4012, metadata ptr %2, metadata !DIExpression()), !dbg !3995
  %26 = getelementptr inbounds %struct.metrics_value, ptr %2, i64 0, i32 1, !dbg !4013
  store i64 0, ptr %26, align 8, !dbg !4014, !tbaa !1798, !DIAssignID !4015
  call void @llvm.dbg.assign(metadata i64 0, metadata !1760, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !4015, metadata ptr %26, metadata !DIExpression()), !dbg !3995
  %27 = call i32 inttoptr (i64 2 to ptr)(ptr noundef nonnull @cilium_metrics, ptr noundef nonnull %3, ptr noundef nonnull %2, i32 noundef 0) #5, !dbg !4016
  br label %28

28:                                               ; preds = %22, %25
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3) #5, !dbg !4017
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #5, !dbg !4017
  br label %29, !dbg !4018

29:                                               ; preds = %8, %28, %1
  ret i32 1, !dbg !4019
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #3

; Function Attrs: nounwind memory(none)
declare i1 @llvm.bpf.passthrough.i1.i1(i32, i1) #4

attributes #0 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind memory(none) }
attributes #5 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!1113, !1114, !1115, !1116, !1117}
!llvm.ident = !{!1118}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "__config_cluster_id_bits", scope: !2, file: !116, line: 57, type: !80, isLocal: false, isDefinition: true, annotations: !1111)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !78, globals: !101, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/repository/vendor/repos/cilium/bpf/bpf_sock.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "c266373ca70a10c959f52e3be5615484")
!4 = !{!5, !11, !18, !26, !55, !68}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 12, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../stddef.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "0595dbc0c9f00117e6524ed413cda666")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10}
!9 = !DIEnumerator(name: "false", value: 0)
!10 = !DIEnumerator(name: "true", value: 1)
!11 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "metric_dir", file: !12, line: 241, baseType: !13, size: 8, elements: !14)
!12 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/common.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "6d717dcb2b302aba4aa83d59567585a9")
!13 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!14 = !{!15, !16, !17}
!15 = !DIEnumerator(name: "METRIC_INGRESS", value: 1)
!16 = !DIEnumerator(name: "METRIC_EGRESS", value: 2)
!17 = !DIEnumerator(name: "METRIC_SERVICE", value: 3)
!18 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "xlate_point", file: !19, line: 52, baseType: !13, size: 8, elements: !20)
!19 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/trace_sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "030d77c2fb19a84a2ba208444488c6b2")
!20 = !{!21, !22, !23, !24, !25}
!21 = !DIEnumerator(name: "XLATE_UNKNOWN", value: 0)
!22 = !DIEnumerator(name: "XLATE_PRE_DIRECTION_FWD", value: 1)
!23 = !DIEnumerator(name: "XLATE_POST_DIRECTION_FWD", value: 2)
!24 = !DIEnumerator(name: "XLATE_PRE_DIRECTION_REV", value: 3)
!25 = !DIEnumerator(name: "XLATE_POST_DIRECTION_REV", value: 4)
!26 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !27, line: 25, baseType: !7, size: 32, elements: !28)
!27 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/in.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "655dc6bc041c7af070df041a2bf6f562")
!28 = !{!29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54}
!29 = !DIEnumerator(name: "IPPROTO_IP", value: 0)
!30 = !DIEnumerator(name: "IPPROTO_ICMP", value: 1)
!31 = !DIEnumerator(name: "IPPROTO_IGMP", value: 2)
!32 = !DIEnumerator(name: "IPPROTO_IPIP", value: 4)
!33 = !DIEnumerator(name: "IPPROTO_TCP", value: 6)
!34 = !DIEnumerator(name: "IPPROTO_EGP", value: 8)
!35 = !DIEnumerator(name: "IPPROTO_PUP", value: 12)
!36 = !DIEnumerator(name: "IPPROTO_UDP", value: 17)
!37 = !DIEnumerator(name: "IPPROTO_IDP", value: 22)
!38 = !DIEnumerator(name: "IPPROTO_TP", value: 29)
!39 = !DIEnumerator(name: "IPPROTO_DCCP", value: 33)
!40 = !DIEnumerator(name: "IPPROTO_IPV6", value: 41)
!41 = !DIEnumerator(name: "IPPROTO_RSVP", value: 46)
!42 = !DIEnumerator(name: "IPPROTO_GRE", value: 47)
!43 = !DIEnumerator(name: "IPPROTO_ESP", value: 50)
!44 = !DIEnumerator(name: "IPPROTO_AH", value: 51)
!45 = !DIEnumerator(name: "IPPROTO_MTP", value: 92)
!46 = !DIEnumerator(name: "IPPROTO_BEETPH", value: 94)
!47 = !DIEnumerator(name: "IPPROTO_ENCAP", value: 98)
!48 = !DIEnumerator(name: "IPPROTO_PIM", value: 103)
!49 = !DIEnumerator(name: "IPPROTO_COMP", value: 108)
!50 = !DIEnumerator(name: "IPPROTO_SCTP", value: 132)
!51 = !DIEnumerator(name: "IPPROTO_UDPLITE", value: 136)
!52 = !DIEnumerator(name: "IPPROTO_MPLS", value: 137)
!53 = !DIEnumerator(name: "IPPROTO_RAW", value: 255)
!54 = !DIEnumerator(name: "IPPROTO_MAX", value: 256)
!55 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !56, line: 368, baseType: !7, size: 32, elements: !57)
!56 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/lb.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "589b82b01c055c395b82efa3d1b0b55a")
!57 = !{!58, !59, !60, !61, !62, !63, !64, !65, !66, !67}
!58 = !DIEnumerator(name: "SVC_FLAG_LOCALREDIRECT", value: 1)
!59 = !DIEnumerator(name: "SVC_FLAG_NAT_46X64", value: 2)
!60 = !DIEnumerator(name: "SVC_FLAG_L7_LOADBALANCER", value: 4)
!61 = !DIEnumerator(name: "SVC_FLAG_LOOPBACK", value: 8)
!62 = !DIEnumerator(name: "SVC_FLAG_L7_DELEGATE", value: 8)
!63 = !DIEnumerator(name: "SVC_FLAG_INT_LOCAL_SCOPE", value: 16)
!64 = !DIEnumerator(name: "SVC_FLAG_TWO_SCOPES", value: 32)
!65 = !DIEnumerator(name: "SVC_FLAG_QUARANTINED", value: 64)
!66 = !DIEnumerator(name: "SVC_FLAG_SOURCE_RANGE_DENY", value: 64)
!67 = !DIEnumerator(name: "SVC_FLAG_FWD_MODE_DSR", value: 128)
!68 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !56, line: 356, baseType: !7, size: 32, elements: !69)
!69 = !{!70, !71, !72, !73, !74, !75, !76, !77}
!70 = !DIEnumerator(name: "SVC_FLAG_EXTERNAL_IP", value: 1)
!71 = !DIEnumerator(name: "SVC_FLAG_NODEPORT", value: 2)
!72 = !DIEnumerator(name: "SVC_FLAG_EXT_LOCAL_SCOPE", value: 4)
!73 = !DIEnumerator(name: "SVC_FLAG_HOSTPORT", value: 8)
!74 = !DIEnumerator(name: "SVC_FLAG_AFFINITY", value: 16)
!75 = !DIEnumerator(name: "SVC_FLAG_LOADBALANCER", value: 32)
!76 = !DIEnumerator(name: "SVC_FLAG_ROUTABLE", value: 64)
!77 = !DIEnumerator(name: "SVC_FLAG_SOURCE_RANGE", value: 128)
!78 = !{!79, !84, !82, !85, !89, !91, !92, !93, !94, !97, !98, !99}
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !80, size: 64)
!80 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !81)
!81 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !82)
!82 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !83, line: 13, baseType: !7)
!83 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/../bpf/types_mapper.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "ed32c96abe0b86529815ffb521dc9d75")
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !83, line: 7, baseType: !13)
!85 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !86, size: 64)
!86 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !87)
!87 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !88)
!88 = !DIBasicType(name: "_Bool", size: 8, encoding: DW_ATE_boolean)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !83, line: 10, baseType: !90)
!90 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !83, line: 19, baseType: !89)
!93 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64)
!94 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !95, size: 64)
!95 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !83, line: 16, baseType: !96)
!96 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!97 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !89, size: 64)
!98 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!99 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !100, size: 64)
!100 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !95)
!101 = !{!0, !102, !109, !114, !120, !134, !138, !142, !156, !181, !185, !189, !193, !197, !201, !205, !209, !215, !219, !223, !227, !231, !237, !241, !245, !249, !253, !257, !261, !265, !269, !273, !279, !284, !288, !293, !297, !338, !374, !378, !402, !406, !411, !454, !504, !535, !557, !572, !606, !626, !656, !677, !693, !724, !739, !772, !792, !815, !832, !846, !865, !881, !903, !926, !943, !947, !975, !998, !1007, !1015, !1020, !1025, !1027, !1032, !1037, !1042, !1047, !1050, !1055, !1060, !1062, !1065, !1070, !1072, !1077, !1079, !1082, !1084, !1086, !1091, !1096, !1098, !1100, !1102, !1107, !1109}
!102 = !DIGlobalVariableExpression(var: !103, expr: !DIExpression())
!103 = distinct !DIGlobalVariable(scope: null, file: !104, line: 1293, type: !105, isLocal: true, isDefinition: true)
!104 = !DIFile(filename: "vendor/repos/cilium/bpf/bpf_sock.c", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "c266373ca70a10c959f52e3be5615484")
!105 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 88, elements: !107)
!106 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!107 = !{!108}
!108 = !DISubrange(count: 11)
!109 = !DIGlobalVariableExpression(var: !110, expr: !DIExpression())
!110 = distinct !DIGlobalVariable(name: "____license", scope: !2, file: !104, line: 1326, type: !111, isLocal: false, isDefinition: true)
!111 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 104, elements: !112)
!112 = !{!113}
!113 = !DISubrange(count: 13)
!114 = !DIGlobalVariableExpression(var: !115, expr: !DIExpression())
!115 = distinct !DIGlobalVariable(name: "__config_cilium_net_ifindex", scope: !2, file: !116, line: 18, type: !80, isLocal: false, isDefinition: true, annotations: !117)
!116 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/config/node.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "2c957a7d9212068bebde674044b7ae68")
!117 = !{!118, !119}
!118 = !{!"btf_decl_tag", !"kind:node"}
!119 = !{!"btf_decl_tag", !"Interface index of the cilium_net device"}
!120 = !DIGlobalVariableExpression(var: !121, expr: !DIExpression())
!121 = distinct !DIGlobalVariable(name: "__config_cilium_net_mac", scope: !2, file: !116, line: 19, type: !122, isLocal: false, isDefinition: true, annotations: !132)
!122 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !123)
!123 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !124)
!124 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "macaddr", file: !125, line: 17, size: 64, elements: !126)
!125 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/eth.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "e93e5308c934dae62adf207729923efa")
!126 = !{!127, !131}
!127 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !124, file: !125, line: 18, baseType: !128, size: 48)
!128 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 48, elements: !129)
!129 = !{!130}
!130 = !DISubrange(count: 6)
!131 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !124, file: !125, line: 19, baseType: !95, size: 64)
!132 = !{!118, !133}
!133 = !{!"btf_decl_tag", !"MAC address of the cilium_net device"}
!134 = !DIGlobalVariableExpression(var: !135, expr: !DIExpression())
!135 = distinct !DIGlobalVariable(name: "__config_cilium_host_ifindex", scope: !2, file: !116, line: 20, type: !80, isLocal: false, isDefinition: true, annotations: !136)
!136 = !{!118, !137}
!137 = !{!"btf_decl_tag", !"Interface index of the cilium_host device"}
!138 = !DIGlobalVariableExpression(var: !139, expr: !DIExpression())
!139 = distinct !DIGlobalVariable(name: "__config_cilium_host_mac", scope: !2, file: !116, line: 21, type: !122, isLocal: false, isDefinition: true, annotations: !140)
!140 = !{!118, !141}
!141 = !{!"btf_decl_tag", !"MAC address of the cilium_host device"}
!142 = !DIGlobalVariableExpression(var: !143, expr: !DIExpression())
!143 = distinct !DIGlobalVariable(name: "__config_service_loopback_ipv4", scope: !2, file: !116, line: 23, type: !144, isLocal: false, isDefinition: true, annotations: !154)
!144 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !145)
!145 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !146)
!146 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "v4addr", file: !12, line: 65, size: 32, elements: !147)
!147 = !{!148, !152}
!148 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !146, file: !12, line: 66, baseType: !149, size: 32)
!149 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 32, elements: !150)
!150 = !{!151}
!151 = !DISubrange(count: 4)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "be32", scope: !146, file: !12, line: 67, baseType: !153, size: 32)
!153 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !83, line: 22, baseType: !82)
!154 = !{!118, !155}
!155 = !{!"btf_decl_tag", !"IPv4 source address used for SNAT when a Pod talks to itself over a Service"}
!156 = !DIGlobalVariableExpression(var: !157, expr: !DIExpression())
!157 = distinct !DIGlobalVariable(name: "__config_service_loopback_ipv6", scope: !2, file: !116, line: 24, type: !158, isLocal: false, isDefinition: true, annotations: !179)
!158 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !159)
!159 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !160)
!160 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "v6addr", file: !161, line: 6, size: 128, elements: !162)
!161 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv6_core.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "302bbd1e468493867fe227a3cbb3d3ac")
!162 = !{!163, !167, !174}
!163 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !160, file: !161, line: 7, baseType: !164, size: 128)
!164 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 128, elements: !165)
!165 = !{!166}
!166 = !DISubrange(count: 16)
!167 = !DIDerivedType(tag: DW_TAG_member, name: "p", scope: !160, file: !161, line: 13, baseType: !168, size: 128)
!168 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !160, file: !161, line: 8, size: 128, elements: !169)
!169 = !{!170, !171, !172, !173}
!170 = !DIDerivedType(tag: DW_TAG_member, name: "p1", scope: !168, file: !161, line: 9, baseType: !82, size: 32)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "p2", scope: !168, file: !161, line: 10, baseType: !82, size: 32, offset: 32)
!172 = !DIDerivedType(tag: DW_TAG_member, name: "p3", scope: !168, file: !161, line: 11, baseType: !82, size: 32, offset: 64)
!173 = !DIDerivedType(tag: DW_TAG_member, name: "p4", scope: !168, file: !161, line: 12, baseType: !82, size: 32, offset: 96)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "d", scope: !160, file: !161, line: 21, baseType: !175, size: 128)
!175 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !160, file: !161, line: 18, size: 128, elements: !176)
!176 = !{!177, !178}
!177 = !DIDerivedType(tag: DW_TAG_member, name: "d1", scope: !175, file: !161, line: 19, baseType: !95, size: 64)
!178 = !DIDerivedType(tag: DW_TAG_member, name: "d2", scope: !175, file: !161, line: 20, baseType: !95, size: 64, offset: 64)
!179 = !{!118, !180}
!180 = !{!"btf_decl_tag", !"IPv6 source address used for SNAT when a Pod talks to itself over a Service"}
!181 = !DIGlobalVariableExpression(var: !182, expr: !DIExpression())
!182 = distinct !DIGlobalVariable(name: "__config_router_ipv6", scope: !2, file: !116, line: 26, type: !158, isLocal: false, isDefinition: true, annotations: !183)
!183 = !{!118, !184}
!184 = !{!"btf_decl_tag", !"Internal IPv6 router address assigned to the cilium_host interface"}
!185 = !DIGlobalVariableExpression(var: !186, expr: !DIExpression())
!186 = distinct !DIGlobalVariable(name: "__config_trace_payload_len", scope: !2, file: !116, line: 28, type: !80, isLocal: false, isDefinition: true, annotations: !187)
!187 = !{!118, !188}
!188 = !{!"btf_decl_tag", !"Length of payload to capture when tracing native packets."}
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(name: "__config_trace_payload_len_overlay", scope: !2, file: !116, line: 31, type: !80, isLocal: false, isDefinition: true, annotations: !191)
!191 = !{!118, !192}
!192 = !{!"btf_decl_tag", !"Length of payload to capture when tracing overlay packets."}
!193 = !DIGlobalVariableExpression(var: !194, expr: !DIExpression())
!194 = distinct !DIGlobalVariable(name: "__config_direct_routing_dev_ifindex", scope: !2, file: !116, line: 33, type: !80, isLocal: false, isDefinition: true, annotations: !195)
!195 = !{!118, !196}
!196 = !{!"btf_decl_tag", !"Index of the interface used to connect nodes in the cluster."}
!197 = !DIGlobalVariableExpression(var: !198, expr: !DIExpression())
!198 = distinct !DIGlobalVariable(name: "__config_supports_fib_lookup_skip_neigh", scope: !2, file: !116, line: 35, type: !86, isLocal: false, isDefinition: true, annotations: !199)
!199 = !{!118, !200}
!200 = !{!"btf_decl_tag", !"Whether or not BPF_FIB_LOOKUP_SKIP_NEIGH is supported."}
!201 = !DIGlobalVariableExpression(var: !202, expr: !DIExpression())
!202 = distinct !DIGlobalVariable(name: "__config_supports_fib_lookup_src", scope: !2, file: !116, line: 38, type: !86, isLocal: false, isDefinition: true, annotations: !203)
!203 = !{!118, !204}
!204 = !{!"btf_decl_tag", !"Whether or not BPF_FIB_LOOKUP_SRC is supported."}
!205 = !DIGlobalVariableExpression(var: !206, expr: !DIExpression())
!206 = distinct !DIGlobalVariable(name: "__config_enable_nodeport_source_lookup", scope: !2, file: !116, line: 41, type: !86, isLocal: false, isDefinition: true, annotations: !207)
!207 = !{!118, !208}
!208 = !{!"btf_decl_tag", !"Enable dynamic source IP resolution for SNAT via linux's routing table."}
!209 = !DIGlobalVariableExpression(var: !210, expr: !DIExpression())
!210 = distinct !DIGlobalVariable(name: "__config_tracing_ip_option_type", scope: !2, file: !116, line: 44, type: !211, isLocal: false, isDefinition: true, annotations: !213)
!211 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !212)
!212 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !84)
!213 = !{!118, !214}
!214 = !{!"btf_decl_tag", !"The IP option type to use for packet tracing"}
!215 = !DIGlobalVariableExpression(var: !216, expr: !DIExpression())
!216 = distinct !DIGlobalVariable(name: "__config_policy_deny_response_enabled", scope: !2, file: !116, line: 46, type: !86, isLocal: false, isDefinition: true, annotations: !217)
!217 = !{!118, !218}
!218 = !{!"btf_decl_tag", !"Enable ICMP responses for policy-denied traffic"}
!219 = !DIGlobalVariableExpression(var: !220, expr: !DIExpression())
!220 = distinct !DIGlobalVariable(name: "__config_cluster_id", scope: !2, file: !116, line: 48, type: !80, isLocal: false, isDefinition: true, annotations: !221)
!221 = !{!118, !222}
!222 = !{!"btf_decl_tag", !"Cluster ID"}
!223 = !DIGlobalVariableExpression(var: !224, expr: !DIExpression())
!224 = distinct !DIGlobalVariable(name: "__config_enable_conntrack_accounting", scope: !2, file: !116, line: 59, type: !86, isLocal: false, isDefinition: true, annotations: !225)
!225 = !{!118, !226}
!226 = !{!"btf_decl_tag", !"Enable per flow (conntrack) statistics"}
!227 = !DIGlobalVariableExpression(var: !228, expr: !DIExpression())
!228 = distinct !DIGlobalVariable(name: "__config_debug_lb", scope: !2, file: !116, line: 61, type: !86, isLocal: false, isDefinition: true, annotations: !229)
!229 = !{!118, !230}
!230 = !{!"btf_decl_tag", !"Enable debugging trace statements for load balancer"}
!231 = !DIGlobalVariableExpression(var: !232, expr: !DIExpression())
!232 = distinct !DIGlobalVariable(name: "__config_nodeport_port_min", scope: !2, file: !116, line: 63, type: !233, isLocal: false, isDefinition: true, annotations: !235)
!233 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !234)
!234 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !89)
!235 = !{!118, !236}
!236 = !{!"btf_decl_tag", !"Nodeport minimum port value."}
!237 = !DIGlobalVariableExpression(var: !238, expr: !DIExpression())
!238 = distinct !DIGlobalVariable(name: "__config_nodeport_port_max", scope: !2, file: !116, line: 64, type: !233, isLocal: false, isDefinition: true, annotations: !239)
!239 = !{!118, !240}
!240 = !{!"btf_decl_tag", !"Nodeport maximum port value."}
!241 = !DIGlobalVariableExpression(var: !242, expr: !DIExpression())
!242 = distinct !DIGlobalVariable(name: "__config_hash_init4_seed", scope: !2, file: !116, line: 66, type: !80, isLocal: false, isDefinition: true, annotations: !243)
!243 = !{!118, !244}
!244 = !{!"btf_decl_tag", !"Cluster-wide IPv4 tuple hash seed sourced"}
!245 = !DIGlobalVariableExpression(var: !246, expr: !DIExpression())
!246 = distinct !DIGlobalVariable(name: "__config_hash_init6_seed", scope: !2, file: !116, line: 67, type: !80, isLocal: false, isDefinition: true, annotations: !247)
!247 = !{!118, !248}
!248 = !{!"btf_decl_tag", !"Cluster-wide IPv6 tuple hash seed sourced"}
!249 = !DIGlobalVariableExpression(var: !250, expr: !DIExpression())
!250 = distinct !DIGlobalVariable(name: "__config_nat_46x64_prefix", scope: !2, file: !116, line: 69, type: !144, isLocal: false, isDefinition: true, annotations: !251)
!251 = !{!118, !252}
!252 = !{!"btf_decl_tag", !"NAT 46x64 prefix"}
!253 = !DIGlobalVariableExpression(var: !254, expr: !DIExpression())
!254 = distinct !DIGlobalVariable(name: "__config_enable_tproxy", scope: !2, file: !116, line: 71, type: !86, isLocal: false, isDefinition: true, annotations: !255)
!255 = !{!118, !256}
!256 = !{!"btf_decl_tag", !"Enable BPF-based proxy redirection"}
!257 = !DIGlobalVariableExpression(var: !258, expr: !DIExpression())
!258 = distinct !DIGlobalVariable(name: "__config_events_map_rate_limit", scope: !2, file: !116, line: 73, type: !80, isLocal: false, isDefinition: true, annotations: !259)
!259 = !{!118, !260}
!260 = !{!"btf_decl_tag", !"The sustained message rate for the BPF events map in messages per second"}
!261 = !DIGlobalVariableExpression(var: !262, expr: !DIExpression())
!262 = distinct !DIGlobalVariable(name: "__config_events_map_burst_limit", scope: !2, file: !116, line: 75, type: !80, isLocal: false, isDefinition: true, annotations: !263)
!263 = !{!118, !264}
!264 = !{!"btf_decl_tag", !"Maximum number of messages that can be written to BPF events map in 1 second"}
!265 = !DIGlobalVariableExpression(var: !266, expr: !DIExpression())
!266 = distinct !DIGlobalVariable(name: "__config_enable_endpoint_routes", scope: !2, file: !116, line: 78, type: !86, isLocal: false, isDefinition: true, annotations: !267)
!267 = !{!118, !268}
!268 = !{!"btf_decl_tag", !"Enable per endpoint routes"}
!269 = !DIGlobalVariableExpression(var: !270, expr: !DIExpression())
!270 = distinct !DIGlobalVariable(name: "__config_enable_identity_mark", scope: !2, file: !116, line: 80, type: !86, isLocal: false, isDefinition: true, annotations: !271)
!271 = !{!118, !272}
!272 = !{!"btf_decl_tag", !"Enable setting identity mark for local traffic"}
!273 = !DIGlobalVariableExpression(var: !274, expr: !DIExpression())
!274 = distinct !DIGlobalVariable(name: "__config_enable_no_service_endpoints_routable", scope: !2, file: !275, line: 12, type: !86, isLocal: false, isDefinition: true, annotations: !276)
!275 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/config/sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "9d4aa23e1dc39e0b8f56dbae0a0d0aaa")
!276 = !{!277, !278}
!277 = !{!"btf_decl_tag", !"kind:object"}
!278 = !{!"btf_decl_tag", !"Enable routes when service has 0 endpoints"}
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(name: "__config_tunnel_protocol", scope: !2, file: !281, line: 13, type: !211, isLocal: false, isDefinition: true, annotations: !282)
!281 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/tunnel.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "deadd08d84a77550e53e333137948c7d")
!282 = !{!277, !283}
!283 = !{!"btf_decl_tag", !"The identifier of the tunnel protocol used for the overlay network"}
!284 = !DIGlobalVariableExpression(var: !285, expr: !DIExpression())
!285 = distinct !DIGlobalVariable(name: "__config_tunnel_port", scope: !2, file: !281, line: 15, type: !233, isLocal: false, isDefinition: true, annotations: !286)
!286 = !{!277, !287}
!287 = !{!"btf_decl_tag", !"Port number used for the overlay network"}
!288 = !DIGlobalVariableExpression(var: !289, expr: !DIExpression())
!289 = distinct !DIGlobalVariable(name: "__config_enable_jiffies", scope: !2, file: !290, line: 13, type: !86, isLocal: false, isDefinition: true, annotations: !291)
!290 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/time.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "cede07acb17595554e213823ab4d68f8")
!291 = !{!118, !292}
!292 = !{!"btf_decl_tag", !"Use jiffies (count of timer ticks since boot)."}
!293 = !DIGlobalVariableExpression(var: !294, expr: !DIExpression())
!294 = distinct !DIGlobalVariable(name: "__config_kernel_hz", scope: !2, file: !290, line: 14, type: !80, isLocal: false, isDefinition: true, annotations: !295)
!295 = !{!118, !296}
!296 = !{!"btf_decl_tag", !"Number of timer ticks per second."}
!297 = !DIGlobalVariableExpression(var: !298, expr: !DIExpression())
!298 = distinct !DIGlobalVariable(name: "cilium_metrics", scope: !2, file: !299, line: 35, type: !300, isLocal: false, isDefinition: true)
!299 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/metrics.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "bd6864e45aaef2a70477bbef7a6154c5")
!300 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !299, line: 28, size: 384, elements: !301)
!301 = !{!302, !308, !321, !327, !332, !337}
!302 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !300, file: !299, line: 29, baseType: !303, size: 64)
!303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !304, size: 64)
!304 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 160, elements: !306)
!305 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!306 = !{!307}
!307 = !DISubrange(count: 5)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !300, file: !299, line: 30, baseType: !309, size: 64, offset: 64)
!309 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !310, size: 64)
!310 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "metrics_key", file: !299, line: 14, size: 64, elements: !311)
!311 = !{!312, !313, !314, !315, !316, !317}
!312 = !DIDerivedType(tag: DW_TAG_member, name: "reason", scope: !310, file: !299, line: 15, baseType: !84, size: 8)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "dir", scope: !310, file: !299, line: 16, baseType: !84, size: 2, offset: 8, flags: DIFlagBitField, extraData: i64 8)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !310, file: !299, line: 17, baseType: !84, size: 6, offset: 10, flags: DIFlagBitField, extraData: i64 8)
!315 = !DIDerivedType(tag: DW_TAG_member, name: "line", scope: !310, file: !299, line: 18, baseType: !89, size: 16, offset: 16)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "file", scope: !310, file: !299, line: 19, baseType: !84, size: 8, offset: 32)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !310, file: !299, line: 20, baseType: !318, size: 24, offset: 40)
!318 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 24, elements: !319)
!319 = !{!320}
!320 = !DISubrange(count: 3)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !300, file: !299, line: 31, baseType: !322, size: 64, offset: 128)
!322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !323, size: 64)
!323 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "metrics_value", file: !299, line: 23, size: 128, elements: !324)
!324 = !{!325, !326}
!325 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !323, file: !299, line: 24, baseType: !95, size: 64)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !323, file: !299, line: 25, baseType: !95, size: 64, offset: 64)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !300, file: !299, line: 32, baseType: !328, size: 64, offset: 192)
!328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !329, size: 64)
!329 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32, elements: !330)
!330 = !{!331}
!331 = !DISubrange(count: 1)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !300, file: !299, line: 33, baseType: !333, size: 64, offset: 256)
!333 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !334, size: 64)
!334 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 2097152, elements: !335)
!335 = !{!336}
!336 = !DISubrange(count: 65536)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !300, file: !299, line: 34, baseType: !328, size: 64, offset: 320)
!338 = !DIGlobalVariableExpression(var: !339, expr: !DIExpression())
!339 = distinct !DIGlobalVariable(name: "cilium_ipv4_frag_datagrams", scope: !2, file: !340, line: 36, type: !341, isLocal: false, isDefinition: true)
!340 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv4.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "95f511aec67302923e0996ea848a1a83")
!341 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !340, line: 29, size: 384, elements: !342)
!342 = !{!343, !348, !357, !363, !364, !369}
!343 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !341, file: !340, line: 30, baseType: !344, size: 64)
!344 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!345 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 288, elements: !346)
!346 = !{!347}
!347 = !DISubrange(count: 9)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !341, file: !340, line: 31, baseType: !349, size: 64, offset: 64)
!349 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!350 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_frag_id", file: !340, line: 16, size: 96, elements: !351)
!351 = !{!352, !353, !354, !355, !356}
!352 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !350, file: !340, line: 17, baseType: !153, size: 32)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !350, file: !340, line: 18, baseType: !153, size: 32, offset: 32)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !350, file: !340, line: 19, baseType: !92, size: 16, offset: 64)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !350, file: !340, line: 20, baseType: !84, size: 8, offset: 80)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !350, file: !340, line: 21, baseType: !84, size: 8, offset: 88)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !341, file: !340, line: 32, baseType: !358, size: 64, offset: 128)
!358 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !359, size: 64)
!359 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_frag_l4ports", file: !340, line: 24, size: 32, elements: !360)
!360 = !{!361, !362}
!361 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !359, file: !340, line: 25, baseType: !92, size: 16)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !359, file: !340, line: 26, baseType: !92, size: 16, offset: 16)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !341, file: !340, line: 33, baseType: !328, size: 64, offset: 192)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !341, file: !340, line: 34, baseType: !365, size: 64, offset: 256)
!365 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !366, size: 64)
!366 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 262144, elements: !367)
!367 = !{!368}
!368 = !DISubrange(count: 8192)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !341, file: !340, line: 35, baseType: !370, size: 64, offset: 320)
!370 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !371, size: 64)
!371 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, elements: !372)
!372 = !{!373}
!373 = !DISubrange(count: 0)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "__config_enable_ipv4_fragments", scope: !2, file: !340, line: 38, type: !86, isLocal: false, isDefinition: true, annotations: !376)
!376 = !{!277, !377}
!377 = !{!"btf_decl_tag", !"Enable IPv4 fragments tracking"}
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(name: "cilium_ipv6_frag_datagrams", scope: !2, file: !380, line: 63, type: !381, isLocal: false, isDefinition: true)
!380 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ipv6.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "9b34fd6d79827b36002c907097fa16e8")
!381 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !380, line: 56, size: 384, elements: !382)
!382 = !{!383, !384, !393, !399, !400, !401}
!383 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !381, file: !380, line: 57, baseType: !344, size: 64)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !381, file: !380, line: 58, baseType: !385, size: 64, offset: 64)
!385 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !386, size: 64)
!386 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_frag_id", file: !380, line: 43, size: 320, elements: !387)
!387 = !{!388, !389, !390, !391, !392}
!388 = !DIDerivedType(tag: DW_TAG_member, name: "id", scope: !386, file: !380, line: 44, baseType: !153, size: 32)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !386, file: !380, line: 45, baseType: !84, size: 8, offset: 32)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !386, file: !380, line: 46, baseType: !318, size: 24, offset: 40)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !386, file: !380, line: 47, baseType: !160, size: 128, offset: 64)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !386, file: !380, line: 48, baseType: !160, size: 128, offset: 192)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !381, file: !380, line: 59, baseType: !394, size: 64, offset: 128)
!394 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !395, size: 64)
!395 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_frag_l4ports", file: !380, line: 51, size: 32, elements: !396)
!396 = !{!397, !398}
!397 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !395, file: !380, line: 52, baseType: !92, size: 16)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !395, file: !380, line: 53, baseType: !92, size: 16, offset: 16)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !381, file: !380, line: 60, baseType: !328, size: 64, offset: 192)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !381, file: !380, line: 61, baseType: !365, size: 64, offset: 256)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !381, file: !380, line: 62, baseType: !370, size: 64, offset: 320)
!402 = !DIGlobalVariableExpression(var: !403, expr: !DIExpression())
!403 = distinct !DIGlobalVariable(name: "__config_enable_ipv6_fragments", scope: !2, file: !380, line: 65, type: !86, isLocal: false, isDefinition: true, annotations: !404)
!404 = !{!277, !405}
!405 = !{!"btf_decl_tag", !"Enable IPv6 fragments tracking"}
!406 = !DIGlobalVariableExpression(var: !407, expr: !DIExpression())
!407 = distinct !DIGlobalVariable(name: "__config_enable_extended_ip_protocols", scope: !2, file: !408, line: 20, type: !86, isLocal: false, isDefinition: true, annotations: !409)
!408 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/conntrack.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "55dc355b668ff7d7eba6e075c9719098")
!409 = !{!277, !410}
!410 = !{!"btf_decl_tag", !"Pass traffic with extended IP protocols"}
!411 = !DIGlobalVariableExpression(var: !412, expr: !DIExpression())
!412 = distinct !DIGlobalVariable(name: "cilium_lxc", scope: !2, file: !413, line: 56, type: !414, isLocal: false, isDefinition: true)
!413 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/eps.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "e1aa19a2efaa3c0442f444e1d917b318")
!414 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !413, line: 49, size: 384, elements: !415)
!415 = !{!416, !417, !429, !447, !448, !449}
!416 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !414, file: !413, line: 50, baseType: !328, size: 64)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !414, file: !413, line: 51, baseType: !418, size: 64, offset: 64)
!418 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !419, size: 64)
!419 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "endpoint_key", file: !413, line: 17, size: 160, elements: !420)
!420 = !{!421, !426, !427, !428}
!421 = !DIDerivedType(tag: DW_TAG_member, scope: !419, file: !413, line: 18, baseType: !422, size: 128)
!422 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !419, file: !413, line: 18, size: 128, elements: !423)
!423 = !{!424, !425}
!424 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !422, file: !413, line: 19, baseType: !146, size: 32)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !422, file: !413, line: 20, baseType: !160, size: 128)
!426 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !419, file: !413, line: 22, baseType: !84, size: 8, offset: 128)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !419, file: !413, line: 23, baseType: !84, size: 8, offset: 136)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !419, file: !413, line: 24, baseType: !89, size: 16, offset: 144)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !414, file: !413, line: 52, baseType: !430, size: 64, offset: 128)
!430 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !431, size: 64)
!431 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "endpoint_info", file: !413, line: 36, size: 384, elements: !432)
!432 = !{!433, !434, !435, !436, !437, !438, !440, !441, !442, !443}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !431, file: !413, line: 37, baseType: !82, size: 32)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "unused", scope: !431, file: !413, line: 38, baseType: !89, size: 16, offset: 32)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "lxc_id", scope: !431, file: !413, line: 39, baseType: !89, size: 16, offset: 48)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !431, file: !413, line: 40, baseType: !82, size: 32, offset: 64)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "rt_info", scope: !431, file: !413, line: 41, baseType: !82, size: 32, offset: 96)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "mac", scope: !431, file: !413, line: 42, baseType: !439, size: 64, offset: 128)
!439 = !DIDerivedType(tag: DW_TAG_typedef, name: "mac_t", file: !12, line: 63, baseType: !95)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "node_mac", scope: !431, file: !413, line: 43, baseType: !439, size: 64, offset: 192)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "sec_id", scope: !431, file: !413, line: 44, baseType: !82, size: 32, offset: 256)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "parent_ifindex", scope: !431, file: !413, line: 45, baseType: !82, size: 32, offset: 288)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !431, file: !413, line: 46, baseType: !444, size: 64, offset: 320)
!444 = !DICompositeType(tag: DW_TAG_array_type, baseType: !82, size: 64, elements: !445)
!445 = !{!446}
!446 = !DISubrange(count: 2)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !414, file: !413, line: 53, baseType: !328, size: 64, offset: 192)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !414, file: !413, line: 54, baseType: !333, size: 64, offset: 256)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !414, file: !413, line: 55, baseType: !450, size: 64, offset: 320)
!450 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !451, size: 64)
!451 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 4128, elements: !452)
!452 = !{!453}
!453 = !DISubrange(count: 129)
!454 = !DIGlobalVariableExpression(var: !455, expr: !DIExpression())
!455 = distinct !DIGlobalVariable(name: "cilium_ipcache_v2", scope: !2, file: !413, line: 126, type: !456, isLocal: false, isDefinition: true)
!456 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !413, line: 119, size: 384, elements: !457)
!457 = !{!458, !461, !480, !497, !498, !503}
!458 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !456, file: !413, line: 120, baseType: !459, size: 64)
!459 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !460, size: 64)
!460 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 352, elements: !107)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !456, file: !413, line: 121, baseType: !462, size: 64, offset: 64)
!462 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !463, size: 64)
!463 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipcache_key", file: !413, line: 107, size: 192, elements: !464)
!464 = !{!465, !472, !473, !474, !475}
!465 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !463, file: !413, line: 108, baseType: !466, size: 32)
!466 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_lpm_trie_key", file: !467, line: 82, size: 32, elements: !468)
!467 = !DIFile(filename: "vendor/repos/cilium/bpf/include/linux/bpf.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "3d6f4ba3c0dbd345e28bb269cff4f6f1")
!468 = !{!469, !470}
!469 = !DIDerivedType(tag: DW_TAG_member, name: "prefixlen", scope: !466, file: !467, line: 83, baseType: !82, size: 32)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !466, file: !467, line: 84, baseType: !471, offset: 32)
!471 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, elements: !372)
!472 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !463, file: !413, line: 109, baseType: !89, size: 16, offset: 32)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !463, file: !413, line: 110, baseType: !84, size: 8, offset: 48)
!474 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !463, file: !413, line: 111, baseType: !84, size: 8, offset: 56)
!475 = !DIDerivedType(tag: DW_TAG_member, scope: !463, file: !413, line: 112, baseType: !476, size: 128, offset: 64)
!476 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !463, file: !413, line: 112, size: 128, elements: !477)
!477 = !{!478, !479}
!478 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !476, file: !413, line: 113, baseType: !146, size: 32)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !476, file: !413, line: 114, baseType: !160, size: 128)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !456, file: !413, line: 122, baseType: !481, size: 64, offset: 128)
!481 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !482, size: 64)
!482 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "remote_endpoint_info", file: !413, line: 92, size: 192, elements: !483)
!483 = !{!484, !485, !490, !491, !492, !493, !494, !495, !496}
!484 = !DIDerivedType(tag: DW_TAG_member, name: "sec_identity", scope: !482, file: !413, line: 93, baseType: !82, size: 32)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_endpoint", scope: !482, file: !413, line: 97, baseType: !486, size: 128, offset: 32)
!486 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !482, file: !413, line: 94, size: 128, elements: !487)
!487 = !{!488, !489}
!488 = !DIDerivedType(tag: DW_TAG_member, name: "ip4", scope: !486, file: !413, line: 95, baseType: !146, size: 32)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "ip6", scope: !486, file: !413, line: 96, baseType: !160, size: 128)
!490 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !482, file: !413, line: 98, baseType: !89, size: 16, offset: 160)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !482, file: !413, line: 99, baseType: !84, size: 8, offset: 176)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "flag_skip_tunnel", scope: !482, file: !413, line: 100, baseType: !84, size: 1, offset: 184, flags: DIFlagBitField, extraData: i64 184)
!493 = !DIDerivedType(tag: DW_TAG_member, name: "flag_has_tunnel_ep", scope: !482, file: !413, line: 101, baseType: !84, size: 1, offset: 185, flags: DIFlagBitField, extraData: i64 184)
!494 = !DIDerivedType(tag: DW_TAG_member, name: "flag_ipv6_tunnel_ep", scope: !482, file: !413, line: 102, baseType: !84, size: 1, offset: 186, flags: DIFlagBitField, extraData: i64 184)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "flag_remote_cluster", scope: !482, file: !413, line: 103, baseType: !84, size: 1, offset: 187, flags: DIFlagBitField, extraData: i64 184)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !482, file: !413, line: 104, baseType: !84, size: 4, offset: 188, flags: DIFlagBitField, extraData: i64 184)
!497 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !456, file: !413, line: 123, baseType: !328, size: 64, offset: 192)
!498 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !456, file: !413, line: 124, baseType: !499, size: 64, offset: 256)
!499 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !500, size: 64)
!500 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 16384000, elements: !501)
!501 = !{!502}
!502 = !DISubrange(count: 512000)
!503 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !456, file: !413, line: 125, baseType: !450, size: 64, offset: 320)
!504 = !DIGlobalVariableExpression(var: !505, expr: !DIExpression())
!505 = distinct !DIGlobalVariable(name: "cilium_ratelimit", scope: !2, file: !506, line: 34, type: !507, isLocal: false, isDefinition: true)
!506 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/ratelimit.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "1c2ea6163fda2531791bda72da99556a")
!507 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !506, line: 27, size: 384, elements: !508)
!508 = !{!509, !510, !522, !528, !529, !534}
!509 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !507, file: !506, line: 28, baseType: !344, size: 64)
!510 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !507, file: !506, line: 29, baseType: !511, size: 64, offset: 64)
!511 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !512, size: 64)
!512 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_key", file: !506, line: 13, size: 64, elements: !513)
!513 = !{!514, !515}
!514 = !DIDerivedType(tag: DW_TAG_member, name: "usage", scope: !512, file: !506, line: 14, baseType: !82, size: 32)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !512, file: !506, line: 19, baseType: !516, size: 32, offset: 32)
!516 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !512, file: !506, line: 15, size: 32, elements: !517)
!517 = !{!518}
!518 = !DIDerivedType(tag: DW_TAG_member, name: "icmpv6", scope: !516, file: !506, line: 18, baseType: !519, size: 32)
!519 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !516, file: !506, line: 16, size: 32, elements: !520)
!520 = !{!521}
!521 = !DIDerivedType(tag: DW_TAG_member, name: "netdev_idx", scope: !519, file: !506, line: 17, baseType: !82, size: 32)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !507, file: !506, line: 30, baseType: !523, size: 64, offset: 128)
!523 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !524, size: 64)
!524 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_value", file: !506, line: 22, size: 128, elements: !525)
!525 = !{!526, !527}
!526 = !DIDerivedType(tag: DW_TAG_member, name: "last_topup", scope: !524, file: !506, line: 23, baseType: !95, size: 64)
!527 = !DIDerivedType(tag: DW_TAG_member, name: "tokens", scope: !524, file: !506, line: 24, baseType: !95, size: 64, offset: 64)
!528 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !507, file: !506, line: 31, baseType: !328, size: 64, offset: 192)
!529 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !507, file: !506, line: 32, baseType: !530, size: 64, offset: 256)
!530 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !531, size: 64)
!531 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32768, elements: !532)
!532 = !{!533}
!533 = !DISubrange(count: 1024)
!534 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !507, file: !506, line: 33, baseType: !370, size: 64, offset: 320)
!535 = !DIGlobalVariableExpression(var: !536, expr: !DIExpression())
!536 = distinct !DIGlobalVariable(name: "cilium_ratelimit_metrics", scope: !2, file: !506, line: 51, type: !537, isLocal: false, isDefinition: true)
!537 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !506, line: 44, size: 384, elements: !538)
!538 = !{!539, !540, !545, !550, !551, !556}
!539 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !537, file: !506, line: 45, baseType: !328, size: 64)
!540 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !537, file: !506, line: 46, baseType: !541, size: 64, offset: 64)
!541 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !542, size: 64)
!542 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_metrics_key", file: !506, line: 36, size: 32, elements: !543)
!543 = !{!544}
!544 = !DIDerivedType(tag: DW_TAG_member, name: "usage", scope: !542, file: !506, line: 37, baseType: !82, size: 32)
!545 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !537, file: !506, line: 47, baseType: !546, size: 64, offset: 128)
!546 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !547, size: 64)
!547 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ratelimit_metrics_value", file: !506, line: 40, size: 64, elements: !548)
!548 = !{!549}
!549 = !DIDerivedType(tag: DW_TAG_member, name: "dropped", scope: !547, file: !506, line: 41, baseType: !95, size: 64)
!550 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !537, file: !506, line: 48, baseType: !328, size: 64, offset: 192)
!551 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !537, file: !506, line: 49, baseType: !552, size: 64, offset: 256)
!552 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !553, size: 64)
!553 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 2048, elements: !554)
!554 = !{!555}
!555 = !DISubrange(count: 64)
!556 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !537, file: !506, line: 50, baseType: !328, size: 64, offset: 320)
!557 = !DIGlobalVariableExpression(var: !558, expr: !DIExpression())
!558 = distinct !DIGlobalVariable(name: "cilium_lb6_reverse_nat", scope: !2, file: !56, line: 193, type: !559, isLocal: false, isDefinition: true)
!559 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 186, size: 384, elements: !560)
!560 = !{!561, !562, !563, !569, !570, !571}
!561 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !559, file: !56, line: 187, baseType: !328, size: 64)
!562 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !559, file: !56, line: 188, baseType: !97, size: 64, offset: 64)
!563 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !559, file: !56, line: 189, baseType: !564, size: 64, offset: 128)
!564 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !565, size: 64)
!565 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_reverse_nat", file: !12, line: 410, size: 144, elements: !566)
!566 = !{!567, !568}
!567 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !565, file: !12, line: 411, baseType: !160, size: 128)
!568 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !565, file: !12, line: 412, baseType: !92, size: 16, offset: 128)
!569 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !559, file: !56, line: 190, baseType: !328, size: 64, offset: 192)
!570 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !559, file: !56, line: 191, baseType: !333, size: 64, offset: 256)
!571 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !559, file: !56, line: 192, baseType: !328, size: 64, offset: 320)
!572 = !DIGlobalVariableExpression(var: !573, expr: !DIExpression())
!573 = distinct !DIGlobalVariable(name: "cilium_lb6_services_v2", scope: !2, file: !56, line: 202, type: !574, isLocal: false, isDefinition: true)
!574 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 195, size: 384, elements: !575)
!575 = !{!576, !577, !588, !603, !604, !605}
!576 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !574, file: !56, line: 196, baseType: !328, size: 64)
!577 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !574, file: !56, line: 197, baseType: !578, size: 64, offset: 64)
!578 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !579, size: 64)
!579 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_key", file: !56, line: 24, size: 192, elements: !580)
!580 = !{!581, !582, !583, !584, !585, !586}
!581 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !579, file: !56, line: 25, baseType: !160, size: 128)
!582 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !579, file: !56, line: 26, baseType: !92, size: 16, offset: 128)
!583 = !DIDerivedType(tag: DW_TAG_member, name: "backend_slot", scope: !579, file: !56, line: 27, baseType: !89, size: 16, offset: 144)
!584 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !579, file: !56, line: 28, baseType: !84, size: 8, offset: 160)
!585 = !DIDerivedType(tag: DW_TAG_member, name: "scope", scope: !579, file: !56, line: 29, baseType: !84, size: 8, offset: 168)
!586 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !579, file: !56, line: 30, baseType: !587, size: 16, offset: 176)
!587 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 16, elements: !445)
!588 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !574, file: !56, line: 198, baseType: !589, size: 64, offset: 128)
!589 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !590, size: 64)
!590 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_service", file: !56, line: 34, size: 96, elements: !591)
!591 = !{!592, !598, !599, !600, !601, !602}
!592 = !DIDerivedType(tag: DW_TAG_member, scope: !590, file: !56, line: 35, baseType: !593, size: 32)
!593 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !590, file: !56, line: 35, size: 32, elements: !594)
!594 = !{!595, !596, !597}
!595 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !593, file: !56, line: 36, baseType: !82, size: 32)
!596 = !DIDerivedType(tag: DW_TAG_member, name: "affinity_timeout", scope: !593, file: !56, line: 38, baseType: !82, size: 32)
!597 = !DIDerivedType(tag: DW_TAG_member, name: "l7_lb_proxy_port", scope: !593, file: !56, line: 39, baseType: !82, size: 32)
!598 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !590, file: !56, line: 41, baseType: !89, size: 16, offset: 32)
!599 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !590, file: !56, line: 42, baseType: !89, size: 16, offset: 48)
!600 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !590, file: !56, line: 43, baseType: !84, size: 8, offset: 64)
!601 = !DIDerivedType(tag: DW_TAG_member, name: "flags2", scope: !590, file: !56, line: 44, baseType: !84, size: 8, offset: 72)
!602 = !DIDerivedType(tag: DW_TAG_member, name: "qcount", scope: !590, file: !56, line: 45, baseType: !89, size: 16, offset: 80)
!603 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !574, file: !56, line: 199, baseType: !328, size: 64, offset: 192)
!604 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !574, file: !56, line: 200, baseType: !333, size: 64, offset: 256)
!605 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !574, file: !56, line: 201, baseType: !450, size: 64, offset: 320)
!606 = !DIGlobalVariableExpression(var: !607, expr: !DIExpression())
!607 = distinct !DIGlobalVariable(name: "cilium_lb6_backends_v3", scope: !2, file: !56, line: 215, type: !608, isLocal: false, isDefinition: true)
!608 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 208, size: 384, elements: !609)
!609 = !{!610, !611, !612, !623, !624, !625}
!610 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !608, file: !56, line: 209, baseType: !328, size: 64)
!611 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !608, file: !56, line: 210, baseType: !98, size: 64, offset: 64)
!612 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !608, file: !56, line: 211, baseType: !613, size: 64, offset: 128)
!613 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !614, size: 64)
!614 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_backend", file: !56, line: 49, size: 192, elements: !615)
!615 = !{!616, !617, !618, !619, !620, !621, !622}
!616 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !614, file: !56, line: 50, baseType: !160, size: 128)
!617 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !614, file: !56, line: 51, baseType: !92, size: 16, offset: 128)
!618 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !614, file: !56, line: 52, baseType: !84, size: 8, offset: 144)
!619 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !614, file: !56, line: 53, baseType: !84, size: 8, offset: 152)
!620 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !614, file: !56, line: 54, baseType: !89, size: 16, offset: 160)
!621 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !614, file: !56, line: 58, baseType: !84, size: 8, offset: 176)
!622 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !614, file: !56, line: 59, baseType: !84, size: 8, offset: 184)
!623 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !608, file: !56, line: 212, baseType: !328, size: 64, offset: 192)
!624 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !608, file: !56, line: 213, baseType: !333, size: 64, offset: 256)
!625 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !608, file: !56, line: 214, baseType: !328, size: 64, offset: 320)
!626 = !DIGlobalVariableExpression(var: !627, expr: !DIExpression())
!627 = distinct !DIGlobalVariable(name: "cilium_lb6_affinity", scope: !2, file: !56, line: 224, type: !628, isLocal: false, isDefinition: true)
!628 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 217, size: 384, elements: !629)
!629 = !{!630, !631, !646, !653, !654, !655}
!630 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !628, file: !56, line: 218, baseType: !344, size: 64)
!631 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !628, file: !56, line: 219, baseType: !632, size: 64, offset: 64)
!632 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !633, size: 64)
!633 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_affinity_key", file: !56, line: 144, size: 192, elements: !634)
!634 = !{!635, !641, !642, !643, !644, !645}
!635 = !DIDerivedType(tag: DW_TAG_member, name: "client_id", scope: !633, file: !56, line: 145, baseType: !636, size: 128)
!636 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "lb6_affinity_client_id", file: !56, line: 139, size: 128, elements: !637)
!637 = !{!638, !639}
!638 = !DIDerivedType(tag: DW_TAG_member, name: "client_ip", scope: !636, file: !56, line: 140, baseType: !160, size: 128)
!639 = !DIDerivedType(tag: DW_TAG_member, name: "client_cookie", scope: !636, file: !56, line: 141, baseType: !640, size: 64)
!640 = !DIDerivedType(tag: DW_TAG_typedef, name: "__net_cookie", file: !83, line: 32, baseType: !95)
!641 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !633, file: !56, line: 146, baseType: !89, size: 16, offset: 128)
!642 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !633, file: !56, line: 147, baseType: !84, size: 1, offset: 144, flags: DIFlagBitField, extraData: i64 144)
!643 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !633, file: !56, line: 148, baseType: !84, size: 7, offset: 145, flags: DIFlagBitField, extraData: i64 144)
!644 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !633, file: !56, line: 149, baseType: !84, size: 8, offset: 152)
!645 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !633, file: !56, line: 150, baseType: !82, size: 32, offset: 160)
!646 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !628, file: !56, line: 220, baseType: !647, size: 64, offset: 128)
!647 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !648, size: 64)
!648 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_affinity_val", file: !56, line: 153, size: 128, elements: !649)
!649 = !{!650, !651, !652}
!650 = !DIDerivedType(tag: DW_TAG_member, name: "last_used", scope: !648, file: !56, line: 154, baseType: !95, size: 64)
!651 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !648, file: !56, line: 155, baseType: !82, size: 32, offset: 64)
!652 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !648, file: !56, line: 156, baseType: !82, size: 32, offset: 96)
!653 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !628, file: !56, line: 221, baseType: !328, size: 64, offset: 192)
!654 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !628, file: !56, line: 222, baseType: !333, size: 64, offset: 256)
!655 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !628, file: !56, line: 223, baseType: !370, size: 64, offset: 320)
!656 = !DIGlobalVariableExpression(var: !657, expr: !DIExpression())
!657 = distinct !DIGlobalVariable(name: "cilium_lb6_source_range", scope: !2, file: !56, line: 233, type: !658, isLocal: false, isDefinition: true)
!658 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 226, size: 384, elements: !659)
!659 = !{!660, !661, !669, !670, !671, !676}
!660 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !658, file: !56, line: 227, baseType: !459, size: 64)
!661 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !658, file: !56, line: 228, baseType: !662, size: 64, offset: 64)
!662 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !663, size: 64)
!663 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_src_range_key", file: !56, line: 175, size: 192, elements: !664)
!664 = !{!665, !666, !667, !668}
!665 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !663, file: !56, line: 176, baseType: !466, size: 32)
!666 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !663, file: !56, line: 177, baseType: !89, size: 16, offset: 32)
!667 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !663, file: !56, line: 178, baseType: !89, size: 16, offset: 48)
!668 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !663, file: !56, line: 179, baseType: !160, size: 128, offset: 64)
!669 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !658, file: !56, line: 229, baseType: !93, size: 64, offset: 128)
!670 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !658, file: !56, line: 230, baseType: !328, size: 64, offset: 192)
!671 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !658, file: !56, line: 231, baseType: !672, size: 64, offset: 256)
!672 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !673, size: 64)
!673 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 32000, elements: !674)
!674 = !{!675}
!675 = !DISubrange(count: 1000)
!676 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !658, file: !56, line: 232, baseType: !450, size: 64, offset: 320)
!677 = !DIGlobalVariableExpression(var: !678, expr: !DIExpression())
!678 = distinct !DIGlobalVariable(name: "cilium_lb6_health", scope: !2, file: !56, line: 242, type: !679, isLocal: false, isDefinition: true)
!679 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 235, size: 384, elements: !680)
!680 = !{!681, !682, !685, !690, !691, !692}
!681 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !679, file: !56, line: 236, baseType: !344, size: 64)
!682 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !679, file: !56, line: 237, baseType: !683, size: 64, offset: 64)
!683 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !684, size: 64)
!684 = !DIDerivedType(tag: DW_TAG_typedef, name: "__sock_cookie", file: !83, line: 33, baseType: !95)
!685 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !679, file: !56, line: 238, baseType: !686, size: 64, offset: 128)
!686 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !687, size: 64)
!687 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb6_health", file: !56, line: 62, size: 192, elements: !688)
!688 = !{!689}
!689 = !DIDerivedType(tag: DW_TAG_member, name: "peer", scope: !687, file: !56, line: 63, baseType: !614, size: 192)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !679, file: !56, line: 239, baseType: !328, size: 64, offset: 192)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !679, file: !56, line: 240, baseType: !333, size: 64, offset: 256)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !679, file: !56, line: 241, baseType: !370, size: 64, offset: 320)
!693 = !DIGlobalVariableExpression(var: !694, expr: !DIExpression())
!694 = distinct !DIGlobalVariable(name: "cilium_lb6_maglev", scope: !2, file: !56, line: 259, type: !695, isLocal: false, isDefinition: true)
!695 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 245, size: 384, elements: !696)
!696 = !{!697, !700, !701, !702, !703, !704, !705}
!697 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !695, file: !56, line: 246, baseType: !698, size: 64)
!698 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !699, size: 64)
!699 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 416, elements: !112)
!700 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !695, file: !56, line: 247, baseType: !97, size: 64, offset: 64)
!701 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !695, file: !56, line: 248, baseType: !98, size: 64, offset: 128)
!702 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !695, file: !56, line: 249, baseType: !328, size: 64, offset: 192)
!703 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !695, file: !56, line: 250, baseType: !333, size: 64, offset: 256)
!704 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !695, file: !56, line: 251, baseType: !450, size: 64, offset: 320)
!705 = !DIDerivedType(tag: DW_TAG_member, name: "values", scope: !695, file: !56, line: 253, baseType: !706, offset: 384)
!706 = !DICompositeType(tag: DW_TAG_array_type, baseType: !707, elements: !722)
!707 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !708, size: 64)
!708 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !695, file: !56, line: 253, size: 256, elements: !709)
!709 = !{!710, !713, !716, !721}
!710 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !708, file: !56, line: 253, baseType: !711, size: 64)
!711 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !712, size: 64)
!712 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 64, elements: !445)
!713 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !708, file: !56, line: 253, baseType: !714, size: 64, offset: 64)
!714 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !715, size: 64)
!715 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 128, elements: !150)
!716 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !708, file: !56, line: 253, baseType: !717, size: 64, offset: 128)
!717 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !718, size: 64)
!718 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 4191872, elements: !719)
!719 = !{!720}
!720 = !DISubrange(count: 130996)
!721 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !708, file: !56, line: 253, baseType: !328, size: 64, offset: 192)
!722 = !{!723}
!723 = !DISubrange(count: -1)
!724 = !DIGlobalVariableExpression(var: !725, expr: !DIExpression())
!725 = distinct !DIGlobalVariable(name: "cilium_lb4_reverse_nat", scope: !2, file: !56, line: 273, type: !726, isLocal: false, isDefinition: true)
!726 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 266, size: 384, elements: !727)
!727 = !{!728, !729, !730, !736, !737, !738}
!728 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !726, file: !56, line: 267, baseType: !328, size: 64)
!729 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !726, file: !56, line: 268, baseType: !97, size: 64, offset: 64)
!730 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !726, file: !56, line: 269, baseType: !731, size: 64, offset: 128)
!731 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !732, size: 64)
!732 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_reverse_nat", file: !12, line: 415, size: 48, elements: !733)
!733 = !{!734, !735}
!734 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !732, file: !12, line: 416, baseType: !153, size: 32)
!735 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !732, file: !12, line: 417, baseType: !92, size: 16, offset: 32)
!736 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !726, file: !56, line: 270, baseType: !328, size: 64, offset: 192)
!737 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !726, file: !56, line: 271, baseType: !333, size: 64, offset: 256)
!738 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !726, file: !56, line: 272, baseType: !328, size: 64, offset: 320)
!739 = !DIGlobalVariableExpression(var: !740, expr: !DIExpression())
!740 = distinct !DIGlobalVariable(name: "cilium_lb4_services_v2", scope: !2, file: !56, line: 282, type: !741, isLocal: false, isDefinition: true)
!741 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 275, size: 384, elements: !742)
!742 = !{!743, !744, !754, !769, !770, !771}
!743 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !741, file: !56, line: 276, baseType: !328, size: 64)
!744 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !741, file: !56, line: 277, baseType: !745, size: 64, offset: 64)
!745 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !746, size: 64)
!746 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_key", file: !56, line: 66, size: 96, elements: !747)
!747 = !{!748, !749, !750, !751, !752, !753}
!748 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !746, file: !56, line: 67, baseType: !153, size: 32)
!749 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !746, file: !56, line: 68, baseType: !92, size: 16, offset: 32)
!750 = !DIDerivedType(tag: DW_TAG_member, name: "backend_slot", scope: !746, file: !56, line: 69, baseType: !89, size: 16, offset: 48)
!751 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !746, file: !56, line: 70, baseType: !84, size: 8, offset: 64)
!752 = !DIDerivedType(tag: DW_TAG_member, name: "scope", scope: !746, file: !56, line: 71, baseType: !84, size: 8, offset: 72)
!753 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !746, file: !56, line: 72, baseType: !587, size: 16, offset: 80)
!754 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !741, file: !56, line: 278, baseType: !755, size: 64, offset: 128)
!755 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !756, size: 64)
!756 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_service", file: !56, line: 75, size: 96, elements: !757)
!757 = !{!758, !764, !765, !766, !767, !768}
!758 = !DIDerivedType(tag: DW_TAG_member, scope: !756, file: !56, line: 76, baseType: !759, size: 32)
!759 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !756, file: !56, line: 76, size: 32, elements: !760)
!760 = !{!761, !762, !763}
!761 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !759, file: !56, line: 78, baseType: !82, size: 32)
!762 = !DIDerivedType(tag: DW_TAG_member, name: "affinity_timeout", scope: !759, file: !56, line: 89, baseType: !82, size: 32)
!763 = !DIDerivedType(tag: DW_TAG_member, name: "l7_lb_proxy_port", scope: !759, file: !56, line: 93, baseType: !82, size: 32)
!764 = !DIDerivedType(tag: DW_TAG_member, name: "count", scope: !756, file: !56, line: 98, baseType: !89, size: 16, offset: 32)
!765 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !756, file: !56, line: 99, baseType: !89, size: 16, offset: 48)
!766 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !756, file: !56, line: 100, baseType: !84, size: 8, offset: 64)
!767 = !DIDerivedType(tag: DW_TAG_member, name: "flags2", scope: !756, file: !56, line: 101, baseType: !84, size: 8, offset: 72)
!768 = !DIDerivedType(tag: DW_TAG_member, name: "qcount", scope: !756, file: !56, line: 105, baseType: !89, size: 16, offset: 80)
!769 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !741, file: !56, line: 279, baseType: !328, size: 64, offset: 192)
!770 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !741, file: !56, line: 280, baseType: !333, size: 64, offset: 256)
!771 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !741, file: !56, line: 281, baseType: !450, size: 64, offset: 320)
!772 = !DIGlobalVariableExpression(var: !773, expr: !DIExpression())
!773 = distinct !DIGlobalVariable(name: "cilium_lb4_backends_v3", scope: !2, file: !56, line: 295, type: !774, isLocal: false, isDefinition: true)
!774 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 288, size: 384, elements: !775)
!775 = !{!776, !777, !778, !789, !790, !791}
!776 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !774, file: !56, line: 289, baseType: !328, size: 64)
!777 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !774, file: !56, line: 290, baseType: !98, size: 64, offset: 64)
!778 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !774, file: !56, line: 291, baseType: !779, size: 64, offset: 128)
!779 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !780, size: 64)
!780 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_backend", file: !56, line: 108, size: 96, elements: !781)
!781 = !{!782, !783, !784, !785, !786, !787, !788}
!782 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !780, file: !56, line: 109, baseType: !153, size: 32)
!783 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !780, file: !56, line: 110, baseType: !92, size: 16, offset: 32)
!784 = !DIDerivedType(tag: DW_TAG_member, name: "proto", scope: !780, file: !56, line: 111, baseType: !84, size: 8, offset: 48)
!785 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !780, file: !56, line: 112, baseType: !84, size: 8, offset: 56)
!786 = !DIDerivedType(tag: DW_TAG_member, name: "cluster_id", scope: !780, file: !56, line: 113, baseType: !89, size: 16, offset: 64)
!787 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !780, file: !56, line: 117, baseType: !84, size: 8, offset: 80)
!788 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !780, file: !56, line: 118, baseType: !84, size: 8, offset: 88)
!789 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !774, file: !56, line: 292, baseType: !328, size: 64, offset: 192)
!790 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !774, file: !56, line: 293, baseType: !333, size: 64, offset: 256)
!791 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !774, file: !56, line: 294, baseType: !328, size: 64, offset: 320)
!792 = !DIGlobalVariableExpression(var: !793, expr: !DIExpression())
!793 = distinct !DIGlobalVariable(name: "cilium_lb4_affinity", scope: !2, file: !56, line: 304, type: !794, isLocal: false, isDefinition: true)
!794 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 297, size: 384, elements: !795)
!795 = !{!796, !797, !811, !812, !813, !814}
!796 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !794, file: !56, line: 298, baseType: !344, size: 64)
!797 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !794, file: !56, line: 299, baseType: !798, size: 64, offset: 64)
!798 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !799, size: 64)
!799 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_affinity_key", file: !56, line: 130, size: 128, elements: !800)
!800 = !{!801, !806, !807, !808, !809, !810}
!801 = !DIDerivedType(tag: DW_TAG_member, name: "client_id", scope: !799, file: !56, line: 131, baseType: !802, size: 64)
!802 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "lb4_affinity_client_id", file: !56, line: 125, size: 64, elements: !803)
!803 = !{!804, !805}
!804 = !DIDerivedType(tag: DW_TAG_member, name: "client_ip", scope: !802, file: !56, line: 126, baseType: !82, size: 32)
!805 = !DIDerivedType(tag: DW_TAG_member, name: "client_cookie", scope: !802, file: !56, line: 127, baseType: !640, size: 64)
!806 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !799, file: !56, line: 132, baseType: !89, size: 16, offset: 64)
!807 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !799, file: !56, line: 133, baseType: !84, size: 1, offset: 80, flags: DIFlagBitField, extraData: i64 80)
!808 = !DIDerivedType(tag: DW_TAG_member, name: "reserved", scope: !799, file: !56, line: 134, baseType: !84, size: 7, offset: 81, flags: DIFlagBitField, extraData: i64 80)
!809 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !799, file: !56, line: 135, baseType: !84, size: 8, offset: 88)
!810 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !799, file: !56, line: 136, baseType: !82, size: 32, offset: 96)
!811 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !794, file: !56, line: 300, baseType: !647, size: 64, offset: 128)
!812 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !794, file: !56, line: 301, baseType: !328, size: 64, offset: 192)
!813 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !794, file: !56, line: 302, baseType: !333, size: 64, offset: 256)
!814 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !794, file: !56, line: 303, baseType: !370, size: 64, offset: 320)
!815 = !DIGlobalVariableExpression(var: !816, expr: !DIExpression())
!816 = distinct !DIGlobalVariable(name: "cilium_lb4_source_range", scope: !2, file: !56, line: 313, type: !817, isLocal: false, isDefinition: true)
!817 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 306, size: 384, elements: !818)
!818 = !{!819, !820, !828, !829, !830, !831}
!819 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !817, file: !56, line: 307, baseType: !459, size: 64)
!820 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !817, file: !56, line: 308, baseType: !821, size: 64, offset: 64)
!821 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !822, size: 64)
!822 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_src_range_key", file: !56, line: 168, size: 96, elements: !823)
!823 = !{!824, !825, !826, !827}
!824 = !DIDerivedType(tag: DW_TAG_member, name: "lpm_key", scope: !822, file: !56, line: 169, baseType: !466, size: 32)
!825 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !822, file: !56, line: 170, baseType: !89, size: 16, offset: 32)
!826 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !822, file: !56, line: 171, baseType: !89, size: 16, offset: 48)
!827 = !DIDerivedType(tag: DW_TAG_member, name: "addr", scope: !822, file: !56, line: 172, baseType: !82, size: 32, offset: 64)
!828 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !817, file: !56, line: 309, baseType: !93, size: 64, offset: 128)
!829 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !817, file: !56, line: 310, baseType: !328, size: 64, offset: 192)
!830 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !817, file: !56, line: 311, baseType: !672, size: 64, offset: 256)
!831 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !817, file: !56, line: 312, baseType: !450, size: 64, offset: 320)
!832 = !DIGlobalVariableExpression(var: !833, expr: !DIExpression())
!833 = distinct !DIGlobalVariable(name: "cilium_lb4_health", scope: !2, file: !56, line: 322, type: !834, isLocal: false, isDefinition: true)
!834 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 315, size: 384, elements: !835)
!835 = !{!836, !837, !838, !843, !844, !845}
!836 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !834, file: !56, line: 316, baseType: !344, size: 64)
!837 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !834, file: !56, line: 317, baseType: !683, size: 64, offset: 64)
!838 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !834, file: !56, line: 318, baseType: !839, size: 64, offset: 128)
!839 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !840, size: 64)
!840 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb4_health", file: !56, line: 121, size: 96, elements: !841)
!841 = !{!842}
!842 = !DIDerivedType(tag: DW_TAG_member, name: "peer", scope: !840, file: !56, line: 122, baseType: !780, size: 96)
!843 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !834, file: !56, line: 319, baseType: !328, size: 64, offset: 192)
!844 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !834, file: !56, line: 320, baseType: !333, size: 64, offset: 256)
!845 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !834, file: !56, line: 321, baseType: !370, size: 64, offset: 320)
!846 = !DIGlobalVariableExpression(var: !847, expr: !DIExpression())
!847 = distinct !DIGlobalVariable(name: "cilium_lb4_maglev", scope: !2, file: !56, line: 339, type: !848, isLocal: false, isDefinition: true)
!848 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 325, size: 384, elements: !849)
!849 = !{!850, !851, !852, !853, !854, !855, !856}
!850 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !848, file: !56, line: 326, baseType: !698, size: 64)
!851 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !848, file: !56, line: 327, baseType: !97, size: 64, offset: 64)
!852 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !848, file: !56, line: 328, baseType: !98, size: 64, offset: 128)
!853 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !848, file: !56, line: 329, baseType: !328, size: 64, offset: 192)
!854 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !848, file: !56, line: 330, baseType: !333, size: 64, offset: 256)
!855 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !848, file: !56, line: 331, baseType: !450, size: 64, offset: 320)
!856 = !DIDerivedType(tag: DW_TAG_member, name: "values", scope: !848, file: !56, line: 333, baseType: !857, offset: 384)
!857 = !DICompositeType(tag: DW_TAG_array_type, baseType: !858, elements: !722)
!858 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !859, size: 64)
!859 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !848, file: !56, line: 333, size: 256, elements: !860)
!860 = !{!861, !862, !863, !864}
!861 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !859, file: !56, line: 333, baseType: !711, size: 64)
!862 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !859, file: !56, line: 333, baseType: !714, size: 64, offset: 64)
!863 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !859, file: !56, line: 333, baseType: !717, size: 64, offset: 128)
!864 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !859, file: !56, line: 333, baseType: !328, size: 64, offset: 192)
!865 = !DIGlobalVariableExpression(var: !866, expr: !DIExpression())
!866 = distinct !DIGlobalVariable(name: "cilium_lb_affinity_match", scope: !2, file: !56, line: 349, type: !867, isLocal: false, isDefinition: true)
!867 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !56, line: 342, size: 384, elements: !868)
!868 = !{!869, !870, !877, !878, !879, !880}
!869 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !867, file: !56, line: 343, baseType: !328, size: 64)
!870 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !867, file: !56, line: 344, baseType: !871, size: 64, offset: 64)
!871 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !872, size: 64)
!872 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_affinity_match", file: !56, line: 159, size: 64, elements: !873)
!873 = !{!874, !875, !876}
!874 = !DIDerivedType(tag: DW_TAG_member, name: "backend_id", scope: !872, file: !56, line: 160, baseType: !82, size: 32)
!875 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_id", scope: !872, file: !56, line: 161, baseType: !89, size: 16, offset: 32)
!876 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !872, file: !56, line: 162, baseType: !89, size: 16, offset: 48)
!877 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !867, file: !56, line: 345, baseType: !93, size: 64, offset: 128)
!878 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !867, file: !56, line: 346, baseType: !328, size: 64, offset: 192)
!879 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !867, file: !56, line: 347, baseType: !333, size: 64, offset: 256)
!880 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !867, file: !56, line: 348, baseType: !450, size: 64, offset: 320)
!881 = !DIGlobalVariableExpression(var: !882, expr: !DIExpression())
!882 = distinct !DIGlobalVariable(name: "cilium_lb_act", scope: !2, file: !883, line: 28, type: !884, isLocal: false, isDefinition: true)
!883 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/act.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "fedf61bdb03fde76463add1b3bc5404c")
!884 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !883, line: 21, size: 384, elements: !885)
!885 = !{!886, !887, !894, !900, !901, !902}
!886 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !884, file: !883, line: 22, baseType: !344, size: 64)
!887 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !884, file: !883, line: 23, baseType: !888, size: 64, offset: 64)
!888 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !889, size: 64)
!889 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_act_key", file: !883, line: 10, size: 32, elements: !890)
!890 = !{!891, !892, !893}
!891 = !DIDerivedType(tag: DW_TAG_member, name: "svc_id", scope: !889, file: !883, line: 11, baseType: !89, size: 16)
!892 = !DIDerivedType(tag: DW_TAG_member, name: "zone", scope: !889, file: !883, line: 12, baseType: !84, size: 8, offset: 16)
!893 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !889, file: !883, line: 13, baseType: !84, size: 8, offset: 24)
!894 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !884, file: !883, line: 24, baseType: !895, size: 64, offset: 128)
!895 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !896, size: 64)
!896 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "lb_act_value", file: !883, line: 16, size: 64, elements: !897)
!897 = !{!898, !899}
!898 = !DIDerivedType(tag: DW_TAG_member, name: "opened", scope: !896, file: !883, line: 17, baseType: !82, size: 32)
!899 = !DIDerivedType(tag: DW_TAG_member, name: "closed", scope: !896, file: !883, line: 18, baseType: !82, size: 32, offset: 32)
!900 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !884, file: !883, line: 25, baseType: !328, size: 64, offset: 192)
!901 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !884, file: !883, line: 26, baseType: !333, size: 64, offset: 256)
!902 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !884, file: !883, line: 27, baseType: !370, size: 64, offset: 320)
!903 = !DIGlobalVariableExpression(var: !904, expr: !DIExpression())
!904 = distinct !DIGlobalVariable(name: "cilium_skip_lb6", scope: !2, file: !905, line: 28, type: !906, isLocal: false, isDefinition: true)
!905 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/lrp.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "03dbfb650c93a58cdb7545f6c98dd875")
!906 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !905, line: 21, size: 384, elements: !907)
!907 = !{!908, !909, !918, !919, !920, !925}
!908 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !906, file: !905, line: 22, baseType: !328, size: 64)
!909 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !906, file: !905, line: 23, baseType: !910, size: 64, offset: 64)
!910 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !911, size: 64)
!911 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "skip_lb6_key", file: !905, line: 13, size: 256, elements: !912)
!912 = !{!913, !914, !915, !916, !917}
!913 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !911, file: !905, line: 14, baseType: !95, size: 64)
!914 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !911, file: !905, line: 15, baseType: !160, size: 128, offset: 64)
!915 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !911, file: !905, line: 16, baseType: !82, size: 32, offset: 192)
!916 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !911, file: !905, line: 17, baseType: !89, size: 16, offset: 224)
!917 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !911, file: !905, line: 18, baseType: !89, size: 16, offset: 240)
!918 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !906, file: !905, line: 24, baseType: !93, size: 64, offset: 128)
!919 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !906, file: !905, line: 25, baseType: !328, size: 64, offset: 192)
!920 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !906, file: !905, line: 26, baseType: !921, size: 64, offset: 256)
!921 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !922, size: 64)
!922 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 3200, elements: !923)
!923 = !{!924}
!924 = !DISubrange(count: 100)
!925 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !906, file: !905, line: 27, baseType: !450, size: 64, offset: 320)
!926 = !DIGlobalVariableExpression(var: !927, expr: !DIExpression())
!927 = distinct !DIGlobalVariable(name: "cilium_skip_lb4", scope: !2, file: !905, line: 37, type: !928, isLocal: false, isDefinition: true)
!928 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !905, line: 30, size: 384, elements: !929)
!929 = !{!930, !931, !939, !940, !941, !942}
!930 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !928, file: !905, line: 31, baseType: !328, size: 64)
!931 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !928, file: !905, line: 32, baseType: !932, size: 64, offset: 64)
!932 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !933, size: 64)
!933 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "skip_lb4_key", file: !905, line: 6, size: 128, elements: !934)
!934 = !{!935, !936, !937, !938}
!935 = !DIDerivedType(tag: DW_TAG_member, name: "netns_cookie", scope: !933, file: !905, line: 7, baseType: !95, size: 64)
!936 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !933, file: !905, line: 8, baseType: !82, size: 32, offset: 64)
!937 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !933, file: !905, line: 9, baseType: !89, size: 16, offset: 96)
!938 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !933, file: !905, line: 10, baseType: !89, size: 16, offset: 112)
!939 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !928, file: !905, line: 33, baseType: !93, size: 64, offset: 128)
!940 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !928, file: !905, line: 34, baseType: !328, size: 64, offset: 192)
!941 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !928, file: !905, line: 35, baseType: !921, size: 64, offset: 256)
!942 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !928, file: !905, line: 36, baseType: !450, size: 64, offset: 320)
!943 = !DIGlobalVariableExpression(var: !944, expr: !DIExpression())
!944 = distinct !DIGlobalVariable(name: "__config_enable_lrp", scope: !2, file: !905, line: 39, type: !86, isLocal: false, isDefinition: true, annotations: !945)
!945 = !{!277, !946}
!946 = !{!"btf_decl_tag", !"Enable support for Local Redirect Policy"}
!947 = !DIGlobalVariableExpression(var: !948, expr: !DIExpression())
!948 = distinct !DIGlobalVariable(name: "cilium_lb4_reverse_sk", scope: !2, file: !949, line: 42, type: !950, isLocal: false, isDefinition: true)
!949 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/sock.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "ae3d583b4ce8be357b1cbf765842c908")
!950 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !949, line: 35, size: 384, elements: !951)
!951 = !{!952, !953, !961, !968, !969, !974}
!952 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !950, file: !949, line: 36, baseType: !344, size: 64)
!953 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !950, file: !949, line: 37, baseType: !954, size: 64, offset: 64)
!954 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !955, size: 64)
!955 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_revnat_tuple", file: !949, line: 22, size: 128, elements: !956)
!956 = !{!957, !958, !959, !960}
!957 = !DIDerivedType(tag: DW_TAG_member, name: "cookie", scope: !955, file: !949, line: 23, baseType: !684, size: 64)
!958 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !955, file: !949, line: 24, baseType: !153, size: 32, offset: 64)
!959 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !955, file: !949, line: 25, baseType: !92, size: 16, offset: 96)
!960 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !955, file: !949, line: 26, baseType: !89, size: 16, offset: 112)
!961 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !950, file: !949, line: 38, baseType: !962, size: 64, offset: 128)
!962 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !963, size: 64)
!963 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv4_revnat_entry", file: !949, line: 29, size: 64, elements: !964)
!964 = !{!965, !966, !967}
!965 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !963, file: !949, line: 30, baseType: !153, size: 32)
!966 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !963, file: !949, line: 31, baseType: !92, size: 16, offset: 32)
!967 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !963, file: !949, line: 32, baseType: !89, size: 16, offset: 48)
!968 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !950, file: !949, line: 39, baseType: !328, size: 64, offset: 192)
!969 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !950, file: !949, line: 40, baseType: !970, size: 64, offset: 256)
!970 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !971, size: 64)
!971 = !DICompositeType(tag: DW_TAG_array_type, baseType: !305, size: 8388608, elements: !972)
!972 = !{!973}
!973 = !DISubrange(count: 262144)
!974 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !950, file: !949, line: 41, baseType: !370, size: 64, offset: 320)
!975 = !DIGlobalVariableExpression(var: !976, expr: !DIExpression())
!976 = distinct !DIGlobalVariable(name: "cilium_lb6_reverse_sk", scope: !2, file: !949, line: 64, type: !977, isLocal: false, isDefinition: true)
!977 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !949, line: 57, size: 384, elements: !978)
!978 = !{!979, !980, !988, !995, !996, !997}
!979 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !977, file: !949, line: 58, baseType: !344, size: 64)
!980 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !977, file: !949, line: 59, baseType: !981, size: 64, offset: 64)
!981 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !982, size: 64)
!982 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_revnat_tuple", file: !949, line: 44, size: 256, elements: !983)
!983 = !{!984, !985, !986, !987}
!984 = !DIDerivedType(tag: DW_TAG_member, name: "cookie", scope: !982, file: !949, line: 45, baseType: !684, size: 64)
!985 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !982, file: !949, line: 46, baseType: !160, size: 128, offset: 64)
!986 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !982, file: !949, line: 47, baseType: !92, size: 16, offset: 192)
!987 = !DIDerivedType(tag: DW_TAG_member, name: "pad", scope: !982, file: !949, line: 48, baseType: !89, size: 16, offset: 208)
!988 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !977, file: !949, line: 60, baseType: !989, size: 64, offset: 128)
!989 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !990, size: 64)
!990 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "ipv6_revnat_entry", file: !949, line: 51, size: 160, elements: !991)
!991 = !{!992, !993, !994}
!992 = !DIDerivedType(tag: DW_TAG_member, name: "address", scope: !990, file: !949, line: 52, baseType: !160, size: 128)
!993 = !DIDerivedType(tag: DW_TAG_member, name: "port", scope: !990, file: !949, line: 53, baseType: !92, size: 16, offset: 128)
!994 = !DIDerivedType(tag: DW_TAG_member, name: "rev_nat_index", scope: !990, file: !949, line: 54, baseType: !89, size: 16, offset: 144)
!995 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !977, file: !949, line: 61, baseType: !328, size: 64, offset: 192)
!996 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !977, file: !949, line: 62, baseType: !970, size: 64, offset: 256)
!997 = !DIDerivedType(tag: DW_TAG_member, name: "map_flags", scope: !977, file: !949, line: 63, baseType: !370, size: 64, offset: 320)
!998 = !DIGlobalVariableExpression(var: !999, expr: !DIExpression())
!999 = distinct !DIGlobalVariable(name: "cilium_events", scope: !2, file: !1000, line: 13, type: !1001, isLocal: false, isDefinition: true)
!1000 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/events.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "61b587317a5ed8647de3686340876e90")
!1001 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1000, line: 8, size: 256, elements: !1002)
!1002 = !{!1003, !1004, !1005, !1006}
!1003 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1001, file: !1000, line: 9, baseType: !714, size: 64)
!1004 = !DIDerivedType(tag: DW_TAG_member, name: "key_size", scope: !1001, file: !1000, line: 10, baseType: !714, size: 64, offset: 64)
!1005 = !DIDerivedType(tag: DW_TAG_member, name: "value_size", scope: !1001, file: !1000, line: 11, baseType: !714, size: 64, offset: 128)
!1006 = !DIDerivedType(tag: DW_TAG_member, name: "pinning", scope: !1001, file: !1000, line: 12, baseType: !328, size: 64, offset: 192)
!1007 = !DIGlobalVariableExpression(var: !1008, expr: !DIExpression(DW_OP_constu, 1, DW_OP_stack_value))
!1008 = distinct !DIGlobalVariable(name: "map_lookup_elem", scope: !2, file: !1009, line: 33, type: !1010, isLocal: true, isDefinition: true)
!1009 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../helpers.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "186086bcd68d0bf51ebf2512e88283a5")
!1010 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1011, size: 64)
!1011 = !DISubroutineType(types: !1012)
!1012 = !{!91, !1013, !1013}
!1013 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1014, size: 64)
!1014 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!1015 = !DIGlobalVariableExpression(var: !1016, expr: !DIExpression(DW_OP_constu, 122, DW_OP_stack_value))
!1016 = distinct !DIGlobalVariable(name: "get_netns_cookie", scope: !2, file: !1009, line: 49, type: !1017, isLocal: true, isDefinition: true)
!1017 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1018, size: 64)
!1018 = !DISubroutineType(types: !1019)
!1019 = !{!640, !91}
!1020 = !DIGlobalVariableExpression(var: !1021, expr: !DIExpression(DW_OP_constu, 118, DW_OP_stack_value))
!1021 = distinct !DIGlobalVariable(name: "jiffies64", scope: !2, file: !1009, line: 45, type: !1022, isLocal: true, isDefinition: true)
!1022 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1023, size: 64)
!1023 = !DISubroutineType(types: !1024)
!1024 = !{!95, null}
!1025 = !DIGlobalVariableExpression(var: !1026, expr: !DIExpression(DW_OP_constu, 5, DW_OP_stack_value))
!1026 = distinct !DIGlobalVariable(name: "ktime_get_ns", scope: !2, file: !1009, line: 43, type: !1022, isLocal: true, isDefinition: true)
!1027 = !DIGlobalVariableExpression(var: !1028, expr: !DIExpression(DW_OP_constu, 3, DW_OP_stack_value))
!1028 = distinct !DIGlobalVariable(name: "map_delete_elem", scope: !2, file: !1009, line: 36, type: !1029, isLocal: true, isDefinition: true)
!1029 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1030, size: 64)
!1030 = !DISubroutineType(types: !1031)
!1031 = !{!305, !1013, !1013}
!1032 = !DIGlobalVariableExpression(var: !1033, expr: !DIExpression(DW_OP_constu, 7, DW_OP_stack_value))
!1033 = distinct !DIGlobalVariable(name: "get_prandom_u32", scope: !2, file: !1009, line: 59, type: !1034, isLocal: true, isDefinition: true)
!1034 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1035, size: 64)
!1035 = !DISubroutineType(types: !1036)
!1036 = !{!82, null}
!1037 = !DIGlobalVariableExpression(var: !1038, expr: !DIExpression(DW_OP_constu, 46, DW_OP_stack_value))
!1038 = distinct !DIGlobalVariable(name: "get_socket_cookie", scope: !2, file: !1009, line: 48, type: !1039, isLocal: true, isDefinition: true)
!1039 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1040, size: 64)
!1040 = !DISubroutineType(types: !1041)
!1041 = !{!684, !91}
!1042 = !DIGlobalVariableExpression(var: !1043, expr: !DIExpression(DW_OP_constu, 2, DW_OP_stack_value))
!1043 = distinct !DIGlobalVariable(name: "map_update_elem", scope: !2, file: !1009, line: 34, type: !1044, isLocal: true, isDefinition: true)
!1044 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1045, size: 64)
!1045 = !DISubroutineType(types: !1046)
!1046 = !{!305, !1013, !1013, !1013, !82}
!1047 = !DIGlobalVariableExpression(var: !1048, expr: !DIExpression())
!1048 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 36, type: !105, isLocal: true, isDefinition: true)
!1049 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/source_info.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "527298247430c74ca5c56b703daf641a")
!1050 = !DIGlobalVariableExpression(var: !1051, expr: !DIExpression())
!1051 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 37, type: !1052, isLocal: true, isDefinition: true)
!1052 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 80, elements: !1053)
!1053 = !{!1054}
!1054 = !DISubrange(count: 10)
!1055 = !DIGlobalVariableExpression(var: !1056, expr: !DIExpression())
!1056 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 38, type: !1057, isLocal: true, isDefinition: true)
!1057 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 112, elements: !1058)
!1058 = !{!1059}
!1059 = !DISubrange(count: 14)
!1060 = !DIGlobalVariableExpression(var: !1061, expr: !DIExpression())
!1061 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 39, type: !1052, isLocal: true, isDefinition: true)
!1062 = !DIGlobalVariableExpression(var: !1063, expr: !DIExpression())
!1063 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 42, type: !1064, isLocal: true, isDefinition: true)
!1064 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 128, elements: !165)
!1065 = !DIGlobalVariableExpression(var: !1066, expr: !DIExpression())
!1066 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 45, type: !1067, isLocal: true, isDefinition: true)
!1067 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 56, elements: !1068)
!1068 = !{!1069}
!1069 = !DISubrange(count: 7)
!1070 = !DIGlobalVariableExpression(var: !1071, expr: !DIExpression())
!1071 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 46, type: !1067, isLocal: true, isDefinition: true)
!1072 = !DIGlobalVariableExpression(var: !1073, expr: !DIExpression())
!1073 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 47, type: !1074, isLocal: true, isDefinition: true)
!1074 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 64, elements: !1075)
!1075 = !{!1076}
!1076 = !DISubrange(count: 8)
!1077 = !DIGlobalVariableExpression(var: !1078, expr: !DIExpression())
!1078 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 48, type: !105, isLocal: true, isDefinition: true)
!1079 = !DIGlobalVariableExpression(var: !1080, expr: !DIExpression())
!1080 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 49, type: !1081, isLocal: true, isDefinition: true)
!1081 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 40, elements: !306)
!1082 = !DIGlobalVariableExpression(var: !1083, expr: !DIExpression())
!1083 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 50, type: !1074, isLocal: true, isDefinition: true)
!1084 = !DIGlobalVariableExpression(var: !1085, expr: !DIExpression())
!1085 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 51, type: !1067, isLocal: true, isDefinition: true)
!1086 = !DIGlobalVariableExpression(var: !1087, expr: !DIExpression())
!1087 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 52, type: !1088, isLocal: true, isDefinition: true)
!1088 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 96, elements: !1089)
!1089 = !{!1090}
!1090 = !DISubrange(count: 12)
!1091 = !DIGlobalVariableExpression(var: !1092, expr: !DIExpression())
!1092 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 53, type: !1093, isLocal: true, isDefinition: true)
!1093 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 136, elements: !1094)
!1094 = !{!1095}
!1095 = !DISubrange(count: 17)
!1096 = !DIGlobalVariableExpression(var: !1097, expr: !DIExpression())
!1097 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 54, type: !1074, isLocal: true, isDefinition: true)
!1098 = !DIGlobalVariableExpression(var: !1099, expr: !DIExpression())
!1099 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 55, type: !1074, isLocal: true, isDefinition: true)
!1100 = !DIGlobalVariableExpression(var: !1101, expr: !DIExpression())
!1101 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 56, type: !1064, isLocal: true, isDefinition: true)
!1102 = !DIGlobalVariableExpression(var: !1103, expr: !DIExpression())
!1103 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 57, type: !1104, isLocal: true, isDefinition: true)
!1104 = !DICompositeType(tag: DW_TAG_array_type, baseType: !106, size: 144, elements: !1105)
!1105 = !{!1106}
!1106 = !DISubrange(count: 18)
!1107 = !DIGlobalVariableExpression(var: !1108, expr: !DIExpression())
!1108 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 58, type: !1067, isLocal: true, isDefinition: true)
!1109 = !DIGlobalVariableExpression(var: !1110, expr: !DIExpression())
!1110 = distinct !DIGlobalVariable(scope: null, file: !1049, line: 59, type: !1057, isLocal: true, isDefinition: true)
!1111 = !{!118, !1112}
!1112 = !{!"btf_decl_tag", !"Number of bits of the identity reserved for the Cluster ID"}
!1113 = !{i32 7, !"Dwarf Version", i32 5}
!1114 = !{i32 2, !"Debug Info Version", i32 3}
!1115 = !{i32 1, !"wchar_size", i32 4}
!1116 = !{i32 7, !"frame-pointer", i32 2}
!1117 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!1118 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!1119 = distinct !DISubprogram(name: "__check_cluster_id_bits", scope: !116, file: !116, line: 57, type: !1120, scopeLine: 57, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1122)
!1120 = !DISubroutineType(types: !1121)
!1121 = !{null}
!1122 = !{!1123}
!1123 = !DILocalVariable(name: "out", scope: !1124, file: !116, line: 57, type: !91)
!1124 = distinct !DILexicalBlock(scope: !1119, file: !116, line: 57, column: 1)
!1125 = !DILocation(line: 57, column: 1, scope: !1124)
!1126 = !{i64 2148005471}
!1127 = !DILocation(line: 0, scope: !1124)
!1128 = !DILocation(line: 57, column: 1, scope: !1119)
!1129 = !{!1130, !1130, i64 0}
!1130 = !{!"int", !1131, i64 0}
!1131 = !{!"omnipotent char", !1132, i64 0}
!1132 = !{!"Simple C/C++ TBAA"}
!1133 = distinct !DISubprogram(name: "cil_sock4_connect", scope: !104, file: !104, line: 459, type: !1134, scopeLine: 460, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1171)
!1134 = !DISubroutineType(types: !1135)
!1135 = !{!305, !1136}
!1136 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1137, size: 64)
!1137 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock_addr", file: !467, line: 6567, size: 576, elements: !1138)
!1138 = !{!1139, !1140, !1141, !1143, !1144, !1145, !1146, !1147, !1148, !1149}
!1139 = !DIDerivedType(tag: DW_TAG_member, name: "user_family", scope: !1137, file: !467, line: 6568, baseType: !82, size: 32)
!1140 = !DIDerivedType(tag: DW_TAG_member, name: "user_ip4", scope: !1137, file: !467, line: 6569, baseType: !82, size: 32, offset: 32)
!1141 = !DIDerivedType(tag: DW_TAG_member, name: "user_ip6", scope: !1137, file: !467, line: 6572, baseType: !1142, size: 128, offset: 64)
!1142 = !DICompositeType(tag: DW_TAG_array_type, baseType: !82, size: 128, elements: !150)
!1143 = !DIDerivedType(tag: DW_TAG_member, name: "user_port", scope: !1137, file: !467, line: 6575, baseType: !82, size: 32, offset: 192)
!1144 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !1137, file: !467, line: 6578, baseType: !82, size: 32, offset: 224)
!1145 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1137, file: !467, line: 6579, baseType: !82, size: 32, offset: 256)
!1146 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !1137, file: !467, line: 6580, baseType: !82, size: 32, offset: 288)
!1147 = !DIDerivedType(tag: DW_TAG_member, name: "msg_src_ip4", scope: !1137, file: !467, line: 6581, baseType: !82, size: 32, offset: 320)
!1148 = !DIDerivedType(tag: DW_TAG_member, name: "msg_src_ip6", scope: !1137, file: !467, line: 6584, baseType: !1142, size: 128, offset: 352)
!1149 = !DIDerivedType(tag: DW_TAG_member, scope: !1137, file: !467, line: 6587, baseType: !1150, size: 64, align: 64, offset: 512)
!1150 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !1137, file: !467, line: 6587, size: 64, align: 64, elements: !1151)
!1151 = !{!1152}
!1152 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !1150, file: !467, line: 6587, baseType: !1153, size: 64)
!1153 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1154, size: 64)
!1154 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !467, line: 6180, size: 640, elements: !1155)
!1155 = !{!1156, !1157, !1158, !1159, !1160, !1161, !1162, !1163, !1164, !1165, !1166, !1167, !1168, !1169}
!1156 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !1154, file: !467, line: 6181, baseType: !82, size: 32)
!1157 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !1154, file: !467, line: 6182, baseType: !82, size: 32, offset: 32)
!1158 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !1154, file: !467, line: 6183, baseType: !82, size: 32, offset: 64)
!1159 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !1154, file: !467, line: 6184, baseType: !82, size: 32, offset: 96)
!1160 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !1154, file: !467, line: 6185, baseType: !82, size: 32, offset: 128)
!1161 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !1154, file: !467, line: 6186, baseType: !82, size: 32, offset: 160)
!1162 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !1154, file: !467, line: 6188, baseType: !82, size: 32, offset: 192)
!1163 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !1154, file: !467, line: 6189, baseType: !1142, size: 128, offset: 224)
!1164 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !1154, file: !467, line: 6190, baseType: !82, size: 32, offset: 352)
!1165 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !1154, file: !467, line: 6191, baseType: !92, size: 16, offset: 384)
!1166 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !1154, file: !467, line: 6193, baseType: !82, size: 32, offset: 416)
!1167 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !1154, file: !467, line: 6194, baseType: !1142, size: 128, offset: 448)
!1168 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !1154, file: !467, line: 6195, baseType: !82, size: 32, offset: 576)
!1169 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !1154, file: !467, line: 6196, baseType: !1170, size: 32, offset: 608)
!1170 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !83, line: 12, baseType: !305)
!1171 = !{!1172, !1173}
!1172 = !DILocalVariable(name: "ctx", arg: 1, scope: !1133, file: !104, line: 459, type: !1136)
!1173 = !DILocalVariable(name: "err", scope: !1133, file: !104, line: 461, type: !305)
!1174 = distinct !DIAssignID()
!1175 = distinct !DIAssignID()
!1176 = distinct !DIAssignID()
!1177 = distinct !DIAssignID()
!1178 = distinct !DIAssignID()
!1179 = distinct !DIAssignID()
!1180 = distinct !DIAssignID()
!1181 = distinct !DIAssignID()
!1182 = distinct !DIAssignID()
!1183 = distinct !DIAssignID()
!1184 = distinct !DIAssignID()
!1185 = distinct !DIAssignID()
!1186 = distinct !DIAssignID()
!1187 = distinct !DIAssignID()
!1188 = distinct !DIAssignID()
!1189 = distinct !DIAssignID()
!1190 = distinct !DIAssignID()
!1191 = distinct !DIAssignID()
!1192 = !DILocation(line: 0, scope: !1133)
!1193 = !DILocalVariable(name: "key", scope: !1194, file: !104, line: 302, type: !746)
!1194 = distinct !DISubprogram(name: "__sock4_xlate_fwd", scope: !104, file: !104, line: 290, type: !1195, scopeLine: 294, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1198)
!1195 = !DISubroutineType(types: !1196)
!1196 = !{!305, !1136, !1136, !1197, !1197}
!1197 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !88)
!1198 = !{!1199, !1200, !1201, !1202, !1203, !1204, !1205, !1208, !1211, !1212, !1213, !1193, !1214, !1215, !1216, !1217, !1222}
!1199 = !DILocalVariable(name: "ctx", arg: 1, scope: !1194, file: !104, line: 290, type: !1136)
!1200 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !1194, file: !104, line: 291, type: !1136)
!1201 = !DILocalVariable(name: "udp_only", arg: 3, scope: !1194, file: !104, line: 292, type: !1197)
!1202 = !DILocalVariable(name: "is_connect", arg: 4, scope: !1194, file: !104, line: 293, type: !1197)
!1203 = !DILocalVariable(name: "id", scope: !1194, file: !104, line: 295, type: !802)
!1204 = !DILocalVariable(name: "in_hostns", scope: !1194, file: !104, line: 296, type: !1197)
!1205 = !DILocalVariable(name: "backend", scope: !1194, file: !104, line: 297, type: !1206)
!1206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1207, size: 64)
!1207 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !780)
!1208 = !DILocalVariable(name: "svc", scope: !1194, file: !104, line: 298, type: !1209)
!1209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1210, size: 64)
!1210 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !756)
!1211 = !DILocalVariable(name: "dst_port", scope: !1194, file: !104, line: 299, type: !92)
!1212 = !DILocalVariable(name: "protocol", scope: !1194, file: !104, line: 300, type: !84)
!1213 = !DILocalVariable(name: "dst_ip", scope: !1194, file: !104, line: 301, type: !153)
!1214 = !DILocalVariable(name: "backend_slot", scope: !1194, file: !104, line: 307, type: !1209)
!1215 = !DILocalVariable(name: "backend_from_affinity", scope: !1194, file: !104, line: 308, type: !88)
!1216 = !DILocalVariable(name: "backend_id", scope: !1194, file: !104, line: 309, type: !82)
!1217 = !DILocalVariable(name: "out", scope: !1218, file: !104, line: 331, type: !91)
!1218 = distinct !DILexicalBlock(scope: !1219, file: !104, line: 331, column: 7)
!1219 = distinct !DILexicalBlock(scope: !1220, file: !104, line: 331, column: 7)
!1220 = distinct !DILexicalBlock(scope: !1221, file: !104, line: 329, column: 59)
!1221 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 329, column: 6)
!1222 = !DILocalVariable(name: "out", scope: !1223, file: !104, line: 357, type: !91)
!1223 = distinct !DILexicalBlock(scope: !1224, file: !104, line: 357, column: 6)
!1224 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 357, column: 6)
!1225 = !DILocation(line: 0, scope: !1194, inlinedAt: !1226)
!1226 = distinct !DILocation(line: 468, column: 8, scope: !1133)
!1227 = !DILocalVariable(name: "ctx", arg: 1, scope: !1228, file: !104, line: 84, type: !91)
!1228 = distinct !DISubprogram(name: "ctx_in_hostns", scope: !104, file: !104, line: 84, type: !1229, scopeLine: 85, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1232)
!1229 = !DISubroutineType(types: !1230)
!1230 = !{!88, !91, !1231}
!1231 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !640, size: 64)
!1232 = !{!1227, !1233, !1234}
!1233 = !DILocalVariable(name: "cookie", arg: 2, scope: !1228, file: !104, line: 84, type: !1231)
!1234 = !DILocalVariable(name: "own_cookie", scope: !1228, file: !104, line: 86, type: !640)
!1235 = !DILocation(line: 0, scope: !1228, inlinedAt: !1236)
!1236 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !1226)
!1237 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !1236)
!1238 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !1236)
!1239 = !DILocalVariable(name: "dport", scope: !1240, file: !104, line: 54, type: !81)
!1240 = distinct !DISubprogram(name: "ctx_dst_port", scope: !104, file: !104, line: 52, type: !1241, scopeLine: 53, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1245)
!1241 = !DISubroutineType(types: !1242)
!1242 = !{!92, !1243}
!1243 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1244, size: 64)
!1244 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1137)
!1245 = !{!1246, !1239}
!1246 = !DILocalVariable(name: "ctx", arg: 1, scope: !1240, file: !104, line: 52, type: !1243)
!1247 = !DILocation(line: 0, scope: !1240, inlinedAt: !1248)
!1248 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !1226)
!1249 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !1248)
!1250 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !1248)
!1251 = !{!1252, !1130, i64 24}
!1252 = !{!"bpf_sock_addr", !1130, i64 0, !1130, i64 4, !1131, i64 8, !1130, i64 24, !1130, i64 28, !1130, i64 32, !1130, i64 36, !1130, i64 40, !1131, i64 44, !1131, i64 64}
!1253 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !1248)
!1254 = distinct !DIAssignID()
!1255 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !1248)
!1256 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !1248)
!1257 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !1248)
!1258 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !1226)
!1259 = !{!1252, !1130, i64 36}
!1260 = !DILocation(line: 301, column: 23, scope: !1194, inlinedAt: !1226)
!1261 = !{!1252, !1130, i64 4}
!1262 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !1226)
!1263 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !1226)
!1264 = !{!1265, !1130, i64 0}
!1265 = !{!"lb4_key", !1130, i64 0, !1266, i64 4, !1266, i64 6, !1131, i64 8, !1131, i64 9, !1131, i64 10}
!1266 = !{!"short", !1131, i64 0}
!1267 = distinct !DIAssignID()
!1268 = !{!1265, !1266, i64 4}
!1269 = distinct !DIAssignID()
!1270 = distinct !DIAssignID()
!1271 = !{!1265, !1131, i64 8}
!1272 = distinct !DIAssignID()
!1273 = distinct !DIAssignID()
!1274 = distinct !DIAssignID()
!1275 = !DILocalVariable(name: "proto", arg: 1, scope: !1276, file: !104, line: 130, type: !84)
!1276 = distinct !DISubprogram(name: "sock_proto_enabled", scope: !104, file: !104, line: 130, type: !1277, scopeLine: 131, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1279)
!1277 = !DISubroutineType(types: !1278)
!1278 = !{!88, !84}
!1279 = !{!1275}
!1280 = !DILocation(line: 0, scope: !1276, inlinedAt: !1281)
!1281 = distinct !DILocation(line: 317, column: 20, scope: !1282, inlinedAt: !1226)
!1282 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 317, column: 6)
!1283 = !DILocation(line: 132, column: 2, scope: !1276, inlinedAt: !1281)
!1284 = !DILocalVariable(name: "dport", scope: !1285, file: !56, line: 1748, type: !89)
!1285 = distinct !DISubprogram(name: "lb4_lookup_service", scope: !56, file: !56, line: 1745, type: !1286, scopeLine: 1746, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1288)
!1286 = !DISubroutineType(types: !1287)
!1287 = !{!1209, !745, !1197}
!1288 = !{!1289, !1290, !1291, !1284, !1292}
!1289 = !DILocalVariable(name: "key", arg: 1, scope: !1285, file: !56, line: 1745, type: !745)
!1290 = !DILocalVariable(name: "east_west", arg: 2, scope: !1285, file: !56, line: 1745, type: !1197)
!1291 = !DILocalVariable(name: "svc", scope: !1285, file: !56, line: 1747, type: !1209)
!1292 = !DILocalVariable(name: "proto", scope: !1285, file: !56, line: 1749, type: !84)
!1293 = distinct !DIAssignID()
!1294 = !DILocation(line: 0, scope: !1285, inlinedAt: !1295)
!1295 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !1226)
!1296 = distinct !DIAssignID()
!1297 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !1295)
!1298 = !{!1265, !1266, i64 6}
!1299 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !1295)
!1300 = !{!1265, !1131, i64 9}
!1301 = !DILocalVariable(name: "key", arg: 1, scope: !1302, file: !56, line: 1715, type: !745)
!1302 = distinct !DISubprogram(name: "__lb4_lookup_service", scope: !56, file: !56, line: 1715, type: !1303, scopeLine: 1716, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1305)
!1303 = !DISubroutineType(types: !1304)
!1304 = !{!1209, !745}
!1305 = !{!1301}
!1306 = !DILocation(line: 0, scope: !1302, inlinedAt: !1307)
!1307 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !1295)
!1308 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1307)
!1309 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !1295)
!1310 = distinct !DILexicalBlock(scope: !1285, file: !56, line: 1755, column: 6)
!1311 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !1295)
!1312 = !DILocalVariable(name: "svc", arg: 1, scope: !1313, file: !56, line: 505, type: !1209)
!1313 = distinct !DISubprogram(name: "lb4_svc_is_two_scopes", scope: !56, file: !56, line: 505, type: !1314, scopeLine: 506, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1316)
!1314 = !DISubroutineType(types: !1315)
!1315 = !{!88, !1209}
!1316 = !{!1312}
!1317 = !DILocation(line: 0, scope: !1313, inlinedAt: !1318)
!1318 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !1295)
!1319 = distinct !DILexicalBlock(scope: !1285, file: !56, line: 1775, column: 6)
!1320 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !1318)
!1321 = !{!1322, !1131, i64 9}
!1322 = !{!"lb4_service", !1131, i64 0, !1266, i64 4, !1266, i64 6, !1131, i64 8, !1131, i64 9, !1266, i64 10}
!1323 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !1318)
!1324 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !1318)
!1325 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !1295)
!1326 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !1295)
!1327 = !DILocation(line: 0, scope: !1302, inlinedAt: !1328)
!1328 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !1295)
!1329 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1328)
!1330 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !1226)
!1331 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 325, column: 6)
!1332 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !1226)
!1333 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !1226)
!1334 = !{!1322, !1266, i64 4}
!1335 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !1226)
!1336 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !1226)
!1337 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !1226)
!1338 = !{i64 2148404698}
!1339 = !DILocation(line: 0, scope: !1218, inlinedAt: !1226)
!1340 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !1226)
!1341 = !{!1342, !1342, i64 0}
!1342 = !{!"_Bool", !1131, i64 0}
!1343 = !{i8 0, i8 2}
!1344 = !{}
!1345 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !1226)
!1346 = !DILocalVariable(name: "svc", arg: 1, scope: !1347, file: !56, line: 2355, type: !1209)
!1347 = distinct !DISubprogram(name: "handle_nonroutable_endpoints_v4", scope: !56, file: !56, line: 2355, type: !1348, scopeLine: 2356, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1350)
!1348 = !DISubroutineType(types: !1349)
!1349 = !{!305, !1209}
!1350 = !{!1346}
!1351 = !DILocation(line: 0, scope: !1347, inlinedAt: !1352)
!1352 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !1226)
!1353 = distinct !DILexicalBlock(scope: !1220, file: !104, line: 333, column: 7)
!1354 = !DILocalVariable(name: "svc", arg: 1, scope: !1355, file: !56, line: 612, type: !1209)
!1355 = distinct !DISubprogram(name: "lb4_svc_is_external", scope: !56, file: !56, line: 612, type: !1314, scopeLine: 613, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1356)
!1356 = !{!1354}
!1357 = !DILocation(line: 0, scope: !1355, inlinedAt: !1358)
!1358 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !1352)
!1359 = distinct !DILexicalBlock(scope: !1347, file: !56, line: 2358, column: 6)
!1360 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !1358)
!1361 = !{!1322, !1131, i64 8}
!1362 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !1358)
!1363 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !1358)
!1364 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !1352)
!1365 = !DILocalVariable(name: "svc", arg: 1, scope: !1366, file: !56, line: 624, type: !1209)
!1366 = distinct !DISubprogram(name: "lb4_svc_is_etp_local", scope: !56, file: !56, line: 624, type: !1314, scopeLine: 625, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1367)
!1367 = !{!1365}
!1368 = !DILocation(line: 0, scope: !1366, inlinedAt: !1369)
!1369 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !1352)
!1370 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !1369)
!1371 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !1369)
!1372 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !1352)
!1373 = !DILocation(line: 0, scope: !1355, inlinedAt: !1374)
!1374 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !1352)
!1375 = !DILocalVariable(name: "svc", arg: 1, scope: !1376, file: !56, line: 636, type: !1209)
!1376 = distinct !DISubprogram(name: "lb4_svc_is_itp_local", scope: !56, file: !56, line: 636, type: !1314, scopeLine: 637, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1377)
!1377 = !{!1375}
!1378 = !DILocation(line: 0, scope: !1376, inlinedAt: !1379)
!1379 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !1352)
!1380 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !1379)
!1381 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !1379)
!1382 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !1379)
!1383 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !1352)
!1384 = !DILocation(line: 0, scope: !1220, inlinedAt: !1226)
!1385 = !DILocalVariable(name: "svc", arg: 1, scope: !1386, file: !56, line: 568, type: !1209)
!1386 = distinct !DISubprogram(name: "lb4_svc_is_l7_punt_proxy", scope: !56, file: !56, line: 568, type: !1314, scopeLine: 569, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1387)
!1387 = !{!1385}
!1388 = !DILocation(line: 0, scope: !1386, inlinedAt: !1389)
!1389 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !1226)
!1390 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 345, column: 6)
!1391 = !DILocalVariable(name: "svc", arg: 1, scope: !1392, file: !56, line: 469, type: !1209)
!1392 = distinct !DISubprogram(name: "lb4_svc_is_hostport", scope: !56, file: !56, line: 469, type: !1314, scopeLine: 470, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1393)
!1393 = !{!1391}
!1394 = !DILocation(line: 0, scope: !1392, inlinedAt: !1395)
!1395 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !1389)
!1396 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !1395)
!1397 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !1395)
!1398 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !1395)
!1399 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !1389)
!1400 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !1389)
!1401 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !1389)
!1402 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !1226)
!1403 = !DILocalVariable(name: "svc", arg: 1, scope: !1404, file: !104, line: 188, type: !1209)
!1404 = distinct !DISubprogram(name: "sock4_skip_xlate", scope: !104, file: !104, line: 188, type: !1405, scopeLine: 189, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1407)
!1405 = !DISubroutineType(types: !1406)
!1406 = !{!88, !1209, !153}
!1407 = !{!1403, !1408, !1409}
!1408 = !DILocalVariable(name: "address", arg: 2, scope: !1404, file: !104, line: 188, type: !153)
!1409 = !DILocalVariable(name: "info", scope: !1410, file: !104, line: 194, type: !1412)
!1410 = distinct !DILexicalBlock(scope: !1411, file: !104, line: 193, column: 62)
!1411 = distinct !DILexicalBlock(scope: !1404, file: !104, line: 192, column: 6)
!1412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1413, size: 64)
!1413 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !482)
!1414 = !DILocation(line: 0, scope: !1404, inlinedAt: !1415)
!1415 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !1226)
!1416 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 354, column: 6)
!1417 = !DILocalVariable(name: "svc", arg: 1, scope: !1418, file: !56, line: 457, type: !1209)
!1418 = distinct !DISubprogram(name: "lb4_svc_is_external_ip", scope: !56, file: !56, line: 457, type: !1314, scopeLine: 458, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1419)
!1419 = !{!1417}
!1420 = !DILocation(line: 0, scope: !1418, inlinedAt: !1421)
!1421 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !1415)
!1422 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !1421)
!1423 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !1421)
!1424 = !DILocation(line: 0, scope: !1392, inlinedAt: !1425)
!1425 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !1415)
!1426 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !1415)
!1427 = !DILocalVariable(name: "key", scope: !1428, file: !413, line: 161, type: !463)
!1428 = distinct !DISubprogram(name: "ipcache_lookup4", scope: !413, file: !413, line: 159, type: !1429, scopeLine: 160, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1431)
!1429 = !DISubroutineType(types: !1430)
!1430 = !{!1412, !1013, !153, !82, !82}
!1431 = !{!1432, !1433, !1434, !1435, !1427}
!1432 = !DILocalVariable(name: "map", arg: 1, scope: !1428, file: !413, line: 159, type: !1013)
!1433 = !DILocalVariable(name: "addr", arg: 2, scope: !1428, file: !413, line: 159, type: !153)
!1434 = !DILocalVariable(name: "prefix", arg: 3, scope: !1428, file: !413, line: 159, type: !82)
!1435 = !DILocalVariable(name: "cluster_id", arg: 4, scope: !1428, file: !413, line: 159, type: !82)
!1436 = !DILocation(line: 0, scope: !1428, inlinedAt: !1437)
!1437 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !1415)
!1438 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !1437)
!1439 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !1437)
!1440 = distinct !DIAssignID()
!1441 = distinct !DIAssignID()
!1442 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !1437)
!1443 = !{i64 0, i64 4, !1129, i64 4, i64 0, !1444}
!1444 = !{!1131, !1131, i64 0}
!1445 = distinct !DIAssignID()
!1446 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !1437)
!1447 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !1437)
!1448 = !{!1449, !1131, i64 7}
!1449 = !{!"ipcache_key", !1450, i64 0, !1266, i64 4, !1131, i64 6, !1131, i64 7, !1131, i64 8}
!1450 = !{!"bpf_lpm_trie_key", !1130, i64 0, !1131, i64 4}
!1451 = distinct !DIAssignID()
!1452 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !1437)
!1453 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !1437)
!1454 = distinct !DIAssignID()
!1455 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !1437)
!1456 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !1437)
!1457 = !{!1449, !1266, i64 4}
!1458 = distinct !DIAssignID()
!1459 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !1437)
!1460 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !1437)
!1461 = !DILocation(line: 0, scope: !1410, inlinedAt: !1415)
!1462 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !1415)
!1463 = distinct !DILexicalBlock(scope: !1410, file: !104, line: 197, column: 7)
!1464 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !1415)
!1465 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !1415)
!1466 = !{!1467, !1130, i64 0}
!1467 = !{!"remote_endpoint_info", !1130, i64 0, !1131, i64 4, !1266, i64 20, !1131, i64 22, !1131, i64 23, !1131, i64 23, !1131, i64 23, !1131, i64 23, !1131, i64 23}
!1468 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !1415)
!1469 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !1415)
!1470 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !1226)
!1471 = !{i64 2148406123}
!1472 = !DILocation(line: 0, scope: !1223, inlinedAt: !1226)
!1473 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !1226)
!1474 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !1226)
!1475 = !DILocalVariable(name: "svc", arg: 1, scope: !1476, file: !56, line: 546, type: !1209)
!1476 = distinct !DISubprogram(name: "lb4_svc_is_localredirect", scope: !56, file: !56, line: 546, type: !1314, scopeLine: 547, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1477)
!1477 = !{!1475}
!1478 = !DILocation(line: 0, scope: !1476, inlinedAt: !1479)
!1479 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !1226)
!1480 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !1479)
!1481 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !1479)
!1482 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !1479)
!1483 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !1226)
!1484 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !1226)
!1485 = !DILocalVariable(name: "key", scope: !1486, file: !905, line: 77, type: !933)
!1486 = distinct !DISubprogram(name: "lrp_v4_skip_xlate_from_ctx_to_svc", scope: !905, file: !905, line: 75, type: !1487, scopeLine: 76, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1489)
!1487 = !DISubroutineType(types: !1488)
!1488 = !{!88, !640, !153, !92}
!1489 = !{!1490, !1491, !1492, !1485, !1493}
!1490 = !DILocalVariable(name: "cookie", arg: 1, scope: !1486, file: !905, line: 75, type: !640)
!1491 = !DILocalVariable(name: "address", arg: 2, scope: !1486, file: !905, line: 75, type: !153)
!1492 = !DILocalVariable(name: "port", arg: 3, scope: !1486, file: !905, line: 75, type: !92)
!1493 = !DILocalVariable(name: "val", scope: !1486, file: !905, line: 78, type: !93)
!1494 = !DILocation(line: 0, scope: !1486, inlinedAt: !1495)
!1495 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !1226)
!1496 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !1495)
!1497 = !DILocalVariable(name: "d", arg: 1, scope: !1498, file: !1499, line: 152, type: !91)
!1498 = distinct !DISubprogram(name: "memset", scope: !1499, file: !1499, line: 152, type: !1500, scopeLine: 154, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1502)
!1499 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/builtins.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "b637b2eb683f238f586aafe0a119b3ec")
!1500 = !DISubroutineType(types: !1501)
!1501 = !{null, !91, !305, !95}
!1502 = !{!1497, !1503, !1504}
!1503 = !DILocalVariable(name: "c", arg: 2, scope: !1498, file: !1499, line: 152, type: !305)
!1504 = !DILocalVariable(name: "len", arg: 3, scope: !1498, file: !1499, line: 153, type: !95)
!1505 = !DILocation(line: 0, scope: !1498, inlinedAt: !1506)
!1506 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !1495)
!1507 = !DILocalVariable(name: "len", arg: 2, scope: !1508, file: !1499, line: 44, type: !95)
!1508 = distinct !DISubprogram(name: "__bpf_memzero", scope: !1499, file: !1499, line: 44, type: !1509, scopeLine: 45, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1511)
!1509 = !DISubroutineType(types: !1510)
!1510 = !{null, !91, !95}
!1511 = !{!1512, !1507, !1513, !1515, !1516, !1517, !1518, !1519, !1520, !1521, !1522, !1523, !1524, !1525, !1526, !1527, !1528}
!1512 = !DILocalVariable(name: "d", arg: 1, scope: !1508, file: !1499, line: 44, type: !91)
!1513 = !DILabel(scope: !1514, name: "jmp_120", file: !1499, line: 58)
!1514 = distinct !DILexicalBlock(scope: !1508, file: !1499, line: 56, column: 15)
!1515 = !DILabel(scope: !1514, name: "jmp_112", file: !1499, line: 59)
!1516 = !DILabel(scope: !1514, name: "jmp_104", file: !1499, line: 60)
!1517 = !DILabel(scope: !1514, name: "jmp_96", file: !1499, line: 61)
!1518 = !DILabel(scope: !1514, name: "jmp_88", file: !1499, line: 62)
!1519 = !DILabel(scope: !1514, name: "jmp_80", file: !1499, line: 63)
!1520 = !DILabel(scope: !1514, name: "jmp_72", file: !1499, line: 64)
!1521 = !DILabel(scope: !1514, name: "jmp_64", file: !1499, line: 65)
!1522 = !DILabel(scope: !1514, name: "jmp_56", file: !1499, line: 66)
!1523 = !DILabel(scope: !1514, name: "jmp_48", file: !1499, line: 67)
!1524 = !DILabel(scope: !1514, name: "jmp_40", file: !1499, line: 68)
!1525 = !DILabel(scope: !1514, name: "jmp_32", file: !1499, line: 69)
!1526 = !DILabel(scope: !1514, name: "jmp_24", file: !1499, line: 70)
!1527 = !DILabel(scope: !1514, name: "jmp_16", file: !1499, line: 71)
!1528 = !DILabel(scope: !1514, name: "jmp_8", file: !1499, line: 72)
!1529 = !DILocation(line: 0, scope: !1508, inlinedAt: !1530)
!1530 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !1506)
!1531 = distinct !DILexicalBlock(scope: !1498, file: !1499, line: 155, column: 6)
!1532 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !1530)
!1533 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !1530)
!1534 = !{!1535, !1535, i64 0}
!1535 = !{!"long long", !1131, i64 0}
!1536 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !1530)
!1537 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !1495)
!1538 = !{!1539, !1535, i64 0}
!1539 = !{!"skip_lb4_key", !1535, i64 0, !1130, i64 8, !1266, i64 12, !1266, i64 14}
!1540 = distinct !DIAssignID()
!1541 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !1495)
!1542 = !{!1539, !1130, i64 8}
!1543 = distinct !DIAssignID()
!1544 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !1495)
!1545 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !1495)
!1546 = !{!1539, !1266, i64 12}
!1547 = distinct !DIAssignID()
!1548 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !1495)
!1549 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !1495)
!1550 = distinct !DILexicalBlock(scope: !1486, file: !905, line: 85, column: 6)
!1551 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !1495)
!1552 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !1226)
!1553 = !DILocalVariable(name: "svc", arg: 1, scope: !1554, file: !56, line: 517, type: !1209)
!1554 = distinct !DISubprogram(name: "lb4_svc_is_affinity", scope: !56, file: !56, line: 517, type: !1314, scopeLine: 518, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1555)
!1555 = !{!1553}
!1556 = !DILocation(line: 0, scope: !1554, inlinedAt: !1557)
!1557 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !1226)
!1558 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 392, column: 6)
!1559 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !1557)
!1560 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !1557)
!1561 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !1557)
!1562 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !1226)
!1563 = !DILocalVariable(name: "svc", arg: 1, scope: !1564, file: !56, line: 2109, type: !1209)
!1564 = distinct !DISubprogram(name: "lb4_affinity_backend_id_by_netns", scope: !56, file: !56, line: 2109, type: !1565, scopeLine: 2111, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1568)
!1565 = !DISubroutineType(types: !1566)
!1566 = !{!82, !1209, !1567}
!1567 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !802, size: 64)
!1568 = !{!1563, !1569}
!1569 = !DILocalVariable(name: "id", arg: 2, scope: !1564, file: !56, line: 2110, type: !1567)
!1570 = !DILocation(line: 0, scope: !1564, inlinedAt: !1571)
!1571 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !1226)
!1572 = distinct !DILexicalBlock(scope: !1558, file: !104, line: 392, column: 32)
!1573 = !DILocalVariable(name: "key", scope: !1574, file: !56, line: 2037, type: !799)
!1574 = distinct !DISubprogram(name: "__lb4_affinity_backend_id", scope: !56, file: !56, line: 2034, type: !1575, scopeLine: 2036, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1579)
!1575 = !DISubroutineType(types: !1576)
!1576 = !{!82, !1209, !88, !1577}
!1577 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1578, size: 64)
!1578 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !802)
!1579 = !{!1580, !1581, !1582, !1573, !1583, !1584, !1587, !1588, !1591}
!1580 = !DILocalVariable(name: "svc", arg: 1, scope: !1574, file: !56, line: 2034, type: !1209)
!1581 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !1574, file: !56, line: 2034, type: !88)
!1582 = !DILocalVariable(name: "id", arg: 3, scope: !1574, file: !56, line: 2035, type: !1577)
!1583 = !DILocalVariable(name: "val", scope: !1574, file: !56, line: 2042, type: !647)
!1584 = !DILocalVariable(name: "now", scope: !1585, file: !56, line: 2046, type: !82)
!1585 = distinct !DILexicalBlock(scope: !1586, file: !56, line: 2045, column: 19)
!1586 = distinct !DILexicalBlock(scope: !1574, file: !56, line: 2045, column: 6)
!1587 = !DILocalVariable(name: "match", scope: !1585, file: !56, line: 2047, type: !872)
!1588 = !DILocalVariable(name: "__val", scope: !1589, file: !56, line: 2057, type: !95)
!1589 = distinct !DILexicalBlock(scope: !1590, file: !56, line: 2057, column: 7)
!1590 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2057, column: 7)
!1591 = !DILocalVariable(name: "__val", scope: !1592, file: !56, line: 2068, type: !95)
!1592 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2068, column: 3)
!1593 = !DILocation(line: 0, scope: !1574, inlinedAt: !1594)
!1594 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !1571)
!1595 = !DILocation(line: 0, scope: !1585, inlinedAt: !1594)
!1596 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !1594)
!1597 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !1594)
!1598 = distinct !DIAssignID()
!1599 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !1594)
!1600 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !1594)
!1601 = !{!1322, !1266, i64 6}
!1602 = !{!1603, !1266, i64 8}
!1603 = !{!"lb4_affinity_key", !1131, i64 0, !1266, i64 8, !1131, i64 10, !1131, i64 10, !1131, i64 11, !1130, i64 12}
!1604 = distinct !DIAssignID()
!1605 = distinct !DIAssignID()
!1606 = distinct !DIAssignID()
!1607 = !{!1603, !1131, i64 11}
!1608 = distinct !DIAssignID()
!1609 = !{!1603, !1130, i64 12}
!1610 = distinct !DIAssignID()
!1611 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !1594)
!1612 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !1594)
!1613 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !1594)
!1614 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !1594)
!1615 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !1226)
!1616 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !1624)
!1617 = distinct !DILexicalBlock(scope: !1618, file: !290, line: 26, column: 6)
!1618 = distinct !DILexicalBlock(scope: !1619, file: !290, line: 26, column: 6)
!1619 = distinct !DISubprogram(name: "bpf_mono_now", scope: !290, file: !290, line: 24, type: !1620, scopeLine: 25, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1622)
!1620 = !DISubroutineType(types: !1621)
!1621 = !{!95}
!1622 = !{!1623}
!1623 = !DILocalVariable(name: "out", scope: !1617, file: !290, line: 26, type: !91)
!1624 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !1594)
!1625 = !{i64 2148213198}
!1626 = !DILocation(line: 0, scope: !1617, inlinedAt: !1624)
!1627 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !1624)
!1628 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !1624)
!1629 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !1624)
!1630 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !1624)
!1631 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !1624)
!1632 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !1634)
!1633 = distinct !DISubprogram(name: "bpf_ktime_get_sec", scope: !290, file: !290, line: 17, type: !1620, scopeLine: 18, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1634 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !1624)
!1635 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !1634)
!1636 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !1624)
!1637 = !DILocation(line: 0, scope: !1619, inlinedAt: !1624)
!1638 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !1594)
!1639 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !1594)
!1640 = !{!1641, !1130, i64 8}
!1641 = !{!"lb_affinity_val", !1535, i64 0, !1130, i64 8, !1130, i64 12}
!1642 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !1594)
!1643 = !{!1644, !1130, i64 0}
!1644 = !{!"lb_affinity_match", !1130, i64 0, !1266, i64 4, !1266, i64 6}
!1645 = distinct !DIAssignID()
!1646 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !1594)
!1647 = !{!1644, !1266, i64 4}
!1648 = distinct !DIAssignID()
!1649 = !{!1644, !1266, i64 6}
!1650 = distinct !DIAssignID()
!1651 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !1594)
!1652 = !DILocation(line: 0, scope: !1589, inlinedAt: !1594)
!1653 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !1656)
!1654 = distinct !DISubprogram(name: "bpf_barrier", scope: !1655, file: !1655, line: 83, type: !1120, scopeLine: 84, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!1655 = !DIFile(filename: "vendor/repos/cilium/bpf/include/bpf/ctx/../compiler.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "223438cf74958b7bda161886abcea0ce")
!1656 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !1594)
!1657 = !{i64 2147845021}
!1658 = !DILocalVariable(name: "svc", arg: 1, scope: !1659, file: !56, line: 2028, type: !1209)
!1659 = distinct !DISubprogram(name: "lb4_affinity_timeout", scope: !56, file: !56, line: 2028, type: !1660, scopeLine: 2029, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1662)
!1660 = !DISubroutineType(types: !1661)
!1661 = !{!82, !1209}
!1662 = !{!1658}
!1663 = !DILocation(line: 0, scope: !1659, inlinedAt: !1664)
!1664 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !1594)
!1665 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !1664)
!1666 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !1664)
!1667 = !DILocalVariable(name: "s", arg: 1, scope: !1668, file: !290, line: 31, type: !82)
!1668 = distinct !DISubprogram(name: "bpf_sec_to_mono", scope: !290, file: !290, line: 31, type: !1669, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1671)
!1669 = !DISubroutineType(types: !1670)
!1670 = !{!82, !82}
!1671 = !{!1667, !1672, !1675}
!1672 = !DILocalVariable(name: "out", scope: !1673, file: !290, line: 33, type: !91)
!1673 = distinct !DILexicalBlock(scope: !1674, file: !290, line: 33, column: 6)
!1674 = distinct !DILexicalBlock(scope: !1668, file: !290, line: 33, column: 6)
!1675 = !DILocalVariable(name: "out", scope: !1676, file: !290, line: 34, type: !91)
!1676 = distinct !DILexicalBlock(scope: !1674, file: !290, line: 34, column: 22)
!1677 = !DILocation(line: 0, scope: !1668, inlinedAt: !1678)
!1678 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !1594)
!1679 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !1678)
!1680 = !{i64 2148214126}
!1681 = !DILocation(line: 0, scope: !1673, inlinedAt: !1678)
!1682 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !1678)
!1683 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !1678)
!1684 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !1678)
!1685 = !{i64 2148219075}
!1686 = !DILocation(line: 0, scope: !1676, inlinedAt: !1678)
!1687 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !1678)
!1688 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !1678)
!1689 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !1678)
!1690 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !1678)
!1691 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !1594)
!1692 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !1594)
!1693 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !1594)
!1694 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !1594)
!1695 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !1594)
!1696 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !1594)
!1697 = distinct !DILexicalBlock(scope: !1585, file: !56, line: 2063, column: 7)
!1698 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !1594)
!1699 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !1594)
!1700 = !DILocation(line: 0, scope: !1592, inlinedAt: !1594)
!1701 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !1594)
!1702 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !1703)
!1703 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !1594)
!1704 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !1594)
!1705 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !1226)
!1706 = distinct !DILexicalBlock(scope: !1572, file: !104, line: 403, column: 7)
!1707 = !DILocalVariable(name: "backend_id", arg: 1, scope: !1708, file: !56, line: 1847, type: !82)
!1708 = distinct !DISubprogram(name: "__lb4_lookup_backend", scope: !56, file: !56, line: 1847, type: !1709, scopeLine: 1848, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1711)
!1709 = !DISubroutineType(types: !1710)
!1710 = !{!1206, !82}
!1711 = !{!1707}
!1712 = !DILocation(line: 0, scope: !1708, inlinedAt: !1713)
!1713 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !1226)
!1714 = distinct !DILexicalBlock(scope: !1706, file: !104, line: 403, column: 24)
!1715 = distinct !DIAssignID()
!1716 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !1713)
!1717 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !1713)
!1718 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !1226)
!1719 = distinct !DILexicalBlock(scope: !1714, file: !104, line: 405, column: 8)
!1720 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !1226)
!1721 = !{i64 2148406328}
!1722 = !DILocation(line: 0, scope: !1714, inlinedAt: !1226)
!1723 = !DILocalVariable(name: "ctx", arg: 1, scope: !1724, file: !104, line: 123, type: !1136)
!1724 = distinct !DISubprogram(name: "sock_select_slot", scope: !104, file: !104, line: 123, type: !1725, scopeLine: 124, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1727)
!1725 = !DISubroutineType(types: !1726)
!1726 = !{!95, !1136}
!1727 = !{!1723}
!1728 = !DILocation(line: 0, scope: !1724, inlinedAt: !1729)
!1729 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !1226)
!1730 = distinct !DILexicalBlock(scope: !1731, file: !104, line: 417, column: 23)
!1731 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 417, column: 6)
!1732 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !1729)
!1733 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !1729)
!1734 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !1729)
!1735 = !DILocalVariable(name: "ctx", arg: 1, scope: !1736, file: !949, line: 10, type: !1136)
!1736 = distinct !DISubprogram(name: "sock_local_cookie", scope: !949, file: !949, line: 10, type: !1737, scopeLine: 11, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1739)
!1737 = !DISubroutineType(types: !1738)
!1738 = !{!684, !1136}
!1739 = !{!1735}
!1740 = !DILocation(line: 0, scope: !1736, inlinedAt: !1741)
!1741 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !1729)
!1742 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !1741)
!1743 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !1226)
!1744 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !1226)
!1745 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !1226)
!1746 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !1226)
!1747 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !1226)
!1748 = distinct !DIAssignID()
!1749 = !DILocalVariable(name: "key", arg: 1, scope: !1750, file: !56, line: 1865, type: !745)
!1750 = distinct !DISubprogram(name: "__lb4_lookup_backend_slot", scope: !56, file: !56, line: 1865, type: !1303, scopeLine: 1866, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1751)
!1751 = !{!1749}
!1752 = !DILocation(line: 0, scope: !1750, inlinedAt: !1753)
!1753 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !1226)
!1754 = !DILocation(line: 0, scope: !1302, inlinedAt: !1755)
!1755 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !1753)
!1756 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !1755)
!1757 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !1226)
!1758 = distinct !DILexicalBlock(scope: !1730, file: !104, line: 422, column: 7)
!1759 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !1226)
!1760 = !DILocalVariable(name: "new_entry", scope: !1761, file: !299, line: 50, type: !323)
!1761 = distinct !DISubprogram(name: "_update_metrics", scope: !299, file: !299, line: 47, type: !1762, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1764)
!1762 = !DISubroutineType(types: !1763)
!1763 = !{null, !95, !84, !84, !89, !84}
!1764 = !{!1765, !1766, !1767, !1768, !1769, !1770, !1760, !1771}
!1765 = !DILocalVariable(name: "bytes", arg: 1, scope: !1761, file: !299, line: 47, type: !95)
!1766 = !DILocalVariable(name: "direction", arg: 2, scope: !1761, file: !299, line: 47, type: !84)
!1767 = !DILocalVariable(name: "reason", arg: 3, scope: !1761, file: !299, line: 48, type: !84)
!1768 = !DILocalVariable(name: "line", arg: 4, scope: !1761, file: !299, line: 48, type: !89)
!1769 = !DILocalVariable(name: "file", arg: 5, scope: !1761, file: !299, line: 48, type: !84)
!1770 = !DILocalVariable(name: "entry", scope: !1761, file: !299, line: 50, type: !322)
!1771 = !DILocalVariable(name: "key", scope: !1761, file: !299, line: 51, type: !310)
!1772 = !DILocation(line: 0, scope: !1761, inlinedAt: !1773)
!1773 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !1226)
!1774 = distinct !DILexicalBlock(scope: !1758, file: !104, line: 422, column: 22)
!1775 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !1773)
!1776 = distinct !DIAssignID()
!1777 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !1773)
!1778 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !1773)
!1779 = distinct !DIAssignID()
!1780 = distinct !DIAssignID()
!1781 = distinct !DIAssignID()
!1782 = distinct !DIAssignID()
!1783 = distinct !DIAssignID()
!1784 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !1773)
!1785 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !1773)
!1786 = distinct !DILexicalBlock(scope: !1761, file: !299, line: 59, column: 6)
!1787 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !1773)
!1788 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !1773)
!1789 = distinct !DILexicalBlock(scope: !1786, file: !299, line: 59, column: 13)
!1790 = !{!1791, !1535, i64 0}
!1791 = !{!"metrics_value", !1535, i64 0, !1535, i64 8}
!1792 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !1773)
!1793 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !1773)
!1794 = distinct !DILexicalBlock(scope: !1786, file: !299, line: 62, column: 9)
!1795 = distinct !DIAssignID()
!1796 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !1773)
!1797 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !1773)
!1798 = !{!1791, !1535, i64 8}
!1799 = distinct !DIAssignID()
!1800 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !1773)
!1801 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !1773)
!1802 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !1226)
!1803 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !1226)
!1804 = !DILocation(line: 0, scope: !1708, inlinedAt: !1805)
!1805 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !1226)
!1806 = distinct !DIAssignID()
!1807 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !1805)
!1808 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !1805)
!1809 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !1226)
!1810 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 431, column: 6)
!1811 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !1226)
!1812 = !DILocation(line: 0, scope: !1761, inlinedAt: !1813)
!1813 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !1226)
!1814 = distinct !DILexicalBlock(scope: !1810, file: !104, line: 431, column: 16)
!1815 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !1813)
!1816 = distinct !DIAssignID()
!1817 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !1813)
!1818 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !1813)
!1819 = distinct !DIAssignID()
!1820 = distinct !DIAssignID()
!1821 = distinct !DIAssignID()
!1822 = distinct !DIAssignID()
!1823 = distinct !DIAssignID()
!1824 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !1813)
!1825 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !1813)
!1826 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !1813)
!1827 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !1813)
!1828 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !1813)
!1829 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !1813)
!1830 = distinct !DIAssignID()
!1831 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !1813)
!1832 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !1813)
!1833 = distinct !DIAssignID()
!1834 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !1813)
!1835 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !1813)
!1836 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !1226)
!1837 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !1226)
!1838 = !{i64 2148406676}
!1839 = !DILocation(line: 0, scope: !1554, inlinedAt: !1840)
!1840 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !1226)
!1841 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 437, column: 6)
!1842 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !1840)
!1843 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !1840)
!1844 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !1840)
!1845 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !1226)
!1846 = !DILocalVariable(name: "svc", arg: 1, scope: !1847, file: !56, line: 2116, type: !1209)
!1847 = distinct !DISubprogram(name: "lb4_update_affinity_by_netns", scope: !56, file: !56, line: 2116, type: !1848, scopeLine: 2119, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1850)
!1848 = !DISubroutineType(types: !1849)
!1849 = !{null, !1209, !1567, !82}
!1850 = !{!1846, !1851, !1852}
!1851 = !DILocalVariable(name: "id", arg: 2, scope: !1847, file: !56, line: 2117, type: !1567)
!1852 = !DILocalVariable(name: "backend_id", arg: 3, scope: !1847, file: !56, line: 2118, type: !82)
!1853 = !DILocation(line: 0, scope: !1847, inlinedAt: !1854)
!1854 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !1226)
!1855 = !DILocalVariable(name: "key", scope: !1856, file: !56, line: 2088, type: !799)
!1856 = distinct !DISubprogram(name: "__lb4_update_affinity", scope: !56, file: !56, line: 2083, type: !1857, scopeLine: 2086, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1859)
!1857 = !DISubroutineType(types: !1858)
!1858 = !{null, !1209, !88, !1577, !82}
!1859 = !{!1860, !1861, !1862, !1863, !1864, !1855, !1865}
!1860 = !DILocalVariable(name: "svc", arg: 1, scope: !1856, file: !56, line: 2083, type: !1209)
!1861 = !DILocalVariable(name: "netns_cookie", arg: 2, scope: !1856, file: !56, line: 2083, type: !88)
!1862 = !DILocalVariable(name: "id", arg: 3, scope: !1856, file: !56, line: 2084, type: !1577)
!1863 = !DILocalVariable(name: "backend_id", arg: 4, scope: !1856, file: !56, line: 2085, type: !82)
!1864 = !DILocalVariable(name: "now", scope: !1856, file: !56, line: 2087, type: !82)
!1865 = !DILocalVariable(name: "val", scope: !1856, file: !56, line: 2093, type: !648)
!1866 = !DILocation(line: 0, scope: !1856, inlinedAt: !1867)
!1867 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !1854)
!1868 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !1869)
!1869 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !1867)
!1870 = !DILocation(line: 0, scope: !1617, inlinedAt: !1869)
!1871 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !1869)
!1872 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !1869)
!1873 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !1869)
!1874 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !1869)
!1875 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !1869)
!1876 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !1877)
!1877 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !1869)
!1878 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !1877)
!1879 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !1869)
!1880 = !DILocation(line: 0, scope: !1619, inlinedAt: !1869)
!1881 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !1867)
!1882 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !1867)
!1883 = distinct !DIAssignID()
!1884 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !1867)
!1885 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !1867)
!1886 = distinct !DIAssignID()
!1887 = distinct !DIAssignID()
!1888 = distinct !DIAssignID()
!1889 = distinct !DIAssignID()
!1890 = distinct !DIAssignID()
!1891 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !1867)
!1892 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !1867)
!1893 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !1867)
!1894 = !{!1641, !1535, i64 0}
!1895 = distinct !DIAssignID()
!1896 = distinct !DIAssignID()
!1897 = !{!1641, !1130, i64 12}
!1898 = distinct !DIAssignID()
!1899 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !1867)
!1900 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !1867)
!1901 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !1226)
!1902 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !1226)
!1903 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !1226)
!1904 = distinct !DILexicalBlock(scope: !1194, file: !104, line: 446, column: 6)
!1905 = !DILocalVariable(name: "val", scope: !1906, file: !104, line: 150, type: !963)
!1906 = distinct !DISubprogram(name: "sock4_update_revnat", scope: !104, file: !104, line: 145, type: !1907, scopeLine: 149, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1909)
!1907 = !DISubroutineType(types: !1908)
!1908 = !{!305, !1136, !1206, !153, !92, !89}
!1909 = !{!1910, !1911, !1912, !1913, !1914, !1905, !1915, !1916, !1917}
!1910 = !DILocalVariable(name: "ctx", arg: 1, scope: !1906, file: !104, line: 145, type: !1136)
!1911 = !DILocalVariable(name: "backend", arg: 2, scope: !1906, file: !104, line: 146, type: !1206)
!1912 = !DILocalVariable(name: "dst_ip", arg: 3, scope: !1906, file: !104, line: 147, type: !153)
!1913 = !DILocalVariable(name: "dst_port", arg: 4, scope: !1906, file: !104, line: 147, type: !92)
!1914 = !DILocalVariable(name: "rev_nat_id", arg: 5, scope: !1906, file: !104, line: 148, type: !89)
!1915 = !DILocalVariable(name: "tmp", scope: !1906, file: !104, line: 150, type: !962)
!1916 = !DILocalVariable(name: "key", scope: !1906, file: !104, line: 151, type: !955)
!1917 = !DILocalVariable(name: "ret", scope: !1906, file: !104, line: 152, type: !305)
!1918 = !DILocation(line: 0, scope: !1906, inlinedAt: !1919)
!1919 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !1226)
!1920 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !1919)
!1921 = distinct !DIAssignID()
!1922 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !1919)
!1923 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !1919)
!1924 = distinct !DIAssignID()
!1925 = distinct !DIAssignID()
!1926 = !DILocation(line: 0, scope: !1736, inlinedAt: !1927)
!1927 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !1919)
!1928 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !1927)
!1929 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !1919)
!1930 = !{!1931, !1535, i64 0}
!1931 = !{!"ipv4_revnat_tuple", !1535, i64 0, !1130, i64 8, !1266, i64 12, !1266, i64 14}
!1932 = distinct !DIAssignID()
!1933 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !1919)
!1934 = !{!1935, !1130, i64 0}
!1935 = !{!"lb4_backend", !1130, i64 0, !1266, i64 4, !1131, i64 6, !1131, i64 7, !1266, i64 8, !1131, i64 10, !1131, i64 11}
!1936 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !1919)
!1937 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !1919)
!1938 = !{!1931, !1130, i64 8}
!1939 = distinct !DIAssignID()
!1940 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !1919)
!1941 = !{!1935, !1266, i64 4}
!1942 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !1919)
!1943 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !1919)
!1944 = !{!1931, !1266, i64 12}
!1945 = distinct !DIAssignID()
!1946 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !1919)
!1947 = !{!1948, !1130, i64 0}
!1948 = !{!"ipv4_revnat_entry", !1130, i64 0, !1266, i64 4, !1266, i64 6}
!1949 = distinct !DIAssignID()
!1950 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !1919)
!1951 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !1919)
!1952 = !{!1948, !1266, i64 4}
!1953 = distinct !DIAssignID()
!1954 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !1919)
!1955 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !1919)
!1956 = !{!1948, !1266, i64 6}
!1957 = distinct !DIAssignID()
!1958 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !1919)
!1959 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !1919)
!1960 = distinct !DILexicalBlock(scope: !1906, file: !104, line: 167, column: 6)
!1961 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !1919)
!1962 = !DILocalVariable(name: "x", arg: 1, scope: !1963, file: !1499, line: 411, type: !1013)
!1963 = distinct !DISubprogram(name: "memcmp", scope: !1499, file: !1499, line: 411, type: !1964, scopeLine: 414, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1966)
!1964 = !DISubroutineType(types: !1965)
!1965 = !{!95, !1013, !1013, !95}
!1966 = !{!1962, !1967, !1968}
!1967 = !DILocalVariable(name: "y", arg: 2, scope: !1963, file: !1499, line: 412, type: !1013)
!1968 = !DILocalVariable(name: "len", arg: 3, scope: !1963, file: !1499, line: 413, type: !95)
!1969 = !DILocation(line: 0, scope: !1963, inlinedAt: !1970)
!1970 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !1919)
!1971 = !DILocalVariable(name: "len", arg: 3, scope: !1972, file: !1499, line: 299, type: !95)
!1972 = distinct !DISubprogram(name: "__bpf_memcmp", scope: !1499, file: !1499, line: 298, type: !1964, scopeLine: 300, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !1973)
!1973 = !{!1974, !1975, !1971, !1976, !1977, !1979, !1980, !1981, !1982, !1983, !1984, !1985, !1986, !1987, !1988, !1989, !1990, !1991, !1992}
!1974 = !DILocalVariable(name: "x", arg: 1, scope: !1972, file: !1499, line: 298, type: !1013)
!1975 = !DILocalVariable(name: "y", arg: 2, scope: !1972, file: !1499, line: 298, type: !1013)
!1976 = !DILocalVariable(name: "r", scope: !1972, file: !1499, line: 301, type: !95)
!1977 = !DILabel(scope: !1978, name: "jmp_120", file: !1499, line: 316)
!1978 = distinct !DILexicalBlock(scope: !1972, file: !1499, line: 314, column: 15)
!1979 = !DILabel(scope: !1978, name: "jmp_112", file: !1499, line: 317)
!1980 = !DILabel(scope: !1978, name: "jmp_104", file: !1499, line: 318)
!1981 = !DILabel(scope: !1978, name: "jmp_96", file: !1499, line: 319)
!1982 = !DILabel(scope: !1978, name: "jmp_88", file: !1499, line: 320)
!1983 = !DILabel(scope: !1978, name: "jmp_80", file: !1499, line: 321)
!1984 = !DILabel(scope: !1978, name: "jmp_72", file: !1499, line: 322)
!1985 = !DILabel(scope: !1978, name: "jmp_64", file: !1499, line: 323)
!1986 = !DILabel(scope: !1978, name: "jmp_56", file: !1499, line: 324)
!1987 = !DILabel(scope: !1978, name: "jmp_48", file: !1499, line: 325)
!1988 = !DILabel(scope: !1978, name: "jmp_40", file: !1499, line: 326)
!1989 = !DILabel(scope: !1978, name: "jmp_32", file: !1499, line: 327)
!1990 = !DILabel(scope: !1978, name: "jmp_24", file: !1499, line: 328)
!1991 = !DILabel(scope: !1978, name: "jmp_16", file: !1499, line: 329)
!1992 = !DILabel(scope: !1978, name: "jmp_8", file: !1499, line: 330)
!1993 = !DILocation(line: 0, scope: !1972, inlinedAt: !1994)
!1994 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !1970)
!1995 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !1994)
!1996 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !1994)
!1997 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !1919)
!1998 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !1919)
!1999 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !1919)
!2000 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !1226)
!2001 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !1919)
!2002 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !1226)
!2003 = !DILocation(line: 0, scope: !1761, inlinedAt: !2004)
!2004 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !1226)
!2005 = distinct !DILexicalBlock(scope: !1904, file: !104, line: 447, column: 30)
!2006 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2004)
!2007 = distinct !DIAssignID()
!2008 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2004)
!2009 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2004)
!2010 = distinct !DIAssignID()
!2011 = distinct !DIAssignID()
!2012 = distinct !DIAssignID()
!2013 = distinct !DIAssignID()
!2014 = distinct !DIAssignID()
!2015 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2004)
!2016 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2004)
!2017 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2004)
!2018 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2004)
!2019 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2004)
!2020 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2004)
!2021 = distinct !DIAssignID()
!2022 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2004)
!2023 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2004)
!2024 = distinct !DIAssignID()
!2025 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2004)
!2026 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2004)
!2027 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !1226)
!2028 = !DILocation(line: 469, column: 27, scope: !2029)
!2029 = distinct !DILexicalBlock(scope: !1133, file: !104, line: 469, column: 6)
!2030 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !1226)
!2031 = !DILocation(line: 452, column: 16, scope: !1194, inlinedAt: !1226)
!2032 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !1226)
!2033 = !DILocalVariable(name: "ctx", arg: 1, scope: !2034, file: !104, line: 68, type: !1136)
!2034 = distinct !DISubprogram(name: "ctx_set_port", scope: !104, file: !104, line: 68, type: !2035, scopeLine: 69, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2037)
!2035 = !DISubroutineType(types: !2036)
!2036 = !{null, !1136, !92}
!2037 = !{!2033, !2038}
!2038 = !DILocalVariable(name: "dport", arg: 2, scope: !2034, file: !104, line: 68, type: !92)
!2039 = !DILocation(line: 0, scope: !2034, inlinedAt: !2040)
!2040 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !1226)
!2041 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2040)
!2042 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2040)
!2043 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !1226)
!2044 = !DILocation(line: 471, column: 3, scope: !2045)
!2045 = distinct !DILexicalBlock(scope: !2029, file: !104, line: 469, column: 46)
!2046 = !DILocation(line: 475, column: 1, scope: !1133)
!2047 = distinct !DISubprogram(name: "cil_sock4_sendmsg", scope: !104, file: !104, line: 627, type: !1134, scopeLine: 628, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2048)
!2048 = !{!2049, !2050}
!2049 = !DILocalVariable(name: "ctx", arg: 1, scope: !2047, file: !104, line: 627, type: !1136)
!2050 = !DILocalVariable(name: "err", scope: !2047, file: !104, line: 629, type: !305)
!2051 = distinct !DIAssignID()
!2052 = distinct !DIAssignID()
!2053 = distinct !DIAssignID()
!2054 = distinct !DIAssignID()
!2055 = distinct !DIAssignID()
!2056 = distinct !DIAssignID()
!2057 = distinct !DIAssignID()
!2058 = distinct !DIAssignID()
!2059 = distinct !DIAssignID()
!2060 = distinct !DIAssignID()
!2061 = distinct !DIAssignID()
!2062 = distinct !DIAssignID()
!2063 = distinct !DIAssignID()
!2064 = distinct !DIAssignID()
!2065 = distinct !DIAssignID()
!2066 = distinct !DIAssignID()
!2067 = distinct !DIAssignID()
!2068 = distinct !DIAssignID()
!2069 = !DILocation(line: 0, scope: !2047)
!2070 = !DILocation(line: 0, scope: !1194, inlinedAt: !2071)
!2071 = distinct !DILocation(line: 631, column: 8, scope: !2047)
!2072 = !DILocation(line: 0, scope: !1228, inlinedAt: !2073)
!2073 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !2071)
!2074 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2073)
!2075 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2073)
!2076 = !DILocation(line: 0, scope: !1240, inlinedAt: !2077)
!2077 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !2071)
!2078 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2077)
!2079 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2077)
!2080 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2077)
!2081 = distinct !DIAssignID()
!2082 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2077)
!2083 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2077)
!2084 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2077)
!2085 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !2071)
!2086 = !DILocation(line: 301, column: 23, scope: !1194, inlinedAt: !2071)
!2087 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !2071)
!2088 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !2071)
!2089 = distinct !DIAssignID()
!2090 = distinct !DIAssignID()
!2091 = distinct !DIAssignID()
!2092 = distinct !DIAssignID()
!2093 = distinct !DIAssignID()
!2094 = distinct !DIAssignID()
!2095 = !DILocation(line: 0, scope: !1285, inlinedAt: !2096)
!2096 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !2071)
!2097 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2096)
!2098 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2096)
!2099 = !DILocation(line: 0, scope: !1302, inlinedAt: !2100)
!2100 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2096)
!2101 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2100)
!2102 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2096)
!2103 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2096)
!2104 = !DILocation(line: 0, scope: !1313, inlinedAt: !2105)
!2105 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2096)
!2106 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2105)
!2107 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2105)
!2108 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2105)
!2109 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2096)
!2110 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2096)
!2111 = !DILocation(line: 0, scope: !1302, inlinedAt: !2112)
!2112 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2096)
!2113 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2112)
!2114 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !2071)
!2115 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !2071)
!2116 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !2071)
!2117 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !2071)
!2118 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !2071)
!2119 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !2071)
!2120 = !DILocation(line: 0, scope: !1218, inlinedAt: !2071)
!2121 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !2071)
!2122 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !2071)
!2123 = !DILocation(line: 0, scope: !1347, inlinedAt: !2124)
!2124 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !2071)
!2125 = !DILocation(line: 0, scope: !1355, inlinedAt: !2126)
!2126 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !2124)
!2127 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !2126)
!2128 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !2126)
!2129 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !2126)
!2130 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !2124)
!2131 = !DILocation(line: 0, scope: !1366, inlinedAt: !2132)
!2132 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !2124)
!2133 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !2132)
!2134 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !2132)
!2135 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !2124)
!2136 = !DILocation(line: 0, scope: !1355, inlinedAt: !2137)
!2137 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !2124)
!2138 = !DILocation(line: 0, scope: !1376, inlinedAt: !2139)
!2139 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !2124)
!2140 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !2139)
!2141 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !2139)
!2142 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !2139)
!2143 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !2124)
!2144 = !DILocation(line: 0, scope: !1220, inlinedAt: !2071)
!2145 = !DILocation(line: 0, scope: !1386, inlinedAt: !2146)
!2146 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !2071)
!2147 = !DILocation(line: 0, scope: !1392, inlinedAt: !2148)
!2148 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !2146)
!2149 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !2148)
!2150 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !2148)
!2151 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !2148)
!2152 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !2146)
!2153 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !2146)
!2154 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !2146)
!2155 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !2071)
!2156 = !DILocation(line: 0, scope: !1404, inlinedAt: !2157)
!2157 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !2071)
!2158 = !DILocation(line: 0, scope: !1418, inlinedAt: !2159)
!2159 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !2157)
!2160 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !2159)
!2161 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !2159)
!2162 = !DILocation(line: 0, scope: !1392, inlinedAt: !2163)
!2163 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !2157)
!2164 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !2157)
!2165 = !DILocation(line: 0, scope: !1428, inlinedAt: !2166)
!2166 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !2157)
!2167 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !2166)
!2168 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !2166)
!2169 = distinct !DIAssignID()
!2170 = distinct !DIAssignID()
!2171 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !2166)
!2172 = distinct !DIAssignID()
!2173 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !2166)
!2174 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !2166)
!2175 = distinct !DIAssignID()
!2176 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !2166)
!2177 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !2166)
!2178 = distinct !DIAssignID()
!2179 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !2166)
!2180 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !2166)
!2181 = distinct !DIAssignID()
!2182 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !2166)
!2183 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !2166)
!2184 = !DILocation(line: 0, scope: !1410, inlinedAt: !2157)
!2185 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !2157)
!2186 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !2157)
!2187 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !2157)
!2188 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !2157)
!2189 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !2157)
!2190 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !2071)
!2191 = !DILocation(line: 0, scope: !1223, inlinedAt: !2071)
!2192 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !2071)
!2193 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !2071)
!2194 = !DILocation(line: 0, scope: !1476, inlinedAt: !2195)
!2195 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !2071)
!2196 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !2195)
!2197 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !2195)
!2198 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !2195)
!2199 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !2071)
!2200 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !2071)
!2201 = !DILocation(line: 0, scope: !1486, inlinedAt: !2202)
!2202 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !2071)
!2203 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !2202)
!2204 = !DILocation(line: 0, scope: !1498, inlinedAt: !2205)
!2205 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !2202)
!2206 = !DILocation(line: 0, scope: !1508, inlinedAt: !2207)
!2207 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !2205)
!2208 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !2207)
!2209 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !2207)
!2210 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !2207)
!2211 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !2202)
!2212 = distinct !DIAssignID()
!2213 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !2202)
!2214 = distinct !DIAssignID()
!2215 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !2202)
!2216 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !2202)
!2217 = distinct !DIAssignID()
!2218 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !2202)
!2219 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !2202)
!2220 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !2202)
!2221 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !2071)
!2222 = !DILocation(line: 0, scope: !1554, inlinedAt: !2223)
!2223 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !2071)
!2224 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !2223)
!2225 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !2223)
!2226 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !2223)
!2227 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !2071)
!2228 = !DILocation(line: 0, scope: !1564, inlinedAt: !2229)
!2229 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !2071)
!2230 = !DILocation(line: 0, scope: !1574, inlinedAt: !2231)
!2231 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !2229)
!2232 = !DILocation(line: 0, scope: !1585, inlinedAt: !2231)
!2233 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !2231)
!2234 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !2231)
!2235 = distinct !DIAssignID()
!2236 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !2231)
!2237 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !2231)
!2238 = distinct !DIAssignID()
!2239 = distinct !DIAssignID()
!2240 = distinct !DIAssignID()
!2241 = distinct !DIAssignID()
!2242 = distinct !DIAssignID()
!2243 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !2231)
!2244 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !2231)
!2245 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !2231)
!2246 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !2231)
!2247 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !2071)
!2248 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !2249)
!2249 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !2231)
!2250 = !DILocation(line: 0, scope: !1617, inlinedAt: !2249)
!2251 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !2249)
!2252 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !2249)
!2253 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !2249)
!2254 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !2249)
!2255 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !2249)
!2256 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !2257)
!2257 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !2249)
!2258 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !2257)
!2259 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !2249)
!2260 = !DILocation(line: 0, scope: !1619, inlinedAt: !2249)
!2261 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !2231)
!2262 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !2231)
!2263 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !2231)
!2264 = distinct !DIAssignID()
!2265 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !2231)
!2266 = distinct !DIAssignID()
!2267 = distinct !DIAssignID()
!2268 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2231)
!2269 = !DILocation(line: 0, scope: !1589, inlinedAt: !2231)
!2270 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2271)
!2271 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2231)
!2272 = !DILocation(line: 0, scope: !1659, inlinedAt: !2273)
!2273 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !2231)
!2274 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !2273)
!2275 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !2273)
!2276 = !DILocation(line: 0, scope: !1668, inlinedAt: !2277)
!2277 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2231)
!2278 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !2277)
!2279 = !DILocation(line: 0, scope: !1673, inlinedAt: !2277)
!2280 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !2277)
!2281 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !2277)
!2282 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !2277)
!2283 = !DILocation(line: 0, scope: !1676, inlinedAt: !2277)
!2284 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !2277)
!2285 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !2277)
!2286 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !2277)
!2287 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !2277)
!2288 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2231)
!2289 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !2231)
!2290 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !2231)
!2291 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !2231)
!2292 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !2231)
!2293 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !2231)
!2294 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !2231)
!2295 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !2231)
!2296 = !DILocation(line: 0, scope: !1592, inlinedAt: !2231)
!2297 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2231)
!2298 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2299)
!2299 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2231)
!2300 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !2231)
!2301 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !2071)
!2302 = !DILocation(line: 0, scope: !1708, inlinedAt: !2303)
!2303 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !2071)
!2304 = distinct !DIAssignID()
!2305 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !2303)
!2306 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !2303)
!2307 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !2071)
!2308 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !2071)
!2309 = !DILocation(line: 0, scope: !1714, inlinedAt: !2071)
!2310 = !DILocation(line: 0, scope: !1724, inlinedAt: !2311)
!2311 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !2071)
!2312 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !2311)
!2313 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !2311)
!2314 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !2311)
!2315 = !DILocation(line: 0, scope: !1736, inlinedAt: !2316)
!2316 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !2311)
!2317 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2316)
!2318 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !2071)
!2319 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !2071)
!2320 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !2071)
!2321 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !2071)
!2322 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !2071)
!2323 = distinct !DIAssignID()
!2324 = !DILocation(line: 0, scope: !1750, inlinedAt: !2325)
!2325 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !2071)
!2326 = !DILocation(line: 0, scope: !1302, inlinedAt: !2327)
!2327 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !2325)
!2328 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2327)
!2329 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !2071)
!2330 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !2071)
!2331 = !DILocation(line: 0, scope: !1761, inlinedAt: !2332)
!2332 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !2071)
!2333 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2332)
!2334 = distinct !DIAssignID()
!2335 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2332)
!2336 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2332)
!2337 = distinct !DIAssignID()
!2338 = distinct !DIAssignID()
!2339 = distinct !DIAssignID()
!2340 = distinct !DIAssignID()
!2341 = distinct !DIAssignID()
!2342 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2332)
!2343 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2332)
!2344 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2332)
!2345 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2332)
!2346 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2332)
!2347 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2332)
!2348 = distinct !DIAssignID()
!2349 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2332)
!2350 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2332)
!2351 = distinct !DIAssignID()
!2352 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2332)
!2353 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2332)
!2354 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !2071)
!2355 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !2071)
!2356 = !DILocation(line: 0, scope: !1708, inlinedAt: !2357)
!2357 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !2071)
!2358 = distinct !DIAssignID()
!2359 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !2357)
!2360 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !2357)
!2361 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !2071)
!2362 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !2071)
!2363 = !DILocation(line: 0, scope: !1761, inlinedAt: !2364)
!2364 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !2071)
!2365 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2364)
!2366 = distinct !DIAssignID()
!2367 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2364)
!2368 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2364)
!2369 = distinct !DIAssignID()
!2370 = distinct !DIAssignID()
!2371 = distinct !DIAssignID()
!2372 = distinct !DIAssignID()
!2373 = distinct !DIAssignID()
!2374 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2364)
!2375 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2364)
!2376 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2364)
!2377 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2364)
!2378 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2364)
!2379 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2364)
!2380 = distinct !DIAssignID()
!2381 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2364)
!2382 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2364)
!2383 = distinct !DIAssignID()
!2384 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2364)
!2385 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2364)
!2386 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !2071)
!2387 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !2071)
!2388 = !DILocation(line: 0, scope: !1554, inlinedAt: !2389)
!2389 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !2071)
!2390 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !2389)
!2391 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !2389)
!2392 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !2389)
!2393 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !2071)
!2394 = !DILocation(line: 0, scope: !1847, inlinedAt: !2395)
!2395 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2071)
!2396 = !DILocation(line: 0, scope: !1856, inlinedAt: !2397)
!2397 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !2395)
!2398 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !2399)
!2399 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !2397)
!2400 = !DILocation(line: 0, scope: !1617, inlinedAt: !2399)
!2401 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !2399)
!2402 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !2399)
!2403 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !2399)
!2404 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !2399)
!2405 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !2399)
!2406 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !2407)
!2407 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !2399)
!2408 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !2407)
!2409 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !2399)
!2410 = !DILocation(line: 0, scope: !1619, inlinedAt: !2399)
!2411 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !2397)
!2412 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !2397)
!2413 = distinct !DIAssignID()
!2414 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !2397)
!2415 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !2397)
!2416 = distinct !DIAssignID()
!2417 = distinct !DIAssignID()
!2418 = distinct !DIAssignID()
!2419 = distinct !DIAssignID()
!2420 = distinct !DIAssignID()
!2421 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !2397)
!2422 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !2397)
!2423 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !2397)
!2424 = distinct !DIAssignID()
!2425 = distinct !DIAssignID()
!2426 = distinct !DIAssignID()
!2427 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !2397)
!2428 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !2397)
!2429 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2071)
!2430 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !2071)
!2431 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !2071)
!2432 = !DILocation(line: 0, scope: !1906, inlinedAt: !2433)
!2433 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !2071)
!2434 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !2433)
!2435 = distinct !DIAssignID()
!2436 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !2433)
!2437 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !2433)
!2438 = distinct !DIAssignID()
!2439 = distinct !DIAssignID()
!2440 = !DILocation(line: 0, scope: !1736, inlinedAt: !2441)
!2441 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !2433)
!2442 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2441)
!2443 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !2433)
!2444 = distinct !DIAssignID()
!2445 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !2433)
!2446 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !2433)
!2447 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !2433)
!2448 = distinct !DIAssignID()
!2449 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !2433)
!2450 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !2433)
!2451 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !2433)
!2452 = distinct !DIAssignID()
!2453 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !2433)
!2454 = distinct !DIAssignID()
!2455 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !2433)
!2456 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !2433)
!2457 = distinct !DIAssignID()
!2458 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !2433)
!2459 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !2433)
!2460 = distinct !DIAssignID()
!2461 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !2433)
!2462 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !2433)
!2463 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !2433)
!2464 = !DILocation(line: 0, scope: !1963, inlinedAt: !2465)
!2465 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !2433)
!2466 = !DILocation(line: 0, scope: !1972, inlinedAt: !2467)
!2467 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !2465)
!2468 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !2467)
!2469 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !2467)
!2470 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !2433)
!2471 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !2433)
!2472 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !2433)
!2473 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !2071)
!2474 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !2433)
!2475 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !2071)
!2476 = !DILocation(line: 0, scope: !1761, inlinedAt: !2477)
!2477 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !2071)
!2478 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2477)
!2479 = distinct !DIAssignID()
!2480 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2477)
!2481 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2477)
!2482 = distinct !DIAssignID()
!2483 = distinct !DIAssignID()
!2484 = distinct !DIAssignID()
!2485 = distinct !DIAssignID()
!2486 = distinct !DIAssignID()
!2487 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2477)
!2488 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2477)
!2489 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2477)
!2490 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2477)
!2491 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2477)
!2492 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2477)
!2493 = distinct !DIAssignID()
!2494 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2477)
!2495 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2477)
!2496 = distinct !DIAssignID()
!2497 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2477)
!2498 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2477)
!2499 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !2071)
!2500 = !DILocation(line: 632, column: 27, scope: !2501)
!2501 = distinct !DILexicalBlock(scope: !2047, file: !104, line: 632, column: 6)
!2502 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !2071)
!2503 = !DILocation(line: 452, column: 16, scope: !1194, inlinedAt: !2071)
!2504 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !2071)
!2505 = !DILocation(line: 0, scope: !2034, inlinedAt: !2506)
!2506 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !2071)
!2507 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2506)
!2508 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2506)
!2509 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !2071)
!2510 = !DILocation(line: 634, column: 3, scope: !2511)
!2511 = distinct !DILexicalBlock(scope: !2501, file: !104, line: 632, column: 46)
!2512 = !DILocation(line: 638, column: 1, scope: !2047)
!2513 = distinct !DISubprogram(name: "cil_sock4_recvmsg", scope: !104, file: !104, line: 641, type: !1134, scopeLine: 642, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2514)
!2514 = !{!2515}
!2515 = !DILocalVariable(name: "ctx", arg: 1, scope: !2513, file: !104, line: 641, type: !1136)
!2516 = distinct !DIAssignID()
!2517 = distinct !DIAssignID()
!2518 = distinct !DIAssignID()
!2519 = distinct !DIAssignID()
!2520 = distinct !DIAssignID()
!2521 = !DILocation(line: 0, scope: !2513)
!2522 = !DILocalVariable(name: "key", scope: !2523, file: !104, line: 587, type: !955)
!2523 = distinct !DISubprogram(name: "__sock4_xlate_rev", scope: !104, file: !104, line: 580, type: !2524, scopeLine: 582, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2526)
!2524 = !DISubroutineType(types: !2525)
!2525 = !{!305, !1136, !1136}
!2526 = !{!2527, !2528, !2529, !2530, !2531, !2532, !2522, !2533, !2536}
!2527 = !DILocalVariable(name: "ctx", arg: 1, scope: !2523, file: !104, line: 580, type: !1136)
!2528 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !2523, file: !104, line: 581, type: !1136)
!2529 = !DILocalVariable(name: "val", scope: !2523, file: !104, line: 583, type: !962)
!2530 = !DILocalVariable(name: "dst_port", scope: !2523, file: !104, line: 584, type: !89)
!2531 = !DILocalVariable(name: "protocol", scope: !2523, file: !104, line: 585, type: !84)
!2532 = !DILocalVariable(name: "dst_ip", scope: !2523, file: !104, line: 586, type: !82)
!2533 = !DILocalVariable(name: "svc", scope: !2534, file: !104, line: 597, type: !1209)
!2534 = distinct !DILexicalBlock(scope: !2535, file: !104, line: 596, column: 11)
!2535 = distinct !DILexicalBlock(scope: !2523, file: !104, line: 596, column: 6)
!2536 = !DILocalVariable(name: "svc_key", scope: !2534, file: !104, line: 598, type: !746)
!2537 = !DILocation(line: 0, scope: !2523, inlinedAt: !2538)
!2538 = distinct !DILocation(line: 643, column: 2, scope: !2513)
!2539 = !DILocation(line: 0, scope: !2534, inlinedAt: !2538)
!2540 = !DILocation(line: 0, scope: !1240, inlinedAt: !2541)
!2541 = distinct !DILocation(line: 584, column: 19, scope: !2523, inlinedAt: !2538)
!2542 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2541)
!2543 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2541)
!2544 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2541)
!2545 = distinct !DIAssignID()
!2546 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2541)
!2547 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2541)
!2548 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2541)
!2549 = !DILocation(line: 585, column: 18, scope: !2523, inlinedAt: !2538)
!2550 = !DILocation(line: 586, column: 22, scope: !2523, inlinedAt: !2538)
!2551 = !DILocation(line: 587, column: 2, scope: !2523, inlinedAt: !2538)
!2552 = !DILocation(line: 0, scope: !1736, inlinedAt: !2553)
!2553 = distinct !DILocation(line: 588, column: 14, scope: !2523, inlinedAt: !2538)
!2554 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !2553)
!2555 = !DILocation(line: 587, column: 33, scope: !2523, inlinedAt: !2538)
!2556 = distinct !DIAssignID()
!2557 = distinct !DIAssignID()
!2558 = distinct !DIAssignID()
!2559 = !{!1931, !1266, i64 14}
!2560 = distinct !DIAssignID()
!2561 = !DILocation(line: 595, column: 8, scope: !2523, inlinedAt: !2538)
!2562 = !DILocation(line: 596, column: 6, scope: !2535, inlinedAt: !2538)
!2563 = !DILocation(line: 596, column: 6, scope: !2523, inlinedAt: !2538)
!2564 = !DILocation(line: 598, column: 3, scope: !2534, inlinedAt: !2538)
!2565 = !DILocation(line: 599, column: 20, scope: !2534, inlinedAt: !2538)
!2566 = !DILocation(line: 598, column: 28, scope: !2534, inlinedAt: !2538)
!2567 = distinct !DIAssignID()
!2568 = !DILocation(line: 600, column: 19, scope: !2534, inlinedAt: !2538)
!2569 = distinct !DIAssignID()
!2570 = distinct !DIAssignID()
!2571 = distinct !DIAssignID()
!2572 = distinct !DIAssignID()
!2573 = distinct !DIAssignID()
!2574 = distinct !DIAssignID()
!2575 = !DILocation(line: 0, scope: !1285, inlinedAt: !2576)
!2576 = distinct !DILocation(line: 604, column: 9, scope: !2534, inlinedAt: !2538)
!2577 = distinct !DIAssignID()
!2578 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2576)
!2579 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2576)
!2580 = !DILocation(line: 0, scope: !1302, inlinedAt: !2581)
!2581 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2576)
!2582 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2581)
!2583 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2576)
!2584 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2576)
!2585 = !DILocation(line: 0, scope: !1313, inlinedAt: !2586)
!2586 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2576)
!2587 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2586)
!2588 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2586)
!2589 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2586)
!2590 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2576)
!2591 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2576)
!2592 = !DILocation(line: 0, scope: !1302, inlinedAt: !2593)
!2593 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2576)
!2594 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2593)
!2595 = !DILocation(line: 605, column: 8, scope: !2596, inlinedAt: !2538)
!2596 = distinct !DILexicalBlock(scope: !2534, file: !104, line: 605, column: 7)
!2597 = !DILocation(line: 605, column: 7, scope: !2534, inlinedAt: !2538)
!2598 = !DILocation(line: 0, scope: !1228, inlinedAt: !2599)
!2599 = distinct !DILocation(line: 607, column: 7, scope: !2600, inlinedAt: !2538)
!2600 = distinct !DILexicalBlock(scope: !2596, file: !104, line: 605, column: 13)
!2601 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2599)
!2602 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2599)
!2603 = !DILocation(line: 90, column: 41, scope: !1228, inlinedAt: !2599)
!2604 = !DILocation(line: 609, column: 20, scope: !2605, inlinedAt: !2538)
!2605 = distinct !DILexicalBlock(scope: !2534, file: !104, line: 609, column: 7)
!2606 = !DILocation(line: 609, column: 42, scope: !2605, inlinedAt: !2538)
!2607 = !DILocation(line: 609, column: 34, scope: !2605, inlinedAt: !2538)
!2608 = !DILocation(line: 609, column: 56, scope: !2605, inlinedAt: !2538)
!2609 = !DILocation(line: 610, column: 13, scope: !2605, inlinedAt: !2538)
!2610 = !DILocation(line: 610, column: 19, scope: !2605, inlinedAt: !2538)
!2611 = !DILocation(line: 610, column: 24, scope: !2605, inlinedAt: !2538)
!2612 = !DILocation(line: 611, column: 4, scope: !2613, inlinedAt: !2538)
!2613 = distinct !DILexicalBlock(scope: !2605, file: !104, line: 610, column: 62)
!2614 = !DILocation(line: 0, scope: !1761, inlinedAt: !2615)
!2615 = distinct !DILocation(line: 612, column: 4, scope: !2613, inlinedAt: !2538)
!2616 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !2615)
!2617 = distinct !DIAssignID()
!2618 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !2615)
!2619 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !2615)
!2620 = distinct !DIAssignID()
!2621 = distinct !DIAssignID()
!2622 = distinct !DIAssignID()
!2623 = distinct !DIAssignID()
!2624 = distinct !DIAssignID()
!2625 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !2615)
!2626 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !2615)
!2627 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !2615)
!2628 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !2615)
!2629 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !2615)
!2630 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !2615)
!2631 = distinct !DIAssignID()
!2632 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !2615)
!2633 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !2615)
!2634 = distinct !DIAssignID()
!2635 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !2615)
!2636 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !2615)
!2637 = !DILocation(line: 613, column: 4, scope: !2613, inlinedAt: !2538)
!2638 = !DILocation(line: 616, column: 24, scope: !2534, inlinedAt: !2538)
!2639 = !DILocation(line: 616, column: 17, scope: !2534, inlinedAt: !2538)
!2640 = !DILocation(line: 617, column: 26, scope: !2534, inlinedAt: !2538)
!2641 = !DILocation(line: 0, scope: !2034, inlinedAt: !2642)
!2642 = distinct !DILocation(line: 617, column: 3, scope: !2534, inlinedAt: !2538)
!2643 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !2642)
!2644 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !2642)
!2645 = !DILocation(line: 620, column: 3, scope: !2534, inlinedAt: !2538)
!2646 = !DILocation(line: 621, column: 2, scope: !2535, inlinedAt: !2538)
!2647 = !DILocation(line: 624, column: 1, scope: !2523, inlinedAt: !2538)
!2648 = !DILocation(line: 644, column: 2, scope: !2513)
!2649 = distinct !DISubprogram(name: "cil_sock6_connect", scope: !104, file: !104, line: 1162, type: !1134, scopeLine: 1163, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2650)
!2650 = !{!2651, !2652}
!2651 = !DILocalVariable(name: "ctx", arg: 1, scope: !2649, file: !104, line: 1162, type: !1136)
!2652 = !DILocalVariable(name: "err", scope: !2649, file: !104, line: 1164, type: !305)
!2653 = distinct !DIAssignID()
!2654 = distinct !DIAssignID()
!2655 = distinct !DIAssignID()
!2656 = distinct !DIAssignID()
!2657 = distinct !DIAssignID()
!2658 = distinct !DIAssignID()
!2659 = distinct !DIAssignID()
!2660 = distinct !DIAssignID()
!2661 = distinct !DIAssignID()
!2662 = distinct !DIAssignID()
!2663 = distinct !DIAssignID()
!2664 = distinct !DIAssignID()
!2665 = distinct !DIAssignID()
!2666 = distinct !DIAssignID()
!2667 = distinct !DIAssignID()
!2668 = distinct !DIAssignID()
!2669 = distinct !DIAssignID()
!2670 = distinct !DIAssignID()
!2671 = distinct !DIAssignID()
!2672 = !DILocation(line: 0, scope: !2649)
!2673 = !DILocalVariable(name: "ctx", arg: 1, scope: !2674, file: !104, line: 1028, type: !1136)
!2674 = distinct !DISubprogram(name: "__sock6_xlate_fwd", scope: !104, file: !104, line: 1028, type: !2675, scopeLine: 1031, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2677)
!2675 = !DISubroutineType(types: !2676)
!2676 = !{!305, !1136, !1197, !1197}
!2677 = !{!2673, !2678, !2679}
!2678 = !DILocalVariable(name: "udp_only", arg: 2, scope: !2674, file: !104, line: 1029, type: !1197)
!2679 = !DILocalVariable(name: "is_connect", arg: 3, scope: !2674, file: !104, line: 1030, type: !1197)
!2680 = !DILocation(line: 0, scope: !2674, inlinedAt: !2681)
!2681 = distinct !DILocation(line: 1171, column: 8, scope: !2649)
!2682 = !DILocalVariable(name: "ctx", arg: 1, scope: !2683, file: !104, line: 851, type: !1136)
!2683 = distinct !DISubprogram(name: "sock6_xlate_v4_in_v6", scope: !104, file: !104, line: 851, type: !2675, scopeLine: 854, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2684)
!2684 = !{!2682, !2685, !2686, !2687, !2688, !2689}
!2685 = !DILocalVariable(name: "udp_only", arg: 2, scope: !2683, file: !104, line: 852, type: !1197)
!2686 = !DILocalVariable(name: "is_connect", arg: 3, scope: !2683, file: !104, line: 853, type: !1197)
!2687 = !DILocalVariable(name: "fake_ctx", scope: !2683, file: !104, line: 856, type: !1137)
!2688 = !DILocalVariable(name: "addr6", scope: !2683, file: !104, line: 857, type: !160)
!2689 = !DILocalVariable(name: "ret", scope: !2683, file: !104, line: 858, type: !305)
!2690 = !DILocation(line: 0, scope: !2683, inlinedAt: !2691)
!2691 = distinct !DILocation(line: 1157, column: 9, scope: !2674, inlinedAt: !2681)
!2692 = !DILocalVariable(name: "ctx", arg: 1, scope: !2693, file: !104, line: 713, type: !1243)
!2693 = distinct !DISubprogram(name: "ctx_get_v6_address", scope: !104, file: !104, line: 713, type: !2694, scopeLine: 715, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2697)
!2694 = !DISubroutineType(types: !2695)
!2695 = !{null, !1243, !2696}
!2696 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !160, size: 64)
!2697 = !{!2692, !2698}
!2698 = !DILocalVariable(name: "addr", arg: 2, scope: !2693, file: !104, line: 714, type: !2696)
!2699 = !DILocation(line: 0, scope: !2693, inlinedAt: !2700)
!2700 = distinct !DILocation(line: 860, column: 2, scope: !2683, inlinedAt: !2691)
!2701 = !DILocation(line: 716, column: 18, scope: !2693, inlinedAt: !2700)
!2702 = !DILocation(line: 716, column: 13, scope: !2693, inlinedAt: !2700)
!2703 = !DILocation(line: 716, column: 11, scope: !2693, inlinedAt: !2700)
!2704 = !DILocation(line: 717, column: 2, scope: !2693, inlinedAt: !2700)
!2705 = !{i64 2148412669}
!2706 = !DILocation(line: 718, column: 13, scope: !2693, inlinedAt: !2700)
!2707 = !DILocation(line: 718, column: 11, scope: !2693, inlinedAt: !2700)
!2708 = !DILocation(line: 719, column: 2, scope: !2693, inlinedAt: !2700)
!2709 = !{i64 2148412704}
!2710 = !DILocation(line: 720, column: 13, scope: !2693, inlinedAt: !2700)
!2711 = !DILocation(line: 721, column: 2, scope: !2693, inlinedAt: !2700)
!2712 = !{i64 2148412739}
!2713 = !DILocation(line: 722, column: 13, scope: !2693, inlinedAt: !2700)
!2714 = !DILocation(line: 723, column: 2, scope: !2693, inlinedAt: !2700)
!2715 = !{i64 2148412774}
!2716 = !DILocalVariable(name: "daddr", arg: 1, scope: !2717, file: !2718, line: 16, type: !2721)
!2717 = distinct !DISubprogram(name: "is_v4_in_v6", scope: !2718, file: !2718, line: 16, type: !2719, scopeLine: 17, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2723)
!2718 = !DIFile(filename: "vendor/repos/cilium/bpf/lib/nat_46x64.h", directory: "/workspaces/repository", checksumkind: CSK_MD5, checksum: "a07799fd0bb120425c60542dca5a00b1")
!2719 = !DISubroutineType(types: !2720)
!2720 = !{!88, !2721}
!2721 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !2722, size: 64)
!2722 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !160)
!2723 = !{!2716, !2724, !2725}
!2724 = !DILocalVariable(name: "dprobe", scope: !2717, file: !2718, line: 19, type: !160)
!2725 = !DILocalVariable(name: "dmasked", scope: !2717, file: !2718, line: 23, type: !160)
!2726 = !DILocation(line: 0, scope: !2717, inlinedAt: !2727)
!2727 = distinct !DILocation(line: 861, column: 7, scope: !2728, inlinedAt: !2691)
!2728 = distinct !DILexicalBlock(scope: !2683, file: !104, line: 861, column: 6)
!2729 = !DILocalVariable(name: "a", arg: 1, scope: !2730, file: !161, line: 39, type: !2721)
!2730 = distinct !DISubprogram(name: "ipv6_addr_equals", scope: !161, file: !161, line: 39, type: !2731, scopeLine: 41, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !2733)
!2731 = !DISubroutineType(types: !2732)
!2732 = !{!88, !2721, !2721}
!2733 = !{!2729, !2734}
!2734 = !DILocalVariable(name: "b", arg: 2, scope: !2730, file: !161, line: 40, type: !2721)
!2735 = !DILocation(line: 0, scope: !2730, inlinedAt: !2736)
!2736 = distinct !DILocation(line: 28, column: 9, scope: !2717, inlinedAt: !2727)
!2737 = !DILocation(line: 42, column: 12, scope: !2738, inlinedAt: !2736)
!2738 = distinct !DILexicalBlock(scope: !2730, file: !161, line: 42, column: 6)
!2739 = !DILocation(line: 42, column: 6, scope: !2730, inlinedAt: !2736)
!2740 = !DILocation(line: 0, scope: !1498, inlinedAt: !2741)
!2741 = distinct !DILocation(line: 864, column: 2, scope: !2683, inlinedAt: !2691)
!2742 = !DILocation(line: 0, scope: !1508, inlinedAt: !2743)
!2743 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !2741)
!2744 = !DILocation(line: 64, column: 12, scope: !1514, inlinedAt: !2743)
!2745 = !DILocation(line: 65, column: 12, scope: !1514, inlinedAt: !2743)
!2746 = !DILocation(line: 66, column: 12, scope: !1514, inlinedAt: !2743)
!2747 = !DILocation(line: 67, column: 12, scope: !1514, inlinedAt: !2743)
!2748 = !DILocation(line: 68, column: 12, scope: !1514, inlinedAt: !2743)
!2749 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !2743)
!2750 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !2743)
!2751 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !2743)
!2752 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !2743)
!2753 = !DILocation(line: 865, column: 23, scope: !2683, inlinedAt: !2691)
!2754 = !DILocation(line: 0, scope: !1240, inlinedAt: !2755)
!2755 = distinct !DILocation(line: 867, column: 23, scope: !2683, inlinedAt: !2691)
!2756 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2755)
!2757 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !2755)
!2758 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2755)
!2759 = distinct !DIAssignID()
!2760 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2755)
!2761 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2755)
!2762 = !DILocation(line: 867, column: 23, scope: !2683, inlinedAt: !2691)
!2763 = !DILocation(line: 0, scope: !1194, inlinedAt: !2764)
!2764 = distinct !DILocation(line: 869, column: 8, scope: !2683, inlinedAt: !2691)
!2765 = !DILocation(line: 0, scope: !1228, inlinedAt: !2766)
!2766 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !2764)
!2767 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !2766)
!2768 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !2766)
!2769 = !DILocation(line: 0, scope: !1240, inlinedAt: !2770)
!2770 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !2764)
!2771 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !2770)
!2772 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !2770)
!2773 = distinct !DIAssignID()
!2774 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !2770)
!2775 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !2770)
!2776 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !2770)
!2777 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !2764)
!2778 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !2764)
!2779 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !2764)
!2780 = distinct !DIAssignID()
!2781 = distinct !DIAssignID()
!2782 = distinct !DIAssignID()
!2783 = distinct !DIAssignID()
!2784 = distinct !DIAssignID()
!2785 = distinct !DIAssignID()
!2786 = !DILocation(line: 0, scope: !1276, inlinedAt: !2787)
!2787 = distinct !DILocation(line: 317, column: 20, scope: !1282, inlinedAt: !2764)
!2788 = !DILocation(line: 132, column: 2, scope: !1276, inlinedAt: !2787)
!2789 = distinct !DIAssignID()
!2790 = !DILocation(line: 0, scope: !1285, inlinedAt: !2791)
!2791 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !2764)
!2792 = distinct !DIAssignID()
!2793 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !2791)
!2794 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !2791)
!2795 = !DILocation(line: 0, scope: !1302, inlinedAt: !2796)
!2796 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !2791)
!2797 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2796)
!2798 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !2791)
!2799 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !2791)
!2800 = !DILocation(line: 0, scope: !1313, inlinedAt: !2801)
!2801 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !2791)
!2802 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !2801)
!2803 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !2801)
!2804 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !2801)
!2805 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !2791)
!2806 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !2791)
!2807 = !DILocation(line: 0, scope: !1302, inlinedAt: !2808)
!2808 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !2791)
!2809 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !2808)
!2810 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !2764)
!2811 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !2764)
!2812 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !2764)
!2813 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !2764)
!2814 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !2764)
!2815 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !2764)
!2816 = !DILocation(line: 0, scope: !1218, inlinedAt: !2764)
!2817 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !2764)
!2818 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !2764)
!2819 = !DILocation(line: 0, scope: !1347, inlinedAt: !2820)
!2820 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !2764)
!2821 = !DILocation(line: 0, scope: !1355, inlinedAt: !2822)
!2822 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !2820)
!2823 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !2822)
!2824 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !2822)
!2825 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !2822)
!2826 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !2820)
!2827 = !DILocation(line: 0, scope: !1366, inlinedAt: !2828)
!2828 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !2820)
!2829 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !2828)
!2830 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !2828)
!2831 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !2820)
!2832 = !DILocation(line: 0, scope: !1355, inlinedAt: !2833)
!2833 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !2820)
!2834 = !DILocation(line: 0, scope: !1376, inlinedAt: !2835)
!2835 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !2820)
!2836 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !2835)
!2837 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !2835)
!2838 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !2835)
!2839 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !2820)
!2840 = !DILocation(line: 0, scope: !1386, inlinedAt: !2841)
!2841 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !2764)
!2842 = !DILocation(line: 0, scope: !1392, inlinedAt: !2843)
!2843 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !2841)
!2844 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !2843)
!2845 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !2843)
!2846 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !2843)
!2847 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !2841)
!2848 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !2841)
!2849 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !2841)
!2850 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !2764)
!2851 = !DILocation(line: 0, scope: !1404, inlinedAt: !2852)
!2852 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !2764)
!2853 = !DILocation(line: 0, scope: !1418, inlinedAt: !2854)
!2854 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !2852)
!2855 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !2854)
!2856 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !2854)
!2857 = !DILocation(line: 0, scope: !1392, inlinedAt: !2858)
!2858 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !2852)
!2859 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !2852)
!2860 = !DILocation(line: 0, scope: !1428, inlinedAt: !2861)
!2861 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !2852)
!2862 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !2861)
!2863 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !2861)
!2864 = distinct !DIAssignID()
!2865 = distinct !DIAssignID()
!2866 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !2861)
!2867 = distinct !DIAssignID()
!2868 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !2861)
!2869 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !2861)
!2870 = distinct !DIAssignID()
!2871 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !2861)
!2872 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !2861)
!2873 = distinct !DIAssignID()
!2874 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !2861)
!2875 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !2861)
!2876 = distinct !DIAssignID()
!2877 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !2861)
!2878 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !2861)
!2879 = !DILocation(line: 0, scope: !1410, inlinedAt: !2852)
!2880 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !2852)
!2881 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !2852)
!2882 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !2852)
!2883 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !2852)
!2884 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !2852)
!2885 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !2764)
!2886 = !DILocation(line: 0, scope: !1223, inlinedAt: !2764)
!2887 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !2764)
!2888 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !2764)
!2889 = !DILocation(line: 0, scope: !1476, inlinedAt: !2890)
!2890 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !2764)
!2891 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !2890)
!2892 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !2890)
!2893 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !2890)
!2894 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !2764)
!2895 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !2764)
!2896 = !DILocation(line: 0, scope: !1486, inlinedAt: !2897)
!2897 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !2764)
!2898 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !2897)
!2899 = !DILocation(line: 0, scope: !1498, inlinedAt: !2900)
!2900 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !2897)
!2901 = !DILocation(line: 0, scope: !1508, inlinedAt: !2902)
!2902 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !2900)
!2903 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !2902)
!2904 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !2902)
!2905 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !2902)
!2906 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !2897)
!2907 = distinct !DIAssignID()
!2908 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !2897)
!2909 = distinct !DIAssignID()
!2910 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !2897)
!2911 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !2897)
!2912 = distinct !DIAssignID()
!2913 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !2897)
!2914 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !2897)
!2915 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !2897)
!2916 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !2764)
!2917 = !DILocation(line: 0, scope: !1554, inlinedAt: !2918)
!2918 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !2764)
!2919 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !2918)
!2920 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !2918)
!2921 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !2918)
!2922 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !2764)
!2923 = !DILocation(line: 0, scope: !1564, inlinedAt: !2924)
!2924 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !2764)
!2925 = !DILocation(line: 0, scope: !1574, inlinedAt: !2926)
!2926 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !2924)
!2927 = !DILocation(line: 0, scope: !1585, inlinedAt: !2926)
!2928 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !2926)
!2929 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !2926)
!2930 = distinct !DIAssignID()
!2931 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !2926)
!2932 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !2926)
!2933 = distinct !DIAssignID()
!2934 = distinct !DIAssignID()
!2935 = distinct !DIAssignID()
!2936 = distinct !DIAssignID()
!2937 = distinct !DIAssignID()
!2938 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !2926)
!2939 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !2926)
!2940 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !2926)
!2941 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !2926)
!2942 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !2764)
!2943 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !2944)
!2944 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !2926)
!2945 = !DILocation(line: 0, scope: !1617, inlinedAt: !2944)
!2946 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !2944)
!2947 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !2944)
!2948 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !2944)
!2949 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !2944)
!2950 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !2944)
!2951 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !2952)
!2952 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !2944)
!2953 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !2952)
!2954 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !2944)
!2955 = !DILocation(line: 0, scope: !1619, inlinedAt: !2944)
!2956 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !2926)
!2957 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !2926)
!2958 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !2926)
!2959 = distinct !DIAssignID()
!2960 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !2926)
!2961 = distinct !DIAssignID()
!2962 = distinct !DIAssignID()
!2963 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2926)
!2964 = !DILocation(line: 0, scope: !1589, inlinedAt: !2926)
!2965 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2966)
!2966 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !2926)
!2967 = !DILocation(line: 0, scope: !1659, inlinedAt: !2968)
!2968 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !2926)
!2969 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !2968)
!2970 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !2968)
!2971 = !DILocation(line: 0, scope: !1668, inlinedAt: !2972)
!2972 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2926)
!2973 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !2972)
!2974 = !DILocation(line: 0, scope: !1673, inlinedAt: !2972)
!2975 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !2972)
!2976 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !2972)
!2977 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !2972)
!2978 = !DILocation(line: 0, scope: !1676, inlinedAt: !2972)
!2979 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !2972)
!2980 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !2972)
!2981 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !2972)
!2982 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !2972)
!2983 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !2926)
!2984 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !2926)
!2985 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !2926)
!2986 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !2926)
!2987 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !2926)
!2988 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !2926)
!2989 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !2926)
!2990 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !2926)
!2991 = !DILocation(line: 0, scope: !1592, inlinedAt: !2926)
!2992 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2926)
!2993 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !2994)
!2994 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !2926)
!2995 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !2926)
!2996 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !2764)
!2997 = !DILocation(line: 0, scope: !1708, inlinedAt: !2998)
!2998 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !2764)
!2999 = distinct !DIAssignID()
!3000 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !2998)
!3001 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !2998)
!3002 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !2764)
!3003 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !2764)
!3004 = !DILocation(line: 0, scope: !1714, inlinedAt: !2764)
!3005 = !DILocation(line: 0, scope: !1724, inlinedAt: !3006)
!3006 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !2764)
!3007 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !3006)
!3008 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !3006)
!3009 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !3006)
!3010 = !DILocation(line: 0, scope: !1736, inlinedAt: !3011)
!3011 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !3006)
!3012 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3011)
!3013 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !2764)
!3014 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !2764)
!3015 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !2764)
!3016 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !2764)
!3017 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !2764)
!3018 = distinct !DIAssignID()
!3019 = !DILocation(line: 0, scope: !1750, inlinedAt: !3020)
!3020 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !2764)
!3021 = !DILocation(line: 0, scope: !1302, inlinedAt: !3022)
!3022 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !3020)
!3023 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3022)
!3024 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !2764)
!3025 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !2764)
!3026 = !DILocation(line: 0, scope: !1761, inlinedAt: !3027)
!3027 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !2764)
!3028 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3027)
!3029 = distinct !DIAssignID()
!3030 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3027)
!3031 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3027)
!3032 = distinct !DIAssignID()
!3033 = distinct !DIAssignID()
!3034 = distinct !DIAssignID()
!3035 = distinct !DIAssignID()
!3036 = distinct !DIAssignID()
!3037 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3027)
!3038 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3027)
!3039 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3027)
!3040 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3027)
!3041 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3027)
!3042 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3027)
!3043 = distinct !DIAssignID()
!3044 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3027)
!3045 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3027)
!3046 = distinct !DIAssignID()
!3047 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3027)
!3048 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3027)
!3049 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !2764)
!3050 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !2764)
!3051 = !DILocation(line: 0, scope: !1708, inlinedAt: !3052)
!3052 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !2764)
!3053 = distinct !DIAssignID()
!3054 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !3052)
!3055 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !3052)
!3056 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !2764)
!3057 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !2764)
!3058 = !DILocation(line: 0, scope: !1761, inlinedAt: !3059)
!3059 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !2764)
!3060 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3059)
!3061 = distinct !DIAssignID()
!3062 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3059)
!3063 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3059)
!3064 = distinct !DIAssignID()
!3065 = distinct !DIAssignID()
!3066 = distinct !DIAssignID()
!3067 = distinct !DIAssignID()
!3068 = distinct !DIAssignID()
!3069 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3059)
!3070 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3059)
!3071 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3059)
!3072 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3059)
!3073 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3059)
!3074 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3059)
!3075 = distinct !DIAssignID()
!3076 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3059)
!3077 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3059)
!3078 = distinct !DIAssignID()
!3079 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3059)
!3080 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3059)
!3081 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !2764)
!3082 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !2764)
!3083 = !DILocation(line: 0, scope: !1554, inlinedAt: !3084)
!3084 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !2764)
!3085 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !3084)
!3086 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !3084)
!3087 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !3084)
!3088 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !2764)
!3089 = !DILocation(line: 0, scope: !1847, inlinedAt: !3090)
!3090 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2764)
!3091 = !DILocation(line: 0, scope: !1856, inlinedAt: !3092)
!3092 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !3090)
!3093 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3094)
!3094 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !3092)
!3095 = !DILocation(line: 0, scope: !1617, inlinedAt: !3094)
!3096 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3094)
!3097 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3094)
!3098 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3094)
!3099 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3094)
!3100 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3094)
!3101 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3102)
!3102 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3094)
!3103 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3102)
!3104 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3094)
!3105 = !DILocation(line: 0, scope: !1619, inlinedAt: !3094)
!3106 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !3092)
!3107 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !3092)
!3108 = distinct !DIAssignID()
!3109 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !3092)
!3110 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !3092)
!3111 = distinct !DIAssignID()
!3112 = distinct !DIAssignID()
!3113 = distinct !DIAssignID()
!3114 = distinct !DIAssignID()
!3115 = distinct !DIAssignID()
!3116 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !3092)
!3117 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !3092)
!3118 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !3092)
!3119 = distinct !DIAssignID()
!3120 = distinct !DIAssignID()
!3121 = distinct !DIAssignID()
!3122 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !3092)
!3123 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !3092)
!3124 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !2764)
!3125 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !2764)
!3126 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !2764)
!3127 = !DILocation(line: 0, scope: !1906, inlinedAt: !3128)
!3128 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !2764)
!3129 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !3128)
!3130 = distinct !DIAssignID()
!3131 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !3128)
!3132 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !3128)
!3133 = distinct !DIAssignID()
!3134 = distinct !DIAssignID()
!3135 = !DILocation(line: 0, scope: !1736, inlinedAt: !3136)
!3136 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !3128)
!3137 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3136)
!3138 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !3128)
!3139 = distinct !DIAssignID()
!3140 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !3128)
!3141 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !3128)
!3142 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !3128)
!3143 = distinct !DIAssignID()
!3144 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !3128)
!3145 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !3128)
!3146 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !3128)
!3147 = distinct !DIAssignID()
!3148 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !3128)
!3149 = distinct !DIAssignID()
!3150 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !3128)
!3151 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !3128)
!3152 = distinct !DIAssignID()
!3153 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !3128)
!3154 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !3128)
!3155 = distinct !DIAssignID()
!3156 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !3128)
!3157 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !3128)
!3158 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !3128)
!3159 = !DILocation(line: 0, scope: !1963, inlinedAt: !3160)
!3160 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3128)
!3161 = !DILocation(line: 0, scope: !1972, inlinedAt: !3162)
!3162 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !3160)
!3163 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !3162)
!3164 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !3162)
!3165 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3128)
!3166 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !3128)
!3167 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !3128)
!3168 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !2764)
!3169 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !3128)
!3170 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !2764)
!3171 = !DILocation(line: 0, scope: !1761, inlinedAt: !3172)
!3172 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !2764)
!3173 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3172)
!3174 = distinct !DIAssignID()
!3175 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3172)
!3176 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3172)
!3177 = distinct !DIAssignID()
!3178 = distinct !DIAssignID()
!3179 = distinct !DIAssignID()
!3180 = distinct !DIAssignID()
!3181 = distinct !DIAssignID()
!3182 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3172)
!3183 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3172)
!3184 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3172)
!3185 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3172)
!3186 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3172)
!3187 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3172)
!3188 = distinct !DIAssignID()
!3189 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3172)
!3190 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3172)
!3191 = distinct !DIAssignID()
!3192 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3172)
!3193 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3172)
!3194 = !DILocation(line: 449, column: 3, scope: !2005, inlinedAt: !2764)
!3195 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !2764)
!3196 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !2764)
!3197 = !DILocation(line: 0, scope: !2034, inlinedAt: !3198)
!3198 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !2764)
!3199 = !DILocation(line: 875, column: 36, scope: !2683, inlinedAt: !2691)
!3200 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !2764)
!3201 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !2764)
!3202 = !DILocation(line: 870, column: 6, scope: !2683, inlinedAt: !2691)
!3203 = !DILocation(line: 0, scope: !1498, inlinedAt: !3204)
!3204 = distinct !DILocation(line: 55, column: 2, scope: !3205, inlinedAt: !3211)
!3205 = distinct !DISubprogram(name: "build_v4_in_v6", scope: !2718, file: !2718, line: 53, type: !3206, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3208)
!3206 = !DISubroutineType(types: !3207)
!3207 = !{null, !2696, !153}
!3208 = !{!3209, !3210}
!3209 = !DILocalVariable(name: "daddr", arg: 1, scope: !3205, file: !2718, line: 53, type: !2696)
!3210 = !DILocalVariable(name: "v4", arg: 2, scope: !3205, file: !2718, line: 53, type: !153)
!3211 = distinct !DILocation(line: 873, column: 2, scope: !2683, inlinedAt: !2691)
!3212 = !DILocation(line: 0, scope: !1508, inlinedAt: !3213)
!3213 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3204)
!3214 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3213)
!3215 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3213)
!3216 = !DILocalVariable(name: "ctx", arg: 1, scope: !3217, file: !104, line: 741, type: !1136)
!3217 = distinct !DISubprogram(name: "ctx_set_v6_address", scope: !104, file: !104, line: 741, type: !3218, scopeLine: 743, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3220)
!3218 = !DISubroutineType(types: !3219)
!3219 = !{null, !1136, !2721}
!3220 = !{!3216, !3221}
!3221 = !DILocalVariable(name: "addr", arg: 2, scope: !3217, file: !104, line: 742, type: !2721)
!3222 = !DILocation(line: 0, scope: !3217, inlinedAt: !3223)
!3223 = distinct !DILocation(line: 874, column: 2, scope: !2683, inlinedAt: !2691)
!3224 = !DILocation(line: 744, column: 19, scope: !3217, inlinedAt: !3223)
!3225 = !DILocation(line: 745, column: 2, scope: !3217, inlinedAt: !3223)
!3226 = !{i64 2148412847}
!3227 = !DILocation(line: 746, column: 19, scope: !3217, inlinedAt: !3223)
!3228 = !DILocation(line: 747, column: 2, scope: !3217, inlinedAt: !3223)
!3229 = !{i64 2148412882}
!3230 = !DILocation(line: 748, column: 19, scope: !3217, inlinedAt: !3223)
!3231 = !DILocation(line: 749, column: 2, scope: !3217, inlinedAt: !3223)
!3232 = !{i64 2148412917}
!3233 = !DILocation(line: 750, column: 19, scope: !3217, inlinedAt: !3223)
!3234 = !DILocation(line: 751, column: 2, scope: !3217, inlinedAt: !3223)
!3235 = !{i64 2148412952}
!3236 = !DILocation(line: 0, scope: !2034, inlinedAt: !3237)
!3237 = distinct !DILocation(line: 875, column: 2, scope: !2683, inlinedAt: !2691)
!3238 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !3237)
!3239 = !DILocation(line: 877, column: 2, scope: !2683, inlinedAt: !2691)
!3240 = !DILocation(line: 1172, column: 10, scope: !3241)
!3241 = distinct !DILexicalBlock(scope: !2649, file: !104, line: 1172, column: 6)
!3242 = !DILocation(line: 1172, column: 27, scope: !3241)
!3243 = !DILocation(line: 1178, column: 1, scope: !2649)
!3244 = distinct !DISubprogram(name: "cil_sock6_sendmsg", scope: !104, file: !104, line: 1258, type: !1134, scopeLine: 1259, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3245)
!3245 = !{!3246, !3247}
!3246 = !DILocalVariable(name: "ctx", arg: 1, scope: !3244, file: !104, line: 1258, type: !1136)
!3247 = !DILocalVariable(name: "err", scope: !3244, file: !104, line: 1260, type: !305)
!3248 = distinct !DIAssignID()
!3249 = distinct !DIAssignID()
!3250 = distinct !DIAssignID()
!3251 = distinct !DIAssignID()
!3252 = distinct !DIAssignID()
!3253 = distinct !DIAssignID()
!3254 = distinct !DIAssignID()
!3255 = distinct !DIAssignID()
!3256 = distinct !DIAssignID()
!3257 = distinct !DIAssignID()
!3258 = distinct !DIAssignID()
!3259 = distinct !DIAssignID()
!3260 = distinct !DIAssignID()
!3261 = distinct !DIAssignID()
!3262 = distinct !DIAssignID()
!3263 = distinct !DIAssignID()
!3264 = distinct !DIAssignID()
!3265 = distinct !DIAssignID()
!3266 = distinct !DIAssignID()
!3267 = !DILocation(line: 0, scope: !3244)
!3268 = !DILocation(line: 0, scope: !2674, inlinedAt: !3269)
!3269 = distinct !DILocation(line: 1262, column: 8, scope: !3244)
!3270 = !DILocation(line: 0, scope: !2683, inlinedAt: !3271)
!3271 = distinct !DILocation(line: 1157, column: 9, scope: !2674, inlinedAt: !3269)
!3272 = !DILocation(line: 0, scope: !2693, inlinedAt: !3273)
!3273 = distinct !DILocation(line: 860, column: 2, scope: !2683, inlinedAt: !3271)
!3274 = !DILocation(line: 716, column: 18, scope: !2693, inlinedAt: !3273)
!3275 = !DILocation(line: 716, column: 13, scope: !2693, inlinedAt: !3273)
!3276 = !DILocation(line: 716, column: 11, scope: !2693, inlinedAt: !3273)
!3277 = !DILocation(line: 717, column: 2, scope: !2693, inlinedAt: !3273)
!3278 = !DILocation(line: 718, column: 13, scope: !2693, inlinedAt: !3273)
!3279 = !DILocation(line: 718, column: 11, scope: !2693, inlinedAt: !3273)
!3280 = !DILocation(line: 719, column: 2, scope: !2693, inlinedAt: !3273)
!3281 = !DILocation(line: 720, column: 13, scope: !2693, inlinedAt: !3273)
!3282 = !DILocation(line: 721, column: 2, scope: !2693, inlinedAt: !3273)
!3283 = !DILocation(line: 722, column: 13, scope: !2693, inlinedAt: !3273)
!3284 = !DILocation(line: 723, column: 2, scope: !2693, inlinedAt: !3273)
!3285 = !DILocation(line: 0, scope: !2717, inlinedAt: !3286)
!3286 = distinct !DILocation(line: 861, column: 7, scope: !2728, inlinedAt: !3271)
!3287 = !DILocation(line: 0, scope: !2730, inlinedAt: !3288)
!3288 = distinct !DILocation(line: 28, column: 9, scope: !2717, inlinedAt: !3286)
!3289 = !DILocation(line: 42, column: 12, scope: !2738, inlinedAt: !3288)
!3290 = !DILocation(line: 42, column: 6, scope: !2730, inlinedAt: !3288)
!3291 = !DILocation(line: 0, scope: !1498, inlinedAt: !3292)
!3292 = distinct !DILocation(line: 864, column: 2, scope: !2683, inlinedAt: !3271)
!3293 = !DILocation(line: 0, scope: !1508, inlinedAt: !3294)
!3294 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3292)
!3295 = !DILocation(line: 64, column: 12, scope: !1514, inlinedAt: !3294)
!3296 = !DILocation(line: 65, column: 12, scope: !1514, inlinedAt: !3294)
!3297 = !DILocation(line: 66, column: 12, scope: !1514, inlinedAt: !3294)
!3298 = !DILocation(line: 67, column: 12, scope: !1514, inlinedAt: !3294)
!3299 = !DILocation(line: 68, column: 12, scope: !1514, inlinedAt: !3294)
!3300 = !DILocation(line: 69, column: 12, scope: !1514, inlinedAt: !3294)
!3301 = !DILocation(line: 70, column: 12, scope: !1514, inlinedAt: !3294)
!3302 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3294)
!3303 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3294)
!3304 = !DILocation(line: 865, column: 23, scope: !2683, inlinedAt: !3271)
!3305 = !DILocation(line: 0, scope: !1240, inlinedAt: !3306)
!3306 = distinct !DILocation(line: 867, column: 23, scope: !2683, inlinedAt: !3271)
!3307 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !3306)
!3308 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !3306)
!3309 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !3306)
!3310 = distinct !DIAssignID()
!3311 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !3306)
!3312 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !3306)
!3313 = !DILocation(line: 867, column: 23, scope: !2683, inlinedAt: !3271)
!3314 = !DILocation(line: 0, scope: !1194, inlinedAt: !3315)
!3315 = distinct !DILocation(line: 869, column: 8, scope: !2683, inlinedAt: !3271)
!3316 = !DILocation(line: 0, scope: !1228, inlinedAt: !3317)
!3317 = distinct !DILocation(line: 296, column: 25, scope: !1194, inlinedAt: !3315)
!3318 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !3317)
!3319 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !3317)
!3320 = !DILocation(line: 0, scope: !1240, inlinedAt: !3321)
!3321 = distinct !DILocation(line: 299, column: 20, scope: !1194, inlinedAt: !3315)
!3322 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !3321)
!3323 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !3321)
!3324 = distinct !DIAssignID()
!3325 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !3321)
!3326 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !3321)
!3327 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !3321)
!3328 = !DILocation(line: 300, column: 18, scope: !1194, inlinedAt: !3315)
!3329 = !DILocation(line: 302, column: 2, scope: !1194, inlinedAt: !3315)
!3330 = !DILocation(line: 302, column: 23, scope: !1194, inlinedAt: !3315)
!3331 = distinct !DIAssignID()
!3332 = distinct !DIAssignID()
!3333 = distinct !DIAssignID()
!3334 = distinct !DIAssignID()
!3335 = distinct !DIAssignID()
!3336 = distinct !DIAssignID()
!3337 = distinct !DIAssignID()
!3338 = !DILocation(line: 0, scope: !1285, inlinedAt: !3339)
!3339 = distinct !DILocation(line: 324, column: 8, scope: !1194, inlinedAt: !3315)
!3340 = distinct !DIAssignID()
!3341 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !3339)
!3342 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !3339)
!3343 = !DILocation(line: 0, scope: !1302, inlinedAt: !3344)
!3344 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !3339)
!3345 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3344)
!3346 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !3339)
!3347 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !3339)
!3348 = !DILocation(line: 0, scope: !1313, inlinedAt: !3349)
!3349 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !3339)
!3350 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !3349)
!3351 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !3349)
!3352 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !3349)
!3353 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !3339)
!3354 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !3339)
!3355 = !DILocation(line: 0, scope: !1302, inlinedAt: !3356)
!3356 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !3339)
!3357 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3356)
!3358 = !DILocation(line: 325, column: 7, scope: !1331, inlinedAt: !3315)
!3359 = !DILocation(line: 325, column: 6, scope: !1194, inlinedAt: !3315)
!3360 = !DILocation(line: 329, column: 11, scope: !1221, inlinedAt: !3315)
!3361 = !DILocation(line: 329, column: 17, scope: !1221, inlinedAt: !3315)
!3362 = !DILocation(line: 329, column: 22, scope: !1221, inlinedAt: !3315)
!3363 = !DILocation(line: 331, column: 7, scope: !1218, inlinedAt: !3315)
!3364 = !DILocation(line: 0, scope: !1218, inlinedAt: !3315)
!3365 = !DILocation(line: 331, column: 7, scope: !1219, inlinedAt: !3315)
!3366 = !DILocation(line: 331, column: 7, scope: !1220, inlinedAt: !3315)
!3367 = !DILocation(line: 0, scope: !1347, inlinedAt: !3368)
!3368 = distinct !DILocation(line: 333, column: 7, scope: !1353, inlinedAt: !3315)
!3369 = !DILocation(line: 0, scope: !1355, inlinedAt: !3370)
!3370 = distinct !DILocation(line: 2358, column: 7, scope: !1359, inlinedAt: !3368)
!3371 = !DILocation(line: 614, column: 14, scope: !1355, inlinedAt: !3370)
!3372 = !DILocation(line: 614, column: 20, scope: !1355, inlinedAt: !3370)
!3373 = !DILocation(line: 614, column: 9, scope: !1355, inlinedAt: !3370)
!3374 = !DILocation(line: 2358, column: 32, scope: !1359, inlinedAt: !3368)
!3375 = !DILocation(line: 0, scope: !1366, inlinedAt: !3376)
!3376 = distinct !DILocation(line: 2358, column: 35, scope: !1359, inlinedAt: !3368)
!3377 = !DILocation(line: 626, column: 20, scope: !1366, inlinedAt: !3376)
!3378 = !DILocation(line: 626, column: 9, scope: !1366, inlinedAt: !3376)
!3379 = !DILocation(line: 2358, column: 62, scope: !1359, inlinedAt: !3368)
!3380 = !DILocation(line: 0, scope: !1355, inlinedAt: !3381)
!3381 = distinct !DILocation(line: 2359, column: 8, scope: !1359, inlinedAt: !3368)
!3382 = !DILocation(line: 0, scope: !1376, inlinedAt: !3383)
!3383 = distinct !DILocation(line: 2359, column: 36, scope: !1359, inlinedAt: !3368)
!3384 = !DILocation(line: 638, column: 14, scope: !1376, inlinedAt: !3383)
!3385 = !DILocation(line: 638, column: 21, scope: !1376, inlinedAt: !3383)
!3386 = !DILocation(line: 638, column: 9, scope: !1376, inlinedAt: !3383)
!3387 = !DILocation(line: 2358, column: 6, scope: !1347, inlinedAt: !3368)
!3388 = !DILocation(line: 0, scope: !1386, inlinedAt: !3389)
!3389 = distinct !DILocation(line: 345, column: 6, scope: !1390, inlinedAt: !3315)
!3390 = !DILocation(line: 0, scope: !1392, inlinedAt: !3391)
!3391 = distinct !DILocation(line: 570, column: 10, scope: !1386, inlinedAt: !3389)
!3392 = !DILocation(line: 471, column: 14, scope: !1392, inlinedAt: !3391)
!3393 = !DILocation(line: 471, column: 20, scope: !1392, inlinedAt: !3391)
!3394 = !DILocation(line: 471, column: 9, scope: !1392, inlinedAt: !3391)
!3395 = !DILocation(line: 570, column: 35, scope: !1386, inlinedAt: !3389)
!3396 = !DILocation(line: 570, column: 44, scope: !1386, inlinedAt: !3389)
!3397 = !DILocation(line: 570, column: 51, scope: !1386, inlinedAt: !3389)
!3398 = !DILocation(line: 345, column: 6, scope: !1194, inlinedAt: !3315)
!3399 = !DILocation(line: 0, scope: !1404, inlinedAt: !3400)
!3400 = distinct !DILocation(line: 354, column: 6, scope: !1416, inlinedAt: !3315)
!3401 = !DILocation(line: 0, scope: !1418, inlinedAt: !3402)
!3402 = distinct !DILocation(line: 192, column: 7, scope: !1411, inlinedAt: !3400)
!3403 = !DILocation(line: 459, column: 20, scope: !1418, inlinedAt: !3402)
!3404 = !DILocation(line: 459, column: 9, scope: !1418, inlinedAt: !3402)
!3405 = !DILocation(line: 0, scope: !1392, inlinedAt: !3406)
!3406 = distinct !DILocation(line: 193, column: 7, scope: !1411, inlinedAt: !3400)
!3407 = !DILocation(line: 192, column: 83, scope: !1411, inlinedAt: !3400)
!3408 = !DILocation(line: 0, scope: !1428, inlinedAt: !3409)
!3409 = distinct !DILocation(line: 196, column: 10, scope: !1410, inlinedAt: !3400)
!3410 = !DILocation(line: 161, column: 2, scope: !1428, inlinedAt: !3409)
!3411 = !DILocation(line: 161, column: 21, scope: !1428, inlinedAt: !3409)
!3412 = distinct !DIAssignID()
!3413 = distinct !DIAssignID()
!3414 = !DILocation(line: 163, column: 16, scope: !1428, inlinedAt: !3409)
!3415 = distinct !DIAssignID()
!3416 = !DILocation(line: 164, column: 6, scope: !1428, inlinedAt: !3409)
!3417 = !DILocation(line: 164, column: 13, scope: !1428, inlinedAt: !3409)
!3418 = distinct !DIAssignID()
!3419 = !DILocation(line: 165, column: 6, scope: !1428, inlinedAt: !3409)
!3420 = !DILocation(line: 165, column: 15, scope: !1428, inlinedAt: !3409)
!3421 = distinct !DIAssignID()
!3422 = !DILocation(line: 171, column: 6, scope: !1428, inlinedAt: !3409)
!3423 = !DILocation(line: 171, column: 17, scope: !1428, inlinedAt: !3409)
!3424 = distinct !DIAssignID()
!3425 = !DILocation(line: 173, column: 9, scope: !1428, inlinedAt: !3409)
!3426 = !DILocation(line: 174, column: 1, scope: !1428, inlinedAt: !3409)
!3427 = !DILocation(line: 0, scope: !1410, inlinedAt: !3400)
!3428 = !DILocation(line: 197, column: 8, scope: !1463, inlinedAt: !3400)
!3429 = !DILocation(line: 197, column: 13, scope: !1463, inlinedAt: !3400)
!3430 = !DILocation(line: 197, column: 22, scope: !1463, inlinedAt: !3400)
!3431 = !DILocation(line: 197, column: 35, scope: !1463, inlinedAt: !3400)
!3432 = !DILocation(line: 197, column: 7, scope: !1410, inlinedAt: !3400)
!3433 = !DILocation(line: 357, column: 6, scope: !1223, inlinedAt: !3315)
!3434 = !DILocation(line: 0, scope: !1223, inlinedAt: !3315)
!3435 = !DILocation(line: 357, column: 6, scope: !1224, inlinedAt: !3315)
!3436 = !DILocation(line: 357, column: 25, scope: !1224, inlinedAt: !3315)
!3437 = !DILocation(line: 0, scope: !1476, inlinedAt: !3438)
!3438 = distinct !DILocation(line: 358, column: 6, scope: !1224, inlinedAt: !3315)
!3439 = !DILocation(line: 548, column: 14, scope: !1476, inlinedAt: !3438)
!3440 = !DILocation(line: 548, column: 21, scope: !1476, inlinedAt: !3438)
!3441 = !DILocation(line: 548, column: 9, scope: !1476, inlinedAt: !3438)
!3442 = !DILocation(line: 358, column: 36, scope: !1224, inlinedAt: !3315)
!3443 = !DILocation(line: 359, column: 40, scope: !1224, inlinedAt: !3315)
!3444 = !DILocation(line: 0, scope: !1486, inlinedAt: !3445)
!3445 = distinct !DILocation(line: 359, column: 6, scope: !1224, inlinedAt: !3315)
!3446 = !DILocation(line: 77, column: 2, scope: !1486, inlinedAt: !3445)
!3447 = !DILocation(line: 0, scope: !1498, inlinedAt: !3448)
!3448 = distinct !DILocation(line: 80, column: 2, scope: !1486, inlinedAt: !3445)
!3449 = !DILocation(line: 0, scope: !1508, inlinedAt: !3450)
!3450 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3448)
!3451 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3450)
!3452 = !DILocation(line: 71, column: 21, scope: !1514, inlinedAt: !3450)
!3453 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3450)
!3454 = !DILocation(line: 81, column: 19, scope: !1486, inlinedAt: !3445)
!3455 = distinct !DIAssignID()
!3456 = !DILocation(line: 82, column: 14, scope: !1486, inlinedAt: !3445)
!3457 = distinct !DIAssignID()
!3458 = !DILocation(line: 83, column: 6, scope: !1486, inlinedAt: !3445)
!3459 = !DILocation(line: 83, column: 11, scope: !1486, inlinedAt: !3445)
!3460 = distinct !DIAssignID()
!3461 = !DILocation(line: 84, column: 8, scope: !1486, inlinedAt: !3445)
!3462 = !DILocation(line: 85, column: 6, scope: !1550, inlinedAt: !3445)
!3463 = !DILocation(line: 88, column: 1, scope: !1486, inlinedAt: !3445)
!3464 = !DILocation(line: 357, column: 6, scope: !1194, inlinedAt: !3315)
!3465 = !DILocation(line: 0, scope: !1554, inlinedAt: !3466)
!3466 = distinct !DILocation(line: 392, column: 6, scope: !1558, inlinedAt: !3315)
!3467 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !3466)
!3468 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !3466)
!3469 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !3466)
!3470 = !DILocation(line: 392, column: 6, scope: !1194, inlinedAt: !3315)
!3471 = !DILocation(line: 0, scope: !1564, inlinedAt: !3472)
!3472 = distinct !DILocation(line: 400, column: 16, scope: !1572, inlinedAt: !3315)
!3473 = !DILocation(line: 0, scope: !1574, inlinedAt: !3474)
!3474 = distinct !DILocation(line: 2112, column: 9, scope: !1564, inlinedAt: !3472)
!3475 = !DILocation(line: 0, scope: !1585, inlinedAt: !3474)
!3476 = !DILocation(line: 2037, column: 2, scope: !1574, inlinedAt: !3474)
!3477 = !DILocation(line: 2040, column: 16, scope: !1574, inlinedAt: !3474)
!3478 = distinct !DIAssignID()
!3479 = !DILocation(line: 2037, column: 32, scope: !1574, inlinedAt: !3474)
!3480 = !DILocation(line: 2038, column: 22, scope: !1574, inlinedAt: !3474)
!3481 = distinct !DIAssignID()
!3482 = distinct !DIAssignID()
!3483 = distinct !DIAssignID()
!3484 = distinct !DIAssignID()
!3485 = distinct !DIAssignID()
!3486 = !DILocation(line: 2044, column: 8, scope: !1574, inlinedAt: !3474)
!3487 = !DILocation(line: 2045, column: 10, scope: !1586, inlinedAt: !3474)
!3488 = !DILocation(line: 2045, column: 6, scope: !1574, inlinedAt: !3474)
!3489 = !DILocation(line: 2073, column: 1, scope: !1574, inlinedAt: !3474)
!3490 = !DILocation(line: 403, column: 7, scope: !1572, inlinedAt: !3315)
!3491 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3492)
!3492 = distinct !DILocation(line: 2046, column: 22, scope: !1585, inlinedAt: !3474)
!3493 = !DILocation(line: 0, scope: !1617, inlinedAt: !3492)
!3494 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3492)
!3495 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3492)
!3496 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3492)
!3497 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3492)
!3498 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3492)
!3499 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3500)
!3500 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3492)
!3501 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3500)
!3502 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3492)
!3503 = !DILocation(line: 0, scope: !1619, inlinedAt: !3492)
!3504 = !DILocation(line: 2047, column: 3, scope: !1585, inlinedAt: !3474)
!3505 = !DILocation(line: 2049, column: 23, scope: !1585, inlinedAt: !3474)
!3506 = !DILocation(line: 2047, column: 36, scope: !1585, inlinedAt: !3474)
!3507 = distinct !DIAssignID()
!3508 = !DILocation(line: 2048, column: 23, scope: !1585, inlinedAt: !3474)
!3509 = distinct !DIAssignID()
!3510 = distinct !DIAssignID()
!3511 = !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !3474)
!3512 = !DILocation(line: 0, scope: !1589, inlinedAt: !3474)
!3513 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3514)
!3514 = distinct !DILocation(line: 2057, column: 7, scope: !1589, inlinedAt: !3474)
!3515 = !DILocation(line: 0, scope: !1659, inlinedAt: !3516)
!3516 = distinct !DILocation(line: 2058, column: 23, scope: !1590, inlinedAt: !3474)
!3517 = !DILocation(line: 2030, column: 14, scope: !1659, inlinedAt: !3516)
!3518 = !DILocation(line: 2030, column: 31, scope: !1659, inlinedAt: !3516)
!3519 = !DILocation(line: 0, scope: !1668, inlinedAt: !3520)
!3520 = distinct !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !3474)
!3521 = !DILocation(line: 33, column: 6, scope: !1673, inlinedAt: !3520)
!3522 = !DILocation(line: 0, scope: !1673, inlinedAt: !3520)
!3523 = !DILocation(line: 33, column: 6, scope: !1674, inlinedAt: !3520)
!3524 = !DILocation(line: 33, column: 6, scope: !1668, inlinedAt: !3520)
!3525 = !DILocation(line: 34, column: 22, scope: !1676, inlinedAt: !3520)
!3526 = !DILocation(line: 0, scope: !1676, inlinedAt: !3520)
!3527 = !DILocation(line: 34, column: 22, scope: !1674, inlinedAt: !3520)
!3528 = !DILocation(line: 34, column: 20, scope: !1674, inlinedAt: !3520)
!3529 = !DILocation(line: 34, column: 41, scope: !1674, inlinedAt: !3520)
!3530 = !DILocation(line: 34, column: 3, scope: !1674, inlinedAt: !3520)
!3531 = !DILocation(line: 2058, column: 7, scope: !1590, inlinedAt: !3474)
!3532 = !DILocation(line: 2057, column: 33, scope: !1590, inlinedAt: !3474)
!3533 = !DILocation(line: 2058, column: 53, scope: !1590, inlinedAt: !3474)
!3534 = !DILocation(line: 2058, column: 50, scope: !1590, inlinedAt: !3474)
!3535 = !DILocation(line: 2057, column: 7, scope: !1585, inlinedAt: !3474)
!3536 = !DILocation(line: 2063, column: 8, scope: !1697, inlinedAt: !3474)
!3537 = !DILocation(line: 2063, column: 7, scope: !1585, inlinedAt: !3474)
!3538 = !DILocation(line: 2070, column: 2, scope: !1586, inlinedAt: !3474)
!3539 = !DILocation(line: 0, scope: !1592, inlinedAt: !3474)
!3540 = !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !3474)
!3541 = !DILocation(line: 89, column: 2, scope: !1654, inlinedAt: !3542)
!3542 = distinct !DILocation(line: 2068, column: 3, scope: !1592, inlinedAt: !3474)
!3543 = !DILocation(line: 2069, column: 15, scope: !1585, inlinedAt: !3474)
!3544 = !DILocation(line: 403, column: 18, scope: !1706, inlinedAt: !3315)
!3545 = !DILocation(line: 0, scope: !1708, inlinedAt: !3546)
!3546 = distinct !DILocation(line: 404, column: 14, scope: !1714, inlinedAt: !3315)
!3547 = distinct !DIAssignID()
!3548 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !3546)
!3549 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !3546)
!3550 = !DILocation(line: 405, column: 9, scope: !1719, inlinedAt: !3315)
!3551 = !DILocation(line: 413, column: 4, scope: !1714, inlinedAt: !3315)
!3552 = !DILocation(line: 0, scope: !1714, inlinedAt: !3315)
!3553 = !DILocation(line: 0, scope: !1724, inlinedAt: !3554)
!3554 = distinct !DILocation(line: 420, column: 23, scope: !1730, inlinedAt: !3315)
!3555 = !DILocation(line: 125, column: 9, scope: !1724, inlinedAt: !3554)
!3556 = !DILocation(line: 125, column: 27, scope: !1724, inlinedAt: !3554)
!3557 = !DILocation(line: 126, column: 9, scope: !1724, inlinedAt: !3554)
!3558 = !DILocation(line: 0, scope: !1736, inlinedAt: !3559)
!3559 = distinct !DILocation(line: 126, column: 29, scope: !1724, inlinedAt: !3554)
!3560 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3559)
!3561 = !DILocation(line: 420, column: 57, scope: !1730, inlinedAt: !3315)
!3562 = !DILocation(line: 420, column: 52, scope: !1730, inlinedAt: !3315)
!3563 = !DILocation(line: 420, column: 50, scope: !1730, inlinedAt: !3315)
!3564 = !DILocation(line: 420, column: 22, scope: !1730, inlinedAt: !3315)
!3565 = !DILocation(line: 420, column: 20, scope: !1730, inlinedAt: !3315)
!3566 = distinct !DIAssignID()
!3567 = !DILocation(line: 0, scope: !1750, inlinedAt: !3568)
!3568 = distinct !DILocation(line: 421, column: 18, scope: !1730, inlinedAt: !3315)
!3569 = !DILocation(line: 0, scope: !1302, inlinedAt: !3570)
!3570 = distinct !DILocation(line: 1867, column: 9, scope: !1750, inlinedAt: !3568)
!3571 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3570)
!3572 = !DILocation(line: 422, column: 8, scope: !1758, inlinedAt: !3315)
!3573 = !DILocation(line: 422, column: 7, scope: !1730, inlinedAt: !3315)
!3574 = !DILocation(line: 0, scope: !1761, inlinedAt: !3575)
!3575 = distinct !DILocation(line: 423, column: 4, scope: !1774, inlinedAt: !3315)
!3576 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3575)
!3577 = distinct !DIAssignID()
!3578 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3575)
!3579 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3575)
!3580 = distinct !DIAssignID()
!3581 = distinct !DIAssignID()
!3582 = distinct !DIAssignID()
!3583 = distinct !DIAssignID()
!3584 = distinct !DIAssignID()
!3585 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3575)
!3586 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3575)
!3587 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3575)
!3588 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3575)
!3589 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3575)
!3590 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3575)
!3591 = distinct !DIAssignID()
!3592 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3575)
!3593 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3575)
!3594 = distinct !DIAssignID()
!3595 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3575)
!3596 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3575)
!3597 = !DILocation(line: 424, column: 4, scope: !1774, inlinedAt: !3315)
!3598 = !DILocation(line: 427, column: 30, scope: !1730, inlinedAt: !3315)
!3599 = !DILocation(line: 0, scope: !1708, inlinedAt: !3600)
!3600 = distinct !DILocation(line: 428, column: 13, scope: !1730, inlinedAt: !3315)
!3601 = distinct !DIAssignID()
!3602 = !DILocation(line: 1849, column: 9, scope: !1708, inlinedAt: !3600)
!3603 = !DILocation(line: 1849, column: 2, scope: !1708, inlinedAt: !3600)
!3604 = !DILocation(line: 431, column: 7, scope: !1810, inlinedAt: !3315)
!3605 = !DILocation(line: 431, column: 6, scope: !1194, inlinedAt: !3315)
!3606 = !DILocation(line: 0, scope: !1761, inlinedAt: !3607)
!3607 = distinct !DILocation(line: 432, column: 3, scope: !1814, inlinedAt: !3315)
!3608 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3607)
!3609 = distinct !DIAssignID()
!3610 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3607)
!3611 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3607)
!3612 = distinct !DIAssignID()
!3613 = distinct !DIAssignID()
!3614 = distinct !DIAssignID()
!3615 = distinct !DIAssignID()
!3616 = distinct !DIAssignID()
!3617 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3607)
!3618 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3607)
!3619 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3607)
!3620 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3607)
!3621 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3607)
!3622 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3607)
!3623 = distinct !DIAssignID()
!3624 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3607)
!3625 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3607)
!3626 = distinct !DIAssignID()
!3627 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3607)
!3628 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3607)
!3629 = !DILocation(line: 433, column: 3, scope: !1814, inlinedAt: !3315)
!3630 = !DILocation(line: 435, column: 2, scope: !1194, inlinedAt: !3315)
!3631 = !DILocation(line: 0, scope: !1554, inlinedAt: !3632)
!3632 = distinct !DILocation(line: 437, column: 6, scope: !1841, inlinedAt: !3315)
!3633 = !DILocation(line: 519, column: 14, scope: !1554, inlinedAt: !3632)
!3634 = !DILocation(line: 519, column: 20, scope: !1554, inlinedAt: !3632)
!3635 = !DILocation(line: 519, column: 9, scope: !1554, inlinedAt: !3632)
!3636 = !DILocation(line: 437, column: 31, scope: !1841, inlinedAt: !3315)
!3637 = !DILocation(line: 0, scope: !1847, inlinedAt: !3638)
!3638 = distinct !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !3315)
!3639 = !DILocation(line: 0, scope: !1856, inlinedAt: !3640)
!3640 = distinct !DILocation(line: 2120, column: 2, scope: !1847, inlinedAt: !3638)
!3641 = !DILocation(line: 26, column: 6, scope: !1617, inlinedAt: !3642)
!3642 = distinct !DILocation(line: 2087, column: 21, scope: !1856, inlinedAt: !3640)
!3643 = !DILocation(line: 0, scope: !1617, inlinedAt: !3642)
!3644 = !DILocation(line: 26, column: 6, scope: !1618, inlinedAt: !3642)
!3645 = !DILocation(line: 26, column: 6, scope: !1619, inlinedAt: !3642)
!3646 = !DILocation(line: 27, column: 10, scope: !1618, inlinedAt: !3642)
!3647 = !DILocation(line: 27, column: 22, scope: !1618, inlinedAt: !3642)
!3648 = !DILocation(line: 27, column: 3, scope: !1618, inlinedAt: !3642)
!3649 = !DILocation(line: 19, column: 9, scope: !1633, inlinedAt: !3650)
!3650 = distinct !DILocation(line: 28, column: 9, scope: !1619, inlinedAt: !3642)
!3651 = !DILocation(line: 19, column: 24, scope: !1633, inlinedAt: !3650)
!3652 = !DILocation(line: 28, column: 2, scope: !1619, inlinedAt: !3642)
!3653 = !DILocation(line: 0, scope: !1619, inlinedAt: !3642)
!3654 = !DILocation(line: 2088, column: 2, scope: !1856, inlinedAt: !3640)
!3655 = !DILocation(line: 2091, column: 16, scope: !1856, inlinedAt: !3640)
!3656 = distinct !DIAssignID()
!3657 = !DILocation(line: 2088, column: 32, scope: !1856, inlinedAt: !3640)
!3658 = !DILocation(line: 2089, column: 22, scope: !1856, inlinedAt: !3640)
!3659 = distinct !DIAssignID()
!3660 = distinct !DIAssignID()
!3661 = distinct !DIAssignID()
!3662 = distinct !DIAssignID()
!3663 = distinct !DIAssignID()
!3664 = !DILocation(line: 2093, column: 2, scope: !1856, inlinedAt: !3640)
!3665 = !DILocation(line: 2095, column: 16, scope: !1856, inlinedAt: !3640)
!3666 = !DILocation(line: 2093, column: 31, scope: !1856, inlinedAt: !3640)
!3667 = distinct !DIAssignID()
!3668 = distinct !DIAssignID()
!3669 = distinct !DIAssignID()
!3670 = !DILocation(line: 2098, column: 2, scope: !1856, inlinedAt: !3640)
!3671 = !DILocation(line: 2099, column: 1, scope: !1856, inlinedAt: !3640)
!3672 = !DILocation(line: 438, column: 3, scope: !1841, inlinedAt: !3315)
!3673 = !DILocation(line: 441, column: 5, scope: !1194, inlinedAt: !3315)
!3674 = !DILocation(line: 447, column: 10, scope: !1904, inlinedAt: !3315)
!3675 = !DILocation(line: 0, scope: !1906, inlinedAt: !3676)
!3676 = distinct !DILocation(line: 446, column: 6, scope: !1904, inlinedAt: !3315)
!3677 = !DILocation(line: 150, column: 2, scope: !1906, inlinedAt: !3676)
!3678 = distinct !DIAssignID()
!3679 = !DILocation(line: 151, column: 2, scope: !1906, inlinedAt: !3676)
!3680 = !DILocation(line: 151, column: 27, scope: !1906, inlinedAt: !3676)
!3681 = distinct !DIAssignID()
!3682 = distinct !DIAssignID()
!3683 = !DILocation(line: 0, scope: !1736, inlinedAt: !3684)
!3684 = distinct !DILocation(line: 158, column: 15, scope: !1906, inlinedAt: !3676)
!3685 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3684)
!3686 = !DILocation(line: 158, column: 13, scope: !1906, inlinedAt: !3676)
!3687 = distinct !DIAssignID()
!3688 = !DILocation(line: 159, column: 25, scope: !1906, inlinedAt: !3676)
!3689 = !DILocation(line: 159, column: 6, scope: !1906, inlinedAt: !3676)
!3690 = !DILocation(line: 159, column: 14, scope: !1906, inlinedAt: !3676)
!3691 = distinct !DIAssignID()
!3692 = !DILocation(line: 160, column: 22, scope: !1906, inlinedAt: !3676)
!3693 = !DILocation(line: 160, column: 6, scope: !1906, inlinedAt: !3676)
!3694 = !DILocation(line: 160, column: 11, scope: !1906, inlinedAt: !3676)
!3695 = distinct !DIAssignID()
!3696 = !DILocation(line: 162, column: 14, scope: !1906, inlinedAt: !3676)
!3697 = distinct !DIAssignID()
!3698 = !DILocation(line: 163, column: 6, scope: !1906, inlinedAt: !3676)
!3699 = !DILocation(line: 163, column: 11, scope: !1906, inlinedAt: !3676)
!3700 = distinct !DIAssignID()
!3701 = !DILocation(line: 164, column: 6, scope: !1906, inlinedAt: !3676)
!3702 = !DILocation(line: 164, column: 20, scope: !1906, inlinedAt: !3676)
!3703 = distinct !DIAssignID()
!3704 = !DILocation(line: 166, column: 8, scope: !1906, inlinedAt: !3676)
!3705 = !DILocation(line: 167, column: 7, scope: !1960, inlinedAt: !3676)
!3706 = !DILocation(line: 167, column: 11, scope: !1960, inlinedAt: !3676)
!3707 = !DILocation(line: 0, scope: !1963, inlinedAt: !3708)
!3708 = distinct !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3676)
!3709 = !DILocation(line: 0, scope: !1972, inlinedAt: !3710)
!3710 = distinct !DILocation(line: 415, column: 9, scope: !1963, inlinedAt: !3708)
!3711 = !DILocation(line: 330, column: 12, scope: !1978, inlinedAt: !3710)
!3712 = !DILocation(line: 330, column: 21, scope: !1978, inlinedAt: !3710)
!3713 = !DILocation(line: 167, column: 14, scope: !1960, inlinedAt: !3676)
!3714 = !DILocation(line: 167, column: 6, scope: !1906, inlinedAt: !3676)
!3715 = !DILocation(line: 171, column: 1, scope: !1906, inlinedAt: !3676)
!3716 = !DILocation(line: 446, column: 6, scope: !1194, inlinedAt: !3315)
!3717 = !DILocation(line: 168, column: 9, scope: !1960, inlinedAt: !3676)
!3718 = !DILocation(line: 447, column: 25, scope: !1904, inlinedAt: !3315)
!3719 = !DILocation(line: 0, scope: !1761, inlinedAt: !3720)
!3720 = distinct !DILocation(line: 448, column: 3, scope: !2005, inlinedAt: !3315)
!3721 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3720)
!3722 = distinct !DIAssignID()
!3723 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3720)
!3724 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3720)
!3725 = distinct !DIAssignID()
!3726 = distinct !DIAssignID()
!3727 = distinct !DIAssignID()
!3728 = distinct !DIAssignID()
!3729 = distinct !DIAssignID()
!3730 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3720)
!3731 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3720)
!3732 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3720)
!3733 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3720)
!3734 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3720)
!3735 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3720)
!3736 = distinct !DIAssignID()
!3737 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3720)
!3738 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3720)
!3739 = distinct !DIAssignID()
!3740 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3720)
!3741 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3720)
!3742 = !DILocation(line: 449, column: 3, scope: !2005, inlinedAt: !3315)
!3743 = !DILocation(line: 452, column: 27, scope: !1194, inlinedAt: !3315)
!3744 = !DILocation(line: 453, column: 29, scope: !1194, inlinedAt: !3315)
!3745 = !DILocation(line: 0, scope: !2034, inlinedAt: !3746)
!3746 = distinct !DILocation(line: 453, column: 2, scope: !1194, inlinedAt: !3315)
!3747 = !DILocation(line: 875, column: 36, scope: !2683, inlinedAt: !3271)
!3748 = !DILocation(line: 455, column: 2, scope: !1194, inlinedAt: !3315)
!3749 = !DILocation(line: 456, column: 1, scope: !1194, inlinedAt: !3315)
!3750 = !DILocation(line: 870, column: 6, scope: !2683, inlinedAt: !3271)
!3751 = !DILocation(line: 0, scope: !1498, inlinedAt: !3752)
!3752 = distinct !DILocation(line: 55, column: 2, scope: !3205, inlinedAt: !3753)
!3753 = distinct !DILocation(line: 873, column: 2, scope: !2683, inlinedAt: !3271)
!3754 = !DILocation(line: 0, scope: !1508, inlinedAt: !3755)
!3755 = distinct !DILocation(line: 156, column: 3, scope: !1531, inlinedAt: !3752)
!3756 = !DILocation(line: 71, column: 12, scope: !1514, inlinedAt: !3755)
!3757 = !DILocation(line: 72, column: 12, scope: !1514, inlinedAt: !3755)
!3758 = !DILocation(line: 0, scope: !3217, inlinedAt: !3759)
!3759 = distinct !DILocation(line: 874, column: 2, scope: !2683, inlinedAt: !3271)
!3760 = !DILocation(line: 744, column: 19, scope: !3217, inlinedAt: !3759)
!3761 = !DILocation(line: 745, column: 2, scope: !3217, inlinedAt: !3759)
!3762 = !DILocation(line: 746, column: 19, scope: !3217, inlinedAt: !3759)
!3763 = !DILocation(line: 747, column: 2, scope: !3217, inlinedAt: !3759)
!3764 = !DILocation(line: 748, column: 19, scope: !3217, inlinedAt: !3759)
!3765 = !DILocation(line: 749, column: 2, scope: !3217, inlinedAt: !3759)
!3766 = !DILocation(line: 750, column: 19, scope: !3217, inlinedAt: !3759)
!3767 = !DILocation(line: 751, column: 2, scope: !3217, inlinedAt: !3759)
!3768 = !DILocation(line: 0, scope: !2034, inlinedAt: !3769)
!3769 = distinct !DILocation(line: 875, column: 2, scope: !2683, inlinedAt: !3271)
!3770 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !3769)
!3771 = !DILocation(line: 877, column: 2, scope: !2683, inlinedAt: !3271)
!3772 = !DILocation(line: 1263, column: 10, scope: !3773)
!3773 = distinct !DILexicalBlock(scope: !3244, file: !104, line: 1263, column: 6)
!3774 = !DILocation(line: 1263, column: 27, scope: !3773)
!3775 = !DILocation(line: 1269, column: 1, scope: !3244)
!3776 = distinct !DISubprogram(name: "cil_sock6_recvmsg", scope: !104, file: !104, line: 1272, type: !1134, scopeLine: 1273, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3777)
!3777 = !{!3778}
!3778 = !DILocalVariable(name: "ctx", arg: 1, scope: !3776, file: !104, line: 1272, type: !1136)
!3779 = distinct !DIAssignID()
!3780 = distinct !DIAssignID()
!3781 = distinct !DIAssignID()
!3782 = distinct !DIAssignID()
!3783 = distinct !DIAssignID()
!3784 = distinct !DIAssignID()
!3785 = !DILocation(line: 0, scope: !3776)
!3786 = !DILocalVariable(name: "ctx", arg: 1, scope: !3787, file: !104, line: 1210, type: !1136)
!3787 = distinct !DISubprogram(name: "__sock6_xlate_rev", scope: !104, file: !104, line: 1210, type: !1134, scopeLine: 1211, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3788)
!3788 = !{!3786}
!3789 = !DILocation(line: 0, scope: !3787, inlinedAt: !3790)
!3790 = distinct !DILocation(line: 1274, column: 2, scope: !3776)
!3791 = !DILocalVariable(name: "ctx", arg: 1, scope: !3792, file: !104, line: 1181, type: !1136)
!3792 = distinct !DISubprogram(name: "sock6_xlate_rev_v4_in_v6", scope: !104, file: !104, line: 1181, type: !1134, scopeLine: 1182, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3793)
!3793 = !{!3791, !3794, !3795, !3796}
!3794 = !DILocalVariable(name: "fake_ctx", scope: !3792, file: !104, line: 1184, type: !1137)
!3795 = !DILocalVariable(name: "addr6", scope: !3792, file: !104, line: 1185, type: !160)
!3796 = !DILocalVariable(name: "ret", scope: !3792, file: !104, line: 1186, type: !305)
!3797 = !DILocation(line: 0, scope: !3792, inlinedAt: !3798)
!3798 = distinct !DILocation(line: 1254, column: 9, scope: !3787, inlinedAt: !3790)
!3799 = !DILocation(line: 0, scope: !2693, inlinedAt: !3800)
!3800 = distinct !DILocation(line: 1188, column: 2, scope: !3792, inlinedAt: !3798)
!3801 = !DILocation(line: 716, column: 18, scope: !2693, inlinedAt: !3800)
!3802 = !DILocation(line: 716, column: 13, scope: !2693, inlinedAt: !3800)
!3803 = !DILocation(line: 716, column: 11, scope: !2693, inlinedAt: !3800)
!3804 = !DILocation(line: 717, column: 2, scope: !2693, inlinedAt: !3800)
!3805 = !DILocation(line: 718, column: 13, scope: !2693, inlinedAt: !3800)
!3806 = !DILocation(line: 718, column: 11, scope: !2693, inlinedAt: !3800)
!3807 = !DILocation(line: 719, column: 2, scope: !2693, inlinedAt: !3800)
!3808 = !DILocation(line: 720, column: 13, scope: !2693, inlinedAt: !3800)
!3809 = !DILocation(line: 721, column: 2, scope: !2693, inlinedAt: !3800)
!3810 = !DILocation(line: 722, column: 13, scope: !2693, inlinedAt: !3800)
!3811 = !DILocation(line: 723, column: 2, scope: !2693, inlinedAt: !3800)
!3812 = !DILocation(line: 0, scope: !2717, inlinedAt: !3813)
!3813 = distinct !DILocation(line: 1189, column: 7, scope: !3814, inlinedAt: !3798)
!3814 = distinct !DILexicalBlock(scope: !3792, file: !104, line: 1189, column: 6)
!3815 = !DILocation(line: 0, scope: !2730, inlinedAt: !3816)
!3816 = distinct !DILocation(line: 28, column: 9, scope: !2717, inlinedAt: !3813)
!3817 = !DILocation(line: 42, column: 12, scope: !2738, inlinedAt: !3816)
!3818 = !DILocation(line: 42, column: 6, scope: !2730, inlinedAt: !3816)
!3819 = !DILocation(line: 1193, column: 23, scope: !3792, inlinedAt: !3798)
!3820 = !DILocation(line: 0, scope: !1240, inlinedAt: !3821)
!3821 = distinct !DILocation(line: 1195, column: 23, scope: !3792, inlinedAt: !3798)
!3822 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !3821)
!3823 = !DILocation(line: 54, column: 30, scope: !1240, inlinedAt: !3821)
!3824 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !3821)
!3825 = distinct !DIAssignID()
!3826 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !3821)
!3827 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !3821)
!3828 = !DILocation(line: 1195, column: 23, scope: !3792, inlinedAt: !3798)
!3829 = !DILocation(line: 0, scope: !2523, inlinedAt: !3830)
!3830 = distinct !DILocation(line: 1197, column: 8, scope: !3792, inlinedAt: !3798)
!3831 = !DILocation(line: 0, scope: !2534, inlinedAt: !3830)
!3832 = !DILocation(line: 0, scope: !1240, inlinedAt: !3833)
!3833 = distinct !DILocation(line: 584, column: 19, scope: !2523, inlinedAt: !3830)
!3834 = !DILocation(line: 54, column: 2, scope: !1240, inlinedAt: !3833)
!3835 = !DILocation(line: 54, column: 17, scope: !1240, inlinedAt: !3833)
!3836 = distinct !DIAssignID()
!3837 = !DILocation(line: 56, column: 17, scope: !1240, inlinedAt: !3833)
!3838 = !DILocation(line: 56, column: 9, scope: !1240, inlinedAt: !3833)
!3839 = !DILocation(line: 57, column: 1, scope: !1240, inlinedAt: !3833)
!3840 = !DILocation(line: 587, column: 2, scope: !2523, inlinedAt: !3830)
!3841 = !DILocation(line: 0, scope: !1736, inlinedAt: !3842)
!3842 = distinct !DILocation(line: 588, column: 14, scope: !2523, inlinedAt: !3830)
!3843 = !DILocation(line: 18, column: 9, scope: !1736, inlinedAt: !3842)
!3844 = !DILocation(line: 587, column: 33, scope: !2523, inlinedAt: !3830)
!3845 = distinct !DIAssignID()
!3846 = distinct !DIAssignID()
!3847 = distinct !DIAssignID()
!3848 = distinct !DIAssignID()
!3849 = !DILocation(line: 595, column: 8, scope: !2523, inlinedAt: !3830)
!3850 = !DILocation(line: 596, column: 6, scope: !2535, inlinedAt: !3830)
!3851 = !DILocation(line: 596, column: 6, scope: !2523, inlinedAt: !3830)
!3852 = !DILocation(line: 624, column: 1, scope: !2523, inlinedAt: !3830)
!3853 = !DILocation(line: 1198, column: 6, scope: !3792, inlinedAt: !3798)
!3854 = !DILocation(line: 585, column: 18, scope: !2523, inlinedAt: !3830)
!3855 = !DILocation(line: 598, column: 3, scope: !2534, inlinedAt: !3830)
!3856 = !DILocation(line: 599, column: 20, scope: !2534, inlinedAt: !3830)
!3857 = !DILocation(line: 598, column: 28, scope: !2534, inlinedAt: !3830)
!3858 = distinct !DIAssignID()
!3859 = !DILocation(line: 600, column: 19, scope: !2534, inlinedAt: !3830)
!3860 = distinct !DIAssignID()
!3861 = distinct !DIAssignID()
!3862 = distinct !DIAssignID()
!3863 = distinct !DIAssignID()
!3864 = distinct !DIAssignID()
!3865 = distinct !DIAssignID()
!3866 = !DILocation(line: 0, scope: !1285, inlinedAt: !3867)
!3867 = distinct !DILocation(line: 604, column: 9, scope: !2534, inlinedAt: !3830)
!3868 = distinct !DIAssignID()
!3869 = !DILocation(line: 1751, column: 20, scope: !1285, inlinedAt: !3867)
!3870 = !DILocation(line: 1753, column: 13, scope: !1285, inlinedAt: !3867)
!3871 = !DILocation(line: 0, scope: !1302, inlinedAt: !3872)
!3872 = distinct !DILocation(line: 1754, column: 8, scope: !1285, inlinedAt: !3867)
!3873 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3872)
!3874 = !DILocation(line: 1755, column: 7, scope: !1310, inlinedAt: !3867)
!3875 = !DILocation(line: 1755, column: 6, scope: !1285, inlinedAt: !3867)
!3876 = !DILocation(line: 0, scope: !1313, inlinedAt: !3877)
!3877 = distinct !DILocation(line: 1775, column: 21, scope: !1319, inlinedAt: !3867)
!3878 = !DILocation(line: 507, column: 14, scope: !1313, inlinedAt: !3877)
!3879 = !DILocation(line: 507, column: 21, scope: !1313, inlinedAt: !3877)
!3880 = !DILocation(line: 507, column: 9, scope: !1313, inlinedAt: !3877)
!3881 = !DILocation(line: 1775, column: 6, scope: !1285, inlinedAt: !3867)
!3882 = !DILocation(line: 1778, column: 13, scope: !1285, inlinedAt: !3867)
!3883 = !DILocation(line: 0, scope: !1302, inlinedAt: !3884)
!3884 = distinct !DILocation(line: 1779, column: 9, scope: !1285, inlinedAt: !3867)
!3885 = !DILocation(line: 1717, column: 9, scope: !1302, inlinedAt: !3884)
!3886 = !DILocation(line: 605, column: 8, scope: !2596, inlinedAt: !3830)
!3887 = !DILocation(line: 605, column: 7, scope: !2534, inlinedAt: !3830)
!3888 = !DILocation(line: 0, scope: !1228, inlinedAt: !3889)
!3889 = distinct !DILocation(line: 607, column: 7, scope: !2600, inlinedAt: !3830)
!3890 = !DILocation(line: 86, column: 28, scope: !1228, inlinedAt: !3889)
!3891 = !DILocation(line: 90, column: 23, scope: !1228, inlinedAt: !3889)
!3892 = !DILocation(line: 90, column: 41, scope: !1228, inlinedAt: !3889)
!3893 = !DILocation(line: 609, column: 20, scope: !2605, inlinedAt: !3830)
!3894 = !DILocation(line: 609, column: 42, scope: !2605, inlinedAt: !3830)
!3895 = !DILocation(line: 609, column: 34, scope: !2605, inlinedAt: !3830)
!3896 = !DILocation(line: 609, column: 56, scope: !2605, inlinedAt: !3830)
!3897 = !DILocation(line: 610, column: 13, scope: !2605, inlinedAt: !3830)
!3898 = !DILocation(line: 610, column: 19, scope: !2605, inlinedAt: !3830)
!3899 = !DILocation(line: 610, column: 24, scope: !2605, inlinedAt: !3830)
!3900 = !DILocation(line: 611, column: 4, scope: !2613, inlinedAt: !3830)
!3901 = !DILocation(line: 0, scope: !1761, inlinedAt: !3902)
!3902 = distinct !DILocation(line: 612, column: 4, scope: !2613, inlinedAt: !3830)
!3903 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3902)
!3904 = distinct !DIAssignID()
!3905 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3902)
!3906 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3902)
!3907 = distinct !DIAssignID()
!3908 = distinct !DIAssignID()
!3909 = distinct !DIAssignID()
!3910 = distinct !DIAssignID()
!3911 = distinct !DIAssignID()
!3912 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3902)
!3913 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3902)
!3914 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3902)
!3915 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3902)
!3916 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3902)
!3917 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3902)
!3918 = distinct !DIAssignID()
!3919 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3902)
!3920 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3902)
!3921 = distinct !DIAssignID()
!3922 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3902)
!3923 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3902)
!3924 = !DILocation(line: 621, column: 2, scope: !2535, inlinedAt: !3830)
!3925 = !DILocation(line: 616, column: 24, scope: !2534, inlinedAt: !3830)
!3926 = !DILocation(line: 617, column: 26, scope: !2534, inlinedAt: !3830)
!3927 = !DILocation(line: 0, scope: !2034, inlinedAt: !3928)
!3928 = distinct !DILocation(line: 617, column: 3, scope: !2534, inlinedAt: !3830)
!3929 = !DILocation(line: 0, scope: !3217, inlinedAt: !3930)
!3930 = distinct !DILocation(line: 1202, column: 2, scope: !3792, inlinedAt: !3798)
!3931 = !DILocation(line: 744, column: 19, scope: !3217, inlinedAt: !3930)
!3932 = !DILocation(line: 745, column: 2, scope: !3217, inlinedAt: !3930)
!3933 = !DILocation(line: 746, column: 19, scope: !3217, inlinedAt: !3930)
!3934 = !DILocation(line: 747, column: 2, scope: !3217, inlinedAt: !3930)
!3935 = !DILocation(line: 748, column: 19, scope: !3217, inlinedAt: !3930)
!3936 = !DILocation(line: 749, column: 2, scope: !3217, inlinedAt: !3930)
!3937 = !DILocation(line: 750, column: 19, scope: !3217, inlinedAt: !3930)
!3938 = !DILocation(line: 751, column: 2, scope: !3217, inlinedAt: !3930)
!3939 = !DILocation(line: 0, scope: !2034, inlinedAt: !3940)
!3940 = distinct !DILocation(line: 1203, column: 2, scope: !3792, inlinedAt: !3798)
!3941 = !DILocation(line: 70, column: 19, scope: !2034, inlinedAt: !3940)
!3942 = !DILocation(line: 70, column: 17, scope: !2034, inlinedAt: !3940)
!3943 = !DILocation(line: 1205, column: 2, scope: !3792, inlinedAt: !3798)
!3944 = !DILocation(line: 1275, column: 2, scope: !3776)
!3945 = distinct !DISubprogram(name: "cil_sock_release", scope: !104, file: !104, line: 1288, type: !3946, scopeLine: 1289, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3948)
!3946 = !DISubroutineType(types: !3947)
!3947 = !{!305, !1153}
!3948 = !{!3949}
!3949 = !DILocalVariable(name: "ctx", arg: 1, scope: !3945, file: !104, line: 1288, type: !1153)
!3950 = distinct !DIAssignID()
!3951 = distinct !DIAssignID()
!3952 = distinct !DIAssignID()
!3953 = !DILocation(line: 0, scope: !3945)
!3954 = !DILocation(line: 1291, column: 11, scope: !3955)
!3955 = distinct !DILexicalBlock(scope: !3945, file: !104, line: 1291, column: 6)
!3956 = !{!3957, !1130, i64 4}
!3957 = !{!"bpf_sock", !1130, i64 0, !1130, i64 4, !1130, i64 8, !1130, i64 12, !1130, i64 16, !1130, i64 20, !1130, i64 24, !1131, i64 28, !1130, i64 44, !1266, i64 48, !1130, i64 52, !1131, i64 56, !1130, i64 72, !1130, i64 76}
!3958 = !DILocation(line: 1291, column: 18, scope: !3955)
!3959 = !DILocation(line: 1291, column: 6, scope: !3945)
!3960 = !DILocalVariable(name: "key", scope: !3961, file: !104, line: 176, type: !955)
!3961 = distinct !DISubprogram(name: "sock4_delete_revnat", scope: !104, file: !104, line: 173, type: !3962, scopeLine: 175, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !3966)
!3962 = !DISubroutineType(types: !3963)
!3963 = !{!305, !3964, !1153}
!3964 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3965, size: 64)
!3965 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !1154)
!3966 = !{!3967, !3968, !3960, !3969}
!3967 = !DILocalVariable(name: "ctx", arg: 1, scope: !3961, file: !104, line: 173, type: !3964)
!3968 = !DILocalVariable(name: "ctx_full", arg: 2, scope: !3961, file: !104, line: 174, type: !1153)
!3969 = !DILocalVariable(name: "ret", scope: !3961, file: !104, line: 177, type: !305)
!3970 = !DILocation(line: 0, scope: !3961, inlinedAt: !3971)
!3971 = distinct !DILocation(line: 1292, column: 8, scope: !3972)
!3972 = distinct !DILexicalBlock(scope: !3973, file: !104, line: 1292, column: 7)
!3973 = distinct !DILexicalBlock(scope: !3955, file: !104, line: 1291, column: 30)
!3974 = !DILocation(line: 176, column: 5, scope: !3961, inlinedAt: !3971)
!3975 = !DILocation(line: 176, column: 30, scope: !3961, inlinedAt: !3971)
!3976 = distinct !DIAssignID()
!3977 = distinct !DIAssignID()
!3978 = !DILocation(line: 179, column: 18, scope: !3961, inlinedAt: !3971)
!3979 = !DILocation(line: 179, column: 16, scope: !3961, inlinedAt: !3971)
!3980 = distinct !DIAssignID()
!3981 = !DILocation(line: 180, column: 31, scope: !3961, inlinedAt: !3971)
!3982 = !{!3957, !1130, i64 52}
!3983 = !DILocation(line: 180, column: 9, scope: !3961, inlinedAt: !3971)
!3984 = !DILocation(line: 180, column: 17, scope: !3961, inlinedAt: !3971)
!3985 = distinct !DIAssignID()
!3986 = !DILocation(line: 181, column: 28, scope: !3961, inlinedAt: !3971)
!3987 = !{!3957, !1266, i64 48}
!3988 = !DILocation(line: 181, column: 9, scope: !3961, inlinedAt: !3971)
!3989 = !DILocation(line: 181, column: 14, scope: !3961, inlinedAt: !3971)
!3990 = distinct !DIAssignID()
!3991 = !DILocation(line: 183, column: 11, scope: !3961, inlinedAt: !3971)
!3992 = !DILocation(line: 185, column: 1, scope: !3961, inlinedAt: !3971)
!3993 = !DILocation(line: 1292, column: 8, scope: !3972)
!3994 = !DILocation(line: 1292, column: 7, scope: !3973)
!3995 = !DILocation(line: 0, scope: !1761, inlinedAt: !3996)
!3996 = distinct !DILocation(line: 1293, column: 4, scope: !3972)
!3997 = !DILocation(line: 50, column: 2, scope: !1761, inlinedAt: !3996)
!3998 = distinct !DIAssignID()
!3999 = !DILocation(line: 51, column: 2, scope: !1761, inlinedAt: !3996)
!4000 = !DILocation(line: 51, column: 21, scope: !1761, inlinedAt: !3996)
!4001 = distinct !DIAssignID()
!4002 = distinct !DIAssignID()
!4003 = distinct !DIAssignID()
!4004 = distinct !DIAssignID()
!4005 = distinct !DIAssignID()
!4006 = !DILocation(line: 58, column: 10, scope: !1761, inlinedAt: !3996)
!4007 = !DILocation(line: 59, column: 6, scope: !1786, inlinedAt: !3996)
!4008 = !DILocation(line: 59, column: 6, scope: !1761, inlinedAt: !3996)
!4009 = !DILocation(line: 60, column: 16, scope: !1789, inlinedAt: !3996)
!4010 = !DILocation(line: 62, column: 2, scope: !1789, inlinedAt: !3996)
!4011 = !DILocation(line: 63, column: 19, scope: !1794, inlinedAt: !3996)
!4012 = distinct !DIAssignID()
!4013 = !DILocation(line: 64, column: 13, scope: !1794, inlinedAt: !3996)
!4014 = !DILocation(line: 64, column: 19, scope: !1794, inlinedAt: !3996)
!4015 = distinct !DIAssignID()
!4016 = !DILocation(line: 65, column: 3, scope: !1794, inlinedAt: !3996)
!4017 = !DILocation(line: 67, column: 1, scope: !1761, inlinedAt: !3996)
!4018 = !DILocation(line: 1293, column: 4, scope: !3972)
!4019 = !DILocation(line: 1322, column: 2, scope: !3945)
