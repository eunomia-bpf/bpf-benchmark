from pathlib import Path
import json,subprocess,re,time,yaml,hashlib
from elftools.elf.elffile import ELFFile
r=Path(__file__).resolve().parent;old=Path('/workspaces/kprog-raw/perf/20261114-otel-combined-codegen/checked/first-main-failure');a=json.load(open(old/'mir-command.json'));a=[x.replace('-stop-after=prologepilog','-stop-before=prologepilog') for x in a];a[a.index('-o')+1]=str(r/'before.mir')
def run(a,label):
 p=subprocess.run(a,capture_output=True,text=True);(r/(label+'.stderr')).write_text(p.stderr);(r/(label+'.command.json')).write_text(json.dumps(a,indent=2)+chr(10));p.check_returncode()
if not (r/'before.mir').exists():run(a,'before')
base=['llc-18','-O3','-march=bpf','-mcpu=v4','-bpf-stack-size=4096','-filetype=obj','-start-before=prologepilog'];run([*base,str(r/'before.mir'),'-o',str(r/'roundtrip.o')],'roundtrip')
def code(path):
 with path.open('rb') as f:
  e=ELFFile(f);return {s.name:s.data() for s in e.iter_sections() if s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS'}
assert code(old/'trusted_x86.bpf.o')==code(r/'roundtrip.o'),'Unmodified MIR roundtrip changed allocated bytes'
s=(r/'before.mir').read_text();docs=list(yaml.safe_load_all(s));changed=[]
for function in docs:
 if not isinstance(function,dict) or 'stack' not in function:continue
 body=function['body'];slots=[]
 for slot in function['stack']:
  if slot['type']!='spill-slot' or slot['size']!=4 or slot['alignment']!=8:continue
  ident=slot['id'];uses=[line for line in body.splitlines() if re.search(r'%stack\.'+str(ident)+r'(?![0-9])',line) and not line.lstrip().startswith('DBG_')]
  assert uses and all(re.search(r'\((?:load|store) \(s32\)',line) for line in uses),(ident,uses[:2])
  assert all(set(map(int,re.findall(r'%stack\.(\d+)',line)))=={ident} for line in uses),(ident,'mixed memory references')
  for line in uses:body=body.replace(line,line.replace('align 8','align 4'))
  slot['alignment']=4;slots.append(ident)
 function['body']=body;changed.append(dict(function=function['name'],slots=slots))
assert any(v['slots'] for v in changed)
(r/'compact.mir').write_text(yaml.safe_dump_all(docs,sort_keys=False,width=1000000,explicit_start=True))
run([*base,str(r/'compact.mir'),'-o',str(r/'compact.o')],'compact')
run(['llc-18','-O3','-march=bpf','-mcpu=v4','-bpf-stack-size=4096','-start-before=prologepilog','-stop-after=prologepilog',str(r/'compact.mir'),'-o',str(r/'after.mir')],'after')
after=(r/'after.mir').read_text();result=dict(recorded=time.time(),roundtrip_allocated_bytes_equal=True,changed_scalar_slots=changed,stack_sizes=list(map(int,re.findall(r'stackSize:\s+(\d+)',after))),old_bpf_sha256=hashlib.sha256((old/'trusted_x86.bpf.o').read_bytes()).hexdigest(),new_bpf_sha256=hashlib.sha256((r/'compact.o').read_bytes()).hexdigest(),scope='Private compiler spill-layout prototype only. Architectural VM stack and source P/C unchanged; no kernel verification or native execution claim.')
(r/'result.json').write_text(json.dumps(result,indent=2)+chr(10));print(result,flush=True);(r/'finished').write_text(str(time.time()))
