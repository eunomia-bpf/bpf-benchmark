#!/bin/bash
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-bpf-spill-layout/kernel
date -u +%FT%TZ > "$r/started"
exec 9>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
taskset -c 16-17 vng --run /workspaces/.agent-state/kprog-ck/build-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/kprog-raw --overlay-rwdir /tmp --disable-monitor --cpus 2 --memory 16G --append 'loglevel=4 panic=30 oops=panic' --exec 'bash /workspaces/kprog-raw/perf/20261114-bpf-spill-layout/kernel/guest.sh' > "$r/job.log" 2>&1
echo $? > "$r/exit-code"
date -u +%FT%TZ > "$r/finished"
