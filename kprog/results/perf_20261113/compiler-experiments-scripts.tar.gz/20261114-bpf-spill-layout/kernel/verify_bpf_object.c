/* Stock libbpf load-only diagnostic: never executes or installs native code. */
#include <bpf/libbpf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: verify-bpf-object OBJECT VERIFIER_LOG\n");
        return 2;
    }
    size_t capacity = 128U * 1024U * 1024U;
    char *log = calloc(1, capacity);
    if (!log) return 2;
    LIBBPF_OPTS(bpf_object_open_opts, options,
        .kernel_log_buf = log, .kernel_log_size = capacity, .kernel_log_level = 2);
    struct bpf_object *object = bpf_object__open_file(argv[1], &options);
    long error = libbpf_get_error(object);
    if (!error) error = bpf_object__load(object);
    FILE *file = fopen(argv[2], "w");
    if (!file) return 2;
    size_t bytes = strnlen(log, capacity);
    int write_error = fwrite(log, 1, bytes, file) != bytes;
    if (fclose(file)) write_error = 1;
    fprintf(stderr, "stock_load_error=%ld verifier_log_bytes=%zu\n", error, bytes);
    if (!libbpf_get_error(object)) bpf_object__close(object);
    free(log);
    return write_error ? 2 : error ? 1 : 0;
}
