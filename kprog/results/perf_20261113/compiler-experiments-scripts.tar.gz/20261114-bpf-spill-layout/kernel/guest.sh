#!/bin/bash
r=/workspaces/kprog-raw/perf/20261114-bpf-spill-layout/kernel
mountpoint -q /sys/fs/bpf || mount -t bpf bpffs /sys/fs/bpf
for which in original compact; do
 if [ "$which" = original ]; then object=/workspaces/kprog-raw/perf/20261114-otel-combined-codegen/checked/first-main-failure/trusted_x86.bpf.o; else object=/workspaces/kprog-raw/perf/20261114-bpf-spill-layout/retry4/compact.o; fi
 "$r/verify-bpf-object" "$object" "$r/$which.verifier.log" > "$r/$which.stdout" 2> "$r/$which.stderr"
 echo $? > "$r/$which.exit"
done
