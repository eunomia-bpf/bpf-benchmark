from pathlib import Path
import tarfile,re,collections,json,time
r=Path(__file__).resolve().parent
root=Path('/workspaces/kprog-raw/perf/20261114-otel-combined-codegen/checked');source=root/'first-main-failure/trusted_x86.bpf.c';lines=source.read_text().splitlines();archive=root/'control/state/session-sbpz0fqm/requests/3.failure.tar.gz'
headers=collections.Counter();macros=collections.Counter();counts=collections.Counter();byline=collections.Counter();total=directives=0;filename='';lineno=0
with tarfile.open(archive,'r|gz') as t:
 for entry in t:
  if not entry.name.endswith('/trusted_x86.bpf.i'):continue
  size=entry.size
  f=t.extractfile(entry)
  for line in f:
   total+=len(line)
   m=re.match(rb'\s*#\s+(\d+)\s+"([^"]+)"',line)
   if m:
    lineno=int(m[1]);filename=m[2].decode(errors='replace');directives+=len(line);continue
   if filename.endswith('/trusted_x86.bpf.c') and 0<lineno<=len(lines):
    original=lines[lineno-1];op=re.search(r'\b(X86_SIM_[A-Z0-9_]+)\s*\(',original);key=op[1] if op else 'generated-C-other';macros[key]+=len(line);counts[key]+=1;byline[lineno]+=len(line)
   else:headers[filename]+=len(line)
   lineno+=1
  break
assert total==size,(total,size)
d=dict(preprocessed_bytes=total,generated_c_bytes=source.stat().st_size,expansion_ratio=total/source.stat().st_size,line_directive_bytes=directives,macro_expanded_bytes=dict(macros.most_common()),expanded_line_counts=dict(counts),header_bytes=dict(headers.most_common()),largest_source_lines=[dict(line=n,expanded_bytes=b,source=lines[n-1][:250]) for n,b in byline.most_common(12)],scope='Exact archived OTel failed-main preprocessor output; source-line attribution, not native runtime cost or proof acceptance.')
(r/'result.json').write_text(json.dumps(d,indent=2)+'\n');(r/'finished').write_text(str(time.time()));print(json.dumps(d),flush=True)
