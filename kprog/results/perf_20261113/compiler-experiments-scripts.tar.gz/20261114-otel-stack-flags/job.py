from pathlib import Path
import subprocess,json,re,hashlib,sys,time
sys.path.insert(0,'kprog');sys.path.insert(0,'kprog/x86/micro-prog')
import generate_micro_sim_proofs as gen
from trusted_generation import context_kind
r=Path(__file__).resolve().parent;base=Path('/workspaces/kprog-raw/perf/20261114-otel-combined-codegen');report=json.load(open(base/'build/native-report.json'));cmd=report['commands'][3]['argv'];probe=subprocess.run(['clang-18','-###','-march=native','-mtune=native','-x','c','-c','/dev/null','-o','/dev/null'],capture_output=True,text=True);(r/'host-cpu.txt').write_text(probe.stderr);cpu=re.search(r'"-tune-cpu" "([^"]+)"',probe.stderr)[1]
text=(base/'build/tracer.codegen.ll').read_text().replace('"tune-cpu"="generic"','"tune-cpu"="'+cpu+'"');(r/'native-tune.ll').write_text(text);subprocess.run(['llvm-as-18',str(r/'native-tune.ll'),'-o',str(r/'native-tune.bc')],check=True);meta=json.load(open(base/'checked/first-main-failure/generation.metadata.json'));rows=[]
variants=[('O2',['-O2'],False),('Os',['-Os'],False),('Oz',['-Oz'],False),('native-tune-O3',['-O3','-mtune=native'],True),('native-tune-Os',['-Os','-mtune=native'],True)]
for name,flags,tuned in variants:
 d=r/name;d.mkdir(exist_ok=True);a=list(cmd);a[a.index('-o')+1]=str(d/'native.o')
 if tuned:a[a.index('-c')+1]=str(r/'native-tune.bc')
 a+=flags;start=time.monotonic();p=subprocess.run(a,capture_output=True,text=True);(d/'compile.stderr').write_text(p.stderr);row=dict(name=name,command=a,exit=p.returncode,seconds=time.monotonic()-start,tune_cpu=cpu if tuned else 'inherited generic')
 if p.returncode==0:
  a=['/workspaces/repository/corpus/results/perf-combined-codegen-compatible-20261114/native-link.real','--input',str(d/'native.o'),'--symbol','perf_unwind_native','--mode','proof','--preserve-entry-abi','--output',str(d/'trusted_x86.proof.o')];p=subprocess.run(a,capture_output=True,text=True);(d/'proof.stderr').write_text(p.stderr);row['proof_exit']=p.returncode
  if p.returncode==0:
   try:
    insns,funcs,end,rodata=gen.parse_native_linked_program('trusted_x86',d);c=gen.render_program('trusted_x86',insns,funcs,kind=context_kind(meta['prog_type']),exit_addr=end,rodata16=rodata,program_section=meta['section'],trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset')) for m in meta['maps']],kernel_functions={});(d/'rendered.c').write_text(c);row.update(vm_stack_bytes=int(re.search(r'#define X86_SIM_STACK_BYTES (\d+)',c)[1]),instructions=len(insns),source_sha256=hashlib.sha256((d/'native.o').read_bytes()).hexdigest())
   except Exception as e:row['render_error']=str(e)
 rows.append(row);(r/'results.json').write_text(json.dumps(rows,indent=2)+chr(10));print({k:v for k,v in row.items() if k!='command'},flush=True)
(r/'finished').write_text(str(time.time()))
