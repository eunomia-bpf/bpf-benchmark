from pathlib import Path
import json,sys,subprocess,time
sys.path.insert(0,'kprog');sys.path.insert(0,'kprog/x86')
from trusted_specializer import compile_simulator
r=Path(__file__).resolve().parent;rows=json.load(open(r/'cilium-replay.json'));candidates=sorted([v for v in rows if v['original_status']!=0 and v['render_status']=='ok'],key=lambda v:v['generated_c_bytes']);seen=set();reports=[]
for v in candidates:
 if v['proof_sha256'] in seen:continue
 seen.add(v['proof_sha256']);d=r/'cilium-replay'/str(v['request']);text=(d/'rendered.c').read_text().replace('#include "../x86_sim_local_bpf.h"','#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"');source=d/'trusted_x86.bpf.c';source.write_text(text)
 def run(command):
  command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True)
  with (d/'compile-commands.jsonl').open('a') as f:f.write(json.dumps(dict(argv=command,seconds=time.monotonic()-start,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))+chr(10))
  p.check_returncode()
 start=time.monotonic()
 try:
  compile_simulator('/workspaces/repository/kprog/stock-path/bin/clang',source,d/'trusted_x86.bpf.o',run,bounds_compiler=Path('/workspaces/.agent-state/kprog-ck/verified-compiler/packet-bounds'))
  row=dict(request=v['request'],source_prog_id=v['source_prog_id'],proof_sha256=v['proof_sha256'],status='compiled',bytes=(d/'trusted_x86.bpf.o').stat().st_size)
 except Exception as e:row=dict(request=v['request'],status='error',error=str(e))
 row['seconds']=time.monotonic()-start;reports.append(row);(r/'compile-results.json').write_text(json.dumps(reports,indent=2)+chr(10));print(row,flush=True)
(r/'compile-finished').write_text(str(time.time()))
