from pathlib import Path
import json,tarfile,io,sys,importlib.util,types,subprocess,time,hashlib
sys.path.insert(0,'kprog');sys.path.insert(0,'kprog/x86/micro-prog')
import generate_micro_sim_proofs as new
from trusted_generation import context_kind
old=types.ModuleType('old_mul_generator');old.__file__=str(Path('kprog/x86/micro-prog/generate_micro_sim_proofs.py').resolve());sys.modules[old.__name__]=old
exec(compile(subprocess.check_output(['git','show','HEAD:kprog/x86/micro-prog/generate_micro_sim_proofs.py']).decode(),old.__file__,'exec'),old.__dict__)
r=Path(__file__).resolve().parent;c=Path('/workspaces/kprog-raw/verified/20261114-cilium-current-model-lto/perf-short-entry');summary=json.load(open(c/'collected-summary.json'));rows=[]
with tarfile.open(c/'control/service.tar.gz') as outer:
 for request in summary['programs']:
  d=r/'cilium-replay'/str(request['request_id']);d.mkdir(parents=True,exist_ok=True);name=request.get('failure_archive',request.get('artifact_archive'))
  if not name:continue
  with tarfile.open(fileobj=io.BytesIO(outer.extractfile('service/requests/'+Path(name).name).read())) as inner:
   for source,target in [('request/generated/trusted_x86.proof.o','trusted_x86.proof.o'),('request/generation.metadata.json','metadata.json'),('request/generated/kernel-functions.json','kernel-functions.json')]:
    (d/target).write_bytes(inner.extractfile(source).read())
  instructions,functions,exit_addr,rodata=new.parse_native_linked_program('trusted_x86',d);metadata=json.load(open(d/'metadata.json'));kw=dict(kind=context_kind(metadata['prog_type']),exit_addr=exit_addr,rodata16=rodata,program_section=metadata['section'],trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset')) for m in metadata['maps']],kernel_functions=json.load(open(d/'kernel-functions.json')))
  row=dict(request=request['request_id'],source_prog_id=request['source_prog_id'],original_status=request['status'],mul64_sites=sum(x.mnemonic=='mul' for x in instructions),proof_sha256=hashlib.sha256((d/'trusted_x86.proof.o').read_bytes()).hexdigest())
  try:
   text=new.render_program('trusted_x86',instructions,functions,**kw);(d/'rendered.c').write_text(text);row.update(render_status='ok',generated_c_bytes=len(text),generated_c_sha256=hashlib.sha256(text.encode()).hexdigest())
   if request['status']==0:row['default_c_equal']=text==old.render_program('trusted_x86',instructions,functions,**kw);assert row['default_c_equal']
  except Exception as e:row.update(render_status='error',error=str(e))
  rows.append(row);(r/'cilium-replay.json').write_text(json.dumps(rows,indent=2)+chr(10));print(row,flush=True)
(r/'replay-finished').write_text(str(time.time()))
