#!/bin/bash
set -uo pipefail
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-mul-u64
date -u +%FT%TZ > "$r/host-started"
taskset -c 16-19 make -C kprog/libnativeloader checked-sim-check CHECKED_SIM_BUILD="$r/host-build" CHECKED_SIM_OUTPUT="$r/host-check" FRAME_LINKER=/workspaces/repository/corpus/results/perf-combined-codegen-compatible-20261114/native-link.real > "$r/host-check.log" 2>&1
status=$?;echo "$status" > "$r/host-exit";date -u +%FT%TZ > "$r/host-finished";exit "$status"
