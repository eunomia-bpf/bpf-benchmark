from pathlib import Path
import json,subprocess,re,time
r=Path(__file__).resolve().parent;source=r/'first-main-failure';original=json.load(open(source/'mir-command.json'));variants=[('O2',['-O2']),('Os',['-Os']),('Oz',['-Oz']),('O3-basic',['-O3','-mllvm','-regalloc=basic']),('O3-no-misched',['-O3','-mllvm','-enable-misched=false']),('O3-icmp',['-O3','-mllvm','-bpf-disable-serialize-icmp=true']),('O3-memcpy',['-O3','-mllvm','-bpf-expand-memcpy-in-order=true'])];rows=[]
for name,flags in variants:
 d=r/'backend-matrix'/name;d.mkdir(parents=True,exist_ok=True);cmd=list(original);cmd[cmd.index('-o')+1]=str(d/'frame.mir');cmd+=flags;start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);(d/'stderr').write_text(p.stderr);row=dict(name=name,command=cmd,exit=p.returncode,seconds=time.monotonic()-start)
 if p.returncode==0:row['stack_sizes']=list(map(int,re.findall(r'stackSize:\s+(\d+)',(d/'frame.mir').read_text())))
 rows.append(row);(r/'backend-matrix.json').write_text(json.dumps(rows,indent=2)+chr(10));print({k:v for k,v in row.items() if k!='command'},flush=True)
(r/'backend-matrix-finished').write_text(str(time.time()))
