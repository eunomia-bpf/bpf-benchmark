from pathlib import Path
import json,hashlib,re,tarfile,time
r=Path(__file__).resolve().parent;root=r/'control/state';failure=next(root.glob('*/requests/3.failure.tar.gz'));active=next(p for p in root.glob('*/requests/request-*') if p.is_dir());out=r/'first-main-failure';out.mkdir(exist_ok=True)
def digest(f):
 h=hashlib.sha256();raw=hashlib.sha256();size=0
 for line in f:
  raw.update(line);size+=len(line)
  if not re.match(rb'^\s*#\s*(?:line\s+)?\d+\s+"',line):h.update(line)
 return dict(bytes=size,sha256=raw.hexdigest(),tokens_sha256=h.hexdigest())
old={}
with tarfile.open(failure,mode='r|gz') as t:
 for m in t:
  if m.name in ['request/generation.metadata.json','request/kernel.facts.json','request/kernel.native.o','request/generated/trusted_x86.bpf.c','request/generated/trusted_x86.bpf.bounds.bc','request/generated/trusted_x86.bpf.o']:
   b=t.extractfile(m).read();name=Path(m.name).name;(out/name).write_bytes(b)
   if name=='generation.metadata.json':old['metadata']=json.loads(b)
   if name=='kernel.native.o':old['native_sha256']=hashlib.sha256(b).hexdigest()
  if m.name=='request/generated/trusted_x86.bpf.i':old['preprocessed']=digest(t.extractfile(m))
current=dict(metadata=json.load(open(active/'generation.metadata.json')),native_sha256=hashlib.sha256((active/'kernel.native.o').read_bytes()).hexdigest())
with (active/'generated/trusted_x86.bpf.i').open('rb') as f:current['preprocessed']=digest(f)
def canonical(meta):
 meta=dict(meta);meta['maps']=sorted(meta['maps'],key=lambda x:x['name']);return meta
result=dict(recorded=time.time(),active_request=str(active),failure_archive=str(failure),old=old,current=current,native_equal=old['native_sha256']==current['native_sha256'],metadata_equal=canonical(old['metadata'])==canonical(current['metadata']),token_equal=old['preprocessed']['tokens_sha256']==current['preprocessed']['tokens_sha256'],scope='Compare only, no process stopped. Line markers excluded; all non-line-directive bytes, metadata and P hashes must match before treating retry as duplicate.')
(r/'duplicate-comparison.json').write_text(json.dumps(result,indent=2)+chr(10));print({k:v for k,v in result.items() if k not in ['old','current']},flush=True)
