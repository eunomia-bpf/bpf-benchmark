#!/bin/bash
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-census-resume
date -u +%FT%TZ > "$r/started"
exec 9>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
make -f kprog/test/resident-census.mk run OUTPUT="$r/ready/queues/0" RUN_OUTPUT="$r/control" HOST_CPUS=20-23 VM_CPUS=4 VM_MEM=24G > "$r/make.log" 2>&1
echo $? > "$r/exit-code"
date -u +%FT%TZ > "$r/finished"
