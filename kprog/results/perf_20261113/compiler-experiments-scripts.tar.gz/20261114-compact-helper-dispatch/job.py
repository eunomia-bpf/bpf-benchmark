from pathlib import Path
import sys,json,re,subprocess,time,hashlib
from elftools.elf.elffile import ELFFile
sys.path[:0]=['kprog','kprog/x86']
from trusted_specializer import compile_simulator
r=Path(__file__).resolve().parent
old=Path('/workspaces/kprog-raw/perf/20261114-mul-u64/cilium-replay/39')
source=(old/'trusted_x86.bpf.c').read_text();source,n=re.subn(r'X86_SIM_BPF_CALL_ID\(X86_SIM_HELPER_([A-Za-z0-9_]+)\);',r'X86_SIM_BPF_CALL_\1();',source);assert n
p=r/'trusted_x86.bpf.c';p.write_text(source)
def run(a):
 a=list(map(str,a));start=time.monotonic();z=subprocess.run(a,capture_output=True,text=True)
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(argv=a,seconds=time.monotonic()-start,exit=z.returncode,stderr=z.stderr))+chr(10))
 z.check_returncode()
compile_simulator('/workspaces/repository/kprog/stock-path/bin/clang',p,r/'trusted_x86.bpf.o',run,bounds_compiler=Path('/workspaces/.agent-state/kprog-ck/verified-compiler/packet-bounds'))
def code(p):
 with p.open('rb') as f:
  e=ELFFile(f);return {s.name:s.data() for s in e.iter_sections() if s['sh_flags']&2 and s['sh_type']!='SHT_NOBITS'}
a,b=code(old/'trusted_x86.bpf.o'),code(r/'trusted_x86.bpf.o')
result=dict(calls=n,allocated_bytes_equal=a==b,old_preprocessed_bytes=(old/'trusted_x86.bpf.i').stat().st_size,new_preprocessed_bytes=(r/'trusted_x86.bpf.i').stat().st_size,scope='Raw static-known-helper dispatch prototype on one real Cilium proof. Not full compiler promotion or M4 closure.')
(r/'result.json').write_text(json.dumps(result,indent=2)+chr(10));print(result,flush=True);(r/'finished').write_text(str(time.time()))
