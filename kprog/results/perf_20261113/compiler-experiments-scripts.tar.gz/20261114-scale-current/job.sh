#!/bin/bash
cd /workspaces/repository
r=/workspaces/kprog-raw/perf/20261114-scale-current
date -u +%FT%TZ > "$r/started"
sha256sum kprog/fidelity/scale.py kprog/x86/x86_sim_local_bpf.h kprog/x86/micro-prog/generate_micro_sim_proofs.py > "$r/input-sha256"
/usr/bin/time -v -o "$r/build.resources" taskset -c 18-19 make -C kprog/fidelity scale-build SCALE_BUILD="$r/build" SCALE_SIZES='100 1000 10000 100000' > "$r/build.log" 2>&1
echo $? > "$r/build-exit"
# Use the sole live kernel; no legacy fidelity kernel target.
exec 9>/workspaces/.agent-state/kprog-lanes/locks/image
flock -s 9
taskset -c 18-19 vng --run /workspaces/.agent-state/kprog-ck/build-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir "$r" --overlay-rwdir /tmp --disable-monitor --cpus 2 --memory 8G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -C /workspaces/repository/kprog/fidelity scale-guest SCALE_BUILD=/workspaces/kprog-raw/perf/20261114-scale-current/build SCALE_OUT=/workspaces/kprog-raw/perf/20261114-scale-current/kernel' > "$r/kernel.log" 2>&1
echo $? > "$r/kernel-exit"
date -u +%FT%TZ > "$r/finished"
