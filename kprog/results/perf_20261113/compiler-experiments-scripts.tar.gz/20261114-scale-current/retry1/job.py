from pathlib import Path
import subprocess,os,time,json,datetime,hashlib,fcntl
r=Path(__file__).resolve().parent
os.chdir('/workspaces/repository')
def run(a,name):
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as f:
  p=subprocess.Popen(a,stdout=f,stderr=subprocess.STDOUT);pid,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 d=dict(argv=a,exit=p.returncode,seconds=time.monotonic()-start,user_seconds=ru.ru_utime,system_seconds=ru.ru_stime,max_rss_kib=ru.ru_maxrss)
 (r/(name+'.resources.json')).write_text(json.dumps(d,indent=2)+'\n');return p.returncode
(r/'started').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
run(['taskset','-c','18-19','make','-C','kprog/fidelity','scale-build','SCALE_BUILD='+str(r/'build'),'SCALE_SIZES=100 1000 10000 100000'],'build')
if list((r/'build').glob('n*.json')):
 with open('/workspaces/.agent-state/kprog-lanes/locks/image','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_SH)
  run(['taskset','-c','18-19','vng','--run','/workspaces/.agent-state/kprog-ck/build-x86/arch/x86/boot/bzImage','--cwd','/workspaces/repository','--rwdir','/workspaces/repository','--rwdir',str(r),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','8G','--append','loglevel=4 panic=30 oops=panic','--exec','make -C /workspaces/repository/kprog/fidelity scale-guest SCALE_BUILD='+str(r/'build')+' SCALE_OUT='+str(r/'kernel')],'kernel')
(r/'finished').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
