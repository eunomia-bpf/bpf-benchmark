from pathlib import Path
import subprocess,os,json,time,datetime,resource
r=Path(__file__).resolve().parent
source=Path('/workspaces/kprog-raw/perf/20261114-compact-helper-dispatch/otel-main/commands.jsonl');rows=[json.loads(x) for x in source.read_text().splitlines()];a=next(x['argv'] for x in rows if '-emit-llvm' in x['argv']);a=a.copy();a[a.index('-o')+1]=str(r/'unoptimized.bc');a+=['-Xclang','-disable-llvm-passes','-ftime-report'];resource.setrlimit(resource.RLIMIT_AS,(85899345920,85899345920));start=time.monotonic()
with (r/'stdout').open('w') as out,(r/'stderr').open('w') as err:
 p=subprocess.Popen(a,stdout=out,stderr=err);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
d=dict(recorded=datetime.datetime.now(datetime.timezone.utc).isoformat(),argv=a,exit=p.returncode,wall_seconds=time.monotonic()-start,user_seconds=ru.ru_utime,system_seconds=ru.ru_stime,max_rss_kib=ru.ru_maxrss,scope='IR-generation diagnostic on exact archived370MB OTel input/same O3flags with LLVM passes disabled; no nativeP flag candidate, machine code or verifier acceptance. Shared E-core timings are not a controlled speedup comparison.')
(r/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d,flush=True)
