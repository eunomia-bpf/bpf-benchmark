from pathlib import Path
import subprocess,os,time,json,datetime,resource
r=Path(__file__).resolve().parent;resource.setrlimit(resource.RLIMIT_AS,(85899345920,85899345920));a=['opt-18','-passes=default<O3>','-debug-pass-manager','-time-passes',str(r.parent/'irgen/unoptimized.bc'),'-o',str(r/'optimized.bc')];start=time.monotonic();(r/'started').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())
with (r/'stdout').open('w') as out,(r/'stderr').open('w') as err:
 p=subprocess.Popen(a,stdout=out,stderr=err);_,status,ru=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
d=dict(recorded=datetime.datetime.now(datetime.timezone.utc).isoformat(),argv=a,exit=p.returncode,wall_seconds=time.monotonic()-start,user_seconds=ru.ru_utime,system_seconds=ru.ru_stime,max_rss_kib=ru.ru_maxrss,scope='Compiler-cost diagnostic defaultO3 replay on exact archived unoptimized B IR, not P flag selection/native execution/verifier acceptance; opt pipeline may differ from clang target hooks, record actual pass logs and do not infer speedup.')
(r/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d,flush=True)
