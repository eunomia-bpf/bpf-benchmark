from pathlib import Path
import re,json,collections
r=Path(__file__).resolve().parent;s=(r/'before.mir').read_text();variables={a:b for a,b in re.findall(r'!(\d+) = !DILocalVariable\(name: "([^"]+)"',s)};body=s.split('body:             |',1)[1];defs={};names={};report={str(n):dict(stores=0,definitions=collections.Counter(),debug_names=collections.Counter(),examples=[]) for n in (2,9,17,18)}
for line in body.splitlines():
 if re.match(r'\s*bb\.',line):defs={};names={}
 m=re.search(r'(\$[wr]\d+) = ([^!]+)',line)
 if m:
  reg=m[1][2:];defs[reg]=m[2].split('debug-location')[0].strip().strip(',');names.pop(reg,None)
 m=re.search(r'DBG_VALUE (\$[wr]\d+),.*?!(\d+)',line)
 if m:names[m[1][2:]]=variables.get(m[2],m[2])
 m=re.search(r'STW32 (?:killed )?(\$w\d+), %stack\.(2|9|17|18), 0',line)
 if m:
  reg=m[1][2:];d=report[m[2]];d['stores']+=1;d['definitions'][defs.get(reg,'not-local')]+=1;d['debug_names'][names.get(reg,'not-local')]+=1
  if len(d['examples'])<4:d['examples'].append(dict(instruction=line.strip(),last_definition=defs.get(reg),debug_name=names.get(reg)))
(r/'slot-observations.json').write_text(json.dumps(dict(scope='Exact old OTel prePEI MIR local physical-register definitions only; debug/coalescing not a proof of semantic variable identity or verifier precision.',slots=report),indent=2)+'\n')
for slot,d in report.items():print(slot,d['stores'],d['definitions'].most_common(6),d['debug_names'].most_common(4))
