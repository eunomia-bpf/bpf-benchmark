#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 200U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(12) M(13) M(14) M(15) M(16) M(17)
#include "../x86_sim_local_bpf.h"

extern __u8 dotnet_procs[] __ksym;
extern __u8 interpreter_offsets[] __ksym;
extern __u8 metrics[] __ksym;
extern __u8 per_cpu_records[] __ksym;
extern __u8 perf_progs[] __ksym;
extern __u8 pid_page_to_mapping_info[] __ksym;
static const __u8 __x86_rodata_0[66] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x64, 0x6f, 0x74, 0x6e, 0x65, 0x74, 0x3a, 0x20, 0x20, 0x2d, 0x2d, 0x3e, 0x20, 0x66, 0x69, 0x6e, 0x64, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x20, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x25, 0x6c, 0x78, 0x3a, 0x20, 0x70, 0x63, 0x5f, 0x62, 0x61, 0x73, 0x65, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x6d, 0x61, 0x70, 0x5f, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x25, 0x6c, 0x78, 0x0a, 0x00};
static const __u8 __x86_rodata_1[67] SEC(".rodata.native.1") __attribute__((aligned(16))) = {0x64, 0x6f, 0x74, 0x6e, 0x65, 0x74, 0x3a, 0x20, 0x20, 0x2d, 0x2d, 0x3e, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x73, 0x74, 0x61, 0x72, 0x74, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x68, 0x65, 0x61, 0x64, 0x65, 0x72, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x2c, 0x20, 0x70, 0x63, 0x5f, 0x6f, 0x66, 0x66, 0x73, 0x65, 0x74, 0x20, 0x3d, 0x20, 0x25, 0x6c, 0x78, 0x0a, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L__const.dotnet_find_code_start.____fmt\",\"size\":66},{\"proof_section\":\".rodata.native.1\",\"proof_symbol\":\"__x86_rodata_1\",\"native_symbol\":\".L__const.unwind_one_dotnet_frame.____fmt.9\",\"size\":67}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

static __always_inline __u64 __x86_rodata_1_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 32, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 33, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 34, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 35, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 36, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 37, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 38, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 39, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 40, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 41, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 42, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 43, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 44, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 45, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 46, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 47, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 48, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 49, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 50, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 51, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 52, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 53, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 54, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 55, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 56, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 57, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 58, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 59, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 60, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 61, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 62, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 63, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 64, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 65, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 66, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 31, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 32, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 33, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 34, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 35, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 36, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 37, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 38, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 39, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 40, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 41, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 42, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 43, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 44, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 45, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 46, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 47, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 48, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 49, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 50, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 51, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 52, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 53, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 54, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 55, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 56, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 57, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 58, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 59, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 60, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 61, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 62, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 63, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 64, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 65, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 29, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 30, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 31, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 32, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 33, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 34, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 35, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 36, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 37, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 38, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 39, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 40, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 41, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 42, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 43, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 44, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 45, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 46, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 47, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 48, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 49, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 50, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 51, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 52, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 53, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 54, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 55, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 56, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 57, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 58, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 59, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 60, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 61, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 62, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 63, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 25, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 26, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 27, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 28, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 29, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 30, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 31, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 32, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 33, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 34, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 35, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 36, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 37, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 38, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 39, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 40, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 41, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 42, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 43, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 44, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 45, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 46, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 47, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 48, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 49, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 50, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 51, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 52, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 53, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 54, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 55, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 56, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 57, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 58, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 59, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_1 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_1)) \
       RESULT = __x86_rodata_1_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_1 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_STORE, X86_OP_MOVBE_STORE)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_REP_MOVS, X86_OP_REP_MOVS)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/unwind_dotnet")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 152ULL);
x86_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_23:
	/* 0x23: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28:
	/* 0x28: call   2d <kprobe_unwind_dotnet+0x2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d:
	/* 0x2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30:
	/* 0x30: je     71c4 <kprobe_unwind_dotnet+0x71c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30, 0x71c4, x86_l_71c4);
x86_l_36:
	/* 0x36: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39:
	/* 0x39: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b:
	/* 0x3b: mov    DWORD PTR [rsp+0x94],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_42:
	/* 0x42: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_49:
	/* 0x49: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d:
	/* 0x4d: jne    647 <kprobe_unwind_dotnet+0x647> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4d, 0x647, x86_l_647);
x86_l_53:
	/* 0x53: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)dotnet_procs));
x86_l_5a:
	/* 0x5a: lea    rsi,[rsp+0x94] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_62:
	/* 0x62: call   67 <kprobe_unwind_dotnet+0x67> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_67:
	/* 0x67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a:
	/* 0x6a: je     97 <kprobe_unwind_dotnet+0x97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a, 0x97, x86_l_97);
x86_l_6c:
	/* 0x6c: mov    BYTE PTR [r14+0x1385],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 21461951578114ULL);
x86_l_74:
	/* 0x74: mov    DWORD PTR [rsp+0x70],0x5a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337242ULL);
x86_l_7c:
	/* 0x7c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_83:
	/* 0x83: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_88:
	/* 0x88: call   8d <kprobe_unwind_dotnet+0x8d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8d:
	/* 0x8d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_90:
	/* 0x90: je     cb <kprobe_unwind_dotnet+0xcb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90, 0xcb, x86_l_cb);
x86_l_92:
	/* 0x92: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_95:
	/* 0x95: jmp    d5 <kprobe_unwind_dotnet+0xd5> */
	X86_SIM_X86_JMP(0x95, 0xd5, x86_l_d5);
x86_l_97:
	/* 0x97: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9b:
	/* 0x9b: jne    722 <kprobe_unwind_dotnet+0x722> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9b, 0x722, x86_l_722);
x86_l_a1:
	/* 0xa1: mov    DWORD PTR [rsp+0x70],0x5c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337244ULL);
x86_l_a9:
	/* 0xa9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_b0:
	/* 0xb0: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_b5:
	/* 0xb5: call   ba <kprobe_unwind_dotnet+0xba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ba:
	/* 0xba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd:
	/* 0xbd: je     202 <kprobe_unwind_dotnet+0x202> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd, 0x202, x86_l_202);
x86_l_c3:
	/* 0xc3: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_c6:
	/* 0xc6: jmp    20c <kprobe_unwind_dotnet+0x20c> */
	X86_SIM_X86_JMP(0xc6, 0x20c, x86_l_20c);
x86_l_cb:
	/* 0xcb: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cf:
	/* 0xcf: jne    7a0 <kprobe_unwind_dotnet+0x7a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcf, 0x7a0, x86_l_7a0);
x86_l_d5:
	/* 0xd5: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_dc:
	/* 0xdc: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_e3:
	/* 0xe3: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_ea:
	/* 0xea: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_f2:
	/* 0xf2: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f6:
	/* 0xf6: jne    6b4 <kprobe_unwind_dotnet+0x6b4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf6, 0x6b4, x86_l_6b4);
x86_l_fc:
	/* 0xfc: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ff:
	/* 0xff: jb     70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JCC(X86_CC_B, 0xff, 0x70d6, x86_l_70d6);
x86_l_105:
	/* 0x105: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_10c:
	/* 0x10c: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10f:
	/* 0x10f: jae    70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10f, 0x70d6, x86_l_70d6);
x86_l_115:
	/* 0x115: mov    BYTE PTR [rsp+0x88],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_11c:
	/* 0x11c: mov    QWORD PTR [rsp+0x60],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_121:
	/* 0x121: lea    rbx,[r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_128:
	/* 0x128: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12b:
	/* 0x12b: add    rax,0xf80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3968ULL);
x86_l_131:
	/* 0x131: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_139:
	/* 0x139: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_140:
	/* 0x140: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_147:
	/* 0x147: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_14c:
	/* 0x14c: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_154:
	/* 0x154: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_157:
	/* 0x157: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_15b:
	/* 0x15b: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_161:
	/* 0x161: jne    1ab <kprobe_unwind_dotnet+0x1ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x161, 0x1ab, x86_l_1ab);
x86_l_163:
	/* 0x163: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_16a:
	/* 0x16a: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16d:
	/* 0x16d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_172:
	/* 0x172: call   177 <kprobe_unwind_dotnet+0x177> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_177:
	/* 0x177: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17a:
	/* 0x17a: je     283 <kprobe_unwind_dotnet+0x283> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17a, 0x283, x86_l_283);
x86_l_180:
	/* 0x180: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_187:
	/* 0x187: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18b:
	/* 0x18b: je     1d7 <kprobe_unwind_dotnet+0x1d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b, 0x1d7, x86_l_1d7);
x86_l_18d:
	/* 0x18d: movabs rax,0xa7265746e696f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2940529837762927ULL);
x86_l_197:
	/* 0x197: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19c:
	/* 0x19c: movabs rax,0x70206b6361747320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8079575806083625760ULL);
x86_l_1a6:
	/* 0x1a6: jmp    8c2 <kprobe_unwind_dotnet+0x8c2> */
	X86_SIM_X86_JMP(0x1a6, 0x8c2, x86_l_8c2);
x86_l_1ab:
	/* 0x1ab: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1b0:
	/* 0x1b0: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1b5:
	/* 0x1b5: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1b8:
	/* 0x1b8: call   1bd <kprobe_unwind_dotnet+0x1bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1bd:
	/* 0x1bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c0:
	/* 0x1c0: je     293 <kprobe_unwind_dotnet+0x293> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c0, 0x293, x86_l_293);
x86_l_1c6:
	/* 0x1c6: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1cd:
	/* 0x1cd: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d1:
	/* 0x1d1: jne    8a9 <kprobe_unwind_dotnet+0x8a9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d1, 0x8a9, x86_l_8a9);
x86_l_1d7:
	/* 0x1d7: mov    DWORD PTR [rsp+0xc],0x5d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607645ULL);
x86_l_1df:
	/* 0x1df: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1e6:
	/* 0x1e6: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1eb:
	/* 0x1eb: call   1f0 <kprobe_unwind_dotnet+0x1f0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f0:
	/* 0x1f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f3:
	/* 0x1f3: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1f8:
	/* 0x1f8: je     216 <kprobe_unwind_dotnet+0x216> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8, 0x216, x86_l_216);
x86_l_1fa:
	/* 0x1fa: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1fd:
	/* 0x1fd: jmp    7121 <kprobe_unwind_dotnet+0x7121> */
	X86_SIM_X86_JMP(0x1fd, 0x7121, x86_l_7121);
x86_l_202:
	/* 0x202: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_206:
	/* 0x206: jne    817 <kprobe_unwind_dotnet+0x817> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x206, 0x817, x86_l_817);
x86_l_20c:
	/* 0x20c: mov    eax,0x1770 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6000ULL);
x86_l_211:
	/* 0x211: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0x211, 0x7126, x86_l_7126);
x86_l_216:
	/* 0x216: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21a:
	/* 0x21a: je     7121 <kprobe_unwind_dotnet+0x7121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a, 0x7121, x86_l_7121);
x86_l_220:
	/* 0x220: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_22a:
	/* 0x22a: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_22f:
	/* 0x22f: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_239:
	/* 0x239: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_23e:
	/* 0x23e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_248:
	/* 0x248: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24d:
	/* 0x24d: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_257:
	/* 0x257: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25c:
	/* 0x25c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_266:
	/* 0x266: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26b:
	/* 0x26b: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_275:
	/* 0x275: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27a:
	/* 0x27a: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_27e:
	/* 0x27e: jmp    7339 <kprobe_unwind_dotnet+0x7339> */
	X86_SIM_X86_JMP(0x27e, 0x7339, x86_l_7339);
x86_l_283:
	/* 0x283: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_28b:
	/* 0x28b: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_28e:
	/* 0x28e: jmp    a31 <kprobe_unwind_dotnet+0xa31> */
	X86_SIM_X86_JMP(0x28e, 0xa31, x86_l_a31);
x86_l_293:
	/* 0x293: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_297:
	/* 0x297: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_29e:
	/* 0x29e: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2a3:
	/* 0x2a3: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2aa:
	/* 0x2aa: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2af:
	/* 0x2af: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2b6:
	/* 0x2b6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2bd:
	/* 0x2bd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c0:
	/* 0x2c0: jne    900 <kprobe_unwind_dotnet+0x900> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c0, 0x900, x86_l_900);
x86_l_2c6:
	/* 0x2c6: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_2cd:
	/* 0x2cd: jb     a31 <kprobe_unwind_dotnet+0xa31> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2cd, 0xa31, x86_l_a31);
x86_l_2d3:
	/* 0x2d3: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2da:
	/* 0x2da: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_2e1:
	/* 0x2e1: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2e4:
	/* 0x2e4: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2e7:
	/* 0x2e7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2ee:
	/* 0x2ee: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f1:
	/* 0x2f1: jne    97c <kprobe_unwind_dotnet+0x97c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f1, 0x97c, x86_l_97c);
x86_l_2f7:
	/* 0x2f7: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2fa:
	/* 0x2fa: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_2fe:
	/* 0x2fe: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_303:
	/* 0x303: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_305:
	/* 0x305: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_308:
	/* 0x308: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30a:
	/* 0x30a: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_311:
	/* 0x311: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_319:
	/* 0x319: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_31d:
	/* 0x31d: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_320:
	/* 0x320: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_323:
	/* 0x323: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_32b:
	/* 0x32b: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_32f:
	/* 0x32f: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_334:
	/* 0x334: call   339 <kprobe_unwind_dotnet+0x339> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_339:
	/* 0x339: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33c:
	/* 0x33c: je     38a <kprobe_unwind_dotnet+0x38a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33c, 0x38a, x86_l_38a);
x86_l_33e:
	/* 0x33e: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_345:
	/* 0x345: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_349:
	/* 0x349: jne    5f2 <kprobe_unwind_dotnet+0x5f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x349, 0x5f2, x86_l_5f2);
x86_l_34f:
	/* 0x34f: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_357:
	/* 0x357: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_35e:
	/* 0x35e: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_363:
	/* 0x363: call   368 <kprobe_unwind_dotnet+0x368> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_368:
	/* 0x368: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36b:
	/* 0x36b: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_370:
	/* 0x370: mov    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_373:
	/* 0x373: je     3e1 <kprobe_unwind_dotnet+0x3e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x373, 0x3e1, x86_l_3e1);
x86_l_375:
	/* 0x375: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_378:
	/* 0x378: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_37d:
	/* 0x37d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37f:
	/* 0x37f: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_383:
	/* 0x383: je     3fc <kprobe_unwind_dotnet+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x383, 0x3fc, x86_l_3fc);
x86_l_385:
	/* 0x385: jmp    1850 <kprobe_unwind_dotnet+0x1850> */
	X86_SIM_X86_JMP(0x385, 0x1850, x86_l_1850);
x86_l_38a:
	/* 0x38a: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_391:
	/* 0x391: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_398:
	/* 0x398: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39b:
	/* 0x39b: jne    ed8 <kprobe_unwind_dotnet+0xed8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39b, 0xed8, x86_l_ed8);
x86_l_3a1:
	/* 0x3a1: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_3a4:
	/* 0x3a4: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_3a6:
	/* 0x3a6: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_3a9:
	/* 0x3a9: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_3ab:
	/* 0x3ab: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_3b0:
	/* 0x3b0: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3b3:
	/* 0x3b3: je     525 <kprobe_unwind_dotnet+0x525> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b3, 0x525, x86_l_525);
x86_l_3b9:
	/* 0x3b9: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_3bd:
	/* 0x3bd: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3c0:
	/* 0x3c0: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3c3:
	/* 0x3c3: jne    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c3, 0x9c3, x86_l_9c3);
x86_l_3c9:
	/* 0x3c9: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3cc:
	/* 0x3cc: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_3cf:
	/* 0x3cf: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3d2:
	/* 0x3d2: je     633 <kprobe_unwind_dotnet+0x633> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d2, 0x633, x86_l_633);
x86_l_3d8:
	/* 0x3d8: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_3dc:
	/* 0x3dc: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x3dc, 0x9c3, x86_l_9c3);
x86_l_3e1:
	/* 0x3e1: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e5:
	/* 0x3e5: jne    fd8 <kprobe_unwind_dotnet+0xfd8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e5, 0xfd8, x86_l_fd8);
x86_l_3eb:
	/* 0x3eb: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_3f0:
	/* 0x3f0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f2:
	/* 0x3f2: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f6:
	/* 0x3f6: jne    1850 <kprobe_unwind_dotnet+0x1850> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f6, 0x1850, x86_l_1850);
x86_l_3fc:
	/* 0x3fc: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_401:
	/* 0x401: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_403:
	/* 0x403: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x403, 0x7126, x86_l_7126);
x86_l_409:
	/* 0x409: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_410:
	/* 0x410: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_414:
	/* 0x414: jb     4c7 <kprobe_unwind_dotnet+0x4c7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x414, 0x4c7, x86_l_4c7);
x86_l_41a:
	/* 0x41a: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41e:
	/* 0x41e: jne    1060 <kprobe_unwind_dotnet+0x1060> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41e, 0x1060, x86_l_1060);
x86_l_424:
	/* 0x424: mov    DWORD PTR [rsp+0xc],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607554ULL);
x86_l_42c:
	/* 0x42c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_433:
	/* 0x433: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_438:
	/* 0x438: call   43d <kprobe_unwind_dotnet+0x43d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_43d:
	/* 0x43d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_440:
	/* 0x440: jne    a86 <kprobe_unwind_dotnet+0xa86> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x440, 0xa86, x86_l_a86);
x86_l_446:
	/* 0x446: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44a:
	/* 0x44a: je     a89 <kprobe_unwind_dotnet+0xa89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44a, 0xa89, x86_l_a89);
x86_l_450:
	/* 0x450: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_45a:
	/* 0x45a: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_45f:
	/* 0x45f: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_469:
	/* 0x469: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_46e:
	/* 0x46e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_478:
	/* 0x478: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_47d:
	/* 0x47d: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_487:
	/* 0x487: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_48c:
	/* 0x48c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_496:
	/* 0x496: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_49b:
	/* 0x49b: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_4a5:
	/* 0x4a5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4aa:
	/* 0x4aa: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4ae:
	/* 0x4ae: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b3:
	/* 0x4b3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4b8:
	/* 0x4b8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ba:
	/* 0x4ba: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4bd:
	/* 0x4bd: call   4c2 <kprobe_unwind_dotnet+0x4c2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4c2:
	/* 0x4c2: jmp    a89 <kprobe_unwind_dotnet+0xa89> */
	X86_SIM_X86_JMP(0x4c2, 0xa89, x86_l_a89);
x86_l_4c7:
	/* 0x4c7: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4ca:
	/* 0x4ca: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4d1:
	/* 0x4d1: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_4d5:
	/* 0x4d5: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_4e1:
	/* 0x4e1: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_4ed:
	/* 0x4ed: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_4f6:
	/* 0x4f6: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_502:
	/* 0x502: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_50e:
	/* 0x50e: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_511:
	/* 0x511: mov    r13,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_514:
	/* 0x514: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_517:
	/* 0x517: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_51a:
	/* 0x51a: jne    bb5 <kprobe_unwind_dotnet+0xbb5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51a, 0xbb5, x86_l_bb5);
x86_l_520:
	/* 0x520: jmp    224a <kprobe_unwind_dotnet+0x224a> */
	X86_SIM_X86_JMP(0x520, 0x224a, x86_l_224a);
x86_l_525:
	/* 0x525: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_52c:
	/* 0x52c: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_530:
	/* 0x530: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_537:
	/* 0x537: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_53e:
	/* 0x53e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_541:
	/* 0x541: jne    1212 <kprobe_unwind_dotnet+0x1212> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x541, 0x1212, x86_l_1212);
x86_l_547:
	/* 0x547: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_549:
	/* 0x549: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_54c:
	/* 0x54c: je     129e <kprobe_unwind_dotnet+0x129e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54c, 0x129e, x86_l_129e);
x86_l_552:
	/* 0x552: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_554:
	/* 0x554: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_557:
	/* 0x557: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_55a:
	/* 0x55a: jae    17cd <kprobe_unwind_dotnet+0x17cd> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x55a, 0x17cd, x86_l_17cd);
x86_l_560:
	/* 0x560: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_567:
	/* 0x567: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56b:
	/* 0x56b: je     34f <kprobe_unwind_dotnet+0x34f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56b, 0x34f, x86_l_34f);
x86_l_571:
	/* 0x571: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_57b:
	/* 0x57b: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_580:
	/* 0x580: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_58a:
	/* 0x58a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_58f:
	/* 0x58f: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_599:
	/* 0x599: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_59e:
	/* 0x59e: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_5a8:
	/* 0x5a8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5ad:
	/* 0x5ad: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_5b7:
	/* 0x5b7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5bc:
	/* 0x5bc: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5c6:
	/* 0x5c6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cb:
	/* 0x5cb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5d0:
	/* 0x5d0: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5d5:
	/* 0x5d5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5d7:
	/* 0x5d7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5d9:
	/* 0x5d9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5dc:
	/* 0x5dc: call   5e1 <kprobe_unwind_dotnet+0x5e1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5e1:
	/* 0x5e1: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5e8:
	/* 0x5e8: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ec:
	/* 0x5ec: je     34f <kprobe_unwind_dotnet+0x34f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ec, 0x34f, x86_l_34f);
x86_l_5f2:
	/* 0x5f2: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_5fc:
	/* 0x5fc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_601:
	/* 0x601: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_60b:
	/* 0x60b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_610:
	/* 0x610: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_618:
	/* 0x618: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_61d:
	/* 0x61d: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_622:
	/* 0x622: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_624:
	/* 0x624: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_626:
	/* 0x626: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_629:
	/* 0x629: call   62e <kprobe_unwind_dotnet+0x62e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_62e:
	/* 0x62e: jmp    34f <kprobe_unwind_dotnet+0x34f> */
	X86_SIM_X86_JMP(0x62e, 0x34f, x86_l_34f);
x86_l_633:
	/* 0x633: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_636:
	/* 0x636: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_639:
	/* 0x639: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_63c:
	/* 0x63c: je     69c <kprobe_unwind_dotnet+0x69c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63c, 0x69c, x86_l_69c);
x86_l_63e:
	/* 0x63e: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_642:
	/* 0x642: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x642, 0x9c3, x86_l_9c3);
x86_l_647:
	/* 0x647: movabs rax,0x3d3d206425207465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4412718824384656485ULL);
x86_l_651:
	/* 0x651: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_656:
	/* 0x656: movabs rax,0x6e746f645f646e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959108918358339177ULL);
x86_l_660:
	/* 0x660: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_665:
	/* 0x665: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8605944719278423357ULL);
x86_l_66f:
	/* 0x66f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_674:
	/* 0x674: mov    DWORD PTR [rsp+0x28],0xa3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171799362877ULL);
x86_l_67c:
	/* 0x67c: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_683:
	/* 0x683: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_688:
	/* 0x688: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_68d:
	/* 0x68d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_68f:
	/* 0x68f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_692:
	/* 0x692: call   697 <kprobe_unwind_dotnet+0x697> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_697:
	/* 0x697: jmp    53 <kprobe_unwind_dotnet+0x53> */
	X86_SIM_X86_JMP(0x697, 0x53, x86_l_53);
x86_l_69c:
	/* 0x69c: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_69f:
	/* 0x69f: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_6a2:
	/* 0x6a2: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_6a5:
	/* 0x6a5: je     788 <kprobe_unwind_dotnet+0x788> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a5, 0x788, x86_l_788);
x86_l_6ab:
	/* 0x6ab: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_6af:
	/* 0x6af: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x6af, 0x9c3, x86_l_9c3);
x86_l_6b4:
	/* 0x6b4: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_6be:
	/* 0x6be: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6c3:
	/* 0x6c3: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_6cd:
	/* 0x6cd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6d2:
	/* 0x6d2: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_6dc:
	/* 0x6dc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6e1:
	/* 0x6e1: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_6eb:
	/* 0x6eb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6f0:
	/* 0x6f0: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_6f8:
	/* 0x6f8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6fd:
	/* 0x6fd: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_702:
	/* 0x702: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_705:
	/* 0x705: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_707:
	/* 0x707: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_70a:
	/* 0x70a: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_70d:
	/* 0x70d: call   712 <kprobe_unwind_dotnet+0x712> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_712:
	/* 0x712: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_714:
	/* 0x714: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_717:
	/* 0x717: jae    105 <kprobe_unwind_dotnet+0x105> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x717, 0x105, x86_l_105);
x86_l_71d:
	/* 0x71d: jmp    70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JMP(0x71d, 0x70d6, x86_l_70d6);
x86_l_722:
	/* 0x722: movabs rax,0xa646970207369 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2925153782625129ULL);
x86_l_72c:
	/* 0x72c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_731:
	/* 0x731: movabs rax,0x687420726f66206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7526676553110265967ULL);
x86_l_73b:
	/* 0x73b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_740:
	/* 0x740: movabs rax,0x666e49636f725074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7380917530727174260ULL);
x86_l_74a:
	/* 0x74a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_74f:
	/* 0x74f: movabs rax,0x656e746f44206f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7308907266502061934ULL);
x86_l_759:
	/* 0x759: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_75e:
	/* 0x75e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_768:
	/* 0x768: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76d:
	/* 0x76d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_772:
	/* 0x772: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_777:
	/* 0x777: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_779:
	/* 0x779: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77b:
	/* 0x77b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77e:
	/* 0x77e: call   783 <kprobe_unwind_dotnet+0x783> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_783:
	/* 0x783: jmp    a1 <kprobe_unwind_dotnet+0xa1> */
	X86_SIM_X86_JMP(0x783, 0xa1, x86_l_a1);
x86_l_788:
	/* 0x788: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_78b:
	/* 0x78b: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_78e:
	/* 0x78e: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_791:
	/* 0x791: je     88e <kprobe_unwind_dotnet+0x88e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x791, 0x88e, x86_l_88e);
x86_l_797:
	/* 0x797: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_79b:
	/* 0x79b: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x79b, 0x9c3, x86_l_9c3);
x86_l_7a0:
	/* 0x7a0: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_7aa:
	/* 0x7aa: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7af:
	/* 0x7af: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_7b9:
	/* 0x7b9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7be:
	/* 0x7be: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_7c8:
	/* 0x7c8: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7cd:
	/* 0x7cd: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7d7:
	/* 0x7d7: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7dc:
	/* 0x7dc: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7e6:
	/* 0x7e6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7eb:
	/* 0x7eb: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_7f5:
	/* 0x7f5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7fa:
	/* 0x7fa: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7fe:
	/* 0x7fe: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_803:
	/* 0x803: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_808:
	/* 0x808: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80a:
	/* 0x80a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80d:
	/* 0x80d: call   812 <kprobe_unwind_dotnet+0x812> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_812:
	/* 0x812: jmp    d5 <kprobe_unwind_dotnet+0xd5> */
	X86_SIM_X86_JMP(0x812, 0xd5, x86_l_d5);
x86_l_817:
	/* 0x817: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_821:
	/* 0x821: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_826:
	/* 0x826: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_830:
	/* 0x830: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_835:
	/* 0x835: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_83f:
	/* 0x83f: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_844:
	/* 0x844: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_84e:
	/* 0x84e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_853:
	/* 0x853: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_85d:
	/* 0x85d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_862:
	/* 0x862: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_86c:
	/* 0x86c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_871:
	/* 0x871: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_875:
	/* 0x875: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_87a:
	/* 0x87a: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_87f:
	/* 0x87f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_881:
	/* 0x881: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_884:
	/* 0x884: call   889 <kprobe_unwind_dotnet+0x889> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_889:
	/* 0x889: jmp    20c <kprobe_unwind_dotnet+0x20c> */
	X86_SIM_X86_JMP(0x889, 0x20c, x86_l_20c);
x86_l_88e:
	/* 0x88e: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_891:
	/* 0x891: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_894:
	/* 0x894: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_897:
	/* 0x897: je     968 <kprobe_unwind_dotnet+0x968> */
	X86_SIM_X86_JCC(X86_CC_E, 0x897, 0x968, x86_l_968);
x86_l_89d:
	/* 0x89d: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_8a4:
	/* 0x8a4: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x8a4, 0x9c3, x86_l_9c3);
x86_l_8a9:
	/* 0x8a9: movabs rax,0xa7265746e696f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2940529837762927ULL);
x86_l_8b3:
	/* 0x8b3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8b8:
	/* 0x8b8: movabs rax,0x7020656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8079569251963397664ULL);
x86_l_8c2:
	/* 0x8c2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8c7:
	/* 0x8c7: movabs rax,0x646162203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7233170367155350816ULL);
x86_l_8d1:
	/* 0x8d1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8d6:
	/* 0x8d6: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_8e0:
	/* 0x8e0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8e5:
	/* 0x8e5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8ea:
	/* 0x8ea: mov    esi,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_8ef:
	/* 0x8ef: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8f1:
	/* 0x8f1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8f3:
	/* 0x8f3: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8f6:
	/* 0x8f6: call   8fb <kprobe_unwind_dotnet+0x8fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_8fb:
	/* 0x8fb: jmp    1d7 <kprobe_unwind_dotnet+0x1d7> */
	X86_SIM_X86_JMP(0x8fb, 0x1d7, x86_l_1d7);
x86_l_900:
	/* 0x900: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_90a:
	/* 0x90a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_90f:
	/* 0x90f: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_919:
	/* 0x919: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_91e:
	/* 0x91e: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_928:
	/* 0x928: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_92d:
	/* 0x92d: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_937:
	/* 0x937: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_93c:
	/* 0x93c: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_944:
	/* 0x944: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_949:
	/* 0x949: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_94e:
	/* 0x94e: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_951:
	/* 0x951: call   956 <kprobe_unwind_dotnet+0x956> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_956:
	/* 0x956: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_95d:
	/* 0x95d: jae    2d3 <kprobe_unwind_dotnet+0x2d3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x95d, 0x2d3, x86_l_2d3);
x86_l_963:
	/* 0x963: jmp    a31 <kprobe_unwind_dotnet+0xa31> */
	X86_SIM_X86_JMP(0x963, 0xa31, x86_l_a31);
x86_l_968:
	/* 0x968: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_96b:
	/* 0x96b: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_96e:
	/* 0x96e: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_971:
	/* 0x971: je     9b5 <kprobe_unwind_dotnet+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x971, 0x9b5, x86_l_9b5);
x86_l_973:
	/* 0x973: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_97a:
	/* 0x97a: jmp    9c3 <kprobe_unwind_dotnet+0x9c3> */
	X86_SIM_X86_JMP(0x97a, 0x9c3, x86_l_9c3);
x86_l_97c:
	/* 0x97c: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_983:
	/* 0x983: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_988:
	/* 0x988: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_98d:
	/* 0x98d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_990:
	/* 0x990: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_993:
	/* 0x993: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_99a:
	/* 0x99a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_99d:
	/* 0x99d: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_9a2:
	/* 0x9a2: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_9a5:
	/* 0x9a5: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_9a8:
	/* 0x9a8: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_9ab:
	/* 0x9ab: call   9b0 <kprobe_unwind_dotnet+0x9b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_9b0:
	/* 0x9b0: jmp    2f7 <kprobe_unwind_dotnet+0x2f7> */
	X86_SIM_X86_JMP(0x9b0, 0x2f7, x86_l_2f7);
x86_l_9b5:
	/* 0x9b5: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_9b9:
	/* 0x9b9: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_9c0:
	/* 0x9c0: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_9c3:
	/* 0x9c3: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_9c6:
	/* 0x9c6: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_9ce:
	/* 0x9ce: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_9d1:
	/* 0x9d1: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_9d8:
	/* 0x9d8: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9dc:
	/* 0x9dc: jne    f62 <kprobe_unwind_dotnet+0xf62> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9dc, 0xf62, x86_l_f62);
x86_l_9e2:
	/* 0x9e2: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_9e6:
	/* 0x9e6: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_9eb:
	/* 0x9eb: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_9f0:
	/* 0x9f0: call   9f5 <kprobe_unwind_dotnet+0x9f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_9f5:
	/* 0x9f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9f8:
	/* 0x9f8: je     a2c <kprobe_unwind_dotnet+0xa2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f8, 0xa2c, x86_l_a2c);
x86_l_9fa:
	/* 0x9fa: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9fe:
	/* 0x9fe: jne    10c6 <kprobe_unwind_dotnet+0x10c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9fe, 0x10c6, x86_l_10c6);
x86_l_a04:
	/* 0xa04: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_a0c:
	/* 0xa0c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_a13:
	/* 0xa13: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a18:
	/* 0xa18: call   a1d <kprobe_unwind_dotnet+0xa1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a1d:
	/* 0xa1d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a20:
	/* 0xa20: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a25:
	/* 0xa25: je     a93 <kprobe_unwind_dotnet+0xa93> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa25, 0xa93, x86_l_a93);
x86_l_a27:
	/* 0xa27: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_a2a:
	/* 0xa2a: jmp    a9d <kprobe_unwind_dotnet+0xa9d> */
	X86_SIM_X86_JMP(0xa2a, 0xa9d, x86_l_a9d);
x86_l_a2c:
	/* 0xa2c: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_a31:
	/* 0xa31: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_a38:
	/* 0xa38: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a3b:
	/* 0xa3b: jne    aa7 <kprobe_unwind_dotnet+0xaa7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa3b, 0xaa7, x86_l_aa7);
x86_l_a3d:
	/* 0xa3d: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_a44:
	/* 0xa44: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_a48:
	/* 0xa48: jb     af6 <kprobe_unwind_dotnet+0xaf6> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa48, 0xaf6, x86_l_af6);
x86_l_a4e:
	/* 0xa4e: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_a55:
	/* 0xa55: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a59:
	/* 0xa59: jne    be9 <kprobe_unwind_dotnet+0xbe9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa59, 0xbe9, x86_l_be9);
x86_l_a5f:
	/* 0xa5f: mov    DWORD PTR [rsp+0xc],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607554ULL);
x86_l_a67:
	/* 0xa67: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_a6e:
	/* 0xa6e: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a73:
	/* 0xa73: call   a78 <kprobe_unwind_dotnet+0xa78> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a78:
	/* 0xa78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a7b:
	/* 0xa7b: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a80:
	/* 0xa80: je     446 <kprobe_unwind_dotnet+0x446> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa80, 0x446, x86_l_446);
x86_l_a86:
	/* 0xa86: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_a89:
	/* 0xa89: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_a8e:
	/* 0xa8e: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0xa8e, 0x7126, x86_l_7126);
x86_l_a93:
	/* 0xa93: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a97:
	/* 0xa97: jne    1957 <kprobe_unwind_dotnet+0x1957> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa97, 0x1957, x86_l_1957);
x86_l_a9d:
	/* 0xa9d: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_aa2:
	/* 0xaa2: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0xaa2, 0x7126, x86_l_7126);
x86_l_aa7:
	/* 0xaa7: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_aae:
	/* 0xaae: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ab3:
	/* 0xab3: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_ab8:
	/* 0xab8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_abb:
	/* 0xabb: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_abe:
	/* 0xabe: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_ac3:
	/* 0xac3: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_aca:
	/* 0xaca: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_acf:
	/* 0xacf: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ad2:
	/* 0xad2: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_ad5:
	/* 0xad5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad8:
	/* 0xad8: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_add:
	/* 0xadd: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ae0:
	/* 0xae0: call   ae5 <kprobe_unwind_dotnet+0xae5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_ae5:
	/* 0xae5: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_aec:
	/* 0xaec: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_af0:
	/* 0xaf0: jae    a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xaf0, 0xa4e, x86_l_a4e);
x86_l_af6:
	/* 0xaf6: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_afb:
	/* 0xafb: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_afe:
	/* 0xafe: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_b02:
	/* 0xb02: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b05:
	/* 0xb05: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_b08:
	/* 0xb08: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_b0f:
	/* 0xb0f: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_b13:
	/* 0xb13: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_b1b:
	/* 0xb1b: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_b23:
	/* 0xb23: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_b2c:
	/* 0xb2c: movzx  ecx,BYTE PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 136ULL);
x86_l_b34:
	/* 0xb34: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_b3c:
	/* 0xb3c: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_b48:
	/* 0xb48: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_b53:
	/* 0xb53: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_b5b:
	/* 0xb5b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_b62:
	/* 0xb62: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b67:
	/* 0xb67: call   b6c <kprobe_unwind_dotnet+0xb6c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b6c:
	/* 0xb6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b6f:
	/* 0xb6f: je     b90 <kprobe_unwind_dotnet+0xb90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb6f, 0xb90, x86_l_b90);
x86_l_b71:
	/* 0xb71: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_b74:
	/* 0xb74: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_b79:
	/* 0xb79: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_b80:
	/* 0xb80: mov    r13,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b83:
	/* 0xb83: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b86:
	/* 0xb86: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b89:
	/* 0xb89: jne    bb5 <kprobe_unwind_dotnet+0xbb5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb89, 0xbb5, x86_l_bb5);
x86_l_b8b:
	/* 0xb8b: jmp    224a <kprobe_unwind_dotnet+0x224a> */
	X86_SIM_X86_JMP(0xb8b, 0x224a, x86_l_224a);
x86_l_b90:
	/* 0xb90: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_b97:
	/* 0xb97: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b9b:
	/* 0xb9b: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_ba0:
	/* 0xba0: jne    e52 <kprobe_unwind_dotnet+0xe52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xba0, 0xe52, x86_l_e52);
x86_l_ba6:
	/* 0xba6: mov    r13,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ba9:
	/* 0xba9: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bac:
	/* 0xbac: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_baf:
	/* 0xbaf: je     224a <kprobe_unwind_dotnet+0x224a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbaf, 0x224a, x86_l_224a);
x86_l_bb5:
	/* 0xbb5: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_bb7:
	/* 0xbb7: jne    c4f <kprobe_unwind_dotnet+0xc4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbb7, 0xc4f, x86_l_c4f);
x86_l_bbd:
	/* 0xbbd: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bc0:
	/* 0xbc0: shr    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_bc4:
	/* 0xbc4: je     cdd <kprobe_unwind_dotnet+0xcdd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc4, 0xcdd, x86_l_cdd);
x86_l_bca:
	/* 0xbca: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bce:
	/* 0xbce: jne    21e6 <kprobe_unwind_dotnet+0x21e6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbce, 0x21e6, x86_l_21e6);
x86_l_bd4:
	/* 0xbd4: mov    DWORD PTR [r14+0xf28],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108491ULL);
x86_l_bdf:
	/* 0xbdf: mov    eax,0xfab */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4011ULL);
x86_l_be4:
	/* 0xbe4: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0xbe4, 0x7126, x86_l_7126);
x86_l_be9:
	/* 0xbe9: movabs rax,0xa6c6c75662073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2933962849001587ULL);
x86_l_bf3:
	/* 0xbf3: mov    QWORD PTR [rsp+0x2d],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 45ULL);
x86_l_bf8:
	/* 0xbf8: movabs rax,0x66207369206b6361 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359008686476059489ULL);
x86_l_c02:
	/* 0xc02: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c07:
	/* 0xc07: movabs rax,0x7473203a656d6172 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8391085965903225202ULL);
x86_l_c11:
	/* 0xc11: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c16:
	/* 0xc16: movabs rax,0x662068737570206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358996636224200815ULL);
x86_l_c20:
	/* 0xc20: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c25:
	/* 0xc25: movabs rax,0x7420656c62616e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367799623835807349ULL);
x86_l_c2f:
	/* 0xc2f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c34:
	/* 0xc34: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c39:
	/* 0xc39: mov    esi,0x25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_c3e:
	/* 0xc3e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c40:
	/* 0xc40: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c42:
	/* 0xc42: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c45:
	/* 0xc45: call   c4a <kprobe_unwind_dotnet+0xc4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_c4a:
	/* 0xc4a: jmp    a5f <kprobe_unwind_dotnet+0xa5f> */
	X86_SIM_X86_JMP(0xc4a, 0xa5f, x86_l_a5f);
x86_l_c4f:
	/* 0xc4f: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_c59:
	/* 0xc59: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c5e:
	/* 0xc5e: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_c68:
	/* 0xc68: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c6d:
	/* 0xc6d: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_c77:
	/* 0xc77: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c7c:
	/* 0xc7c: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_c86:
	/* 0xc86: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c8b:
	/* 0xc8b: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_c95:
	/* 0xc95: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c9a:
	/* 0xc9a: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_ca4:
	/* 0xca4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ca9:
	/* 0xca9: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_cae:
	/* 0xcae: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_cb5:
	/* 0xcb5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cba:
	/* 0xcba: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_cbf:
	/* 0xcbf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cc1:
	/* 0xcc1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cc4:
	/* 0xcc4: call   cc9 <kprobe_unwind_dotnet+0xcc9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_cc9:
	/* 0xcc9: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_cd0:
	/* 0xcd0: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cd3:
	/* 0xcd3: shr    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_cd7:
	/* 0xcd7: jne    bca <kprobe_unwind_dotnet+0xbca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcd7, 0xbca, x86_l_bca);
x86_l_cdd:
	/* 0xcdd: cmp    r13,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_ce4:
	/* 0xce4: ja     d05 <kprobe_unwind_dotnet+0xd05> */
	X86_SIM_X86_JCC(X86_CC_A, 0xce4, 0xd05, x86_l_d05);
x86_l_ce6:
	/* 0xce6: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cea:
	/* 0xcea: jne    236e <kprobe_unwind_dotnet+0x236e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcea, 0x236e, x86_l_236e);
x86_l_cf0:
	/* 0xcf0: mov    DWORD PTR [r14+0xf28],0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108529ULL);
x86_l_cfb:
	/* 0xcfb: mov    eax,0xfae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4014ULL);
x86_l_d00:
	/* 0xd00: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0xd00, 0x7126, x86_l_7126);
x86_l_d05:
	/* 0xd05: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d08:
	/* 0xd08: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_d10:
	/* 0xd10: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_d16:
	/* 0xd16: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_d1d:
	/* 0xd1d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_d24:
	/* 0xd24: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d29:
	/* 0xd29: call   d2e <kprobe_unwind_dotnet+0xd2e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d2e:
	/* 0xd2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d31:
	/* 0xd31: je     80cd <kprobe_unwind_dotnet+0x80cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd31, 0x80cd, x86_l_80cd);
x86_l_d37:
	/* 0xd37: mov    QWORD PTR [rsp+0x88],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_d3f:
	/* 0xd3f: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_d49:
	/* 0xd49: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d4d:
	/* 0xd4d: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d50:
	/* 0xd50: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d53:
	/* 0xd53: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_d5a:
	/* 0xd5a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d5d:
	/* 0xd5d: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_d64:
	/* 0xd64: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_d68:
	/* 0xd68: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d6b:
	/* 0xd6b: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_d6e:
	/* 0xd6e: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_d75:
	/* 0xd75: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d79:
	/* 0xd79: jne    111d <kprobe_unwind_dotnet+0x111d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd79, 0x111d, x86_l_111d);
x86_l_d7f:
	/* 0xd7f: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d83:
	/* 0xd83: jne    1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd83, 0x1a76, x86_l_1a76);
x86_l_d89:
	/* 0xd89: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_d90:
	/* 0xd90: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d95:
	/* 0xd95: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_d9c:
	/* 0xd9c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_da3:
	/* 0xda3: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_da8:
	/* 0xda8: call   dad <kprobe_unwind_dotnet+0xdad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_dad:
	/* 0xdad: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_db3:
	/* 0xdb3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_db6:
	/* 0xdb6: je     1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb6, 0x1a76, x86_l_1a76);
x86_l_dbc:
	/* 0xdbc: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dbf:
	/* 0xdbf: ja     dc7 <kprobe_unwind_dotnet+0xdc7> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdbf, 0xdc7, x86_l_dc7);
x86_l_dc1:
	/* 0xdc1: cmp    QWORD PTR [rax+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dc5:
	/* 0xdc5: jae    ddb <kprobe_unwind_dotnet+0xddb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xdc5, 0xddb, x86_l_ddb);
x86_l_dc7:
	/* 0xdc7: cmp    QWORD PTR [rax+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dcb:
	/* 0xdcb: ja     1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdcb, 0x1a76, x86_l_1a76);
x86_l_dd1:
	/* 0xdd1: cmp    QWORD PTR [rax+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_dd5:
	/* 0xdd5: jb     1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JCC(X86_CC_B, 0xdd5, 0x1a76, x86_l_1a76);
x86_l_ddb:
	/* 0xddb: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ddf:
	/* 0xddf: jne    19ce <kprobe_unwind_dotnet+0x19ce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xddf, 0x19ce, x86_l_19ce);
x86_l_de5:
	/* 0xde5: mov    ecx,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_dec:
	/* 0xdec: mov    edx,DWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_def:
	/* 0xdef: bt     ecx,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_df2:
	/* 0xdf2: jae    1a3b <kprobe_unwind_dotnet+0x1a3b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xdf2, 0x1a3b, x86_l_1a3b);
x86_l_df8:
	/* 0xdf8: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dfc:
	/* 0xdfc: je     1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdfc, 0x1a76, x86_l_1a76);
x86_l_e02:
	/* 0xe02: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_e0c:
	/* 0xe0c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e11:
	/* 0xe11: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_e1b:
	/* 0xe1b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e20:
	/* 0xe20: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_e2a:
	/* 0xe2a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e2f:
	/* 0xe2f: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_e37:
	/* 0xe37: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e3c:
	/* 0xe3c: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_e41:
	/* 0xe41: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e43:
	/* 0xe43: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e45:
	/* 0xe45: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e48:
	/* 0xe48: call   e4d <kprobe_unwind_dotnet+0xe4d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_e4d:
	/* 0xe4d: jmp    1a76 <kprobe_unwind_dotnet+0x1a76> */
	X86_SIM_X86_JMP(0xe4d, 0x1a76, x86_l_1a76);
x86_l_e52:
	/* 0xe52: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_e5c:
	/* 0xe5c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_e61:
	/* 0xe61: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_e6b:
	/* 0xe6b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e70:
	/* 0xe70: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_e7a:
	/* 0xe7a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e7f:
	/* 0xe7f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_e89:
	/* 0xe89: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e8e:
	/* 0xe8e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_e98:
	/* 0xe98: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e9d:
	/* 0xe9d: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_ea7:
	/* 0xea7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eac:
	/* 0xeac: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_eb0:
	/* 0xeb0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eb5:
	/* 0xeb5: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_eba:
	/* 0xeba: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ebc:
	/* 0xebc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ebf:
	/* 0xebf: call   ec4 <kprobe_unwind_dotnet+0xec4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_ec4:
	/* 0xec4: mov    r13,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ec7:
	/* 0xec7: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eca:
	/* 0xeca: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_ecd:
	/* 0xecd: jne    bb5 <kprobe_unwind_dotnet+0xbb5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xecd, 0xbb5, x86_l_bb5);
x86_l_ed3:
	/* 0xed3: jmp    224a <kprobe_unwind_dotnet+0x224a> */
	X86_SIM_X86_JMP(0xed3, 0x224a, x86_l_224a);
x86_l_ed8:
	/* 0xed8: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_edb:
	/* 0xedb: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_edf:
	/* 0xedf: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_ee9:
	/* 0xee9: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_eee:
	/* 0xeee: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_ef8:
	/* 0xef8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_efd:
	/* 0xefd: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_f07:
	/* 0xf07: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f0c:
	/* 0xf0c: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_f16:
	/* 0xf16: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_f1b:
	/* 0xf1b: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_f25:
	/* 0xf25: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f2a:
	/* 0xf2a: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_f34:
	/* 0xf34: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f39:
	/* 0xf39: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_f43:
	/* 0xf43: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f48:
	/* 0xf48: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f4d:
	/* 0xf4d: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_f52:
	/* 0xf52: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f55:
	/* 0xf55: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f58:
	/* 0xf58: call   f5d <kprobe_unwind_dotnet+0xf5d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_f5d:
	/* 0xf5d: jmp    3a1 <kprobe_unwind_dotnet+0x3a1> */
	X86_SIM_X86_JMP(0xf5d, 0x3a1, x86_l_3a1);
x86_l_f62:
	/* 0xf62: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_f64:
	/* 0xf64: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_f6e:
	/* 0xf6e: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_f73:
	/* 0xf73: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_f7d:
	/* 0xf7d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f82:
	/* 0xf82: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_f8c:
	/* 0xf8c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_f91:
	/* 0xf91: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_f9b:
	/* 0xf9b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_fa0:
	/* 0xfa0: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_faa:
	/* 0xfaa: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_faf:
	/* 0xfaf: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_fb9:
	/* 0xfb9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fbe:
	/* 0xfbe: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fc3:
	/* 0xfc3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_fc8:
	/* 0xfc8: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_fcb:
	/* 0xfcb: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fce:
	/* 0xfce: call   fd3 <kprobe_unwind_dotnet+0xfd3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_fd3:
	/* 0xfd3: jmp    9e2 <kprobe_unwind_dotnet+0x9e2> */
	X86_SIM_X86_JMP(0xfd3, 0x9e2, x86_l_9e2);
x86_l_fd8:
	/* 0xfd8: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_fe2:
	/* 0xfe2: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_fe7:
	/* 0xfe7: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_ff1:
	/* 0xff1: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ff6:
	/* 0xff6: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_1000:
	/* 0x1000: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1005:
	/* 0x1005: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_100f:
	/* 0x100f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1014:
	/* 0x1014: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_101e:
	/* 0x101e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1023:
	/* 0x1023: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_102d:
	/* 0x102d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1032:
	/* 0x1032: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1036:
	/* 0x1036: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_103b:
	/* 0x103b: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_1040:
	/* 0x1040: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1042:
	/* 0x1042: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1045:
	/* 0x1045: call   104a <kprobe_unwind_dotnet+0x104a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_104a:
	/* 0x104a: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_104f:
	/* 0x104f: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1051:
	/* 0x1051: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1055:
	/* 0x1055: je     3fc <kprobe_unwind_dotnet+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1055, 0x3fc, x86_l_3fc);
x86_l_105b:
	/* 0x105b: jmp    1850 <kprobe_unwind_dotnet+0x1850> */
	X86_SIM_X86_JMP(0x105b, 0x1850, x86_l_1850);
x86_l_1060:
	/* 0x1060: movabs rax,0xa6c6c75662073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2933962849001587ULL);
x86_l_106a:
	/* 0x106a: mov    QWORD PTR [rsp+0x2d],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 45ULL);
x86_l_106f:
	/* 0x106f: movabs rax,0x66207369206b6361 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359008686476059489ULL);
x86_l_1079:
	/* 0x1079: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_107e:
	/* 0x107e: movabs rax,0x7473203a656d6172 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8391085965903225202ULL);
x86_l_1088:
	/* 0x1088: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_108d:
	/* 0x108d: movabs rax,0x662068737570206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358996636224200815ULL);
x86_l_1097:
	/* 0x1097: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_109c:
	/* 0x109c: movabs rax,0x7420656c62616e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367799623835807349ULL);
x86_l_10a6:
	/* 0x10a6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10ab:
	/* 0x10ab: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10b0:
	/* 0x10b0: mov    esi,0x25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_10b5:
	/* 0x10b5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b7:
	/* 0x10b7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b9:
	/* 0x10b9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10bc:
	/* 0x10bc: call   10c1 <kprobe_unwind_dotnet+0x10c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_10c1:
	/* 0x10c1: jmp    424 <kprobe_unwind_dotnet+0x424> */
	X86_SIM_X86_JMP(0x10c1, 0x424, x86_l_424);
x86_l_10c6:
	/* 0x10c6: movabs rax,0xa726564616568 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2940529568474472ULL);
x86_l_10d0:
	/* 0x10d0: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_10d5:
	/* 0x10d5: movabs rax,0x65682065646f6320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7307126015257436960ULL);
x86_l_10df:
	/* 0x10df: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_10e4:
	/* 0x10e4: movabs rax,0x646162203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7233170367155350816ULL);
x86_l_10ee:
	/* 0x10ee: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_10f3:
	/* 0x10f3: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_10fd:
	/* 0x10fd: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1102:
	/* 0x1102: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1107:
	/* 0x1107: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_110c:
	/* 0x110c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_110e:
	/* 0x110e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1110:
	/* 0x1110: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1113:
	/* 0x1113: call   1118 <kprobe_unwind_dotnet+0x1118> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1118:
	/* 0x1118: jmp    a04 <kprobe_unwind_dotnet+0xa04> */
	X86_SIM_X86_JMP(0x1118, 0xa04, x86_l_a04);
x86_l_111d:
	/* 0x111d: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_1127:
	/* 0x1127: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_112c:
	/* 0x112c: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_1136:
	/* 0x1136: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_113b:
	/* 0x113b: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_1145:
	/* 0x1145: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_114a:
	/* 0x114a: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_1154:
	/* 0x1154: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1159:
	/* 0x1159: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_1163:
	/* 0x1163: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1168:
	/* 0x1168: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_1172:
	/* 0x1172: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1177:
	/* 0x1177: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_117e:
	/* 0x117e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1183:
	/* 0x1183: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_1188:
	/* 0x1188: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_118b:
	/* 0x118b: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_118e:
	/* 0x118e: call   1193 <kprobe_unwind_dotnet+0x1193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1193:
	/* 0x1193: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1197:
	/* 0x1197: je     d7f <kprobe_unwind_dotnet+0xd7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1197, 0xd7f, x86_l_d7f);
x86_l_119d:
	/* 0x119d: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_11a7:
	/* 0x11a7: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_11ac:
	/* 0x11ac: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_11b6:
	/* 0x11b6: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_11bb:
	/* 0x11bb: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_11c5:
	/* 0x11c5: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11ca:
	/* 0x11ca: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_11d4:
	/* 0x11d4: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11d9:
	/* 0x11d9: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_11e3:
	/* 0x11e3: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11e8:
	/* 0x11e8: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11ed:
	/* 0x11ed: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_11f4:
	/* 0x11f4: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_11fb:
	/* 0x11fb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1200:
	/* 0x1200: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_1205:
	/* 0x1205: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1208:
	/* 0x1208: call   120d <kprobe_unwind_dotnet+0x120d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_120d:
	/* 0x120d: jmp    d7f <kprobe_unwind_dotnet+0xd7f> */
	X86_SIM_X86_JMP(0x120d, 0xd7f, x86_l_d7f);
x86_l_1212:
	/* 0x1212: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_121c:
	/* 0x121c: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_1221:
	/* 0x1221: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_122b:
	/* 0x122b: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1230:
	/* 0x1230: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_123a:
	/* 0x123a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_123f:
	/* 0x123f: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_1249:
	/* 0x1249: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_124e:
	/* 0x124e: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_1258:
	/* 0x1258: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_125d:
	/* 0x125d: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_1267:
	/* 0x1267: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_126c:
	/* 0x126c: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1276:
	/* 0x1276: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_127b:
	/* 0x127b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1280:
	/* 0x1280: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_1285:
	/* 0x1285: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1288:
	/* 0x1288: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_128b:
	/* 0x128b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_128e:
	/* 0x128e: call   1293 <kprobe_unwind_dotnet+0x1293> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1293:
	/* 0x1293: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1295:
	/* 0x1295: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1298:
	/* 0x1298: jne    552 <kprobe_unwind_dotnet+0x552> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1298, 0x552, x86_l_552);
x86_l_129e:
	/* 0x129e: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_12a5:
	/* 0x12a5: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_12aa:
	/* 0x12aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ad:
	/* 0x12ad: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12ad, 0x17a5, x86_l_17a5);
x86_l_12b3:
	/* 0x12b3: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_12ba:
	/* 0x12ba: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_12bf:
	/* 0x12bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12c2:
	/* 0x12c2: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12c2, 0x17a5, x86_l_17a5);
x86_l_12c8:
	/* 0x12c8: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_12cf:
	/* 0x12cf: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_12d4:
	/* 0x12d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d7:
	/* 0x12d7: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12d7, 0x17a5, x86_l_17a5);
x86_l_12dd:
	/* 0x12dd: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_12e4:
	/* 0x12e4: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_12e9:
	/* 0x12e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ec:
	/* 0x12ec: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12ec, 0x17a5, x86_l_17a5);
x86_l_12f2:
	/* 0x12f2: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_12f9:
	/* 0x12f9: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_12fe:
	/* 0x12fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1301:
	/* 0x1301: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1301, 0x17a5, x86_l_17a5);
x86_l_1307:
	/* 0x1307: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_130e:
	/* 0x130e: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_1313:
	/* 0x1313: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1316:
	/* 0x1316: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1316, 0x17a5, x86_l_17a5);
x86_l_131c:
	/* 0x131c: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_1323:
	/* 0x1323: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_1328:
	/* 0x1328: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_132b:
	/* 0x132b: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x132b, 0x17a5, x86_l_17a5);
x86_l_1331:
	/* 0x1331: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_1338:
	/* 0x1338: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_133d:
	/* 0x133d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1340:
	/* 0x1340: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1340, 0x17a5, x86_l_17a5);
x86_l_1346:
	/* 0x1346: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_134d:
	/* 0x134d: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_1352:
	/* 0x1352: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1355:
	/* 0x1355: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1355, 0x17a5, x86_l_17a5);
x86_l_135b:
	/* 0x135b: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_1362:
	/* 0x1362: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_1367:
	/* 0x1367: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_136a:
	/* 0x136a: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x136a, 0x17a5, x86_l_17a5);
x86_l_1370:
	/* 0x1370: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_1377:
	/* 0x1377: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_137c:
	/* 0x137c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_137f:
	/* 0x137f: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x137f, 0x17a5, x86_l_17a5);
x86_l_1385:
	/* 0x1385: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_138c:
	/* 0x138c: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_1391:
	/* 0x1391: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1394:
	/* 0x1394: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1394, 0x17a5, x86_l_17a5);
x86_l_139a:
	/* 0x139a: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_13a1:
	/* 0x13a1: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_13a6:
	/* 0x13a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13a9:
	/* 0x13a9: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13a9, 0x17a5, x86_l_17a5);
x86_l_13af:
	/* 0x13af: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_13b6:
	/* 0x13b6: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_13bb:
	/* 0x13bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13be:
	/* 0x13be: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13be, 0x17a5, x86_l_17a5);
x86_l_13c4:
	/* 0x13c4: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_13cb:
	/* 0x13cb: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_13d0:
	/* 0x13d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13d3:
	/* 0x13d3: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13d3, 0x17a5, x86_l_17a5);
x86_l_13d9:
	/* 0x13d9: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_13e0:
	/* 0x13e0: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_13e5:
	/* 0x13e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13e8:
	/* 0x13e8: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13e8, 0x17a5, x86_l_17a5);
x86_l_13ee:
	/* 0x13ee: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_13f5:
	/* 0x13f5: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_13fa:
	/* 0x13fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13fd:
	/* 0x13fd: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13fd, 0x17a5, x86_l_17a5);
x86_l_1403:
	/* 0x1403: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_140a:
	/* 0x140a: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_140f:
	/* 0x140f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1412:
	/* 0x1412: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1412, 0x17a5, x86_l_17a5);
x86_l_1418:
	/* 0x1418: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_141f:
	/* 0x141f: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_1424:
	/* 0x1424: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1427:
	/* 0x1427: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1427, 0x17a5, x86_l_17a5);
x86_l_142d:
	/* 0x142d: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_1434:
	/* 0x1434: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_1439:
	/* 0x1439: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_143c:
	/* 0x143c: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x143c, 0x17a5, x86_l_17a5);
x86_l_1442:
	/* 0x1442: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_1449:
	/* 0x1449: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_144e:
	/* 0x144e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1451:
	/* 0x1451: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1451, 0x17a5, x86_l_17a5);
x86_l_1457:
	/* 0x1457: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_145e:
	/* 0x145e: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_1463:
	/* 0x1463: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1466:
	/* 0x1466: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1466, 0x17a5, x86_l_17a5);
x86_l_146c:
	/* 0x146c: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_1473:
	/* 0x1473: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_1478:
	/* 0x1478: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_147b:
	/* 0x147b: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x147b, 0x17a5, x86_l_17a5);
x86_l_1481:
	/* 0x1481: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_1488:
	/* 0x1488: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_148d:
	/* 0x148d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1490:
	/* 0x1490: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1490, 0x17a5, x86_l_17a5);
x86_l_1496:
	/* 0x1496: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_149d:
	/* 0x149d: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_14a2:
	/* 0x14a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a5:
	/* 0x14a5: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14a5, 0x17a5, x86_l_17a5);
x86_l_14ab:
	/* 0x14ab: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_14b2:
	/* 0x14b2: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_14b7:
	/* 0x14b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14ba:
	/* 0x14ba: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14ba, 0x17a5, x86_l_17a5);
x86_l_14c0:
	/* 0x14c0: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_14c7:
	/* 0x14c7: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_14cc:
	/* 0x14cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14cf:
	/* 0x14cf: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14cf, 0x17a5, x86_l_17a5);
x86_l_14d5:
	/* 0x14d5: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_14dc:
	/* 0x14dc: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_14e1:
	/* 0x14e1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e4:
	/* 0x14e4: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14e4, 0x17a5, x86_l_17a5);
x86_l_14ea:
	/* 0x14ea: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_14f1:
	/* 0x14f1: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_14f6:
	/* 0x14f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14f9:
	/* 0x14f9: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14f9, 0x17a5, x86_l_17a5);
x86_l_14ff:
	/* 0x14ff: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_1506:
	/* 0x1506: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_150b:
	/* 0x150b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_150e:
	/* 0x150e: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x150e, 0x17a5, x86_l_17a5);
x86_l_1514:
	/* 0x1514: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_151b:
	/* 0x151b: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_1520:
	/* 0x1520: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1523:
	/* 0x1523: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1523, 0x17a5, x86_l_17a5);
x86_l_1529:
	/* 0x1529: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_1530:
	/* 0x1530: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_1535:
	/* 0x1535: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1538:
	/* 0x1538: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1538, 0x17a5, x86_l_17a5);
x86_l_153e:
	/* 0x153e: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_1545:
	/* 0x1545: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_154a:
	/* 0x154a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_154d:
	/* 0x154d: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x154d, 0x17a5, x86_l_17a5);
x86_l_1553:
	/* 0x1553: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_155a:
	/* 0x155a: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_155f:
	/* 0x155f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1562:
	/* 0x1562: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1562, 0x17a5, x86_l_17a5);
x86_l_1568:
	/* 0x1568: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_156f:
	/* 0x156f: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_1574:
	/* 0x1574: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1577:
	/* 0x1577: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1577, 0x17a5, x86_l_17a5);
x86_l_157d:
	/* 0x157d: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_1584:
	/* 0x1584: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_1589:
	/* 0x1589: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_158c:
	/* 0x158c: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x158c, 0x17a5, x86_l_17a5);
x86_l_1592:
	/* 0x1592: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_1599:
	/* 0x1599: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_159e:
	/* 0x159e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15a1:
	/* 0x15a1: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15a1, 0x17a5, x86_l_17a5);
x86_l_15a7:
	/* 0x15a7: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_15ae:
	/* 0x15ae: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_15b3:
	/* 0x15b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15b6:
	/* 0x15b6: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15b6, 0x17a5, x86_l_17a5);
x86_l_15bc:
	/* 0x15bc: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_15c3:
	/* 0x15c3: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_15c8:
	/* 0x15c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15cb:
	/* 0x15cb: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15cb, 0x17a5, x86_l_17a5);
x86_l_15d1:
	/* 0x15d1: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_15d8:
	/* 0x15d8: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_15dd:
	/* 0x15dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15e0:
	/* 0x15e0: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15e0, 0x17a5, x86_l_17a5);
x86_l_15e6:
	/* 0x15e6: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_15ed:
	/* 0x15ed: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_15f2:
	/* 0x15f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15f5:
	/* 0x15f5: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15f5, 0x17a5, x86_l_17a5);
x86_l_15fb:
	/* 0x15fb: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_1602:
	/* 0x1602: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_1607:
	/* 0x1607: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_160a:
	/* 0x160a: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x160a, 0x17a5, x86_l_17a5);
x86_l_1610:
	/* 0x1610: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_1617:
	/* 0x1617: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_161c:
	/* 0x161c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_161f:
	/* 0x161f: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x161f, 0x17a5, x86_l_17a5);
x86_l_1625:
	/* 0x1625: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_162c:
	/* 0x162c: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_1631:
	/* 0x1631: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1634:
	/* 0x1634: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1634, 0x17a5, x86_l_17a5);
x86_l_163a:
	/* 0x163a: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_1641:
	/* 0x1641: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_1646:
	/* 0x1646: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1649:
	/* 0x1649: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1649, 0x17a5, x86_l_17a5);
x86_l_164f:
	/* 0x164f: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_1656:
	/* 0x1656: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_165b:
	/* 0x165b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165e:
	/* 0x165e: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x165e, 0x17a5, x86_l_17a5);
x86_l_1664:
	/* 0x1664: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_166b:
	/* 0x166b: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_1670:
	/* 0x1670: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1673:
	/* 0x1673: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1673, 0x17a5, x86_l_17a5);
x86_l_1679:
	/* 0x1679: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_1680:
	/* 0x1680: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_1685:
	/* 0x1685: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1688:
	/* 0x1688: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1688, 0x17a5, x86_l_17a5);
x86_l_168e:
	/* 0x168e: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_1695:
	/* 0x1695: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_169a:
	/* 0x169a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_169d:
	/* 0x169d: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x169d, 0x17a5, x86_l_17a5);
x86_l_16a3:
	/* 0x16a3: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_16aa:
	/* 0x16aa: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_16af:
	/* 0x16af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16b2:
	/* 0x16b2: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16b2, 0x17a5, x86_l_17a5);
x86_l_16b8:
	/* 0x16b8: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_16bf:
	/* 0x16bf: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_16c4:
	/* 0x16c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16c7:
	/* 0x16c7: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16c7, 0x17a5, x86_l_17a5);
x86_l_16cd:
	/* 0x16cd: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_16d4:
	/* 0x16d4: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_16d9:
	/* 0x16d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16dc:
	/* 0x16dc: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16dc, 0x17a5, x86_l_17a5);
x86_l_16e2:
	/* 0x16e2: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_16e9:
	/* 0x16e9: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_16ee:
	/* 0x16ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16f1:
	/* 0x16f1: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16f1, 0x17a5, x86_l_17a5);
x86_l_16f7:
	/* 0x16f7: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_16fe:
	/* 0x16fe: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_1703:
	/* 0x1703: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1706:
	/* 0x1706: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1706, 0x17a5, x86_l_17a5);
x86_l_170c:
	/* 0x170c: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_1713:
	/* 0x1713: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_1718:
	/* 0x1718: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_171b:
	/* 0x171b: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x171b, 0x17a5, x86_l_17a5);
x86_l_1721:
	/* 0x1721: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_1728:
	/* 0x1728: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_172d:
	/* 0x172d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1730:
	/* 0x1730: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1730, 0x17a5, x86_l_17a5);
x86_l_1732:
	/* 0x1732: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_1739:
	/* 0x1739: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_173e:
	/* 0x173e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1741:
	/* 0x1741: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1741, 0x17a5, x86_l_17a5);
x86_l_1743:
	/* 0x1743: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_174a:
	/* 0x174a: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_174f:
	/* 0x174f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1752:
	/* 0x1752: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1752, 0x17a5, x86_l_17a5);
x86_l_1754:
	/* 0x1754: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_175b:
	/* 0x175b: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_1760:
	/* 0x1760: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1763:
	/* 0x1763: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1763, 0x17a5, x86_l_17a5);
x86_l_1765:
	/* 0x1765: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_176c:
	/* 0x176c: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_1771:
	/* 0x1771: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1774:
	/* 0x1774: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1774, 0x17a5, x86_l_17a5);
x86_l_1776:
	/* 0x1776: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_177d:
	/* 0x177d: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_1782:
	/* 0x1782: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1785:
	/* 0x1785: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1785, 0x17a5, x86_l_17a5);
x86_l_1787:
	/* 0x1787: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_178e:
	/* 0x178e: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_1793:
	/* 0x1793: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1796:
	/* 0x1796: jne    17a5 <kprobe_unwind_dotnet+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1796, 0x17a5, x86_l_17a5);
x86_l_1798:
	/* 0x1798: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_17a0:
	/* 0x17a0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a3:
	/* 0x17a3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a5:
	/* 0x17a5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a7:
	/* 0x17a7: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17aa:
	/* 0x17aa: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_17ae:
	/* 0x17ae: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_17b2:
	/* 0x17b2: jne    17b7 <kprobe_unwind_dotnet+0x17b7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17b2, 0x17b7, x86_l_17b7);
x86_l_17b4:
	/* 0x17b4: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_17b7:
	/* 0x17b7: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_17ba:
	/* 0x17ba: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_17bc:
	/* 0x17bc: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_17bf:
	/* 0x17bf: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_17c1:
	/* 0x17c1: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_17c4:
	/* 0x17c4: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_17c7:
	/* 0x17c7: jb     560 <kprobe_unwind_dotnet+0x560> */
	X86_SIM_X86_JCC(X86_CC_B, 0x17c7, 0x560, x86_l_560);
x86_l_17cd:
	/* 0x17cd: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_17d4:
	/* 0x17d4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17d7:
	/* 0x17d7: jne    18c1 <kprobe_unwind_dotnet+0x18c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17d7, 0x18c1, x86_l_18c1);
x86_l_17dd:
	/* 0x17dd: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_17e0:
	/* 0x17e0: jne    3bd <kprobe_unwind_dotnet+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17e0, 0x3bd, x86_l_3bd);
x86_l_17e6:
	/* 0x17e6: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_17ee:
	/* 0x17ee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_17f5:
	/* 0x17f5: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_17fa:
	/* 0x17fa: call   17ff <kprobe_unwind_dotnet+0x17ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17ff:
	/* 0x17ff: mov    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1802:
	/* 0x1802: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1805:
	/* 0x1805: je     1829 <kprobe_unwind_dotnet+0x1829> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1805, 0x1829, x86_l_1829);
x86_l_1807:
	/* 0x1807: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_180a:
	/* 0x180a: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_180f:
	/* 0x180f: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1816:
	/* 0x1816: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_181b:
	/* 0x181b: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_181d:
	/* 0x181d: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1821:
	/* 0x1821: je     3fc <kprobe_unwind_dotnet+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1821, 0x3fc, x86_l_3fc);
x86_l_1827:
	/* 0x1827: jmp    1850 <kprobe_unwind_dotnet+0x1850> */
	X86_SIM_X86_JMP(0x1827, 0x1850, x86_l_1850);
x86_l_1829:
	/* 0x1829: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1830:
	/* 0x1830: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1834:
	/* 0x1834: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1839:
	/* 0x1839: jne    1ede <kprobe_unwind_dotnet+0x1ede> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1839, 0x1ede, x86_l_1ede);
x86_l_183f:
	/* 0x183f: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_1844:
	/* 0x1844: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1846:
	/* 0x1846: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_184a:
	/* 0x184a: je     3fc <kprobe_unwind_dotnet+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184a, 0x3fc, x86_l_3fc);
x86_l_1850:
	/* 0x1850: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_185a:
	/* 0x185a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_185f:
	/* 0x185f: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_1869:
	/* 0x1869: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_186e:
	/* 0x186e: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_1878:
	/* 0x1878: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_187d:
	/* 0x187d: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_1887:
	/* 0x1887: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_188c:
	/* 0x188c: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1896:
	/* 0x1896: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_189b:
	/* 0x189b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18a0:
	/* 0x18a0: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_18a5:
	/* 0x18a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18a7:
	/* 0x18a7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18aa:
	/* 0x18aa: call   18af <kprobe_unwind_dotnet+0x18af> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_18af:
	/* 0x18af: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_18b4:
	/* 0x18b4: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_18b6:
	/* 0x18b6: jne    409 <kprobe_unwind_dotnet+0x409> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b6, 0x409, x86_l_409);
x86_l_18bc:
	/* 0x18bc: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0x18bc, 0x7126, x86_l_7126);
x86_l_18c1:
	/* 0x18c1: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_18cb:
	/* 0x18cb: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_18d0:
	/* 0x18d0: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_18da:
	/* 0x18da: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_18df:
	/* 0x18df: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_18e9:
	/* 0x18e9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18ee:
	/* 0x18ee: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_18f8:
	/* 0x18f8: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18fd:
	/* 0x18fd: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_1907:
	/* 0x1907: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_190c:
	/* 0x190c: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_1916:
	/* 0x1916: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_191b:
	/* 0x191b: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1925:
	/* 0x1925: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_192a:
	/* 0x192a: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_1932:
	/* 0x1932: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1934:
	/* 0x1934: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1937:
	/* 0x1937: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_193c:
	/* 0x193c: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_1941:
	/* 0x1941: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1944:
	/* 0x1944: call   1949 <kprobe_unwind_dotnet+0x1949> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1949:
	/* 0x1949: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_194c:
	/* 0x194c: jne    3bd <kprobe_unwind_dotnet+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x194c, 0x3bd, x86_l_3bd);
x86_l_1952:
	/* 0x1952: jmp    17e6 <kprobe_unwind_dotnet+0x17e6> */
	X86_SIM_X86_JMP(0x1952, 0x17e6, x86_l_17e6);
x86_l_1957:
	/* 0x1957: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_1961:
	/* 0x1961: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1966:
	/* 0x1966: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_1970:
	/* 0x1970: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1975:
	/* 0x1975: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_197f:
	/* 0x197f: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1984:
	/* 0x1984: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_198e:
	/* 0x198e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1993:
	/* 0x1993: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_199d:
	/* 0x199d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19a2:
	/* 0x19a2: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_19ac:
	/* 0x19ac: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19b1:
	/* 0x19b1: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_19b5:
	/* 0x19b5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19ba:
	/* 0x19ba: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_19bf:
	/* 0x19bf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19c1:
	/* 0x19c1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19c4:
	/* 0x19c4: call   19c9 <kprobe_unwind_dotnet+0x19c9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_19c9:
	/* 0x19c9: jmp    a9d <kprobe_unwind_dotnet+0xa9d> */
	X86_SIM_X86_JMP(0x19c9, 0xa9d, x86_l_a9d);
x86_l_19ce:
	/* 0x19ce: movabs rcx,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_19d8:
	/* 0x19d8: mov    QWORD PTR [rsp+0x26],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_19dd:
	/* 0x19dd: movabs rcx,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_19e7:
	/* 0x19e7: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19ec:
	/* 0x19ec: movabs rcx,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_19f6:
	/* 0x19f6: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19fb:
	/* 0x19fb: movabs rcx,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_1a05:
	/* 0x1a05: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a0a:
	/* 0x1a0a: movzx  edx,WORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1a0e:
	/* 0x1a0e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a13:
	/* 0x1a13: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_1a18:
	/* 0x1a18: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a1a:
	/* 0x1a1a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a1d:
	/* 0x1a1d: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a20:
	/* 0x1a20: call   1a25 <kprobe_unwind_dotnet+0x1a25> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1a25:
	/* 0x1a25: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a28:
	/* 0x1a28: mov    ecx,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_1a2f:
	/* 0x1a2f: mov    edx,DWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a32:
	/* 0x1a32: bt     ecx,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1a35:
	/* 0x1a35: jb     df8 <kprobe_unwind_dotnet+0xdf8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a35, 0xdf8, x86_l_df8);
x86_l_1a3b:
	/* 0x1a3b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a3e:
	/* 0x1a3e: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1a46:
	/* 0x1a46: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1a4d:
	/* 0x1a4d: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1a52:
	/* 0x1a52: call   1a57 <kprobe_unwind_dotnet+0x1a57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a57:
	/* 0x1a57: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a5a:
	/* 0x1a5a: je     1a64 <kprobe_unwind_dotnet+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5a, 0x1a64, x86_l_1a64);
x86_l_1a5c:
	/* 0x1a5c: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1a5f:
	/* 0x1a5f: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a62:
	/* 0x1a62: jmp    1a71 <kprobe_unwind_dotnet+0x1a71> */
	X86_SIM_X86_JMP(0x1a62, 0x1a71, x86_l_1a71);
x86_l_1a64:
	/* 0x1a64: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a68:
	/* 0x1a68: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6b:
	/* 0x1a6b: jne    2022 <kprobe_unwind_dotnet+0x2022> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a6b, 0x2022, x86_l_2022);
x86_l_1a71:
	/* 0x1a71: movzx  r12d,WORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1a76:
	/* 0x1a76: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a78:
	/* 0x1a78: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1a7c:
	/* 0x1a7c: jne    7129 <kprobe_unwind_dotnet+0x7129> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a7c, 0x7129, x86_l_7129);
x86_l_1a82:
	/* 0x1a82: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1a89:
	/* 0x1a89: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1a90:
	/* 0x1a90: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1a97:
	/* 0x1a97: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_1a9f:
	/* 0x1a9f: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aa3:
	/* 0x1aa3: jne    1e41 <kprobe_unwind_dotnet+0x1e41> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1aa3, 0x1e41, x86_l_1e41);
x86_l_1aa9:
	/* 0x1aa9: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1aac:
	/* 0x1aac: jb     70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1aac, 0x70d6, x86_l_70d6);
x86_l_1ab2:
	/* 0x1ab2: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_1ab9:
	/* 0x1ab9: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1abc:
	/* 0x1abc: jae    70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1abc, 0x70d6, x86_l_70d6);
x86_l_1ac2:
	/* 0x1ac2: mov    ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1ac4:
	/* 0x1ac4: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1acb:
	/* 0x1acb: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1ad2:
	/* 0x1ad2: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1ad7:
	/* 0x1ad7: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_1adf:
	/* 0x1adf: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1ae2:
	/* 0x1ae2: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_1ae6:
	/* 0x1ae6: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_1aec:
	/* 0x1aec: jne    1b20 <kprobe_unwind_dotnet+0x1b20> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1aec, 0x1b20, x86_l_1b20);
x86_l_1aee:
	/* 0x1aee: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1af5:
	/* 0x1af5: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1afd:
	/* 0x1afd: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1b02:
	/* 0x1b02: call   1b07 <kprobe_unwind_dotnet+0x1b07> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1b07:
	/* 0x1b07: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b0a:
	/* 0x1b0a: jne    180 <kprobe_unwind_dotnet+0x180> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b0a, 0x180, x86_l_180);
x86_l_1b10:
	/* 0x1b10: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_1b18:
	/* 0x1b18: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1b1b:
	/* 0x1b1b: jmp    20ed <kprobe_unwind_dotnet+0x20ed> */
	X86_SIM_X86_JMP(0x1b1b, 0x20ed, x86_l_20ed);
x86_l_1b20:
	/* 0x1b20: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1b25:
	/* 0x1b25: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1b2a:
	/* 0x1b2a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1b2d:
	/* 0x1b2d: call   1b32 <kprobe_unwind_dotnet+0x1b32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1b32:
	/* 0x1b32: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b35:
	/* 0x1b35: jne    1c6 <kprobe_unwind_dotnet+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b35, 0x1c6, x86_l_1c6);
x86_l_1b3b:
	/* 0x1b3b: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1b3f:
	/* 0x1b3f: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1b46:
	/* 0x1b46: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1b4b:
	/* 0x1b4b: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1b52:
	/* 0x1b52: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1b57:
	/* 0x1b57: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1b5e:
	/* 0x1b5e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1b65:
	/* 0x1b65: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b68:
	/* 0x1b68: jne    1f66 <kprobe_unwind_dotnet+0x1f66> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b68, 0x1f66, x86_l_1f66);
x86_l_1b6e:
	/* 0x1b6e: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1b75:
	/* 0x1b75: jb     20ed <kprobe_unwind_dotnet+0x20ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b75, 0x20ed, x86_l_20ed);
x86_l_1b7b:
	/* 0x1b7b: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1b82:
	/* 0x1b82: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1b89:
	/* 0x1b89: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1b8c:
	/* 0x1b8c: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1b8f:
	/* 0x1b8f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1b96:
	/* 0x1b96: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b99:
	/* 0x1b99: jne    1fe9 <kprobe_unwind_dotnet+0x1fe9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b99, 0x1fe9, x86_l_1fe9);
x86_l_1b9f:
	/* 0x1b9f: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1ba2:
	/* 0x1ba2: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_1ba6:
	/* 0x1ba6: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_1bab:
	/* 0x1bab: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1bad:
	/* 0x1bad: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1bb0:
	/* 0x1bb0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bb2:
	/* 0x1bb2: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_1bb9:
	/* 0x1bb9: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_1bc1:
	/* 0x1bc1: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_1bc5:
	/* 0x1bc5: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_1bc8:
	/* 0x1bc8: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1bcb:
	/* 0x1bcb: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1bd3:
	/* 0x1bd3: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1bd7:
	/* 0x1bd7: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_1bdc:
	/* 0x1bdc: call   1be1 <kprobe_unwind_dotnet+0x1be1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1be1:
	/* 0x1be1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1be4:
	/* 0x1be4: je     1c19 <kprobe_unwind_dotnet+0x1c19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1be4, 0x1c19, x86_l_1c19);
x86_l_1be6:
	/* 0x1be6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1bed:
	/* 0x1bed: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf0:
	/* 0x1bf0: jne    1dd8 <kprobe_unwind_dotnet+0x1dd8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bf0, 0x1dd8, x86_l_1dd8);
x86_l_1bf6:
	/* 0x1bf6: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_1bfe:
	/* 0x1bfe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1c05:
	/* 0x1c05: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c0a:
	/* 0x1c0a: call   1c0f <kprobe_unwind_dotnet+0x1c0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c0f:
	/* 0x1c0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c12:
	/* 0x1c12: je     1c70 <kprobe_unwind_dotnet+0x1c70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c12, 0x1c70, x86_l_1c70);
x86_l_1c14:
	/* 0x1c14: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1c17:
	/* 0x1c17: jmp    1c80 <kprobe_unwind_dotnet+0x1c80> */
	X86_SIM_X86_JMP(0x1c17, 0x1c80, x86_l_1c80);
x86_l_1c19:
	/* 0x1c19: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_1c20:
	/* 0x1c20: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1c27:
	/* 0x1c27: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c2a:
	/* 0x1c2a: jne    2598 <kprobe_unwind_dotnet+0x2598> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c2a, 0x2598, x86_l_2598);
x86_l_1c30:
	/* 0x1c30: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1c33:
	/* 0x1c33: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_1c35:
	/* 0x1c35: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_1c38:
	/* 0x1c38: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_1c3a:
	/* 0x1c3a: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_1c3f:
	/* 0x1c3f: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1c42:
	/* 0x1c42: je     1d0d <kprobe_unwind_dotnet+0x1d0d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c42, 0x1d0d, x86_l_1d0d);
x86_l_1c48:
	/* 0x1c48: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_1c4c:
	/* 0x1c4c: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1c4f:
	/* 0x1c4f: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1c52:
	/* 0x1c52: jne    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c52, 0x20a7, x86_l_20a7);
x86_l_1c58:
	/* 0x1c58: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1c5b:
	/* 0x1c5b: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_1c5e:
	/* 0x1c5e: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1c61:
	/* 0x1c61: je     1e19 <kprobe_unwind_dotnet+0x1e19> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c61, 0x1e19, x86_l_1e19);
x86_l_1c67:
	/* 0x1c67: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_1c6b:
	/* 0x1c6b: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1c6b, 0x20a7, x86_l_20a7);
x86_l_1c70:
	/* 0x1c70: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1c77:
	/* 0x1c77: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c7a:
	/* 0x1c7a: jne    2698 <kprobe_unwind_dotnet+0x2698> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c7a, 0x2698, x86_l_2698);
x86_l_1c80:
	/* 0x1c80: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_1c85:
	/* 0x1c85: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c87:
	/* 0x1c87: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1c8e:
	/* 0x1c8e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c91:
	/* 0x1c91: jne    2e28 <kprobe_unwind_dotnet+0x2e28> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c91, 0x2e28, x86_l_2e28);
x86_l_1c97:
	/* 0x1c97: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_1c9c:
	/* 0x1c9c: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_1c9e:
	/* 0x1c9e: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1ca3:
	/* 0x1ca3: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1caa:
	/* 0x1caa: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1caa, 0x7126, x86_l_7126);
x86_l_1cb0:
	/* 0x1cb0: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1cb7:
	/* 0x1cb7: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_1cbb:
	/* 0x1cbb: ja     41a <kprobe_unwind_dotnet+0x41a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1cbb, 0x41a, x86_l_41a);
x86_l_1cc1:
	/* 0x1cc1: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1cc4:
	/* 0x1cc4: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1ccb:
	/* 0x1ccb: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_1ccf:
	/* 0x1ccf: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_1cdb:
	/* 0x1cdb: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_1ce7:
	/* 0x1ce7: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_1cf0:
	/* 0x1cf0: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_1cfc:
	/* 0x1cfc: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_1d08:
	/* 0x1d08: jmp    219e <kprobe_unwind_dotnet+0x219e> */
	X86_SIM_X86_JMP(0x1d08, 0x219e, x86_l_219e);
x86_l_1d0d:
	/* 0x1d0d: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_1d14:
	/* 0x1d14: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_1d18:
	/* 0x1d18: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_1d1f:
	/* 0x1d1f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1d26:
	/* 0x1d26: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d29:
	/* 0x1d29: jne    280a <kprobe_unwind_dotnet+0x280a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d29, 0x280a, x86_l_280a);
x86_l_1d2f:
	/* 0x1d2f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d31:
	/* 0x1d31: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1d34:
	/* 0x1d34: je     2896 <kprobe_unwind_dotnet+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d34, 0x2896, x86_l_2896);
x86_l_1d3a:
	/* 0x1d3a: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1d3c:
	/* 0x1d3c: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_1d3f:
	/* 0x1d3f: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1d42:
	/* 0x1d42: jae    2dc5 <kprobe_unwind_dotnet+0x2dc5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1d42, 0x2dc5, x86_l_2dc5);
x86_l_1d48:
	/* 0x1d48: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1d4f:
	/* 0x1d4f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d52:
	/* 0x1d52: je     1bf6 <kprobe_unwind_dotnet+0x1bf6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d52, 0x1bf6, x86_l_1bf6);
x86_l_1d58:
	/* 0x1d58: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_1d62:
	/* 0x1d62: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1d67:
	/* 0x1d67: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_1d71:
	/* 0x1d71: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d76:
	/* 0x1d76: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_1d80:
	/* 0x1d80: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d85:
	/* 0x1d85: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_1d8f:
	/* 0x1d8f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d94:
	/* 0x1d94: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_1d9e:
	/* 0x1d9e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1da3:
	/* 0x1da3: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1dad:
	/* 0x1dad: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1db2:
	/* 0x1db2: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1db7:
	/* 0x1db7: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_1dbc:
	/* 0x1dbc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dbe:
	/* 0x1dbe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc0:
	/* 0x1dc0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc3:
	/* 0x1dc3: call   1dc8 <kprobe_unwind_dotnet+0x1dc8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1dc8:
	/* 0x1dc8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1dcf:
	/* 0x1dcf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd2:
	/* 0x1dd2: je     1bf6 <kprobe_unwind_dotnet+0x1bf6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dd2, 0x1bf6, x86_l_1bf6);
x86_l_1dd8:
	/* 0x1dd8: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_1de2:
	/* 0x1de2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1de7:
	/* 0x1de7: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1df1:
	/* 0x1df1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1df6:
	/* 0x1df6: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_1dfe:
	/* 0x1dfe: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e03:
	/* 0x1e03: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_1e08:
	/* 0x1e08: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e0a:
	/* 0x1e0a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e0c:
	/* 0x1e0c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e0f:
	/* 0x1e0f: call   1e14 <kprobe_unwind_dotnet+0x1e14> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1e14:
	/* 0x1e14: jmp    1bf6 <kprobe_unwind_dotnet+0x1bf6> */
	X86_SIM_X86_JMP(0x1e14, 0x1bf6, x86_l_1bf6);
x86_l_1e19:
	/* 0x1e19: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e1c:
	/* 0x1e1c: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_1e1f:
	/* 0x1e1f: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1e22:
	/* 0x1e22: je     1e2d <kprobe_unwind_dotnet+0x1e2d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e22, 0x1e2d, x86_l_1e2d);
x86_l_1e24:
	/* 0x1e24: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_1e28:
	/* 0x1e28: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1e28, 0x20a7, x86_l_20a7);
x86_l_1e2d:
	/* 0x1e2d: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e30:
	/* 0x1e30: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_1e33:
	/* 0x1e33: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1e36:
	/* 0x1e36: je     1eaf <kprobe_unwind_dotnet+0x1eaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e36, 0x1eaf, x86_l_1eaf);
x86_l_1e38:
	/* 0x1e38: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_1e3c:
	/* 0x1e3c: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1e3c, 0x20a7, x86_l_20a7);
x86_l_1e41:
	/* 0x1e41: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_1e4b:
	/* 0x1e4b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e50:
	/* 0x1e50: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_1e5a:
	/* 0x1e5a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e5f:
	/* 0x1e5f: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_1e69:
	/* 0x1e69: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e6e:
	/* 0x1e6e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1e78:
	/* 0x1e78: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e7d:
	/* 0x1e7d: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_1e85:
	/* 0x1e85: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e8a:
	/* 0x1e8a: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_1e8f:
	/* 0x1e8f: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e92:
	/* 0x1e92: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1e94:
	/* 0x1e94: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e97:
	/* 0x1e97: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e9a:
	/* 0x1e9a: call   1e9f <kprobe_unwind_dotnet+0x1e9f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1e9f:
	/* 0x1e9f: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1ea1:
	/* 0x1ea1: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ea4:
	/* 0x1ea4: jae    1ab2 <kprobe_unwind_dotnet+0x1ab2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ea4, 0x1ab2, x86_l_1ab2);
x86_l_1eaa:
	/* 0x1eaa: jmp    70d6 <kprobe_unwind_dotnet+0x70d6> */
	X86_SIM_X86_JMP(0x1eaa, 0x70d6, x86_l_70d6);
x86_l_1eaf:
	/* 0x1eaf: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1eb2:
	/* 0x1eb2: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_1eb5:
	/* 0x1eb5: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1eb8:
	/* 0x1eb8: je     1ec3 <kprobe_unwind_dotnet+0x1ec3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb8, 0x1ec3, x86_l_1ec3);
x86_l_1eba:
	/* 0x1eba: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_1ebe:
	/* 0x1ebe: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1ebe, 0x20a7, x86_l_20a7);
x86_l_1ec3:
	/* 0x1ec3: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1ec6:
	/* 0x1ec6: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_1ec9:
	/* 0x1ec9: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1ecc:
	/* 0x1ecc: je     1fce <kprobe_unwind_dotnet+0x1fce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ecc, 0x1fce, x86_l_1fce);
x86_l_1ed2:
	/* 0x1ed2: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_1ed9:
	/* 0x1ed9: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1ed9, 0x20a7, x86_l_20a7);
x86_l_1ede:
	/* 0x1ede: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_1ee8:
	/* 0x1ee8: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1eed:
	/* 0x1eed: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_1ef7:
	/* 0x1ef7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1efc:
	/* 0x1efc: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_1f06:
	/* 0x1f06: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f0b:
	/* 0x1f0b: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_1f15:
	/* 0x1f15: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f1a:
	/* 0x1f1a: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_1f24:
	/* 0x1f24: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f29:
	/* 0x1f29: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_1f33:
	/* 0x1f33: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f38:
	/* 0x1f38: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1f3c:
	/* 0x1f3c: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f41:
	/* 0x1f41: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_1f46:
	/* 0x1f46: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f48:
	/* 0x1f48: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4b:
	/* 0x1f4b: call   1f50 <kprobe_unwind_dotnet+0x1f50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1f50:
	/* 0x1f50: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_1f55:
	/* 0x1f55: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1f57:
	/* 0x1f57: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5b:
	/* 0x1f5b: je     3fc <kprobe_unwind_dotnet+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5b, 0x3fc, x86_l_3fc);
x86_l_1f61:
	/* 0x1f61: jmp    1850 <kprobe_unwind_dotnet+0x1850> */
	X86_SIM_X86_JMP(0x1f61, 0x1850, x86_l_1850);
x86_l_1f66:
	/* 0x1f66: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_1f70:
	/* 0x1f70: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f75:
	/* 0x1f75: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_1f7f:
	/* 0x1f7f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f84:
	/* 0x1f84: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_1f8e:
	/* 0x1f8e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f93:
	/* 0x1f93: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_1f9d:
	/* 0x1f9d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fa2:
	/* 0x1fa2: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_1faa:
	/* 0x1faa: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1faf:
	/* 0x1faf: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_1fb4:
	/* 0x1fb4: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1fb7:
	/* 0x1fb7: call   1fbc <kprobe_unwind_dotnet+0x1fbc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1fbc:
	/* 0x1fbc: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1fc3:
	/* 0x1fc3: jae    1b7b <kprobe_unwind_dotnet+0x1b7b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fc3, 0x1b7b, x86_l_1b7b);
x86_l_1fc9:
	/* 0x1fc9: jmp    20ed <kprobe_unwind_dotnet+0x20ed> */
	X86_SIM_X86_JMP(0x1fc9, 0x20ed, x86_l_20ed);
x86_l_1fce:
	/* 0x1fce: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1fd1:
	/* 0x1fd1: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_1fd4:
	/* 0x1fd4: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1fd7:
	/* 0x1fd7: je     2099 <kprobe_unwind_dotnet+0x2099> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd7, 0x2099, x86_l_2099);
x86_l_1fdd:
	/* 0x1fdd: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_1fe4:
	/* 0x1fe4: jmp    20a7 <kprobe_unwind_dotnet+0x20a7> */
	X86_SIM_X86_JMP(0x1fe4, 0x20a7, x86_l_20a7);
x86_l_1fe9:
	/* 0x1fe9: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1ff0:
	/* 0x1ff0: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ff5:
	/* 0x1ff5: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1ffa:
	/* 0x1ffa: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ffd:
	/* 0x1ffd: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_2000:
	/* 0x2000: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_2007:
	/* 0x2007: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_200a:
	/* 0x200a: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_200f:
	/* 0x200f: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2012:
	/* 0x2012: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2015:
	/* 0x2015: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2018:
	/* 0x2018: call   201d <kprobe_unwind_dotnet+0x201d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_201d:
	/* 0x201d: jmp    1b9f <kprobe_unwind_dotnet+0x1b9f> */
	X86_SIM_X86_JMP(0x201d, 0x1b9f, x86_l_1b9f);
x86_l_2022:
	/* 0x2022: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_202c:
	/* 0x202c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2031:
	/* 0x2031: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_203b:
	/* 0x203b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2040:
	/* 0x2040: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_204a:
	/* 0x204a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_204f:
	/* 0x204f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_2059:
	/* 0x2059: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_205e:
	/* 0x205e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_2068:
	/* 0x2068: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_206d:
	/* 0x206d: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_2077:
	/* 0x2077: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_207c:
	/* 0x207c: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2080:
	/* 0x2080: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2085:
	/* 0x2085: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_208a:
	/* 0x208a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208c:
	/* 0x208c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208f:
	/* 0x208f: call   2094 <kprobe_unwind_dotnet+0x2094> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2094:
	/* 0x2094: jmp    1a5f <kprobe_unwind_dotnet+0x1a5f> */
	X86_SIM_X86_JMP(0x2094, 0x1a5f, x86_l_1a5f);
x86_l_2099:
	/* 0x2099: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_209d:
	/* 0x209d: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_20a4:
	/* 0x20a4: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_20a7:
	/* 0x20a7: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20aa:
	/* 0x20aa: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_20b2:
	/* 0x20b2: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20b5:
	/* 0x20b5: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_20bc:
	/* 0x20bc: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20bf:
	/* 0x20bf: jne    2622 <kprobe_unwind_dotnet+0x2622> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20bf, 0x2622, x86_l_2622);
x86_l_20c5:
	/* 0x20c5: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_20c9:
	/* 0x20c9: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20ce:
	/* 0x20ce: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_20d3:
	/* 0x20d3: call   20d8 <kprobe_unwind_dotnet+0x20d8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_20d8:
	/* 0x20d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20db:
	/* 0x20db: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_20e2:
	/* 0x20e2: jne    9fa <kprobe_unwind_dotnet+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20e2, 0x9fa, x86_l_9fa);
x86_l_20e8:
	/* 0x20e8: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_20ed:
	/* 0x20ed: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_20f4:
	/* 0x20f4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20f7:
	/* 0x20f7: jne    2267 <kprobe_unwind_dotnet+0x2267> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20f7, 0x2267, x86_l_2267);
x86_l_20fd:
	/* 0x20fd: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2104:
	/* 0x2104: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_2108:
	/* 0x2108: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2108, 0xa4e, x86_l_a4e);
x86_l_210e:
	/* 0x210e: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2113:
	/* 0x2113: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2116:
	/* 0x2116: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_211a:
	/* 0x211a: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_211d:
	/* 0x211d: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2120:
	/* 0x2120: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2127:
	/* 0x2127: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_212b:
	/* 0x212b: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_2133:
	/* 0x2133: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_213b:
	/* 0x213b: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_2144:
	/* 0x2144: mov    BYTE PTR [r14+rax*8+0x2e1],bl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_214c:
	/* 0x214c: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_2158:
	/* 0x2158: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_2163:
	/* 0x2163: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_216b:
	/* 0x216b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2172:
	/* 0x2172: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2177:
	/* 0x2177: call   217c <kprobe_unwind_dotnet+0x217c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_217c:
	/* 0x217c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_217f:
	/* 0x217f: je     218d <kprobe_unwind_dotnet+0x218d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x217f, 0x218d, x86_l_218d);
x86_l_2181:
	/* 0x2181: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2184:
	/* 0x2184: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_218b:
	/* 0x218b: jmp    219e <kprobe_unwind_dotnet+0x219e> */
	X86_SIM_X86_JMP(0x218b, 0x219e, x86_l_219e);
x86_l_218d:
	/* 0x218d: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2194:
	/* 0x2194: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2198:
	/* 0x2198: jne    2521 <kprobe_unwind_dotnet+0x2521> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2198, 0x2521, x86_l_2521);
x86_l_219e:
	/* 0x219e: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_21a6:
	/* 0x21a6: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21a9:
	/* 0x21a9: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21ac:
	/* 0x21ac: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21af:
	/* 0x21af: je     2245 <kprobe_unwind_dotnet+0x2245> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21af, 0x2245, x86_l_2245);
x86_l_21b5:
	/* 0x21b5: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_21b7:
	/* 0x21b7: jne    22bb <kprobe_unwind_dotnet+0x22bb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21b7, 0x22bb, x86_l_22bb);
x86_l_21bd:
	/* 0x21bd: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_21c7:
	/* 0x21c7: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21ca:
	/* 0x21ca: jbe    234f <kprobe_unwind_dotnet+0x234f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x21ca, 0x234f, x86_l_234f);
x86_l_21d0:
	/* 0x21d0: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_21d5:
	/* 0x21d5: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_21dc:
	/* 0x21dc: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e0:
	/* 0x21e0: je     bd4 <kprobe_unwind_dotnet+0xbd4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e0, 0xbd4, x86_l_bd4);
x86_l_21e6:
	/* 0x21e6: movabs rax,0x7373657264646120 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8319104478668415264ULL);
x86_l_21f0:
	/* 0x21f0: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21f5:
	/* 0x21f5: movabs rax,0x6c656e72656b2061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7810770566350839905ULL);
x86_l_21ff:
	/* 0x21ff: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2204:
	/* 0x2204: movabs rax,0x20736920786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338328219715642656ULL);
x86_l_220e:
	/* 0x220e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2213:
	/* 0x2213: movabs rax,0x65756c6176204350 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310868735955321680ULL);
x86_l_221d:
	/* 0x221d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2222:
	/* 0x2222: mov    WORD PTR [rsp+0x30],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430218ULL);
x86_l_2229:
	/* 0x2229: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_222e:
	/* 0x222e: mov    esi,0x22 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_2233:
	/* 0x2233: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2236:
	/* 0x2236: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2238:
	/* 0x2238: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_223b:
	/* 0x223b: call   2240 <kprobe_unwind_dotnet+0x2240> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2240:
	/* 0x2240: jmp    bd4 <kprobe_unwind_dotnet+0xbd4> */
	X86_SIM_X86_JMP(0x2240, 0xbd4, x86_l_bd4);
x86_l_2245:
	/* 0x2245: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_224a:
	/* 0x224a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_224c:
	/* 0x224c: jne    8186 <kprobe_unwind_dotnet+0x8186> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x224c, 0x8186, x86_l_8186);
x86_l_2252:
	/* 0x2252: mov    DWORD PTR [r14+0xf28],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108481ULL);
x86_l_225d:
	/* 0x225d: mov    eax,0xfad */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4013ULL);
x86_l_2262:
	/* 0x2262: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0x2262, 0x7126, x86_l_7126);
x86_l_2267:
	/* 0x2267: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_226e:
	/* 0x226e: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2273:
	/* 0x2273: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2278:
	/* 0x2278: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_227b:
	/* 0x227b: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_227e:
	/* 0x227e: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_2283:
	/* 0x2283: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_228a:
	/* 0x228a: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_228f:
	/* 0x228f: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2292:
	/* 0x2292: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2295:
	/* 0x2295: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2298:
	/* 0x2298: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_229d:
	/* 0x229d: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_22a0:
	/* 0x22a0: call   22a5 <kprobe_unwind_dotnet+0x22a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_22a5:
	/* 0x22a5: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_22ac:
	/* 0x22ac: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_22b0:
	/* 0x22b0: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22b0, 0xa4e, x86_l_a4e);
x86_l_22b6:
	/* 0x22b6: jmp    210e <kprobe_unwind_dotnet+0x210e> */
	X86_SIM_X86_JMP(0x22b6, 0x210e, x86_l_210e);
x86_l_22bb:
	/* 0x22bb: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_22c5:
	/* 0x22c5: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_22ca:
	/* 0x22ca: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_22d4:
	/* 0x22d4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_22d9:
	/* 0x22d9: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_22e3:
	/* 0x22e3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_22e8:
	/* 0x22e8: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_22f2:
	/* 0x22f2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22f7:
	/* 0x22f7: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_2301:
	/* 0x2301: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2306:
	/* 0x2306: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_2310:
	/* 0x2310: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2315:
	/* 0x2315: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_231a:
	/* 0x231a: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2321:
	/* 0x2321: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2326:
	/* 0x2326: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_232b:
	/* 0x232b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_232d:
	/* 0x232d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2330:
	/* 0x2330: call   2335 <kprobe_unwind_dotnet+0x2335> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2335:
	/* 0x2335: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_233c:
	/* 0x233c: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2346:
	/* 0x2346: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2349:
	/* 0x2349: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2349, 0x21d0, x86_l_21d0);
x86_l_234f:
	/* 0x234f: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2356:
	/* 0x2356: jae    23c6 <kprobe_unwind_dotnet+0x23c6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2356, 0x23c6, x86_l_23c6);
x86_l_2358:
	/* 0x2358: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_235d:
	/* 0x235d: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2364:
	/* 0x2364: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2368:
	/* 0x2368: je     cf0 <kprobe_unwind_dotnet+0xcf0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2368, 0xcf0, x86_l_cf0);
x86_l_236e:
	/* 0x236e: movabs rax,0xa676e69726f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2928473680277358ULL);
x86_l_2378:
	/* 0x2378: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_237d:
	/* 0x237d: movabs rax,0x6f6e6769202c786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8029468886857185388ULL);
x86_l_2387:
	/* 0x2387: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_238c:
	/* 0x238c: movabs rax,0x252065756c617620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675249733661980192ULL);
x86_l_2396:
	/* 0x2396: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_239b:
	/* 0x239b: movabs rax,0x6370206c6c616d73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165262657193340275ULL);
x86_l_23a5:
	/* 0x23a5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23aa:
	/* 0x23aa: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23af:
	/* 0x23af: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_23b4:
	/* 0x23b4: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_23b7:
	/* 0x23b7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b9:
	/* 0x23b9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23bc:
	/* 0x23bc: call   23c1 <kprobe_unwind_dotnet+0x23c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_23c1:
	/* 0x23c1: jmp    cf0 <kprobe_unwind_dotnet+0xcf0> */
	X86_SIM_X86_JMP(0x23c1, 0xcf0, x86_l_cf0);
x86_l_23c6:
	/* 0x23c6: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23c9:
	/* 0x23c9: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_23d1:
	/* 0x23d1: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_23d7:
	/* 0x23d7: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_23de:
	/* 0x23de: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_23e5:
	/* 0x23e5: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_23ea:
	/* 0x23ea: call   23ef <kprobe_unwind_dotnet+0x23ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_23ef:
	/* 0x23ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23f2:
	/* 0x23f2: je     80c1 <kprobe_unwind_dotnet+0x80c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f2, 0x80c1, x86_l_80c1);
x86_l_23f8:
	/* 0x23f8: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23fc:
	/* 0x23fc: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_23ff:
	/* 0x23ff: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2409:
	/* 0x2409: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_240c:
	/* 0x240c: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_2413:
	/* 0x2413: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2416:
	/* 0x2416: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_241d:
	/* 0x241d: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_2421:
	/* 0x2421: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2424:
	/* 0x2424: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2427:
	/* 0x2427: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_242e:
	/* 0x242e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2435:
	/* 0x2435: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2438:
	/* 0x2438: jne    270f <kprobe_unwind_dotnet+0x270f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2438, 0x270f, x86_l_270f);
x86_l_243e:
	/* 0x243e: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2442:
	/* 0x2442: jne    2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2442, 0x2fc3, x86_l_2fc3);
x86_l_2448:
	/* 0x2448: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_244f:
	/* 0x244f: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2454:
	/* 0x2454: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_245b:
	/* 0x245b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_2462:
	/* 0x2462: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2467:
	/* 0x2467: call   246c <kprobe_unwind_dotnet+0x246c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_246c:
	/* 0x246c: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2472:
	/* 0x2472: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2475:
	/* 0x2475: je     2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2475, 0x2fc3, x86_l_2fc3);
x86_l_247b:
	/* 0x247b: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_247e:
	/* 0x247e: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2481:
	/* 0x2481: ja     2489 <kprobe_unwind_dotnet+0x2489> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2481, 0x2489, x86_l_2489);
x86_l_2483:
	/* 0x2483: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2487:
	/* 0x2487: jae    249d <kprobe_unwind_dotnet+0x249d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2487, 0x249d, x86_l_249d);
x86_l_2489:
	/* 0x2489: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_248d:
	/* 0x248d: ja     2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x248d, 0x2fc3, x86_l_2fc3);
x86_l_2493:
	/* 0x2493: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2497:
	/* 0x2497: jb     2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2497, 0x2fc3, x86_l_2fc3);
x86_l_249d:
	/* 0x249d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_24a4:
	/* 0x24a4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24a7:
	/* 0x24a7: jne    2f22 <kprobe_unwind_dotnet+0x2f22> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24a7, 0x2f22, x86_l_2f22);
x86_l_24ad:
	/* 0x24ad: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_24b4:
	/* 0x24b4: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24b8:
	/* 0x24b8: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_24bb:
	/* 0x24bb: jae    2f8b <kprobe_unwind_dotnet+0x2f8b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x24bb, 0x2f8b, x86_l_2f8b);
x86_l_24c1:
	/* 0x24c1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_24c8:
	/* 0x24c8: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24cb:
	/* 0x24cb: je     2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24cb, 0x2fc3, x86_l_2fc3);
x86_l_24d1:
	/* 0x24d1: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_24db:
	/* 0x24db: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24e0:
	/* 0x24e0: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_24ea:
	/* 0x24ea: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24ef:
	/* 0x24ef: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_24f9:
	/* 0x24f9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24fe:
	/* 0x24fe: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_2506:
	/* 0x2506: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_250b:
	/* 0x250b: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_2510:
	/* 0x2510: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2512:
	/* 0x2512: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2514:
	/* 0x2514: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2517:
	/* 0x2517: call   251c <kprobe_unwind_dotnet+0x251c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_251c:
	/* 0x251c: jmp    2fc3 <kprobe_unwind_dotnet+0x2fc3> */
	X86_SIM_X86_JMP(0x251c, 0x2fc3, x86_l_2fc3);
x86_l_2521:
	/* 0x2521: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_252b:
	/* 0x252b: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2530:
	/* 0x2530: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_253a:
	/* 0x253a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_253f:
	/* 0x253f: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_2549:
	/* 0x2549: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_254e:
	/* 0x254e: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_2558:
	/* 0x2558: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_255d:
	/* 0x255d: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_2567:
	/* 0x2567: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_256c:
	/* 0x256c: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_2576:
	/* 0x2576: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_257b:
	/* 0x257b: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_257f:
	/* 0x257f: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2584:
	/* 0x2584: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2589:
	/* 0x2589: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258b:
	/* 0x258b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258e:
	/* 0x258e: call   2593 <kprobe_unwind_dotnet+0x2593> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2593:
	/* 0x2593: jmp    219e <kprobe_unwind_dotnet+0x219e> */
	X86_SIM_X86_JMP(0x2593, 0x219e, x86_l_219e);
x86_l_2598:
	/* 0x2598: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_259b:
	/* 0x259b: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_259f:
	/* 0x259f: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_25a9:
	/* 0x25a9: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_25ae:
	/* 0x25ae: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_25b8:
	/* 0x25b8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_25bd:
	/* 0x25bd: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_25c7:
	/* 0x25c7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25cc:
	/* 0x25cc: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_25d6:
	/* 0x25d6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_25db:
	/* 0x25db: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_25e5:
	/* 0x25e5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25ea:
	/* 0x25ea: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_25f4:
	/* 0x25f4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25f9:
	/* 0x25f9: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_2603:
	/* 0x2603: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2608:
	/* 0x2608: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_260d:
	/* 0x260d: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_2612:
	/* 0x2612: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2615:
	/* 0x2615: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2618:
	/* 0x2618: call   261d <kprobe_unwind_dotnet+0x261d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_261d:
	/* 0x261d: jmp    1c30 <kprobe_unwind_dotnet+0x1c30> */
	X86_SIM_X86_JMP(0x261d, 0x1c30, x86_l_1c30);
x86_l_2622:
	/* 0x2622: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2624:
	/* 0x2624: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_262e:
	/* 0x262e: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2633:
	/* 0x2633: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_263d:
	/* 0x263d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2642:
	/* 0x2642: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_264c:
	/* 0x264c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2651:
	/* 0x2651: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_265b:
	/* 0x265b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2660:
	/* 0x2660: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_266a:
	/* 0x266a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_266f:
	/* 0x266f: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_2679:
	/* 0x2679: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_267e:
	/* 0x267e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2683:
	/* 0x2683: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2688:
	/* 0x2688: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_268b:
	/* 0x268b: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_268e:
	/* 0x268e: call   2693 <kprobe_unwind_dotnet+0x2693> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2693:
	/* 0x2693: jmp    20c5 <kprobe_unwind_dotnet+0x20c5> */
	X86_SIM_X86_JMP(0x2693, 0x20c5, x86_l_20c5);
x86_l_2698:
	/* 0x2698: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_26a2:
	/* 0x26a2: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_26a7:
	/* 0x26a7: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_26b1:
	/* 0x26b1: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_26b6:
	/* 0x26b6: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_26c0:
	/* 0x26c0: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_26c5:
	/* 0x26c5: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_26cf:
	/* 0x26cf: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_26d4:
	/* 0x26d4: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_26de:
	/* 0x26de: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26e3:
	/* 0x26e3: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_26ed:
	/* 0x26ed: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26f2:
	/* 0x26f2: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_26f6:
	/* 0x26f6: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26fb:
	/* 0x26fb: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2700:
	/* 0x2700: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2702:
	/* 0x2702: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2705:
	/* 0x2705: call   270a <kprobe_unwind_dotnet+0x270a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_270a:
	/* 0x270a: jmp    1c80 <kprobe_unwind_dotnet+0x1c80> */
	X86_SIM_X86_JMP(0x270a, 0x1c80, x86_l_1c80);
x86_l_270f:
	/* 0x270f: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_2719:
	/* 0x2719: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_271e:
	/* 0x271e: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_2728:
	/* 0x2728: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_272d:
	/* 0x272d: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_2737:
	/* 0x2737: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_273c:
	/* 0x273c: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_2746:
	/* 0x2746: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_274b:
	/* 0x274b: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_2755:
	/* 0x2755: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_275a:
	/* 0x275a: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_2764:
	/* 0x2764: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2769:
	/* 0x2769: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_2770:
	/* 0x2770: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2775:
	/* 0x2775: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_277a:
	/* 0x277a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_277d:
	/* 0x277d: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2780:
	/* 0x2780: call   2785 <kprobe_unwind_dotnet+0x2785> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2785:
	/* 0x2785: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_278c:
	/* 0x278c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278f:
	/* 0x278f: je     243e <kprobe_unwind_dotnet+0x243e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x278f, 0x243e, x86_l_243e);
x86_l_2795:
	/* 0x2795: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_279f:
	/* 0x279f: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_27a4:
	/* 0x27a4: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_27ae:
	/* 0x27ae: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_27b3:
	/* 0x27b3: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_27bd:
	/* 0x27bd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_27c2:
	/* 0x27c2: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_27cc:
	/* 0x27cc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27d1:
	/* 0x27d1: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_27db:
	/* 0x27db: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_27e0:
	/* 0x27e0: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27e5:
	/* 0x27e5: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_27ec:
	/* 0x27ec: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_27f3:
	/* 0x27f3: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27f8:
	/* 0x27f8: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_27fd:
	/* 0x27fd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2800:
	/* 0x2800: call   2805 <kprobe_unwind_dotnet+0x2805> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2805:
	/* 0x2805: jmp    243e <kprobe_unwind_dotnet+0x243e> */
	X86_SIM_X86_JMP(0x2805, 0x243e, x86_l_243e);
x86_l_280a:
	/* 0x280a: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_2814:
	/* 0x2814: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_2819:
	/* 0x2819: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_2823:
	/* 0x2823: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2828:
	/* 0x2828: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_2832:
	/* 0x2832: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2837:
	/* 0x2837: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_2841:
	/* 0x2841: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2846:
	/* 0x2846: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_2850:
	/* 0x2850: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2855:
	/* 0x2855: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_285f:
	/* 0x285f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2864:
	/* 0x2864: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_286e:
	/* 0x286e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2873:
	/* 0x2873: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2878:
	/* 0x2878: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_287d:
	/* 0x287d: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2880:
	/* 0x2880: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2883:
	/* 0x2883: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2886:
	/* 0x2886: call   288b <kprobe_unwind_dotnet+0x288b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_288b:
	/* 0x288b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_288d:
	/* 0x288d: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2890:
	/* 0x2890: jne    1d3a <kprobe_unwind_dotnet+0x1d3a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2890, 0x1d3a, x86_l_1d3a);
x86_l_2896:
	/* 0x2896: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_289d:
	/* 0x289d: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_28a2:
	/* 0x28a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a5:
	/* 0x28a5: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28a5, 0x2d9d, x86_l_2d9d);
x86_l_28ab:
	/* 0x28ab: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_28b2:
	/* 0x28b2: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_28b7:
	/* 0x28b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28ba:
	/* 0x28ba: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28ba, 0x2d9d, x86_l_2d9d);
x86_l_28c0:
	/* 0x28c0: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_28c7:
	/* 0x28c7: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_28cc:
	/* 0x28cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28cf:
	/* 0x28cf: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28cf, 0x2d9d, x86_l_2d9d);
x86_l_28d5:
	/* 0x28d5: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_28dc:
	/* 0x28dc: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_28e1:
	/* 0x28e1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28e4:
	/* 0x28e4: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28e4, 0x2d9d, x86_l_2d9d);
x86_l_28ea:
	/* 0x28ea: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_28f1:
	/* 0x28f1: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_28f6:
	/* 0x28f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28f9:
	/* 0x28f9: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28f9, 0x2d9d, x86_l_2d9d);
x86_l_28ff:
	/* 0x28ff: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_2906:
	/* 0x2906: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_290b:
	/* 0x290b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_290e:
	/* 0x290e: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x290e, 0x2d9d, x86_l_2d9d);
x86_l_2914:
	/* 0x2914: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_291b:
	/* 0x291b: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_2920:
	/* 0x2920: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2923:
	/* 0x2923: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2923, 0x2d9d, x86_l_2d9d);
x86_l_2929:
	/* 0x2929: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_2930:
	/* 0x2930: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_2935:
	/* 0x2935: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2938:
	/* 0x2938: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2938, 0x2d9d, x86_l_2d9d);
x86_l_293e:
	/* 0x293e: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_2945:
	/* 0x2945: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_294a:
	/* 0x294a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_294d:
	/* 0x294d: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x294d, 0x2d9d, x86_l_2d9d);
x86_l_2953:
	/* 0x2953: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_295a:
	/* 0x295a: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_295f:
	/* 0x295f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2962:
	/* 0x2962: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2962, 0x2d9d, x86_l_2d9d);
x86_l_2968:
	/* 0x2968: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_296f:
	/* 0x296f: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_2974:
	/* 0x2974: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2977:
	/* 0x2977: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2977, 0x2d9d, x86_l_2d9d);
x86_l_297d:
	/* 0x297d: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_2984:
	/* 0x2984: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_2989:
	/* 0x2989: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_298c:
	/* 0x298c: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x298c, 0x2d9d, x86_l_2d9d);
x86_l_2992:
	/* 0x2992: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_2999:
	/* 0x2999: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_299e:
	/* 0x299e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29a1:
	/* 0x29a1: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29a1, 0x2d9d, x86_l_2d9d);
x86_l_29a7:
	/* 0x29a7: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_29ae:
	/* 0x29ae: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_29b3:
	/* 0x29b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29b6:
	/* 0x29b6: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29b6, 0x2d9d, x86_l_2d9d);
x86_l_29bc:
	/* 0x29bc: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_29c3:
	/* 0x29c3: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_29c8:
	/* 0x29c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29cb:
	/* 0x29cb: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29cb, 0x2d9d, x86_l_2d9d);
x86_l_29d1:
	/* 0x29d1: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_29d8:
	/* 0x29d8: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_29dd:
	/* 0x29dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29e0:
	/* 0x29e0: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29e0, 0x2d9d, x86_l_2d9d);
x86_l_29e6:
	/* 0x29e6: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_29ed:
	/* 0x29ed: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_29f2:
	/* 0x29f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29f5:
	/* 0x29f5: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29f5, 0x2d9d, x86_l_2d9d);
x86_l_29fb:
	/* 0x29fb: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_2a02:
	/* 0x2a02: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_2a07:
	/* 0x2a07: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a0a:
	/* 0x2a0a: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a0a, 0x2d9d, x86_l_2d9d);
x86_l_2a10:
	/* 0x2a10: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_2a17:
	/* 0x2a17: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_2a1c:
	/* 0x2a1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a1f:
	/* 0x2a1f: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a1f, 0x2d9d, x86_l_2d9d);
x86_l_2a25:
	/* 0x2a25: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_2a2c:
	/* 0x2a2c: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_2a31:
	/* 0x2a31: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a34:
	/* 0x2a34: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a34, 0x2d9d, x86_l_2d9d);
x86_l_2a3a:
	/* 0x2a3a: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_2a41:
	/* 0x2a41: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_2a46:
	/* 0x2a46: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a49:
	/* 0x2a49: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a49, 0x2d9d, x86_l_2d9d);
x86_l_2a4f:
	/* 0x2a4f: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_2a56:
	/* 0x2a56: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_2a5b:
	/* 0x2a5b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a5e:
	/* 0x2a5e: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a5e, 0x2d9d, x86_l_2d9d);
x86_l_2a64:
	/* 0x2a64: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_2a6b:
	/* 0x2a6b: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_2a70:
	/* 0x2a70: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a73:
	/* 0x2a73: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a73, 0x2d9d, x86_l_2d9d);
x86_l_2a79:
	/* 0x2a79: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_2a80:
	/* 0x2a80: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_2a85:
	/* 0x2a85: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a88:
	/* 0x2a88: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a88, 0x2d9d, x86_l_2d9d);
x86_l_2a8e:
	/* 0x2a8e: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_2a95:
	/* 0x2a95: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_2a9a:
	/* 0x2a9a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a9d:
	/* 0x2a9d: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a9d, 0x2d9d, x86_l_2d9d);
x86_l_2aa3:
	/* 0x2aa3: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_2aaa:
	/* 0x2aaa: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_2aaf:
	/* 0x2aaf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ab2:
	/* 0x2ab2: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ab2, 0x2d9d, x86_l_2d9d);
x86_l_2ab8:
	/* 0x2ab8: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_2abf:
	/* 0x2abf: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_2ac4:
	/* 0x2ac4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ac7:
	/* 0x2ac7: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ac7, 0x2d9d, x86_l_2d9d);
x86_l_2acd:
	/* 0x2acd: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_2ad4:
	/* 0x2ad4: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_2ad9:
	/* 0x2ad9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2adc:
	/* 0x2adc: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2adc, 0x2d9d, x86_l_2d9d);
x86_l_2ae2:
	/* 0x2ae2: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_2ae9:
	/* 0x2ae9: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_2aee:
	/* 0x2aee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af1:
	/* 0x2af1: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2af1, 0x2d9d, x86_l_2d9d);
x86_l_2af7:
	/* 0x2af7: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_2afe:
	/* 0x2afe: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_2b03:
	/* 0x2b03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b06:
	/* 0x2b06: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b06, 0x2d9d, x86_l_2d9d);
x86_l_2b0c:
	/* 0x2b0c: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_2b13:
	/* 0x2b13: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_2b18:
	/* 0x2b18: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b1b:
	/* 0x2b1b: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b1b, 0x2d9d, x86_l_2d9d);
x86_l_2b21:
	/* 0x2b21: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_2b28:
	/* 0x2b28: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_2b2d:
	/* 0x2b2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b30:
	/* 0x2b30: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b30, 0x2d9d, x86_l_2d9d);
x86_l_2b36:
	/* 0x2b36: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_2b3d:
	/* 0x2b3d: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_2b42:
	/* 0x2b42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b45:
	/* 0x2b45: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b45, 0x2d9d, x86_l_2d9d);
x86_l_2b4b:
	/* 0x2b4b: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_2b52:
	/* 0x2b52: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_2b57:
	/* 0x2b57: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b5a:
	/* 0x2b5a: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b5a, 0x2d9d, x86_l_2d9d);
x86_l_2b60:
	/* 0x2b60: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_2b67:
	/* 0x2b67: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_2b6c:
	/* 0x2b6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b6f:
	/* 0x2b6f: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b6f, 0x2d9d, x86_l_2d9d);
x86_l_2b75:
	/* 0x2b75: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_2b7c:
	/* 0x2b7c: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_2b81:
	/* 0x2b81: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b84:
	/* 0x2b84: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b84, 0x2d9d, x86_l_2d9d);
x86_l_2b8a:
	/* 0x2b8a: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_2b91:
	/* 0x2b91: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_2b96:
	/* 0x2b96: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b99:
	/* 0x2b99: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b99, 0x2d9d, x86_l_2d9d);
x86_l_2b9f:
	/* 0x2b9f: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_2ba6:
	/* 0x2ba6: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_2bab:
	/* 0x2bab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bae:
	/* 0x2bae: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bae, 0x2d9d, x86_l_2d9d);
x86_l_2bb4:
	/* 0x2bb4: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_2bbb:
	/* 0x2bbb: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_2bc0:
	/* 0x2bc0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bc3:
	/* 0x2bc3: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bc3, 0x2d9d, x86_l_2d9d);
x86_l_2bc9:
	/* 0x2bc9: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_2bd0:
	/* 0x2bd0: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_2bd5:
	/* 0x2bd5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bd8:
	/* 0x2bd8: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bd8, 0x2d9d, x86_l_2d9d);
x86_l_2bde:
	/* 0x2bde: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_2be5:
	/* 0x2be5: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_2bea:
	/* 0x2bea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bed:
	/* 0x2bed: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bed, 0x2d9d, x86_l_2d9d);
x86_l_2bf3:
	/* 0x2bf3: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_2bfa:
	/* 0x2bfa: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_2bff:
	/* 0x2bff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c02:
	/* 0x2c02: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c02, 0x2d9d, x86_l_2d9d);
x86_l_2c08:
	/* 0x2c08: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_2c0f:
	/* 0x2c0f: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_2c14:
	/* 0x2c14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c17:
	/* 0x2c17: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c17, 0x2d9d, x86_l_2d9d);
x86_l_2c1d:
	/* 0x2c1d: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_2c24:
	/* 0x2c24: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_2c29:
	/* 0x2c29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c2c:
	/* 0x2c2c: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c2c, 0x2d9d, x86_l_2d9d);
x86_l_2c32:
	/* 0x2c32: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_2c39:
	/* 0x2c39: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_2c3e:
	/* 0x2c3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c41:
	/* 0x2c41: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c41, 0x2d9d, x86_l_2d9d);
x86_l_2c47:
	/* 0x2c47: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_2c4e:
	/* 0x2c4e: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_2c53:
	/* 0x2c53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c56:
	/* 0x2c56: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c56, 0x2d9d, x86_l_2d9d);
x86_l_2c5c:
	/* 0x2c5c: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_2c63:
	/* 0x2c63: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_2c68:
	/* 0x2c68: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c6b:
	/* 0x2c6b: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c6b, 0x2d9d, x86_l_2d9d);
x86_l_2c71:
	/* 0x2c71: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_2c78:
	/* 0x2c78: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_2c7d:
	/* 0x2c7d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c80:
	/* 0x2c80: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c80, 0x2d9d, x86_l_2d9d);
x86_l_2c86:
	/* 0x2c86: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_2c8d:
	/* 0x2c8d: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_2c92:
	/* 0x2c92: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c95:
	/* 0x2c95: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c95, 0x2d9d, x86_l_2d9d);
x86_l_2c9b:
	/* 0x2c9b: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_2ca2:
	/* 0x2ca2: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_2ca7:
	/* 0x2ca7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2caa:
	/* 0x2caa: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2caa, 0x2d9d, x86_l_2d9d);
x86_l_2cb0:
	/* 0x2cb0: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_2cb7:
	/* 0x2cb7: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_2cbc:
	/* 0x2cbc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cbf:
	/* 0x2cbf: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cbf, 0x2d9d, x86_l_2d9d);
x86_l_2cc5:
	/* 0x2cc5: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_2ccc:
	/* 0x2ccc: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_2cd1:
	/* 0x2cd1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cd4:
	/* 0x2cd4: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cd4, 0x2d9d, x86_l_2d9d);
x86_l_2cda:
	/* 0x2cda: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_2ce1:
	/* 0x2ce1: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_2ce6:
	/* 0x2ce6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ce9:
	/* 0x2ce9: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ce9, 0x2d9d, x86_l_2d9d);
x86_l_2cef:
	/* 0x2cef: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_2cf6:
	/* 0x2cf6: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_2cfb:
	/* 0x2cfb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cfe:
	/* 0x2cfe: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cfe, 0x2d9d, x86_l_2d9d);
x86_l_2d04:
	/* 0x2d04: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_2d0b:
	/* 0x2d0b: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_2d10:
	/* 0x2d10: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d13:
	/* 0x2d13: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d13, 0x2d9d, x86_l_2d9d);
x86_l_2d19:
	/* 0x2d19: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_2d20:
	/* 0x2d20: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_2d25:
	/* 0x2d25: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d28:
	/* 0x2d28: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d28, 0x2d9d, x86_l_2d9d);
x86_l_2d2a:
	/* 0x2d2a: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_2d31:
	/* 0x2d31: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_2d36:
	/* 0x2d36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d39:
	/* 0x2d39: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d39, 0x2d9d, x86_l_2d9d);
x86_l_2d3b:
	/* 0x2d3b: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_2d42:
	/* 0x2d42: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_2d47:
	/* 0x2d47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d4a:
	/* 0x2d4a: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d4a, 0x2d9d, x86_l_2d9d);
x86_l_2d4c:
	/* 0x2d4c: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_2d53:
	/* 0x2d53: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_2d58:
	/* 0x2d58: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d5b:
	/* 0x2d5b: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d5b, 0x2d9d, x86_l_2d9d);
x86_l_2d5d:
	/* 0x2d5d: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_2d64:
	/* 0x2d64: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_2d69:
	/* 0x2d69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d6c:
	/* 0x2d6c: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d6c, 0x2d9d, x86_l_2d9d);
x86_l_2d6e:
	/* 0x2d6e: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_2d75:
	/* 0x2d75: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_2d7a:
	/* 0x2d7a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d7d:
	/* 0x2d7d: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d7d, 0x2d9d, x86_l_2d9d);
x86_l_2d7f:
	/* 0x2d7f: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_2d86:
	/* 0x2d86: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_2d8b:
	/* 0x2d8b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d8e:
	/* 0x2d8e: jne    2d9d <kprobe_unwind_dotnet+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d8e, 0x2d9d, x86_l_2d9d);
x86_l_2d90:
	/* 0x2d90: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2d98:
	/* 0x2d98: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d9b:
	/* 0x2d9b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d9d:
	/* 0x2d9d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d9f:
	/* 0x2d9f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2da2:
	/* 0x2da2: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2da6:
	/* 0x2da6: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2daa:
	/* 0x2daa: jne    2daf <kprobe_unwind_dotnet+0x2daf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2daa, 0x2daf, x86_l_2daf);
x86_l_2dac:
	/* 0x2dac: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2daf:
	/* 0x2daf: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_2db2:
	/* 0x2db2: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2db4:
	/* 0x2db4: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_2db7:
	/* 0x2db7: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2db9:
	/* 0x2db9: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_2dbc:
	/* 0x2dbc: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2dbf:
	/* 0x2dbf: jb     1d48 <kprobe_unwind_dotnet+0x1d48> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2dbf, 0x1d48, x86_l_1d48);
x86_l_2dc5:
	/* 0x2dc5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2dcc:
	/* 0x2dcc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dcf:
	/* 0x2dcf: jne    2e8c <kprobe_unwind_dotnet+0x2e8c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dcf, 0x2e8c, x86_l_2e8c);
x86_l_2dd5:
	/* 0x2dd5: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2dd8:
	/* 0x2dd8: jne    1c4c <kprobe_unwind_dotnet+0x1c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dd8, 0x1c4c, x86_l_1c4c);
x86_l_2dde:
	/* 0x2dde: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_2de6:
	/* 0x2de6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2ded:
	/* 0x2ded: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2df2:
	/* 0x2df2: call   2df7 <kprobe_unwind_dotnet+0x2df7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2df7:
	/* 0x2df7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dfa:
	/* 0x2dfa: je     2e01 <kprobe_unwind_dotnet+0x2e01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dfa, 0x2e01, x86_l_2e01);
x86_l_2dfc:
	/* 0x2dfc: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2dff:
	/* 0x2dff: jmp    2e11 <kprobe_unwind_dotnet+0x2e11> */
	X86_SIM_X86_JMP(0x2dff, 0x2e11, x86_l_2e11);
x86_l_2e01:
	/* 0x2e01: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2e08:
	/* 0x2e08: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e0b:
	/* 0x2e0b: jne    342d <kprobe_unwind_dotnet+0x342d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e0b, 0x342d, x86_l_342d);
x86_l_2e11:
	/* 0x2e11: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_2e16:
	/* 0x2e16: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2e18:
	/* 0x2e18: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2e1f:
	/* 0x2e1f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e22:
	/* 0x2e22: je     1c97 <kprobe_unwind_dotnet+0x1c97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e22, 0x1c97, x86_l_1c97);
x86_l_2e28:
	/* 0x2e28: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_2e32:
	/* 0x2e32: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e37:
	/* 0x2e37: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_2e41:
	/* 0x2e41: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e46:
	/* 0x2e46: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_2e50:
	/* 0x2e50: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e55:
	/* 0x2e55: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_2e5f:
	/* 0x2e5f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2e64:
	/* 0x2e64: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_2e6e:
	/* 0x2e6e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e73:
	/* 0x2e73: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e78:
	/* 0x2e78: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_2e7d:
	/* 0x2e7d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e7f:
	/* 0x2e7f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e82:
	/* 0x2e82: call   2e87 <kprobe_unwind_dotnet+0x2e87> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2e87:
	/* 0x2e87: jmp    1c97 <kprobe_unwind_dotnet+0x1c97> */
	X86_SIM_X86_JMP(0x2e87, 0x1c97, x86_l_1c97);
x86_l_2e8c:
	/* 0x2e8c: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_2e96:
	/* 0x2e96: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2e9b:
	/* 0x2e9b: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_2ea5:
	/* 0x2ea5: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2eaa:
	/* 0x2eaa: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_2eb4:
	/* 0x2eb4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2eb9:
	/* 0x2eb9: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_2ec3:
	/* 0x2ec3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2ec8:
	/* 0x2ec8: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_2ed2:
	/* 0x2ed2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ed7:
	/* 0x2ed7: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_2ee1:
	/* 0x2ee1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ee6:
	/* 0x2ee6: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_2ef0:
	/* 0x2ef0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ef5:
	/* 0x2ef5: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_2efd:
	/* 0x2efd: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2eff:
	/* 0x2eff: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2f02:
	/* 0x2f02: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f07:
	/* 0x2f07: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_2f0c:
	/* 0x2f0c: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2f0f:
	/* 0x2f0f: call   2f14 <kprobe_unwind_dotnet+0x2f14> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2f14:
	/* 0x2f14: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2f17:
	/* 0x2f17: jne    1c4c <kprobe_unwind_dotnet+0x1c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f17, 0x1c4c, x86_l_1c4c);
x86_l_2f1d:
	/* 0x2f1d: jmp    2dde <kprobe_unwind_dotnet+0x2dde> */
	X86_SIM_X86_JMP(0x2f1d, 0x2dde, x86_l_2dde);
x86_l_2f22:
	/* 0x2f22: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_2f2c:
	/* 0x2f2c: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_2f31:
	/* 0x2f31: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_2f3b:
	/* 0x2f3b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f40:
	/* 0x2f40: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_2f4a:
	/* 0x2f4a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2f4f:
	/* 0x2f4f: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_2f59:
	/* 0x2f59: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f5e:
	/* 0x2f5e: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_2f63:
	/* 0x2f63: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f68:
	/* 0x2f68: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_2f6d:
	/* 0x2f6d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f6f:
	/* 0x2f6f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f72:
	/* 0x2f72: call   2f77 <kprobe_unwind_dotnet+0x2f77> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2f77:
	/* 0x2f77: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_2f7e:
	/* 0x2f7e: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f82:
	/* 0x2f82: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2f85:
	/* 0x2f85: jb     24c1 <kprobe_unwind_dotnet+0x24c1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2f85, 0x24c1, x86_l_24c1);
x86_l_2f8b:
	/* 0x2f8b: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_2f93:
	/* 0x2f93: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2f9a:
	/* 0x2f9a: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2f9f:
	/* 0x2f9f: call   2fa4 <kprobe_unwind_dotnet+0x2fa4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2fa4:
	/* 0x2fa4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fa7:
	/* 0x2fa7: je     2fae <kprobe_unwind_dotnet+0x2fae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fa7, 0x2fae, x86_l_2fae);
x86_l_2fa9:
	/* 0x2fa9: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2fac:
	/* 0x2fac: jmp    2fbe <kprobe_unwind_dotnet+0x2fbe> */
	X86_SIM_X86_JMP(0x2fac, 0x2fbe, x86_l_2fbe);
x86_l_2fae:
	/* 0x2fae: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2fb5:
	/* 0x2fb5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fb8:
	/* 0x2fb8: jne    3560 <kprobe_unwind_dotnet+0x3560> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fb8, 0x3560, x86_l_3560);
x86_l_2fbe:
	/* 0x2fbe: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_2fc3:
	/* 0x2fc3: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2fc7:
	/* 0x2fc7: jne    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fc7, 0x85e7, x86_l_85e7);
x86_l_2fcd:
	/* 0x2fcd: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2fd4:
	/* 0x2fd4: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2fdb:
	/* 0x2fdb: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2fe2:
	/* 0x2fe2: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_2fea:
	/* 0x2fea: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_2fee:
	/* 0x2fee: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2ff5:
	/* 0x2ff5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff8:
	/* 0x2ff8: jne    3394 <kprobe_unwind_dotnet+0x3394> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ff8, 0x3394, x86_l_3394);
x86_l_2ffe:
	/* 0x2ffe: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3001:
	/* 0x3001: jb     70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3001, 0x70d1, x86_l_70d1);
x86_l_3007:
	/* 0x3007: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_300e:
	/* 0x300e: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3011:
	/* 0x3011: jae    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3011, 0x70d1, x86_l_70d1);
x86_l_3017:
	/* 0x3017: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_301e:
	/* 0x301e: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3025:
	/* 0x3025: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_302a:
	/* 0x302a: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_3032:
	/* 0x3032: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3035:
	/* 0x3035: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_3039:
	/* 0x3039: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_303f:
	/* 0x303f: jne    3073 <kprobe_unwind_dotnet+0x3073> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x303f, 0x3073, x86_l_3073);
x86_l_3041:
	/* 0x3041: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_3048:
	/* 0x3048: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_3050:
	/* 0x3050: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3055:
	/* 0x3055: call   305a <kprobe_unwind_dotnet+0x305a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_305a:
	/* 0x305a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_305d:
	/* 0x305d: jne    180 <kprobe_unwind_dotnet+0x180> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x305d, 0x180, x86_l_180);
x86_l_3063:
	/* 0x3063: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_306b:
	/* 0x306b: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_306e:
	/* 0x306e: jmp    362b <kprobe_unwind_dotnet+0x362b> */
	X86_SIM_X86_JMP(0x306e, 0x362b, x86_l_362b);
x86_l_3073:
	/* 0x3073: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3078:
	/* 0x3078: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_307d:
	/* 0x307d: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3080:
	/* 0x3080: call   3085 <kprobe_unwind_dotnet+0x3085> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3085:
	/* 0x3085: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3088:
	/* 0x3088: jne    1c6 <kprobe_unwind_dotnet+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3088, 0x1c6, x86_l_1c6);
x86_l_308e:
	/* 0x308e: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3092:
	/* 0x3092: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_3099:
	/* 0x3099: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_309e:
	/* 0x309e: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_30a5:
	/* 0x30a5: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_30aa:
	/* 0x30aa: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_30b1:
	/* 0x30b1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_30b8:
	/* 0x30b8: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30bb:
	/* 0x30bb: jne    34a4 <kprobe_unwind_dotnet+0x34a4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30bb, 0x34a4, x86_l_34a4);
x86_l_30c1:
	/* 0x30c1: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_30c8:
	/* 0x30c8: jb     362b <kprobe_unwind_dotnet+0x362b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x30c8, 0x362b, x86_l_362b);
x86_l_30ce:
	/* 0x30ce: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_30d5:
	/* 0x30d5: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_30dc:
	/* 0x30dc: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_30df:
	/* 0x30df: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_30e2:
	/* 0x30e2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_30e9:
	/* 0x30e9: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ec:
	/* 0x30ec: jne    3527 <kprobe_unwind_dotnet+0x3527> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30ec, 0x3527, x86_l_3527);
x86_l_30f2:
	/* 0x30f2: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_30f5:
	/* 0x30f5: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_30f9:
	/* 0x30f9: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_30fe:
	/* 0x30fe: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3100:
	/* 0x3100: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_3103:
	/* 0x3103: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3105:
	/* 0x3105: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_310c:
	/* 0x310c: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_3114:
	/* 0x3114: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_3118:
	/* 0x3118: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_311b:
	/* 0x311b: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_311e:
	/* 0x311e: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3126:
	/* 0x3126: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_312a:
	/* 0x312a: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_312f:
	/* 0x312f: call   3134 <kprobe_unwind_dotnet+0x3134> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3134:
	/* 0x3134: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3137:
	/* 0x3137: je     316c <kprobe_unwind_dotnet+0x316c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3137, 0x316c, x86_l_316c);
x86_l_3139:
	/* 0x3139: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3140:
	/* 0x3140: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3143:
	/* 0x3143: jne    332b <kprobe_unwind_dotnet+0x332b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3143, 0x332b, x86_l_332b);
x86_l_3149:
	/* 0x3149: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_3151:
	/* 0x3151: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_3158:
	/* 0x3158: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_315d:
	/* 0x315d: call   3162 <kprobe_unwind_dotnet+0x3162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3162:
	/* 0x3162: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3165:
	/* 0x3165: je     31c3 <kprobe_unwind_dotnet+0x31c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3165, 0x31c3, x86_l_31c3);
x86_l_3167:
	/* 0x3167: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_316a:
	/* 0x316a: jmp    31d3 <kprobe_unwind_dotnet+0x31d3> */
	X86_SIM_X86_JMP(0x316a, 0x31d3, x86_l_31d3);
x86_l_316c:
	/* 0x316c: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_3173:
	/* 0x3173: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_317a:
	/* 0x317a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_317d:
	/* 0x317d: jne    39dd <kprobe_unwind_dotnet+0x39dd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x317d, 0x39dd, x86_l_39dd);
x86_l_3183:
	/* 0x3183: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_3186:
	/* 0x3186: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_3188:
	/* 0x3188: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_318b:
	/* 0x318b: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_318d:
	/* 0x318d: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_3192:
	/* 0x3192: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3195:
	/* 0x3195: je     3260 <kprobe_unwind_dotnet+0x3260> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3195, 0x3260, x86_l_3260);
x86_l_319b:
	/* 0x319b: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_319f:
	/* 0x319f: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_31a2:
	/* 0x31a2: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_31a5:
	/* 0x31a5: jne    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31a5, 0x35e5, x86_l_35e5);
x86_l_31ab:
	/* 0x31ab: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_31ae:
	/* 0x31ae: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_31b1:
	/* 0x31b1: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_31b4:
	/* 0x31b4: je     336c <kprobe_unwind_dotnet+0x336c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31b4, 0x336c, x86_l_336c);
x86_l_31ba:
	/* 0x31ba: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_31be:
	/* 0x31be: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x31be, 0x35e5, x86_l_35e5);
x86_l_31c3:
	/* 0x31c3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_31ca:
	/* 0x31ca: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31cd:
	/* 0x31cd: jne    3add <kprobe_unwind_dotnet+0x3add> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31cd, 0x3add, x86_l_3add);
x86_l_31d3:
	/* 0x31d3: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_31d8:
	/* 0x31d8: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31da:
	/* 0x31da: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_31e1:
	/* 0x31e1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31e4:
	/* 0x31e4: jne    426d <kprobe_unwind_dotnet+0x426d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31e4, 0x426d, x86_l_426d);
x86_l_31ea:
	/* 0x31ea: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_31ef:
	/* 0x31ef: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_31f1:
	/* 0x31f1: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_31f6:
	/* 0x31f6: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_31fd:
	/* 0x31fd: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31fd, 0x7126, x86_l_7126);
x86_l_3203:
	/* 0x3203: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_320a:
	/* 0x320a: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_320e:
	/* 0x320e: ja     41a <kprobe_unwind_dotnet+0x41a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x320e, 0x41a, x86_l_41a);
x86_l_3214:
	/* 0x3214: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3217:
	/* 0x3217: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_321e:
	/* 0x321e: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_3222:
	/* 0x3222: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_322e:
	/* 0x322e: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_323a:
	/* 0x323a: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_3243:
	/* 0x3243: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_324f:
	/* 0x324f: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_325b:
	/* 0x325b: jmp    36d9 <kprobe_unwind_dotnet+0x36d9> */
	X86_SIM_X86_JMP(0x325b, 0x36d9, x86_l_36d9);
x86_l_3260:
	/* 0x3260: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_3267:
	/* 0x3267: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_326b:
	/* 0x326b: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_3272:
	/* 0x3272: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3279:
	/* 0x3279: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_327c:
	/* 0x327c: jne    3c4f <kprobe_unwind_dotnet+0x3c4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x327c, 0x3c4f, x86_l_3c4f);
x86_l_3282:
	/* 0x3282: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3284:
	/* 0x3284: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3287:
	/* 0x3287: je     3cdb <kprobe_unwind_dotnet+0x3cdb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3287, 0x3cdb, x86_l_3cdb);
x86_l_328d:
	/* 0x328d: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_328f:
	/* 0x328f: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_3292:
	/* 0x3292: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_3295:
	/* 0x3295: jae    420a <kprobe_unwind_dotnet+0x420a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3295, 0x420a, x86_l_420a);
x86_l_329b:
	/* 0x329b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_32a2:
	/* 0x32a2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32a5:
	/* 0x32a5: je     3149 <kprobe_unwind_dotnet+0x3149> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32a5, 0x3149, x86_l_3149);
x86_l_32ab:
	/* 0x32ab: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_32b5:
	/* 0x32b5: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_32ba:
	/* 0x32ba: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_32c4:
	/* 0x32c4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_32c9:
	/* 0x32c9: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_32d3:
	/* 0x32d3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_32d8:
	/* 0x32d8: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_32e2:
	/* 0x32e2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32e7:
	/* 0x32e7: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_32f1:
	/* 0x32f1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32f6:
	/* 0x32f6: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_3300:
	/* 0x3300: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3305:
	/* 0x3305: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_330a:
	/* 0x330a: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_330f:
	/* 0x330f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3311:
	/* 0x3311: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3313:
	/* 0x3313: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3316:
	/* 0x3316: call   331b <kprobe_unwind_dotnet+0x331b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_331b:
	/* 0x331b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3322:
	/* 0x3322: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3325:
	/* 0x3325: je     3149 <kprobe_unwind_dotnet+0x3149> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3325, 0x3149, x86_l_3149);
x86_l_332b:
	/* 0x332b: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_3335:
	/* 0x3335: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_333a:
	/* 0x333a: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_3344:
	/* 0x3344: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3349:
	/* 0x3349: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_3351:
	/* 0x3351: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3356:
	/* 0x3356: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_335b:
	/* 0x335b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_335d:
	/* 0x335d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_335f:
	/* 0x335f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3362:
	/* 0x3362: call   3367 <kprobe_unwind_dotnet+0x3367> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3367:
	/* 0x3367: jmp    3149 <kprobe_unwind_dotnet+0x3149> */
	X86_SIM_X86_JMP(0x3367, 0x3149, x86_l_3149);
x86_l_336c:
	/* 0x336c: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_336f:
	/* 0x336f: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_3372:
	/* 0x3372: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3375:
	/* 0x3375: je     3380 <kprobe_unwind_dotnet+0x3380> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3375, 0x3380, x86_l_3380);
x86_l_3377:
	/* 0x3377: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_337b:
	/* 0x337b: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x337b, 0x35e5, x86_l_35e5);
x86_l_3380:
	/* 0x3380: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3383:
	/* 0x3383: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_3386:
	/* 0x3386: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3389:
	/* 0x3389: je     33fe <kprobe_unwind_dotnet+0x33fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3389, 0x33fe, x86_l_33fe);
x86_l_338b:
	/* 0x338b: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_338f:
	/* 0x338f: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x338f, 0x35e5, x86_l_35e5);
x86_l_3394:
	/* 0x3394: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_339e:
	/* 0x339e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_33a3:
	/* 0x33a3: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_33ad:
	/* 0x33ad: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33b2:
	/* 0x33b2: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_33bc:
	/* 0x33bc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33c1:
	/* 0x33c1: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_33cb:
	/* 0x33cb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33d0:
	/* 0x33d0: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_33d8:
	/* 0x33d8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33dd:
	/* 0x33dd: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_33e2:
	/* 0x33e2: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_33e5:
	/* 0x33e5: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33e8:
	/* 0x33e8: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_33eb:
	/* 0x33eb: call   33f0 <kprobe_unwind_dotnet+0x33f0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_33f0:
	/* 0x33f0: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33f3:
	/* 0x33f3: jae    3007 <kprobe_unwind_dotnet+0x3007> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x33f3, 0x3007, x86_l_3007);
x86_l_33f9:
	/* 0x33f9: jmp    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JMP(0x33f9, 0x70d1, x86_l_70d1);
x86_l_33fe:
	/* 0x33fe: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3401:
	/* 0x3401: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_3404:
	/* 0x3404: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3407:
	/* 0x3407: je     3412 <kprobe_unwind_dotnet+0x3412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3407, 0x3412, x86_l_3412);
x86_l_3409:
	/* 0x3409: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_340d:
	/* 0x340d: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x340d, 0x35e5, x86_l_35e5);
x86_l_3412:
	/* 0x3412: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3415:
	/* 0x3415: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_3418:
	/* 0x3418: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_341b:
	/* 0x341b: je     350c <kprobe_unwind_dotnet+0x350c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x341b, 0x350c, x86_l_350c);
x86_l_3421:
	/* 0x3421: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_3428:
	/* 0x3428: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x3428, 0x35e5, x86_l_35e5);
x86_l_342d:
	/* 0x342d: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3437:
	/* 0x3437: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_343c:
	/* 0x343c: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3446:
	/* 0x3446: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_344b:
	/* 0x344b: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3455:
	/* 0x3455: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_345a:
	/* 0x345a: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3464:
	/* 0x3464: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3469:
	/* 0x3469: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_3473:
	/* 0x3473: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3478:
	/* 0x3478: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_3482:
	/* 0x3482: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3487:
	/* 0x3487: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_348b:
	/* 0x348b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3490:
	/* 0x3490: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_3495:
	/* 0x3495: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3497:
	/* 0x3497: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_349a:
	/* 0x349a: call   349f <kprobe_unwind_dotnet+0x349f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_349f:
	/* 0x349f: jmp    2e11 <kprobe_unwind_dotnet+0x2e11> */
	X86_SIM_X86_JMP(0x349f, 0x2e11, x86_l_2e11);
x86_l_34a4:
	/* 0x34a4: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_34ae:
	/* 0x34ae: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_34b3:
	/* 0x34b3: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_34bd:
	/* 0x34bd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_34c2:
	/* 0x34c2: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_34cc:
	/* 0x34cc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_34d1:
	/* 0x34d1: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_34db:
	/* 0x34db: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_34e0:
	/* 0x34e0: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_34e8:
	/* 0x34e8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_34ed:
	/* 0x34ed: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_34f2:
	/* 0x34f2: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_34f5:
	/* 0x34f5: call   34fa <kprobe_unwind_dotnet+0x34fa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_34fa:
	/* 0x34fa: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_3501:
	/* 0x3501: jae    30ce <kprobe_unwind_dotnet+0x30ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3501, 0x30ce, x86_l_30ce);
x86_l_3507:
	/* 0x3507: jmp    362b <kprobe_unwind_dotnet+0x362b> */
	X86_SIM_X86_JMP(0x3507, 0x362b, x86_l_362b);
x86_l_350c:
	/* 0x350c: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_350f:
	/* 0x350f: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_3512:
	/* 0x3512: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_3515:
	/* 0x3515: je     35d7 <kprobe_unwind_dotnet+0x35d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3515, 0x35d7, x86_l_35d7);
x86_l_351b:
	/* 0x351b: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_3522:
	/* 0x3522: jmp    35e5 <kprobe_unwind_dotnet+0x35e5> */
	X86_SIM_X86_JMP(0x3522, 0x35e5, x86_l_35e5);
x86_l_3527:
	/* 0x3527: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_352e:
	/* 0x352e: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3533:
	/* 0x3533: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3538:
	/* 0x3538: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_353b:
	/* 0x353b: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_353e:
	/* 0x353e: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_3545:
	/* 0x3545: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3548:
	/* 0x3548: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_354d:
	/* 0x354d: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3550:
	/* 0x3550: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3553:
	/* 0x3553: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3556:
	/* 0x3556: call   355b <kprobe_unwind_dotnet+0x355b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_355b:
	/* 0x355b: jmp    30f2 <kprobe_unwind_dotnet+0x30f2> */
	X86_SIM_X86_JMP(0x355b, 0x30f2, x86_l_30f2);
x86_l_3560:
	/* 0x3560: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_356a:
	/* 0x356a: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_356f:
	/* 0x356f: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3579:
	/* 0x3579: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_357e:
	/* 0x357e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3588:
	/* 0x3588: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_358d:
	/* 0x358d: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3597:
	/* 0x3597: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_359c:
	/* 0x359c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_35a6:
	/* 0x35a6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_35ab:
	/* 0x35ab: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_35b5:
	/* 0x35b5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35ba:
	/* 0x35ba: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_35be:
	/* 0x35be: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35c3:
	/* 0x35c3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_35c8:
	/* 0x35c8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35ca:
	/* 0x35ca: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35cd:
	/* 0x35cd: call   35d2 <kprobe_unwind_dotnet+0x35d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_35d2:
	/* 0x35d2: jmp    2fbe <kprobe_unwind_dotnet+0x2fbe> */
	X86_SIM_X86_JMP(0x35d2, 0x2fbe, x86_l_2fbe);
x86_l_35d7:
	/* 0x35d7: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_35db:
	/* 0x35db: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_35e2:
	/* 0x35e2: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_35e5:
	/* 0x35e5: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_35e8:
	/* 0x35e8: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_35f0:
	/* 0x35f0: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_35f3:
	/* 0x35f3: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_35fa:
	/* 0x35fa: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35fd:
	/* 0x35fd: jne    3a67 <kprobe_unwind_dotnet+0x3a67> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35fd, 0x3a67, x86_l_3a67);
x86_l_3603:
	/* 0x3603: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_3607:
	/* 0x3607: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_360c:
	/* 0x360c: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3611:
	/* 0x3611: call   3616 <kprobe_unwind_dotnet+0x3616> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3616:
	/* 0x3616: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3619:
	/* 0x3619: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3620:
	/* 0x3620: jne    9fa <kprobe_unwind_dotnet+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3620, 0x9fa, x86_l_9fa);
x86_l_3626:
	/* 0x3626: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_362b:
	/* 0x362b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3632:
	/* 0x3632: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3635:
	/* 0x3635: jne    3879 <kprobe_unwind_dotnet+0x3879> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3635, 0x3879, x86_l_3879);
x86_l_363b:
	/* 0x363b: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3642:
	/* 0x3642: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_3646:
	/* 0x3646: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3646, 0xa4e, x86_l_a4e);
x86_l_364c:
	/* 0x364c: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3651:
	/* 0x3651: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_3654:
	/* 0x3654: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_3658:
	/* 0x3658: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_365b:
	/* 0x365b: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_365e:
	/* 0x365e: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3665:
	/* 0x3665: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_3669:
	/* 0x3669: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_3671:
	/* 0x3671: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_3679:
	/* 0x3679: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_3682:
	/* 0x3682: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_3687:
	/* 0x3687: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_368f:
	/* 0x368f: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_369b:
	/* 0x369b: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_36a6:
	/* 0x36a6: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_36ae:
	/* 0x36ae: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_36b5:
	/* 0x36b5: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_36ba:
	/* 0x36ba: call   36bf <kprobe_unwind_dotnet+0x36bf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_36bf:
	/* 0x36bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36c2:
	/* 0x36c2: je     36c9 <kprobe_unwind_dotnet+0x36c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36c2, 0x36c9, x86_l_36c9);
x86_l_36c4:
	/* 0x36c4: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_36c7:
	/* 0x36c7: jmp    36d9 <kprobe_unwind_dotnet+0x36d9> */
	X86_SIM_X86_JMP(0x36c7, 0x36d9, x86_l_36d9);
x86_l_36c9:
	/* 0x36c9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_36d0:
	/* 0x36d0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36d3:
	/* 0x36d3: jne    3966 <kprobe_unwind_dotnet+0x3966> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36d3, 0x3966, x86_l_3966);
x86_l_36d9:
	/* 0x36d9: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_36e1:
	/* 0x36e1: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36e4:
	/* 0x36e4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_36eb:
	/* 0x36eb: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36ed:
	/* 0x36ed: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_36f0:
	/* 0x36f0: je     8172 <kprobe_unwind_dotnet+0x8172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36f0, 0x8172, x86_l_8172);
x86_l_36f6:
	/* 0x36f6: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_36f8:
	/* 0x36f8: jne    38cd <kprobe_unwind_dotnet+0x38cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36f8, 0x38cd, x86_l_38cd);
x86_l_36fe:
	/* 0x36fe: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_3708:
	/* 0x3708: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_370b:
	/* 0x370b: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x370b, 0x21d0, x86_l_21d0);
x86_l_3711:
	/* 0x3711: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_3718:
	/* 0x3718: jb     2358 <kprobe_unwind_dotnet+0x2358> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3718, 0x2358, x86_l_2358);
x86_l_371e:
	/* 0x371e: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3721:
	/* 0x3721: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_3729:
	/* 0x3729: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_372f:
	/* 0x372f: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_3736:
	/* 0x3736: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_373d:
	/* 0x373d: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3742:
	/* 0x3742: call   3747 <kprobe_unwind_dotnet+0x3747> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3747:
	/* 0x3747: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_374a:
	/* 0x374a: je     80c1 <kprobe_unwind_dotnet+0x80c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x374a, 0x80c1, x86_l_80c1);
x86_l_3750:
	/* 0x3750: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3754:
	/* 0x3754: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3757:
	/* 0x3757: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_3761:
	/* 0x3761: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3764:
	/* 0x3764: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_376b:
	/* 0x376b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_376e:
	/* 0x376e: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3775:
	/* 0x3775: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_3779:
	/* 0x3779: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_377c:
	/* 0x377c: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_377f:
	/* 0x377f: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3786:
	/* 0x3786: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_378d:
	/* 0x378d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3790:
	/* 0x3790: jne    3b54 <kprobe_unwind_dotnet+0x3b54> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3790, 0x3b54, x86_l_3b54);
x86_l_3796:
	/* 0x3796: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_379a:
	/* 0x379a: jne    4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x379a, 0x4408, x86_l_4408);
x86_l_37a0:
	/* 0x37a0: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_37a7:
	/* 0x37a7: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_37ac:
	/* 0x37ac: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_37b3:
	/* 0x37b3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_37ba:
	/* 0x37ba: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_37bf:
	/* 0x37bf: call   37c4 <kprobe_unwind_dotnet+0x37c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_37c4:
	/* 0x37c4: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_37ca:
	/* 0x37ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37cd:
	/* 0x37cd: je     4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37cd, 0x4408, x86_l_4408);
x86_l_37d3:
	/* 0x37d3: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37d6:
	/* 0x37d6: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37d9:
	/* 0x37d9: ja     37e1 <kprobe_unwind_dotnet+0x37e1> */
	X86_SIM_X86_JCC(X86_CC_A, 0x37d9, 0x37e1, x86_l_37e1);
x86_l_37db:
	/* 0x37db: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37df:
	/* 0x37df: jae    37f5 <kprobe_unwind_dotnet+0x37f5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x37df, 0x37f5, x86_l_37f5);
x86_l_37e1:
	/* 0x37e1: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37e5:
	/* 0x37e5: ja     4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JCC(X86_CC_A, 0x37e5, 0x4408, x86_l_4408);
x86_l_37eb:
	/* 0x37eb: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37ef:
	/* 0x37ef: jb     4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JCC(X86_CC_B, 0x37ef, 0x4408, x86_l_4408);
x86_l_37f5:
	/* 0x37f5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_37fc:
	/* 0x37fc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37ff:
	/* 0x37ff: jne    4367 <kprobe_unwind_dotnet+0x4367> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37ff, 0x4367, x86_l_4367);
x86_l_3805:
	/* 0x3805: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_380c:
	/* 0x380c: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3810:
	/* 0x3810: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3813:
	/* 0x3813: jae    43d0 <kprobe_unwind_dotnet+0x43d0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3813, 0x43d0, x86_l_43d0);
x86_l_3819:
	/* 0x3819: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3820:
	/* 0x3820: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3823:
	/* 0x3823: je     4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3823, 0x4408, x86_l_4408);
x86_l_3829:
	/* 0x3829: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_3833:
	/* 0x3833: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3838:
	/* 0x3838: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_3842:
	/* 0x3842: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3847:
	/* 0x3847: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_3851:
	/* 0x3851: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3856:
	/* 0x3856: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_385e:
	/* 0x385e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3863:
	/* 0x3863: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_3868:
	/* 0x3868: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_386a:
	/* 0x386a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_386c:
	/* 0x386c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_386f:
	/* 0x386f: call   3874 <kprobe_unwind_dotnet+0x3874> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3874:
	/* 0x3874: jmp    4408 <kprobe_unwind_dotnet+0x4408> */
	X86_SIM_X86_JMP(0x3874, 0x4408, x86_l_4408);
x86_l_3879:
	/* 0x3879: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_3880:
	/* 0x3880: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3885:
	/* 0x3885: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_388a:
	/* 0x388a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_388d:
	/* 0x388d: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_3890:
	/* 0x3890: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_3895:
	/* 0x3895: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_389c:
	/* 0x389c: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_38a1:
	/* 0x38a1: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_38a4:
	/* 0x38a4: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_38a7:
	/* 0x38a7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38aa:
	/* 0x38aa: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_38af:
	/* 0x38af: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_38b2:
	/* 0x38b2: call   38b7 <kprobe_unwind_dotnet+0x38b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_38b7:
	/* 0x38b7: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_38be:
	/* 0x38be: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_38c2:
	/* 0x38c2: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x38c2, 0xa4e, x86_l_a4e);
x86_l_38c8:
	/* 0x38c8: jmp    364c <kprobe_unwind_dotnet+0x364c> */
	X86_SIM_X86_JMP(0x38c8, 0x364c, x86_l_364c);
x86_l_38cd:
	/* 0x38cd: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_38d7:
	/* 0x38d7: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_38dc:
	/* 0x38dc: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_38e6:
	/* 0x38e6: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_38eb:
	/* 0x38eb: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_38f5:
	/* 0x38f5: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_38fa:
	/* 0x38fa: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_3904:
	/* 0x3904: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3909:
	/* 0x3909: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_3913:
	/* 0x3913: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3918:
	/* 0x3918: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_3922:
	/* 0x3922: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3927:
	/* 0x3927: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_392c:
	/* 0x392c: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3933:
	/* 0x3933: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3938:
	/* 0x3938: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_393d:
	/* 0x393d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_393f:
	/* 0x393f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3942:
	/* 0x3942: call   3947 <kprobe_unwind_dotnet+0x3947> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3947:
	/* 0x3947: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_394e:
	/* 0x394e: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_3958:
	/* 0x3958: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_395b:
	/* 0x395b: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x395b, 0x21d0, x86_l_21d0);
x86_l_3961:
	/* 0x3961: jmp    3711 <kprobe_unwind_dotnet+0x3711> */
	X86_SIM_X86_JMP(0x3961, 0x3711, x86_l_3711);
x86_l_3966:
	/* 0x3966: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3970:
	/* 0x3970: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3975:
	/* 0x3975: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_397f:
	/* 0x397f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3984:
	/* 0x3984: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_398e:
	/* 0x398e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3993:
	/* 0x3993: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_399d:
	/* 0x399d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_39a2:
	/* 0x39a2: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_39ac:
	/* 0x39ac: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_39b1:
	/* 0x39b1: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_39bb:
	/* 0x39bb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39c0:
	/* 0x39c0: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_39c4:
	/* 0x39c4: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39c9:
	/* 0x39c9: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_39ce:
	/* 0x39ce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39d0:
	/* 0x39d0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39d3:
	/* 0x39d3: call   39d8 <kprobe_unwind_dotnet+0x39d8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_39d8:
	/* 0x39d8: jmp    36d9 <kprobe_unwind_dotnet+0x36d9> */
	X86_SIM_X86_JMP(0x39d8, 0x36d9, x86_l_36d9);
x86_l_39dd:
	/* 0x39dd: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_39e0:
	/* 0x39e0: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_39e4:
	/* 0x39e4: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_39ee:
	/* 0x39ee: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_39f3:
	/* 0x39f3: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_39fd:
	/* 0x39fd: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3a02:
	/* 0x3a02: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_3a0c:
	/* 0x3a0c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3a11:
	/* 0x3a11: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_3a1b:
	/* 0x3a1b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a20:
	/* 0x3a20: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_3a2a:
	/* 0x3a2a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a2f:
	/* 0x3a2f: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_3a39:
	/* 0x3a39: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3a3e:
	/* 0x3a3e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_3a48:
	/* 0x3a48: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a4d:
	/* 0x3a4d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a52:
	/* 0x3a52: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_3a57:
	/* 0x3a57: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a5a:
	/* 0x3a5a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a5d:
	/* 0x3a5d: call   3a62 <kprobe_unwind_dotnet+0x3a62> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3a62:
	/* 0x3a62: jmp    3183 <kprobe_unwind_dotnet+0x3183> */
	X86_SIM_X86_JMP(0x3a62, 0x3183, x86_l_3183);
x86_l_3a67:
	/* 0x3a67: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3a69:
	/* 0x3a69: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_3a73:
	/* 0x3a73: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3a78:
	/* 0x3a78: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_3a82:
	/* 0x3a82: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3a87:
	/* 0x3a87: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_3a91:
	/* 0x3a91: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a96:
	/* 0x3a96: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_3aa0:
	/* 0x3aa0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3aa5:
	/* 0x3aa5: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_3aaf:
	/* 0x3aaf: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ab4:
	/* 0x3ab4: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_3abe:
	/* 0x3abe: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ac3:
	/* 0x3ac3: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ac8:
	/* 0x3ac8: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_3acd:
	/* 0x3acd: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3ad0:
	/* 0x3ad0: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3ad3:
	/* 0x3ad3: call   3ad8 <kprobe_unwind_dotnet+0x3ad8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3ad8:
	/* 0x3ad8: jmp    3603 <kprobe_unwind_dotnet+0x3603> */
	X86_SIM_X86_JMP(0x3ad8, 0x3603, x86_l_3603);
x86_l_3add:
	/* 0x3add: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3ae7:
	/* 0x3ae7: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3aec:
	/* 0x3aec: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3af6:
	/* 0x3af6: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3afb:
	/* 0x3afb: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3b05:
	/* 0x3b05: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3b0a:
	/* 0x3b0a: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3b14:
	/* 0x3b14: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b19:
	/* 0x3b19: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_3b23:
	/* 0x3b23: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b28:
	/* 0x3b28: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_3b32:
	/* 0x3b32: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b37:
	/* 0x3b37: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3b3b:
	/* 0x3b3b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b40:
	/* 0x3b40: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_3b45:
	/* 0x3b45: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b47:
	/* 0x3b47: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b4a:
	/* 0x3b4a: call   3b4f <kprobe_unwind_dotnet+0x3b4f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3b4f:
	/* 0x3b4f: jmp    31d3 <kprobe_unwind_dotnet+0x31d3> */
	X86_SIM_X86_JMP(0x3b4f, 0x31d3, x86_l_31d3);
x86_l_3b54:
	/* 0x3b54: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_3b5e:
	/* 0x3b5e: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3b63:
	/* 0x3b63: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_3b6d:
	/* 0x3b6d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3b72:
	/* 0x3b72: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_3b7c:
	/* 0x3b7c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3b81:
	/* 0x3b81: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_3b8b:
	/* 0x3b8b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b90:
	/* 0x3b90: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_3b9a:
	/* 0x3b9a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b9f:
	/* 0x3b9f: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_3ba9:
	/* 0x3ba9: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3bae:
	/* 0x3bae: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_3bb5:
	/* 0x3bb5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3bba:
	/* 0x3bba: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_3bbf:
	/* 0x3bbf: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3bc2:
	/* 0x3bc2: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3bc5:
	/* 0x3bc5: call   3bca <kprobe_unwind_dotnet+0x3bca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3bca:
	/* 0x3bca: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3bd1:
	/* 0x3bd1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bd4:
	/* 0x3bd4: je     3796 <kprobe_unwind_dotnet+0x3796> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bd4, 0x3796, x86_l_3796);
x86_l_3bda:
	/* 0x3bda: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_3be4:
	/* 0x3be4: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_3be9:
	/* 0x3be9: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_3bf3:
	/* 0x3bf3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3bf8:
	/* 0x3bf8: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_3c02:
	/* 0x3c02: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3c07:
	/* 0x3c07: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_3c11:
	/* 0x3c11: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3c16:
	/* 0x3c16: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_3c20:
	/* 0x3c20: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3c25:
	/* 0x3c25: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c2a:
	/* 0x3c2a: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3c31:
	/* 0x3c31: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3c38:
	/* 0x3c38: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c3d:
	/* 0x3c3d: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_3c42:
	/* 0x3c42: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c45:
	/* 0x3c45: call   3c4a <kprobe_unwind_dotnet+0x3c4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3c4a:
	/* 0x3c4a: jmp    3796 <kprobe_unwind_dotnet+0x3796> */
	X86_SIM_X86_JMP(0x3c4a, 0x3796, x86_l_3796);
x86_l_3c4f:
	/* 0x3c4f: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_3c59:
	/* 0x3c59: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_3c5e:
	/* 0x3c5e: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_3c68:
	/* 0x3c68: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3c6d:
	/* 0x3c6d: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_3c77:
	/* 0x3c77: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3c7c:
	/* 0x3c7c: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_3c86:
	/* 0x3c86: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3c8b:
	/* 0x3c8b: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_3c95:
	/* 0x3c95: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3c9a:
	/* 0x3c9a: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_3ca4:
	/* 0x3ca4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ca9:
	/* 0x3ca9: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_3cb3:
	/* 0x3cb3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3cb8:
	/* 0x3cb8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3cbd:
	/* 0x3cbd: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_3cc2:
	/* 0x3cc2: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3cc5:
	/* 0x3cc5: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3cc8:
	/* 0x3cc8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ccb:
	/* 0x3ccb: call   3cd0 <kprobe_unwind_dotnet+0x3cd0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3cd0:
	/* 0x3cd0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3cd2:
	/* 0x3cd2: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3cd5:
	/* 0x3cd5: jne    328d <kprobe_unwind_dotnet+0x328d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3cd5, 0x328d, x86_l_328d);
x86_l_3cdb:
	/* 0x3cdb: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_3ce2:
	/* 0x3ce2: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_3ce7:
	/* 0x3ce7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cea:
	/* 0x3cea: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3cea, 0x41e2, x86_l_41e2);
x86_l_3cf0:
	/* 0x3cf0: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_3cf7:
	/* 0x3cf7: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_3cfc:
	/* 0x3cfc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cff:
	/* 0x3cff: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3cff, 0x41e2, x86_l_41e2);
x86_l_3d05:
	/* 0x3d05: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_3d0c:
	/* 0x3d0c: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_3d11:
	/* 0x3d11: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d14:
	/* 0x3d14: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d14, 0x41e2, x86_l_41e2);
x86_l_3d1a:
	/* 0x3d1a: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_3d21:
	/* 0x3d21: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_3d26:
	/* 0x3d26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d29:
	/* 0x3d29: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d29, 0x41e2, x86_l_41e2);
x86_l_3d2f:
	/* 0x3d2f: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_3d36:
	/* 0x3d36: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_3d3b:
	/* 0x3d3b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d3e:
	/* 0x3d3e: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d3e, 0x41e2, x86_l_41e2);
x86_l_3d44:
	/* 0x3d44: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_3d4b:
	/* 0x3d4b: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_3d50:
	/* 0x3d50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d53:
	/* 0x3d53: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d53, 0x41e2, x86_l_41e2);
x86_l_3d59:
	/* 0x3d59: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_3d60:
	/* 0x3d60: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_3d65:
	/* 0x3d65: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d68:
	/* 0x3d68: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d68, 0x41e2, x86_l_41e2);
x86_l_3d6e:
	/* 0x3d6e: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_3d75:
	/* 0x3d75: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_3d7a:
	/* 0x3d7a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d7d:
	/* 0x3d7d: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d7d, 0x41e2, x86_l_41e2);
x86_l_3d83:
	/* 0x3d83: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_3d8a:
	/* 0x3d8a: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_3d8f:
	/* 0x3d8f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d92:
	/* 0x3d92: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d92, 0x41e2, x86_l_41e2);
x86_l_3d98:
	/* 0x3d98: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_3d9f:
	/* 0x3d9f: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_3da4:
	/* 0x3da4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3da7:
	/* 0x3da7: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3da7, 0x41e2, x86_l_41e2);
x86_l_3dad:
	/* 0x3dad: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_3db4:
	/* 0x3db4: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_3db9:
	/* 0x3db9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dbc:
	/* 0x3dbc: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3dbc, 0x41e2, x86_l_41e2);
x86_l_3dc2:
	/* 0x3dc2: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_3dc9:
	/* 0x3dc9: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_3dce:
	/* 0x3dce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dd1:
	/* 0x3dd1: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3dd1, 0x41e2, x86_l_41e2);
x86_l_3dd7:
	/* 0x3dd7: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_3dde:
	/* 0x3dde: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_3de3:
	/* 0x3de3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3de6:
	/* 0x3de6: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3de6, 0x41e2, x86_l_41e2);
x86_l_3dec:
	/* 0x3dec: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_3df3:
	/* 0x3df3: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_3df8:
	/* 0x3df8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dfb:
	/* 0x3dfb: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3dfb, 0x41e2, x86_l_41e2);
x86_l_3e01:
	/* 0x3e01: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_3e08:
	/* 0x3e08: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_3e0d:
	/* 0x3e0d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e10:
	/* 0x3e10: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e10, 0x41e2, x86_l_41e2);
x86_l_3e16:
	/* 0x3e16: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_3e1d:
	/* 0x3e1d: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_3e22:
	/* 0x3e22: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e25:
	/* 0x3e25: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e25, 0x41e2, x86_l_41e2);
x86_l_3e2b:
	/* 0x3e2b: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_3e32:
	/* 0x3e32: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_3e37:
	/* 0x3e37: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e3a:
	/* 0x3e3a: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e3a, 0x41e2, x86_l_41e2);
x86_l_3e40:
	/* 0x3e40: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_3e47:
	/* 0x3e47: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_3e4c:
	/* 0x3e4c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e4f:
	/* 0x3e4f: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e4f, 0x41e2, x86_l_41e2);
x86_l_3e55:
	/* 0x3e55: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_3e5c:
	/* 0x3e5c: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_3e61:
	/* 0x3e61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e64:
	/* 0x3e64: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e64, 0x41e2, x86_l_41e2);
x86_l_3e6a:
	/* 0x3e6a: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_3e71:
	/* 0x3e71: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_3e76:
	/* 0x3e76: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e79:
	/* 0x3e79: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e79, 0x41e2, x86_l_41e2);
x86_l_3e7f:
	/* 0x3e7f: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_3e86:
	/* 0x3e86: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_3e8b:
	/* 0x3e8b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e8e:
	/* 0x3e8e: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e8e, 0x41e2, x86_l_41e2);
x86_l_3e94:
	/* 0x3e94: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_3e9b:
	/* 0x3e9b: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_3ea0:
	/* 0x3ea0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ea3:
	/* 0x3ea3: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ea3, 0x41e2, x86_l_41e2);
x86_l_3ea9:
	/* 0x3ea9: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_3eb0:
	/* 0x3eb0: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_3eb5:
	/* 0x3eb5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3eb8:
	/* 0x3eb8: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3eb8, 0x41e2, x86_l_41e2);
x86_l_3ebe:
	/* 0x3ebe: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_3ec5:
	/* 0x3ec5: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_3eca:
	/* 0x3eca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ecd:
	/* 0x3ecd: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ecd, 0x41e2, x86_l_41e2);
x86_l_3ed3:
	/* 0x3ed3: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_3eda:
	/* 0x3eda: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_3edf:
	/* 0x3edf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ee2:
	/* 0x3ee2: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ee2, 0x41e2, x86_l_41e2);
x86_l_3ee8:
	/* 0x3ee8: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_3eef:
	/* 0x3eef: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_3ef4:
	/* 0x3ef4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ef7:
	/* 0x3ef7: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ef7, 0x41e2, x86_l_41e2);
x86_l_3efd:
	/* 0x3efd: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_3f04:
	/* 0x3f04: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_3f09:
	/* 0x3f09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f0c:
	/* 0x3f0c: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f0c, 0x41e2, x86_l_41e2);
x86_l_3f12:
	/* 0x3f12: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_3f19:
	/* 0x3f19: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_3f1e:
	/* 0x3f1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f21:
	/* 0x3f21: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f21, 0x41e2, x86_l_41e2);
x86_l_3f27:
	/* 0x3f27: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_3f2e:
	/* 0x3f2e: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_3f33:
	/* 0x3f33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f36:
	/* 0x3f36: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f36, 0x41e2, x86_l_41e2);
x86_l_3f3c:
	/* 0x3f3c: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_3f43:
	/* 0x3f43: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_3f48:
	/* 0x3f48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f4b:
	/* 0x3f4b: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f4b, 0x41e2, x86_l_41e2);
x86_l_3f51:
	/* 0x3f51: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_3f58:
	/* 0x3f58: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_3f5d:
	/* 0x3f5d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f60:
	/* 0x3f60: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f60, 0x41e2, x86_l_41e2);
x86_l_3f66:
	/* 0x3f66: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_3f6d:
	/* 0x3f6d: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_3f72:
	/* 0x3f72: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f75:
	/* 0x3f75: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f75, 0x41e2, x86_l_41e2);
x86_l_3f7b:
	/* 0x3f7b: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_3f82:
	/* 0x3f82: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_3f87:
	/* 0x3f87: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f8a:
	/* 0x3f8a: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f8a, 0x41e2, x86_l_41e2);
x86_l_3f90:
	/* 0x3f90: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_3f97:
	/* 0x3f97: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_3f9c:
	/* 0x3f9c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f9f:
	/* 0x3f9f: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f9f, 0x41e2, x86_l_41e2);
x86_l_3fa5:
	/* 0x3fa5: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_3fac:
	/* 0x3fac: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_3fb1:
	/* 0x3fb1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fb4:
	/* 0x3fb4: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3fb4, 0x41e2, x86_l_41e2);
x86_l_3fba:
	/* 0x3fba: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_3fc1:
	/* 0x3fc1: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_3fc6:
	/* 0x3fc6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fc9:
	/* 0x3fc9: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3fc9, 0x41e2, x86_l_41e2);
x86_l_3fcf:
	/* 0x3fcf: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_3fd6:
	/* 0x3fd6: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_3fdb:
	/* 0x3fdb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fde:
	/* 0x3fde: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3fde, 0x41e2, x86_l_41e2);
x86_l_3fe4:
	/* 0x3fe4: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_3feb:
	/* 0x3feb: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_3ff0:
	/* 0x3ff0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ff3:
	/* 0x3ff3: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ff3, 0x41e2, x86_l_41e2);
x86_l_3ff9:
	/* 0x3ff9: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_4000:
	/* 0x4000: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_4005:
	/* 0x4005: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4008:
	/* 0x4008: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4008, 0x41e2, x86_l_41e2);
x86_l_400e:
	/* 0x400e: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_4015:
	/* 0x4015: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_401a:
	/* 0x401a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_401d:
	/* 0x401d: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x401d, 0x41e2, x86_l_41e2);
x86_l_4023:
	/* 0x4023: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_402a:
	/* 0x402a: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_402f:
	/* 0x402f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4032:
	/* 0x4032: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4032, 0x41e2, x86_l_41e2);
x86_l_4038:
	/* 0x4038: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_403f:
	/* 0x403f: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_4044:
	/* 0x4044: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4047:
	/* 0x4047: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4047, 0x41e2, x86_l_41e2);
x86_l_404d:
	/* 0x404d: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_4054:
	/* 0x4054: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_4059:
	/* 0x4059: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_405c:
	/* 0x405c: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x405c, 0x41e2, x86_l_41e2);
x86_l_4062:
	/* 0x4062: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_4069:
	/* 0x4069: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_406e:
	/* 0x406e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4071:
	/* 0x4071: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4071, 0x41e2, x86_l_41e2);
x86_l_4077:
	/* 0x4077: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_407e:
	/* 0x407e: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_4083:
	/* 0x4083: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4086:
	/* 0x4086: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4086, 0x41e2, x86_l_41e2);
x86_l_408c:
	/* 0x408c: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_4093:
	/* 0x4093: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_4098:
	/* 0x4098: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_409b:
	/* 0x409b: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x409b, 0x41e2, x86_l_41e2);
x86_l_40a1:
	/* 0x40a1: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_40a8:
	/* 0x40a8: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_40ad:
	/* 0x40ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40b0:
	/* 0x40b0: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40b0, 0x41e2, x86_l_41e2);
x86_l_40b6:
	/* 0x40b6: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_40bd:
	/* 0x40bd: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_40c2:
	/* 0x40c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40c5:
	/* 0x40c5: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40c5, 0x41e2, x86_l_41e2);
x86_l_40cb:
	/* 0x40cb: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_40d2:
	/* 0x40d2: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_40d7:
	/* 0x40d7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40da:
	/* 0x40da: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40da, 0x41e2, x86_l_41e2);
x86_l_40e0:
	/* 0x40e0: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_40e7:
	/* 0x40e7: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_40ec:
	/* 0x40ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40ef:
	/* 0x40ef: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40ef, 0x41e2, x86_l_41e2);
x86_l_40f5:
	/* 0x40f5: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_40fc:
	/* 0x40fc: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_4101:
	/* 0x4101: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4104:
	/* 0x4104: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4104, 0x41e2, x86_l_41e2);
x86_l_410a:
	/* 0x410a: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_4111:
	/* 0x4111: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_4116:
	/* 0x4116: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4119:
	/* 0x4119: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4119, 0x41e2, x86_l_41e2);
x86_l_411f:
	/* 0x411f: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_4126:
	/* 0x4126: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_412b:
	/* 0x412b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_412e:
	/* 0x412e: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x412e, 0x41e2, x86_l_41e2);
x86_l_4134:
	/* 0x4134: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_413b:
	/* 0x413b: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_4140:
	/* 0x4140: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4143:
	/* 0x4143: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4143, 0x41e2, x86_l_41e2);
x86_l_4149:
	/* 0x4149: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_4150:
	/* 0x4150: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_4155:
	/* 0x4155: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4158:
	/* 0x4158: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4158, 0x41e2, x86_l_41e2);
x86_l_415e:
	/* 0x415e: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_4165:
	/* 0x4165: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_416a:
	/* 0x416a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_416d:
	/* 0x416d: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x416d, 0x41e2, x86_l_41e2);
x86_l_416f:
	/* 0x416f: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_4176:
	/* 0x4176: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_417b:
	/* 0x417b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_417e:
	/* 0x417e: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x417e, 0x41e2, x86_l_41e2);
x86_l_4180:
	/* 0x4180: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_4187:
	/* 0x4187: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_418c:
	/* 0x418c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_418f:
	/* 0x418f: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x418f, 0x41e2, x86_l_41e2);
x86_l_4191:
	/* 0x4191: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_4198:
	/* 0x4198: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_419d:
	/* 0x419d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41a0:
	/* 0x41a0: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41a0, 0x41e2, x86_l_41e2);
x86_l_41a2:
	/* 0x41a2: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_41a9:
	/* 0x41a9: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_41ae:
	/* 0x41ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41b1:
	/* 0x41b1: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41b1, 0x41e2, x86_l_41e2);
x86_l_41b3:
	/* 0x41b3: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_41ba:
	/* 0x41ba: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_41bf:
	/* 0x41bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41c2:
	/* 0x41c2: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41c2, 0x41e2, x86_l_41e2);
x86_l_41c4:
	/* 0x41c4: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_41cb:
	/* 0x41cb: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_41d0:
	/* 0x41d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41d3:
	/* 0x41d3: jne    41e2 <kprobe_unwind_dotnet+0x41e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41d3, 0x41e2, x86_l_41e2);
x86_l_41d5:
	/* 0x41d5: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_41dd:
	/* 0x41dd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41e0:
	/* 0x41e0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41e2:
	/* 0x41e2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41e4:
	/* 0x41e4: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41e7:
	/* 0x41e7: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_41eb:
	/* 0x41eb: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_41ef:
	/* 0x41ef: jne    41f4 <kprobe_unwind_dotnet+0x41f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41ef, 0x41f4, x86_l_41f4);
x86_l_41f1:
	/* 0x41f1: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_41f4:
	/* 0x41f4: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_41f7:
	/* 0x41f7: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_41f9:
	/* 0x41f9: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_41fc:
	/* 0x41fc: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_41fe:
	/* 0x41fe: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_4201:
	/* 0x4201: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4204:
	/* 0x4204: jb     329b <kprobe_unwind_dotnet+0x329b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4204, 0x329b, x86_l_329b);
x86_l_420a:
	/* 0x420a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4211:
	/* 0x4211: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4214:
	/* 0x4214: jne    42d1 <kprobe_unwind_dotnet+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4214, 0x42d1, x86_l_42d1);
x86_l_421a:
	/* 0x421a: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_421d:
	/* 0x421d: jne    319f <kprobe_unwind_dotnet+0x319f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x421d, 0x319f, x86_l_319f);
x86_l_4223:
	/* 0x4223: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_422b:
	/* 0x422b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_4232:
	/* 0x4232: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4237:
	/* 0x4237: call   423c <kprobe_unwind_dotnet+0x423c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_423c:
	/* 0x423c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_423f:
	/* 0x423f: je     4246 <kprobe_unwind_dotnet+0x4246> */
	X86_SIM_X86_JCC(X86_CC_E, 0x423f, 0x4246, x86_l_4246);
x86_l_4241:
	/* 0x4241: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4244:
	/* 0x4244: jmp    4256 <kprobe_unwind_dotnet+0x4256> */
	X86_SIM_X86_JMP(0x4244, 0x4256, x86_l_4256);
x86_l_4246:
	/* 0x4246: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_424d:
	/* 0x424d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4250:
	/* 0x4250: jne    4872 <kprobe_unwind_dotnet+0x4872> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4250, 0x4872, x86_l_4872);
x86_l_4256:
	/* 0x4256: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_425b:
	/* 0x425b: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_425d:
	/* 0x425d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4264:
	/* 0x4264: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4267:
	/* 0x4267: je     31ea <kprobe_unwind_dotnet+0x31ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4267, 0x31ea, x86_l_31ea);
x86_l_426d:
	/* 0x426d: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_4277:
	/* 0x4277: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_427c:
	/* 0x427c: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_4286:
	/* 0x4286: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_428b:
	/* 0x428b: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_4295:
	/* 0x4295: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_429a:
	/* 0x429a: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_42a4:
	/* 0x42a4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_42a9:
	/* 0x42a9: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_42b3:
	/* 0x42b3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_42b8:
	/* 0x42b8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_42bd:
	/* 0x42bd: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_42c2:
	/* 0x42c2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42c4:
	/* 0x42c4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42c7:
	/* 0x42c7: call   42cc <kprobe_unwind_dotnet+0x42cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_42cc:
	/* 0x42cc: jmp    31ea <kprobe_unwind_dotnet+0x31ea> */
	X86_SIM_X86_JMP(0x42cc, 0x31ea, x86_l_31ea);
x86_l_42d1:
	/* 0x42d1: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_42db:
	/* 0x42db: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_42e0:
	/* 0x42e0: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_42ea:
	/* 0x42ea: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_42ef:
	/* 0x42ef: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_42f9:
	/* 0x42f9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_42fe:
	/* 0x42fe: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_4308:
	/* 0x4308: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_430d:
	/* 0x430d: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_4317:
	/* 0x4317: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_431c:
	/* 0x431c: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_4326:
	/* 0x4326: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_432b:
	/* 0x432b: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4335:
	/* 0x4335: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_433a:
	/* 0x433a: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_4342:
	/* 0x4342: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4344:
	/* 0x4344: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4347:
	/* 0x4347: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_434c:
	/* 0x434c: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_4351:
	/* 0x4351: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4354:
	/* 0x4354: call   4359 <kprobe_unwind_dotnet+0x4359> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4359:
	/* 0x4359: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_435c:
	/* 0x435c: jne    319f <kprobe_unwind_dotnet+0x319f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x435c, 0x319f, x86_l_319f);
x86_l_4362:
	/* 0x4362: jmp    4223 <kprobe_unwind_dotnet+0x4223> */
	X86_SIM_X86_JMP(0x4362, 0x4223, x86_l_4223);
x86_l_4367:
	/* 0x4367: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_4371:
	/* 0x4371: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_4376:
	/* 0x4376: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_4380:
	/* 0x4380: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4385:
	/* 0x4385: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_438f:
	/* 0x438f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4394:
	/* 0x4394: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_439e:
	/* 0x439e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_43a3:
	/* 0x43a3: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_43a8:
	/* 0x43a8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_43ad:
	/* 0x43ad: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_43b2:
	/* 0x43b2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_43b4:
	/* 0x43b4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_43b7:
	/* 0x43b7: call   43bc <kprobe_unwind_dotnet+0x43bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_43bc:
	/* 0x43bc: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_43c3:
	/* 0x43c3: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_43c7:
	/* 0x43c7: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_43ca:
	/* 0x43ca: jb     3819 <kprobe_unwind_dotnet+0x3819> */
	X86_SIM_X86_JCC(X86_CC_B, 0x43ca, 0x3819, x86_l_3819);
x86_l_43d0:
	/* 0x43d0: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_43d8:
	/* 0x43d8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_43df:
	/* 0x43df: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_43e4:
	/* 0x43e4: call   43e9 <kprobe_unwind_dotnet+0x43e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_43e9:
	/* 0x43e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_43ec:
	/* 0x43ec: je     43f3 <kprobe_unwind_dotnet+0x43f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43ec, 0x43f3, x86_l_43f3);
x86_l_43ee:
	/* 0x43ee: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_43f1:
	/* 0x43f1: jmp    4403 <kprobe_unwind_dotnet+0x4403> */
	X86_SIM_X86_JMP(0x43f1, 0x4403, x86_l_4403);
x86_l_43f3:
	/* 0x43f3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_43fa:
	/* 0x43fa: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43fd:
	/* 0x43fd: jne    49a5 <kprobe_unwind_dotnet+0x49a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43fd, 0x49a5, x86_l_49a5);
x86_l_4403:
	/* 0x4403: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_4408:
	/* 0x4408: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_440c:
	/* 0x440c: jne    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x440c, 0x85e7, x86_l_85e7);
x86_l_4412:
	/* 0x4412: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_4419:
	/* 0x4419: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_4420:
	/* 0x4420: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_4427:
	/* 0x4427: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_442f:
	/* 0x442f: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_4433:
	/* 0x4433: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_443a:
	/* 0x443a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_443d:
	/* 0x443d: jne    47d9 <kprobe_unwind_dotnet+0x47d9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x443d, 0x47d9, x86_l_47d9);
x86_l_4443:
	/* 0x4443: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4446:
	/* 0x4446: jb     70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4446, 0x70d1, x86_l_70d1);
x86_l_444c:
	/* 0x444c: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_4453:
	/* 0x4453: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4456:
	/* 0x4456: jae    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4456, 0x70d1, x86_l_70d1);
x86_l_445c:
	/* 0x445c: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4463:
	/* 0x4463: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_446a:
	/* 0x446a: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_446f:
	/* 0x446f: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_4477:
	/* 0x4477: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_447a:
	/* 0x447a: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_447e:
	/* 0x447e: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_4484:
	/* 0x4484: jne    44b8 <kprobe_unwind_dotnet+0x44b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4484, 0x44b8, x86_l_44b8);
x86_l_4486:
	/* 0x4486: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_448d:
	/* 0x448d: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4495:
	/* 0x4495: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_449a:
	/* 0x449a: call   449f <kprobe_unwind_dotnet+0x449f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_449f:
	/* 0x449f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44a2:
	/* 0x44a2: jne    180 <kprobe_unwind_dotnet+0x180> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44a2, 0x180, x86_l_180);
x86_l_44a8:
	/* 0x44a8: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_44b0:
	/* 0x44b0: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_44b3:
	/* 0x44b3: jmp    4a70 <kprobe_unwind_dotnet+0x4a70> */
	X86_SIM_X86_JMP(0x44b3, 0x4a70, x86_l_4a70);
x86_l_44b8:
	/* 0x44b8: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_44bd:
	/* 0x44bd: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_44c2:
	/* 0x44c2: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_44c5:
	/* 0x44c5: call   44ca <kprobe_unwind_dotnet+0x44ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_44ca:
	/* 0x44ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44cd:
	/* 0x44cd: jne    1c6 <kprobe_unwind_dotnet+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44cd, 0x1c6, x86_l_1c6);
x86_l_44d3:
	/* 0x44d3: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_44d7:
	/* 0x44d7: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_44de:
	/* 0x44de: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_44e3:
	/* 0x44e3: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_44ea:
	/* 0x44ea: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_44ef:
	/* 0x44ef: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_44f6:
	/* 0x44f6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_44fd:
	/* 0x44fd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4500:
	/* 0x4500: jne    48e9 <kprobe_unwind_dotnet+0x48e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4500, 0x48e9, x86_l_48e9);
x86_l_4506:
	/* 0x4506: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_450d:
	/* 0x450d: jb     4a70 <kprobe_unwind_dotnet+0x4a70> */
	X86_SIM_X86_JCC(X86_CC_B, 0x450d, 0x4a70, x86_l_4a70);
x86_l_4513:
	/* 0x4513: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_451a:
	/* 0x451a: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4521:
	/* 0x4521: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4524:
	/* 0x4524: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4527:
	/* 0x4527: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_452e:
	/* 0x452e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4531:
	/* 0x4531: jne    496c <kprobe_unwind_dotnet+0x496c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4531, 0x496c, x86_l_496c);
x86_l_4537:
	/* 0x4537: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_453a:
	/* 0x453a: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_453e:
	/* 0x453e: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_4543:
	/* 0x4543: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_4545:
	/* 0x4545: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_4548:
	/* 0x4548: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_454a:
	/* 0x454a: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_4551:
	/* 0x4551: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_4559:
	/* 0x4559: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_455d:
	/* 0x455d: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_4560:
	/* 0x4560: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4563:
	/* 0x4563: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_456b:
	/* 0x456b: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_456f:
	/* 0x456f: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_4574:
	/* 0x4574: call   4579 <kprobe_unwind_dotnet+0x4579> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4579:
	/* 0x4579: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_457c:
	/* 0x457c: je     45b1 <kprobe_unwind_dotnet+0x45b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x457c, 0x45b1, x86_l_45b1);
x86_l_457e:
	/* 0x457e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4585:
	/* 0x4585: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4588:
	/* 0x4588: jne    4770 <kprobe_unwind_dotnet+0x4770> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4588, 0x4770, x86_l_4770);
x86_l_458e:
	/* 0x458e: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_4596:
	/* 0x4596: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_459d:
	/* 0x459d: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_45a2:
	/* 0x45a2: call   45a7 <kprobe_unwind_dotnet+0x45a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_45a7:
	/* 0x45a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45aa:
	/* 0x45aa: je     4608 <kprobe_unwind_dotnet+0x4608> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45aa, 0x4608, x86_l_4608);
x86_l_45ac:
	/* 0x45ac: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_45af:
	/* 0x45af: jmp    4618 <kprobe_unwind_dotnet+0x4618> */
	X86_SIM_X86_JMP(0x45af, 0x4618, x86_l_4618);
x86_l_45b1:
	/* 0x45b1: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_45b8:
	/* 0x45b8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_45bf:
	/* 0x45bf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45c2:
	/* 0x45c2: jne    4e22 <kprobe_unwind_dotnet+0x4e22> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45c2, 0x4e22, x86_l_4e22);
x86_l_45c8:
	/* 0x45c8: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_45cb:
	/* 0x45cb: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_45cd:
	/* 0x45cd: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_45d0:
	/* 0x45d0: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_45d2:
	/* 0x45d2: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_45d7:
	/* 0x45d7: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_45da:
	/* 0x45da: je     46a5 <kprobe_unwind_dotnet+0x46a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45da, 0x46a5, x86_l_46a5);
x86_l_45e0:
	/* 0x45e0: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_45e4:
	/* 0x45e4: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_45e7:
	/* 0x45e7: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_45ea:
	/* 0x45ea: jne    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45ea, 0x4a2a, x86_l_4a2a);
x86_l_45f0:
	/* 0x45f0: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_45f3:
	/* 0x45f3: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_45f6:
	/* 0x45f6: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_45f9:
	/* 0x45f9: je     47b1 <kprobe_unwind_dotnet+0x47b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x45f9, 0x47b1, x86_l_47b1);
x86_l_45ff:
	/* 0x45ff: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_4603:
	/* 0x4603: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x4603, 0x4a2a, x86_l_4a2a);
x86_l_4608:
	/* 0x4608: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_460f:
	/* 0x460f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4612:
	/* 0x4612: jne    4f22 <kprobe_unwind_dotnet+0x4f22> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4612, 0x4f22, x86_l_4f22);
x86_l_4618:
	/* 0x4618: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_461d:
	/* 0x461d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_461f:
	/* 0x461f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4626:
	/* 0x4626: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4629:
	/* 0x4629: jne    52a0 <kprobe_unwind_dotnet+0x52a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4629, 0x52a0, x86_l_52a0);
x86_l_462f:
	/* 0x462f: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_4634:
	/* 0x4634: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_4636:
	/* 0x4636: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_463b:
	/* 0x463b: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4642:
	/* 0x4642: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4642, 0x7126, x86_l_7126);
x86_l_4648:
	/* 0x4648: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_464f:
	/* 0x464f: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_4653:
	/* 0x4653: ja     41a <kprobe_unwind_dotnet+0x41a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4653, 0x41a, x86_l_41a);
x86_l_4659:
	/* 0x4659: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_465c:
	/* 0x465c: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4663:
	/* 0x4663: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_4667:
	/* 0x4667: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_4673:
	/* 0x4673: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_467f:
	/* 0x467f: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_4688:
	/* 0x4688: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_4694:
	/* 0x4694: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_46a0:
	/* 0x46a0: jmp    4b1e <kprobe_unwind_dotnet+0x4b1e> */
	X86_SIM_X86_JMP(0x46a0, 0x4b1e, x86_l_4b1e);
x86_l_46a5:
	/* 0x46a5: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_46ac:
	/* 0x46ac: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_46b0:
	/* 0x46b0: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_46b7:
	/* 0x46b7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_46be:
	/* 0x46be: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_46c1:
	/* 0x46c1: jne    5094 <kprobe_unwind_dotnet+0x5094> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x46c1, 0x5094, x86_l_5094);
x86_l_46c7:
	/* 0x46c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46c9:
	/* 0x46c9: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_46cc:
	/* 0x46cc: je     5120 <kprobe_unwind_dotnet+0x5120> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46cc, 0x5120, x86_l_5120);
x86_l_46d2:
	/* 0x46d2: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_46d4:
	/* 0x46d4: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_46d7:
	/* 0x46d7: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_46da:
	/* 0x46da: jae    523d <kprobe_unwind_dotnet+0x523d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x46da, 0x523d, x86_l_523d);
x86_l_46e0:
	/* 0x46e0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_46e7:
	/* 0x46e7: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_46ea:
	/* 0x46ea: je     458e <kprobe_unwind_dotnet+0x458e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46ea, 0x458e, x86_l_458e);
x86_l_46f0:
	/* 0x46f0: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_46fa:
	/* 0x46fa: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_46ff:
	/* 0x46ff: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_4709:
	/* 0x4709: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_470e:
	/* 0x470e: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_4718:
	/* 0x4718: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_471d:
	/* 0x471d: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_4727:
	/* 0x4727: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_472c:
	/* 0x472c: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_4736:
	/* 0x4736: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_473b:
	/* 0x473b: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4745:
	/* 0x4745: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_474a:
	/* 0x474a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_474f:
	/* 0x474f: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4754:
	/* 0x4754: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4756:
	/* 0x4756: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4758:
	/* 0x4758: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_475b:
	/* 0x475b: call   4760 <kprobe_unwind_dotnet+0x4760> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4760:
	/* 0x4760: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4767:
	/* 0x4767: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_476a:
	/* 0x476a: je     458e <kprobe_unwind_dotnet+0x458e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x476a, 0x458e, x86_l_458e);
x86_l_4770:
	/* 0x4770: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_477a:
	/* 0x477a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_477f:
	/* 0x477f: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4789:
	/* 0x4789: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_478e:
	/* 0x478e: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_4796:
	/* 0x4796: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_479b:
	/* 0x479b: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_47a0:
	/* 0x47a0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_47a2:
	/* 0x47a2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_47a4:
	/* 0x47a4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_47a7:
	/* 0x47a7: call   47ac <kprobe_unwind_dotnet+0x47ac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_47ac:
	/* 0x47ac: jmp    458e <kprobe_unwind_dotnet+0x458e> */
	X86_SIM_X86_JMP(0x47ac, 0x458e, x86_l_458e);
x86_l_47b1:
	/* 0x47b1: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_47b4:
	/* 0x47b4: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_47b7:
	/* 0x47b7: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_47ba:
	/* 0x47ba: je     47c5 <kprobe_unwind_dotnet+0x47c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47ba, 0x47c5, x86_l_47c5);
x86_l_47bc:
	/* 0x47bc: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_47c0:
	/* 0x47c0: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x47c0, 0x4a2a, x86_l_4a2a);
x86_l_47c5:
	/* 0x47c5: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_47c8:
	/* 0x47c8: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_47cb:
	/* 0x47cb: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_47ce:
	/* 0x47ce: je     4843 <kprobe_unwind_dotnet+0x4843> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47ce, 0x4843, x86_l_4843);
x86_l_47d0:
	/* 0x47d0: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_47d4:
	/* 0x47d4: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x47d4, 0x4a2a, x86_l_4a2a);
x86_l_47d9:
	/* 0x47d9: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_47e3:
	/* 0x47e3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_47e8:
	/* 0x47e8: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_47f2:
	/* 0x47f2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_47f7:
	/* 0x47f7: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_4801:
	/* 0x4801: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4806:
	/* 0x4806: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4810:
	/* 0x4810: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4815:
	/* 0x4815: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_481d:
	/* 0x481d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4822:
	/* 0x4822: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_4827:
	/* 0x4827: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_482a:
	/* 0x482a: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_482d:
	/* 0x482d: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4830:
	/* 0x4830: call   4835 <kprobe_unwind_dotnet+0x4835> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4835:
	/* 0x4835: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4838:
	/* 0x4838: jae    444c <kprobe_unwind_dotnet+0x444c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4838, 0x444c, x86_l_444c);
x86_l_483e:
	/* 0x483e: jmp    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JMP(0x483e, 0x70d1, x86_l_70d1);
x86_l_4843:
	/* 0x4843: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4846:
	/* 0x4846: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_4849:
	/* 0x4849: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_484c:
	/* 0x484c: je     4857 <kprobe_unwind_dotnet+0x4857> */
	X86_SIM_X86_JCC(X86_CC_E, 0x484c, 0x4857, x86_l_4857);
x86_l_484e:
	/* 0x484e: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_4852:
	/* 0x4852: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x4852, 0x4a2a, x86_l_4a2a);
x86_l_4857:
	/* 0x4857: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_485a:
	/* 0x485a: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_485d:
	/* 0x485d: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4860:
	/* 0x4860: je     4951 <kprobe_unwind_dotnet+0x4951> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4860, 0x4951, x86_l_4951);
x86_l_4866:
	/* 0x4866: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_486d:
	/* 0x486d: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x486d, 0x4a2a, x86_l_4a2a);
x86_l_4872:
	/* 0x4872: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_487c:
	/* 0x487c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4881:
	/* 0x4881: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_488b:
	/* 0x488b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4890:
	/* 0x4890: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_489a:
	/* 0x489a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_489f:
	/* 0x489f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_48a9:
	/* 0x48a9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_48ae:
	/* 0x48ae: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_48b8:
	/* 0x48b8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_48bd:
	/* 0x48bd: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_48c7:
	/* 0x48c7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_48cc:
	/* 0x48cc: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_48d0:
	/* 0x48d0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_48d5:
	/* 0x48d5: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_48da:
	/* 0x48da: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_48dc:
	/* 0x48dc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_48df:
	/* 0x48df: call   48e4 <kprobe_unwind_dotnet+0x48e4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_48e4:
	/* 0x48e4: jmp    4256 <kprobe_unwind_dotnet+0x4256> */
	X86_SIM_X86_JMP(0x48e4, 0x4256, x86_l_4256);
x86_l_48e9:
	/* 0x48e9: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_48f3:
	/* 0x48f3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_48f8:
	/* 0x48f8: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_4902:
	/* 0x4902: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4907:
	/* 0x4907: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_4911:
	/* 0x4911: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4916:
	/* 0x4916: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4920:
	/* 0x4920: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4925:
	/* 0x4925: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_492d:
	/* 0x492d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4932:
	/* 0x4932: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_4937:
	/* 0x4937: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_493a:
	/* 0x493a: call   493f <kprobe_unwind_dotnet+0x493f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_493f:
	/* 0x493f: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_4946:
	/* 0x4946: jae    4513 <kprobe_unwind_dotnet+0x4513> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4946, 0x4513, x86_l_4513);
x86_l_494c:
	/* 0x494c: jmp    4a70 <kprobe_unwind_dotnet+0x4a70> */
	X86_SIM_X86_JMP(0x494c, 0x4a70, x86_l_4a70);
x86_l_4951:
	/* 0x4951: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4954:
	/* 0x4954: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_4957:
	/* 0x4957: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_495a:
	/* 0x495a: je     4a1c <kprobe_unwind_dotnet+0x4a1c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x495a, 0x4a1c, x86_l_4a1c);
x86_l_4960:
	/* 0x4960: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_4967:
	/* 0x4967: jmp    4a2a <kprobe_unwind_dotnet+0x4a2a> */
	X86_SIM_X86_JMP(0x4967, 0x4a2a, x86_l_4a2a);
x86_l_496c:
	/* 0x496c: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_4973:
	/* 0x4973: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4978:
	/* 0x4978: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_497d:
	/* 0x497d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4980:
	/* 0x4980: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_4983:
	/* 0x4983: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_498a:
	/* 0x498a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_498d:
	/* 0x498d: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_4992:
	/* 0x4992: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4995:
	/* 0x4995: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4998:
	/* 0x4998: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_499b:
	/* 0x499b: call   49a0 <kprobe_unwind_dotnet+0x49a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_49a0:
	/* 0x49a0: jmp    4537 <kprobe_unwind_dotnet+0x4537> */
	X86_SIM_X86_JMP(0x49a0, 0x4537, x86_l_4537);
x86_l_49a5:
	/* 0x49a5: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_49af:
	/* 0x49af: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_49b4:
	/* 0x49b4: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_49be:
	/* 0x49be: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_49c3:
	/* 0x49c3: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_49cd:
	/* 0x49cd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_49d2:
	/* 0x49d2: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_49dc:
	/* 0x49dc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_49e1:
	/* 0x49e1: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_49eb:
	/* 0x49eb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_49f0:
	/* 0x49f0: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_49fa:
	/* 0x49fa: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49ff:
	/* 0x49ff: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4a03:
	/* 0x4a03: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4a08:
	/* 0x4a08: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4a0d:
	/* 0x4a0d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a0f:
	/* 0x4a0f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a12:
	/* 0x4a12: call   4a17 <kprobe_unwind_dotnet+0x4a17> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4a17:
	/* 0x4a17: jmp    4403 <kprobe_unwind_dotnet+0x4403> */
	X86_SIM_X86_JMP(0x4a17, 0x4403, x86_l_4403);
x86_l_4a1c:
	/* 0x4a1c: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_4a20:
	/* 0x4a20: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_4a27:
	/* 0x4a27: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4a2a:
	/* 0x4a2a: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4a2d:
	/* 0x4a2d: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_4a35:
	/* 0x4a35: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4a38:
	/* 0x4a38: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4a3f:
	/* 0x4a3f: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a42:
	/* 0x4a42: jne    4eac <kprobe_unwind_dotnet+0x4eac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a42, 0x4eac, x86_l_4eac);
x86_l_4a48:
	/* 0x4a48: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_4a4c:
	/* 0x4a4c: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4a51:
	/* 0x4a51: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4a56:
	/* 0x4a56: call   4a5b <kprobe_unwind_dotnet+0x4a5b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4a5b:
	/* 0x4a5b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a5e:
	/* 0x4a5e: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4a65:
	/* 0x4a65: jne    9fa <kprobe_unwind_dotnet+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a65, 0x9fa, x86_l_9fa);
x86_l_4a6b:
	/* 0x4a6b: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_4a70:
	/* 0x4a70: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4a77:
	/* 0x4a77: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a7a:
	/* 0x4a7a: jne    4cbe <kprobe_unwind_dotnet+0x4cbe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a7a, 0x4cbe, x86_l_4cbe);
x86_l_4a80:
	/* 0x4a80: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4a87:
	/* 0x4a87: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_4a8b:
	/* 0x4a8b: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4a8b, 0xa4e, x86_l_a4e);
x86_l_4a91:
	/* 0x4a91: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4a96:
	/* 0x4a96: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4a99:
	/* 0x4a99: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_4a9d:
	/* 0x4a9d: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4aa0:
	/* 0x4aa0: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4aa3:
	/* 0x4aa3: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4aaa:
	/* 0x4aaa: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_4aae:
	/* 0x4aae: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_4ab6:
	/* 0x4ab6: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_4abe:
	/* 0x4abe: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_4ac7:
	/* 0x4ac7: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_4acc:
	/* 0x4acc: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_4ad4:
	/* 0x4ad4: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_4ae0:
	/* 0x4ae0: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_4aeb:
	/* 0x4aeb: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_4af3:
	/* 0x4af3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_4afa:
	/* 0x4afa: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4aff:
	/* 0x4aff: call   4b04 <kprobe_unwind_dotnet+0x4b04> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4b04:
	/* 0x4b04: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b07:
	/* 0x4b07: je     4b0e <kprobe_unwind_dotnet+0x4b0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b07, 0x4b0e, x86_l_4b0e);
x86_l_4b09:
	/* 0x4b09: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4b0c:
	/* 0x4b0c: jmp    4b1e <kprobe_unwind_dotnet+0x4b1e> */
	X86_SIM_X86_JMP(0x4b0c, 0x4b1e, x86_l_4b1e);
x86_l_4b0e:
	/* 0x4b0e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4b15:
	/* 0x4b15: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b18:
	/* 0x4b18: jne    4dab <kprobe_unwind_dotnet+0x4dab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4b18, 0x4dab, x86_l_4dab);
x86_l_4b1e:
	/* 0x4b1e: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4b26:
	/* 0x4b26: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b29:
	/* 0x4b29: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4b30:
	/* 0x4b30: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b32:
	/* 0x4b32: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4b35:
	/* 0x4b35: je     8172 <kprobe_unwind_dotnet+0x8172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b35, 0x8172, x86_l_8172);
x86_l_4b3b:
	/* 0x4b3b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4b3d:
	/* 0x4b3d: jne    4d12 <kprobe_unwind_dotnet+0x4d12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4b3d, 0x4d12, x86_l_4d12);
x86_l_4b43:
	/* 0x4b43: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4b4d:
	/* 0x4b4d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b50:
	/* 0x4b50: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4b50, 0x21d0, x86_l_21d0);
x86_l_4b56:
	/* 0x4b56: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_4b5d:
	/* 0x4b5d: jb     2358 <kprobe_unwind_dotnet+0x2358> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4b5d, 0x2358, x86_l_2358);
x86_l_4b63:
	/* 0x4b63: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b66:
	/* 0x4b66: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_4b6e:
	/* 0x4b6e: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_4b74:
	/* 0x4b74: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_4b7b:
	/* 0x4b7b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_4b82:
	/* 0x4b82: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4b87:
	/* 0x4b87: call   4b8c <kprobe_unwind_dotnet+0x4b8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4b8c:
	/* 0x4b8c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b8f:
	/* 0x4b8f: je     80c1 <kprobe_unwind_dotnet+0x80c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b8f, 0x80c1, x86_l_80c1);
x86_l_4b95:
	/* 0x4b95: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b99:
	/* 0x4b99: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4b9c:
	/* 0x4b9c: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4ba6:
	/* 0x4ba6: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4ba9:
	/* 0x4ba9: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4bb0:
	/* 0x4bb0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4bb3:
	/* 0x4bb3: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4bba:
	/* 0x4bba: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_4bbe:
	/* 0x4bbe: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4bc1:
	/* 0x4bc1: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4bc4:
	/* 0x4bc4: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4bcb:
	/* 0x4bcb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4bd2:
	/* 0x4bd2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4bd5:
	/* 0x4bd5: jne    4f99 <kprobe_unwind_dotnet+0x4f99> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4bd5, 0x4f99, x86_l_4f99);
x86_l_4bdb:
	/* 0x4bdb: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4bdf:
	/* 0x4bdf: jne    543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4bdf, 0x543b, x86_l_543b);
x86_l_4be5:
	/* 0x4be5: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4bec:
	/* 0x4bec: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4bf1:
	/* 0x4bf1: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4bf8:
	/* 0x4bf8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_4bff:
	/* 0x4bff: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4c04:
	/* 0x4c04: call   4c09 <kprobe_unwind_dotnet+0x4c09> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4c09:
	/* 0x4c09: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4c0f:
	/* 0x4c0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c12:
	/* 0x4c12: je     543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c12, 0x543b, x86_l_543b);
x86_l_4c18:
	/* 0x4c18: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c1b:
	/* 0x4c1b: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c1e:
	/* 0x4c1e: ja     4c26 <kprobe_unwind_dotnet+0x4c26> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4c1e, 0x4c26, x86_l_4c26);
x86_l_4c20:
	/* 0x4c20: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4c24:
	/* 0x4c24: jae    4c3a <kprobe_unwind_dotnet+0x4c3a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4c24, 0x4c3a, x86_l_4c3a);
x86_l_4c26:
	/* 0x4c26: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c2a:
	/* 0x4c2a: ja     543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4c2a, 0x543b, x86_l_543b);
x86_l_4c30:
	/* 0x4c30: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c34:
	/* 0x4c34: jb     543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4c34, 0x543b, x86_l_543b);
x86_l_4c3a:
	/* 0x4c3a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4c41:
	/* 0x4c41: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c44:
	/* 0x4c44: jne    539a <kprobe_unwind_dotnet+0x539a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4c44, 0x539a, x86_l_539a);
x86_l_4c4a:
	/* 0x4c4a: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_4c51:
	/* 0x4c51: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4c55:
	/* 0x4c55: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4c58:
	/* 0x4c58: jae    5403 <kprobe_unwind_dotnet+0x5403> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4c58, 0x5403, x86_l_5403);
x86_l_4c5e:
	/* 0x4c5e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4c65:
	/* 0x4c65: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c68:
	/* 0x4c68: je     543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c68, 0x543b, x86_l_543b);
x86_l_4c6e:
	/* 0x4c6e: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_4c78:
	/* 0x4c78: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4c7d:
	/* 0x4c7d: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_4c87:
	/* 0x4c87: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c8c:
	/* 0x4c8c: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_4c96:
	/* 0x4c96: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c9b:
	/* 0x4c9b: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_4ca3:
	/* 0x4ca3: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ca8:
	/* 0x4ca8: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_4cad:
	/* 0x4cad: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4caf:
	/* 0x4caf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4cb1:
	/* 0x4cb1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4cb4:
	/* 0x4cb4: call   4cb9 <kprobe_unwind_dotnet+0x4cb9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4cb9:
	/* 0x4cb9: jmp    543b <kprobe_unwind_dotnet+0x543b> */
	X86_SIM_X86_JMP(0x4cb9, 0x543b, x86_l_543b);
x86_l_4cbe:
	/* 0x4cbe: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_4cc5:
	/* 0x4cc5: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4cca:
	/* 0x4cca: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4ccf:
	/* 0x4ccf: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cd2:
	/* 0x4cd2: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_4cd5:
	/* 0x4cd5: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_4cda:
	/* 0x4cda: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_4ce1:
	/* 0x4ce1: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4ce6:
	/* 0x4ce6: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4ce9:
	/* 0x4ce9: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4cec:
	/* 0x4cec: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cef:
	/* 0x4cef: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_4cf4:
	/* 0x4cf4: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4cf7:
	/* 0x4cf7: call   4cfc <kprobe_unwind_dotnet+0x4cfc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4cfc:
	/* 0x4cfc: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4d03:
	/* 0x4d03: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_4d07:
	/* 0x4d07: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4d07, 0xa4e, x86_l_a4e);
x86_l_4d0d:
	/* 0x4d0d: jmp    4a91 <kprobe_unwind_dotnet+0x4a91> */
	X86_SIM_X86_JMP(0x4d0d, 0x4a91, x86_l_4a91);
x86_l_4d12:
	/* 0x4d12: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_4d1c:
	/* 0x4d1c: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4d21:
	/* 0x4d21: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_4d2b:
	/* 0x4d2b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d30:
	/* 0x4d30: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_4d3a:
	/* 0x4d3a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d3f:
	/* 0x4d3f: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_4d49:
	/* 0x4d49: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4d4e:
	/* 0x4d4e: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_4d58:
	/* 0x4d58: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d5d:
	/* 0x4d5d: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_4d67:
	/* 0x4d67: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d6c:
	/* 0x4d6c: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_4d71:
	/* 0x4d71: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4d78:
	/* 0x4d78: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d7d:
	/* 0x4d7d: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_4d82:
	/* 0x4d82: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d84:
	/* 0x4d84: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d87:
	/* 0x4d87: call   4d8c <kprobe_unwind_dotnet+0x4d8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4d8c:
	/* 0x4d8c: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_4d93:
	/* 0x4d93: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4d9d:
	/* 0x4d9d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4da0:
	/* 0x4da0: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4da0, 0x21d0, x86_l_21d0);
x86_l_4da6:
	/* 0x4da6: jmp    4b56 <kprobe_unwind_dotnet+0x4b56> */
	X86_SIM_X86_JMP(0x4da6, 0x4b56, x86_l_4b56);
x86_l_4dab:
	/* 0x4dab: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_4db5:
	/* 0x4db5: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4dba:
	/* 0x4dba: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_4dc4:
	/* 0x4dc4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4dc9:
	/* 0x4dc9: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_4dd3:
	/* 0x4dd3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4dd8:
	/* 0x4dd8: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_4de2:
	/* 0x4de2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4de7:
	/* 0x4de7: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_4df1:
	/* 0x4df1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4df6:
	/* 0x4df6: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_4e00:
	/* 0x4e00: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e05:
	/* 0x4e05: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4e09:
	/* 0x4e09: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e0e:
	/* 0x4e0e: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4e13:
	/* 0x4e13: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e15:
	/* 0x4e15: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e18:
	/* 0x4e18: call   4e1d <kprobe_unwind_dotnet+0x4e1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4e1d:
	/* 0x4e1d: jmp    4b1e <kprobe_unwind_dotnet+0x4b1e> */
	X86_SIM_X86_JMP(0x4e1d, 0x4b1e, x86_l_4b1e);
x86_l_4e22:
	/* 0x4e22: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4e25:
	/* 0x4e25: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_4e29:
	/* 0x4e29: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_4e33:
	/* 0x4e33: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_4e38:
	/* 0x4e38: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_4e42:
	/* 0x4e42: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4e47:
	/* 0x4e47: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_4e51:
	/* 0x4e51: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4e56:
	/* 0x4e56: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_4e60:
	/* 0x4e60: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4e65:
	/* 0x4e65: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_4e6f:
	/* 0x4e6f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4e74:
	/* 0x4e74: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_4e7e:
	/* 0x4e7e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4e83:
	/* 0x4e83: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4e8d:
	/* 0x4e8d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e92:
	/* 0x4e92: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e97:
	/* 0x4e97: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_4e9c:
	/* 0x4e9c: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4e9f:
	/* 0x4e9f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ea2:
	/* 0x4ea2: call   4ea7 <kprobe_unwind_dotnet+0x4ea7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4ea7:
	/* 0x4ea7: jmp    45c8 <kprobe_unwind_dotnet+0x45c8> */
	X86_SIM_X86_JMP(0x4ea7, 0x45c8, x86_l_45c8);
x86_l_4eac:
	/* 0x4eac: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4eae:
	/* 0x4eae: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_4eb8:
	/* 0x4eb8: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4ebd:
	/* 0x4ebd: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_4ec7:
	/* 0x4ec7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4ecc:
	/* 0x4ecc: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_4ed6:
	/* 0x4ed6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4edb:
	/* 0x4edb: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_4ee5:
	/* 0x4ee5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4eea:
	/* 0x4eea: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_4ef4:
	/* 0x4ef4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4ef9:
	/* 0x4ef9: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_4f03:
	/* 0x4f03: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f08:
	/* 0x4f08: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f0d:
	/* 0x4f0d: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4f12:
	/* 0x4f12: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4f15:
	/* 0x4f15: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4f18:
	/* 0x4f18: call   4f1d <kprobe_unwind_dotnet+0x4f1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4f1d:
	/* 0x4f1d: jmp    4a48 <kprobe_unwind_dotnet+0x4a48> */
	X86_SIM_X86_JMP(0x4f1d, 0x4a48, x86_l_4a48);
x86_l_4f22:
	/* 0x4f22: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_4f2c:
	/* 0x4f2c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4f31:
	/* 0x4f31: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_4f3b:
	/* 0x4f3b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4f40:
	/* 0x4f40: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_4f4a:
	/* 0x4f4a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4f4f:
	/* 0x4f4f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_4f59:
	/* 0x4f59: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4f5e:
	/* 0x4f5e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_4f68:
	/* 0x4f68: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4f6d:
	/* 0x4f6d: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_4f77:
	/* 0x4f77: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f7c:
	/* 0x4f7c: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4f80:
	/* 0x4f80: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f85:
	/* 0x4f85: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4f8a:
	/* 0x4f8a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4f8c:
	/* 0x4f8c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4f8f:
	/* 0x4f8f: call   4f94 <kprobe_unwind_dotnet+0x4f94> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4f94:
	/* 0x4f94: jmp    4618 <kprobe_unwind_dotnet+0x4618> */
	X86_SIM_X86_JMP(0x4f94, 0x4618, x86_l_4618);
x86_l_4f99:
	/* 0x4f99: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_4fa3:
	/* 0x4fa3: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4fa8:
	/* 0x4fa8: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_4fb2:
	/* 0x4fb2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4fb7:
	/* 0x4fb7: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_4fc1:
	/* 0x4fc1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4fc6:
	/* 0x4fc6: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_4fd0:
	/* 0x4fd0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4fd5:
	/* 0x4fd5: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_4fdf:
	/* 0x4fdf: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4fe4:
	/* 0x4fe4: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_4fee:
	/* 0x4fee: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ff3:
	/* 0x4ff3: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_4ffa:
	/* 0x4ffa: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4fff:
	/* 0x4fff: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_5004:
	/* 0x5004: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5007:
	/* 0x5007: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_500a:
	/* 0x500a: call   500f <kprobe_unwind_dotnet+0x500f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_500f:
	/* 0x500f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5016:
	/* 0x5016: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5019:
	/* 0x5019: je     4bdb <kprobe_unwind_dotnet+0x4bdb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5019, 0x4bdb, x86_l_4bdb);
x86_l_501f:
	/* 0x501f: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_5029:
	/* 0x5029: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_502e:
	/* 0x502e: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_5038:
	/* 0x5038: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_503d:
	/* 0x503d: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_5047:
	/* 0x5047: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_504c:
	/* 0x504c: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_5056:
	/* 0x5056: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_505b:
	/* 0x505b: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_5065:
	/* 0x5065: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_506a:
	/* 0x506a: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_506f:
	/* 0x506f: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_5076:
	/* 0x5076: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_507d:
	/* 0x507d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5082:
	/* 0x5082: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_5087:
	/* 0x5087: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_508a:
	/* 0x508a: call   508f <kprobe_unwind_dotnet+0x508f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_508f:
	/* 0x508f: jmp    4bdb <kprobe_unwind_dotnet+0x4bdb> */
	X86_SIM_X86_JMP(0x508f, 0x4bdb, x86_l_4bdb);
x86_l_5094:
	/* 0x5094: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_509e:
	/* 0x509e: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_50a3:
	/* 0x50a3: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_50ad:
	/* 0x50ad: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_50b2:
	/* 0x50b2: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_50bc:
	/* 0x50bc: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_50c1:
	/* 0x50c1: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_50cb:
	/* 0x50cb: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_50d0:
	/* 0x50d0: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_50da:
	/* 0x50da: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_50df:
	/* 0x50df: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_50e9:
	/* 0x50e9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_50ee:
	/* 0x50ee: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_50f8:
	/* 0x50f8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_50fd:
	/* 0x50fd: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5102:
	/* 0x5102: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_5107:
	/* 0x5107: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_510a:
	/* 0x510a: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_510d:
	/* 0x510d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5110:
	/* 0x5110: call   5115 <kprobe_unwind_dotnet+0x5115> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5115:
	/* 0x5115: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5117:
	/* 0x5117: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_511a:
	/* 0x511a: jne    46d2 <kprobe_unwind_dotnet+0x46d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x511a, 0x46d2, x86_l_46d2);
x86_l_5120:
	/* 0x5120: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_5127:
	/* 0x5127: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_512c:
	/* 0x512c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_512f:
	/* 0x512f: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x512f, 0x5215, x86_l_5215);
x86_l_5135:
	/* 0x5135: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_513c:
	/* 0x513c: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_5141:
	/* 0x5141: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5144:
	/* 0x5144: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5144, 0x5215, x86_l_5215);
x86_l_514a:
	/* 0x514a: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_5151:
	/* 0x5151: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_5156:
	/* 0x5156: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5159:
	/* 0x5159: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5159, 0x5215, x86_l_5215);
x86_l_515f:
	/* 0x515f: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_5166:
	/* 0x5166: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_516b:
	/* 0x516b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_516e:
	/* 0x516e: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x516e, 0x5215, x86_l_5215);
x86_l_5174:
	/* 0x5174: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_517b:
	/* 0x517b: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_5180:
	/* 0x5180: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5183:
	/* 0x5183: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5183, 0x5215, x86_l_5215);
x86_l_5189:
	/* 0x5189: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_5190:
	/* 0x5190: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_5195:
	/* 0x5195: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5198:
	/* 0x5198: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5198, 0x5215, x86_l_5215);
x86_l_519a:
	/* 0x519a: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_51a1:
	/* 0x51a1: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_51a6:
	/* 0x51a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51a9:
	/* 0x51a9: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51a9, 0x5215, x86_l_5215);
x86_l_51ab:
	/* 0x51ab: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_51b2:
	/* 0x51b2: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_51b7:
	/* 0x51b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51ba:
	/* 0x51ba: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51ba, 0x5215, x86_l_5215);
x86_l_51bc:
	/* 0x51bc: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_51c3:
	/* 0x51c3: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_51c8:
	/* 0x51c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51cb:
	/* 0x51cb: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51cb, 0x5215, x86_l_5215);
x86_l_51cd:
	/* 0x51cd: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_51d4:
	/* 0x51d4: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_51d9:
	/* 0x51d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51dc:
	/* 0x51dc: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51dc, 0x5215, x86_l_5215);
x86_l_51de:
	/* 0x51de: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_51e5:
	/* 0x51e5: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_51ea:
	/* 0x51ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51ed:
	/* 0x51ed: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51ed, 0x5215, x86_l_5215);
x86_l_51ef:
	/* 0x51ef: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_51f6:
	/* 0x51f6: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_51fb:
	/* 0x51fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51fe:
	/* 0x51fe: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51fe, 0x5215, x86_l_5215);
x86_l_5200:
	/* 0x5200: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_5207:
	/* 0x5207: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_520c:
	/* 0x520c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_520f:
	/* 0x520f: je     6749 <kprobe_unwind_dotnet+0x6749> */
	X86_SIM_X86_JCC(X86_CC_E, 0x520f, 0x6749, x86_l_6749);
x86_l_5215:
	/* 0x5215: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5217:
	/* 0x5217: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_521a:
	/* 0x521a: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_521e:
	/* 0x521e: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_5222:
	/* 0x5222: jne    5227 <kprobe_unwind_dotnet+0x5227> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5222, 0x5227, x86_l_5227);
x86_l_5224:
	/* 0x5224: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5227:
	/* 0x5227: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_522a:
	/* 0x522a: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_522c:
	/* 0x522c: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_522f:
	/* 0x522f: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5231:
	/* 0x5231: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_5234:
	/* 0x5234: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_5237:
	/* 0x5237: jb     46e0 <kprobe_unwind_dotnet+0x46e0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5237, 0x46e0, x86_l_46e0);
x86_l_523d:
	/* 0x523d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5244:
	/* 0x5244: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5247:
	/* 0x5247: jne    5304 <kprobe_unwind_dotnet+0x5304> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5247, 0x5304, x86_l_5304);
x86_l_524d:
	/* 0x524d: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5250:
	/* 0x5250: jne    45e4 <kprobe_unwind_dotnet+0x45e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5250, 0x45e4, x86_l_45e4);
x86_l_5256:
	/* 0x5256: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_525e:
	/* 0x525e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5265:
	/* 0x5265: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_526a:
	/* 0x526a: call   526f <kprobe_unwind_dotnet+0x526f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_526f:
	/* 0x526f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5272:
	/* 0x5272: je     5279 <kprobe_unwind_dotnet+0x5279> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5272, 0x5279, x86_l_5279);
x86_l_5274:
	/* 0x5274: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5277:
	/* 0x5277: jmp    5289 <kprobe_unwind_dotnet+0x5289> */
	X86_SIM_X86_JMP(0x5277, 0x5289, x86_l_5289);
x86_l_5279:
	/* 0x5279: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5280:
	/* 0x5280: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5283:
	/* 0x5283: jne    58a5 <kprobe_unwind_dotnet+0x58a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5283, 0x58a5, x86_l_58a5);
x86_l_5289:
	/* 0x5289: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_528e:
	/* 0x528e: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_5290:
	/* 0x5290: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5297:
	/* 0x5297: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_529a:
	/* 0x529a: je     462f <kprobe_unwind_dotnet+0x462f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x529a, 0x462f, x86_l_462f);
x86_l_52a0:
	/* 0x52a0: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_52aa:
	/* 0x52aa: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_52af:
	/* 0x52af: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_52b9:
	/* 0x52b9: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_52be:
	/* 0x52be: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_52c8:
	/* 0x52c8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_52cd:
	/* 0x52cd: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_52d7:
	/* 0x52d7: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_52dc:
	/* 0x52dc: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_52e6:
	/* 0x52e6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_52eb:
	/* 0x52eb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_52f0:
	/* 0x52f0: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_52f5:
	/* 0x52f5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_52f7:
	/* 0x52f7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_52fa:
	/* 0x52fa: call   52ff <kprobe_unwind_dotnet+0x52ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_52ff:
	/* 0x52ff: jmp    462f <kprobe_unwind_dotnet+0x462f> */
	X86_SIM_X86_JMP(0x52ff, 0x462f, x86_l_462f);
x86_l_5304:
	/* 0x5304: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_530e:
	/* 0x530e: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5313:
	/* 0x5313: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_531d:
	/* 0x531d: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5322:
	/* 0x5322: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_532c:
	/* 0x532c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5331:
	/* 0x5331: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_533b:
	/* 0x533b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5340:
	/* 0x5340: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_534a:
	/* 0x534a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_534f:
	/* 0x534f: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_5359:
	/* 0x5359: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_535e:
	/* 0x535e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5368:
	/* 0x5368: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_536d:
	/* 0x536d: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_5375:
	/* 0x5375: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5377:
	/* 0x5377: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_537a:
	/* 0x537a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_537f:
	/* 0x537f: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_5384:
	/* 0x5384: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5387:
	/* 0x5387: call   538c <kprobe_unwind_dotnet+0x538c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_538c:
	/* 0x538c: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_538f:
	/* 0x538f: jne    45e4 <kprobe_unwind_dotnet+0x45e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x538f, 0x45e4, x86_l_45e4);
x86_l_5395:
	/* 0x5395: jmp    5256 <kprobe_unwind_dotnet+0x5256> */
	X86_SIM_X86_JMP(0x5395, 0x5256, x86_l_5256);
x86_l_539a:
	/* 0x539a: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_53a4:
	/* 0x53a4: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_53a9:
	/* 0x53a9: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_53b3:
	/* 0x53b3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_53b8:
	/* 0x53b8: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_53c2:
	/* 0x53c2: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_53c7:
	/* 0x53c7: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_53d1:
	/* 0x53d1: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53d6:
	/* 0x53d6: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_53db:
	/* 0x53db: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53e0:
	/* 0x53e0: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_53e5:
	/* 0x53e5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53e7:
	/* 0x53e7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53ea:
	/* 0x53ea: call   53ef <kprobe_unwind_dotnet+0x53ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_53ef:
	/* 0x53ef: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_53f6:
	/* 0x53f6: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_53fa:
	/* 0x53fa: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_53fd:
	/* 0x53fd: jb     4c5e <kprobe_unwind_dotnet+0x4c5e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x53fd, 0x4c5e, x86_l_4c5e);
x86_l_5403:
	/* 0x5403: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_540b:
	/* 0x540b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5412:
	/* 0x5412: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5417:
	/* 0x5417: call   541c <kprobe_unwind_dotnet+0x541c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_541c:
	/* 0x541c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_541f:
	/* 0x541f: je     5426 <kprobe_unwind_dotnet+0x5426> */
	X86_SIM_X86_JCC(X86_CC_E, 0x541f, 0x5426, x86_l_5426);
x86_l_5421:
	/* 0x5421: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5424:
	/* 0x5424: jmp    5436 <kprobe_unwind_dotnet+0x5436> */
	X86_SIM_X86_JMP(0x5424, 0x5436, x86_l_5436);
x86_l_5426:
	/* 0x5426: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_542d:
	/* 0x542d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5430:
	/* 0x5430: jne    59d8 <kprobe_unwind_dotnet+0x59d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5430, 0x59d8, x86_l_59d8);
x86_l_5436:
	/* 0x5436: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_543b:
	/* 0x543b: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_543f:
	/* 0x543f: jne    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x543f, 0x85e7, x86_l_85e7);
x86_l_5445:
	/* 0x5445: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_544c:
	/* 0x544c: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_5453:
	/* 0x5453: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_545a:
	/* 0x545a: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_5462:
	/* 0x5462: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_5466:
	/* 0x5466: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_546d:
	/* 0x546d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5470:
	/* 0x5470: jne    580c <kprobe_unwind_dotnet+0x580c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5470, 0x580c, x86_l_580c);
x86_l_5476:
	/* 0x5476: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5479:
	/* 0x5479: jb     70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5479, 0x70d1, x86_l_70d1);
x86_l_547f:
	/* 0x547f: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_5486:
	/* 0x5486: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5489:
	/* 0x5489: jae    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5489, 0x70d1, x86_l_70d1);
x86_l_548f:
	/* 0x548f: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5496:
	/* 0x5496: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_549d:
	/* 0x549d: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_54a2:
	/* 0x54a2: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_54aa:
	/* 0x54aa: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_54ad:
	/* 0x54ad: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_54b1:
	/* 0x54b1: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_54b7:
	/* 0x54b7: jne    54eb <kprobe_unwind_dotnet+0x54eb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x54b7, 0x54eb, x86_l_54eb);
x86_l_54b9:
	/* 0x54b9: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_54c0:
	/* 0x54c0: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_54c8:
	/* 0x54c8: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_54cd:
	/* 0x54cd: call   54d2 <kprobe_unwind_dotnet+0x54d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_54d2:
	/* 0x54d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54d5:
	/* 0x54d5: jne    180 <kprobe_unwind_dotnet+0x180> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x54d5, 0x180, x86_l_180);
x86_l_54db:
	/* 0x54db: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_54e3:
	/* 0x54e3: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_54e6:
	/* 0x54e6: jmp    5aa3 <kprobe_unwind_dotnet+0x5aa3> */
	X86_SIM_X86_JMP(0x54e6, 0x5aa3, x86_l_5aa3);
x86_l_54eb:
	/* 0x54eb: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_54f0:
	/* 0x54f0: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_54f5:
	/* 0x54f5: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_54f8:
	/* 0x54f8: call   54fd <kprobe_unwind_dotnet+0x54fd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_54fd:
	/* 0x54fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5500:
	/* 0x5500: jne    1c6 <kprobe_unwind_dotnet+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5500, 0x1c6, x86_l_1c6);
x86_l_5506:
	/* 0x5506: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_550a:
	/* 0x550a: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_5511:
	/* 0x5511: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5516:
	/* 0x5516: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_551d:
	/* 0x551d: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_5522:
	/* 0x5522: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5529:
	/* 0x5529: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5530:
	/* 0x5530: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5533:
	/* 0x5533: jne    591c <kprobe_unwind_dotnet+0x591c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5533, 0x591c, x86_l_591c);
x86_l_5539:
	/* 0x5539: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_5540:
	/* 0x5540: jb     5aa3 <kprobe_unwind_dotnet+0x5aa3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5540, 0x5aa3, x86_l_5aa3);
x86_l_5546:
	/* 0x5546: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_554d:
	/* 0x554d: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_5554:
	/* 0x5554: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5557:
	/* 0x5557: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_555a:
	/* 0x555a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5561:
	/* 0x5561: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5564:
	/* 0x5564: jne    599f <kprobe_unwind_dotnet+0x599f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5564, 0x599f, x86_l_599f);
x86_l_556a:
	/* 0x556a: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_556d:
	/* 0x556d: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_5571:
	/* 0x5571: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_5576:
	/* 0x5576: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_5578:
	/* 0x5578: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_557b:
	/* 0x557b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_557d:
	/* 0x557d: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_5584:
	/* 0x5584: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_558c:
	/* 0x558c: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_5590:
	/* 0x5590: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_5593:
	/* 0x5593: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5596:
	/* 0x5596: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_559e:
	/* 0x559e: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_55a2:
	/* 0x55a2: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_55a7:
	/* 0x55a7: call   55ac <kprobe_unwind_dotnet+0x55ac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_55ac:
	/* 0x55ac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_55af:
	/* 0x55af: je     55e4 <kprobe_unwind_dotnet+0x55e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55af, 0x55e4, x86_l_55e4);
x86_l_55b1:
	/* 0x55b1: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_55b8:
	/* 0x55b8: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55bb:
	/* 0x55bb: jne    57a3 <kprobe_unwind_dotnet+0x57a3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x55bb, 0x57a3, x86_l_57a3);
x86_l_55c1:
	/* 0x55c1: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_55c9:
	/* 0x55c9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_55d0:
	/* 0x55d0: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_55d5:
	/* 0x55d5: call   55da <kprobe_unwind_dotnet+0x55da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_55da:
	/* 0x55da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_55dd:
	/* 0x55dd: je     563b <kprobe_unwind_dotnet+0x563b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55dd, 0x563b, x86_l_563b);
x86_l_55df:
	/* 0x55df: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_55e2:
	/* 0x55e2: jmp    564b <kprobe_unwind_dotnet+0x564b> */
	X86_SIM_X86_JMP(0x55e2, 0x564b, x86_l_564b);
x86_l_55e4:
	/* 0x55e4: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_55eb:
	/* 0x55eb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_55f2:
	/* 0x55f2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55f5:
	/* 0x55f5: jne    5e55 <kprobe_unwind_dotnet+0x5e55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x55f5, 0x5e55, x86_l_5e55);
x86_l_55fb:
	/* 0x55fb: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_55fe:
	/* 0x55fe: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_5600:
	/* 0x5600: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_5603:
	/* 0x5603: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_5605:
	/* 0x5605: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_560a:
	/* 0x560a: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_560d:
	/* 0x560d: je     56d8 <kprobe_unwind_dotnet+0x56d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x560d, 0x56d8, x86_l_56d8);
x86_l_5613:
	/* 0x5613: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_5617:
	/* 0x5617: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_561a:
	/* 0x561a: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_561d:
	/* 0x561d: jne    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x561d, 0x5a5d, x86_l_5a5d);
x86_l_5623:
	/* 0x5623: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5626:
	/* 0x5626: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_5629:
	/* 0x5629: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_562c:
	/* 0x562c: je     57e4 <kprobe_unwind_dotnet+0x57e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x562c, 0x57e4, x86_l_57e4);
x86_l_5632:
	/* 0x5632: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_5636:
	/* 0x5636: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x5636, 0x5a5d, x86_l_5a5d);
x86_l_563b:
	/* 0x563b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5642:
	/* 0x5642: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5645:
	/* 0x5645: jne    5f55 <kprobe_unwind_dotnet+0x5f55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5645, 0x5f55, x86_l_5f55);
x86_l_564b:
	/* 0x564b: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_5650:
	/* 0x5650: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5652:
	/* 0x5652: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5659:
	/* 0x5659: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_565c:
	/* 0x565c: jne    66e5 <kprobe_unwind_dotnet+0x66e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x565c, 0x66e5, x86_l_66e5);
x86_l_5662:
	/* 0x5662: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_5667:
	/* 0x5667: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_5669:
	/* 0x5669: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_566e:
	/* 0x566e: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5675:
	/* 0x5675: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5675, 0x7126, x86_l_7126);
x86_l_567b:
	/* 0x567b: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5682:
	/* 0x5682: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_5686:
	/* 0x5686: ja     41a <kprobe_unwind_dotnet+0x41a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5686, 0x41a, x86_l_41a);
x86_l_568c:
	/* 0x568c: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_568f:
	/* 0x568f: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5696:
	/* 0x5696: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_569a:
	/* 0x569a: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_56a6:
	/* 0x56a6: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_56b2:
	/* 0x56b2: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_56bb:
	/* 0x56bb: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_56c7:
	/* 0x56c7: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_56d3:
	/* 0x56d3: jmp    5b51 <kprobe_unwind_dotnet+0x5b51> */
	X86_SIM_X86_JMP(0x56d3, 0x5b51, x86_l_5b51);
x86_l_56d8:
	/* 0x56d8: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_56df:
	/* 0x56df: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_56e3:
	/* 0x56e3: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_56ea:
	/* 0x56ea: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_56f1:
	/* 0x56f1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56f4:
	/* 0x56f4: jne    60c7 <kprobe_unwind_dotnet+0x60c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56f4, 0x60c7, x86_l_60c7);
x86_l_56fa:
	/* 0x56fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_56fc:
	/* 0x56fc: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_56ff:
	/* 0x56ff: je     6153 <kprobe_unwind_dotnet+0x6153> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56ff, 0x6153, x86_l_6153);
x86_l_5705:
	/* 0x5705: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5707:
	/* 0x5707: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_570a:
	/* 0x570a: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_570d:
	/* 0x570d: jae    6682 <kprobe_unwind_dotnet+0x6682> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x570d, 0x6682, x86_l_6682);
x86_l_5713:
	/* 0x5713: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_571a:
	/* 0x571a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_571d:
	/* 0x571d: je     55c1 <kprobe_unwind_dotnet+0x55c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x571d, 0x55c1, x86_l_55c1);
x86_l_5723:
	/* 0x5723: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_572d:
	/* 0x572d: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5732:
	/* 0x5732: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_573c:
	/* 0x573c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5741:
	/* 0x5741: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_574b:
	/* 0x574b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5750:
	/* 0x5750: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_575a:
	/* 0x575a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_575f:
	/* 0x575f: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_5769:
	/* 0x5769: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_576e:
	/* 0x576e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5778:
	/* 0x5778: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_577d:
	/* 0x577d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5782:
	/* 0x5782: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5787:
	/* 0x5787: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5789:
	/* 0x5789: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_578b:
	/* 0x578b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_578e:
	/* 0x578e: call   5793 <kprobe_unwind_dotnet+0x5793> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5793:
	/* 0x5793: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_579a:
	/* 0x579a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_579d:
	/* 0x579d: je     55c1 <kprobe_unwind_dotnet+0x55c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x579d, 0x55c1, x86_l_55c1);
x86_l_57a3:
	/* 0x57a3: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_57ad:
	/* 0x57ad: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_57b2:
	/* 0x57b2: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_57bc:
	/* 0x57bc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57c1:
	/* 0x57c1: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_57c9:
	/* 0x57c9: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57ce:
	/* 0x57ce: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_57d3:
	/* 0x57d3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57d5:
	/* 0x57d5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57d7:
	/* 0x57d7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57da:
	/* 0x57da: call   57df <kprobe_unwind_dotnet+0x57df> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_57df:
	/* 0x57df: jmp    55c1 <kprobe_unwind_dotnet+0x55c1> */
	X86_SIM_X86_JMP(0x57df, 0x55c1, x86_l_55c1);
x86_l_57e4:
	/* 0x57e4: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_57e7:
	/* 0x57e7: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_57ea:
	/* 0x57ea: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_57ed:
	/* 0x57ed: je     57f8 <kprobe_unwind_dotnet+0x57f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57ed, 0x57f8, x86_l_57f8);
x86_l_57ef:
	/* 0x57ef: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_57f3:
	/* 0x57f3: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x57f3, 0x5a5d, x86_l_5a5d);
x86_l_57f8:
	/* 0x57f8: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_57fb:
	/* 0x57fb: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_57fe:
	/* 0x57fe: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5801:
	/* 0x5801: je     5876 <kprobe_unwind_dotnet+0x5876> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5801, 0x5876, x86_l_5876);
x86_l_5803:
	/* 0x5803: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_5807:
	/* 0x5807: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x5807, 0x5a5d, x86_l_5a5d);
x86_l_580c:
	/* 0x580c: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_5816:
	/* 0x5816: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_581b:
	/* 0x581b: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_5825:
	/* 0x5825: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_582a:
	/* 0x582a: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_5834:
	/* 0x5834: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5839:
	/* 0x5839: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5843:
	/* 0x5843: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5848:
	/* 0x5848: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_5850:
	/* 0x5850: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5855:
	/* 0x5855: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_585a:
	/* 0x585a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_585d:
	/* 0x585d: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5860:
	/* 0x5860: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5863:
	/* 0x5863: call   5868 <kprobe_unwind_dotnet+0x5868> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5868:
	/* 0x5868: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_586b:
	/* 0x586b: jae    547f <kprobe_unwind_dotnet+0x547f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x586b, 0x547f, x86_l_547f);
x86_l_5871:
	/* 0x5871: jmp    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JMP(0x5871, 0x70d1, x86_l_70d1);
x86_l_5876:
	/* 0x5876: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5879:
	/* 0x5879: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_587c:
	/* 0x587c: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_587f:
	/* 0x587f: je     588a <kprobe_unwind_dotnet+0x588a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x587f, 0x588a, x86_l_588a);
x86_l_5881:
	/* 0x5881: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_5885:
	/* 0x5885: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x5885, 0x5a5d, x86_l_5a5d);
x86_l_588a:
	/* 0x588a: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_588d:
	/* 0x588d: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_5890:
	/* 0x5890: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5893:
	/* 0x5893: je     5984 <kprobe_unwind_dotnet+0x5984> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5893, 0x5984, x86_l_5984);
x86_l_5899:
	/* 0x5899: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_58a0:
	/* 0x58a0: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x58a0, 0x5a5d, x86_l_5a5d);
x86_l_58a5:
	/* 0x58a5: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_58af:
	/* 0x58af: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_58b4:
	/* 0x58b4: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_58be:
	/* 0x58be: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_58c3:
	/* 0x58c3: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_58cd:
	/* 0x58cd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_58d2:
	/* 0x58d2: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_58dc:
	/* 0x58dc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_58e1:
	/* 0x58e1: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_58eb:
	/* 0x58eb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_58f0:
	/* 0x58f0: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_58fa:
	/* 0x58fa: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58ff:
	/* 0x58ff: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5903:
	/* 0x5903: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5908:
	/* 0x5908: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_590d:
	/* 0x590d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_590f:
	/* 0x590f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5912:
	/* 0x5912: call   5917 <kprobe_unwind_dotnet+0x5917> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5917:
	/* 0x5917: jmp    5289 <kprobe_unwind_dotnet+0x5289> */
	X86_SIM_X86_JMP(0x5917, 0x5289, x86_l_5289);
x86_l_591c:
	/* 0x591c: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_5926:
	/* 0x5926: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_592b:
	/* 0x592b: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_5935:
	/* 0x5935: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_593a:
	/* 0x593a: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_5944:
	/* 0x5944: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5949:
	/* 0x5949: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5953:
	/* 0x5953: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5958:
	/* 0x5958: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_5960:
	/* 0x5960: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5965:
	/* 0x5965: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_596a:
	/* 0x596a: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_596d:
	/* 0x596d: call   5972 <kprobe_unwind_dotnet+0x5972> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5972:
	/* 0x5972: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_5979:
	/* 0x5979: jae    5546 <kprobe_unwind_dotnet+0x5546> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5979, 0x5546, x86_l_5546);
x86_l_597f:
	/* 0x597f: jmp    5aa3 <kprobe_unwind_dotnet+0x5aa3> */
	X86_SIM_X86_JMP(0x597f, 0x5aa3, x86_l_5aa3);
x86_l_5984:
	/* 0x5984: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5987:
	/* 0x5987: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_598a:
	/* 0x598a: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_598d:
	/* 0x598d: je     5a4f <kprobe_unwind_dotnet+0x5a4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x598d, 0x5a4f, x86_l_5a4f);
x86_l_5993:
	/* 0x5993: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_599a:
	/* 0x599a: jmp    5a5d <kprobe_unwind_dotnet+0x5a5d> */
	X86_SIM_X86_JMP(0x599a, 0x5a5d, x86_l_5a5d);
x86_l_599f:
	/* 0x599f: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_59a6:
	/* 0x59a6: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_59ab:
	/* 0x59ab: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_59b0:
	/* 0x59b0: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_59b3:
	/* 0x59b3: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_59b6:
	/* 0x59b6: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_59bd:
	/* 0x59bd: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_59c0:
	/* 0x59c0: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_59c5:
	/* 0x59c5: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_59c8:
	/* 0x59c8: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_59cb:
	/* 0x59cb: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_59ce:
	/* 0x59ce: call   59d3 <kprobe_unwind_dotnet+0x59d3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_59d3:
	/* 0x59d3: jmp    556a <kprobe_unwind_dotnet+0x556a> */
	X86_SIM_X86_JMP(0x59d3, 0x556a, x86_l_556a);
x86_l_59d8:
	/* 0x59d8: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_59e2:
	/* 0x59e2: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_59e7:
	/* 0x59e7: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_59f1:
	/* 0x59f1: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_59f6:
	/* 0x59f6: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5a00:
	/* 0x5a00: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5a05:
	/* 0x5a05: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_5a0f:
	/* 0x5a0f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5a14:
	/* 0x5a14: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_5a1e:
	/* 0x5a1e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5a23:
	/* 0x5a23: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_5a2d:
	/* 0x5a2d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5a32:
	/* 0x5a32: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5a36:
	/* 0x5a36: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5a3b:
	/* 0x5a3b: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5a40:
	/* 0x5a40: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5a42:
	/* 0x5a42: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5a45:
	/* 0x5a45: call   5a4a <kprobe_unwind_dotnet+0x5a4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5a4a:
	/* 0x5a4a: jmp    5436 <kprobe_unwind_dotnet+0x5436> */
	X86_SIM_X86_JMP(0x5a4a, 0x5436, x86_l_5436);
x86_l_5a4f:
	/* 0x5a4f: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_5a53:
	/* 0x5a53: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_5a5a:
	/* 0x5a5a: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5a5d:
	/* 0x5a5d: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5a60:
	/* 0x5a60: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_5a68:
	/* 0x5a68: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5a6b:
	/* 0x5a6b: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5a72:
	/* 0x5a72: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a75:
	/* 0x5a75: jne    5edf <kprobe_unwind_dotnet+0x5edf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a75, 0x5edf, x86_l_5edf);
x86_l_5a7b:
	/* 0x5a7b: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_5a7f:
	/* 0x5a7f: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5a84:
	/* 0x5a84: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_5a89:
	/* 0x5a89: call   5a8e <kprobe_unwind_dotnet+0x5a8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_5a8e:
	/* 0x5a8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a91:
	/* 0x5a91: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5a98:
	/* 0x5a98: jne    9fa <kprobe_unwind_dotnet+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a98, 0x9fa, x86_l_9fa);
x86_l_5a9e:
	/* 0x5a9e: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_5aa3:
	/* 0x5aa3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5aaa:
	/* 0x5aaa: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aad:
	/* 0x5aad: jne    5cf1 <kprobe_unwind_dotnet+0x5cf1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5aad, 0x5cf1, x86_l_5cf1);
x86_l_5ab3:
	/* 0x5ab3: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5aba:
	/* 0x5aba: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_5abe:
	/* 0x5abe: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5abe, 0xa4e, x86_l_a4e);
x86_l_5ac4:
	/* 0x5ac4: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5ac9:
	/* 0x5ac9: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_5acc:
	/* 0x5acc: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_5ad0:
	/* 0x5ad0: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5ad3:
	/* 0x5ad3: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_5ad6:
	/* 0x5ad6: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5add:
	/* 0x5add: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_5ae1:
	/* 0x5ae1: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_5ae9:
	/* 0x5ae9: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_5af1:
	/* 0x5af1: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_5afa:
	/* 0x5afa: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_5aff:
	/* 0x5aff: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_5b07:
	/* 0x5b07: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_5b13:
	/* 0x5b13: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_5b1e:
	/* 0x5b1e: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_5b26:
	/* 0x5b26: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5b2d:
	/* 0x5b2d: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5b32:
	/* 0x5b32: call   5b37 <kprobe_unwind_dotnet+0x5b37> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b37:
	/* 0x5b37: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b3a:
	/* 0x5b3a: je     5b41 <kprobe_unwind_dotnet+0x5b41> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b3a, 0x5b41, x86_l_5b41);
x86_l_5b3c:
	/* 0x5b3c: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5b3f:
	/* 0x5b3f: jmp    5b51 <kprobe_unwind_dotnet+0x5b51> */
	X86_SIM_X86_JMP(0x5b3f, 0x5b51, x86_l_5b51);
x86_l_5b41:
	/* 0x5b41: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5b48:
	/* 0x5b48: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b4b:
	/* 0x5b4b: jne    5dde <kprobe_unwind_dotnet+0x5dde> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b4b, 0x5dde, x86_l_5dde);
x86_l_5b51:
	/* 0x5b51: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_5b59:
	/* 0x5b59: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b5c:
	/* 0x5b5c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5b63:
	/* 0x5b63: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b65:
	/* 0x5b65: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5b68:
	/* 0x5b68: je     8172 <kprobe_unwind_dotnet+0x8172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b68, 0x8172, x86_l_8172);
x86_l_5b6e:
	/* 0x5b6e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5b70:
	/* 0x5b70: jne    5d45 <kprobe_unwind_dotnet+0x5d45> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b70, 0x5d45, x86_l_5d45);
x86_l_5b76:
	/* 0x5b76: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_5b80:
	/* 0x5b80: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b83:
	/* 0x5b83: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5b83, 0x21d0, x86_l_21d0);
x86_l_5b89:
	/* 0x5b89: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_5b90:
	/* 0x5b90: jb     2358 <kprobe_unwind_dotnet+0x2358> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5b90, 0x2358, x86_l_2358);
x86_l_5b96:
	/* 0x5b96: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b99:
	/* 0x5b99: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_5ba1:
	/* 0x5ba1: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_5ba7:
	/* 0x5ba7: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_5bae:
	/* 0x5bae: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_5bb5:
	/* 0x5bb5: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5bba:
	/* 0x5bba: call   5bbf <kprobe_unwind_dotnet+0x5bbf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5bbf:
	/* 0x5bbf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5bc2:
	/* 0x5bc2: je     80c1 <kprobe_unwind_dotnet+0x80c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5bc2, 0x80c1, x86_l_80c1);
x86_l_5bc8:
	/* 0x5bc8: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5bcc:
	/* 0x5bcc: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5bcf:
	/* 0x5bcf: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_5bd9:
	/* 0x5bd9: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_5bdc:
	/* 0x5bdc: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_5be3:
	/* 0x5be3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5be6:
	/* 0x5be6: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5bed:
	/* 0x5bed: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_5bf1:
	/* 0x5bf1: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5bf4:
	/* 0x5bf4: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_5bf7:
	/* 0x5bf7: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_5bfe:
	/* 0x5bfe: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5c05:
	/* 0x5c05: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c08:
	/* 0x5c08: jne    5fcc <kprobe_unwind_dotnet+0x5fcc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c08, 0x5fcc, x86_l_5fcc);
x86_l_5c0e:
	/* 0x5c0e: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5c12:
	/* 0x5c12: jne    6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c12, 0x6c97, x86_l_6c97);
x86_l_5c18:
	/* 0x5c18: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5c1f:
	/* 0x5c1f: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5c24:
	/* 0x5c24: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_5c2b:
	/* 0x5c2b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_5c32:
	/* 0x5c32: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5c37:
	/* 0x5c37: call   5c3c <kprobe_unwind_dotnet+0x5c3c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c3c:
	/* 0x5c3c: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5c42:
	/* 0x5c42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c45:
	/* 0x5c45: je     6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c45, 0x6c97, x86_l_6c97);
x86_l_5c4b:
	/* 0x5c4b: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c4e:
	/* 0x5c4e: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c51:
	/* 0x5c51: ja     5c59 <kprobe_unwind_dotnet+0x5c59> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c51, 0x5c59, x86_l_5c59);
x86_l_5c53:
	/* 0x5c53: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c57:
	/* 0x5c57: jae    5c6d <kprobe_unwind_dotnet+0x5c6d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c57, 0x5c6d, x86_l_5c6d);
x86_l_5c59:
	/* 0x5c59: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c5d:
	/* 0x5c5d: ja     6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c5d, 0x6c97, x86_l_6c97);
x86_l_5c63:
	/* 0x5c63: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c67:
	/* 0x5c67: jb     6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5c67, 0x6c97, x86_l_6c97);
x86_l_5c6d:
	/* 0x5c6d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5c74:
	/* 0x5c74: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c77:
	/* 0x5c77: jne    6bf6 <kprobe_unwind_dotnet+0x6bf6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c77, 0x6bf6, x86_l_6bf6);
x86_l_5c7d:
	/* 0x5c7d: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_5c84:
	/* 0x5c84: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5c88:
	/* 0x5c88: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5c8b:
	/* 0x5c8b: jae    6c5f <kprobe_unwind_dotnet+0x6c5f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c8b, 0x6c5f, x86_l_6c5f);
x86_l_5c91:
	/* 0x5c91: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5c98:
	/* 0x5c98: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c9b:
	/* 0x5c9b: je     6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c9b, 0x6c97, x86_l_6c97);
x86_l_5ca1:
	/* 0x5ca1: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_5cab:
	/* 0x5cab: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5cb0:
	/* 0x5cb0: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_5cba:
	/* 0x5cba: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5cbf:
	/* 0x5cbf: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_5cc9:
	/* 0x5cc9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cce:
	/* 0x5cce: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_5cd6:
	/* 0x5cd6: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cdb:
	/* 0x5cdb: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_5ce0:
	/* 0x5ce0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ce2:
	/* 0x5ce2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ce4:
	/* 0x5ce4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ce7:
	/* 0x5ce7: call   5cec <kprobe_unwind_dotnet+0x5cec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5cec:
	/* 0x5cec: jmp    6c97 <kprobe_unwind_dotnet+0x6c97> */
	X86_SIM_X86_JMP(0x5cec, 0x6c97, x86_l_6c97);
x86_l_5cf1:
	/* 0x5cf1: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_5cf8:
	/* 0x5cf8: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cfd:
	/* 0x5cfd: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_5d02:
	/* 0x5d02: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d05:
	/* 0x5d05: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_5d08:
	/* 0x5d08: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_5d0d:
	/* 0x5d0d: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_5d14:
	/* 0x5d14: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5d19:
	/* 0x5d19: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5d1c:
	/* 0x5d1c: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_5d1f:
	/* 0x5d1f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d22:
	/* 0x5d22: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_5d27:
	/* 0x5d27: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5d2a:
	/* 0x5d2a: call   5d2f <kprobe_unwind_dotnet+0x5d2f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5d2f:
	/* 0x5d2f: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5d36:
	/* 0x5d36: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_5d3a:
	/* 0x5d3a: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5d3a, 0xa4e, x86_l_a4e);
x86_l_5d40:
	/* 0x5d40: jmp    5ac4 <kprobe_unwind_dotnet+0x5ac4> */
	X86_SIM_X86_JMP(0x5d40, 0x5ac4, x86_l_5ac4);
x86_l_5d45:
	/* 0x5d45: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_5d4f:
	/* 0x5d4f: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5d54:
	/* 0x5d54: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_5d5e:
	/* 0x5d5e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5d63:
	/* 0x5d63: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_5d6d:
	/* 0x5d6d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5d72:
	/* 0x5d72: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_5d7c:
	/* 0x5d7c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5d81:
	/* 0x5d81: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_5d8b:
	/* 0x5d8b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5d90:
	/* 0x5d90: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_5d9a:
	/* 0x5d9a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5d9f:
	/* 0x5d9f: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_5da4:
	/* 0x5da4: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5dab:
	/* 0x5dab: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5db0:
	/* 0x5db0: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_5db5:
	/* 0x5db5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5db7:
	/* 0x5db7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5dba:
	/* 0x5dba: call   5dbf <kprobe_unwind_dotnet+0x5dbf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5dbf:
	/* 0x5dbf: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_5dc6:
	/* 0x5dc6: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_5dd0:
	/* 0x5dd0: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5dd3:
	/* 0x5dd3: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5dd3, 0x21d0, x86_l_21d0);
x86_l_5dd9:
	/* 0x5dd9: jmp    5b89 <kprobe_unwind_dotnet+0x5b89> */
	X86_SIM_X86_JMP(0x5dd9, 0x5b89, x86_l_5b89);
x86_l_5dde:
	/* 0x5dde: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_5de8:
	/* 0x5de8: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5ded:
	/* 0x5ded: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_5df7:
	/* 0x5df7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5dfc:
	/* 0x5dfc: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5e06:
	/* 0x5e06: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5e0b:
	/* 0x5e0b: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_5e15:
	/* 0x5e15: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5e1a:
	/* 0x5e1a: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_5e24:
	/* 0x5e24: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5e29:
	/* 0x5e29: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_5e33:
	/* 0x5e33: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e38:
	/* 0x5e38: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5e3c:
	/* 0x5e3c: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e41:
	/* 0x5e41: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5e46:
	/* 0x5e46: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e48:
	/* 0x5e48: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e4b:
	/* 0x5e4b: call   5e50 <kprobe_unwind_dotnet+0x5e50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5e50:
	/* 0x5e50: jmp    5b51 <kprobe_unwind_dotnet+0x5b51> */
	X86_SIM_X86_JMP(0x5e50, 0x5b51, x86_l_5b51);
x86_l_5e55:
	/* 0x5e55: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5e58:
	/* 0x5e58: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_5e5c:
	/* 0x5e5c: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_5e66:
	/* 0x5e66: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_5e6b:
	/* 0x5e6b: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_5e75:
	/* 0x5e75: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5e7a:
	/* 0x5e7a: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_5e84:
	/* 0x5e84: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5e89:
	/* 0x5e89: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_5e93:
	/* 0x5e93: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5e98:
	/* 0x5e98: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_5ea2:
	/* 0x5ea2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5ea7:
	/* 0x5ea7: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_5eb1:
	/* 0x5eb1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5eb6:
	/* 0x5eb6: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5ec0:
	/* 0x5ec0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5ec5:
	/* 0x5ec5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5eca:
	/* 0x5eca: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_5ecf:
	/* 0x5ecf: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5ed2:
	/* 0x5ed2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ed5:
	/* 0x5ed5: call   5eda <kprobe_unwind_dotnet+0x5eda> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5eda:
	/* 0x5eda: jmp    55fb <kprobe_unwind_dotnet+0x55fb> */
	X86_SIM_X86_JMP(0x5eda, 0x55fb, x86_l_55fb);
x86_l_5edf:
	/* 0x5edf: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5ee1:
	/* 0x5ee1: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_5eeb:
	/* 0x5eeb: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5ef0:
	/* 0x5ef0: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_5efa:
	/* 0x5efa: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5eff:
	/* 0x5eff: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_5f09:
	/* 0x5f09: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5f0e:
	/* 0x5f0e: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_5f18:
	/* 0x5f18: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f1d:
	/* 0x5f1d: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_5f27:
	/* 0x5f27: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5f2c:
	/* 0x5f2c: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_5f36:
	/* 0x5f36: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f3b:
	/* 0x5f3b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f40:
	/* 0x5f40: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5f45:
	/* 0x5f45: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5f48:
	/* 0x5f48: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5f4b:
	/* 0x5f4b: call   5f50 <kprobe_unwind_dotnet+0x5f50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5f50:
	/* 0x5f50: jmp    5a7b <kprobe_unwind_dotnet+0x5a7b> */
	X86_SIM_X86_JMP(0x5f50, 0x5a7b, x86_l_5a7b);
x86_l_5f55:
	/* 0x5f55: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_5f5f:
	/* 0x5f5f: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5f64:
	/* 0x5f64: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_5f6e:
	/* 0x5f6e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5f73:
	/* 0x5f73: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5f7d:
	/* 0x5f7d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5f82:
	/* 0x5f82: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_5f8c:
	/* 0x5f8c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f91:
	/* 0x5f91: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_5f9b:
	/* 0x5f9b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5fa0:
	/* 0x5fa0: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_5faa:
	/* 0x5faa: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5faf:
	/* 0x5faf: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5fb3:
	/* 0x5fb3: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5fb8:
	/* 0x5fb8: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5fbd:
	/* 0x5fbd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5fbf:
	/* 0x5fbf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5fc2:
	/* 0x5fc2: call   5fc7 <kprobe_unwind_dotnet+0x5fc7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5fc7:
	/* 0x5fc7: jmp    564b <kprobe_unwind_dotnet+0x564b> */
	X86_SIM_X86_JMP(0x5fc7, 0x564b, x86_l_564b);
x86_l_5fcc:
	/* 0x5fcc: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_5fd6:
	/* 0x5fd6: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5fdb:
	/* 0x5fdb: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_5fe5:
	/* 0x5fe5: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5fea:
	/* 0x5fea: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_5ff4:
	/* 0x5ff4: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5ff9:
	/* 0x5ff9: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_6003:
	/* 0x6003: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6008:
	/* 0x6008: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_6012:
	/* 0x6012: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6017:
	/* 0x6017: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_6021:
	/* 0x6021: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6026:
	/* 0x6026: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_602d:
	/* 0x602d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6032:
	/* 0x6032: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_6037:
	/* 0x6037: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_603a:
	/* 0x603a: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_603d:
	/* 0x603d: call   6042 <kprobe_unwind_dotnet+0x6042> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6042:
	/* 0x6042: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6049:
	/* 0x6049: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_604c:
	/* 0x604c: je     5c0e <kprobe_unwind_dotnet+0x5c0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x604c, 0x5c0e, x86_l_5c0e);
x86_l_6052:
	/* 0x6052: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_605c:
	/* 0x605c: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_6061:
	/* 0x6061: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_606b:
	/* 0x606b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6070:
	/* 0x6070: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_607a:
	/* 0x607a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_607f:
	/* 0x607f: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_6089:
	/* 0x6089: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_608e:
	/* 0x608e: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_6098:
	/* 0x6098: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_609d:
	/* 0x609d: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_60a2:
	/* 0x60a2: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_60a9:
	/* 0x60a9: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_60b0:
	/* 0x60b0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_60b5:
	/* 0x60b5: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_60ba:
	/* 0x60ba: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_60bd:
	/* 0x60bd: call   60c2 <kprobe_unwind_dotnet+0x60c2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_60c2:
	/* 0x60c2: jmp    5c0e <kprobe_unwind_dotnet+0x5c0e> */
	X86_SIM_X86_JMP(0x60c2, 0x5c0e, x86_l_5c0e);
x86_l_60c7:
	/* 0x60c7: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_60d1:
	/* 0x60d1: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_60d6:
	/* 0x60d6: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_60e0:
	/* 0x60e0: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_60e5:
	/* 0x60e5: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_60ef:
	/* 0x60ef: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_60f4:
	/* 0x60f4: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_60fe:
	/* 0x60fe: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6103:
	/* 0x6103: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_610d:
	/* 0x610d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6112:
	/* 0x6112: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_611c:
	/* 0x611c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6121:
	/* 0x6121: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_612b:
	/* 0x612b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6130:
	/* 0x6130: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6135:
	/* 0x6135: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_613a:
	/* 0x613a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_613d:
	/* 0x613d: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6140:
	/* 0x6140: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6143:
	/* 0x6143: call   6148 <kprobe_unwind_dotnet+0x6148> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6148:
	/* 0x6148: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_614a:
	/* 0x614a: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_614d:
	/* 0x614d: jne    5705 <kprobe_unwind_dotnet+0x5705> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x614d, 0x5705, x86_l_5705);
x86_l_6153:
	/* 0x6153: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_615a:
	/* 0x615a: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_615f:
	/* 0x615f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6162:
	/* 0x6162: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6162, 0x665a, x86_l_665a);
x86_l_6168:
	/* 0x6168: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_616f:
	/* 0x616f: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_6174:
	/* 0x6174: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6177:
	/* 0x6177: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6177, 0x665a, x86_l_665a);
x86_l_617d:
	/* 0x617d: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_6184:
	/* 0x6184: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_6189:
	/* 0x6189: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_618c:
	/* 0x618c: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x618c, 0x665a, x86_l_665a);
x86_l_6192:
	/* 0x6192: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_6199:
	/* 0x6199: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_619e:
	/* 0x619e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61a1:
	/* 0x61a1: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61a1, 0x665a, x86_l_665a);
x86_l_61a7:
	/* 0x61a7: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_61ae:
	/* 0x61ae: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_61b3:
	/* 0x61b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61b6:
	/* 0x61b6: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61b6, 0x665a, x86_l_665a);
x86_l_61bc:
	/* 0x61bc: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_61c3:
	/* 0x61c3: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_61c8:
	/* 0x61c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61cb:
	/* 0x61cb: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61cb, 0x665a, x86_l_665a);
x86_l_61d1:
	/* 0x61d1: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_61d8:
	/* 0x61d8: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_61dd:
	/* 0x61dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61e0:
	/* 0x61e0: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61e0, 0x665a, x86_l_665a);
x86_l_61e6:
	/* 0x61e6: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_61ed:
	/* 0x61ed: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_61f2:
	/* 0x61f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61f5:
	/* 0x61f5: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x61f5, 0x665a, x86_l_665a);
x86_l_61fb:
	/* 0x61fb: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_6202:
	/* 0x6202: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_6207:
	/* 0x6207: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_620a:
	/* 0x620a: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x620a, 0x665a, x86_l_665a);
x86_l_6210:
	/* 0x6210: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_6217:
	/* 0x6217: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_621c:
	/* 0x621c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_621f:
	/* 0x621f: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x621f, 0x665a, x86_l_665a);
x86_l_6225:
	/* 0x6225: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_622c:
	/* 0x622c: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_6231:
	/* 0x6231: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6234:
	/* 0x6234: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6234, 0x665a, x86_l_665a);
x86_l_623a:
	/* 0x623a: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_6241:
	/* 0x6241: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_6246:
	/* 0x6246: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6249:
	/* 0x6249: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6249, 0x665a, x86_l_665a);
x86_l_624f:
	/* 0x624f: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_6256:
	/* 0x6256: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_625b:
	/* 0x625b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_625e:
	/* 0x625e: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x625e, 0x665a, x86_l_665a);
x86_l_6264:
	/* 0x6264: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_626b:
	/* 0x626b: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_6270:
	/* 0x6270: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6273:
	/* 0x6273: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6273, 0x665a, x86_l_665a);
x86_l_6279:
	/* 0x6279: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_6280:
	/* 0x6280: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_6285:
	/* 0x6285: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6288:
	/* 0x6288: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6288, 0x665a, x86_l_665a);
x86_l_628e:
	/* 0x628e: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_6295:
	/* 0x6295: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_629a:
	/* 0x629a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_629d:
	/* 0x629d: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x629d, 0x665a, x86_l_665a);
x86_l_62a3:
	/* 0x62a3: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_62aa:
	/* 0x62aa: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_62af:
	/* 0x62af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62b2:
	/* 0x62b2: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62b2, 0x665a, x86_l_665a);
x86_l_62b8:
	/* 0x62b8: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_62bf:
	/* 0x62bf: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_62c4:
	/* 0x62c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62c7:
	/* 0x62c7: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62c7, 0x665a, x86_l_665a);
x86_l_62cd:
	/* 0x62cd: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_62d4:
	/* 0x62d4: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_62d9:
	/* 0x62d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62dc:
	/* 0x62dc: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62dc, 0x665a, x86_l_665a);
x86_l_62e2:
	/* 0x62e2: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_62e9:
	/* 0x62e9: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_62ee:
	/* 0x62ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62f1:
	/* 0x62f1: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62f1, 0x665a, x86_l_665a);
x86_l_62f7:
	/* 0x62f7: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_62fe:
	/* 0x62fe: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_6303:
	/* 0x6303: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6306:
	/* 0x6306: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6306, 0x665a, x86_l_665a);
x86_l_630c:
	/* 0x630c: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_6313:
	/* 0x6313: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_6318:
	/* 0x6318: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_631b:
	/* 0x631b: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x631b, 0x665a, x86_l_665a);
x86_l_6321:
	/* 0x6321: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_6328:
	/* 0x6328: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_632d:
	/* 0x632d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6330:
	/* 0x6330: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6330, 0x665a, x86_l_665a);
x86_l_6336:
	/* 0x6336: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_633d:
	/* 0x633d: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_6342:
	/* 0x6342: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6345:
	/* 0x6345: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6345, 0x665a, x86_l_665a);
x86_l_634b:
	/* 0x634b: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_6352:
	/* 0x6352: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_6357:
	/* 0x6357: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_635a:
	/* 0x635a: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x635a, 0x665a, x86_l_665a);
x86_l_6360:
	/* 0x6360: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_6367:
	/* 0x6367: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_636c:
	/* 0x636c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_636f:
	/* 0x636f: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x636f, 0x665a, x86_l_665a);
x86_l_6375:
	/* 0x6375: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_637c:
	/* 0x637c: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_6381:
	/* 0x6381: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6384:
	/* 0x6384: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6384, 0x665a, x86_l_665a);
x86_l_638a:
	/* 0x638a: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_6391:
	/* 0x6391: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_6396:
	/* 0x6396: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6399:
	/* 0x6399: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6399, 0x665a, x86_l_665a);
x86_l_639f:
	/* 0x639f: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_63a6:
	/* 0x63a6: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_63ab:
	/* 0x63ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_63ae:
	/* 0x63ae: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x63ae, 0x665a, x86_l_665a);
x86_l_63b4:
	/* 0x63b4: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_63bb:
	/* 0x63bb: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_63c0:
	/* 0x63c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_63c3:
	/* 0x63c3: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x63c3, 0x665a, x86_l_665a);
x86_l_63c9:
	/* 0x63c9: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_63d0:
	/* 0x63d0: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_63d5:
	/* 0x63d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_63d8:
	/* 0x63d8: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x63d8, 0x665a, x86_l_665a);
x86_l_63de:
	/* 0x63de: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_63e5:
	/* 0x63e5: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_63ea:
	/* 0x63ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_63ed:
	/* 0x63ed: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x63ed, 0x665a, x86_l_665a);
x86_l_63f3:
	/* 0x63f3: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_63fa:
	/* 0x63fa: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_63ff:
	/* 0x63ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6402:
	/* 0x6402: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6402, 0x665a, x86_l_665a);
x86_l_6408:
	/* 0x6408: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_640f:
	/* 0x640f: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_6414:
	/* 0x6414: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6417:
	/* 0x6417: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6417, 0x665a, x86_l_665a);
x86_l_641d:
	/* 0x641d: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_6424:
	/* 0x6424: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_6429:
	/* 0x6429: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_642c:
	/* 0x642c: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x642c, 0x665a, x86_l_665a);
x86_l_6432:
	/* 0x6432: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_6439:
	/* 0x6439: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_643e:
	/* 0x643e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6441:
	/* 0x6441: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6441, 0x665a, x86_l_665a);
x86_l_6447:
	/* 0x6447: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_644e:
	/* 0x644e: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_6453:
	/* 0x6453: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6456:
	/* 0x6456: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6456, 0x665a, x86_l_665a);
x86_l_645c:
	/* 0x645c: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_6463:
	/* 0x6463: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_6468:
	/* 0x6468: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_646b:
	/* 0x646b: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x646b, 0x665a, x86_l_665a);
x86_l_6471:
	/* 0x6471: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_6478:
	/* 0x6478: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_647d:
	/* 0x647d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6480:
	/* 0x6480: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6480, 0x665a, x86_l_665a);
x86_l_6486:
	/* 0x6486: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_648d:
	/* 0x648d: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_6492:
	/* 0x6492: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6495:
	/* 0x6495: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6495, 0x665a, x86_l_665a);
x86_l_649b:
	/* 0x649b: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_64a2:
	/* 0x64a2: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_64a7:
	/* 0x64a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64aa:
	/* 0x64aa: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64aa, 0x665a, x86_l_665a);
x86_l_64b0:
	/* 0x64b0: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_64b7:
	/* 0x64b7: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_64bc:
	/* 0x64bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64bf:
	/* 0x64bf: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64bf, 0x665a, x86_l_665a);
x86_l_64c5:
	/* 0x64c5: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_64cc:
	/* 0x64cc: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_64d1:
	/* 0x64d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64d4:
	/* 0x64d4: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64d4, 0x665a, x86_l_665a);
x86_l_64da:
	/* 0x64da: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_64e1:
	/* 0x64e1: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_64e6:
	/* 0x64e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64e9:
	/* 0x64e9: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64e9, 0x665a, x86_l_665a);
x86_l_64ef:
	/* 0x64ef: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_64f6:
	/* 0x64f6: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_64fb:
	/* 0x64fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64fe:
	/* 0x64fe: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64fe, 0x665a, x86_l_665a);
x86_l_6504:
	/* 0x6504: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_650b:
	/* 0x650b: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_6510:
	/* 0x6510: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6513:
	/* 0x6513: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6513, 0x665a, x86_l_665a);
x86_l_6519:
	/* 0x6519: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_6520:
	/* 0x6520: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_6525:
	/* 0x6525: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6528:
	/* 0x6528: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6528, 0x665a, x86_l_665a);
x86_l_652e:
	/* 0x652e: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_6535:
	/* 0x6535: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_653a:
	/* 0x653a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_653d:
	/* 0x653d: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x653d, 0x665a, x86_l_665a);
x86_l_6543:
	/* 0x6543: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_654a:
	/* 0x654a: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_654f:
	/* 0x654f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6552:
	/* 0x6552: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6552, 0x665a, x86_l_665a);
x86_l_6558:
	/* 0x6558: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_655f:
	/* 0x655f: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_6564:
	/* 0x6564: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6567:
	/* 0x6567: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6567, 0x665a, x86_l_665a);
x86_l_656d:
	/* 0x656d: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_6574:
	/* 0x6574: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_6579:
	/* 0x6579: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_657c:
	/* 0x657c: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x657c, 0x665a, x86_l_665a);
x86_l_6582:
	/* 0x6582: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_6589:
	/* 0x6589: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_658e:
	/* 0x658e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6591:
	/* 0x6591: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6591, 0x665a, x86_l_665a);
x86_l_6597:
	/* 0x6597: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_659e:
	/* 0x659e: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_65a3:
	/* 0x65a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65a6:
	/* 0x65a6: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x65a6, 0x665a, x86_l_665a);
x86_l_65ac:
	/* 0x65ac: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_65b3:
	/* 0x65b3: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_65b8:
	/* 0x65b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65bb:
	/* 0x65bb: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x65bb, 0x665a, x86_l_665a);
x86_l_65c1:
	/* 0x65c1: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_65c8:
	/* 0x65c8: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_65cd:
	/* 0x65cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65d0:
	/* 0x65d0: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x65d0, 0x665a, x86_l_665a);
x86_l_65d6:
	/* 0x65d6: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_65dd:
	/* 0x65dd: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_65e2:
	/* 0x65e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65e5:
	/* 0x65e5: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x65e5, 0x665a, x86_l_665a);
x86_l_65e7:
	/* 0x65e7: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_65ee:
	/* 0x65ee: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_65f3:
	/* 0x65f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65f6:
	/* 0x65f6: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x65f6, 0x665a, x86_l_665a);
x86_l_65f8:
	/* 0x65f8: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_65ff:
	/* 0x65ff: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_6604:
	/* 0x6604: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6607:
	/* 0x6607: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6607, 0x665a, x86_l_665a);
x86_l_6609:
	/* 0x6609: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_6610:
	/* 0x6610: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_6615:
	/* 0x6615: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6618:
	/* 0x6618: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6618, 0x665a, x86_l_665a);
x86_l_661a:
	/* 0x661a: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_6621:
	/* 0x6621: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_6626:
	/* 0x6626: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6629:
	/* 0x6629: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6629, 0x665a, x86_l_665a);
x86_l_662b:
	/* 0x662b: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_6632:
	/* 0x6632: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_6637:
	/* 0x6637: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_663a:
	/* 0x663a: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x663a, 0x665a, x86_l_665a);
x86_l_663c:
	/* 0x663c: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_6643:
	/* 0x6643: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_6648:
	/* 0x6648: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_664b:
	/* 0x664b: jne    665a <kprobe_unwind_dotnet+0x665a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x664b, 0x665a, x86_l_665a);
x86_l_664d:
	/* 0x664d: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_6655:
	/* 0x6655: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6658:
	/* 0x6658: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_665a:
	/* 0x665a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_665c:
	/* 0x665c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_665f:
	/* 0x665f: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_6663:
	/* 0x6663: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_6667:
	/* 0x6667: jne    666c <kprobe_unwind_dotnet+0x666c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6667, 0x666c, x86_l_666c);
x86_l_6669:
	/* 0x6669: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_666c:
	/* 0x666c: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_666f:
	/* 0x666f: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_6671:
	/* 0x6671: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_6674:
	/* 0x6674: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6676:
	/* 0x6676: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_6679:
	/* 0x6679: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_667c:
	/* 0x667c: jb     5713 <kprobe_unwind_dotnet+0x5713> */
	X86_SIM_X86_JCC(X86_CC_B, 0x667c, 0x5713, x86_l_5713);
x86_l_6682:
	/* 0x6682: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6689:
	/* 0x6689: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_668c:
	/* 0x668c: jne    6b60 <kprobe_unwind_dotnet+0x6b60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x668c, 0x6b60, x86_l_6b60);
x86_l_6692:
	/* 0x6692: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6695:
	/* 0x6695: jne    5617 <kprobe_unwind_dotnet+0x5617> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6695, 0x5617, x86_l_5617);
x86_l_669b:
	/* 0x669b: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_66a3:
	/* 0x66a3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_66aa:
	/* 0x66aa: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_66af:
	/* 0x66af: call   66b4 <kprobe_unwind_dotnet+0x66b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_66b4:
	/* 0x66b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_66b7:
	/* 0x66b7: je     66be <kprobe_unwind_dotnet+0x66be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x66b7, 0x66be, x86_l_66be);
x86_l_66b9:
	/* 0x66b9: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_66bc:
	/* 0x66bc: jmp    66ce <kprobe_unwind_dotnet+0x66ce> */
	X86_SIM_X86_JMP(0x66bc, 0x66ce, x86_l_66ce);
x86_l_66be:
	/* 0x66be: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_66c5:
	/* 0x66c5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_66c8:
	/* 0x66c8: jne    73c9 <kprobe_unwind_dotnet+0x73c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x66c8, 0x73c9, x86_l_73c9);
x86_l_66ce:
	/* 0x66ce: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_66d3:
	/* 0x66d3: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_66d5:
	/* 0x66d5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_66dc:
	/* 0x66dc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_66df:
	/* 0x66df: je     5662 <kprobe_unwind_dotnet+0x5662> */
	X86_SIM_X86_JCC(X86_CC_E, 0x66df, 0x5662, x86_l_5662);
x86_l_66e5:
	/* 0x66e5: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_66ef:
	/* 0x66ef: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_66f4:
	/* 0x66f4: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_66fe:
	/* 0x66fe: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6703:
	/* 0x6703: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_670d:
	/* 0x670d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6712:
	/* 0x6712: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_671c:
	/* 0x671c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6721:
	/* 0x6721: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_672b:
	/* 0x672b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6730:
	/* 0x6730: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6735:
	/* 0x6735: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_673a:
	/* 0x673a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_673c:
	/* 0x673c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_673f:
	/* 0x673f: call   6744 <kprobe_unwind_dotnet+0x6744> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6744:
	/* 0x6744: jmp    5662 <kprobe_unwind_dotnet+0x5662> */
	X86_SIM_X86_JMP(0x6744, 0x5662, x86_l_5662);
x86_l_6749:
	/* 0x6749: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_6750:
	/* 0x6750: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_6755:
	/* 0x6755: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6758:
	/* 0x6758: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6758, 0x5215, x86_l_5215);
x86_l_675e:
	/* 0x675e: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_6765:
	/* 0x6765: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_676a:
	/* 0x676a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_676d:
	/* 0x676d: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x676d, 0x5215, x86_l_5215);
x86_l_6773:
	/* 0x6773: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_677a:
	/* 0x677a: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_677f:
	/* 0x677f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6782:
	/* 0x6782: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6782, 0x5215, x86_l_5215);
x86_l_6788:
	/* 0x6788: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_678f:
	/* 0x678f: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_6794:
	/* 0x6794: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6797:
	/* 0x6797: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6797, 0x5215, x86_l_5215);
x86_l_679d:
	/* 0x679d: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_67a4:
	/* 0x67a4: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_67a9:
	/* 0x67a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67ac:
	/* 0x67ac: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67ac, 0x5215, x86_l_5215);
x86_l_67b2:
	/* 0x67b2: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_67b9:
	/* 0x67b9: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_67be:
	/* 0x67be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67c1:
	/* 0x67c1: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67c1, 0x5215, x86_l_5215);
x86_l_67c7:
	/* 0x67c7: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_67ce:
	/* 0x67ce: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_67d3:
	/* 0x67d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67d6:
	/* 0x67d6: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67d6, 0x5215, x86_l_5215);
x86_l_67dc:
	/* 0x67dc: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_67e3:
	/* 0x67e3: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_67e8:
	/* 0x67e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67eb:
	/* 0x67eb: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67eb, 0x5215, x86_l_5215);
x86_l_67f1:
	/* 0x67f1: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_67f8:
	/* 0x67f8: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_67fd:
	/* 0x67fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6800:
	/* 0x6800: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6800, 0x5215, x86_l_5215);
x86_l_6806:
	/* 0x6806: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_680d:
	/* 0x680d: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_6812:
	/* 0x6812: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6815:
	/* 0x6815: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6815, 0x5215, x86_l_5215);
x86_l_681b:
	/* 0x681b: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_6822:
	/* 0x6822: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_6827:
	/* 0x6827: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_682a:
	/* 0x682a: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x682a, 0x5215, x86_l_5215);
x86_l_6830:
	/* 0x6830: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_6837:
	/* 0x6837: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_683c:
	/* 0x683c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_683f:
	/* 0x683f: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x683f, 0x5215, x86_l_5215);
x86_l_6845:
	/* 0x6845: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_684c:
	/* 0x684c: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_6851:
	/* 0x6851: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6854:
	/* 0x6854: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6854, 0x5215, x86_l_5215);
x86_l_685a:
	/* 0x685a: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_6861:
	/* 0x6861: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_6866:
	/* 0x6866: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6869:
	/* 0x6869: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6869, 0x5215, x86_l_5215);
x86_l_686f:
	/* 0x686f: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_6876:
	/* 0x6876: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_687b:
	/* 0x687b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_687e:
	/* 0x687e: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x687e, 0x5215, x86_l_5215);
x86_l_6884:
	/* 0x6884: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_688b:
	/* 0x688b: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_6890:
	/* 0x6890: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6893:
	/* 0x6893: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6893, 0x5215, x86_l_5215);
x86_l_6899:
	/* 0x6899: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_68a0:
	/* 0x68a0: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_68a5:
	/* 0x68a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68a8:
	/* 0x68a8: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68a8, 0x5215, x86_l_5215);
x86_l_68ae:
	/* 0x68ae: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_68b5:
	/* 0x68b5: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_68ba:
	/* 0x68ba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68bd:
	/* 0x68bd: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68bd, 0x5215, x86_l_5215);
x86_l_68c3:
	/* 0x68c3: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_68ca:
	/* 0x68ca: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_68cf:
	/* 0x68cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68d2:
	/* 0x68d2: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68d2, 0x5215, x86_l_5215);
x86_l_68d8:
	/* 0x68d8: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_68df:
	/* 0x68df: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_68e4:
	/* 0x68e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68e7:
	/* 0x68e7: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68e7, 0x5215, x86_l_5215);
x86_l_68ed:
	/* 0x68ed: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_68f4:
	/* 0x68f4: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_68f9:
	/* 0x68f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68fc:
	/* 0x68fc: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68fc, 0x5215, x86_l_5215);
x86_l_6902:
	/* 0x6902: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_6909:
	/* 0x6909: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_690e:
	/* 0x690e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6911:
	/* 0x6911: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6911, 0x5215, x86_l_5215);
x86_l_6917:
	/* 0x6917: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_691e:
	/* 0x691e: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_6923:
	/* 0x6923: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6926:
	/* 0x6926: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6926, 0x5215, x86_l_5215);
x86_l_692c:
	/* 0x692c: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_6933:
	/* 0x6933: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_6938:
	/* 0x6938: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_693b:
	/* 0x693b: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x693b, 0x5215, x86_l_5215);
x86_l_6941:
	/* 0x6941: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_6948:
	/* 0x6948: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_694d:
	/* 0x694d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6950:
	/* 0x6950: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6950, 0x5215, x86_l_5215);
x86_l_6956:
	/* 0x6956: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_695d:
	/* 0x695d: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_6962:
	/* 0x6962: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6965:
	/* 0x6965: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6965, 0x5215, x86_l_5215);
x86_l_696b:
	/* 0x696b: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_6972:
	/* 0x6972: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_6977:
	/* 0x6977: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_697a:
	/* 0x697a: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x697a, 0x5215, x86_l_5215);
x86_l_6980:
	/* 0x6980: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_6987:
	/* 0x6987: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_698c:
	/* 0x698c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_698f:
	/* 0x698f: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x698f, 0x5215, x86_l_5215);
x86_l_6995:
	/* 0x6995: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_699c:
	/* 0x699c: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_69a1:
	/* 0x69a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69a4:
	/* 0x69a4: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69a4, 0x5215, x86_l_5215);
x86_l_69aa:
	/* 0x69aa: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_69b1:
	/* 0x69b1: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_69b6:
	/* 0x69b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69b9:
	/* 0x69b9: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69b9, 0x5215, x86_l_5215);
x86_l_69bf:
	/* 0x69bf: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_69c6:
	/* 0x69c6: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_69cb:
	/* 0x69cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69ce:
	/* 0x69ce: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69ce, 0x5215, x86_l_5215);
x86_l_69d4:
	/* 0x69d4: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_69db:
	/* 0x69db: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_69e0:
	/* 0x69e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69e3:
	/* 0x69e3: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69e3, 0x5215, x86_l_5215);
x86_l_69e9:
	/* 0x69e9: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_69f0:
	/* 0x69f0: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_69f5:
	/* 0x69f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69f8:
	/* 0x69f8: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x69f8, 0x5215, x86_l_5215);
x86_l_69fe:
	/* 0x69fe: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_6a05:
	/* 0x6a05: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_6a0a:
	/* 0x6a0a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a0d:
	/* 0x6a0d: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a0d, 0x5215, x86_l_5215);
x86_l_6a13:
	/* 0x6a13: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_6a1a:
	/* 0x6a1a: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_6a1f:
	/* 0x6a1f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a22:
	/* 0x6a22: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a22, 0x5215, x86_l_5215);
x86_l_6a28:
	/* 0x6a28: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_6a2f:
	/* 0x6a2f: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_6a34:
	/* 0x6a34: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a37:
	/* 0x6a37: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a37, 0x5215, x86_l_5215);
x86_l_6a3d:
	/* 0x6a3d: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_6a44:
	/* 0x6a44: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_6a49:
	/* 0x6a49: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a4c:
	/* 0x6a4c: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a4c, 0x5215, x86_l_5215);
x86_l_6a52:
	/* 0x6a52: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_6a59:
	/* 0x6a59: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_6a5e:
	/* 0x6a5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a61:
	/* 0x6a61: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a61, 0x5215, x86_l_5215);
x86_l_6a67:
	/* 0x6a67: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_6a6e:
	/* 0x6a6e: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_6a73:
	/* 0x6a73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a76:
	/* 0x6a76: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a76, 0x5215, x86_l_5215);
x86_l_6a7c:
	/* 0x6a7c: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_6a83:
	/* 0x6a83: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_6a88:
	/* 0x6a88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a8b:
	/* 0x6a8b: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a8b, 0x5215, x86_l_5215);
x86_l_6a91:
	/* 0x6a91: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_6a98:
	/* 0x6a98: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_6a9d:
	/* 0x6a9d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6aa0:
	/* 0x6aa0: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6aa0, 0x5215, x86_l_5215);
x86_l_6aa6:
	/* 0x6aa6: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_6aad:
	/* 0x6aad: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_6ab2:
	/* 0x6ab2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ab5:
	/* 0x6ab5: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ab5, 0x5215, x86_l_5215);
x86_l_6abb:
	/* 0x6abb: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_6ac2:
	/* 0x6ac2: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_6ac7:
	/* 0x6ac7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6aca:
	/* 0x6aca: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6aca, 0x5215, x86_l_5215);
x86_l_6ad0:
	/* 0x6ad0: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_6ad7:
	/* 0x6ad7: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_6adc:
	/* 0x6adc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6adf:
	/* 0x6adf: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6adf, 0x5215, x86_l_5215);
x86_l_6ae5:
	/* 0x6ae5: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_6aec:
	/* 0x6aec: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_6af1:
	/* 0x6af1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6af4:
	/* 0x6af4: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6af4, 0x5215, x86_l_5215);
x86_l_6afa:
	/* 0x6afa: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_6b01:
	/* 0x6b01: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_6b06:
	/* 0x6b06: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b09:
	/* 0x6b09: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b09, 0x5215, x86_l_5215);
x86_l_6b0f:
	/* 0x6b0f: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_6b16:
	/* 0x6b16: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_6b1b:
	/* 0x6b1b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b1e:
	/* 0x6b1e: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b1e, 0x5215, x86_l_5215);
x86_l_6b24:
	/* 0x6b24: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_6b2b:
	/* 0x6b2b: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_6b30:
	/* 0x6b30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b33:
	/* 0x6b33: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b33, 0x5215, x86_l_5215);
x86_l_6b39:
	/* 0x6b39: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_6b40:
	/* 0x6b40: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_6b45:
	/* 0x6b45: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b48:
	/* 0x6b48: jne    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6b48, 0x5215, x86_l_5215);
x86_l_6b4e:
	/* 0x6b4e: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_6b56:
	/* 0x6b56: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b59:
	/* 0x6b59: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b5b:
	/* 0x6b5b: jmp    5215 <kprobe_unwind_dotnet+0x5215> */
	X86_SIM_X86_JMP(0x6b5b, 0x5215, x86_l_5215);
x86_l_6b60:
	/* 0x6b60: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_6b6a:
	/* 0x6b6a: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6b6f:
	/* 0x6b6f: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_6b79:
	/* 0x6b79: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_6b7e:
	/* 0x6b7e: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_6b88:
	/* 0x6b88: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6b8d:
	/* 0x6b8d: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_6b97:
	/* 0x6b97: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6b9c:
	/* 0x6b9c: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_6ba6:
	/* 0x6ba6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6bab:
	/* 0x6bab: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_6bb5:
	/* 0x6bb5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6bba:
	/* 0x6bba: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_6bc4:
	/* 0x6bc4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6bc9:
	/* 0x6bc9: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_6bd1:
	/* 0x6bd1: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6bd3:
	/* 0x6bd3: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6bd6:
	/* 0x6bd6: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6bdb:
	/* 0x6bdb: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_6be0:
	/* 0x6be0: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6be3:
	/* 0x6be3: call   6be8 <kprobe_unwind_dotnet+0x6be8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6be8:
	/* 0x6be8: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6beb:
	/* 0x6beb: jne    5617 <kprobe_unwind_dotnet+0x5617> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6beb, 0x5617, x86_l_5617);
x86_l_6bf1:
	/* 0x6bf1: jmp    669b <kprobe_unwind_dotnet+0x669b> */
	X86_SIM_X86_JMP(0x6bf1, 0x669b, x86_l_669b);
x86_l_6bf6:
	/* 0x6bf6: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_6c00:
	/* 0x6c00: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_6c05:
	/* 0x6c05: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_6c0f:
	/* 0x6c0f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6c14:
	/* 0x6c14: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_6c1e:
	/* 0x6c1e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6c23:
	/* 0x6c23: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_6c2d:
	/* 0x6c2d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6c32:
	/* 0x6c32: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6c37:
	/* 0x6c37: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6c3c:
	/* 0x6c3c: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_6c41:
	/* 0x6c41: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6c43:
	/* 0x6c43: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6c46:
	/* 0x6c46: call   6c4b <kprobe_unwind_dotnet+0x6c4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6c4b:
	/* 0x6c4b: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_6c52:
	/* 0x6c52: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6c56:
	/* 0x6c56: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6c59:
	/* 0x6c59: jb     5c91 <kprobe_unwind_dotnet+0x5c91> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6c59, 0x5c91, x86_l_5c91);
x86_l_6c5f:
	/* 0x6c5f: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_6c67:
	/* 0x6c67: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_6c6e:
	/* 0x6c6e: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6c73:
	/* 0x6c73: call   6c78 <kprobe_unwind_dotnet+0x6c78> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6c78:
	/* 0x6c78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c7b:
	/* 0x6c7b: je     6c82 <kprobe_unwind_dotnet+0x6c82> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c7b, 0x6c82, x86_l_6c82);
x86_l_6c7d:
	/* 0x6c7d: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6c80:
	/* 0x6c80: jmp    6c92 <kprobe_unwind_dotnet+0x6c92> */
	X86_SIM_X86_JMP(0x6c80, 0x6c92, x86_l_6c92);
x86_l_6c82:
	/* 0x6c82: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6c89:
	/* 0x6c89: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c8c:
	/* 0x6c8c: jne    7440 <kprobe_unwind_dotnet+0x7440> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c8c, 0x7440, x86_l_7440);
x86_l_6c92:
	/* 0x6c92: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6c97:
	/* 0x6c97: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6c9b:
	/* 0x6c9b: jne    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c9b, 0x85e7, x86_l_85e7);
x86_l_6ca1:
	/* 0x6ca1: mov    r12,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_6ca8:
	/* 0x6ca8: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_6caf:
	/* 0x6caf: mov    r13,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_6cb6:
	/* 0x6cb6: movzx  eax,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_6cbe:
	/* 0x6cbe: mov    BYTE PTR [rsp+0x5f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 95ULL);
x86_l_6cc2:
	/* 0x6cc2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6cc9:
	/* 0x6cc9: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6ccc:
	/* 0x6ccc: jne    706c <kprobe_unwind_dotnet+0x706c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ccc, 0x706c, x86_l_706c);
x86_l_6cd2:
	/* 0x6cd2: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6cd5:
	/* 0x6cd5: jb     70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6cd5, 0x70d1, x86_l_70d1);
x86_l_6cdb:
	/* 0x6cdb: lea    rax,[rbx+0x2000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8192ULL);
x86_l_6ce2:
	/* 0x6ce2: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ce5:
	/* 0x6ce5: jae    70d1 <kprobe_unwind_dotnet+0x70d1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6ce5, 0x70d1, x86_l_70d1);
x86_l_6ceb:
	/* 0x6ceb: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6cf2:
	/* 0x6cf2: mov    r15,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_6cf9:
	/* 0x6cf9: mov    QWORD PTR [rsp+0x68],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6cfe:
	/* 0x6cfe: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_6d06:
	/* 0x6d06: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_6d09:
	/* 0x6d09: and    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551488ULL);
x86_l_6d0d:
	/* 0x6d0d: cmp    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 128ULL);
x86_l_6d13:
	/* 0x6d13: jne    6d47 <kprobe_unwind_dotnet+0x6d47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d13, 0x6d47, x86_l_6d47);
x86_l_6d15:
	/* 0x6d15: mov    rdx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_6d1c:
	/* 0x6d1c: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_6d24:
	/* 0x6d24: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6d29:
	/* 0x6d29: call   6d2e <kprobe_unwind_dotnet+0x6d2e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6d2e:
	/* 0x6d2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d31:
	/* 0x6d31: jne    180 <kprobe_unwind_dotnet+0x180> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d31, 0x180, x86_l_180);
x86_l_6d37:
	/* 0x6d37: add    QWORD PTR [r14+0xed8],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16320875724808ULL);
x86_l_6d3f:
	/* 0x6d3f: and    ebp,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_6d42:
	/* 0x6d42: jmp    7e76 <kprobe_unwind_dotnet+0x7e76> */
	X86_SIM_X86_JMP(0x6d42, 0x7e76, x86_l_7e76);
x86_l_6d47:
	/* 0x6d47: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6d4c:
	/* 0x6d4c: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_6d51:
	/* 0x6d51: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6d54:
	/* 0x6d54: call   6d59 <kprobe_unwind_dotnet+0x6d59> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6d59:
	/* 0x6d59: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d5c:
	/* 0x6d5c: jne    1c6 <kprobe_unwind_dotnet+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d5c, 0x1c6, x86_l_1c6);
x86_l_6d62:
	/* 0x6d62: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6d66:
	/* 0x6d66: mov    QWORD PTR [r14+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_6d6d:
	/* 0x6d6d: mov    r8,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6d72:
	/* 0x6d72: mov    QWORD PTR [r14+0xee0],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_6d79:
	/* 0x6d79: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_6d7e:
	/* 0x6d7e: mov    QWORD PTR [r14+0xed0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_6d85:
	/* 0x6d85: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6d8c:
	/* 0x6d8c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d8f:
	/* 0x6d8f: jne    74b7 <kprobe_unwind_dotnet+0x74b7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d8f, 0x74b7, x86_l_74b7);
x86_l_6d95:
	/* 0x6d95: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_6d9c:
	/* 0x6d9c: jb     7e76 <kprobe_unwind_dotnet+0x7e76> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6d9c, 0x7e76, x86_l_7e76);
x86_l_6da2:
	/* 0x6da2: mov    r15,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6da9:
	/* 0x6da9: mov    rbp,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_6db0:
	/* 0x6db0: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6db3:
	/* 0x6db3: sub    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_6db6:
	/* 0x6db6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6dbd:
	/* 0x6dbd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6dc0:
	/* 0x6dc0: jne    751f <kprobe_unwind_dotnet+0x751f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6dc0, 0x751f, x86_l_751f);
x86_l_6dc6:
	/* 0x6dc6: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6dc9:
	/* 0x6dc9: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_6dcd:
	/* 0x6dcd: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_6dd2:
	/* 0x6dd2: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_6dd4:
	/* 0x6dd4: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_6dd7:
	/* 0x6dd7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6dd9:
	/* 0x6dd9: cmp    r13,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 32768ULL);
x86_l_6de0:
	/* 0x6de0: lea    rdx,[rax*4-0x3fc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 18446744073709550596ULL);
x86_l_6de8:
	/* 0x6de8: cmovb  rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_6dec:
	/* 0x6dec: cmovae ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_6def:
	/* 0x6def: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6df2:
	/* 0x6df2: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_6dfa:
	/* 0x6dfa: lea    rdi,[rax+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_6dfe:
	/* 0x6dfe: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_6e03:
	/* 0x6e03: call   6e08 <kprobe_unwind_dotnet+0x6e08> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6e08:
	/* 0x6e08: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e0b:
	/* 0x6e0b: je     6e40 <kprobe_unwind_dotnet+0x6e40> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e0b, 0x6e40, x86_l_6e40);
x86_l_6e0d:
	/* 0x6e0d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6e14:
	/* 0x6e14: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e17:
	/* 0x6e17: jne    6fff <kprobe_unwind_dotnet+0x6fff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e17, 0x6fff, x86_l_6fff);
x86_l_6e1d:
	/* 0x6e1d: mov    DWORD PTR [rsp+0xc],0x5e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607646ULL);
x86_l_6e25:
	/* 0x6e25: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_6e2c:
	/* 0x6e2c: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6e31:
	/* 0x6e31: call   6e36 <kprobe_unwind_dotnet+0x6e36> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6e36:
	/* 0x6e36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e39:
	/* 0x6e39: je     6e97 <kprobe_unwind_dotnet+0x6e97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e39, 0x6e97, x86_l_6e97);
x86_l_6e3b:
	/* 0x6e3b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6e3e:
	/* 0x6e3e: jmp    6ea7 <kprobe_unwind_dotnet+0x6ea7> */
	X86_SIM_X86_JMP(0x6e3e, 0x6ea7, x86_l_6ea7);
x86_l_6e40:
	/* 0x6e40: mov    r15d,DWORD PTR [r14+0x117c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4476ULL);
x86_l_6e47:
	/* 0x6e47: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6e4e:
	/* 0x6e4e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e51:
	/* 0x6e51: jne    7558 <kprobe_unwind_dotnet+0x7558> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e51, 0x7558, x86_l_7558);
x86_l_6e57:
	/* 0x6e57: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_6e5a:
	/* 0x6e5a: not    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_6e5c:
	/* 0x6e5c: shr    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 3ULL);
x86_l_6e5f:
	/* 0x6e5f: and    al,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 28ULL);
x86_l_6e61:
	/* 0x6e61: shrx   r15d,r15d,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R15, X86_R15, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_6e66:
	/* 0x6e66: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6e69:
	/* 0x6e69: je     6f34 <kprobe_unwind_dotnet+0x6f34> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e69, 0x6f34, x86_l_6f34);
x86_l_6e6f:
	/* 0x6e6f: and    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551584ULL);
x86_l_6e73:
	/* 0x6e73: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6e76:
	/* 0x6e76: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_6e79:
	/* 0x6e79: jne    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e79, 0x7e30, x86_l_7e30);
x86_l_6e7f:
	/* 0x6e7f: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6e82:
	/* 0x6e82: shr    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 4ULL);
x86_l_6e85:
	/* 0x6e85: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_6e88:
	/* 0x6e88: je     7040 <kprobe_unwind_dotnet+0x7040> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e88, 0x7040, x86_l_7040);
x86_l_6e8e:
	/* 0x6e8e: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_6e92:
	/* 0x6e92: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x6e92, 0x7e30, x86_l_7e30);
x86_l_6e97:
	/* 0x6e97: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6e9e:
	/* 0x6e9e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6ea1:
	/* 0x6ea1: jne    75e2 <kprobe_unwind_dotnet+0x75e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ea1, 0x75e2, x86_l_75e2);
x86_l_6ea7:
	/* 0x6ea7: mov    edx,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_6eac:
	/* 0x6eac: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6eae:
	/* 0x6eae: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6eb5:
	/* 0x6eb5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6eb8:
	/* 0x6eb8: jne    7ce8 <kprobe_unwind_dotnet+0x7ce8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6eb8, 0x7ce8, x86_l_7ce8);
x86_l_6ebe:
	/* 0x6ebe: mov    eax,0x1772 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6002ULL);
x86_l_6ec3:
	/* 0x6ec3: test   bl,bl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_8, 0, 0);
x86_l_6ec5:
	/* 0x6ec5: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_6eca:
	/* 0x6eca: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6ed1:
	/* 0x6ed1: je     7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ed1, 0x7126, x86_l_7126);
x86_l_6ed7:
	/* 0x6ed7: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6ede:
	/* 0x6ede: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_6ee2:
	/* 0x6ee2: ja     41a <kprobe_unwind_dotnet+0x41a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6ee2, 0x41a, x86_l_41a);
x86_l_6ee8:
	/* 0x6ee8: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_6eeb:
	/* 0x6eeb: mov    DWORD PTR [r14+0x2c0],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6ef2:
	/* 0x6ef2: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_6ef6:
	/* 0x6ef6: mov    QWORD PTR [r14+rax*8+0x2d0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3092376453120ULL);
x86_l_6f02:
	/* 0x6f02: mov    QWORD PTR [r14+rax*8+0x2d8],0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 3126736197491ULL);
x86_l_6f0e:
	/* 0x6f0e: mov    BYTE PTR [r14+rax*8+0x2e0],0x8a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929994ULL);
x86_l_6f17:
	/* 0x6f17: mov    DWORD PTR [r14+rax*8+0x2e1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3165390897152ULL);
x86_l_6f23:
	/* 0x6f23: mov    DWORD PTR [r14+rax*8+0x2e4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3178275799040ULL);
x86_l_6f2f:
	/* 0x6f2f: jmp    7f24 <kprobe_unwind_dotnet+0x7f24> */
	X86_SIM_X86_JMP(0x6f2f, 0x7f24, x86_l_7f24);
x86_l_6f34:
	/* 0x6f34: and    r13,0xffffffffffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551360ULL);
x86_l_6f3b:
	/* 0x6f3b: add    r13,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_6f3f:
	/* 0x6f3f: mov    r15d,DWORD PTR [r14+0x1178] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4472ULL);
x86_l_6f46:
	/* 0x6f46: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6f4d:
	/* 0x6f4d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f50:
	/* 0x6f50: jne    7659 <kprobe_unwind_dotnet+0x7659> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6f50, 0x7659, x86_l_7659);
x86_l_6f56:
	/* 0x6f56: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f58:
	/* 0x6f58: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6f5b:
	/* 0x6f5b: je     76e5 <kprobe_unwind_dotnet+0x76e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f5b, 0x76e5, x86_l_76e5);
x86_l_6f61:
	/* 0x6f61: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6f63:
	/* 0x6f63: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_6f66:
	/* 0x6f66: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_6f69:
	/* 0x6f69: jae    7c14 <kprobe_unwind_dotnet+0x7c14> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6f69, 0x7c14, x86_l_7c14);
x86_l_6f6f:
	/* 0x6f6f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6f76:
	/* 0x6f76: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f79:
	/* 0x6f79: je     6e1d <kprobe_unwind_dotnet+0x6e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f79, 0x6e1d, x86_l_6e1d);
x86_l_6f7f:
	/* 0x6f7f: movabs rax,0xa657361625f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926295996587875ULL);
x86_l_6f89:
	/* 0x6f89: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_6f8e:
	/* 0x6f8e: movabs rax,0x5f637020776f6c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460741042564197ULL);
x86_l_6f98:
	/* 0x6f98: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f9d:
	/* 0x6f9d: movabs rax,0x6220746e65772068 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070779432469209192ULL);
x86_l_6fa7:
	/* 0x6fa7: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6fac:
	/* 0x6fac: movabs rax,0x6372616573207061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165897045450977377ULL);
x86_l_6fb6:
	/* 0x6fb6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6fbb:
	/* 0x6fbb: movabs rax,0x6d20656c6262696e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7863396465570376046ULL);
x86_l_6fc5:
	/* 0x6fc5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6fca:
	/* 0x6fca: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_6fd4:
	/* 0x6fd4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6fd9:
	/* 0x6fd9: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6fde:
	/* 0x6fde: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_6fe3:
	/* 0x6fe3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6fe5:
	/* 0x6fe5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6fe7:
	/* 0x6fe7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6fea:
	/* 0x6fea: call   6fef <kprobe_unwind_dotnet+0x6fef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6fef:
	/* 0x6fef: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6ff6:
	/* 0x6ff6: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6ff9:
	/* 0x6ff9: je     6e1d <kprobe_unwind_dotnet+0x6e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ff9, 0x6e1d, x86_l_6e1d);
x86_l_6fff:
	/* 0x6fff: movabs rax,0x6e756f6620746f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959390400869068654ULL);
x86_l_7009:
	/* 0x7009: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_700e:
	/* 0x700e: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_7018:
	/* 0x7018: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_701d:
	/* 0x701d: mov    DWORD PTR [rsp+0x1f],0xa646e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 133144667246ULL);
x86_l_7025:
	/* 0x7025: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_702a:
	/* 0x702a: mov    esi,0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_702f:
	/* 0x702f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7031:
	/* 0x7031: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7033:
	/* 0x7033: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7036:
	/* 0x7036: call   703b <kprobe_unwind_dotnet+0x703b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_703b:
	/* 0x703b: jmp    6e1d <kprobe_unwind_dotnet+0x6e1d> */
	X86_SIM_X86_JMP(0x703b, 0x6e1d, x86_l_6e1d);
x86_l_7040:
	/* 0x7040: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7043:
	/* 0x7043: shr    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_7046:
	/* 0x7046: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7049:
	/* 0x7049: je     7054 <kprobe_unwind_dotnet+0x7054> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7049, 0x7054, x86_l_7054);
x86_l_704b:
	/* 0x704b: add    r13,0xffffffffffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551552ULL);
x86_l_704f:
	/* 0x704f: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x704f, 0x7e30, x86_l_7e30);
x86_l_7054:
	/* 0x7054: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7057:
	/* 0x7057: shr    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_705a:
	/* 0x705a: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_705d:
	/* 0x705d: je     7d4c <kprobe_unwind_dotnet+0x7d4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x705d, 0x7d4c, x86_l_7d4c);
x86_l_7063:
	/* 0x7063: add    r13,0xffffffffffffffa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551520ULL);
x86_l_7067:
	/* 0x7067: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x7067, 0x7e30, x86_l_7e30);
x86_l_706c:
	/* 0x706c: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_7076:
	/* 0x7076: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_707b:
	/* 0x707b: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_7085:
	/* 0x7085: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_708a:
	/* 0x708a: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_7094:
	/* 0x7094: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7099:
	/* 0x7099: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_70a3:
	/* 0x70a3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_70a8:
	/* 0x70a8: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_70b0:
	/* 0x70b0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_70b5:
	/* 0x70b5: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_70ba:
	/* 0x70ba: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_70bd:
	/* 0x70bd: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_70c0:
	/* 0x70c0: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_70c3:
	/* 0x70c3: call   70c8 <kprobe_unwind_dotnet+0x70c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_70c8:
	/* 0x70c8: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_70cb:
	/* 0x70cb: jae    6cdb <kprobe_unwind_dotnet+0x6cdb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x70cb, 0x6cdb, x86_l_6cdb);
x86_l_70d1:
	/* 0x70d1: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_70d6:
	/* 0x70d6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_70dd:
	/* 0x70dd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_70e0:
	/* 0x70e0: jne    7264 <kprobe_unwind_dotnet+0x7264> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70e0, 0x7264, x86_l_7264);
x86_l_70e6:
	/* 0x70e6: mov    DWORD PTR [rsp+0x68],0x5d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598877ULL);
x86_l_70ee:
	/* 0x70ee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_70f5:
	/* 0x70f5: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_70fa:
	/* 0x70fa: call   70ff <kprobe_unwind_dotnet+0x70ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_70ff:
	/* 0x70ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7102:
	/* 0x7102: je     7110 <kprobe_unwind_dotnet+0x7110> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7102, 0x7110, x86_l_7110);
x86_l_7104:
	/* 0x7104: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7107:
	/* 0x7107: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_710e:
	/* 0x710e: jmp    7121 <kprobe_unwind_dotnet+0x7121> */
	X86_SIM_X86_JMP(0x710e, 0x7121, x86_l_7121);
x86_l_7110:
	/* 0x7110: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7117:
	/* 0x7117: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_711b:
	/* 0x711b: jne    72db <kprobe_unwind_dotnet+0x72db> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x711b, 0x72db, x86_l_72db);
x86_l_7121:
	/* 0x7121: mov    eax,0x1771 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6001ULL);
x86_l_7126:
	/* 0x7126: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7129:
	/* 0x7129: mov    DWORD PTR [r14+0xf2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3884ULL);
x86_l_7130:
	/* 0x7130: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_7138:
	/* 0x7138: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_713f:
	/* 0x713f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7144:
	/* 0x7144: call   7149 <kprobe_unwind_dotnet+0x7149> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7149:
	/* 0x7149: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_714c:
	/* 0x714c: je     718d <kprobe_unwind_dotnet+0x718d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x714c, 0x718d, x86_l_718d);
x86_l_714e:
	/* 0x714e: movzx  ecx,BYTE PTR [rax+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_7155:
	/* 0x7155: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_7158:
	/* 0x7158: cmp    cl,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 29ULL);
x86_l_715b:
	/* 0x715b: jb     71a7 <kprobe_unwind_dotnet+0x71a7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x715b, 0x71a7, x86_l_71a7);
x86_l_715d:
	/* 0x715d: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7160:
	/* 0x7160: mov    DWORD PTR [rax+0xf2c],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16681652977669ULL);
x86_l_716a:
	/* 0x716a: mov    DWORD PTR [rsp+0x70],0x44 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337220ULL);
x86_l_7172:
	/* 0x7172: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_7179:
	/* 0x7179: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_717e:
	/* 0x717e: call   7183 <kprobe_unwind_dotnet+0x7183> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7183:
	/* 0x7183: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7186:
	/* 0x7186: je     7191 <kprobe_unwind_dotnet+0x7191> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7186, 0x7191, x86_l_7191);
x86_l_7188:
	/* 0x7188: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_718b:
	/* 0x718b: jmp    719b <kprobe_unwind_dotnet+0x719b> */
	X86_SIM_X86_JMP(0x718b, 0x719b, x86_l_719b);
x86_l_718d:
	/* 0x718d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_718f:
	/* 0x718f: jmp    71af <kprobe_unwind_dotnet+0x71af> */
	X86_SIM_X86_JMP(0x718f, 0x71af, x86_l_71af);
x86_l_7191:
	/* 0x7191: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7195:
	/* 0x7195: jne    7352 <kprobe_unwind_dotnet+0x7352> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7195, 0x7352, x86_l_7352);
x86_l_719b:
	/* 0x719b: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_719e:
	/* 0x719e: movzx  ecx,BYTE PTR [rbx+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_71a5:
	/* 0x71a5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71a7:
	/* 0x71a7: inc    cl */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_71a9:
	/* 0x71a9: mov    BYTE PTR [rax+0x1384],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4996ULL);
x86_l_71af:
	/* 0x71af: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)perf_progs));
x86_l_71b6:
	/* 0x71b6: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_71b9:
	/* 0x71b9: call   71be <kprobe_unwind_dotnet+0x71be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_71be:
	/* 0x71be: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_71c2:
	/* 0x71c2: jne    71df <kprobe_unwind_dotnet+0x71df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x71c2, 0x71df, x86_l_71df);
x86_l_71c4:
	/* 0x71c4: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_71c9:
	/* 0x71c9: add    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_71d0:
	/* 0x71d0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71d1:
	/* 0x71d1: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71d3:
	/* 0x71d3: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71d5:
	/* 0x71d5: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71d7:
	/* 0x71d7: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71d9:
	/* 0x71d9: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_71da:
	/* 0x71da: jmp    85fa <.L__const.unwind_one_dotnet_frame.____fmt.9+0x85aa> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_71df:
	/* 0x71df: movabs rax,0xa64656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2925136540426598ULL);
x86_l_71e9:
	/* 0x71e9: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_71ee:
	/* 0x71ee: movabs rax,0x6620296425282072 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358927301220245618ULL);
x86_l_71f8:
	/* 0x71f8: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_71fd:
	/* 0x71fd: movabs rax,0x65646e69776e7520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7306085894756136224ULL);
x86_l_7207:
	/* 0x7207: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_720c:
	/* 0x720c: movabs rax,0x656d617266207478 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7308604914259752056ULL);
x86_l_7216:
	/* 0x7216: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_721b:
	/* 0x721b: movabs rax,0x656e20726f66206c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7308814921136218220ULL);
x86_l_7225:
	/* 0x7225: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_722a:
	/* 0x722a: movabs rax,0x6c6163206c696174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809632219746099572ULL);
x86_l_7234:
	/* 0x7234: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7239:
	/* 0x7239: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_7243:
	/* 0x7243: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7248:
	/* 0x7248: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_724b:
	/* 0x724b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7250:
	/* 0x7250: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_7255:
	/* 0x7255: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7257:
	/* 0x7257: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_725a:
	/* 0x725a: call   725f <kprobe_unwind_dotnet+0x725f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_725f:
	/* 0x725f: jmp    71c4 <kprobe_unwind_dotnet+0x71c4> */
	X86_SIM_X86_JMP(0x725f, 0x71c4, x86_l_71c4);
x86_l_7264:
	/* 0x7264: movabs rax,0xa786c25202f20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155641773856ULL);
x86_l_726e:
	/* 0x726e: mov    QWORD PTR [rsp+0x35],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_7273:
	/* 0x7273: movabs rax,0x202f20786c252066 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2319108034701631590ULL);
x86_l_727d:
	/* 0x727d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7282:
	/* 0x7282: movabs rax,0x666f20726166206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7381153989915975791ULL);
x86_l_728c:
	/* 0x728c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7291:
	/* 0x7291: movabs rax,0x6f74207265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079711208926825ULL);
x86_l_729b:
	/* 0x729b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_72a0:
	/* 0x72a0: movabs rax,0x6f7020656d617266 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8029953755600482918ULL);
x86_l_72aa:
	/* 0x72aa: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_72af:
	/* 0x72af: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_72b9:
	/* 0x72b9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72be:
	/* 0x72be: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72c3:
	/* 0x72c3: mov    esi,0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 45ULL);
x86_l_72c8:
	/* 0x72c8: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_72cb:
	/* 0x72cb: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_72ce:
	/* 0x72ce: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_72d1:
	/* 0x72d1: call   72d6 <kprobe_unwind_dotnet+0x72d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_72d6:
	/* 0x72d6: jmp    70e6 <kprobe_unwind_dotnet+0x70e6> */
	X86_SIM_X86_JMP(0x72d6, 0x70e6, x86_l_70e6);
x86_l_72db:
	/* 0x72db: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_72e5:
	/* 0x72e5: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_72ea:
	/* 0x72ea: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_72f4:
	/* 0x72f4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_72f9:
	/* 0x72f9: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_7303:
	/* 0x7303: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7308:
	/* 0x7308: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7312:
	/* 0x7312: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7317:
	/* 0x7317: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7321:
	/* 0x7321: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7326:
	/* 0x7326: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_7330:
	/* 0x7330: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7335:
	/* 0x7335: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7339:
	/* 0x7339: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_733e:
	/* 0x733e: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_7343:
	/* 0x7343: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7345:
	/* 0x7345: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7348:
	/* 0x7348: call   734d <kprobe_unwind_dotnet+0x734d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_734d:
	/* 0x734d: jmp    7121 <kprobe_unwind_dotnet+0x7121> */
	X86_SIM_X86_JMP(0x734d, 0x7121, x86_l_7121);
x86_l_7352:
	/* 0x7352: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_735c:
	/* 0x735c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7361:
	/* 0x7361: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_736b:
	/* 0x736b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7370:
	/* 0x7370: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_737a:
	/* 0x737a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_737f:
	/* 0x737f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7389:
	/* 0x7389: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_738e:
	/* 0x738e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7398:
	/* 0x7398: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_739d:
	/* 0x739d: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_73a7:
	/* 0x73a7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_73ac:
	/* 0x73ac: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_73b0:
	/* 0x73b0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_73b5:
	/* 0x73b5: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_73ba:
	/* 0x73ba: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_73bc:
	/* 0x73bc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_73bf:
	/* 0x73bf: call   73c4 <kprobe_unwind_dotnet+0x73c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_73c4:
	/* 0x73c4: jmp    719b <kprobe_unwind_dotnet+0x719b> */
	X86_SIM_X86_JMP(0x73c4, 0x719b, x86_l_719b);
x86_l_73c9:
	/* 0x73c9: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_73d3:
	/* 0x73d3: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_73d8:
	/* 0x73d8: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_73e2:
	/* 0x73e2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_73e7:
	/* 0x73e7: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_73f1:
	/* 0x73f1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_73f6:
	/* 0x73f6: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7400:
	/* 0x7400: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7405:
	/* 0x7405: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_740f:
	/* 0x740f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7414:
	/* 0x7414: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_741e:
	/* 0x741e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7423:
	/* 0x7423: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7427:
	/* 0x7427: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_742c:
	/* 0x742c: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_7431:
	/* 0x7431: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7433:
	/* 0x7433: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7436:
	/* 0x7436: call   743b <kprobe_unwind_dotnet+0x743b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_743b:
	/* 0x743b: jmp    66ce <kprobe_unwind_dotnet+0x66ce> */
	X86_SIM_X86_JMP(0x743b, 0x66ce, x86_l_66ce);
x86_l_7440:
	/* 0x7440: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_744a:
	/* 0x744a: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_744f:
	/* 0x744f: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_7459:
	/* 0x7459: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_745e:
	/* 0x745e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_7468:
	/* 0x7468: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_746d:
	/* 0x746d: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7477:
	/* 0x7477: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_747c:
	/* 0x747c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7486:
	/* 0x7486: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_748b:
	/* 0x748b: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_7495:
	/* 0x7495: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_749a:
	/* 0x749a: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_749e:
	/* 0x749e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_74a3:
	/* 0x74a3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_74a8:
	/* 0x74a8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_74aa:
	/* 0x74aa: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_74ad:
	/* 0x74ad: call   74b2 <kprobe_unwind_dotnet+0x74b2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_74b2:
	/* 0x74b2: jmp    6c92 <kprobe_unwind_dotnet+0x6c92> */
	X86_SIM_X86_JMP(0x74b2, 0x6c92, x86_l_6c92);
x86_l_74b7:
	/* 0x74b7: movabs rax,0x6c25203a7066202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165600444460ULL);
x86_l_74c1:
	/* 0x74c1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_74c6:
	/* 0x74c6: movabs rax,0x786c25203a707320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351402385732384ULL);
x86_l_74d0:
	/* 0x74d0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_74d5:
	/* 0x74d5: movabs rax,0x2c786c25203a6370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 3204430041584395120ULL);
x86_l_74df:
	/* 0x74df: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_74e4:
	/* 0x74e4: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_74ee:
	/* 0x74ee: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_74f3:
	/* 0x74f3: mov    DWORD PTR [rsp+0x2f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 201864149100ULL);
x86_l_74fb:
	/* 0x74fb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7500:
	/* 0x7500: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_7505:
	/* 0x7505: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7508:
	/* 0x7508: call   750d <kprobe_unwind_dotnet+0x750d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_750d:
	/* 0x750d: cmp    rbp,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_7514:
	/* 0x7514: jae    6da2 <kprobe_unwind_dotnet+0x6da2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7514, 0x6da2, x86_l_6da2);
x86_l_751a:
	/* 0x751a: jmp    7e76 <kprobe_unwind_dotnet+0x7e76> */
	X86_SIM_X86_JMP(0x751a, 0x7e76, x86_l_7e76);
x86_l_751f:
	/* 0x751f: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_7526:
	/* 0x7526: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_752b:
	/* 0x752b: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_7530:
	/* 0x7530: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7533:
	/* 0x7533: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_7536:
	/* 0x7536: mov    WORD PTR [rsp+0x50],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597383690ULL);
x86_l_753d:
	/* 0x753d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7540:
	/* 0x7540: mov    esi,0x42 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 66ULL);
x86_l_7545:
	/* 0x7545: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7548:
	/* 0x7548: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_754b:
	/* 0x754b: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_754e:
	/* 0x754e: call   7553 <kprobe_unwind_dotnet+0x7553> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_7553:
	/* 0x7553: jmp    6dc6 <kprobe_unwind_dotnet+0x6dc6> */
	X86_SIM_X86_JMP(0x7553, 0x6dc6, x86_l_6dc6);
x86_l_7558:
	/* 0x7558: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_755b:
	/* 0x755b: and    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709551612ULL);
x86_l_755f:
	/* 0x755f: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_7569:
	/* 0x7569: mov    QWORD PTR [rsp+0x3e],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_756e:
	/* 0x756e: movabs rax,0x72746e6520747372 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8247338198237475698ULL);
x86_l_7578:
	/* 0x7578: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_757d:
	/* 0x757d: movabs rax,0x6966203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7594793257107465504ULL);
x86_l_7587:
	/* 0x7587: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_758c:
	/* 0x758c: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_7596:
	/* 0x7596: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_759b:
	/* 0x759b: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_75a5:
	/* 0x75a5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_75aa:
	/* 0x75aa: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_75b4:
	/* 0x75b4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_75b9:
	/* 0x75b9: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_75c3:
	/* 0x75c3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75c8:
	/* 0x75c8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75cd:
	/* 0x75cd: mov    esi,0x36 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 54ULL);
x86_l_75d2:
	/* 0x75d2: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_75d5:
	/* 0x75d5: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_75d8:
	/* 0x75d8: call   75dd <kprobe_unwind_dotnet+0x75dd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_75dd:
	/* 0x75dd: jmp    6e57 <kprobe_unwind_dotnet+0x6e57> */
	X86_SIM_X86_JMP(0x75dd, 0x6e57, x86_l_6e57);
x86_l_75e2:
	/* 0x75e2: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_75ec:
	/* 0x75ec: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_75f1:
	/* 0x75f1: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_75fb:
	/* 0x75fb: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7600:
	/* 0x7600: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_760a:
	/* 0x760a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_760f:
	/* 0x760f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7619:
	/* 0x7619: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_761e:
	/* 0x761e: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7628:
	/* 0x7628: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_762d:
	/* 0x762d: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_7637:
	/* 0x7637: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_763c:
	/* 0x763c: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7640:
	/* 0x7640: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7645:
	/* 0x7645: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_764a:
	/* 0x764a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_764c:
	/* 0x764c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_764f:
	/* 0x764f: call   7654 <kprobe_unwind_dotnet+0x7654> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_7654:
	/* 0x7654: jmp    6ea7 <kprobe_unwind_dotnet+0x6ea7> */
	X86_SIM_X86_JMP(0x7654, 0x6ea7, x86_l_6ea7);
x86_l_7659:
	/* 0x7659: movabs rax,0xa782520797274 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2946850621059700ULL);
x86_l_7663:
	/* 0x7663: mov    QWORD PTR [rsp+0x3f],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 63ULL);
x86_l_7668:
	/* 0x7668: movabs rax,0x746e6520646e6f63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389754345636130659ULL);
x86_l_7672:
	/* 0x7672: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7677:
	/* 0x7677: movabs rax,0x6573203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222055652992288ULL);
x86_l_7681:
	/* 0x7681: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7686:
	/* 0x7686: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_7690:
	/* 0x7690: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7695:
	/* 0x7695: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_769f:
	/* 0x769f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_76a4:
	/* 0x76a4: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_76ae:
	/* 0x76ae: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_76b3:
	/* 0x76b3: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_76bd:
	/* 0x76bd: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76c2:
	/* 0x76c2: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76c7:
	/* 0x76c7: mov    esi,0x37 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_76cc:
	/* 0x76cc: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_76cf:
	/* 0x76cf: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_76d2:
	/* 0x76d2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_76d5:
	/* 0x76d5: call   76da <kprobe_unwind_dotnet+0x76da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_76da:
	/* 0x76da: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_76dc:
	/* 0x76dc: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_76df:
	/* 0x76df: jne    6f61 <kprobe_unwind_dotnet+0x6f61> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x76df, 0x6f61, x86_l_6f61);
x86_l_76e5:
	/* 0x76e5: mov    rax,QWORD PTR [r14+0x1170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4464ULL);
x86_l_76ec:
	/* 0x76ec: mov    ecx,0xffffff84 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967172ULL);
x86_l_76f1:
	/* 0x76f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_76f4:
	/* 0x76f4: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x76f4, 0x7bec, x86_l_7bec);
x86_l_76fa:
	/* 0x76fa: mov    rax,QWORD PTR [r14+0x1168] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4456ULL);
x86_l_7701:
	/* 0x7701: mov    ecx,0xffffff86 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967174ULL);
x86_l_7706:
	/* 0x7706: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7709:
	/* 0x7709: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7709, 0x7bec, x86_l_7bec);
x86_l_770f:
	/* 0x770f: mov    rax,QWORD PTR [r14+0x1160] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4448ULL);
x86_l_7716:
	/* 0x7716: mov    ecx,0xffffff88 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967176ULL);
x86_l_771b:
	/* 0x771b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_771e:
	/* 0x771e: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x771e, 0x7bec, x86_l_7bec);
x86_l_7724:
	/* 0x7724: mov    rax,QWORD PTR [r14+0x1158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4440ULL);
x86_l_772b:
	/* 0x772b: mov    ecx,0xffffff8a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967178ULL);
x86_l_7730:
	/* 0x7730: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7733:
	/* 0x7733: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7733, 0x7bec, x86_l_7bec);
x86_l_7739:
	/* 0x7739: mov    rax,QWORD PTR [r14+0x1150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4432ULL);
x86_l_7740:
	/* 0x7740: mov    ecx,0xffffff8c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967180ULL);
x86_l_7745:
	/* 0x7745: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7748:
	/* 0x7748: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7748, 0x7bec, x86_l_7bec);
x86_l_774e:
	/* 0x774e: mov    rax,QWORD PTR [r14+0x1148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4424ULL);
x86_l_7755:
	/* 0x7755: mov    ecx,0xffffff8e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967182ULL);
x86_l_775a:
	/* 0x775a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_775d:
	/* 0x775d: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x775d, 0x7bec, x86_l_7bec);
x86_l_7763:
	/* 0x7763: mov    rax,QWORD PTR [r14+0x1140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4416ULL);
x86_l_776a:
	/* 0x776a: mov    ecx,0xffffff90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967184ULL);
x86_l_776f:
	/* 0x776f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7772:
	/* 0x7772: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7772, 0x7bec, x86_l_7bec);
x86_l_7778:
	/* 0x7778: mov    rax,QWORD PTR [r14+0x1138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4408ULL);
x86_l_777f:
	/* 0x777f: mov    ecx,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_7784:
	/* 0x7784: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7787:
	/* 0x7787: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7787, 0x7bec, x86_l_7bec);
x86_l_778d:
	/* 0x778d: mov    rax,QWORD PTR [r14+0x1130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4400ULL);
x86_l_7794:
	/* 0x7794: mov    ecx,0xffffff94 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967188ULL);
x86_l_7799:
	/* 0x7799: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_779c:
	/* 0x779c: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x779c, 0x7bec, x86_l_7bec);
x86_l_77a2:
	/* 0x77a2: mov    rax,QWORD PTR [r14+0x1128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4392ULL);
x86_l_77a9:
	/* 0x77a9: mov    ecx,0xffffff96 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967190ULL);
x86_l_77ae:
	/* 0x77ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77b1:
	/* 0x77b1: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77b1, 0x7bec, x86_l_7bec);
x86_l_77b7:
	/* 0x77b7: mov    rax,QWORD PTR [r14+0x1120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4384ULL);
x86_l_77be:
	/* 0x77be: mov    ecx,0xffffff98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967192ULL);
x86_l_77c3:
	/* 0x77c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77c6:
	/* 0x77c6: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77c6, 0x7bec, x86_l_7bec);
x86_l_77cc:
	/* 0x77cc: mov    rax,QWORD PTR [r14+0x1118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4376ULL);
x86_l_77d3:
	/* 0x77d3: mov    ecx,0xffffff9a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967194ULL);
x86_l_77d8:
	/* 0x77d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77db:
	/* 0x77db: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77db, 0x7bec, x86_l_7bec);
x86_l_77e1:
	/* 0x77e1: mov    rax,QWORD PTR [r14+0x1110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4368ULL);
x86_l_77e8:
	/* 0x77e8: mov    ecx,0xffffff9c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967196ULL);
x86_l_77ed:
	/* 0x77ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77f0:
	/* 0x77f0: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77f0, 0x7bec, x86_l_7bec);
x86_l_77f6:
	/* 0x77f6: mov    rax,QWORD PTR [r14+0x1108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4360ULL);
x86_l_77fd:
	/* 0x77fd: mov    ecx,0xffffff9e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967198ULL);
x86_l_7802:
	/* 0x7802: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7805:
	/* 0x7805: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7805, 0x7bec, x86_l_7bec);
x86_l_780b:
	/* 0x780b: mov    rax,QWORD PTR [r14+0x1100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4352ULL);
x86_l_7812:
	/* 0x7812: mov    ecx,0xffffffa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967200ULL);
x86_l_7817:
	/* 0x7817: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_781a:
	/* 0x781a: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x781a, 0x7bec, x86_l_7bec);
x86_l_7820:
	/* 0x7820: mov    rax,QWORD PTR [r14+0x10f8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4344ULL);
x86_l_7827:
	/* 0x7827: mov    ecx,0xffffffa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967202ULL);
x86_l_782c:
	/* 0x782c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_782f:
	/* 0x782f: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x782f, 0x7bec, x86_l_7bec);
x86_l_7835:
	/* 0x7835: mov    rax,QWORD PTR [r14+0x10f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4336ULL);
x86_l_783c:
	/* 0x783c: mov    ecx,0xffffffa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967204ULL);
x86_l_7841:
	/* 0x7841: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7844:
	/* 0x7844: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7844, 0x7bec, x86_l_7bec);
x86_l_784a:
	/* 0x784a: mov    rax,QWORD PTR [r14+0x10e8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4328ULL);
x86_l_7851:
	/* 0x7851: mov    ecx,0xffffffa6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967206ULL);
x86_l_7856:
	/* 0x7856: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7859:
	/* 0x7859: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7859, 0x7bec, x86_l_7bec);
x86_l_785f:
	/* 0x785f: mov    rax,QWORD PTR [r14+0x10e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4320ULL);
x86_l_7866:
	/* 0x7866: mov    ecx,0xffffffa8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967208ULL);
x86_l_786b:
	/* 0x786b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_786e:
	/* 0x786e: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x786e, 0x7bec, x86_l_7bec);
x86_l_7874:
	/* 0x7874: mov    rax,QWORD PTR [r14+0x10d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4312ULL);
x86_l_787b:
	/* 0x787b: mov    ecx,0xffffffaa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967210ULL);
x86_l_7880:
	/* 0x7880: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7883:
	/* 0x7883: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7883, 0x7bec, x86_l_7bec);
x86_l_7889:
	/* 0x7889: mov    rax,QWORD PTR [r14+0x10d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4304ULL);
x86_l_7890:
	/* 0x7890: mov    ecx,0xffffffac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967212ULL);
x86_l_7895:
	/* 0x7895: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7898:
	/* 0x7898: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7898, 0x7bec, x86_l_7bec);
x86_l_789e:
	/* 0x789e: mov    rax,QWORD PTR [r14+0x10c8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4296ULL);
x86_l_78a5:
	/* 0x78a5: mov    ecx,0xffffffae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967214ULL);
x86_l_78aa:
	/* 0x78aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_78ad:
	/* 0x78ad: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78ad, 0x7bec, x86_l_7bec);
x86_l_78b3:
	/* 0x78b3: mov    rax,QWORD PTR [r14+0x10c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4288ULL);
x86_l_78ba:
	/* 0x78ba: mov    ecx,0xffffffb0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967216ULL);
x86_l_78bf:
	/* 0x78bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_78c2:
	/* 0x78c2: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78c2, 0x7bec, x86_l_7bec);
x86_l_78c8:
	/* 0x78c8: mov    rax,QWORD PTR [r14+0x10b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4280ULL);
x86_l_78cf:
	/* 0x78cf: mov    ecx,0xffffffb2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967218ULL);
x86_l_78d4:
	/* 0x78d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_78d7:
	/* 0x78d7: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78d7, 0x7bec, x86_l_7bec);
x86_l_78dd:
	/* 0x78dd: mov    rax,QWORD PTR [r14+0x10b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4272ULL);
x86_l_78e4:
	/* 0x78e4: mov    ecx,0xffffffb4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967220ULL);
x86_l_78e9:
	/* 0x78e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_78ec:
	/* 0x78ec: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78ec, 0x7bec, x86_l_7bec);
x86_l_78f2:
	/* 0x78f2: mov    rax,QWORD PTR [r14+0x10a8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4264ULL);
x86_l_78f9:
	/* 0x78f9: mov    ecx,0xffffffb6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967222ULL);
x86_l_78fe:
	/* 0x78fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7901:
	/* 0x7901: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7901, 0x7bec, x86_l_7bec);
x86_l_7907:
	/* 0x7907: mov    rax,QWORD PTR [r14+0x10a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4256ULL);
x86_l_790e:
	/* 0x790e: mov    ecx,0xffffffb8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967224ULL);
x86_l_7913:
	/* 0x7913: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7916:
	/* 0x7916: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7916, 0x7bec, x86_l_7bec);
x86_l_791c:
	/* 0x791c: mov    rax,QWORD PTR [r14+0x1098] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4248ULL);
x86_l_7923:
	/* 0x7923: mov    ecx,0xffffffba */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967226ULL);
x86_l_7928:
	/* 0x7928: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_792b:
	/* 0x792b: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x792b, 0x7bec, x86_l_7bec);
x86_l_7931:
	/* 0x7931: mov    rax,QWORD PTR [r14+0x1090] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4240ULL);
x86_l_7938:
	/* 0x7938: mov    ecx,0xffffffbc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967228ULL);
x86_l_793d:
	/* 0x793d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7940:
	/* 0x7940: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7940, 0x7bec, x86_l_7bec);
x86_l_7946:
	/* 0x7946: mov    rax,QWORD PTR [r14+0x1088] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4232ULL);
x86_l_794d:
	/* 0x794d: mov    ecx,0xffffffbe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967230ULL);
x86_l_7952:
	/* 0x7952: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7955:
	/* 0x7955: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7955, 0x7bec, x86_l_7bec);
x86_l_795b:
	/* 0x795b: mov    rax,QWORD PTR [r14+0x1080] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4224ULL);
x86_l_7962:
	/* 0x7962: mov    ecx,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967232ULL);
x86_l_7967:
	/* 0x7967: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_796a:
	/* 0x796a: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x796a, 0x7bec, x86_l_7bec);
x86_l_7970:
	/* 0x7970: mov    rax,QWORD PTR [r14+0x1078] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4216ULL);
x86_l_7977:
	/* 0x7977: mov    ecx,0xffffffc2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967234ULL);
x86_l_797c:
	/* 0x797c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_797f:
	/* 0x797f: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x797f, 0x7bec, x86_l_7bec);
x86_l_7985:
	/* 0x7985: mov    rax,QWORD PTR [r14+0x1070] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4208ULL);
x86_l_798c:
	/* 0x798c: mov    ecx,0xffffffc4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967236ULL);
x86_l_7991:
	/* 0x7991: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7994:
	/* 0x7994: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7994, 0x7bec, x86_l_7bec);
x86_l_799a:
	/* 0x799a: mov    rax,QWORD PTR [r14+0x1068] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4200ULL);
x86_l_79a1:
	/* 0x79a1: mov    ecx,0xffffffc6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967238ULL);
x86_l_79a6:
	/* 0x79a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79a9:
	/* 0x79a9: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x79a9, 0x7bec, x86_l_7bec);
x86_l_79af:
	/* 0x79af: mov    rax,QWORD PTR [r14+0x1060] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4192ULL);
x86_l_79b6:
	/* 0x79b6: mov    ecx,0xffffffc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967240ULL);
x86_l_79bb:
	/* 0x79bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79be:
	/* 0x79be: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x79be, 0x7bec, x86_l_7bec);
x86_l_79c4:
	/* 0x79c4: mov    rax,QWORD PTR [r14+0x1058] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4184ULL);
x86_l_79cb:
	/* 0x79cb: mov    ecx,0xffffffca */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967242ULL);
x86_l_79d0:
	/* 0x79d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79d3:
	/* 0x79d3: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x79d3, 0x7bec, x86_l_7bec);
x86_l_79d9:
	/* 0x79d9: mov    rax,QWORD PTR [r14+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4176ULL);
x86_l_79e0:
	/* 0x79e0: mov    ecx,0xffffffcc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967244ULL);
x86_l_79e5:
	/* 0x79e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79e8:
	/* 0x79e8: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x79e8, 0x7bec, x86_l_7bec);
x86_l_79ee:
	/* 0x79ee: mov    rax,QWORD PTR [r14+0x1048] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4168ULL);
x86_l_79f5:
	/* 0x79f5: mov    ecx,0xffffffce */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967246ULL);
x86_l_79fa:
	/* 0x79fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79fd:
	/* 0x79fd: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x79fd, 0x7bec, x86_l_7bec);
x86_l_7a03:
	/* 0x7a03: mov    rax,QWORD PTR [r14+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_7a0a:
	/* 0x7a0a: mov    ecx,0xffffffd0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967248ULL);
x86_l_7a0f:
	/* 0x7a0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a12:
	/* 0x7a12: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a12, 0x7bec, x86_l_7bec);
x86_l_7a18:
	/* 0x7a18: mov    rax,QWORD PTR [r14+0x1038] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4152ULL);
x86_l_7a1f:
	/* 0x7a1f: mov    ecx,0xffffffd2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967250ULL);
x86_l_7a24:
	/* 0x7a24: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a27:
	/* 0x7a27: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a27, 0x7bec, x86_l_7bec);
x86_l_7a2d:
	/* 0x7a2d: mov    rax,QWORD PTR [r14+0x1030] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4144ULL);
x86_l_7a34:
	/* 0x7a34: mov    ecx,0xffffffd4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967252ULL);
x86_l_7a39:
	/* 0x7a39: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a3c:
	/* 0x7a3c: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a3c, 0x7bec, x86_l_7bec);
x86_l_7a42:
	/* 0x7a42: mov    rax,QWORD PTR [r14+0x1028] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4136ULL);
x86_l_7a49:
	/* 0x7a49: mov    ecx,0xffffffd6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967254ULL);
x86_l_7a4e:
	/* 0x7a4e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a51:
	/* 0x7a51: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a51, 0x7bec, x86_l_7bec);
x86_l_7a57:
	/* 0x7a57: mov    rax,QWORD PTR [r14+0x1020] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4128ULL);
x86_l_7a5e:
	/* 0x7a5e: mov    ecx,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967256ULL);
x86_l_7a63:
	/* 0x7a63: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a66:
	/* 0x7a66: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a66, 0x7bec, x86_l_7bec);
x86_l_7a6c:
	/* 0x7a6c: mov    rax,QWORD PTR [r14+0x1018] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4120ULL);
x86_l_7a73:
	/* 0x7a73: mov    ecx,0xffffffda */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967258ULL);
x86_l_7a78:
	/* 0x7a78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a7b:
	/* 0x7a7b: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a7b, 0x7bec, x86_l_7bec);
x86_l_7a81:
	/* 0x7a81: mov    rax,QWORD PTR [r14+0x1010] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4112ULL);
x86_l_7a88:
	/* 0x7a88: mov    ecx,0xffffffdc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967260ULL);
x86_l_7a8d:
	/* 0x7a8d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a90:
	/* 0x7a90: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a90, 0x7bec, x86_l_7bec);
x86_l_7a96:
	/* 0x7a96: mov    rax,QWORD PTR [r14+0x1008] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_7a9d:
	/* 0x7a9d: mov    ecx,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_7aa2:
	/* 0x7aa2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7aa5:
	/* 0x7aa5: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7aa5, 0x7bec, x86_l_7bec);
x86_l_7aab:
	/* 0x7aab: mov    rax,QWORD PTR [r14+0x1000] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_7ab2:
	/* 0x7ab2: mov    ecx,0xffffffe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967264ULL);
x86_l_7ab7:
	/* 0x7ab7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7aba:
	/* 0x7aba: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7aba, 0x7bec, x86_l_7bec);
x86_l_7ac0:
	/* 0x7ac0: mov    rax,QWORD PTR [r14+0xff8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4088ULL);
x86_l_7ac7:
	/* 0x7ac7: mov    ecx,0xffffffe2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967266ULL);
x86_l_7acc:
	/* 0x7acc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7acf:
	/* 0x7acf: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7acf, 0x7bec, x86_l_7bec);
x86_l_7ad5:
	/* 0x7ad5: mov    rax,QWORD PTR [r14+0xff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4080ULL);
x86_l_7adc:
	/* 0x7adc: mov    ecx,0xffffffe4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967268ULL);
x86_l_7ae1:
	/* 0x7ae1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ae4:
	/* 0x7ae4: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ae4, 0x7bec, x86_l_7bec);
x86_l_7aea:
	/* 0x7aea: mov    rax,QWORD PTR [r14+0xfe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4072ULL);
x86_l_7af1:
	/* 0x7af1: mov    ecx,0xffffffe6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967270ULL);
x86_l_7af6:
	/* 0x7af6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7af9:
	/* 0x7af9: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7af9, 0x7bec, x86_l_7bec);
x86_l_7aff:
	/* 0x7aff: mov    rax,QWORD PTR [r14+0xfe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4064ULL);
x86_l_7b06:
	/* 0x7b06: mov    ecx,0xffffffe8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967272ULL);
x86_l_7b0b:
	/* 0x7b0b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b0e:
	/* 0x7b0e: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b0e, 0x7bec, x86_l_7bec);
x86_l_7b14:
	/* 0x7b14: mov    rax,QWORD PTR [r14+0xfd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4056ULL);
x86_l_7b1b:
	/* 0x7b1b: mov    ecx,0xffffffea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967274ULL);
x86_l_7b20:
	/* 0x7b20: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b23:
	/* 0x7b23: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b23, 0x7bec, x86_l_7bec);
x86_l_7b29:
	/* 0x7b29: mov    rax,QWORD PTR [r14+0xfd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4048ULL);
x86_l_7b30:
	/* 0x7b30: mov    ecx,0xffffffec */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967276ULL);
x86_l_7b35:
	/* 0x7b35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b38:
	/* 0x7b38: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b38, 0x7bec, x86_l_7bec);
x86_l_7b3e:
	/* 0x7b3e: mov    rax,QWORD PTR [r14+0xfc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4040ULL);
x86_l_7b45:
	/* 0x7b45: mov    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967278ULL);
x86_l_7b4a:
	/* 0x7b4a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b4d:
	/* 0x7b4d: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b4d, 0x7bec, x86_l_7bec);
x86_l_7b53:
	/* 0x7b53: mov    rax,QWORD PTR [r14+0xfc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4032ULL);
x86_l_7b5a:
	/* 0x7b5a: mov    ecx,0xfffffff0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967280ULL);
x86_l_7b5f:
	/* 0x7b5f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b62:
	/* 0x7b62: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b62, 0x7bec, x86_l_7bec);
x86_l_7b68:
	/* 0x7b68: mov    rax,QWORD PTR [r14+0xfb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4024ULL);
x86_l_7b6f:
	/* 0x7b6f: mov    ecx,0xfffffff2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967282ULL);
x86_l_7b74:
	/* 0x7b74: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b77:
	/* 0x7b77: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b77, 0x7bec, x86_l_7bec);
x86_l_7b79:
	/* 0x7b79: mov    rax,QWORD PTR [r14+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4016ULL);
x86_l_7b80:
	/* 0x7b80: mov    ecx,0xfffffff4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967284ULL);
x86_l_7b85:
	/* 0x7b85: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b88:
	/* 0x7b88: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b88, 0x7bec, x86_l_7bec);
x86_l_7b8a:
	/* 0x7b8a: mov    rax,QWORD PTR [r14+0xfa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4008ULL);
x86_l_7b91:
	/* 0x7b91: mov    ecx,0xfffffff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967286ULL);
x86_l_7b96:
	/* 0x7b96: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b99:
	/* 0x7b99: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7b99, 0x7bec, x86_l_7bec);
x86_l_7b9b:
	/* 0x7b9b: mov    rax,QWORD PTR [r14+0xfa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4000ULL);
x86_l_7ba2:
	/* 0x7ba2: mov    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967288ULL);
x86_l_7ba7:
	/* 0x7ba7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7baa:
	/* 0x7baa: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7baa, 0x7bec, x86_l_7bec);
x86_l_7bac:
	/* 0x7bac: mov    rax,QWORD PTR [r14+0xf98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3992ULL);
x86_l_7bb3:
	/* 0x7bb3: mov    ecx,0xfffffffa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967290ULL);
x86_l_7bb8:
	/* 0x7bb8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bbb:
	/* 0x7bbb: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7bbb, 0x7bec, x86_l_7bec);
x86_l_7bbd:
	/* 0x7bbd: mov    rax,QWORD PTR [r14+0xf90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3984ULL);
x86_l_7bc4:
	/* 0x7bc4: mov    ecx,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_7bc9:
	/* 0x7bc9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bcc:
	/* 0x7bcc: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7bcc, 0x7bec, x86_l_7bec);
x86_l_7bce:
	/* 0x7bce: mov    rax,QWORD PTR [r14+0xf88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3976ULL);
x86_l_7bd5:
	/* 0x7bd5: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_7bda:
	/* 0x7bda: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bdd:
	/* 0x7bdd: jne    7bec <kprobe_unwind_dotnet+0x7bec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7bdd, 0x7bec, x86_l_7bec);
x86_l_7bdf:
	/* 0x7bdf: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_7be7:
	/* 0x7be7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7bea:
	/* 0x7bea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7bec:
	/* 0x7bec: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7bee:
	/* 0x7bee: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bf1:
	/* 0x7bf1: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_7bf5:
	/* 0x7bf5: setne  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_7bf9:
	/* 0x7bf9: jne    7bfe <kprobe_unwind_dotnet+0x7bfe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7bf9, 0x7bfe, x86_l_7bfe);
x86_l_7bfb:
	/* 0x7bfb: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_7bfe:
	/* 0x7bfe: mov    dl,sil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_7c01:
	/* 0x7c01: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_7c03:
	/* 0x7c03: add    ecx,0x7e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 126ULL);
x86_l_7c06:
	/* 0x7c06: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7c08:
	/* 0x7c08: shl    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_7c0b:
	/* 0x7c0b: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_7c0e:
	/* 0x7c0e: jb     6f6f <kprobe_unwind_dotnet+0x6f6f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7c0e, 0x6f6f, x86_l_6f6f);
x86_l_7c14:
	/* 0x7c14: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7c1b:
	/* 0x7c1b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c1e:
	/* 0x7c1e: jne    7d64 <kprobe_unwind_dotnet+0x7d64> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7c1e, 0x7d64, x86_l_7d64);
x86_l_7c24:
	/* 0x7c24: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7c27:
	/* 0x7c27: jne    6e73 <kprobe_unwind_dotnet+0x6e73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7c27, 0x6e73, x86_l_6e73);
x86_l_7c2d:
	/* 0x7c2d: mov    DWORD PTR [rsp+0xc],0x5f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607647ULL);
x86_l_7c35:
	/* 0x7c35: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_7c3c:
	/* 0x7c3c: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7c41:
	/* 0x7c41: call   7c46 <kprobe_unwind_dotnet+0x7c46> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7c46:
	/* 0x7c46: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c49:
	/* 0x7c49: je     7c53 <kprobe_unwind_dotnet+0x7c53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c49, 0x7c53, x86_l_7c53);
x86_l_7c4b:
	/* 0x7c4b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7c4e:
	/* 0x7c4e: jmp    7cd1 <kprobe_unwind_dotnet+0x7cd1> */
	X86_SIM_X86_JMP(0x7c4e, 0x7cd1, x86_l_7cd1);
x86_l_7c53:
	/* 0x7c53: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7c5a:
	/* 0x7c5a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c5d:
	/* 0x7c5d: je     7cd1 <kprobe_unwind_dotnet+0x7cd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c5d, 0x7cd1, x86_l_7cd1);
x86_l_7c5f:
	/* 0x7c5f: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_7c69:
	/* 0x7c69: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_7c6e:
	/* 0x7c6e: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_7c78:
	/* 0x7c78: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7c7d:
	/* 0x7c7d: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_7c87:
	/* 0x7c87: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7c8c:
	/* 0x7c8c: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_7c96:
	/* 0x7c96: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7c9b:
	/* 0x7c9b: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_7ca5:
	/* 0x7ca5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7caa:
	/* 0x7caa: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_7cb4:
	/* 0x7cb4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7cb9:
	/* 0x7cb9: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7cbd:
	/* 0x7cbd: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7cc2:
	/* 0x7cc2: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_7cc7:
	/* 0x7cc7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7cc9:
	/* 0x7cc9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ccc:
	/* 0x7ccc: call   7cd1 <kprobe_unwind_dotnet+0x7cd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_7cd1:
	/* 0x7cd1: mov    edx,0x1773 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6003ULL);
x86_l_7cd6:
	/* 0x7cd6: mov    bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_7cd8:
	/* 0x7cd8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7cdf:
	/* 0x7cdf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ce2:
	/* 0x7ce2: je     6ebe <kprobe_unwind_dotnet+0x6ebe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7ce2, 0x6ebe, x86_l_6ebe);
x86_l_7ce8:
	/* 0x7ce8: movabs rax,0xa642520687469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387390569ULL);
x86_l_7cf2:
	/* 0x7cf2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7cf7:
	/* 0x7cf7: movabs rax,0x772064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8583971276541485414ULL);
x86_l_7d01:
	/* 0x7d01: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7d06:
	/* 0x7d06: movabs rax,0x2074726174735f65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338619869403242341ULL);
x86_l_7d10:
	/* 0x7d10: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7d15:
	/* 0x7d15: movabs rax,0x646f63203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7237112116340927776ULL);
x86_l_7d1f:
	/* 0x7d1f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7d24:
	/* 0x7d24: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_7d2e:
	/* 0x7d2e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d33:
	/* 0x7d33: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d38:
	/* 0x7d38: mov    esi,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_7d3d:
	/* 0x7d3d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d3f:
	/* 0x7d3f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d42:
	/* 0x7d42: call   7d47 <kprobe_unwind_dotnet+0x7d47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_7d47:
	/* 0x7d47: jmp    6ebe <kprobe_unwind_dotnet+0x6ebe> */
	X86_SIM_X86_JMP(0x7d47, 0x6ebe, x86_l_6ebe);
x86_l_7d4c:
	/* 0x7d4c: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7d4f:
	/* 0x7d4f: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_7d52:
	/* 0x7d52: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7d55:
	/* 0x7d55: je     7dfa <kprobe_unwind_dotnet+0x7dfa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d55, 0x7dfa, x86_l_7dfa);
x86_l_7d5b:
	/* 0x7d5b: add    r13,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551488ULL);
x86_l_7d5f:
	/* 0x7d5f: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x7d5f, 0x7e30, x86_l_7e30);
x86_l_7d64:
	/* 0x7d64: movabs rax,0x207972746e65202c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2340027325789577260ULL);
x86_l_7d6e:
	/* 0x7d6e: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7d73:
	/* 0x7d73: movabs rax,0x6425206465707069 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7216209593501773929ULL);
x86_l_7d7d:
	/* 0x7d7d: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7d82:
	/* 0x7d82: movabs rax,0x6b73203a786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7742567619880559904ULL);
x86_l_7d8c:
	/* 0x7d8c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7d91:
	/* 0x7d91: movabs rax,0x726f662074726174 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732317307252ULL);
x86_l_7d9b:
	/* 0x7d9b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7da0:
	/* 0x7da0: movabs rax,0x732065646f632064 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8295741995656355940ULL);
x86_l_7daa:
	/* 0x7daa: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7daf:
	/* 0x7daf: movabs rax,0x6e6966203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7956002505394826528ULL);
x86_l_7db9:
	/* 0x7db9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7dbe:
	/* 0x7dbe: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_7dc8:
	/* 0x7dc8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7dcd:
	/* 0x7dcd: mov    DWORD PTR [rsp+0x48],0xa7825 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309238331429ULL);
x86_l_7dd5:
	/* 0x7dd5: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7dd7:
	/* 0x7dd7: mov    r8d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7dda:
	/* 0x7dda: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ddf:
	/* 0x7ddf: mov    esi,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_7de4:
	/* 0x7de4: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7de7:
	/* 0x7de7: call   7dec <kprobe_unwind_dotnet+0x7dec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_7dec:
	/* 0x7dec: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7def:
	/* 0x7def: jne    6e73 <kprobe_unwind_dotnet+0x6e73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7def, 0x6e73, x86_l_6e73);
x86_l_7df5:
	/* 0x7df5: jmp    7c2d <kprobe_unwind_dotnet+0x7c2d> */
	X86_SIM_X86_JMP(0x7df5, 0x7c2d, x86_l_7c2d);
x86_l_7dfa:
	/* 0x7dfa: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7dfd:
	/* 0x7dfd: shr    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 20ULL);
x86_l_7e00:
	/* 0x7e00: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7e03:
	/* 0x7e03: je     7e0e <kprobe_unwind_dotnet+0x7e0e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e03, 0x7e0e, x86_l_7e0e);
x86_l_7e05:
	/* 0x7e05: add    r13,0xffffffffffffff60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551456ULL);
x86_l_7e0c:
	/* 0x7e0c: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x7e0c, 0x7e30, x86_l_7e30);
x86_l_7e0e:
	/* 0x7e0e: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7e11:
	/* 0x7e11: shr    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 24ULL);
x86_l_7e14:
	/* 0x7e14: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_7e17:
	/* 0x7e17: je     7e22 <kprobe_unwind_dotnet+0x7e22> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e17, 0x7e22, x86_l_7e22);
x86_l_7e19:
	/* 0x7e19: add    r13,0xffffffffffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551424ULL);
x86_l_7e20:
	/* 0x7e20: jmp    7e30 <kprobe_unwind_dotnet+0x7e30> */
	X86_SIM_X86_JMP(0x7e20, 0x7e30, x86_l_7e30);
x86_l_7e22:
	/* 0x7e22: shr    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_7e26:
	/* 0x7e26: add    r13,0xffffffffffffff20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551392ULL);
x86_l_7e2d:
	/* 0x7e2d: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_7e30:
	/* 0x7e30: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7e33:
	/* 0x7e33: lea    r15d,[rax*4-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 18446744073709551612ULL);
x86_l_7e3b:
	/* 0x7e3b: add    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7e3e:
	/* 0x7e3e: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7e45:
	/* 0x7e45: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e48:
	/* 0x7e48: jne    8200 <kprobe_unwind_dotnet+0x8200> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e48, 0x8200, x86_l_8200);
x86_l_7e4e:
	/* 0x7e4e: lea    rdx,[r15-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_7e52:
	/* 0x7e52: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7e57:
	/* 0x7e57: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_7e5c:
	/* 0x7e5c: call   7e61 <kprobe_unwind_dotnet+0x7e61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_7e61:
	/* 0x7e61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e64:
	/* 0x7e64: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7e6b:
	/* 0x7e6b: jne    9fa <kprobe_unwind_dotnet+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e6b, 0x9fa, x86_l_9fa);
x86_l_7e71:
	/* 0x7e71: mov    ebp,0x1f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_7e76:
	/* 0x7e76: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7e7d:
	/* 0x7e7d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e80:
	/* 0x7e80: jne    8276 <kprobe_unwind_dotnet+0x8276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e80, 0x8276, x86_l_8276);
x86_l_7e86:
	/* 0x7e86: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_7e8d:
	/* 0x7e8d: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_7e91:
	/* 0x7e91: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7e91, 0xa4e, x86_l_a4e);
x86_l_7e97:
	/* 0x7e97: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7e9c:
	/* 0x7e9c: sub    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_7e9f:
	/* 0x7e9f: shl    rcx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 5ULL);
x86_l_7ea3:
	/* 0x7ea3: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7ea6:
	/* 0x7ea6: lea    edx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_7ea9:
	/* 0x7ea9: mov    DWORD PTR [r14+0x2c0],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_7eb0:
	/* 0x7eb0: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_7eb4:
	/* 0x7eb4: mov    QWORD PTR [r14+rax*8+0x2d0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_7ebc:
	/* 0x7ebc: mov    QWORD PTR [r14+rax*8+0x2d8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_7ec4:
	/* 0x7ec4: mov    BYTE PTR [r14+rax*8+0x2e0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929866ULL);
x86_l_7ecd:
	/* 0x7ecd: movzx  ecx,BYTE PTR [rsp+0x5f] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 95ULL);
x86_l_7ed2:
	/* 0x7ed2: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_7eda:
	/* 0x7eda: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_7ee6:
	/* 0x7ee6: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_7ef1:
	/* 0x7ef1: mov    DWORD PTR [rsp+0xc],0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607643ULL);
x86_l_7ef9:
	/* 0x7ef9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_7f00:
	/* 0x7f00: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7f05:
	/* 0x7f05: call   7f0a <kprobe_unwind_dotnet+0x7f0a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f0a:
	/* 0x7f0a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f0d:
	/* 0x7f0d: je     7f14 <kprobe_unwind_dotnet+0x7f14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f0d, 0x7f14, x86_l_7f14);
x86_l_7f0f:
	/* 0x7f0f: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7f12:
	/* 0x7f12: jmp    7f24 <kprobe_unwind_dotnet+0x7f24> */
	X86_SIM_X86_JMP(0x7f12, 0x7f24, x86_l_7f24);
x86_l_7f14:
	/* 0x7f14: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7f1b:
	/* 0x7f1b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f1e:
	/* 0x7f1e: jne    82ca <kprobe_unwind_dotnet+0x82ca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f1e, 0x82ca, x86_l_82ca);
x86_l_7f24:
	/* 0x7f24: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_7f2c:
	/* 0x7f2c: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f2f:
	/* 0x7f2f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7f36:
	/* 0x7f36: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f38:
	/* 0x7f38: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7f3b:
	/* 0x7f3b: je     8172 <kprobe_unwind_dotnet+0x8172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f3b, 0x8172, x86_l_8172);
x86_l_7f41:
	/* 0x7f41: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_7f43:
	/* 0x7f43: jne    8341 <kprobe_unwind_dotnet+0x8341> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f43, 0x8341, x86_l_8341);
x86_l_7f49:
	/* 0x7f49: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_7f53:
	/* 0x7f53: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f56:
	/* 0x7f56: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7f56, 0x21d0, x86_l_21d0);
x86_l_7f5c:
	/* 0x7f5c: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_7f63:
	/* 0x7f63: jb     2358 <kprobe_unwind_dotnet+0x2358> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7f63, 0x2358, x86_l_2358);
x86_l_7f69:
	/* 0x7f69: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f6c:
	/* 0x7f6c: mov    DWORD PTR [rsp+0x70],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337248ULL);
x86_l_7f74:
	/* 0x7f74: movbe  DWORD PTR [rsp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 116ULL);
x86_l_7f7a:
	/* 0x7f7a: movbe  QWORD PTR [rsp+0x78],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 120ULL);
x86_l_7f81:
	/* 0x7f81: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_7f88:
	/* 0x7f88: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7f8d:
	/* 0x7f8d: call   7f92 <kprobe_unwind_dotnet+0x7f92> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f92:
	/* 0x7f92: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f95:
	/* 0x7f95: je     80c1 <kprobe_unwind_dotnet+0x80c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f95, 0x80c1, x86_l_80c1);
x86_l_7f9b:
	/* 0x7f9b: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7f9f:
	/* 0x7f9f: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_7fa9:
	/* 0x7fa9: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7fac:
	/* 0x7fac: mov    QWORD PTR [r14+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_7fb3:
	/* 0x7fb3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7fb6:
	/* 0x7fb6: mov    QWORD PTR [r14+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_7fbd:
	/* 0x7fbd: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_7fc1:
	/* 0x7fc1: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7fc4:
	/* 0x7fc4: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_7fc7:
	/* 0x7fc7: mov    QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_7fce:
	/* 0x7fce: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_7fd5:
	/* 0x7fd5: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7fd8:
	/* 0x7fd8: jne    83da <kprobe_unwind_dotnet+0x83da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7fd8, 0x83da, x86_l_83da);
x86_l_7fde:
	/* 0x7fde: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_7fe2:
	/* 0x7fe2: jne    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7fe2, 0x85e7, x86_l_85e7);
x86_l_7fe8:
	/* 0x7fe8: mov    rax,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_7fef:
	/* 0x7fef: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7ff4:
	/* 0x7ff4: mov    rbx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_7ffb:
	/* 0x7ffb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_8002:
	/* 0x8002: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8007:
	/* 0x8007: call   800c <kprobe_unwind_dotnet+0x800c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_800c:
	/* 0x800c: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_8012:
	/* 0x8012: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8015:
	/* 0x8015: je     85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8015, 0x85e7, x86_l_85e7);
x86_l_801b:
	/* 0x801b: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_801e:
	/* 0x801e: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8021:
	/* 0x8021: ja     8029 <kprobe_unwind_dotnet+0x8029> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8021, 0x8029, x86_l_8029);
x86_l_8023:
	/* 0x8023: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8027:
	/* 0x8027: jae    803d <kprobe_unwind_dotnet+0x803d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x8027, 0x803d, x86_l_803d);
x86_l_8029:
	/* 0x8029: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_802d:
	/* 0x802d: ja     85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x802d, 0x85e7, x86_l_85e7);
x86_l_8033:
	/* 0x8033: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8037:
	/* 0x8037: jb     85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8037, 0x85e7, x86_l_85e7);
x86_l_803d:
	/* 0x803d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_8044:
	/* 0x8044: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8047:
	/* 0x8047: jne    84d5 <kprobe_unwind_dotnet+0x84d5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8047, 0x84d5, x86_l_84d5);
x86_l_804d:
	/* 0x804d: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_8054:
	/* 0x8054: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8058:
	/* 0x8058: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_805b:
	/* 0x805b: jae    853e <kprobe_unwind_dotnet+0x853e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x805b, 0x853e, x86_l_853e);
x86_l_8061:
	/* 0x8061: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_8068:
	/* 0x8068: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_806b:
	/* 0x806b: je     85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x806b, 0x85e7, x86_l_85e7);
x86_l_8071:
	/* 0x8071: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_807b:
	/* 0x807b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8080:
	/* 0x8080: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_808a:
	/* 0x808a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_808f:
	/* 0x808f: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_8099:
	/* 0x8099: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_809e:
	/* 0x809e: mov    DWORD PTR [rsp+0x27],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 167504405870ULL);
x86_l_80a6:
	/* 0x80a6: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_80ab:
	/* 0x80ab: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_80b0:
	/* 0x80b0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80b2:
	/* 0x80b2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80b4:
	/* 0x80b4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80b7:
	/* 0x80b7: call   80bc <kprobe_unwind_dotnet+0x80bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_80bc:
	/* 0x80bc: jmp    85e7 <kprobe_unwind_dotnet+0x85e7> */
	X86_SIM_X86_JMP(0x80bc, 0x85e7, x86_l_85e7);
x86_l_80c1:
	/* 0x80c1: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_80c6:
	/* 0x80c6: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_80cd:
	/* 0x80cd: cmp    DWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_80d1:
	/* 0x80d1: jne    80e8 <kprobe_unwind_dotnet+0x80e8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x80d1, 0x80e8, x86_l_80e8);
x86_l_80d3:
	/* 0x80d3: mov    DWORD PTR [r14+0xf28],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108492ULL);
x86_l_80de:
	/* 0x80de: mov    eax,0xfac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4012ULL);
x86_l_80e3:
	/* 0x80e3: jmp    7126 <kprobe_unwind_dotnet+0x7126> */
	X86_SIM_X86_JMP(0x80e3, 0x7126, x86_l_7126);
x86_l_80e8:
	/* 0x80e8: movabs rax,0xa786c2578302043 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471845770567747ULL);
x86_l_80f2:
	/* 0x80f2: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_80f7:
	/* 0x80f7: movabs rax,0x5020726f6620676e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5773740545069311854ULL);
x86_l_8101:
	/* 0x8101: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8106:
	/* 0x8106: movabs rax,0x697070616d207972 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7597696135119010162ULL);
x86_l_8110:
	/* 0x8110: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8115:
	/* 0x8115: movabs rax,0x6f6d656d206c6176 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8029185230041276790ULL);
x86_l_811f:
	/* 0x811f: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8124:
	/* 0x8124: movabs rax,0x7265746e69207075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243122710530519157ULL);
x86_l_812e:
	/* 0x812e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8133:
	/* 0x8133: movabs rax,0x206b6f6f6c206f74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2336083356067852148ULL);
x86_l_813d:
	/* 0x813d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8142:
	/* 0x8142: movabs rax,0x206572756c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334397830517055814ULL);
x86_l_814c:
	/* 0x814c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8151:
	/* 0x8151: mov    BYTE PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_8156:
	/* 0x8156: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_815b:
	/* 0x815b: mov    esi,0x39 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_8160:
	/* 0x8160: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_8163:
	/* 0x8163: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8165:
	/* 0x8165: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8168:
	/* 0x8168: call   816d <kprobe_unwind_dotnet+0x816d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_816d:
	/* 0x816d: jmp    80d3 <kprobe_unwind_dotnet+0x80d3> */
	X86_SIM_X86_JMP(0x816d, 0x80d3, x86_l_80d3);
x86_l_8172:
	/* 0x8172: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8177:
	/* 0x8177: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_817e:
	/* 0x817e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_8180:
	/* 0x8180: je     2252 <kprobe_unwind_dotnet+0x2252> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8180, 0x2252, x86_l_2252);
x86_l_8186:
	/* 0x8186: movabs rax,0xa2930203d3d2043 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 732169329448919107ULL);
x86_l_8190:
	/* 0x8190: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8195:
	/* 0x8195: movabs rax,0x5028206572756c69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5775902142186744937ULL);
x86_l_819f:
	/* 0x819f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_81a4:
	/* 0x81a4: movabs rax,0x616620646e69776e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018332685024720750ULL);
x86_l_81ae:
	/* 0x81ae: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_81b3:
	/* 0x81b3: movabs rax,0x75206f7420657564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8439868246242719076ULL);
x86_l_81bd:
	/* 0x81bd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_81c2:
	/* 0x81c2: movabs rax,0x20646e69776e7520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334111906139108640ULL);
x86_l_81cc:
	/* 0x81cc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_81d1:
	/* 0x81d1: movabs rax,0x676e6970706f7453 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7453010364988355667ULL);
x86_l_81db:
	/* 0x81db: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_81e0:
	/* 0x81e0: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_81e5:
	/* 0x81e5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_81ea:
	/* 0x81ea: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_81ef:
	/* 0x81ef: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_81f1:
	/* 0x81f1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_81f3:
	/* 0x81f3: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_81f6:
	/* 0x81f6: call   81fb <kprobe_unwind_dotnet+0x81fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_81fb:
	/* 0x81fb: jmp    2252 <kprobe_unwind_dotnet+0x2252> */
	X86_SIM_X86_JMP(0x81fb, 0x2252, x86_l_2252);
x86_l_8200:
	/* 0x8200: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_8202:
	/* 0x8202: movabs rax,0xa786c253d7465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155643692133ULL);
x86_l_820c:
	/* 0x820c: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_8211:
	/* 0x8211: movabs rax,0x746572202c78253d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8387235363558008125ULL);
x86_l_821b:
	/* 0x821b: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8220:
	/* 0x8220: movabs rax,0x6c6176202c786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653109394271269ULL);
x86_l_822a:
	/* 0x822a: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_822f:
	/* 0x822f: movabs rax,0x203d2061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2323048585730221412ULL);
x86_l_8239:
	/* 0x8239: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_823e:
	/* 0x823e: movabs rax,0x5f6370203e2d2d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 6873460740081921312ULL);
x86_l_8248:
	/* 0x8248: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_824d:
	/* 0x824d: movabs rax,0x203a74656e746f64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322296536856555364ULL);
x86_l_8257:
	/* 0x8257: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_825c:
	/* 0x825c: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8261:
	/* 0x8261: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_8266:
	/* 0x8266: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_8269:
	/* 0x8269: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_826c:
	/* 0x826c: call   8271 <kprobe_unwind_dotnet+0x8271> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_8271:
	/* 0x8271: jmp    7e4e <kprobe_unwind_dotnet+0x7e4e> */
	X86_SIM_X86_JMP(0x8271, 0x7e4e, x86_l_7e4e);
x86_l_8276:
	/* 0x8276: lea    rsi,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_827d:
	/* 0x827d: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8282:
	/* 0x8282: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_8287:
	/* 0x8287: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_828a:
	/* 0x828a: rep movs QWORD PTR es:[rdi],QWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_828d:
	/* 0x828d: mov    BYTE PTR [rsp+0x52],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 352187318272ULL);
x86_l_8292:
	/* 0x8292: mov    WORD PTR [rsp+0x50],0xa78 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 343597386360ULL);
x86_l_8299:
	/* 0x8299: mov    rcx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_829e:
	/* 0x829e: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_82a1:
	/* 0x82a1: sub    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_82a4:
	/* 0x82a4: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_82a7:
	/* 0x82a7: mov    esi,0x43 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 67ULL);
x86_l_82ac:
	/* 0x82ac: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_82af:
	/* 0x82af: call   82b4 <kprobe_unwind_dotnet+0x82b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_82b4:
	/* 0x82b4: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_82bb:
	/* 0x82bb: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_82bf:
	/* 0x82bf: ja     a4e <kprobe_unwind_dotnet+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x82bf, 0xa4e, x86_l_a4e);
x86_l_82c5:
	/* 0x82c5: jmp    7e97 <kprobe_unwind_dotnet+0x7e97> */
	X86_SIM_X86_JMP(0x82c5, 0x7e97, x86_l_7e97);
x86_l_82ca:
	/* 0x82ca: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_82d4:
	/* 0x82d4: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_82d9:
	/* 0x82d9: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_82e3:
	/* 0x82e3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_82e8:
	/* 0x82e8: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_82f2:
	/* 0x82f2: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_82f7:
	/* 0x82f7: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_8301:
	/* 0x8301: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8306:
	/* 0x8306: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_8310:
	/* 0x8310: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8315:
	/* 0x8315: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_831f:
	/* 0x831f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8324:
	/* 0x8324: mov    edx,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8328:
	/* 0x8328: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_832d:
	/* 0x832d: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_8332:
	/* 0x8332: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8334:
	/* 0x8334: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8337:
	/* 0x8337: call   833c <kprobe_unwind_dotnet+0x833c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_833c:
	/* 0x833c: jmp    7f24 <kprobe_unwind_dotnet+0x7f24> */
	X86_SIM_X86_JMP(0x833c, 0x7f24, x86_l_7f24);
x86_l_8341:
	/* 0x8341: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_834b:
	/* 0x834b: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8350:
	/* 0x8350: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_835a:
	/* 0x835a: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_835f:
	/* 0x835f: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_8369:
	/* 0x8369: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_836e:
	/* 0x836e: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_8378:
	/* 0x8378: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_837d:
	/* 0x837d: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_8387:
	/* 0x8387: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_838c:
	/* 0x838c: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_8396:
	/* 0x8396: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_839b:
	/* 0x839b: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_83a0:
	/* 0x83a0: mov    edx,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_83a7:
	/* 0x83a7: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_83ac:
	/* 0x83ac: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_83b1:
	/* 0x83b1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_83b3:
	/* 0x83b3: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_83b6:
	/* 0x83b6: call   83bb <kprobe_unwind_dotnet+0x83bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_83bb:
	/* 0x83bb: mov    r13,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_83c2:
	/* 0x83c2: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_83cc:
	/* 0x83cc: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_83cf:
	/* 0x83cf: ja     21d0 <kprobe_unwind_dotnet+0x21d0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x83cf, 0x21d0, x86_l_21d0);
x86_l_83d5:
	/* 0x83d5: jmp    7f5c <kprobe_unwind_dotnet+0x7f5c> */
	X86_SIM_X86_JMP(0x83d5, 0x7f5c, x86_l_7f5c);
x86_l_83da:
	/* 0x83da: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_83e4:
	/* 0x83e4: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_83e9:
	/* 0x83e9: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_83f3:
	/* 0x83f3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_83f8:
	/* 0x83f8: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_8402:
	/* 0x8402: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8407:
	/* 0x8407: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_8411:
	/* 0x8411: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8416:
	/* 0x8416: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_8420:
	/* 0x8420: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8425:
	/* 0x8425: movabs rbx,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_842f:
	/* 0x842f: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8434:
	/* 0x8434: mov    WORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_843b:
	/* 0x843b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8440:
	/* 0x8440: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_8445:
	/* 0x8445: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_8448:
	/* 0x8448: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_844b:
	/* 0x844b: call   8450 <kprobe_unwind_dotnet+0x8450> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_8450:
	/* 0x8450: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_8457:
	/* 0x8457: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_845a:
	/* 0x845a: je     7fde <kprobe_unwind_dotnet+0x7fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x845a, 0x7fde, x86_l_7fde);
x86_l_8460:
	/* 0x8460: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_846a:
	/* 0x846a: mov    QWORD PTR [rsp+0x37],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 55ULL);
x86_l_846f:
	/* 0x846f: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_8479:
	/* 0x8479: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_847e:
	/* 0x847e: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_8488:
	/* 0x8488: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_848d:
	/* 0x848d: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_8497:
	/* 0x8497: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_849c:
	/* 0x849c: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_84a6:
	/* 0x84a6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_84ab:
	/* 0x84ab: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_84b0:
	/* 0x84b0: mov    rcx,QWORD PTR [r14+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_84b7:
	/* 0x84b7: mov    rdx,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_84be:
	/* 0x84be: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_84c3:
	/* 0x84c3: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_84c8:
	/* 0x84c8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_84cb:
	/* 0x84cb: call   84d0 <kprobe_unwind_dotnet+0x84d0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_84d0:
	/* 0x84d0: jmp    7fde <kprobe_unwind_dotnet+0x7fde> */
	X86_SIM_X86_JMP(0x84d0, 0x7fde, x86_l_7fde);
x86_l_84d5:
	/* 0x84d5: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_84df:
	/* 0x84df: mov    QWORD PTR [rsp+0x26],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_84e4:
	/* 0x84e4: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_84ee:
	/* 0x84ee: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_84f3:
	/* 0x84f3: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_84fd:
	/* 0x84fd: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8502:
	/* 0x8502: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_850c:
	/* 0x850c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8511:
	/* 0x8511: movzx  edx,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_8516:
	/* 0x8516: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_851b:
	/* 0x851b: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_8520:
	/* 0x8520: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8522:
	/* 0x8522: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8525:
	/* 0x8525: call   852a <kprobe_unwind_dotnet+0x852a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_852a:
	/* 0x852a: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_8531:
	/* 0x8531: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8535:
	/* 0x8535: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_8538:
	/* 0x8538: jb     8061 <kprobe_unwind_dotnet+0x8061> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8538, 0x8061, x86_l_8061);
x86_l_853e:
	/* 0x853e: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_8546:
	/* 0x8546: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_854d:
	/* 0x854d: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8552:
	/* 0x8552: call   8557 <kprobe_unwind_dotnet+0x8557> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8557:
	/* 0x8557: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_855a:
	/* 0x855a: je     8564 <kprobe_unwind_dotnet+0x8564> */
	X86_SIM_X86_JCC(X86_CC_E, 0x855a, 0x8564, x86_l_8564);
x86_l_855c:
	/* 0x855c: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_855f:
	/* 0x855f: jmp    85e2 <kprobe_unwind_dotnet+0x85e2> */
	X86_SIM_X86_JMP(0x855f, 0x85e2, x86_l_85e2);
x86_l_8564:
	/* 0x8564: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_856b:
	/* 0x856b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_856e:
	/* 0x856e: je     85e2 <kprobe_unwind_dotnet+0x85e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x856e, 0x85e2, x86_l_85e2);
x86_l_8570:
	/* 0x8570: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_857a:
	/* 0x857a: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_857f:
	/* 0x857f: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_8589:
	/* 0x8589: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_858e:
	/* 0x858e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_8598:
	/* 0x8598: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_859d:
	/* 0x859d: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_85a7:
	/* 0x85a7: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_85ac:
	/* 0x85ac: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_85b6:
	/* 0x85b6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_85bb:
	/* 0x85bb: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_85c5:
	/* 0x85c5: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_85ca:
	/* 0x85ca: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_85ce:
	/* 0x85ce: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_85d3:
	/* 0x85d3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_85d8:
	/* 0x85d8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85da:
	/* 0x85da: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85dd:
	/* 0x85dd: call   85e2 <kprobe_unwind_dotnet+0x85e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_85e2:
	/* 0x85e2: movzx  r12d,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_85e7:
	/* 0x85e7: mov    r15,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_85ec:
	/* 0x85ec: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_85f3:
	/* 0x85f3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85f5:
	/* 0x85f5: jmp    7129 <kprobe_unwind_dotnet+0x7129> */
	X86_SIM_X86_JMP(0x85f5, 0x7129, x86_l_7129);
x86_l_85fa:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
