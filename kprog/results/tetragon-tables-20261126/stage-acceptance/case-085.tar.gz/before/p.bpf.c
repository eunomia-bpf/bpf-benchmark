#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 216U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(7) M(9) M(11) M(19) M(20)
#include "../x86_sim_local_bpf.h"

extern const void jiffies_64 __ksym;
extern __u8 cilium_calls[] __ksym;
extern __u8 cilium_ct4_global[] __ksym;
extern __u8 cilium_ct_any4_global[] __ksym;
extern __u8 cilium_devices[] __ksym;
extern __u8 cilium_ipv4_frag_datagrams[] __ksym;
extern __u8 cilium_lb4_reverse_nat[] __ksym;
extern __u8 cilium_metrics[] __ksym;
extern __u8 cilium_nodeport_neigh4[] __ksym;
extern __u8 cilium_xdp_scratch[] __ksym;
static const __u8 __x86_rodata_0[8] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"device_mac.__zero_mac\",\"size\":8}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_MEM_IMM, X86_OP_IMUL_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MULX, X86_OP_MULX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("xdp/tail")
int p_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    rax,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_trace_payload_len));
x86_l_18:
	/* 0x18: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a:
	/* 0x1a: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_23:
	/* 0x23: mov    DWORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_2e:
	/* 0x2e: mov    QWORD PTR [rsp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_3a:
	/* 0x3a: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_46:
	/* 0x46: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_4f:
	/* 0x4f: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_58:
	/* 0x58: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_61:
	/* 0x61: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_6a:
	/* 0x6a: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_73:
	/* 0x73: mov    BYTE PTR [rsp+0x50],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 343597383682ULL);
x86_l_78:
	/* 0x78: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7b:
	/* 0x7b: mov    DWORD PTR [rsp+0x58],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7f:
	/* 0x7f: mov    WORD PTR [rsp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_86:
	/* 0x86: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_8e:
	/* 0x8e: mov    rax,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91:
	/* 0x91: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_96:
	/* 0x96: mov    rcx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9a:
	/* 0x9a: lea    rdx,[rax+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_9e:
	/* 0x9e: mov    ebp,0xffffff7a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967162ULL);
x86_l_a3:
	/* 0xa3: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a6:
	/* 0xa6: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a9:
	/* 0xa9: jbe    1c2 <tail_nodeport_rev_dnat_ipv4+0x1c2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa9, 0x1c2, x86_l_1c2);
x86_l_af:
	/* 0xaf: shl    r14d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_b3:
	/* 0xb3: movzx  r14d,r14w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_b7:
	/* 0xb7: mov    ebx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b9:
	/* 0xb9: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be:
	/* 0xbe: mov    ebp,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_c0:
	/* 0xc0: neg    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_c2:
	/* 0xc2: jns    c6 <tail_nodeport_rev_dnat_ipv4+0xc6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc2, 0xc6, x86_l_c6);
x86_l_c4:
	/* 0xc4: mov    ebp,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_c6:
	/* 0xc6: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_ce:
	/* 0xce: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_d5:
	/* 0xd5: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_da:
	/* 0xda: call   b83 <tail_nodeport_rev_dnat_ipv4+0xb83> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_df:
	/* 0xdf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e2:
	/* 0xe2: je     ea <tail_nodeport_rev_dnat_ipv4+0xea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe2, 0xea, x86_l_ea);
x86_l_e4:
	/* 0xe4: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ea:
	/* 0xea: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_f2:
	/* 0xf2: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_f9:
	/* 0xf9: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_fe:
	/* 0xfe: call   ba3 <tail_nodeport_rev_dnat_ipv4+0xba3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_103:
	/* 0x103: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_106:
	/* 0x106: je     10f <tail_nodeport_rev_dnat_ipv4+0x10f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x106, 0x10f, x86_l_10f);
x86_l_108:
	/* 0x108: mov    DWORD PTR [rax+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_10f:
	/* 0x10f: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_117:
	/* 0x117: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_11e:
	/* 0x11e: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_123:
	/* 0x123: call   bc8 <tail_nodeport_rev_dnat_ipv4+0xbc8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_128:
	/* 0x128: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12b:
	/* 0x12b: je     137 <tail_nodeport_rev_dnat_ipv4+0x137> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12b, 0x137, x86_l_137);
x86_l_12d:
	/* 0x12d: movzx  ecx,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_131:
	/* 0x131: or     ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_134:
	/* 0x134: mov    DWORD PTR [rax+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_137:
	/* 0x137: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_13f:
	/* 0x13f: mov    rdi,QWORD PTR [rip+0xaa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_146:
	/* 0x146: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_14b:
	/* 0x14b: call   bf0 <tail_nodeport_rev_dnat_ipv4+0xbf0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_150:
	/* 0x150: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153:
	/* 0x153: je     15c <tail_nodeport_rev_dnat_ipv4+0x15c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x153, 0x15c, x86_l_15c);
x86_l_155:
	/* 0x155: mov    DWORD PTR [rax+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_15c:
	/* 0x15c: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_164:
	/* 0x164: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_16b:
	/* 0x16b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_170:
	/* 0x170: call   c15 <tail_nodeport_rev_dnat_ipv4+0xc15> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_175:
	/* 0x175: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_178:
	/* 0x178: je     181 <tail_nodeport_rev_dnat_ipv4+0x181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x178, 0x181, x86_l_181);
x86_l_17a:
	/* 0x17a: mov    DWORD PTR [rax+0x10],0x97f6801 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68878821377ULL);
x86_l_181:
	/* 0x181: mov    rbx,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_185:
	/* 0x185: sub    rbx,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_188:
	/* 0x188: movabs rax,0x68097f0200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 446835917312ULL);
x86_l_192:
	/* 0x192: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_197:
	/* 0x197: mov    BYTE PTR [rsp+0x10],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19c:
	/* 0x19c: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_1a3:
	/* 0x1a3: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a8:
	/* 0x1a8: call   c4d <tail_nodeport_rev_dnat_ipv4+0xc4d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ad:
	/* 0x1ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b0:
	/* 0x1b0: je     2c4 <tail_nodeport_rev_dnat_ipv4+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b0, 0x2c4, x86_l_2c4);
x86_l_1b6:
	/* 0x1b6: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1b9:
	/* 0x1b9: add    QWORD PTR [rax+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1bd:
	/* 0x1bd: jmp    2ea <tail_nodeport_rev_dnat_ipv4+0x2ea> */
	X86_SIM_X86_JMP(0x1bd, 0x2ea, x86_l_2ea);
x86_l_1c2:
	/* 0x1c2: movabs r12,0x10000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1099511627776ULL);
x86_l_1cc:
	/* 0x1cc: movzx  edx,WORD PTR [rax+0x12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18ULL);
x86_l_1d0:
	/* 0x1d0: movzx  r15d,BYTE PTR [rax+0x17] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_1d5:
	/* 0x1d5: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1d8:
	/* 0x1d8: shl    r13,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_1dc:
	/* 0x1dc: or     r13,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1df:
	/* 0x1df: movzx  edx,WORD PTR [rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_1e3:
	/* 0x1e3: test   edx,0xff3f */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 65343ULL);
x86_l_1e9:
	/* 0x1e9: je     1ee <tail_nodeport_rev_dnat_ipv4+0x1ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e9, 0x1ee, x86_l_1ee);
x86_l_1eb:
	/* 0x1eb: or     r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1ee:
	/* 0x1ee: movabs r8,0x20000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 2199023255552ULL);
x86_l_1f8:
	/* 0x1f8: test   edx,0xff1f */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 65311ULL);
x86_l_1fe:
	/* 0x1fe: je     203 <tail_nodeport_rev_dnat_ipv4+0x203> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe, 0x203, x86_l_203);
x86_l_200:
	/* 0x200: or     r13,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R8, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_203:
	/* 0x203: mov    edi,DWORD PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_206:
	/* 0x206: mov    BYTE PTR [rsp+0x34],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_20b:
	/* 0x20b: mov    edx,DWORD PTR [rax+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_20e:
	/* 0x20e: mov    DWORD PTR [rsp+0x28],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_212:
	/* 0x212: mov    esi,DWORD PTR [rax+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_215:
	/* 0x215: mov    DWORD PTR [rsp+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_219:
	/* 0x219: mov    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_21e:
	/* 0x21e: cmp    r15d,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_222:
	/* 0x222: je     22e <tail_nodeport_rev_dnat_ipv4+0x22e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222, 0x22e, x86_l_22e);
x86_l_224:
	/* 0x224: cmp    r15d,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_228:
	/* 0x228: jne    dbd <tail_nodeport_rev_dnat_ipv4+0xdbd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x228, 0xdbd, x86_l_dbd);
x86_l_22e:
	/* 0x22e: and    edi,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_231:
	/* 0x231: lea    r10,[rdi*4+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 2), 14ULL);
x86_l_239:
	/* 0x239: mov    r9,QWORD PTR [rip+0xaa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_ipv4_fragments));
x86_l_240:
	/* 0x240: cmp    BYTE PTR [r9],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244:
	/* 0x244: je     31b <tail_nodeport_rev_dnat_ipv4+0x31b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244, 0x31b, x86_l_31b);
x86_l_24a:
	/* 0x24a: mov    DWORD PTR [rsp+0x38],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_24e:
	/* 0x24e: mov    DWORD PTR [rsp+0x3c],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_252:
	/* 0x252: mov    WORD PTR [rsp+0x40],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_258:
	/* 0x258: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: shr    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_25f:
	/* 0x25f: mov    BYTE PTR [rsp+0x42],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 66ULL);
x86_l_263:
	/* 0x263: mov    BYTE PTR [rsp+0x43],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 287762808832ULL);
x86_l_268:
	/* 0x268: test   r13,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26b:
	/* 0x26b: jne    b42 <tail_nodeport_rev_dnat_ipv4+0xb42> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26b, 0xb42, x86_l_b42);
x86_l_271:
	/* 0x271: lea    rdx,[rax+r10*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_275:
	/* 0x275: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_279:
	/* 0x279: mov    ebp,0xffffff79 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967161ULL);
x86_l_27e:
	/* 0x27e: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_281:
	/* 0x281: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x281, 0xaf, x86_l_af);
x86_l_287:
	/* 0x287: add    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28a:
	/* 0x28a: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28c:
	/* 0x28c: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_290:
	/* 0x290: test   r13,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_293:
	/* 0x293: jne    bab <tail_nodeport_rev_dnat_ipv4+0xbab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x293, 0xbab, x86_l_bab);
x86_l_299:
	/* 0x299: movzx  r15d,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_29f:
	/* 0x29f: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_2a3:
	/* 0x2a3: jne    351 <tail_nodeport_rev_dnat_ipv4+0x351> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a3, 0x351, x86_l_351);
x86_l_2a9:
	/* 0x2a9: mov    rdi,QWORD PTR [rip+0xaa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_ct4_global));
x86_l_2b0:
	/* 0x2b0: mov    BYTE PTR [rsp+0x35],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 227633266688ULL);
x86_l_2b5:
	/* 0x2b5: cmp    BYTE PTR [r9],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b9:
	/* 0x2b9: jne    367 <tail_nodeport_rev_dnat_ipv4+0x367> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b9, 0x367, x86_l_367);
x86_l_2bf:
	/* 0x2bf: jmp    3f8 <tail_nodeport_rev_dnat_ipv4+0x3f8> */
	X86_SIM_X86_JMP(0x2bf, 0x3f8, x86_l_3f8);
x86_l_2c4:
	/* 0x2c4: mov    QWORD PTR [rsp+0x50],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383681ULL);
x86_l_2cd:
	/* 0x2cd: mov    QWORD PTR [rsp+0x58],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2d2:
	/* 0x2d2: mov    rdi,QWORD PTR [rip+0xaa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_2d9:
	/* 0x2d9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2de:
	/* 0x2de: lea    rdx,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2e3:
	/* 0x2e3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e5:
	/* 0x2e5: call   d8a <tail_nodeport_rev_dnat_ipv4+0xd8a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2ea:
	/* 0x2ea: mov    rsi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_calls));
x86_l_2f1:
	/* 0x2f1: mov    ebx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2f6:
	/* 0x2f6: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: mov    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2fe:
	/* 0x2fe: call   da7 <tail_nodeport_rev_dnat_ipv4+0xda7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_303:
	/* 0x303: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_305:
	/* 0x305: add    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_30c:
	/* 0x30c: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30d:
	/* 0x30d: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30f:
	/* 0x30f: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_311:
	/* 0x311: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_313:
	/* 0x313: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_315:
	/* 0x315: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_316:
	/* 0x316: jmp    e28 <tail_nodeport_rev_dnat_ipv4+0xe28> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_31b:
	/* 0x31b: test   r13,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_31e:
	/* 0x31e: jne    b6d <tail_nodeport_rev_dnat_ipv4+0xb6d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31e, 0xb6d, x86_l_b6d);
x86_l_324:
	/* 0x324: movzx  edx,r10b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_R10, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_328:
	/* 0x328: lea    rsi,[rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_32c:
	/* 0x32c: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_330:
	/* 0x330: mov    ebp,0xffffff79 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967161ULL);
x86_l_335:
	/* 0x335: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_338:
	/* 0x338: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x338, 0xaf, x86_l_af);
x86_l_33e:
	/* 0x33e: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_341:
	/* 0x341: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_343:
	/* 0x343: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_347:
	/* 0x347: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_34b:
	/* 0x34b: je     2a9 <tail_nodeport_rev_dnat_ipv4+0x2a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34b, 0x2a9, x86_l_2a9);
x86_l_351:
	/* 0x351: mov    rdi,QWORD PTR [rip+0xaa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_ct_any4_global));
x86_l_358:
	/* 0x358: mov    BYTE PTR [rsp+0x35],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 227633266688ULL);
x86_l_35d:
	/* 0x35d: cmp    BYTE PTR [r9],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_361:
	/* 0x361: je     3f8 <tail_nodeport_rev_dnat_ipv4+0x3f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x361, 0x3f8, x86_l_3f8);
x86_l_367:
	/* 0x367: and    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_36a:
	/* 0x36a: je     3f8 <tail_nodeport_rev_dnat_ipv4+0x3f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36a, 0x3f8, x86_l_3f8);
x86_l_370:
	/* 0x370: mov    QWORD PTR [rsp+0x48],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_375:
	/* 0x375: mov    r14,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_378:
	/* 0x378: mov    rbp,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_37b:
	/* 0x37b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_380:
	/* 0x380: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_384:
	/* 0x384: sub    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_387:
	/* 0x387: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_390:
	/* 0x390: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_399:
	/* 0x399: movabs rax,0x6c03a50109 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 463917613321ULL);
x86_l_3a3:
	/* 0x3a3: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3a8:
	/* 0x3a8: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_3af:
	/* 0x3af: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3b4:
	/* 0x3b4: call   e55 <tail_nodeport_rev_dnat_ipv4+0xe55> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3b9:
	/* 0x3b9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bc:
	/* 0x3bc: je     3c7 <tail_nodeport_rev_dnat_ipv4+0x3c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bc, 0x3c7, x86_l_3c7);
x86_l_3be:
	/* 0x3be: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3c1:
	/* 0x3c1: add    QWORD PTR [rax+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_R12, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_3c5:
	/* 0x3c5: jmp    3ed <tail_nodeport_rev_dnat_ipv4+0x3ed> */
	X86_SIM_X86_JMP(0x3c5, 0x3ed, x86_l_3ed);
x86_l_3c7:
	/* 0x3c7: mov    QWORD PTR [rsp+0x10],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476737ULL);
x86_l_3d0:
	/* 0x3d0: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d5:
	/* 0x3d5: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_3dc:
	/* 0x3dc: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3e1:
	/* 0x3e1: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e6:
	/* 0x3e6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e8:
	/* 0x3e8: call   e89 <tail_nodeport_rev_dnat_ipv4+0xe89> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_3ed:
	/* 0x3ed: mov    r10,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3f0:
	/* 0x3f0: mov    r8,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3f3:
	/* 0x3f3: mov    rdi,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3f8:
	/* 0x3f8: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fb:
	/* 0x3fb: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_3ff:
	/* 0x3ff: jne    45a <tail_nodeport_rev_dnat_ipv4+0x45a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ff, 0x45a, x86_l_45a);
x86_l_401:
	/* 0x401: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_404:
	/* 0x404: mov    r12d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_40a:
	/* 0x40a: and    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R8, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_40d:
	/* 0x40d: jne    45d <tail_nodeport_rev_dnat_ipv4+0x45d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40d, 0x45d, x86_l_45d);
x86_l_40f:
	/* 0x40f: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_414:
	/* 0x414: mov    rax,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_417:
	/* 0x417: movzx  ecx,r10b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_R10, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_41b:
	/* 0x41b: lea    rdx,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_41f:
	/* 0x41f: add    rdx,0xe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 14ULL);
x86_l_423:
	/* 0x423: cmp    rdx,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_427:
	/* 0x427: ja     dbd <tail_nodeport_rev_dnat_ipv4+0xdbd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x427, 0xdbd, x86_l_dbd);
x86_l_42d:
	/* 0x42d: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_430:
	/* 0x430: movzx  r14d,WORD PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 12ULL);
x86_l_435:
	/* 0x435: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_438:
	/* 0x438: and    eax,0x1200 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4608ULL);
x86_l_43d:
	/* 0x43d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_440:
	/* 0x440: cmp    eax,0x200 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_445:
	/* 0x445: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_448:
	/* 0x448: test   r14d,0x500 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 1280ULL);
x86_l_44f:
	/* 0x44f: jne    c3d <tail_nodeport_rev_dnat_ipv4+0xc3d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44f, 0xc3d, x86_l_c3d);
x86_l_455:
	/* 0x455: mov    r12b,al */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_458:
	/* 0x458: jmp    45d <tail_nodeport_rev_dnat_ipv4+0x45d> */
	X86_SIM_X86_JMP(0x458, 0x45d, x86_l_45d);
x86_l_45a:
	/* 0x45a: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_45d:
	/* 0x45d: mov    QWORD PTR [rsp+0x48],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_462:
	/* 0x462: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_467:
	/* 0x467: call   f08 <tail_nodeport_rev_dnat_ipv4+0xf08> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_46c:
	/* 0x46c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_46f:
	/* 0x46f: je     db4 <tail_nodeport_rev_dnat_ipv4+0xdb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46f, 0xdb4, x86_l_db4);
x86_l_475:
	/* 0x475: movzx  ecx,WORD PTR [rax+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_479:
	/* 0x479: test   cl,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_47c:
	/* 0x47c: je     db4 <tail_nodeport_rev_dnat_ipv4+0xdb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47c, 0xdb4, x86_l_db4);
x86_l_482:
	/* 0x482: cmp    WORD PTR [rax+0x26],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 163208757248ULL);
x86_l_487:
	/* 0x487: je     db4 <tail_nodeport_rev_dnat_ipv4+0xdb4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x487, 0xdb4, x86_l_db4);
x86_l_48d:
	/* 0x48d: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_48f:
	/* 0x48f: not    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_491:
	/* 0x491: test   dl,0x3 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_494:
	/* 0x494: mov    r8,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_trace_payload_len));
x86_l_49b:
	/* 0x49b: je     5aa <tail_nodeport_rev_dnat_ipv4+0x5aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49b, 0x5aa, x86_l_5aa);
x86_l_4a1:
	/* 0x4a1: mov    DWORD PTR [rsp+0x24],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4a6:
	/* 0x4a6: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_jiffies));
x86_l_4ad:
	/* 0x4ad: cmp    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b0:
	/* 0x4b0: je     4c3 <tail_nodeport_rev_dnat_ipv4+0x4c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b0, 0x4c3, x86_l_4c3);
x86_l_4b2:
	/* 0x4b2: mov    rdx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_4b9:
	/* 0x4b9: imul   r14d,DWORD PTR [rdx],0x3c */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 60ULL);
x86_l_4bd:
	/* 0x4bd: shr    r14d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_4c1:
	/* 0x4c1: jmp    4c9 <tail_nodeport_rev_dnat_ipv4+0x4c9> */
	X86_SIM_X86_JMP(0x4c1, 0x4c9, x86_l_4c9);
x86_l_4c3:
	/* 0x4c3: mov    r14d,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_4c9:
	/* 0x4c9: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_4cd:
	/* 0x4cd: jne    506 <tail_nodeport_rev_dnat_ipv4+0x506> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4cd, 0x506, x86_l_506);
x86_l_4cf:
	/* 0x4cf: mov    edx,DWORD PTR [rsp+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4d3:
	/* 0x4d3: not    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_4d5:
	/* 0x4d5: shr    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 5ULL);
x86_l_4d8:
	/* 0x4d8: and    edx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16ULL);
x86_l_4db:
	/* 0x4db: or     ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_4dd:
	/* 0x4dd: mov    WORD PTR [rax+0x24],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4e1:
	/* 0x4e1: mov    r14d,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_4e7:
	/* 0x4e7: test   cl,0x10 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 16ULL);
x86_l_4ea:
	/* 0x4ea: je     4f2 <tail_nodeport_rev_dnat_ipv4+0x4f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ea, 0x4f2, x86_l_4f2);
x86_l_4ec:
	/* 0x4ec: mov    r14d,0x5460 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 21600ULL);
x86_l_4f2:
	/* 0x4f2: cmp    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f5:
	/* 0x4f5: je     506 <tail_nodeport_rev_dnat_ipv4+0x506> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f5, 0x506, x86_l_506);
x86_l_4f7:
	/* 0x4f7: mov    rcx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_4fe:
	/* 0x4fe: imul   r14d,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RCX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_IMUL)), 0ULL);
x86_l_502:
	/* 0x502: shr    r14d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_506:
	/* 0x506: movzx  ebp,WORD PTR [rsp+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_50b:
	/* 0x50b: shr    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_50e:
	/* 0x50e: cmp    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_511:
	/* 0x511: je     523 <tail_nodeport_rev_dnat_ipv4+0x523> */
	X86_SIM_X86_JCC(X86_CC_E, 0x511, 0x523, x86_l_523);
x86_l_513:
	/* 0x513: mov    rcx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&jiffies_64));
x86_l_51a:
	/* 0x51a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51d:
	/* 0x51d: shr    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_521:
	/* 0x521: jmp    560 <tail_nodeport_rev_dnat_ipv4+0x560> */
	X86_SIM_X86_JMP(0x521, 0x560, x86_l_560);
x86_l_523:
	/* 0x523: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_52b:
	/* 0x52b: call   fcc <tail_nodeport_rev_dnat_ipv4+0xfcc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_530:
	/* 0x530: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_jiffies));
x86_l_537:
	/* 0x537: mov    r8,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_trace_payload_len));
x86_l_53e:
	/* 0x53e: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_541:
	/* 0x541: mov    rax,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_549:
	/* 0x549: shr    rdx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 9ULL);
x86_l_54d:
	/* 0x54d: movabs rcx,0x44b82fa09b5a53 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 19342813113834067ULL);
x86_l_557:
	/* 0x557: mulx   rcx,rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RCX, 0);
x86_l_55c:
	/* 0x55c: shr    rcx,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 11ULL);
x86_l_560:
	/* 0x560: add    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_563:
	/* 0x563: mov    DWORD PTR [rax+0x20],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_567:
	/* 0x567: movzx  edx,BYTE PTR [rax+0x2b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 43ULL);
x86_l_56b:
	/* 0x56b: mov    esi,DWORD PTR [rax+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_56e:
	/* 0x56e: and    bpl,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 7ULL);
x86_l_572:
	/* 0x572: cmp    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_575:
	/* 0x575: je     588 <tail_nodeport_rev_dnat_ipv4+0x588> */
	X86_SIM_X86_JCC(X86_CC_E, 0x575, 0x588, x86_l_588);
x86_l_577:
	/* 0x577: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_57e:
	/* 0x57e: mov    edi,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_580:
	/* 0x580: lea    edi,[rdi+rdi*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 2), 0ULL);
x86_l_583:
	/* 0x583: shr    edi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_586:
	/* 0x586: jmp    58d <tail_nodeport_rev_dnat_ipv4+0x58d> */
	X86_SIM_X86_JMP(0x586, 0x58d, x86_l_58d);
x86_l_588:
	/* 0x588: mov    edi,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_58d:
	/* 0x58d: mov    r14d,DWORD PTR [rsp+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_592:
	/* 0x592: add    edi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_594:
	/* 0x594: or     bpl,dl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_597:
	/* 0x597: cmp    edi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_599:
	/* 0x599: jb     5a0 <tail_nodeport_rev_dnat_ipv4+0x5a0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x599, 0x5a0, x86_l_5a0);
x86_l_59b:
	/* 0x59b: cmp    dl,bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_59e:
	/* 0x59e: je     5aa <tail_nodeport_rev_dnat_ipv4+0x5aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59e, 0x5aa, x86_l_5aa);
x86_l_5a0:
	/* 0x5a0: mov    BYTE PTR [rax+0x2b],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 43ULL);
x86_l_5a4:
	/* 0x5a4: mov    DWORD PTR [rax+0x34],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_5a7:
	/* 0x5a7: mov    ecx,DWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aa:
	/* 0x5aa: mov    rcx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_conntrack_accounting));
x86_l_5b1:
	/* 0x5b1: cmp    BYTE PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b4:
	/* 0x5b4: je     5cc <tail_nodeport_rev_dnat_ipv4+0x5cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b4, 0x5cc, x86_l_5cc);
x86_l_5b6:
	/* 0x5b6: lock inc QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 16ULL);
x86_l_5bb:
	/* 0x5bb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c0:
	/* 0x5c0: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c4:
	/* 0x5c4: sub    rcx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RDX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_5c7:
	/* 0x5c7: lock add QWORD PTR [rax+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RCX, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 24ULL);
x86_l_5cc:
	/* 0x5cc: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5d0:
	/* 0x5d0: je     625 <tail_nodeport_rev_dnat_ipv4+0x625> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d0, 0x625, x86_l_625);
x86_l_5d2:
	/* 0x5d2: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5d6:
	/* 0x5d6: jne    700 <tail_nodeport_rev_dnat_ipv4+0x700> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5d6, 0x700, x86_l_700);
x86_l_5dc:
	/* 0x5dc: movzx  ecx,WORD PTR [rax+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_5e0:
	/* 0x5e0: test   cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_5e3:
	/* 0x5e3: je     700 <tail_nodeport_rev_dnat_ipv4+0x700> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5e3, 0x700, x86_l_700);
x86_l_5e9:
	/* 0x5e9: mov    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_5ec:
	/* 0x5ec: mov    WORD PTR [rax+0x2a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 180388626432ULL);
x86_l_5f2:
	/* 0x5f2: and    ecx,0xffec */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 65516ULL);
x86_l_5f8:
	/* 0x5f8: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5fb:
	/* 0x5fb: mov    WORD PTR [rax+0x24],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_5ff:
	/* 0x5ff: mov    r12,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_jiffies));
x86_l_606:
	/* 0x606: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60b:
	/* 0x60b: je     ceb <tail_nodeport_rev_dnat_ipv4+0xceb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60b, 0xceb, x86_l_ceb);
x86_l_611:
	/* 0x611: mov    rax,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_618:
	/* 0x618: imul   r13d,DWORD PTR [rax],0x3c */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 60ULL);
x86_l_61c:
	/* 0x61c: shr    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_620:
	/* 0x620: jmp    cf1 <tail_nodeport_rev_dnat_ipv4+0xcf1> */
	X86_SIM_X86_JMP(0x620, 0xcf1, x86_l_cf1);
x86_l_625:
	/* 0x625: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_628:
	/* 0x628: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_62b:
	/* 0x62b: and    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2ULL);
x86_l_62e:
	/* 0x62e: or     cx,WORD PTR [rax+0x24] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 36ULL);
x86_l_632:
	/* 0x632: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_634:
	/* 0x634: or     edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 1ULL);
x86_l_637:
	/* 0x637: mov    WORD PTR [rax+0x24],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_63b:
	/* 0x63b: mov    edx,DWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_63e:
	/* 0x63e: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_641:
	/* 0x641: je     700 <tail_nodeport_rev_dnat_ipv4+0x700> */
	X86_SIM_X86_JCC(X86_CC_E, 0x641, 0x700, x86_l_700);
x86_l_647:
	/* 0x647: mov    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_64a:
	/* 0x64a: mov    r14,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_jiffies));
x86_l_651:
	/* 0x651: cmp    BYTE PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_655:
	/* 0x655: je     66c <tail_nodeport_rev_dnat_ipv4+0x66c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x655, 0x66c, x86_l_66c);
x86_l_657:
	/* 0x657: mov    rcx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_65e:
	/* 0x65e: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_660:
	/* 0x660: add    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_662:
	/* 0x662: lea    r15d,[rcx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_666:
	/* 0x666: shr    r15d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_66a:
	/* 0x66a: jmp    672 <tail_nodeport_rev_dnat_ipv4+0x672> */
	X86_SIM_X86_JMP(0x66a, 0x672, x86_l_672);
x86_l_66c:
	/* 0x66c: mov    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_672:
	/* 0x672: movzx  ebp,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RBP, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_675:
	/* 0x675: shr    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_678:
	/* 0x678: cmp    BYTE PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_67c:
	/* 0x67c: je     68e <tail_nodeport_rev_dnat_ipv4+0x68e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67c, 0x68e, x86_l_68e);
x86_l_67e:
	/* 0x67e: mov    rcx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&jiffies_64));
x86_l_685:
	/* 0x685: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_688:
	/* 0x688: shr    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_68c:
	/* 0x68c: jmp    6ba <tail_nodeport_rev_dnat_ipv4+0x6ba> */
	X86_SIM_X86_JMP(0x68c, 0x6ba, x86_l_6ba);
x86_l_68e:
	/* 0x68e: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_691:
	/* 0x691: call   1132 <tail_nodeport_rev_dnat_ipv4+0x1132> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_696:
	/* 0x696: mov    r8,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_trace_payload_len));
x86_l_69d:
	/* 0x69d: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a0:
	/* 0x6a0: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6a3:
	/* 0x6a3: shr    rdx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 9ULL);
x86_l_6a7:
	/* 0x6a7: movabs rcx,0x44b82fa09b5a53 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 19342813113834067ULL);
x86_l_6b1:
	/* 0x6b1: mulx   rcx,rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_RCX, 0);
x86_l_6b6:
	/* 0x6b6: shr    rcx,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 11ULL);
x86_l_6ba:
	/* 0x6ba: add    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_6bd:
	/* 0x6bd: mov    DWORD PTR [rax+0x20],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6c1:
	/* 0x6c1: movzx  edx,BYTE PTR [rax+0x2b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 43ULL);
x86_l_6c5:
	/* 0x6c5: mov    esi,DWORD PTR [rax+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_6c8:
	/* 0x6c8: and    bpl,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 7ULL);
x86_l_6cc:
	/* 0x6cc: cmp    BYTE PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d0:
	/* 0x6d0: je     6e3 <tail_nodeport_rev_dnat_ipv4+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d0, 0x6e3, x86_l_6e3);
x86_l_6d2:
	/* 0x6d2: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_6d9:
	/* 0x6d9: mov    edi,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6db:
	/* 0x6db: lea    edi,[rdi+rdi*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 2), 0ULL);
x86_l_6de:
	/* 0x6de: shr    edi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_6e1:
	/* 0x6e1: jmp    6e8 <tail_nodeport_rev_dnat_ipv4+0x6e8> */
	X86_SIM_X86_JMP(0x6e1, 0x6e8, x86_l_6e8);
x86_l_6e3:
	/* 0x6e3: mov    edi,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_6e8:
	/* 0x6e8: add    edi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_6ea:
	/* 0x6ea: or     bpl,dl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_6ed:
	/* 0x6ed: cmp    edi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6ef:
	/* 0x6ef: jb     6f6 <tail_nodeport_rev_dnat_ipv4+0x6f6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6ef, 0x6f6, x86_l_6f6);
x86_l_6f1:
	/* 0x6f1: cmp    dl,bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_6f4:
	/* 0x6f4: je     700 <tail_nodeport_rev_dnat_ipv4+0x700> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f4, 0x700, x86_l_700);
x86_l_6f6:
	/* 0x6f6: mov    BYTE PTR [rax+0x2b],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 43ULL);
x86_l_6fa:
	/* 0x6fa: mov    DWORD PTR [rax+0x34],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_6fd:
	/* 0x6fd: mov    ecx,DWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_700:
	/* 0x700: test   BYTE PTR [rsp+0x35],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 227633266690ULL);
x86_l_705:
	/* 0x705: jne    dbd <tail_nodeport_rev_dnat_ipv4+0xdbd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x705, 0xdbd, x86_l_dbd);
x86_l_70b:
	/* 0x70b: movzx  eax,WORD PTR [rax+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_70f:
	/* 0x70f: mov    WORD PTR [rsp+0x10],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_714:
	/* 0x714: mov    rbx,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_debug_lb));
x86_l_71b:
	/* 0x71b: movzx  eax,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_71e:
	/* 0x71e: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_lb4_reverse_nat));
x86_l_725:
	/* 0x725: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72a:
	/* 0x72a: call   11cb <tail_nodeport_rev_dnat_ipv4+0x11cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_72f:
	/* 0x72f: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_734:
	/* 0x734: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_737:
	/* 0x737: mov    rcx,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_73b:
	/* 0x73b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73e:
	/* 0x73e: je     83b <tail_nodeport_rev_dnat_ipv4+0x83b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73e, 0x83b, x86_l_83b);
x86_l_744:
	/* 0x744: mov    edx,DWORD PTR [rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_748:
	/* 0x748: movzx  esi,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_74b:
	/* 0x74b: mov    esi,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_74d:
	/* 0x74d: mov    DWORD PTR [rsp+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_751:
	/* 0x751: lea    rsi,[r15+0x1e] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_755:
	/* 0x755: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_758:
	/* 0x758: jbe    767 <tail_nodeport_rev_dnat_ipv4+0x767> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x758, 0x767, x86_l_767);
x86_l_75a:
	/* 0x75a: mov    ebp,0xffffff73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967155ULL);
x86_l_75f:
	/* 0x75f: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_762:
	/* 0x762: jmp    af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JMP(0x762, 0xaf, x86_l_af);
x86_l_767:
	/* 0x767: mov    esi,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_769:
	/* 0x769: not    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_76b:
	/* 0x76b: add    edx,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_76d:
	/* 0x76d: adc    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_770:
	/* 0x770: movzx  edi,WORD PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_775:
	/* 0x775: not    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_777:
	/* 0x777: add    edi,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_779:
	/* 0x779: adc    edi,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_77c:
	/* 0x77c: movzx  r8d,di */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RDI, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_780:
	/* 0x780: shr    edi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_783:
	/* 0x783: add    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_786:
	/* 0x786: mov    r8d,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_789:
	/* 0x789: shr    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_78d:
	/* 0x78d: add    r8d,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RDI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_790:
	/* 0x790: mov    DWORD PTR [r15+0x1a],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_794:
	/* 0x794: not    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_797:
	/* 0x797: mov    WORD PTR [r15+0x18],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_79c:
	/* 0x79c: movabs rsi,0x20000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 2199023255552ULL);
x86_l_7a6:
	/* 0x7a6: test   r13,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_7a9:
	/* 0x7a9: jne    83b <tail_nodeport_rev_dnat_ipv4+0x83b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7a9, 0x83b, x86_l_83b);
x86_l_7af:
	/* 0x7af: movzx  r11d,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_7b5:
	/* 0x7b5: mov    sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_7b8:
	/* 0x7b8: cmp    r11d,0x3a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 58ULL);
x86_l_7bc:
	/* 0x7bc: je     7dd <tail_nodeport_rev_dnat_ipv4+0x7dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7bc, 0x7dd, x86_l_7dd);
x86_l_7be:
	/* 0x7be: cmp    r11d,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_7c2:
	/* 0x7c2: je     7d1 <tail_nodeport_rev_dnat_ipv4+0x7d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c2, 0x7d1, x86_l_7d1);
x86_l_7c4:
	/* 0x7c4: cmp    r11d,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_7c8:
	/* 0x7c8: jne    7e7 <tail_nodeport_rev_dnat_ipv4+0x7e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7c8, 0x7e7, x86_l_7e7);
x86_l_7ca:
	/* 0x7ca: mov    edi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_7cf:
	/* 0x7cf: jmp    7e2 <tail_nodeport_rev_dnat_ipv4+0x7e2> */
	X86_SIM_X86_JMP(0x7cf, 0x7e2, x86_l_7e2);
x86_l_7d1:
	/* 0x7d1: mov    edi,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_7d6:
	/* 0x7d6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d9:
	/* 0x7d9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7db:
	/* 0x7db: jmp    7ec <tail_nodeport_rev_dnat_ipv4+0x7ec> */
	X86_SIM_X86_JMP(0x7db, 0x7ec, x86_l_7ec);
x86_l_7dd:
	/* 0x7dd: mov    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7e2:
	/* 0x7e2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7e5:
	/* 0x7e5: jmp    7ec <tail_nodeport_rev_dnat_ipv4+0x7ec> */
	X86_SIM_X86_JMP(0x7e5, 0x7ec, x86_l_7ec);
x86_l_7e7:
	/* 0x7e7: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7e9:
	/* 0x7e9: mov    r8b,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_7ec:
	/* 0x7ec: movzx  r9d,WORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_7f1:
	/* 0x7f1: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_7f4:
	/* 0x7f4: je     832 <tail_nodeport_rev_dnat_ipv4+0x832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f4, 0x832, x86_l_832);
x86_l_7f6:
	/* 0x7f6: movzx  r10d,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_7fc:
	/* 0x7fc: mov    ebx,0xffffff72 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967154ULL);
x86_l_801:
	/* 0x801: cmp    r11d,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_805:
	/* 0x805: jg     818 <tail_nodeport_rev_dnat_ipv4+0x818> */
	X86_SIM_X86_JCC(X86_CC_G, 0x805, 0x818, x86_l_818);
x86_l_807:
	/* 0x807: cmp    r11d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_80b:
	/* 0x80b: je     832 <tail_nodeport_rev_dnat_ipv4+0x832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x80b, 0x832, x86_l_832);
x86_l_80d:
	/* 0x80d: cmp    r11d,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_811:
	/* 0x811: je     828 <tail_nodeport_rev_dnat_ipv4+0x828> */
	X86_SIM_X86_JCC(X86_CC_E, 0x811, 0x828, x86_l_828);
x86_l_813:
	/* 0x813: jmp    ac0 <tail_nodeport_rev_dnat_ipv4+0xac0> */
	X86_SIM_X86_JMP(0x813, 0xac0, x86_l_ac0);
x86_l_818:
	/* 0x818: cmp    r11d,0x3a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 58ULL);
x86_l_81c:
	/* 0x81c: je     832 <tail_nodeport_rev_dnat_ipv4+0x832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x81c, 0x832, x86_l_832);
x86_l_81e:
	/* 0x81e: cmp    r11d,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_822:
	/* 0x822: jne    ac0 <tail_nodeport_rev_dnat_ipv4+0xac0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x822, 0xac0, x86_l_ac0);
x86_l_828:
	/* 0x828: cmp    r9w,r10w */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_R10, X86_WIDTH_16, 0, 0);
x86_l_82c:
	/* 0x82c: jne    a86 <tail_nodeport_rev_dnat_ipv4+0xa86> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x82c, 0xa86, x86_l_a86);
x86_l_832:
	/* 0x832: test   r8b,r8b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_8, 0, 0);
x86_l_835:
	/* 0x835: je     a08 <tail_nodeport_rev_dnat_ipv4+0xa08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x835, 0xa08, x86_l_a08);
x86_l_83b:
	/* 0x83b: lea    rax,[r15+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_83f:
	/* 0x83f: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_842:
	/* 0x842: mov    ebp,0xffffff7a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967162ULL);
x86_l_847:
	/* 0x847: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_84a:
	/* 0x84a: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x84a, 0xaf, x86_l_af);
x86_l_850:
	/* 0x850: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_858:
	/* 0x858: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_85f:
	/* 0x85f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_864:
	/* 0x864: call   1305 <tail_nodeport_rev_dnat_ipv4+0x1305> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_869:
	/* 0x869: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86c:
	/* 0x86c: je     ce4 <tail_nodeport_rev_dnat_ipv4+0xce4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x86c, 0xce4, x86_l_ce4);
x86_l_872:
	/* 0x872: mov    ebx,DWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_875:
	/* 0x875: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_87d:
	/* 0x87d: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_884:
	/* 0x884: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_889:
	/* 0x889: call   132a <tail_nodeport_rev_dnat_ipv4+0x132a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_88e:
	/* 0x88e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_891:
	/* 0x891: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_896:
	/* 0x896: je     89e <tail_nodeport_rev_dnat_ipv4+0x89e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x896, 0x89e, x86_l_89e);
x86_l_898:
	/* 0x898: or     ebx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_89b:
	/* 0x89b: mov    DWORD PTR [rax+0x18],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_89e:
	/* 0x89e: mov    eax,DWORD PTR [r15+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_8a2:
	/* 0x8a2: mov    DWORD PTR [rsp+0x60],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8a6:
	/* 0x8a6: mov    eax,DWORD PTR [r15+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_8aa:
	/* 0x8aa: mov    DWORD PTR [rsp+0x70],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8ae:
	/* 0x8ae: movzx  ecx,BYTE PTR [r15+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_8b3:
	/* 0x8b3: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8b6:
	/* 0x8b6: mov    ebp,0xffffff3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967100ULL);
x86_l_8bb:
	/* 0x8bb: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_8be:
	/* 0x8be: jb     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8be, 0xaf, x86_l_af);
x86_l_8c4:
	/* 0x8c4: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_8c7:
	/* 0x8c7: mov    BYTE PTR [r15+0x16],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_8cb:
	/* 0x8cb: mov    rax,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8ce:
	/* 0x8ce: lea    rsi,[rax+0x1a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_8d2:
	/* 0x8d2: mov    ebp,0xffffff67 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967143ULL);
x86_l_8d7:
	/* 0x8d7: cmp    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_8db:
	/* 0x8db: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8db, 0xaf, x86_l_af);
x86_l_8e1:
	/* 0x8e1: movzx  edx,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_8e4:
	/* 0x8e4: not    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_8e6:
	/* 0x8e6: add    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_8e8:
	/* 0x8e8: adc    ecx,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_8eb:
	/* 0x8eb: movzx  edx,WORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_8ef:
	/* 0x8ef: not    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_8f1:
	/* 0x8f1: add    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_8f3:
	/* 0x8f3: adc    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_8f6:
	/* 0x8f6: movzx  ecx,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_8f9:
	/* 0x8f9: shr    edx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_8fc:
	/* 0x8fc: add    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_8fe:
	/* 0x8fe: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_900:
	/* 0x900: shr    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_903:
	/* 0x903: add    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_905:
	/* 0x905: not    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_907:
	/* 0x907: mov    WORD PTR [rax+0x18],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_90b:
	/* 0x90b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_910:
	/* 0x910: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_915:
	/* 0x915: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_918:
	/* 0x918: mov    edx,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_91d:
	/* 0x91d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_91f:
	/* 0x91f: call   13c0 <tail_nodeport_rev_dnat_ipv4+0x13c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_fib_lookup);
x86_l_924:
	/* 0x924: mov    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_927:
	/* 0x927: mov    ebp,0xffffff57 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967127ULL);
x86_l_92c:
	/* 0x92c: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_92f:
	/* 0x92f: je     93a <tail_nodeport_rev_dnat_ipv4+0x93a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x92f, 0x93a, x86_l_93a);
x86_l_931:
	/* 0x931: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_934:
	/* 0x934: jne    af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x934, 0xaf, x86_l_af);
x86_l_93a:
	/* 0x93a: mov    ebx,DWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_93e:
	/* 0x93e: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_942:
	/* 0x942: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_devices));
x86_l_949:
	/* 0x949: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_94e:
	/* 0x94e: call   13ef <tail_nodeport_rev_dnat_ipv4+0x13ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_953:
	/* 0x953: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_956:
	/* 0x956: je     962 <tail_nodeport_rev_dnat_ipv4+0x962> */
	X86_SIM_X86_JCC(X86_CC_E, 0x956, 0x962, x86_l_962);
x86_l_958:
	/* 0x958: test   BYTE PTR [rax+0x8],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738369ULL);
x86_l_95c:
	/* 0x95c: jne    b22 <tail_nodeport_rev_dnat_ipv4+0xb22> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x95c, 0xb22, x86_l_b22);
x86_l_962:
	/* 0x962: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_965:
	/* 0x965: je     ac8 <tail_nodeport_rev_dnat_ipv4+0xac8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x965, 0xac8, x86_l_ac8);
x86_l_96b:
	/* 0x96b: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_96f:
	/* 0x96f: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_devices));
x86_l_976:
	/* 0x976: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_97b:
	/* 0x97b: call   141c <tail_nodeport_rev_dnat_ipv4+0x141c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_980:
	/* 0x980: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_983:
	/* 0x983: jne    98c <tail_nodeport_rev_dnat_ipv4+0x98c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x983, 0x98c, x86_l_98c);
x86_l_985:
	/* 0x985: lea    rax,[rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_98c:
	/* 0x98c: mov    r14d,0x64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 100ULL);
x86_l_992:
	/* 0x992: cmp    BYTE PTR [rsp+0x50],0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 343597383682ULL);
x86_l_997:
	/* 0x997: jne    af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x997, 0xaf, x86_l_af);
x86_l_99d:
	/* 0x99d: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9a0:
	/* 0x9a0: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_9a5:
	/* 0x9a5: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_nodeport_neigh4));
x86_l_9ac:
	/* 0x9ac: call   144d <tail_nodeport_rev_dnat_ipv4+0x144d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9b1:
	/* 0x9b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9b4:
	/* 0x9b4: je     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b4, 0xaf, x86_l_af);
x86_l_9ba:
	/* 0x9ba: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9bf:
	/* 0x9bf: mov    rcx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9c2:
	/* 0x9c2: mov    rdx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9c6:
	/* 0x9c6: lea    rsi,[rcx+0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_9ca:
	/* 0x9ca: mov    ebp,0xffffff73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967155ULL);
x86_l_9cf:
	/* 0x9cf: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9d2:
	/* 0x9d2: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9d5:
	/* 0x9d5: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9d5, 0xaf, x86_l_af);
x86_l_9db:
	/* 0x9db: movzx  esi,WORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_9df:
	/* 0x9df: mov    WORD PTR [rcx+0x4],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9e3:
	/* 0x9e3: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9e5:
	/* 0x9e5: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9e7:
	/* 0x9e7: lea    rax,[rcx+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9eb:
	/* 0x9eb: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9ee:
	/* 0x9ee: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9ee, 0xaf, x86_l_af);
x86_l_9f4:
	/* 0x9f4: movzx  eax,WORD PTR [r15+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_9f9:
	/* 0x9f9: mov    WORD PTR [rcx+0xa],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 10ULL);
x86_l_9fd:
	/* 0x9fd: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a00:
	/* 0xa00: mov    DWORD PTR [rcx+0x6],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_a03:
	/* 0xa03: jmp    b1d <tail_nodeport_rev_dnat_ipv4+0xb1d> */
	X86_SIM_X86_JMP(0xa03, 0xb1d, x86_l_b1d);
x86_l_a08:
	/* 0xa08: movzx  eax,BYTE PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 72ULL);
x86_l_a0d:
	/* 0xa0d: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a10:
	/* 0xa10: lea    r8,[rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_a14:
	/* 0xa14: add    r8,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_a18:
	/* 0xa18: mov    ebx,0xffffff66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967142ULL);
x86_l_a1d:
	/* 0xa1d: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a20:
	/* 0xa20: ja     ac0 <tail_nodeport_rev_dnat_ipv4+0xac0> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa20, 0xac0, x86_l_ac0);
x86_l_a26:
	/* 0xa26: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a29:
	/* 0xa29: movzx  eax,WORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_a2c:
	/* 0xa2c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a2e:
	/* 0xa2e: setne  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_a32:
	/* 0xa32: or     r8b,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_a35:
	/* 0xa35: cmp    r8b,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a39:
	/* 0xa39: jne    83b <tail_nodeport_rev_dnat_ipv4+0x83b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa39, 0x83b, x86_l_83b);
x86_l_a3f:
	/* 0xa3f: not    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_a41:
	/* 0xa41: add    edx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_a43:
	/* 0xa43: adc    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_a46:
	/* 0xa46: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_a49:
	/* 0xa49: shr    edx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_a4c:
	/* 0xa4c: add    edx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_a4e:
	/* 0xa4e: mov    r8d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_a51:
	/* 0xa51: shr    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_a55:
	/* 0xa55: add    r8d,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_a58:
	/* 0xa58: mov    eax,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_a5b:
	/* 0xa5b: not    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_a5d:
	/* 0xa5d: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a5f:
	/* 0xa5f: cmp    r8w,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_16, 0, 65535ULL);
x86_l_a64:
	/* 0xa64: jne    a6b <tail_nodeport_rev_dnat_ipv4+0xa6b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa64, 0xa6b, x86_l_a6b);
x86_l_a66:
	/* 0xa66: mov    ecx,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_a6b:
	/* 0xa6b: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_a6e:
	/* 0xa6e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a73:
	/* 0xa73: jne    a77 <tail_nodeport_rev_dnat_ipv4+0xa77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa73, 0xa77, x86_l_a77);
x86_l_a75:
	/* 0xa75: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a77:
	/* 0xa77: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a7a:
	/* 0xa7a: mov    r15,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a7d:
	/* 0xa7d: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a81:
	/* 0xa81: jmp    83b <tail_nodeport_rev_dnat_ipv4+0x83b> */
	X86_SIM_X86_JMP(0xa81, 0x83b, x86_l_83b);
x86_l_a86:
	/* 0xa86: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_a8b:
	/* 0xa8b: add    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a8e:
	/* 0xa8e: add    rax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_a92:
	/* 0xa92: mov    ebx,0xffffff73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967155ULL);
x86_l_a97:
	/* 0xa97: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a9a:
	/* 0xa9a: ja     ac0 <tail_nodeport_rev_dnat_ipv4+0xac0> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa9a, 0xac0, x86_l_ac0);
x86_l_a9c:
	/* 0xa9c: mov    r11,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_aa1:
	/* 0xaa1: lea    rax,[r15+r11*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_aa5:
	/* 0xaa5: mov    WORD PTR [r15+r11*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_aaa:
	/* 0xaaa: lea    r11,[rdi+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_aae:
	/* 0xaae: add    r11,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_ab2:
	/* 0xab2: mov    ebx,0xffffff66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967142ULL);
x86_l_ab7:
	/* 0xab7: cmp    r11,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_aba:
	/* 0xaba: jbe    b77 <tail_nodeport_rev_dnat_ipv4+0xb77> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xaba, 0xb77, x86_l_b77);
x86_l_ac0:
	/* 0xac0: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac3:
	/* 0xac3: jmp    b9 <tail_nodeport_rev_dnat_ipv4+0xb9> */
	X86_SIM_X86_JMP(0xac3, 0xb9, x86_l_b9);
x86_l_ac8:
	/* 0xac8: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_acb:
	/* 0xacb: lea    rcx,[rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_acf:
	/* 0xacf: mov    ebp,0xffffff73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967155ULL);
x86_l_ad4:
	/* 0xad4: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ad7:
	/* 0xad7: cmp    rcx,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_adb:
	/* 0xadb: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0xadb, 0xaf, x86_l_af);
x86_l_ae1:
	/* 0xae1: movzx  ecx,WORD PTR [rsp+0x8e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 142ULL);
x86_l_ae9:
	/* 0xae9: mov    WORD PTR [rax+0x4],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_aed:
	/* 0xaed: mov    ecx,DWORD PTR [rsp+0x8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 138ULL);
x86_l_af4:
	/* 0xaf4: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af6:
	/* 0xaf6: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af9:
	/* 0xaf9: lea    rcx,[rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_afd:
	/* 0xafd: cmp    rcx,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_b01:
	/* 0xb01: ja     af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb01, 0xaf, x86_l_af);
x86_l_b07:
	/* 0xb07: movzx  ecx,WORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 136ULL);
x86_l_b0f:
	/* 0xb0f: mov    WORD PTR [rax+0xa],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 10ULL);
x86_l_b13:
	/* 0xb13: mov    ecx,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_b1a:
	/* 0xb1a: mov    DWORD PTR [rax+0x6],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_b1d:
	/* 0xb1d: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b22:
	/* 0xb22: cmp    DWORD PTR [r15+0xc],ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b26:
	/* 0xb26: jne    b32 <tail_nodeport_rev_dnat_ipv4+0xb32> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb26, 0xb32, x86_l_b32);
x86_l_b28:
	/* 0xb28: mov    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_b2d:
	/* 0xb2d: jmp    303 <tail_nodeport_rev_dnat_ipv4+0x303> */
	X86_SIM_X86_JMP(0xb2d, 0x303, x86_l_303);
x86_l_b32:
	/* 0xb32: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_b34:
	/* 0xb34: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b36:
	/* 0xb36: call   15d7 <tail_nodeport_rev_dnat_ipv4+0x15d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_redirect);
x86_l_b3b:
	/* 0xb3b: mov    ebx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_b3d:
	/* 0xb3d: jmp    dbd <tail_nodeport_rev_dnat_ipv4+0xdbd> */
	X86_SIM_X86_JMP(0xb3d, 0xdbd, x86_l_dbd);
x86_l_b42:
	/* 0xb42: mov    rbp,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_b45:
	/* 0xb45: mov    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_b48:
	/* 0xb48: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_ipv4_frag_datagrams));
x86_l_b4f:
	/* 0xb4f: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_b54:
	/* 0xb54: call   15f5 <tail_nodeport_rev_dnat_ipv4+0x15f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b59:
	/* 0xb59: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5c:
	/* 0xb5c: je     c33 <tail_nodeport_rev_dnat_ipv4+0xc33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5c, 0xc33, x86_l_c33);
x86_l_b62:
	/* 0xb62: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b64:
	/* 0xb64: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b68:
	/* 0xb68: jmp    cc2 <tail_nodeport_rev_dnat_ipv4+0xcc2> */
	X86_SIM_X86_JMP(0xb68, 0xcc2, x86_l_cc2);
x86_l_b6d:
	/* 0xb6d: mov    ebp,0xffffff63 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967139ULL);
x86_l_b72:
	/* 0xb72: jmp    af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JMP(0xb72, 0xaf, x86_l_af);
x86_l_b77:
	/* 0xb77: add    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b7a:
	/* 0xb7a: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_b7d:
	/* 0xb7d: jne    b89 <tail_nodeport_rev_dnat_ipv4+0xb89> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb7d, 0xb89, x86_l_b89);
x86_l_b7f:
	/* 0xb7f: cmp    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b83:
	/* 0xb83: je     832 <tail_nodeport_rev_dnat_ipv4+0x832> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb83, 0x832, x86_l_832);
x86_l_b89:
	/* 0xb89: test   r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_b8c:
	/* 0xb8c: je     c48 <tail_nodeport_rev_dnat_ipv4+0xc48> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8c, 0xc48, x86_l_c48);
x86_l_b92:
	/* 0xb92: not    r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_b95:
	/* 0xb95: add    r10d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R9, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_b98:
	/* 0xb98: adc    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADC, 0ULL);
x86_l_b9c:
	/* 0xb9c: movzx  r11d,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_ba0:
	/* 0xba0: not    r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_ba3:
	/* 0xba3: add    r11d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R10, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_ba6:
	/* 0xba6: jmp    c52 <tail_nodeport_rev_dnat_ipv4+0xc52> */
	X86_SIM_X86_JMP(0xba6, 0xc52, x86_l_c52);
x86_l_bab:
	/* 0xbab: lea    rdx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bb0:
	/* 0xbb0: mov    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_bb3:
	/* 0xbb3: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_ipv4_frag_datagrams));
x86_l_bba:
	/* 0xbba: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_bbf:
	/* 0xbbf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bc1:
	/* 0xbc1: mov    rbp,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_bc4:
	/* 0xbc4: call   1665 <tail_nodeport_rev_dnat_ipv4+0x1665> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_bc9:
	/* 0xbc9: mov    r9,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_ipv4_fragments));
x86_l_bd0:
	/* 0xbd0: mov    r8,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_bd3:
	/* 0xbd3: mov    r10,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bd6:
	/* 0xbd6: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_bd8:
	/* 0xbd8: je     299 <tail_nodeport_rev_dnat_ipv4+0x299> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd8, 0x299, x86_l_299);
x86_l_bde:
	/* 0xbde: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be3:
	/* 0xbe3: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be7:
	/* 0xbe7: sub    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_bea:
	/* 0xbea: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_bf3:
	/* 0xbf3: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_bfc:
	/* 0xbfc: movabs rax,0x6b0085020a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 459570217482ULL);
x86_l_c06:
	/* 0xc06: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_c0e:
	/* 0xc0e: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_c15:
	/* 0xc15: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_c1d:
	/* 0xc1d: call   16be <tail_nodeport_rev_dnat_ipv4+0x16be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c22:
	/* 0xc22: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c25:
	/* 0xc25: je     c99 <tail_nodeport_rev_dnat_ipv4+0xc99> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc25, 0xc99, x86_l_c99);
x86_l_c27:
	/* 0xc27: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_c2a:
	/* 0xc2a: add    QWORD PTR [rax+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_c2e:
	/* 0xc2e: jmp    cc2 <tail_nodeport_rev_dnat_ipv4+0xcc2> */
	X86_SIM_X86_JMP(0xc2e, 0xcc2, x86_l_cc2);
x86_l_c33:
	/* 0xc33: mov    ebp,0xffffff51 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4294967121ULL);
x86_l_c38:
	/* 0xc38: jmp    af <tail_nodeport_rev_dnat_ipv4+0xaf> */
	X86_SIM_X86_JMP(0xc38, 0xaf, x86_l_af);
x86_l_c3d:
	/* 0xc3d: mov    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_c43:
	/* 0xc43: jmp    45d <tail_nodeport_rev_dnat_ipv4+0x45d> */
	X86_SIM_X86_JMP(0xc43, 0x45d, x86_l_45d);
x86_l_c48:
	/* 0xc48: movzx  r11d,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_c4c:
	/* 0xc4c: not    r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_c4f:
	/* 0xc4f: add    r11d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R9, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_c52:
	/* 0xc52: setb   r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_c56:
	/* 0xc56: movzx  r9d,r9b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_c5a:
	/* 0xc5a: add    r9d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R11, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_c5d:
	/* 0xc5d: movzx  r10d,r9w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R10, X86_R9, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_c61:
	/* 0xc61: shr    r9d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_c65:
	/* 0xc65: add    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R10, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_c68:
	/* 0xc68: mov    r11d,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_c6b:
	/* 0xc6b: shr    r11d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_c6f:
	/* 0xc6f: add    r11d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R9, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_c72:
	/* 0xc72: mov    r9d,r11d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R11, X86_WIDTH_32, 0, 0);
x86_l_c75:
	/* 0xc75: not    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_c78:
	/* 0xc78: mov    r10d,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_c7b:
	/* 0xc7b: cmp    r11w,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_16, 0, 65535ULL);
x86_l_c80:
	/* 0xc80: jne    c88 <tail_nodeport_rev_dnat_ipv4+0xc88> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc80, 0xc88, x86_l_c88);
x86_l_c82:
	/* 0xc82: mov    r10d,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_c88:
	/* 0xc88: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_c8b:
	/* 0xc8b: jne    c90 <tail_nodeport_rev_dnat_ipv4+0xc90> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc8b, 0xc90, x86_l_c90);
x86_l_c8d:
	/* 0xc8d: mov    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_c90:
	/* 0xc90: mov    WORD PTR [rax],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c94:
	/* 0xc94: jmp    832 <tail_nodeport_rev_dnat_ipv4+0x832> */
	X86_SIM_X86_JMP(0xc94, 0x832, x86_l_832);
x86_l_c99:
	/* 0xc99: mov    QWORD PTR [rsp+0x10],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476737ULL);
x86_l_ca2:
	/* 0xca2: mov    QWORD PTR [rsp+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ca7:
	/* 0xca7: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_cae:
	/* 0xcae: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cb6:
	/* 0xcb6: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cbb:
	/* 0xcbb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cbd:
	/* 0xcbd: call   175e <tail_nodeport_rev_dnat_ipv4+0x175e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_cc2:
	/* 0xcc2: mov    r10,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_cc5:
	/* 0xcc5: mov    r8,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_cc8:
	/* 0xcc8: mov    r9,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_ipv4_fragments));
x86_l_ccf:
	/* 0xccf: movzx  r15d,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_cd5:
	/* 0xcd5: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_cd9:
	/* 0xcd9: je     2a9 <tail_nodeport_rev_dnat_ipv4+0x2a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd9, 0x2a9, x86_l_2a9);
x86_l_cdf:
	/* 0xcdf: jmp    351 <tail_nodeport_rev_dnat_ipv4+0x351> */
	X86_SIM_X86_JMP(0xcdf, 0x351, x86_l_351);
x86_l_ce4:
	/* 0xce4: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ce6:
	/* 0xce6: jmp    875 <tail_nodeport_rev_dnat_ipv4+0x875> */
	X86_SIM_X86_JMP(0xce6, 0x875, x86_l_875);
x86_l_ceb:
	/* 0xceb: mov    r13d,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_cf1:
	/* 0xcf1: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_cf5:
	/* 0xcf5: jne    d2e <tail_nodeport_rev_dnat_ipv4+0xd2e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcf5, 0xd2e, x86_l_d2e);
x86_l_cf7:
	/* 0xcf7: mov    eax,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_cf9:
	/* 0xcf9: not    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_cfb:
	/* 0xcfb: shr    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 5ULL);
x86_l_cfe:
	/* 0xcfe: and    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16ULL);
x86_l_d01:
	/* 0xd01: or     ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_d03:
	/* 0xd03: mov    WORD PTR [r14+0x24],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_d08:
	/* 0xd08: mov    r13d,0x3c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_d0e:
	/* 0xd0e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d10:
	/* 0xd10: je     d18 <tail_nodeport_rev_dnat_ipv4+0xd18> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd10, 0xd18, x86_l_d18);
x86_l_d12:
	/* 0xd12: mov    r13d,0x5460 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 21600ULL);
x86_l_d18:
	/* 0xd18: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d1d:
	/* 0xd1d: je     d2e <tail_nodeport_rev_dnat_ipv4+0xd2e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd1d, 0xd2e, x86_l_d2e);
x86_l_d1f:
	/* 0xd1f: mov    rax,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_d26:
	/* 0xd26: imul   r13d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_IMUL)), 0ULL);
x86_l_d2a:
	/* 0xd2a: shr    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_d2e:
	/* 0xd2e: movzx  ebp,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RBP, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_d31:
	/* 0xd31: shr    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_d34:
	/* 0xd34: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d39:
	/* 0xd39: je     d4b <tail_nodeport_rev_dnat_ipv4+0xd4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd39, 0xd4b, x86_l_d4b);
x86_l_d3b:
	/* 0xd3b: mov    rax,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&jiffies_64));
x86_l_d42:
	/* 0xd42: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d45:
	/* 0xd45: shr    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_d49:
	/* 0xd49: jmp    d6a <tail_nodeport_rev_dnat_ipv4+0xd6a> */
	X86_SIM_X86_JMP(0xd49, 0xd6a, x86_l_d6a);
x86_l_d4b:
	/* 0xd4b: call   17ec <tail_nodeport_rev_dnat_ipv4+0x17ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_d50:
	/* 0xd50: shr    rax,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 9ULL);
x86_l_d54:
	/* 0xd54: movabs rcx,0x44b82fa09b5a53 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 19342813113834067ULL);
x86_l_d5e:
	/* 0xd5e: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d61:
	/* 0xd61: mulx   rax,rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RAX, X86_RCX, X86_WIDTH_64, X86_RAX, 0);
x86_l_d66:
	/* 0xd66: shr    rax,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 11ULL);
x86_l_d6a:
	/* 0xd6a: add    r13d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_d6d:
	/* 0xd6d: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_d70:
	/* 0xd70: mov    DWORD PTR [r14+0x20],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d74:
	/* 0xd74: movzx  ecx,BYTE PTR [r14+0x2b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 43ULL);
x86_l_d79:
	/* 0xd79: mov    edx,DWORD PTR [r14+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_d7d:
	/* 0xd7d: and    bpl,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 7ULL);
x86_l_d81:
	/* 0xd81: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d86:
	/* 0xd86: je     d99 <tail_nodeport_rev_dnat_ipv4+0xd99> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd86, 0xd99, x86_l_d99);
x86_l_d88:
	/* 0xd88: mov    rsi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_kernel_hz));
x86_l_d8f:
	/* 0xd8f: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d91:
	/* 0xd91: lea    esi,[rsi+rsi*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 2), 0ULL);
x86_l_d94:
	/* 0xd94: shr    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 8ULL);
x86_l_d97:
	/* 0xd97: jmp    d9e <tail_nodeport_rev_dnat_ipv4+0xd9e> */
	X86_SIM_X86_JMP(0xd97, 0xd9e, x86_l_d9e);
x86_l_d99:
	/* 0xd99: mov    esi,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_d9e:
	/* 0xd9e: add    esi,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_da0:
	/* 0xda0: or     bpl,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_da3:
	/* 0xda3: cmp    esi,eax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_da5:
	/* 0xda5: jb     dac <tail_nodeport_rev_dnat_ipv4+0xdac> */
	X86_SIM_X86_JCC(X86_CC_B, 0xda5, 0xdac, x86_l_dac);
x86_l_da7:
	/* 0xda7: cmp    cl,bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_daa:
	/* 0xdaa: je     dbd <tail_nodeport_rev_dnat_ipv4+0xdbd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdaa, 0xdbd, x86_l_dbd);
x86_l_dac:
	/* 0xdac: mov    BYTE PTR [r14+0x2b],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 43ULL);
x86_l_db0:
	/* 0xdb0: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_db4:
	/* 0xdb4: mov    rax,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_trace_payload_len));
x86_l_dbb:
	/* 0xdbb: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dbd:
	/* 0xdbd: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dc0:
	/* 0xdc0: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_dc2:
	/* 0xdc2: js     b9 <tail_nodeport_rev_dnat_ipv4+0xb9> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdc2, 0xb9, x86_l_b9);
x86_l_dc8:
	/* 0xdc8: cmp    ebx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_dcb:
	/* 0xdcb: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dd0:
	/* 0xdd0: je     be <tail_nodeport_rev_dnat_ipv4+0xbe> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdd0, 0xbe, x86_l_be);
x86_l_dd6:
	/* 0xdd6: cmp    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_dd9:
	/* 0xdd9: jne    303 <tail_nodeport_rev_dnat_ipv4+0x303> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdd9, 0x303, x86_l_303);
x86_l_ddf:
	/* 0xddf: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_de7:
	/* 0xde7: mov    rdi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_dee:
	/* 0xdee: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_df3:
	/* 0xdf3: call   1894 <tail_nodeport_rev_dnat_ipv4+0x1894> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_df8:
	/* 0xdf8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dfb:
	/* 0xdfb: je     e04 <tail_nodeport_rev_dnat_ipv4+0xe04> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdfb, 0xe04, x86_l_e04);
x86_l_dfd:
	/* 0xdfd: mov    DWORD PTR [rax+0x14],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345921ULL);
x86_l_e04:
	/* 0xe04: mov    rsi,QWORD PTR [rip+0xa9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_calls));
x86_l_e0b:
	/* 0xe0b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_e0e:
	/* 0xe0e: mov    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_e13:
	/* 0xe13: call   18b4 <tail_nodeport_rev_dnat_ipv4+0x18b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_e18:
	/* 0xe18: mov    ebx,0xffffff74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967156ULL);
x86_l_e1d:
	/* 0xe1d: mov    r14d,0x700 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 1792ULL);
x86_l_e23:
	/* 0xe23: jmp    be <tail_nodeport_rev_dnat_ipv4+0xbe> */
	X86_SIM_X86_JMP(0xe23, 0xbe, x86_l_be);
x86_l_e28:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
