#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 cilium_percpu_trace_id[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_LOAD, X86_OP_MOVBE_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tc/entry")
int p_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_a:
	/* 0xa: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: and    BYTE PTR [rdi+0x86],0xfb */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 575525617915ULL);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rdi+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1b:
	/* 0x1b: mov    DWORD PTR [rdi+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_22:
	/* 0x22: mov    DWORD PTR [rdi+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_29:
	/* 0x29: mov    DWORD PTR [rdi+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_30:
	/* 0x30: mov    DWORD PTR [rdi+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_37:
	/* 0x37: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_tracing_ip_option_type));
x86_l_3e:
	/* 0x3e: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41:
	/* 0x41: je     2b3 <cil_from_wireguard+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41, 0x2b3, x86_l_2b3);
x86_l_47:
	/* 0x47: movzx  ebp,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4a:
	/* 0x4a: cmp    WORD PTR [rbx+0xb4],0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 773094113288ULL);
x86_l_52:
	/* 0x52: jne    28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x52, 0x28e, x86_l_28e);
x86_l_58:
	/* 0x58: mov    eax,DWORD PTR [rbx+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5b:
	/* 0x5b: sub    eax,DWORD PTR [rbx+0x74] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 116ULL);
x86_l_5e:
	/* 0x5e: cmp    eax,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_61:
	/* 0x61: jb     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x61, 0x28e, x86_l_28e);
x86_l_67:
	/* 0x67: mov    rax,QWORD PTR [rbx+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_6e:
	/* 0x6e: movzx  r15d,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_72:
	/* 0x72: and    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_76:
	/* 0x76: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_7a:
	/* 0x7a: jae    a9 <cil_from_wireguard+0xa9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7a, 0xa9, x86_l_a9);
x86_l_7c:
	/* 0x7c: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f:
	/* 0x7f: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_87:
	/* 0x87: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_8e:
	/* 0x8e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_93:
	/* 0x93: call   98 <cil_from_wireguard+0x98> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_98:
	/* 0x98: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9b:
	/* 0x9b: je     2b3 <cil_from_wireguard+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b, 0x2b3, x86_l_2b3);
x86_l_a1:
	/* 0xa1: mov    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a4:
	/* 0xa4: jmp    2b3 <cil_from_wireguard+0x2b3> */
	X86_SIM_X86_JMP(0xa4, 0x2b3, x86_l_2b3);
x86_l_a9:
	/* 0xa9: lea    rdx,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_ae:
	/* 0xae: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b1:
	/* 0xb1: mov    esi,0x14 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_b6:
	/* 0xb6: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_bb:
	/* 0xbb: call   c0 <cil_from_wireguard+0xc0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_c0:
	/* 0xc0: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c2:
	/* 0xc2: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc2, 0x28e, x86_l_28e);
x86_l_c8:
	/* 0xc8: movzx  eax,BYTE PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_cd:
	/* 0xcd: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_cf:
	/* 0xcf: je     7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcf, 0x7c, x86_l_7c);
x86_l_d1:
	/* 0xd1: mov    r14d,0x15 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_d7:
	/* 0xd7: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_da:
	/* 0xda: je     167 <cil_from_wireguard+0x167> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda, 0x167, x86_l_167);
x86_l_e0:
	/* 0xe0: lea    rdx,[rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_e5:
	/* 0xe5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: mov    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_ed:
	/* 0xed: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f2:
	/* 0xf2: call   f7 <cil_from_wireguard+0xf7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_f7:
	/* 0xf7: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_f9:
	/* 0xf9: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf9, 0x28e, x86_l_28e);
x86_l_ff:
	/* 0xff: mov    r14d,0x14 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_105:
	/* 0x105: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_10a:
	/* 0x10a: jne    15d <cil_from_wireguard+0x15d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10a, 0x15d, x86_l_15d);
x86_l_10c:
	/* 0x10c: movzx  eax,BYTE PTR [rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_111:
	/* 0x111: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_114:
	/* 0x114: je     25d <cil_from_wireguard+0x25d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x114, 0x25d, x86_l_25d);
x86_l_11a:
	/* 0x11a: cmp    eax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_11d:
	/* 0x11d: je     233 <cil_from_wireguard+0x233> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d, 0x233, x86_l_233);
x86_l_123:
	/* 0x123: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_126:
	/* 0x126: jne    28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x126, 0x28e, x86_l_28e);
x86_l_12c:
	/* 0x12c: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_130:
	/* 0x130: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_135:
	/* 0x135: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_138:
	/* 0x138: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_13b:
	/* 0x13b: mov    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_140:
	/* 0x140: call   145 <cil_from_wireguard+0x145> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_145:
	/* 0x145: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_147:
	/* 0x147: js     283 <cil_from_wireguard+0x283> */
	X86_SIM_X86_JCC(X86_CC_S, 0x147, 0x283, x86_l_283);
x86_l_14d:
	/* 0x14d: movbe  cx,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RSP, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_154:
	/* 0x154: movzx  r14d,cx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_158:
	/* 0x158: jmp    286 <cil_from_wireguard+0x286> */
	X86_SIM_X86_JMP(0x158, 0x286, x86_l_286);
x86_l_15d:
	/* 0x15d: movzx  r14d,BYTE PTR [rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_163:
	/* 0x163: add    r14d,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 20ULL);
x86_l_167:
	/* 0x167: lea    r15d,[r15*4+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 20ULL);
x86_l_16f:
	/* 0x16f: cmp    r14d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_172:
	/* 0x172: jae    7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x172, 0x7c, x86_l_7c);
x86_l_178:
	/* 0x178: lea    rdx,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_17d:
	/* 0x17d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_180:
	/* 0x180: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_183:
	/* 0x183: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_188:
	/* 0x188: call   18d <cil_from_wireguard+0x18d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_18d:
	/* 0x18d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_18f:
	/* 0x18f: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18f, 0x28e, x86_l_28e);
x86_l_195:
	/* 0x195: movzx  eax,BYTE PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_19a:
	/* 0x19a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_19c:
	/* 0x19c: je     7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c, 0x7c, x86_l_7c);
x86_l_1a2:
	/* 0x1a2: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1a5:
	/* 0x1a5: je     1d5 <cil_from_wireguard+0x1d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5, 0x1d5, x86_l_1d5);
x86_l_1a7:
	/* 0x1a7: lea    esi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ab:
	/* 0x1ab: lea    rdx,[rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_1b0:
	/* 0x1b0: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1b8:
	/* 0x1b8: call   1bd <cil_from_wireguard+0x1bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_1bd:
	/* 0x1bd: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1bf:
	/* 0x1bf: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bf, 0x28e, x86_l_28e);
x86_l_1c5:
	/* 0x1c5: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_1ca:
	/* 0x1ca: je     10c <cil_from_wireguard+0x10c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ca, 0x10c, x86_l_10c);
x86_l_1d0:
	/* 0x1d0: movzx  eax,BYTE PTR [rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_1d5:
	/* 0x1d5: add    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1d8:
	/* 0x1d8: cmp    r14d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1db:
	/* 0x1db: jae    7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1db, 0x7c, x86_l_7c);
x86_l_1e1:
	/* 0x1e1: lea    rdx,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_1e6:
	/* 0x1e6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e9:
	/* 0x1e9: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ec:
	/* 0x1ec: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f1:
	/* 0x1f1: call   1f6 <cil_from_wireguard+0x1f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_1f6:
	/* 0x1f6: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f8:
	/* 0x1f8: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f8, 0x28e, x86_l_28e);
x86_l_1fe:
	/* 0x1fe: cmp    BYTE PTR [rsp+0xe],0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 60129542146ULL);
x86_l_203:
	/* 0x203: jb     7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x203, 0x7c, x86_l_7c);
x86_l_209:
	/* 0x209: lea    esi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20d:
	/* 0x20d: lea    rdx,[rsp+0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
x86_l_212:
	/* 0x212: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_215:
	/* 0x215: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_21a:
	/* 0x21a: call   21f <cil_from_wireguard+0x21f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_21f:
	/* 0x21f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_221:
	/* 0x221: js     28e <cil_from_wireguard+0x28e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x221, 0x28e, x86_l_28e);
x86_l_223:
	/* 0x223: cmp    BYTE PTR [rsp+0xe],bpl */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_228:
	/* 0x228: jne    7c <cil_from_wireguard+0x7c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x228, 0x7c, x86_l_7c);
x86_l_22e:
	/* 0x22e: jmp    10c <cil_from_wireguard+0x10c> */
	X86_SIM_X86_JMP(0x22e, 0x10c, x86_l_10c);
x86_l_233:
	/* 0x233: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_237:
	/* 0x237: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23c:
	/* 0x23c: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_23f:
	/* 0x23f: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_242:
	/* 0x242: mov    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_247:
	/* 0x247: call   24c <cil_from_wireguard+0x24c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_24c:
	/* 0x24c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e:
	/* 0x24e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_250:
	/* 0x250: movbe  r14d,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_257:
	/* 0x257: cmovs  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_S, 0);
x86_l_25b:
	/* 0x25b: jmp    286 <cil_from_wireguard+0x286> */
	X86_SIM_X86_JMP(0x25b, 0x286, x86_l_286);
x86_l_25d:
	/* 0x25d: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_261:
	/* 0x261: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_266:
	/* 0x266: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_26c:
	/* 0x26c: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_271:
	/* 0x271: call   276 <cil_from_wireguard+0x276> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_load_bytes);
x86_l_276:
	/* 0x276: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_278:
	/* 0x278: js     283 <cil_from_wireguard+0x283> */
	X86_SIM_X86_JCC(X86_CC_S, 0x278, 0x283, x86_l_283);
x86_l_27a:
	/* 0x27a: movbe  r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_281:
	/* 0x281: jmp    286 <cil_from_wireguard+0x286> */
	X86_SIM_X86_JMP(0x281, 0x286, x86_l_286);
x86_l_283:
	/* 0x283: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286:
	/* 0x286: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_288:
	/* 0x288: jns    7f <cil_from_wireguard+0x7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x288, 0x7f, x86_l_7f);
x86_l_28e:
	/* 0x28e: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_296:
	/* 0x296: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_29d:
	/* 0x29d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a2:
	/* 0x2a2: call   2a7 <cil_from_wireguard+0x2a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a7:
	/* 0x2a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aa:
	/* 0x2aa: je     2b3 <cil_from_wireguard+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aa, 0x2b3, x86_l_2b3);
x86_l_2ac:
	/* 0x2ac: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3:
	/* 0x2b3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_identity_mark));
x86_l_2ba:
	/* 0x2ba: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bd:
	/* 0x2bd: je     2c9 <cil_from_wireguard+0x2c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bd, 0x2c9, x86_l_2c9);
x86_l_2bf:
	/* 0x2bf: mov    DWORD PTR [rbx+0xa8],0xd00 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554509056ULL);
x86_l_2c9:
	/* 0x2c9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cb:
	/* 0x2cb: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2cf:
	/* 0x2cf: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2d0:
	/* 0x2d0: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2d2:
	/* 0x2d2: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2d4:
	/* 0x2d4: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2d5:
	/* 0x2d5: jmp    2da <cil_from_wireguard+0x2da> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2da:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
