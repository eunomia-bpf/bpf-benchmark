#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 execve_map[] __ksym;
extern __u8 ids_map[] __ksym;
extern __u8 loader_heap[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/perf_event_mmap_output")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_a:
	/* 0xa: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_15:
	/* 0x15: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)loader_heap));
x86_l_1c:
	/* 0x1c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21:
	/* 0x21: call   26 <loader_kprobe+0x26> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26:
	/* 0x26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29:
	/* 0x29: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29, 0x12b, x86_l_12b);
x86_l_2f:
	/* 0x2f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32:
	/* 0x32: mov    r15,QWORD PTR [r14+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_36:
	/* 0x36: mov    rax,QWORD PTR [rax+0x1040] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_3d:
	/* 0x3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40:
	/* 0x40: je     4d <loader_kprobe+0x4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40, 0x4d, x86_l_4d);
x86_l_42:
	/* 0x42: cmp    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_45:
	/* 0x45: jne    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x45, 0x12b, x86_l_12b);
x86_l_4b:
	/* 0x4b: jmp    9a <loader_kprobe+0x9a> */
	X86_SIM_X86_JMP(0x4b, 0x9a, x86_l_9a);
x86_l_4d:
	/* 0x4d: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_55:
	/* 0x55: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ids_map));
x86_l_5c:
	/* 0x5c: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_61:
	/* 0x61: call   66 <loader_kprobe+0x66> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_66:
	/* 0x66: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69:
	/* 0x69: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69, 0x12b, x86_l_12b);
x86_l_6f:
	/* 0x6f: lea    rcx,[r15+0x3f0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1008ULL);
x86_l_76:
	/* 0x76: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_79:
	/* 0x79: jns    88 <loader_kprobe+0x88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x79, 0x88, x86_l_88);
x86_l_7b:
	/* 0x7b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e:
	/* 0x7e: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_81:
	/* 0x81: je     93 <loader_kprobe+0x93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x81, 0x93, x86_l_93);
x86_l_83:
	/* 0x83: jmp    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JMP(0x83, 0x12b, x86_l_12b);
x86_l_88:
	/* 0x88: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8a:
	/* 0x8a: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8d:
	/* 0x8d: jne    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8d, 0x12b, x86_l_12b);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbx+0x1040],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4160ULL);
x86_l_9a:
	/* 0x9a: call   9f <loader_kprobe+0x9f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_9f:
	/* 0x9f: add    rax,0xaf4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
x86_l_a5:
	/* 0xa5: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a7:
	/* 0xa7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aa:
	/* 0xaa: jns    ae <loader_kprobe+0xae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaa, 0xae, x86_l_ae);
x86_l_ac:
	/* 0xac: mov    ebp,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae:
	/* 0xae: mov    DWORD PTR [rsp+0x8],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b2:
	/* 0xb2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_b9:
	/* 0xb9: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be:
	/* 0xbe: call   c3 <loader_kprobe+0xc3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c3:
	/* 0xc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6:
	/* 0xc6: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6, 0x12b, x86_l_12b);
x86_l_c8:
	/* 0xc8: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ca:
	/* 0xca: mov    DWORD PTR [rbx+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cd:
	/* 0xcd: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d1:
	/* 0xd1: mov    QWORD PTR [rbx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d5:
	/* 0xd5: mov    r15,QWORD PTR [r14+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d9:
	/* 0xd9: lea    rax,[r15+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_dd:
	/* 0xdd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e0:
	/* 0xe0: jns    124 <loader_kprobe+0x124> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe0, 0x124, x86_l_124);
x86_l_e2:
	/* 0xe2: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e4:
	/* 0xe4: mov    DWORD PTR [rbx+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_e7:
	/* 0xe7: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_e9:
	/* 0xe9: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe9, 0x12b, x86_l_12b);
x86_l_eb:
	/* 0xeb: lea    rdi,[rbx+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_ef:
	/* 0xef: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f2:
	/* 0xf2: add    rdx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_f6:
	/* 0xf6: jns    13c <loader_kprobe+0x13c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf6, 0x13c, x86_l_13c);
x86_l_f8:
	/* 0xf8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fb:
	/* 0xfb: jns    18c <loader_kprobe+0x18c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfb, 0x18c, x86_l_18c);
x86_l_101:
	/* 0x101: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_104:
	/* 0x104: mov    QWORD PTR [rbx+0x2c],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_108:
	/* 0x108: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10c:
	/* 0x10c: mov    QWORD PTR [rbx+0x34],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_110:
	/* 0x110: mov    eax,DWORD PTR [rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_113:
	/* 0x113: mov    DWORD PTR [rbx+0x3c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_116:
	/* 0x116: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_11a:
	/* 0x11a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11d:
	/* 0x11d: js     14f <loader_kprobe+0x14f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11d, 0x14f, x86_l_14f);
x86_l_11f:
	/* 0x11f: jmp    1ab <loader_kprobe+0x1ab> */
	X86_SIM_X86_JMP(0x11f, 0x1ab, x86_l_1ab);
x86_l_124:
	/* 0x124: mov    DWORD PTR [rbx+0x24],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 154618822656ULL);
x86_l_12b:
	/* 0x12b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12d:
	/* 0x12d: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_131:
	/* 0x131: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_132:
	/* 0x132: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_134:
	/* 0x134: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_136:
	/* 0x136: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: jmp    34b <loader_kprobe+0x34b> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_13c:
	/* 0x13c: mov    esi,0x14 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_141:
	/* 0x141: call   146 <loader_kprobe+0x146> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_146:
	/* 0x146: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_14a:
	/* 0x14a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_14d:
	/* 0x14d: jns    1ab <loader_kprobe+0x1ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14d, 0x1ab, x86_l_1ab);
x86_l_14f:
	/* 0x14f: mov    rdx,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_152:
	/* 0x152: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_155:
	/* 0x155: add    rdi,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_159:
	/* 0x159: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15c:
	/* 0x15c: jns    1b4 <loader_kprobe+0x1b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c, 0x1b4, x86_l_1b4);
x86_l_15e:
	/* 0x15e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_161:
	/* 0x161: jns    2d1 <loader_kprobe+0x2d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161, 0x2d1, x86_l_2d1);
x86_l_167:
	/* 0x167: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_169:
	/* 0x169: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_170:
	/* 0x170: je     301 <loader_kprobe+0x301> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170, 0x301, x86_l_301);
x86_l_176:
	/* 0x176: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17a:
	/* 0x17a: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_17e:
	/* 0x17e: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_182:
	/* 0x182: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_185:
	/* 0x185: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_188:
	/* 0x188: jne    169 <loader_kprobe+0x169> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x188, 0x169, x86_l_169);
x86_l_18a:
	/* 0x18a: jmp    1be <loader_kprobe+0x1be> */
	X86_SIM_X86_JMP(0x18a, 0x1be, x86_l_1be);
x86_l_18c:
	/* 0x18c: mov    DWORD PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_193:
	/* 0x193: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_19b:
	/* 0x19b: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a2:
	/* 0x1a2: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a6:
	/* 0x1a6: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1a9:
	/* 0x1a9: js     14f <loader_kprobe+0x14f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a9, 0x14f, x86_l_14f);
x86_l_1ab:
	/* 0x1ab: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ae:
	/* 0x1ae: add    rdi,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_1b2:
	/* 0x1b2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b4:
	/* 0x1b4: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1b9:
	/* 0x1b9: call   1be <loader_kprobe+0x1be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1be:
	/* 0x1be: mov    DWORD PTR [rbx+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c1:
	/* 0x1c1: mov    DWORD PTR [rbx+0x20],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c4:
	/* 0x1c4: mov    DWORD PTR [rbx+0x4],0x1040 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179873344ULL);
x86_l_1cb:
	/* 0x1cb: call   1d0 <loader_kprobe+0x1d0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_1d0:
	/* 0x1d0: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d4:
	/* 0x1d4: mov    WORD PTR [rbx],0x1a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_1d9:
	/* 0x1d9: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1e1:
	/* 0x1e1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_1e8:
	/* 0x1e8: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1ed:
	/* 0x1ed: call   1f2 <loader_kprobe+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f2:
	/* 0x1f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f5:
	/* 0x1f5: je     26d <loader_kprobe+0x26d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5, 0x26d, x86_l_26d);
x86_l_1f7:
	/* 0x1f7: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1fb:
	/* 0x1fb: je     26d <loader_kprobe+0x26d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb, 0x26d, x86_l_26d);
x86_l_1fd:
	/* 0x1fd: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_204:
	/* 0x204: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_209:
	/* 0x209: mov    r8d,0x1040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 4160ULL);
x86_l_20f:
	/* 0x20f: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_212:
	/* 0x212: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_215:
	/* 0x215: call   21a <loader_kprobe+0x21a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_21a:
	/* 0x21a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21d:
	/* 0x21d: jns    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21d, 0x12b, x86_l_12b);
x86_l_223:
	/* 0x223: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_226:
	/* 0x226: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_22e:
	/* 0x22e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_235:
	/* 0x235: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23a:
	/* 0x23a: call   23f <loader_kprobe+0x23f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_23f:
	/* 0x23f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_242:
	/* 0x242: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x242, 0x12b, x86_l_12b);
x86_l_248:
	/* 0x248: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_24c:
	/* 0x24c: jg     312 <loader_kprobe+0x312> */
	X86_SIM_X86_JCC(X86_CC_G, 0x24c, 0x312, x86_l_312);
x86_l_252:
	/* 0x252: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_256:
	/* 0x256: je     32c <loader_kprobe+0x32c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x256, 0x32c, x86_l_32c);
x86_l_25c:
	/* 0x25c: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_260:
	/* 0x260: jne    2c3 <loader_kprobe+0x2c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x260, 0x2c3, x86_l_2c3);
x86_l_262:
	/* 0x262: add    rax,0x5d0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1488ULL);
x86_l_268:
	/* 0x268: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x268, 0x342, x86_l_342);
x86_l_26d:
	/* 0x26d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_274:
	/* 0x274: mov    edx,0x1040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4160ULL);
x86_l_279:
	/* 0x279: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_27c:
	/* 0x27c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27e:
	/* 0x27e: call   283 <loader_kprobe+0x283> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_283:
	/* 0x283: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_286:
	/* 0x286: jns    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x286, 0x12b, x86_l_12b);
x86_l_28c:
	/* 0x28c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28f:
	/* 0x28f: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_297:
	/* 0x297: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_29e:
	/* 0x29e: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a3:
	/* 0x2a3: call   2a8 <loader_kprobe+0x2a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a8:
	/* 0x2a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ab:
	/* 0x2ab: je     12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ab, 0x12b, x86_l_12b);
x86_l_2b1:
	/* 0x2b1: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2b5:
	/* 0x2b5: jg     2e7 <loader_kprobe+0x2e7> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2b5, 0x2e7, x86_l_2e7);
x86_l_2b7:
	/* 0x2b7: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_2bb:
	/* 0x2bb: je     32c <loader_kprobe+0x32c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bb, 0x32c, x86_l_32c);
x86_l_2bd:
	/* 0x2bd: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2c1:
	/* 0x2c1: je     262 <loader_kprobe+0x262> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c1, 0x262, x86_l_262);
x86_l_2c3:
	/* 0x2c3: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2c7:
	/* 0x2c7: jne    324 <loader_kprobe+0x324> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c7, 0x324, x86_l_324);
x86_l_2c9:
	/* 0x2c9: add    rax,0x5c8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1480ULL);
x86_l_2cf:
	/* 0x2cf: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x2cf, 0x342, x86_l_342);
x86_l_2d1:
	/* 0x2d1: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d6:
	/* 0x2d6: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d8:
	/* 0x2d8: call   2dd <loader_kprobe+0x2dd> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2dd:
	/* 0x2dd: mov    eax,0xffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967262ULL);
x86_l_2e2:
	/* 0x2e2: jmp    1be <loader_kprobe+0x1be> */
	X86_SIM_X86_JMP(0x2e2, 0x1be, x86_l_1be);
x86_l_2e7:
	/* 0x2e7: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2eb:
	/* 0x2eb: je     334 <loader_kprobe+0x334> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2eb, 0x334, x86_l_334);
x86_l_2ed:
	/* 0x2ed: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2f1:
	/* 0x2f1: je     33c <loader_kprobe+0x33c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f1, 0x33c, x86_l_33c);
x86_l_2f3:
	/* 0x2f3: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2f7:
	/* 0x2f7: jne    324 <loader_kprobe+0x324> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f7, 0x324, x86_l_324);
x86_l_2f9:
	/* 0x2f9: add    rax,0x5b8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1464ULL);
x86_l_2ff:
	/* 0x2ff: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x2ff, 0x342, x86_l_342);
x86_l_301:
	/* 0x301: mov    BYTE PTR [rbx+0x103f],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17862768984064ULL);
x86_l_308:
	/* 0x308: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_30d:
	/* 0x30d: jmp    1be <loader_kprobe+0x1be> */
	X86_SIM_X86_JMP(0x30d, 0x1be, x86_l_1be);
x86_l_312:
	/* 0x312: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_316:
	/* 0x316: je     334 <loader_kprobe+0x334> */
	X86_SIM_X86_JCC(X86_CC_E, 0x316, 0x334, x86_l_334);
x86_l_318:
	/* 0x318: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_31c:
	/* 0x31c: je     33c <loader_kprobe+0x33c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c, 0x33c, x86_l_33c);
x86_l_31e:
	/* 0x31e: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_322:
	/* 0x322: je     2f9 <loader_kprobe+0x2f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x322, 0x2f9, x86_l_2f9);
x86_l_324:
	/* 0x324: add    rax,0x5b0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1456ULL);
x86_l_32a:
	/* 0x32a: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x32a, 0x342, x86_l_342);
x86_l_32c:
	/* 0x32c: add    rax,0x5d8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1496ULL);
x86_l_332:
	/* 0x332: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x332, 0x342, x86_l_342);
x86_l_334:
	/* 0x334: add    rax,0x5e0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1504ULL);
x86_l_33a:
	/* 0x33a: jmp    342 <loader_kprobe+0x342> */
	X86_SIM_X86_JMP(0x33a, 0x342, x86_l_342);
x86_l_33c:
	/* 0x33c: add    rax,0x5c0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1472ULL);
x86_l_342:
	/* 0x342: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_346:
	/* 0x346: jmp    12b <loader_kprobe+0x12b> */
	X86_SIM_X86_JMP(0x346, 0x12b, x86_l_12b);
x86_l_34b:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
