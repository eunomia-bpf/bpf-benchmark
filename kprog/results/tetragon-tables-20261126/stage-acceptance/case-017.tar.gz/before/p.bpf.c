#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 cgroup_map[] __ksym;
extern __u8 hists[] __ksym;
extern __u8 start[] __ksym;
static const __u8 __x86_rodata_0[120] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(19):.bss\",\"size\":120}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 117: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 117, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 118: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 118, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 119: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 119, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 117: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 117, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 118: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 118, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_DIV, X86_OP_DIV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tp_btf/sched_switch")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5:
	/* 0x5: mov    rsi,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9:
	/* 0x9: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c:
	/* 0xc: call   0 <sched_switch> */
	X86_SIM_X86_CALL(x86_l_19, 0x11ULL);
x86_l_11:
	/* 0x11: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13:
	/* 0x13: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: jmp    424 <handle_switch+0x40b> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_424:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_19 */
x86_l_19:
	/* 0x19: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1b:
	/* 0x1b: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d:
	/* 0x1d: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e:
	/* 0x1e: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_22:
	/* 0x22: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25:
	/* 0x25: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28:
	/* 0x28: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_cg));
x86_l_2f:
	/* 0x2f: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32:
	/* 0x32: je     4b <handle_switch+0x32> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x32, 0x4b, x86_l_4b);
x86_l_34:
	/* 0x34: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_map));
x86_l_3b:
	/* 0x3b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d:
	/* 0x3d: call   42 <handle_switch+0x29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_current_task_under_cgroup);
x86_l_42:
	/* 0x42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45:
	/* 0x45: je     41a <handle_switch+0x401> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x45, 0x41a, x86_l_41a);
x86_l_4b:
	/* 0x4b: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4e:
	/* 0x4e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51:
	/* 0x51: jns    59 <handle_switch+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x51, 0x59, x86_l_59);
x86_l_53:
	/* 0x53: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55:
	/* 0x55: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_57:
	/* 0x57: jne    b4 <handle_switch+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x57, 0xb4, x86_l_b4);
x86_l_59:
	/* 0x59: lea    rcx,[r14+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_60:
	/* 0x60: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_62:
	/* 0x62: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_65:
	/* 0x65: jns    69 <handle_switch+0x50> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x65, 0x69, x86_l_69);
x86_l_67:
	/* 0x67: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_69:
	/* 0x69: add    r14,0xaf0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2800ULL);
x86_l_70:
	/* 0x70: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_73:
	/* 0x73: jns    b4 <handle_switch+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x73, 0xb4, x86_l_b4);
x86_l_75:
	/* 0x75: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_78:
	/* 0x78: mov    DWORD PTR [rsp+0x4],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7c:
	/* 0x7c: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7e:
	/* 0x7e: je     b4 <handle_switch+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7e, 0xb4, x86_l_b4);
x86_l_80:
	/* 0x80: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_tgid));
x86_l_87:
	/* 0x87: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8a:
	/* 0x8a: je     92 <handle_switch+0x79> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8a, 0x92, x86_l_92);
x86_l_8c:
	/* 0x8c: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e:
	/* 0x8e: cmp    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_90:
	/* 0x90: jne    b4 <handle_switch+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x90, 0xb4, x86_l_b4);
x86_l_92:
	/* 0x92: call   97 <handle_switch+0x7e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_97:
	/* 0x97: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9c:
	/* 0x9c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_a3:
	/* 0xa3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a8:
	/* 0xa8: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ad:
	/* 0xad: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_af:
	/* 0xaf: call   b4 <handle_switch+0x9b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b4:
	/* 0xb4: lea    rcx,[rbx+0xaf0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2800ULL);
x86_l_bb:
	/* 0xbb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bd:
	/* 0xbd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c0:
	/* 0xc0: jns    c4 <handle_switch+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xc0, 0xc4, x86_l_c4);
x86_l_c2:
	/* 0xc2: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c4:
	/* 0xc4: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c8:
	/* 0xc8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_cf:
	/* 0xcf: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d4:
	/* 0xd4: call   d9 <handle_switch+0xc0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d9:
	/* 0xd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dc:
	/* 0xdc: je     41a <handle_switch+0x401> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xdc, 0x41a, x86_l_41a);
x86_l_e2:
	/* 0xe2: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e5:
	/* 0xe5: call   ea <handle_switch+0xd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_ea:
	/* 0xea: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed:
	/* 0xed: sub    r14,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_f0:
	/* 0xf0: js     409 <handle_switch+0x3f0> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0xf0, 0x409, x86_l_409);
x86_l_f6:
	/* 0xf6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_process));
x86_l_fd:
	/* 0xfd: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_100:
	/* 0x100: je     11b <handle_switch+0x102> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x100, 0x11b, x86_l_11b);
x86_l_102:
	/* 0x102: lea    rcx,[rbx+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_109:
	/* 0x109: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b:
	/* 0x10b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10e:
	/* 0x10e: jns    112 <handle_switch+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x10e, 0x112, x86_l_112);
x86_l_110:
	/* 0x110: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_112:
	/* 0x112: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_116:
	/* 0x116: jmp    19d <handle_switch+0x184> */
	X86_SIM_X86_SUB_JMP(0x116, 0x19d, x86_l_19d);
x86_l_11b:
	/* 0x11b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_thread));
x86_l_122:
	/* 0x122: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_125:
	/* 0x125: je     131 <handle_switch+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x125, 0x131, x86_l_131);
x86_l_127:
	/* 0x127: mov    eax,DWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12b:
	/* 0x12b: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_12f:
	/* 0x12f: jmp    19d <handle_switch+0x184> */
	X86_SIM_X86_SUB_JMP(0x12f, 0x19d, x86_l_19d);
x86_l_131:
	/* 0x131: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_pidns));
x86_l_138:
	/* 0x138: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13b:
	/* 0x13b: je     14e <handle_switch+0x135> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13b, 0x14e, x86_l_14e);
x86_l_13d:
	/* 0x13d: lea    rax,[rbx+0xb58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
x86_l_144:
	/* 0x144: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_147:
	/* 0x147: jns    158 <handle_switch+0x13f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x147, 0x158, x86_l_158);
x86_l_149:
	/* 0x149: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c:
	/* 0x14c: jmp    15a <handle_switch+0x141> */
	X86_SIM_X86_SUB_JMP(0x14c, 0x15a, x86_l_15a);
x86_l_14e:
	/* 0x14e: mov    DWORD PTR [rsp+0x4],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 21474836479ULL);
x86_l_156:
	/* 0x156: jmp    19d <handle_switch+0x184> */
	X86_SIM_X86_SUB_JMP(0x156, 0x19d, x86_l_19d);
x86_l_158:
	/* 0x158: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a:
	/* 0x15a: lea    rcx,[rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15e:
	/* 0x15e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_161:
	/* 0x161: jns    169 <handle_switch+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x161, 0x169, x86_l_169);
x86_l_163:
	/* 0x163: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_165:
	/* 0x165: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_167:
	/* 0x167: jmp    16b <handle_switch+0x152> */
	X86_SIM_X86_SUB_JMP(0x167, 0x16b, x86_l_16b);
x86_l_169:
	/* 0x169: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16b:
	/* 0x16b: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16f:
	/* 0x16f: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_172:
	/* 0x172: add    rcx,0x80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
x86_l_179:
	/* 0x179: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17b:
	/* 0x17b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17e:
	/* 0x17e: jns    189 <handle_switch+0x170> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x17e, 0x189, x86_l_189);
x86_l_180:
	/* 0x180: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_183:
	/* 0x183: mov    rcx,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_187:
	/* 0x187: jmp    18b <handle_switch+0x172> */
	X86_SIM_X86_SUB_JMP(0x187, 0x18b, x86_l_18b);
x86_l_189:
	/* 0x189: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b:
	/* 0x18b: add    rcx,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_192:
	/* 0x192: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_195:
	/* 0x195: jns    199 <handle_switch+0x180> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x195, 0x199, x86_l_199);
x86_l_197:
	/* 0x197: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_199:
	/* 0x199: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19d:
	/* 0x19d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_1a4:
	/* 0x1a4: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a9:
	/* 0x1a9: call   1ae <handle_switch+0x195> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ae:
	/* 0x1ae: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b1:
	/* 0x1b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b4:
	/* 0x1b4: je     2b1 <handle_switch+0x298> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1b4, 0x2b1, x86_l_2b1);
x86_l_1ba:
	/* 0x1ba: cmp    BYTE PTR [rcx+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1be:
	/* 0x1be: jne    30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1be, 0x30e, x86_l_30e);
x86_l_1c4:
	/* 0x1c4: lea    rax,[rcx+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1c8:
	/* 0x1c8: add    rbx,0xd10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3344ULL);
x86_l_1cf:
	/* 0x1cf: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d2:
	/* 0x1d2: jns    2ff <handle_switch+0x2e6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1d2, 0x2ff, x86_l_2ff);
x86_l_1d8:
	/* 0x1d8: movzx  edx,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1db:
	/* 0x1db: mov    BYTE PTR [rax],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd:
	/* 0x1dd: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1df:
	/* 0x1df: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1df, 0x30e, x86_l_30e);
x86_l_1e5:
	/* 0x1e5: movzx  eax,BYTE PTR [rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1e9:
	/* 0x1e9: mov    BYTE PTR [rcx+0x69],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 105ULL);
x86_l_1ec:
	/* 0x1ec: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1ee:
	/* 0x1ee: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1ee, 0x30e, x86_l_30e);
x86_l_1f4:
	/* 0x1f4: movzx  eax,BYTE PTR [rbx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1f8:
	/* 0x1f8: mov    BYTE PTR [rcx+0x6a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 106ULL);
x86_l_1fb:
	/* 0x1fb: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1fd:
	/* 0x1fd: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1fd, 0x30e, x86_l_30e);
x86_l_203:
	/* 0x203: movzx  eax,BYTE PTR [rbx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_207:
	/* 0x207: mov    BYTE PTR [rcx+0x6b],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 107ULL);
x86_l_20a:
	/* 0x20a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20c:
	/* 0x20c: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x20c, 0x30e, x86_l_30e);
x86_l_212:
	/* 0x212: movzx  eax,BYTE PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_216:
	/* 0x216: mov    BYTE PTR [rcx+0x6c],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_219:
	/* 0x219: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_21b:
	/* 0x21b: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x21b, 0x30e, x86_l_30e);
x86_l_221:
	/* 0x221: movzx  eax,BYTE PTR [rbx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_225:
	/* 0x225: mov    BYTE PTR [rcx+0x6d],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 109ULL);
x86_l_228:
	/* 0x228: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_22a:
	/* 0x22a: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22a, 0x30e, x86_l_30e);
x86_l_230:
	/* 0x230: movzx  eax,BYTE PTR [rbx+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_234:
	/* 0x234: mov    BYTE PTR [rcx+0x6e],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 110ULL);
x86_l_237:
	/* 0x237: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_239:
	/* 0x239: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x239, 0x30e, x86_l_30e);
x86_l_23f:
	/* 0x23f: movzx  eax,BYTE PTR [rbx+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_243:
	/* 0x243: mov    BYTE PTR [rcx+0x6f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 111ULL);
x86_l_246:
	/* 0x246: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_248:
	/* 0x248: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x248, 0x30e, x86_l_30e);
x86_l_24e:
	/* 0x24e: movzx  eax,BYTE PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_252:
	/* 0x252: mov    BYTE PTR [rcx+0x70],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_255:
	/* 0x255: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_257:
	/* 0x257: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x257, 0x30e, x86_l_30e);
x86_l_25d:
	/* 0x25d: movzx  eax,BYTE PTR [rbx+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_261:
	/* 0x261: mov    BYTE PTR [rcx+0x71],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 113ULL);
x86_l_264:
	/* 0x264: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_266:
	/* 0x266: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x266, 0x30e, x86_l_30e);
x86_l_26c:
	/* 0x26c: movzx  eax,BYTE PTR [rbx+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_270:
	/* 0x270: mov    BYTE PTR [rcx+0x72],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 114ULL);
x86_l_273:
	/* 0x273: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_275:
	/* 0x275: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x275, 0x30e, x86_l_30e);
x86_l_27b:
	/* 0x27b: movzx  eax,BYTE PTR [rbx+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_27f:
	/* 0x27f: mov    BYTE PTR [rcx+0x73],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 115ULL);
x86_l_282:
	/* 0x282: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_284:
	/* 0x284: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x284, 0x30e, x86_l_30e);
x86_l_28a:
	/* 0x28a: movzx  eax,BYTE PTR [rbx+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_28e:
	/* 0x28e: mov    BYTE PTR [rcx+0x74],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_291:
	/* 0x291: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_293:
	/* 0x293: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x293, 0x30e, x86_l_30e);
x86_l_295:
	/* 0x295: movzx  eax,BYTE PTR [rbx+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_299:
	/* 0x299: mov    BYTE PTR [rcx+0x75],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 117ULL);
x86_l_29c:
	/* 0x29c: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_29e:
	/* 0x29e: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x29e, 0x30e, x86_l_30e);
x86_l_2a0:
	/* 0x2a0: movzx  eax,BYTE PTR [rbx+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2a4:
	/* 0x2a4: mov    BYTE PTR [rcx+0x76],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 118ULL);
x86_l_2a7:
	/* 0x2a7: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2a9:
	/* 0x2a9: je     30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2a9, 0x30e, x86_l_30e);
x86_l_2ab:
	/* 0x2ab: mov    BYTE PTR [rcx+0x77],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 511101108224ULL);
x86_l_2af:
	/* 0x2af: jmp    30e <handle_switch+0x2f5> */
	X86_SIM_X86_SUB_JMP(0x2af, 0x30e, x86_l_30e);
x86_l_2b1:
	/* 0x2b1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_2b8:
	/* 0x2b8: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_2bf:
	/* 0x2bf: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c4:
	/* 0x2c4: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2c9:
	/* 0x2c9: call   2ce <handle_switch+0x2b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2ce:
	/* 0x2ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d1:
	/* 0x2d1: je     2dd <handle_switch+0x2c4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2d1, 0x2dd, x86_l_2dd);
x86_l_2d3:
	/* 0x2d3: cmp    rax,0xffffffffffffffef */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551599ULL);
x86_l_2d7:
	/* 0x2d7: jne    409 <handle_switch+0x3f0> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2d7, 0x409, x86_l_409);
x86_l_2dd:
	/* 0x2dd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_2e4:
	/* 0x2e4: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2e9:
	/* 0x2e9: call   2ee <handle_switch+0x2d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ee:
	/* 0x2ee: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f1:
	/* 0x2f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f4:
	/* 0x2f4: jne    1ba <handle_switch+0x1a1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2f4, 0x1ba, x86_l_1ba);
x86_l_2fa:
	/* 0x2fa: jmp    409 <handle_switch+0x3f0> */
	X86_SIM_X86_SUB_JMP(0x2fa, 0x409, x86_l_409);
x86_l_2ff:
	/* 0x2ff: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_307:
	/* 0x307: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30e:
	/* 0x30e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_ms));
x86_l_315:
	/* 0x315: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_318:
	/* 0x318: mov    esi,0x3e8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1000ULL);
x86_l_31d:
	/* 0x31d: je     324 <handle_switch+0x30b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x31d, 0x324, x86_l_324);
x86_l_31f:
	/* 0x31f: mov    esi,0xf4240 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1000000ULL);
x86_l_324:
	/* 0x324: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_327:
	/* 0x327: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_32b:
	/* 0x32b: je     397 <handle_switch+0x37e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x32b, 0x397, x86_l_397);
x86_l_32d:
	/* 0x32d: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_330:
	/* 0x330: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_332:
	/* 0x332: div    rsi */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_335:
	/* 0x335: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_338:
	/* 0x338: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33a:
	/* 0x33a: shr    rsi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_33e:
	/* 0x33e: je     3a9 <handle_switch+0x390> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x33e, 0x3a9, x86_l_3a9);
x86_l_340:
	/* 0x340: cmp    esi,0x10000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 65536ULL);
x86_l_346:
	/* 0x346: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_349:
	/* 0x349: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_34c:
	/* 0x34c: shrx   esi,esi,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_351:
	/* 0x351: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_353:
	/* 0x353: cmp    esi,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_359:
	/* 0x359: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_35c:
	/* 0x35c: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_35f:
	/* 0x35f: shrx   esi,esi,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_364:
	/* 0x364: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_366:
	/* 0x366: cmp    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_369:
	/* 0x369: setae  dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_36d:
	/* 0x36d: shl    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_370:
	/* 0x370: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_375:
	/* 0x375: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_378:
	/* 0x378: cmp    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_37b:
	/* 0x37b: setae  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_37f:
	/* 0x37f: add    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_382:
	/* 0x382: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_387:
	/* 0x387: shr    esi,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_389:
	/* 0x389: or     eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_38b:
	/* 0x38b: or     eax,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_38d:
	/* 0x38d: or     eax,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_390:
	/* 0x390: or     eax,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_392:
	/* 0x392: add    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 32ULL);
x86_l_395:
	/* 0x395: jmp    3fa <handle_switch+0x3e1> */
	X86_SIM_X86_SUB_JMP(0x395, 0x3fa, x86_l_3fa);
x86_l_397:
	/* 0x397: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_39a:
	/* 0x39a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39c:
	/* 0x39c: div    esi */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_39e:
	/* 0x39e: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a1:
	/* 0x3a1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a3:
	/* 0x3a3: shr    rsi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3a7:
	/* 0x3a7: jne    340 <handle_switch+0x327> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3a7, 0x340, x86_l_340);
x86_l_3a9:
	/* 0x3a9: cmp    eax,0x10000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 65536ULL);
x86_l_3ae:
	/* 0x3ae: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3b1:
	/* 0x3b1: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_3b4:
	/* 0x3b4: shrx   esi,eax,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RAX, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_3b9:
	/* 0x3b9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3bb:
	/* 0x3bb: cmp    esi,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_3c1:
	/* 0x3c1: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3c4:
	/* 0x3c4: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_3c7:
	/* 0x3c7: shrx   esi,esi,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_3cc:
	/* 0x3cc: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ce:
	/* 0x3ce: cmp    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3d1:
	/* 0x3d1: setae  dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3d5:
	/* 0x3d5: shl    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_3d8:
	/* 0x3d8: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_3dd:
	/* 0x3dd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e0:
	/* 0x3e0: cmp    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3e3:
	/* 0x3e3: setae  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3e7:
	/* 0x3e7: add    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_3ea:
	/* 0x3ea: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_3ef:
	/* 0x3ef: shr    esi,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3f1:
	/* 0x3f1: or     eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3f3:
	/* 0x3f3: or     eax,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3f5:
	/* 0x3f5: or     eax,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3f8:
	/* 0x3f8: or     eax,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3fa:
	/* 0x3fa: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_3fd:
	/* 0x3fd: mov    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_402:
	/* 0x402: cmovb  edx,eax */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RAX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_405:
	/* 0x405: lock inc DWORD PTR [rcx+rdx*4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RCX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_RDX, 2, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_409:
	/* 0x409: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_410:
	/* 0x410: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_415:
	/* 0x415: call   41a <handle_switch+0x401> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_41a:
	/* 0x41a: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_41e:
	/* 0x41e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_41f:
	/* 0x41f: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_421:
	/* 0x421: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_423:
	/* 0x423: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_423);

x86_sim_ret_dispatch_423:
	switch (__x86_sim_ret_addr) {
	case 0x11ULL: goto x86_l_11;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
