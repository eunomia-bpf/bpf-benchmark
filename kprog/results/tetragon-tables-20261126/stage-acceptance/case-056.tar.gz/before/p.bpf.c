#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(5)
#include "../x86_sim_local_bpf.h"

extern __u8 cilium_calls[] __ksym;
extern __u8 cilium_metrics[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tc/tail")
int p_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: sub    rsp,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 48ULL);
x86_l_8:
	/* 0x8: mov    rax,QWORD PTR [rip+0x9d80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_interface_mac));
x86_l_f:
	/* 0xf: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12:
	/* 0x12: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17:
	/* 0x17: mov    ecx,DWORD PTR [rdi+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1a:
	/* 0x1a: sub    ecx,DWORD PTR [rdi+0x74] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 116ULL);
x86_l_1d:
	/* 0x1d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f:
	/* 0x1f: cmp    ecx,0x2a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 42ULL);
x86_l_22:
	/* 0x22: jb     24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22, 0x24f, x86_l_24f);
x86_l_28:
	/* 0x28: mov    rcx,QWORD PTR [rdi+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2f:
	/* 0x2f: movzx  edx,WORD PTR [rcx+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_33:
	/* 0x33: cmp    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_39:
	/* 0x39: jne    24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39, 0x24f, x86_l_24f);
x86_l_3f:
	/* 0x3f: movzx  edx,WORD PTR [rcx+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_43:
	/* 0x43: cmp    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_49:
	/* 0x49: jne    24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49, 0x24f, x86_l_24f);
x86_l_4f:
	/* 0x4f: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51:
	/* 0x51: mov    r8d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_54:
	/* 0x54: not    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_57:
	/* 0x57: movzx  esi,WORD PTR [rcx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_5b:
	/* 0x5b: mov    r9d,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_5e:
	/* 0x5e: xor    r9d,0xffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_XOR, 65535ULL);
x86_l_65:
	/* 0x65: or     r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_68:
	/* 0x68: je     72 <tail_handle_arp+0x72> */
	X86_SIM_X86_JCC(X86_CC_E, 0x68, 0x72, x86_l_72);
x86_l_6a:
	/* 0x6a: or     edx,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_6c:
	/* 0x6c: jne    24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c, 0x24f, x86_l_24f);
x86_l_72:
	/* 0x72: mov    rdx,QWORD PTR [rcx+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_76:
	/* 0x76: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7b:
	/* 0x7b: mov    edx,DWORD PTR [rcx+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_7e:
	/* 0x7e: mov    ecx,DWORD PTR [rcx+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_81:
	/* 0x81: mov    rsi,QWORD PTR [rip+0x9d80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_endpoint_ipv4));
x86_l_88:
	/* 0x88: cmp    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_8a:
	/* 0x8a: je     24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a, 0x24f, x86_l_24f);
x86_l_90:
	/* 0x90: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_94:
	/* 0x94: mov    DWORD PTR [rsp+0x8],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_98:
	/* 0x98: mov    WORD PTR [rsp+0x6],0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 25769804288ULL);
x86_l_9f:
	/* 0x9f: lea    rdx,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a4:
	/* 0xa4: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a7:
	/* 0xa7: mov    esi,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_ac:
	/* 0xac: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_b1:
	/* 0xb1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b4:
	/* 0xb4: call   9e39 <tail_handle_arp+0x9e39> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_b9:
	/* 0xb9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_bb:
	/* 0xbb: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbb, 0x1ae, x86_l_1ae);
x86_l_c1:
	/* 0xc1: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c6:
	/* 0xc6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c9:
	/* 0xc9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cb:
	/* 0xcb: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_d0:
	/* 0xd0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d3:
	/* 0xd3: call   9e58 <tail_handle_arp+0x9e58> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_d8:
	/* 0xd8: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_da:
	/* 0xda: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0xda, 0x1ae, x86_l_1ae);
x86_l_e0:
	/* 0xe0: lea    rdx,[rsp+0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_e5:
	/* 0xe5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: mov    esi,0x14 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_ed:
	/* 0xed: mov    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f2:
	/* 0xf2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f5:
	/* 0xf5: call   9e7a <tail_handle_arp+0x9e7a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_fa:
	/* 0xfa: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_fc:
	/* 0xfc: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0xfc, 0x1ae, x86_l_1ae);
x86_l_102:
	/* 0x102: lea    rdx,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_107:
	/* 0x107: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10a:
	/* 0x10a: mov    esi,0x16 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_10f:
	/* 0x10f: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_114:
	/* 0x114: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_117:
	/* 0x117: call   9e9c <tail_handle_arp+0x9e9c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_11c:
	/* 0x11c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11e:
	/* 0x11e: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11e, 0x1ae, x86_l_1ae);
x86_l_124:
	/* 0x124: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_129:
	/* 0x129: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12c:
	/* 0x12c: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_131:
	/* 0x131: mov    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_136:
	/* 0x136: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_139:
	/* 0x139: call   9ebe <tail_handle_arp+0x9ebe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_13e:
	/* 0x13e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_140:
	/* 0x140: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x140, 0x1ae, x86_l_1ae);
x86_l_142:
	/* 0x142: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_147:
	/* 0x147: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_14a:
	/* 0x14a: mov    esi,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_14f:
	/* 0x14f: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_154:
	/* 0x154: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157:
	/* 0x157: call   9edc <tail_handle_arp+0x9edc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_15c:
	/* 0x15c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15e:
	/* 0x15e: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15e, 0x1ae, x86_l_1ae);
x86_l_160:
	/* 0x160: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_165:
	/* 0x165: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_167:
	/* 0x167: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16a:
	/* 0x16a: mov    esi,0x26 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 38ULL);
x86_l_16f:
	/* 0x16f: mov    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_174:
	/* 0x174: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_177:
	/* 0x177: call   9efc <tail_handle_arp+0x9efc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_skb_store_bytes);
x86_l_17c:
	/* 0x17c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_17e:
	/* 0x17e: js     1ae <tail_handle_arp+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17e, 0x1ae, x86_l_1ae);
x86_l_180:
	/* 0x180: mov    rax,QWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_184:
	/* 0x184: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_187:
	/* 0x187: je     18f <tail_handle_arp+0x18f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x187, 0x18f, x86_l_18f);
x86_l_189:
	/* 0x189: mov    ebp,DWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_18f:
	/* 0x18f: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_191:
	/* 0x191: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_193:
	/* 0x193: call   9f18 <tail_handle_arp+0x9f18> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_redirect);
x86_l_198:
	/* 0x198: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_19a:
	/* 0x19a: js     25c <tail_handle_arp+0x25c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19a, 0x25c, x86_l_25c);
x86_l_1a0:
	/* 0x1a0: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a3:
	/* 0x1a3: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: jne    24f <tail_handle_arp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a6, 0x24f, x86_l_24f);
x86_l_1ac:
	/* 0x1ac: jmp    1b6 <tail_handle_arp+0x1b6> */
	X86_SIM_X86_JMP(0x1ac, 0x1b6, x86_l_1b6);
x86_l_1ae:
	/* 0x1ae: mov    eax,0xffffff73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967155ULL);
x86_l_1b3:
	/* 0x1b3: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b6:
	/* 0x1b6: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b8:
	/* 0x1b8: neg    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_1ba:
	/* 0x1ba: jns    1be <tail_handle_arp+0x1be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba, 0x1be, x86_l_1be);
x86_l_1bc:
	/* 0x1bc: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1be:
	/* 0x1be: mov    QWORD PTR [rcx+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1c6:
	/* 0x1c6: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1c9:
	/* 0x1c9: mov    DWORD PTR [rcx+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1cc:
	/* 0x1cc: movabs rdx,0x6f7020200000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 501872091088289792ULL);
x86_l_1d6:
	/* 0x1d6: mov    QWORD PTR [rcx+0x3c],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1da:
	/* 0x1da: mov    r14d,DWORD PTR [rcx+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1de:
	/* 0x1de: movabs rcx,0x206f70200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8706785792ULL);
x86_l_1e8:
	/* 0x1e8: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ed:
	/* 0x1ed: mov    BYTE PTR [rsp+0x8],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f1:
	/* 0x1f1: mov    rdi,QWORD PTR [rip+0x9d80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_1f8:
	/* 0x1f8: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fd:
	/* 0x1fd: call   9f82 <tail_handle_arp+0x9f82> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_202:
	/* 0x202: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_205:
	/* 0x205: je     210 <tail_handle_arp+0x210> */
	X86_SIM_X86_JCC(X86_CC_E, 0x205, 0x210, x86_l_210);
x86_l_207:
	/* 0x207: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_20a:
	/* 0x20a: add    QWORD PTR [rax+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_20e:
	/* 0x20e: jmp    236 <tail_handle_arp+0x236> */
	X86_SIM_X86_JMP(0x20e, 0x236, x86_l_236);
x86_l_210:
	/* 0x210: mov    QWORD PTR [rsp+0x20],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953473ULL);
x86_l_219:
	/* 0x219: mov    QWORD PTR [rsp+0x28],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21e:
	/* 0x21e: mov    rdi,QWORD PTR [rip+0x9d80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_metrics));
x86_l_225:
	/* 0x225: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22a:
	/* 0x22a: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22f:
	/* 0x22f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_231:
	/* 0x231: call   9fb6 <tail_handle_arp+0x9fb6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_236:
	/* 0x236: mov    rsi,QWORD PTR [rip+0x9d80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_calls));
x86_l_23d:
	/* 0x23d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_240:
	/* 0x240: mov    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_245:
	/* 0x245: call   9fca <tail_handle_arp+0x9fca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_24a:
	/* 0x24a: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24f:
	/* 0x24f: add    rsp,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_253:
	/* 0x253: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_254:
	/* 0x254: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_256:
	/* 0x256: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_257:
	/* 0x257: jmp    26e <tail_handle_arp+0x26e> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_25c:
	/* 0x25c: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25f:
	/* 0x25f: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_261:
	/* 0x261: neg    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_263:
	/* 0x263: js     1bc <tail_handle_arp+0x1bc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x263, 0x1bc, x86_l_1bc);
x86_l_269:
	/* 0x269: jmp    1be <tail_handle_arp+0x1be> */
	X86_SIM_X86_JMP(0x269, 0x1be, x86_l_1be);
x86_l_26e:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
