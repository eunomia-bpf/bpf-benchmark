#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 392U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(11) M(12) M(14) M(15) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(36) M(37) M(38) M(39) M(40) M(41) M(42)
#include "../x86_sim_local_bpf.h"

extern __u8 exe_id_to_10_stack_deltas[] __ksym;
extern __u8 exe_id_to_11_stack_deltas[] __ksym;
extern __u8 exe_id_to_12_stack_deltas[] __ksym;
extern __u8 exe_id_to_13_stack_deltas[] __ksym;
extern __u8 exe_id_to_14_stack_deltas[] __ksym;
extern __u8 exe_id_to_15_stack_deltas[] __ksym;
extern __u8 exe_id_to_16_stack_deltas[] __ksym;
extern __u8 exe_id_to_17_stack_deltas[] __ksym;
extern __u8 exe_id_to_18_stack_deltas[] __ksym;
extern __u8 exe_id_to_19_stack_deltas[] __ksym;
extern __u8 exe_id_to_20_stack_deltas[] __ksym;
extern __u8 exe_id_to_21_stack_deltas[] __ksym;
extern __u8 exe_id_to_22_stack_deltas[] __ksym;
extern __u8 exe_id_to_23_stack_deltas[] __ksym;
extern __u8 exe_id_to_8_stack_deltas[] __ksym;
extern __u8 exe_id_to_9_stack_deltas[] __ksym;
extern __u8 interpreter_offsets[] __ksym;
extern __u8 metrics[] __ksym;
extern __u8 per_cpu_records[] __ksym;
extern __u8 perf_progs[] __ksym;
extern __u8 pid_page_to_mapping_info[] __ksym;
extern __u8 stack_delta_page_to_info[] __ksym;
extern __u8 unwind_info_array[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_STORE, X86_OP_MOVBE_STORE)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("perf_event/unwind_native")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 344ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2e:
	/* 0x2e: call   33 <perf_unwind_native+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     54c9 <perf_unwind_native+0x54c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x54c9, x86_l_54c9);
x86_l_3c:
	/* 0x3c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42:
	/* 0x42: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_49:
	/* 0x49: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e:
	/* 0x4e: jne    587 <perf_unwind_native+0x587> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4e, 0x587, x86_l_587);
x86_l_54:
	/* 0x54: mov    DWORD PTR [rsp+0x10],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476741ULL);
x86_l_5c:
	/* 0x5c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_63:
	/* 0x63: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_68:
	/* 0x68: call   6d <perf_unwind_native+0x6d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d:
	/* 0x6d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_70:
	/* 0x70: je     112 <perf_unwind_native+0x112> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70, 0x112, x86_l_112);
x86_l_76:
	/* 0x76: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_79:
	/* 0x79: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e:
	/* 0x7e: je     11d <perf_unwind_native+0x11d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e, 0x11d, x86_l_11d);
x86_l_84:
	/* 0x84: movabs rax,0x63617473206e6f20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7161132920309968672ULL);
x86_l_8e:
	/* 0x8e: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_96:
	/* 0x96: movabs rax,0x7525206e6f697469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8441188735263536233ULL);
x86_l_a0:
	/* 0xa0: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_a8:
	/* 0xa8: movabs rax,0x736f70206f742078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8317990321387741304ULL);
x86_l_b2:
	/* 0xb2: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_ba:
	/* 0xba: movabs rax,0x6c6c2520786c6c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274970520613ULL);
x86_l_c4:
	/* 0xc4: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cc:
	/* 0xcc: movabs rax,0x20676e6968737550 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334956330817910096ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_de:
	/* 0xde: mov    DWORD PTR [rsp+0xb7],0xa6b63 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 785979698019ULL);
x86_l_e9:
	/* 0xe9: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_f0:
	/* 0xf0: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_f7:
	/* 0xf7: mov    r8d,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_fe:
	/* 0xfe: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_106:
	/* 0x106: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_10b:
	/* 0x10b: call   110 <perf_unwind_native+0x110> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_110:
	/* 0x110: jmp    11d <perf_unwind_native+0x11d> */
	X86_SIM_X86_JMP(0x110, 0x11d, x86_l_11d);
x86_l_112:
	/* 0x112: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_117:
	/* 0x117: jne    701 <perf_unwind_native+0x701> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x117, 0x701, x86_l_701);
x86_l_11d:
	/* 0x11d: mov    eax,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_123:
	/* 0x123: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_127:
	/* 0x127: jb     1de <perf_unwind_native+0x1de> */
	X86_SIM_X86_JCC(X86_CC_B, 0x127, 0x1de, x86_l_1de);
x86_l_12d:
	/* 0x12d: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_132:
	/* 0x132: jne    631 <perf_unwind_native+0x631> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x132, 0x631, x86_l_631);
x86_l_138:
	/* 0x138: mov    DWORD PTR [rsp+0x10],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476738ULL);
x86_l_140:
	/* 0x140: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_147:
	/* 0x147: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14c:
	/* 0x14c: call   151 <perf_unwind_native+0x151> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_151:
	/* 0x151: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_154:
	/* 0x154: je     2ca <perf_unwind_native+0x2ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x154, 0x2ca, x86_l_2ca);
x86_l_15a:
	/* 0x15a: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_15d:
	/* 0x15d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_160:
	/* 0x160: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_167:
	/* 0x167: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a:
	/* 0x16a: mov    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_16f:
	/* 0x16f: je     541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16f, 0x541d, x86_l_541d);
x86_l_175:
	/* 0x175: movabs rax,0xa656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926270227834400ULL);
x86_l_17f:
	/* 0x17f: mov    QWORD PTR [rsp+0xa5],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_187:
	/* 0x187: movabs rax,0x7266206576697461 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243311788098679905ULL);
x86_l_191:
	/* 0x191: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_199:
	/* 0x199: movabs rax,0x6e2068737570206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7935457388527624303ULL);
x86_l_1a3:
	/* 0x1a3: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1ab:
	/* 0x1ab: movabs rax,0x742064656c696166 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701606ULL);
x86_l_1b5:
	/* 0x1b5: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1bd:
	/* 0x1bd: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c0:
	/* 0x1c0: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1c8:
	/* 0x1c8: mov    esi,0x1d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_1cd:
	/* 0x1cd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cf:
	/* 0x1cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d1:
	/* 0x1d1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d4:
	/* 0x1d4: call   1d9 <perf_unwind_native+0x1d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1d9:
	/* 0x1d9: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x1d9, 0x541d, x86_l_541d);
x86_l_1de:
	/* 0x1de: mov    QWORD PTR [rsp+0x58],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1e3:
	/* 0x1e3: movzx  ecx,BYTE PTR [rbx+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_1ea:
	/* 0x1ea: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1f1:
	/* 0x1f1: mov    rsi,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1f8:
	/* 0x1f8: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1fb:
	/* 0x1fb: mov    DWORD PTR [rbx+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_201:
	/* 0x201: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_205:
	/* 0x205: mov    QWORD PTR [rbx+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_20d:
	/* 0x20d: mov    QWORD PTR [rbx+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_215:
	/* 0x215: mov    BYTE PTR [rbx+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_21d:
	/* 0x21d: mov    BYTE PTR [rbx+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_224:
	/* 0x224: mov    DWORD PTR [rbx+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_22f:
	/* 0x22f: mov    WORD PTR [rbx+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_239:
	/* 0x239: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_241:
	/* 0x241: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_248:
	/* 0x248: mov    QWORD PTR [rsp+0x150],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_250:
	/* 0x250: mov    QWORD PTR [rsp+0x70],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_255:
	/* 0x255: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_25c:
	/* 0x25c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25f:
	/* 0x25f: and    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709486080ULL);
x86_l_265:
	/* 0x265: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_26a:
	/* 0x26a: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f:
	/* 0x26f: jne    6a9 <perf_unwind_native+0x6a9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26f, 0x6a9, x86_l_6a9);
x86_l_275:
	/* 0x275: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_27c:
	/* 0x27c: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_281:
	/* 0x281: call   286 <perf_unwind_native+0x286> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_286:
	/* 0x286: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_289:
	/* 0x289: je     5100 <perf_unwind_native+0x5100> */
	X86_SIM_X86_JCC(X86_CC_E, 0x289, 0x5100, x86_l_5100);
x86_l_28f:
	/* 0x28f: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_292:
	/* 0x292: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_296:
	/* 0x296: movzx  ecx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_299:
	/* 0x299: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_29c:
	/* 0x29c: jg     2e2 <perf_unwind_native+0x2e2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x29c, 0x2e2, x86_l_2e2);
x86_l_29e:
	/* 0x29e: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2a1:
	/* 0x2a1: jg     30e <perf_unwind_native+0x30e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2a1, 0x30e, x86_l_30e);
x86_l_2a3:
	/* 0x2a3: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2a6:
	/* 0x2a6: jg     354 <perf_unwind_native+0x354> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2a6, 0x354, x86_l_354);
x86_l_2ac:
	/* 0x2ac: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2af:
	/* 0x2af: je     3b7 <perf_unwind_native+0x3b7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2af, 0x3b7, x86_l_3b7);
x86_l_2b5:
	/* 0x2b5: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2b8:
	/* 0x2b8: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b8, 0x5276, x86_l_5276);
x86_l_2be:
	/* 0x2be: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas));
x86_l_2c5:
	/* 0x2c5: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x2c5, 0x3fd, x86_l_3fd);
x86_l_2ca:
	/* 0x2ca: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cf:
	/* 0x2cf: jne    7df <perf_unwind_native+0x7df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cf, 0x7df, x86_l_7df);
x86_l_2d5:
	/* 0x2d5: mov    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2da:
	/* 0x2da: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dd:
	/* 0x2dd: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x2dd, 0x541d, x86_l_541d);
x86_l_2e2:
	/* 0x2e2: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_2e5:
	/* 0x2e5: jg     331 <perf_unwind_native+0x331> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2e5, 0x331, x86_l_331);
x86_l_2e7:
	/* 0x2e7: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2ea:
	/* 0x2ea: jg     372 <perf_unwind_native+0x372> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2ea, 0x372, x86_l_372);
x86_l_2f0:
	/* 0x2f0: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2f3:
	/* 0x2f3: je     3c0 <perf_unwind_native+0x3c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f3, 0x3c0, x86_l_3c0);
x86_l_2f9:
	/* 0x2f9: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2fc:
	/* 0x2fc: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fc, 0x5276, x86_l_5276);
x86_l_302:
	/* 0x302: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas));
x86_l_309:
	/* 0x309: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x309, 0x3fd, x86_l_3fd);
x86_l_30e:
	/* 0x30e: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_311:
	/* 0x311: jg     389 <perf_unwind_native+0x389> */
	X86_SIM_X86_JCC(X86_CC_G, 0x311, 0x389, x86_l_389);
x86_l_313:
	/* 0x313: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_316:
	/* 0x316: je     3c9 <perf_unwind_native+0x3c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x316, 0x3c9, x86_l_3c9);
x86_l_31c:
	/* 0x31c: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_31f:
	/* 0x31f: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31f, 0x5276, x86_l_5276);
x86_l_325:
	/* 0x325: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas));
x86_l_32c:
	/* 0x32c: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x32c, 0x3fd, x86_l_3fd);
x86_l_331:
	/* 0x331: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_334:
	/* 0x334: jg     3a0 <perf_unwind_native+0x3a0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x334, 0x3a0, x86_l_3a0);
x86_l_336:
	/* 0x336: cmp    ecx,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_339:
	/* 0x339: je     3d2 <perf_unwind_native+0x3d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x339, 0x3d2, x86_l_3d2);
x86_l_33f:
	/* 0x33f: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_342:
	/* 0x342: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x342, 0x5276, x86_l_5276);
x86_l_348:
	/* 0x348: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas));
x86_l_34f:
	/* 0x34f: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x34f, 0x3fd, x86_l_3fd);
x86_l_354:
	/* 0x354: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_357:
	/* 0x357: je     3db <perf_unwind_native+0x3db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x357, 0x3db, x86_l_3db);
x86_l_35d:
	/* 0x35d: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_360:
	/* 0x360: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x360, 0x5276, x86_l_5276);
x86_l_366:
	/* 0x366: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas));
x86_l_36d:
	/* 0x36d: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x36d, 0x3fd, x86_l_3fd);
x86_l_372:
	/* 0x372: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_375:
	/* 0x375: je     3e4 <perf_unwind_native+0x3e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x375, 0x3e4, x86_l_3e4);
x86_l_377:
	/* 0x377: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_37a:
	/* 0x37a: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37a, 0x5276, x86_l_5276);
x86_l_380:
	/* 0x380: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas));
x86_l_387:
	/* 0x387: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x387, 0x3fd, x86_l_3fd);
x86_l_389:
	/* 0x389: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_38c:
	/* 0x38c: je     3ed <perf_unwind_native+0x3ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38c, 0x3ed, x86_l_3ed);
x86_l_38e:
	/* 0x38e: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_391:
	/* 0x391: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x391, 0x5276, x86_l_5276);
x86_l_397:
	/* 0x397: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas));
x86_l_39e:
	/* 0x39e: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x39e, 0x3fd, x86_l_3fd);
x86_l_3a0:
	/* 0x3a0: cmp    ecx,0x16 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_3a3:
	/* 0x3a3: je     3f6 <perf_unwind_native+0x3f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a3, 0x3f6, x86_l_3f6);
x86_l_3a5:
	/* 0x3a5: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_3a8:
	/* 0x3a8: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a8, 0x5276, x86_l_5276);
x86_l_3ae:
	/* 0x3ae: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas));
x86_l_3b5:
	/* 0x3b5: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3b5, 0x3fd, x86_l_3fd);
x86_l_3b7:
	/* 0x3b7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas));
x86_l_3be:
	/* 0x3be: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3be, 0x3fd, x86_l_3fd);
x86_l_3c0:
	/* 0x3c0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas));
x86_l_3c7:
	/* 0x3c7: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3c7, 0x3fd, x86_l_3fd);
x86_l_3c9:
	/* 0x3c9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas));
x86_l_3d0:
	/* 0x3d0: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3d0, 0x3fd, x86_l_3fd);
x86_l_3d2:
	/* 0x3d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas));
x86_l_3d9:
	/* 0x3d9: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3d9, 0x3fd, x86_l_3fd);
x86_l_3db:
	/* 0x3db: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas));
x86_l_3e2:
	/* 0x3e2: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3e2, 0x3fd, x86_l_3fd);
x86_l_3e4:
	/* 0x3e4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas));
x86_l_3eb:
	/* 0x3eb: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3eb, 0x3fd, x86_l_3fd);
x86_l_3ed:
	/* 0x3ed: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas));
x86_l_3f4:
	/* 0x3f4: jmp    3fd <perf_unwind_native+0x3fd> */
	X86_SIM_X86_JMP(0x3f4, 0x3fd, x86_l_3fd);
x86_l_3f6:
	/* 0x3f6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas));
x86_l_3fd:
	/* 0x3fd: lea    rsi,[rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_405:
	/* 0x405: call   40a <perf_unwind_native+0x40a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_40a:
	/* 0x40a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40d:
	/* 0x40d: je     53f1 <perf_unwind_native+0x53f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40d, 0x53f1, x86_l_53f1);
x86_l_413:
	/* 0x413: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_416:
	/* 0x416: mov    r12d,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_419:
	/* 0x419: mov    DWORD PTR [rsp+0x6c],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_41e:
	/* 0x41e: mov    rax,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_425:
	/* 0x425: mov    QWORD PTR [rsp+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_42a:
	/* 0x42a: movzx  ebp,WORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_42f:
	/* 0x42f: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_431:
	/* 0x431: je     b35 <perf_unwind_native+0xb35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x431, 0xb35, x86_l_b35);
x86_l_437:
	/* 0x437: add    ebp,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_43a:
	/* 0x43a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_441:
	/* 0x441: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_444:
	/* 0x444: jne    86b <perf_unwind_native+0x86b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x444, 0x86b, x86_l_86b);
x86_l_44a:
	/* 0x44a: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_44e:
	/* 0x44e: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_450:
	/* 0x450: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_454:
	/* 0x454: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_459:
	/* 0x459: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_45c:
	/* 0x45c: call   461 <perf_unwind_native+0x461> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_461:
	/* 0x461: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_464:
	/* 0x464: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x464, 0xbe2, x86_l_be2);
x86_l_46a:
	/* 0x46a: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_46e:
	/* 0x46e: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_473:
	/* 0x473: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_476:
	/* 0x476: ja     487 <perf_unwind_native+0x487> */
	X86_SIM_X86_JCC(X86_CC_A, 0x476, 0x487, x86_l_487);
x86_l_478:
	/* 0x478: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_47a:
	/* 0x47a: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_47d:
	/* 0x47d: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_480:
	/* 0x480: jb     492 <perf_unwind_native+0x492> */
	X86_SIM_X86_JCC(X86_CC_B, 0x480, 0x492, x86_l_492);
x86_l_482:
	/* 0x482: jmp    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JMP(0x482, 0xb2a, x86_l_b2a);
x86_l_487:
	/* 0x487: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_489:
	/* 0x489: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_48c:
	/* 0x48c: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x48c, 0xb2a, x86_l_b2a);
x86_l_492:
	/* 0x492: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_496:
	/* 0x496: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_498:
	/* 0x498: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49c:
	/* 0x49c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4a1:
	/* 0x4a1: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4a4:
	/* 0x4a4: call   4a9 <perf_unwind_native+0x4a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4a9:
	/* 0x4a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ac:
	/* 0x4ac: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ac, 0xbe2, x86_l_be2);
x86_l_4b2:
	/* 0x4b2: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b6:
	/* 0x4b6: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4bb:
	/* 0x4bb: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4be:
	/* 0x4be: ja     4c7 <perf_unwind_native+0x4c7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4be, 0x4c7, x86_l_4c7);
x86_l_4c0:
	/* 0x4c0: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_4c2:
	/* 0x4c2: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4c5:
	/* 0x4c5: jmp    4c9 <perf_unwind_native+0x4c9> */
	X86_SIM_X86_JMP(0x4c5, 0x4c9, x86_l_4c9);
x86_l_4c7:
	/* 0x4c7: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4c9:
	/* 0x4c9: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_4cc:
	/* 0x4cc: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4cc, 0xb2a, x86_l_b2a);
x86_l_4d2:
	/* 0x4d2: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_4d6:
	/* 0x4d6: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_4d8:
	/* 0x4d8: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4dc:
	/* 0x4dc: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e1:
	/* 0x4e1: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4e4:
	/* 0x4e4: call   4e9 <perf_unwind_native+0x4e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4e9:
	/* 0x4e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ec:
	/* 0x4ec: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ec, 0xbe2, x86_l_be2);
x86_l_4f2:
	/* 0x4f2: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f6:
	/* 0x4f6: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4fb:
	/* 0x4fb: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fe:
	/* 0x4fe: ja     507 <perf_unwind_native+0x507> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4fe, 0x507, x86_l_507);
x86_l_500:
	/* 0x500: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_502:
	/* 0x502: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_505:
	/* 0x505: jmp    509 <perf_unwind_native+0x509> */
	X86_SIM_X86_JMP(0x505, 0x509, x86_l_509);
x86_l_507:
	/* 0x507: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_509:
	/* 0x509: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_50c:
	/* 0x50c: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x50c, 0xb2a, x86_l_b2a);
x86_l_512:
	/* 0x512: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_516:
	/* 0x516: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_518:
	/* 0x518: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_51c:
	/* 0x51c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_521:
	/* 0x521: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_524:
	/* 0x524: call   529 <perf_unwind_native+0x529> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_529:
	/* 0x529: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52c:
	/* 0x52c: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52c, 0xbe2, x86_l_be2);
x86_l_532:
	/* 0x532: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_536:
	/* 0x536: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_53b:
	/* 0x53b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53e:
	/* 0x53e: ja     547 <perf_unwind_native+0x547> */
	X86_SIM_X86_JCC(X86_CC_A, 0x53e, 0x547, x86_l_547);
x86_l_540:
	/* 0x540: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_542:
	/* 0x542: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_545:
	/* 0x545: jmp    549 <perf_unwind_native+0x549> */
	X86_SIM_X86_JMP(0x545, 0x549, x86_l_549);
x86_l_547:
	/* 0x547: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_549:
	/* 0x549: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_54c:
	/* 0x54c: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x54c, 0xb2a, x86_l_b2a);
x86_l_552:
	/* 0x552: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_556:
	/* 0x556: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_558:
	/* 0x558: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_55c:
	/* 0x55c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_561:
	/* 0x561: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_564:
	/* 0x564: call   569 <perf_unwind_native+0x569> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_569:
	/* 0x569: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56c:
	/* 0x56c: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56c, 0xbe2, x86_l_be2);
x86_l_572:
	/* 0x572: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_576:
	/* 0x576: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_57b:
	/* 0x57b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57e:
	/* 0x57e: ja     5ea <perf_unwind_native+0x5ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0x57e, 0x5ea, x86_l_5ea);
x86_l_580:
	/* 0x580: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_582:
	/* 0x582: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_585:
	/* 0x585: jmp    5ec <perf_unwind_native+0x5ec> */
	X86_SIM_X86_JMP(0x585, 0x5ec, x86_l_5ec);
x86_l_587:
	/* 0x587: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_58d:
	/* 0x58d: movabs rax,0x3d3d206425206576 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4412718824384652662ULL);
x86_l_597:
	/* 0x597: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_59f:
	/* 0x59f: movabs rax,0x6974616e5f646e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7598805597955583593ULL);
x86_l_5a9:
	/* 0x5a9: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_5b1:
	/* 0x5b1: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8605944719278423357ULL);
x86_l_5bb:
	/* 0x5bb: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_5c3:
	/* 0x5c3: mov    DWORD PTR [rsp+0xa8],0xa3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721555176765ULL);
x86_l_5ce:
	/* 0x5ce: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_5d6:
	/* 0x5d6: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_5db:
	/* 0x5db: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5dd:
	/* 0x5dd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e0:
	/* 0x5e0: call   5e5 <perf_unwind_native+0x5e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5e5:
	/* 0x5e5: jmp    54 <perf_unwind_native+0x54> */
	X86_SIM_X86_JMP(0x5e5, 0x54, x86_l_54);
x86_l_5ea:
	/* 0x5ea: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5ec:
	/* 0x5ec: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_5ef:
	/* 0x5ef: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5ef, 0xb2a, x86_l_b2a);
x86_l_5f5:
	/* 0x5f5: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_5f9:
	/* 0x5f9: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5fb:
	/* 0x5fb: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5ff:
	/* 0x5ff: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_604:
	/* 0x604: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_607:
	/* 0x607: call   60c <perf_unwind_native+0x60c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_60c:
	/* 0x60c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_60f:
	/* 0x60f: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60f, 0xbe2, x86_l_be2);
x86_l_615:
	/* 0x615: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_619:
	/* 0x619: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_61e:
	/* 0x61e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_621:
	/* 0x621: ja     798 <perf_unwind_native+0x798> */
	X86_SIM_X86_JCC(X86_CC_A, 0x621, 0x798, x86_l_798);
x86_l_627:
	/* 0x627: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_629:
	/* 0x629: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_62c:
	/* 0x62c: jmp    79a <perf_unwind_native+0x79a> */
	X86_SIM_X86_JMP(0x62c, 0x79a, x86_l_79a);
x86_l_631:
	/* 0x631: movabs rax,0xa6c6c75662073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2933962849001587ULL);
x86_l_63b:
	/* 0x63b: mov    QWORD PTR [rsp+0xad],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 173ULL);
x86_l_643:
	/* 0x643: movabs rax,0x66207369206b6361 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359008686476059489ULL);
x86_l_64d:
	/* 0x64d: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_655:
	/* 0x655: movabs rax,0x7473203a656d6172 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8391085965903225202ULL);
x86_l_65f:
	/* 0x65f: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_667:
	/* 0x667: movabs rax,0x662068737570206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358996636224200815ULL);
x86_l_671:
	/* 0x671: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_679:
	/* 0x679: movabs rax,0x7420656c62616e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367799623835807349ULL);
x86_l_683:
	/* 0x683: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_68b:
	/* 0x68b: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_693:
	/* 0x693: mov    esi,0x25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_698:
	/* 0x698: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69a:
	/* 0x69a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69c:
	/* 0x69c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69f:
	/* 0x69f: call   6a4 <perf_unwind_native+0x6a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6a4:
	/* 0x6a4: jmp    138 <perf_unwind_native+0x138> */
	X86_SIM_X86_JMP(0x6a4, 0x138, x86_l_138);
x86_l_6a9:
	/* 0x6a9: movabs rax,0xa786c253a786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471844735118373ULL);
x86_l_6b3:
	/* 0x6b3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6b8:
	/* 0x6b8: movabs rax,0x20726f662061746c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338053640979313772ULL);
x86_l_6c2:
	/* 0x6c2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6c7:
	/* 0x6c7: movabs rax,0x6564206b63617473 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7306000141102707827ULL);
x86_l_6d1:
	/* 0x6d1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6d6:
	/* 0x6d6: movabs rax,0x207075206b6f6f4c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337496988707155788ULL);
x86_l_6e0:
	/* 0x6e0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6e5:
	/* 0x6e5: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_6ea:
	/* 0x6ea: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6ef:
	/* 0x6ef: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_6f4:
	/* 0x6f4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f7:
	/* 0x6f7: call   6fc <perf_unwind_native+0x6fc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6fc:
	/* 0x6fc: jmp    275 <perf_unwind_native+0x275> */
	X86_SIM_X86_JMP(0x6fc, 0x275, x86_l_275);
x86_l_701:
	/* 0x701: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_70b:
	/* 0x70b: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_713:
	/* 0x713: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_71d:
	/* 0x71d: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_725:
	/* 0x725: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_72f:
	/* 0x72f: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_737:
	/* 0x737: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_741:
	/* 0x741: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_749:
	/* 0x749: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_753:
	/* 0x753: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_75b:
	/* 0x75b: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_765:
	/* 0x765: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_76d:
	/* 0x76d: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_771:
	/* 0x771: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_779:
	/* 0x779: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_77e:
	/* 0x77e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_780:
	/* 0x780: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_783:
	/* 0x783: call   788 <perf_unwind_native+0x788> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_788:
	/* 0x788: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_78d:
	/* 0x78d: je     11d <perf_unwind_native+0x11d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x78d, 0x11d, x86_l_11d);
x86_l_793:
	/* 0x793: jmp    84 <perf_unwind_native+0x84> */
	X86_SIM_X86_JMP(0x793, 0x84, x86_l_84);
x86_l_798:
	/* 0x798: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_79a:
	/* 0x79a: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_79d:
	/* 0x79d: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x79d, 0xb2a, x86_l_b2a);
x86_l_7a3:
	/* 0x7a3: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_7a7:
	/* 0x7a7: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_7a9:
	/* 0x7a9: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ad:
	/* 0x7ad: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7b2:
	/* 0x7b2: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7b5:
	/* 0x7b5: call   7ba <perf_unwind_native+0x7ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7ba:
	/* 0x7ba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bd:
	/* 0x7bd: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7bd, 0xbe2, x86_l_be2);
x86_l_7c3:
	/* 0x7c3: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7c7:
	/* 0x7c7: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_7cc:
	/* 0x7cc: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7cf:
	/* 0x7cf: ja     8e3 <perf_unwind_native+0x8e3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7cf, 0x8e3, x86_l_8e3);
x86_l_7d5:
	/* 0x7d5: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_7d7:
	/* 0x7d7: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7da:
	/* 0x7da: jmp    8e5 <perf_unwind_native+0x8e5> */
	X86_SIM_X86_JMP(0x7da, 0x8e5, x86_l_8e5);
x86_l_7df:
	/* 0x7df: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_7e9:
	/* 0x7e9: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_7f1:
	/* 0x7f1: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_7fb:
	/* 0x7fb: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_803:
	/* 0x803: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_80d:
	/* 0x80d: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_815:
	/* 0x815: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_81f:
	/* 0x81f: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_827:
	/* 0x827: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_831:
	/* 0x831: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_839:
	/* 0x839: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_843:
	/* 0x843: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_84b:
	/* 0x84b: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_84f:
	/* 0x84f: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_857:
	/* 0x857: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_85c:
	/* 0x85c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85e:
	/* 0x85e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_861:
	/* 0x861: call   866 <perf_unwind_native+0x866> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_866:
	/* 0x866: jmp    15d <perf_unwind_native+0x15d> */
	X86_SIM_X86_JMP(0x866, 0x15d, x86_l_15d);
x86_l_86b:
	/* 0x86b: movabs rax,0xa296425204449 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2860259863446601ULL);
x86_l_875:
	/* 0x875: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_87a:
	/* 0x87a: movabs rax,0x70616d2820756c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8097873624099548197ULL);
x86_l_884:
	/* 0x884: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_889:
	/* 0x889: movabs rax,0x206f7420756c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337214414386373920ULL);
x86_l_893:
	/* 0x893: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_898:
	/* 0x898: movabs rax,0x6d6f726620656220 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7885647255504773664ULL);
x86_l_8a2:
	/* 0x8a2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8a7:
	/* 0x8a7: movabs rax,0x646c756f68732073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7236287822631739507ULL);
x86_l_8b1:
	/* 0x8b1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8b6:
	/* 0x8b6: movabs rax,0x6c61767265746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653462537629257ULL);
x86_l_8c0:
	/* 0x8c0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8c5:
	/* 0x8c5: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_8c7:
	/* 0x8c7: movzx  r8d,WORD PTR [r14+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_8cc:
	/* 0x8cc: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8d1:
	/* 0x8d1: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_8d6:
	/* 0x8d6: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8d9:
	/* 0x8d9: call   8de <perf_unwind_native+0x8de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_8de:
	/* 0x8de: jmp    44a <perf_unwind_native+0x44a> */
	X86_SIM_X86_JMP(0x8de, 0x44a, x86_l_44a);
x86_l_8e3:
	/* 0x8e3: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_8e5:
	/* 0x8e5: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_8e8:
	/* 0x8e8: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x8e8, 0xb2a, x86_l_b2a);
x86_l_8ee:
	/* 0x8ee: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_8f2:
	/* 0x8f2: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_8f4:
	/* 0x8f4: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8f8:
	/* 0x8f8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8fd:
	/* 0x8fd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_900:
	/* 0x900: call   905 <perf_unwind_native+0x905> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_905:
	/* 0x905: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_908:
	/* 0x908: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x908, 0xbe2, x86_l_be2);
x86_l_90e:
	/* 0x90e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_912:
	/* 0x912: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_917:
	/* 0x917: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91a:
	/* 0x91a: ja     923 <perf_unwind_native+0x923> */
	X86_SIM_X86_JCC(X86_CC_A, 0x91a, 0x923, x86_l_923);
x86_l_91c:
	/* 0x91c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_91e:
	/* 0x91e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_921:
	/* 0x921: jmp    925 <perf_unwind_native+0x925> */
	X86_SIM_X86_JMP(0x921, 0x925, x86_l_925);
x86_l_923:
	/* 0x923: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_925:
	/* 0x925: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_928:
	/* 0x928: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x928, 0xb2a, x86_l_b2a);
x86_l_92e:
	/* 0x92e: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_932:
	/* 0x932: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_934:
	/* 0x934: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_938:
	/* 0x938: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_93d:
	/* 0x93d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_940:
	/* 0x940: call   945 <perf_unwind_native+0x945> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_945:
	/* 0x945: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_948:
	/* 0x948: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x948, 0xbe2, x86_l_be2);
x86_l_94e:
	/* 0x94e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_952:
	/* 0x952: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_957:
	/* 0x957: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95a:
	/* 0x95a: ja     963 <perf_unwind_native+0x963> */
	X86_SIM_X86_JCC(X86_CC_A, 0x95a, 0x963, x86_l_963);
x86_l_95c:
	/* 0x95c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_95e:
	/* 0x95e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_961:
	/* 0x961: jmp    965 <perf_unwind_native+0x965> */
	X86_SIM_X86_JMP(0x961, 0x965, x86_l_965);
x86_l_963:
	/* 0x963: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_965:
	/* 0x965: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_968:
	/* 0x968: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x968, 0xb2a, x86_l_b2a);
x86_l_96e:
	/* 0x96e: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_972:
	/* 0x972: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_974:
	/* 0x974: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_978:
	/* 0x978: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_97d:
	/* 0x97d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_980:
	/* 0x980: call   985 <perf_unwind_native+0x985> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_985:
	/* 0x985: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_988:
	/* 0x988: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x988, 0xbe2, x86_l_be2);
x86_l_98e:
	/* 0x98e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_992:
	/* 0x992: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_997:
	/* 0x997: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_99a:
	/* 0x99a: ja     9a3 <perf_unwind_native+0x9a3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x99a, 0x9a3, x86_l_9a3);
x86_l_99c:
	/* 0x99c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_99e:
	/* 0x99e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9a1:
	/* 0x9a1: jmp    9a5 <perf_unwind_native+0x9a5> */
	X86_SIM_X86_JMP(0x9a1, 0x9a5, x86_l_9a5);
x86_l_9a3:
	/* 0x9a3: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9a5:
	/* 0x9a5: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_9a8:
	/* 0x9a8: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x9a8, 0xb2a, x86_l_b2a);
x86_l_9ae:
	/* 0x9ae: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_9b2:
	/* 0x9b2: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_9b4:
	/* 0x9b4: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9b8:
	/* 0x9b8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9bd:
	/* 0x9bd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_9c0:
	/* 0x9c0: call   9c5 <perf_unwind_native+0x9c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9c5:
	/* 0x9c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c8:
	/* 0x9c8: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c8, 0xbe2, x86_l_be2);
x86_l_9ce:
	/* 0x9ce: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d2:
	/* 0x9d2: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_9d7:
	/* 0x9d7: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9da:
	/* 0x9da: ja     9e3 <perf_unwind_native+0x9e3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9da, 0x9e3, x86_l_9e3);
x86_l_9dc:
	/* 0x9dc: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_9de:
	/* 0x9de: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9e1:
	/* 0x9e1: jmp    9e5 <perf_unwind_native+0x9e5> */
	X86_SIM_X86_JMP(0x9e1, 0x9e5, x86_l_9e5);
x86_l_9e3:
	/* 0x9e3: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9e5:
	/* 0x9e5: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_9e8:
	/* 0x9e8: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x9e8, 0xb2a, x86_l_b2a);
x86_l_9ee:
	/* 0x9ee: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_9f2:
	/* 0x9f2: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_9f4:
	/* 0x9f4: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9f8:
	/* 0x9f8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9fd:
	/* 0x9fd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a00:
	/* 0xa00: call   a05 <perf_unwind_native+0xa05> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a05:
	/* 0xa05: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a08:
	/* 0xa08: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa08, 0xbe2, x86_l_be2);
x86_l_a0e:
	/* 0xa0e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a12:
	/* 0xa12: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a17:
	/* 0xa17: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a1a:
	/* 0xa1a: ja     a23 <perf_unwind_native+0xa23> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa1a, 0xa23, x86_l_a23);
x86_l_a1c:
	/* 0xa1c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_a1e:
	/* 0xa1e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a21:
	/* 0xa21: jmp    a25 <perf_unwind_native+0xa25> */
	X86_SIM_X86_JMP(0xa21, 0xa25, x86_l_a25);
x86_l_a23:
	/* 0xa23: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a25:
	/* 0xa25: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a28:
	/* 0xa28: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa28, 0xb2a, x86_l_b2a);
x86_l_a2e:
	/* 0xa2e: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_a32:
	/* 0xa32: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_a34:
	/* 0xa34: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a38:
	/* 0xa38: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a3d:
	/* 0xa3d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a40:
	/* 0xa40: call   a45 <perf_unwind_native+0xa45> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a45:
	/* 0xa45: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a48:
	/* 0xa48: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa48, 0xbe2, x86_l_be2);
x86_l_a4e:
	/* 0xa4e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a52:
	/* 0xa52: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a57:
	/* 0xa57: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a5a:
	/* 0xa5a: ja     a63 <perf_unwind_native+0xa63> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa5a, 0xa63, x86_l_a63);
x86_l_a5c:
	/* 0xa5c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_a5e:
	/* 0xa5e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a61:
	/* 0xa61: jmp    a65 <perf_unwind_native+0xa65> */
	X86_SIM_X86_JMP(0xa61, 0xa65, x86_l_a65);
x86_l_a63:
	/* 0xa63: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a65:
	/* 0xa65: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a68:
	/* 0xa68: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa68, 0xb2a, x86_l_b2a);
x86_l_a6e:
	/* 0xa6e: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_a72:
	/* 0xa72: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_a74:
	/* 0xa74: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a78:
	/* 0xa78: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a7d:
	/* 0xa7d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a80:
	/* 0xa80: call   a85 <perf_unwind_native+0xa85> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a85:
	/* 0xa85: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a88:
	/* 0xa88: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa88, 0xbe2, x86_l_be2);
x86_l_a8e:
	/* 0xa8e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a92:
	/* 0xa92: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a97:
	/* 0xa97: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a9a:
	/* 0xa9a: ja     aa3 <perf_unwind_native+0xaa3> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa9a, 0xaa3, x86_l_aa3);
x86_l_a9c:
	/* 0xa9c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_a9e:
	/* 0xa9e: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_aa1:
	/* 0xaa1: jmp    aa5 <perf_unwind_native+0xaa5> */
	X86_SIM_X86_JMP(0xaa1, 0xaa5, x86_l_aa5);
x86_l_aa3:
	/* 0xaa3: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_aa5:
	/* 0xaa5: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_aa8:
	/* 0xaa8: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xaa8, 0xb2a, x86_l_b2a);
x86_l_aae:
	/* 0xaae: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_ab2:
	/* 0xab2: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_ab4:
	/* 0xab4: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ab8:
	/* 0xab8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_abd:
	/* 0xabd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ac0:
	/* 0xac0: call   ac5 <perf_unwind_native+0xac5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ac5:
	/* 0xac5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac8:
	/* 0xac8: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac8, 0xbe2, x86_l_be2);
x86_l_ace:
	/* 0xace: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ad2:
	/* 0xad2: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_ad7:
	/* 0xad7: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ada:
	/* 0xada: ja     ae3 <perf_unwind_native+0xae3> */
	X86_SIM_X86_JCC(X86_CC_A, 0xada, 0xae3, x86_l_ae3);
x86_l_adc:
	/* 0xadc: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_ade:
	/* 0xade: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_ae1:
	/* 0xae1: jmp    ae5 <perf_unwind_native+0xae5> */
	X86_SIM_X86_JMP(0xae1, 0xae5, x86_l_ae5);
x86_l_ae3:
	/* 0xae3: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_ae5:
	/* 0xae5: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_ae8:
	/* 0xae8: jae    b2a <perf_unwind_native+0xb2a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xae8, 0xb2a, x86_l_b2a);
x86_l_aea:
	/* 0xaea: lea    eax,[r12+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_aee:
	/* 0xaee: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_af0:
	/* 0xaf0: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_af4:
	/* 0xaf4: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_af9:
	/* 0xaf9: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_afc:
	/* 0xafc: call   b01 <perf_unwind_native+0xb01> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b01:
	/* 0xb01: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b04:
	/* 0xb04: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb04, 0xbe2, x86_l_be2);
x86_l_b0a:
	/* 0xb0a: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b0e:
	/* 0xb0e: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_b13:
	/* 0xb13: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b16:
	/* 0xb16: ja     b1f <perf_unwind_native+0xb1f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb16, 0xb1f, x86_l_b1f);
x86_l_b18:
	/* 0xb18: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_b1a:
	/* 0xb1a: mov    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b1d:
	/* 0xb1d: jmp    b21 <perf_unwind_native+0xb21> */
	X86_SIM_X86_JMP(0xb1d, 0xb21, x86_l_b21);
x86_l_b1f:
	/* 0xb1f: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b21:
	/* 0xb21: cmp    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b24:
	/* 0xb24: jb     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb24, 0xbe2, x86_l_be2);
x86_l_b2a:
	/* 0xb2a: mov    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b2d:
	/* 0xb2d: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b2f:
	/* 0xb2f: je     be2 <perf_unwind_native+0xbe2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2f, 0xbe2, x86_l_be2);
x86_l_b35:
	/* 0xb35: dec    r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_b38:
	/* 0xb38: mov    DWORD PTR [rsp+0x6c],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_b3d:
	/* 0xb3d: lea    rsi,[rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_b42:
	/* 0xb42: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b45:
	/* 0xb45: call   b4a <perf_unwind_native+0xb4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b4a:
	/* 0xb4a: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_b4f:
	/* 0xb4f: mov    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_b55:
	/* 0xb55: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b58:
	/* 0xb58: je     c70 <perf_unwind_native+0xc70> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb58, 0xc70, x86_l_c70);
x86_l_b5e:
	/* 0xb5e: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_b65:
	/* 0xb65: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b6a:
	/* 0xb6a: jne    1173 <perf_unwind_native+0x1173> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb6a, 0x1173, x86_l_1173);
x86_l_b70:
	/* 0xb70: movzx  ebp,WORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 96ULL);
x86_l_b75:
	/* 0xb75: movzx  ecx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_b78:
	/* 0xb78: sub    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_b7a:
	/* 0xb7a: mov    ecx,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_b7e:
	/* 0xb7e: cmp    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_b81:
	/* 0xb81: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b84:
	/* 0xb84: jae    b8c <perf_unwind_native+0xb8c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb84, 0xb8c, x86_l_b8c);
x86_l_b86:
	/* 0xb86: add    ebp,0x10000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 65536ULL);
x86_l_b8c:
	/* 0xb8c: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_b91:
	/* 0xb91: movzx  eax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_b95:
	/* 0xb95: mov    DWORD PTR [rsp+0x68],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_b99:
	/* 0xb99: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_b9e:
	/* 0xb9e: je     c77 <perf_unwind_native+0xc77> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9e, 0xc77, x86_l_c77);
x86_l_ba4:
	/* 0xba4: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_ba9:
	/* 0xba9: jne    ca3 <perf_unwind_native+0xca3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xba9, 0xca3, x86_l_ca3);
x86_l_baf:
	/* 0xbaf: mov    DWORD PTR [rsp+0x84],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683079ULL);
x86_l_bba:
	/* 0xbba: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_bc1:
	/* 0xbc1: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_bc9:
	/* 0xbc9: call   bce <perf_unwind_native+0xbce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bce:
	/* 0xbce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd1:
	/* 0xbd1: je     c91 <perf_unwind_native+0xc91> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd1, 0xc91, x86_l_c91);
x86_l_bd7:
	/* 0xbd7: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_bda:
	/* 0xbda: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bdd:
	/* 0xbdd: jmp    c9f <perf_unwind_native+0xc9f> */
	X86_SIM_X86_JMP(0xbdd, 0xc9f, x86_l_c9f);
x86_l_be2:
	/* 0xbe2: mov    ecx,0xfa3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4003ULL);
x86_l_be7:
	/* 0xbe7: mov    r15d,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_bed:
	/* 0xbed: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_bf4:
	/* 0xbf4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf7:
	/* 0xbf7: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_bfc:
	/* 0xbfc: je     c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbfc, 0xc82, x86_l_c82);
x86_l_c02:
	/* 0xc02: movabs rax,0x6174616420747075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7022344801646571637ULL);
x86_l_c0c:
	/* 0xc0c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c11:
	/* 0xc11: movabs rax,0x72726f43202e7370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8246776201762206576ULL);
x86_l_c1b:
	/* 0xc1b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c20:
	/* 0xc20: movabs rax,0x657473203631206e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310594677314494574ULL);
x86_l_c2a:
	/* 0xc2a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c2f:
	/* 0xc2f: movabs rax,0x6920686372616573 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7575169349567210867ULL);
x86_l_c39:
	/* 0xc39: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c3e:
	/* 0xc3e: movabs rax,0x622064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070761801744998726ULL);
x86_l_c48:
	/* 0xc48: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c4d:
	/* 0xc4d: mov    DWORD PTR [rsp+0x37],0xa3f61 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 236223872865ULL);
x86_l_c55:
	/* 0xc55: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c5a:
	/* 0xc5a: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_c5f:
	/* 0xc5f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c61:
	/* 0xc61: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c63:
	/* 0xc63: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c66:
	/* 0xc66: call   c6b <perf_unwind_native+0xc6b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_c6b:
	/* 0xc6b: jmp    5dac <perf_unwind_native+0x5dac> */
	X86_SIM_X86_JMP(0xc6b, 0x5dac, x86_l_5dac);
x86_l_c70:
	/* 0xc70: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_c75:
	/* 0xc75: jmp    c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JMP(0xc75, 0xc82, x86_l_c82);
x86_l_c77:
	/* 0xc77: mov    r15d,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_c7d:
	/* 0xc7d: mov    ecx,0xfa5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4005ULL);
x86_l_c82:
	/* 0xc82: mov    DWORD PTR [rbx+0xf28],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3880ULL);
x86_l_c89:
	/* 0xc89: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c8c:
	/* 0xc8c: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0xc8c, 0x5417, x86_l_5417);
x86_l_c91:
	/* 0xc91: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c96:
	/* 0xc96: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c99:
	/* 0xc99: jne    1264 <perf_unwind_native+0x1264> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc99, 0x1264, x86_l_1264);
x86_l_c9f:
	/* 0xc9f: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ca3:
	/* 0xca3: lea    rdx,[rcx+0xed0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_caa:
	/* 0xcaa: lea    rsi,[rcx+0xee0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_cb1:
	/* 0xcb1: lea    rdi,[rcx+0xed8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_cb8:
	/* 0xcb8: lea    r8,[rcx+0xee8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_cbf:
	/* 0xcbf: lea    r9,[rcx+0xef0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_cc6:
	/* 0xcc6: lea    r10,[rcx+0xef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_ccd:
	/* 0xccd: add    rcx,0xf08 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3848ULL);
x86_l_cd4:
	/* 0xcd4: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_cd7:
	/* 0xcd7: mov    QWORD PTR [rsp+0x60],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_cdc:
	/* 0xcdc: js     ded <perf_unwind_native+0xded> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcdc, 0xded, x86_l_ded);
x86_l_ce2:
	/* 0xce2: mov    QWORD PTR [rsp+0x148],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_cea:
	/* 0xcea: mov    QWORD PTR [rsp+0x140],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_cf2:
	/* 0xcf2: mov    QWORD PTR [rsp+0x130],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_cfa:
	/* 0xcfa: mov    QWORD PTR [rsp+0x88],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_d02:
	/* 0xd02: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d05:
	/* 0xd05: mov    QWORD PTR [rsp+0x128],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_d0d:
	/* 0xd0d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_d14:
	/* 0xd14: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d19:
	/* 0xd19: call   d1e <perf_unwind_native+0xd1e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d1e:
	/* 0xd1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d21:
	/* 0xd21: je     5f07 <perf_unwind_native+0x5f07> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd21, 0x5f07, x86_l_5f07);
x86_l_d27:
	/* 0xd27: mov    r13d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_d2b:
	/* 0xd2b: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_d2f:
	/* 0xd2f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d31:
	/* 0xd31: je     f27 <perf_unwind_native+0xf27> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd31, 0xf27, x86_l_f27);
x86_l_d37:
	/* 0xd37: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3c:
	/* 0xd3c: jne    11fa <perf_unwind_native+0x11fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd3c, 0x11fa, x86_l_11fa);
x86_l_d42:
	/* 0xd42: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d44:
	/* 0xd44: and    dl,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 127ULL);
x86_l_d47:
	/* 0xd47: movzx  edx,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_d4a:
	/* 0xd4a: cmp    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_d4c:
	/* 0xd4c: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_d54:
	/* 0xd54: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d59:
	/* 0xd59: jl     f34 <perf_unwind_native+0xf34> */
	X86_SIM_X86_JCC(X86_CC_L, 0xd59, 0xf34, x86_l_f34);
x86_l_d5f:
	/* 0xd5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d61:
	/* 0xd61: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d63:
	/* 0xd63: setns  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_d67:
	/* 0xd67: shl    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_d6a:
	/* 0xd6a: add    r13d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_d6d:
	/* 0xd6d: add    r13d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_d71:
	/* 0xd71: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d76:
	/* 0xd76: je     f34 <perf_unwind_native+0xf34> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd76, 0xf34, x86_l_f34);
x86_l_d7c:
	/* 0xd7c: movabs rcx,0xa64253d61746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 748764383608597605ULL);
x86_l_d86:
	/* 0xd86: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d8b:
	/* 0xd8b: movabs rcx,0x44616663203a6863 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4927332043248527459ULL);
x86_l_d95:
	/* 0xd95: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d9a:
	/* 0xd9a: movabs rcx,0x74616d2061746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8386103966981975141ULL);
x86_l_da4:
	/* 0xda4: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_da9:
	/* 0xda9: movabs rcx,0x642064656772654d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7214876989737559373ULL);
x86_l_db3:
	/* 0xdb3: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_db8:
	/* 0xdb8: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_dbd:
	/* 0xdbd: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_dc1:
	/* 0xdc1: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dc6:
	/* 0xdc6: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_dcb:
	/* 0xdcb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dcd:
	/* 0xdcd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd0:
	/* 0xdd0: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd3:
	/* 0xdd3: call   dd8 <perf_unwind_native+0xdd8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_dd8:
	/* 0xdd8: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_ddd:
	/* 0xddd: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_de0:
	/* 0xde0: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_de8:
	/* 0xde8: jmp    f34 <perf_unwind_native+0xf34> */
	X86_SIM_X86_JMP(0xde8, 0xf34, x86_l_f34);
x86_l_ded:
	/* 0xded: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_df2:
	/* 0xdf2: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_df8:
	/* 0xdf8: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_dfb:
	/* 0xdfb: jg     ea0 <perf_unwind_native+0xea0> */
	X86_SIM_X86_JCC(X86_CC_G, 0xdfb, 0xea0, x86_l_ea0);
x86_l_e01:
	/* 0xe01: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_e04:
	/* 0xe04: je     6052 <perf_unwind_native+0x6052> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe04, 0x6052, x86_l_6052);
x86_l_e0a:
	/* 0xe0a: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e0d:
	/* 0xe0d: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe0d, 0x5417, x86_l_5417);
x86_l_e13:
	/* 0xe13: mov    QWORD PTR [rsp+0x148],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_e1b:
	/* 0xe1b: mov    QWORD PTR [rsp+0x140],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_e23:
	/* 0xe23: mov    QWORD PTR [rsp+0x130],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_e2b:
	/* 0xe2b: mov    QWORD PTR [rsp+0x128],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_e33:
	/* 0xe33: mov    QWORD PTR [rsp+0x88],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_e3b:
	/* 0xe3b: mov    rax,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e3e:
	/* 0xe3e: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e41:
	/* 0xe41: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e43:
	/* 0xe43: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_e46:
	/* 0xe46: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e48:
	/* 0xe48: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_e4b:
	/* 0xe4b: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_e4e:
	/* 0xe4e: lea    r12,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_e52:
	/* 0xe52: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_e56:
	/* 0xe56: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_e5d:
	/* 0xe5d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e60:
	/* 0xe60: je     1506 <perf_unwind_native+0x1506> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe60, 0x1506, x86_l_1506);
x86_l_e66:
	/* 0xe66: movabs rax,0xa786c2578303d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155647541309ULL);
x86_l_e70:
	/* 0xe70: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e75:
	/* 0xe75: movabs rax,0x616663202c544c50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018406059137322064ULL);
x86_l_e7f:
	/* 0xe7f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e84:
	/* 0xe84: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e89:
	/* 0xe89: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_e8e:
	/* 0xe8e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e91:
	/* 0xe91: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e93:
	/* 0xe93: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e96:
	/* 0xe96: call   e9b <perf_unwind_native+0xe9b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_e9b:
	/* 0xe9b: jmp    1506 <perf_unwind_native+0x1506> */
	X86_SIM_X86_JMP(0xe9b, 0x1506, x86_l_1506);
x86_l_ea0:
	/* 0xea0: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_ea3:
	/* 0xea3: je     1037 <perf_unwind_native+0x1037> */
	X86_SIM_X86_JCC(X86_CC_E, 0xea3, 0x1037, x86_l_1037);
x86_l_ea9:
	/* 0xea9: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_eac:
	/* 0xeac: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xeac, 0x5417, x86_l_5417);
x86_l_eb2:
	/* 0xeb2: mov    QWORD PTR [rsp+0x148],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_eba:
	/* 0xeba: mov    QWORD PTR [rsp+0x140],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_ec2:
	/* 0xec2: mov    QWORD PTR [rsp+0x130],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_eca:
	/* 0xeca: mov    QWORD PTR [rsp+0x88],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_ed2:
	/* 0xed2: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ed5:
	/* 0xed5: mov    QWORD PTR [rsp+0x128],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_edd:
	/* 0xedd: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee0:
	/* 0xee0: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ee5:
	/* 0xee5: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_eea:
	/* 0xeea: call   eef <perf_unwind_native+0xeef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_eef:
	/* 0xeef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ef2:
	/* 0xef2: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xef2, 0x1522, x86_l_1522);
x86_l_ef8:
	/* 0xef8: mov    rax,QWORD PTR [rbx+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_eff:
	/* 0xeff: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_f03:
	/* 0xf03: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_f0a:
	/* 0xf0a: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f0f:
	/* 0xf0f: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_f16:
	/* 0xf16: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f1b:
	/* 0xf1b: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_f22:
	/* 0xf22: jmp    1570 <perf_unwind_native+0x1570> */
	X86_SIM_X86_JMP(0xf22, 0x1570, x86_l_1570);
x86_l_f27:
	/* 0xf27: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_f2f:
	/* 0xf2f: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_f34:
	/* 0xf34: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_f37:
	/* 0xf37: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_f3a:
	/* 0xf3a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_f3c:
	/* 0xf3c: jns    f44 <perf_unwind_native+0xf44> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf3c, 0xf44, x86_l_f44);
x86_l_f3e:
	/* 0xf3e: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_f41:
	/* 0xf41: and    esi,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_f44:
	/* 0xf44: mov    r9d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_f47:
	/* 0xf47: and    r9d,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_f4b:
	/* 0xf4b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f4e:
	/* 0xf4e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f52:
	/* 0xf52: jg     f71 <perf_unwind_native+0xf71> */
	X86_SIM_X86_JCC(X86_CC_G, 0xf52, 0xf71, x86_l_f71);
x86_l_f54:
	/* 0xf54: cmp    r9d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f58:
	/* 0xf58: je     fe0 <perf_unwind_native+0xfe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf58, 0xfe0, x86_l_fe0);
x86_l_f5e:
	/* 0xf5e: mov    r8,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_f66:
	/* 0xf66: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f6a:
	/* 0xf6a: je     fdd <perf_unwind_native+0xfdd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf6a, 0xfdd, x86_l_fdd);
x86_l_f6c:
	/* 0xf6c: jmp    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JMP(0xf6c, 0x1359, x86_l_1359);
x86_l_f71:
	/* 0xf71: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f74:
	/* 0xf74: cmp    r9d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_f78:
	/* 0xf78: je     fdd <perf_unwind_native+0xfdd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf78, 0xfdd, x86_l_fdd);
x86_l_f7a:
	/* 0xf7a: cmp    r9d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_f7e:
	/* 0xf7e: jne    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf7e, 0x1359, x86_l_1359);
x86_l_f84:
	/* 0xf84: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_f87:
	/* 0xf87: sar    ecx,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_f89:
	/* 0xf89: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_f8c:
	/* 0xf8c: movsxd rcx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_f8f:
	/* 0xf8f: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_f94:
	/* 0xf94: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_f9b:
	/* 0xf9b: cmp    DWORD PTR [rsi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f9e:
	/* 0xf9e: jne    12de <perf_unwind_native+0x12de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf9e, 0x12de, x86_l_12de);
x86_l_fa4:
	/* 0xfa4: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_fa8:
	/* 0xfa8: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fab:
	/* 0xfab: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_faf:
	/* 0xfaf: jg     133a <perf_unwind_native+0x133a> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfaf, 0x133a, x86_l_133a);
x86_l_fb5:
	/* 0xfb5: mov    rcx,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_fbd:
	/* 0xfbd: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_fc0:
	/* 0xfc0: je     1351 <perf_unwind_native+0x1351> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc0, 0x1351, x86_l_1351);
x86_l_fc6:
	/* 0xfc6: mov    rcx,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_fce:
	/* 0xfce: cmp    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_fd2:
	/* 0xfd2: je     1351 <perf_unwind_native+0x1351> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfd2, 0x1351, x86_l_1351);
x86_l_fd8:
	/* 0xfd8: jmp    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JMP(0xfd8, 0x1359, x86_l_1359);
x86_l_fdd:
	/* 0xfdd: mov    r12,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fe0:
	/* 0xfe0: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_fe3:
	/* 0xfe3: movsxd r12,esi */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_fe6:
	/* 0xfe6: add    r12,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fe9:
	/* 0xfe9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_feb:
	/* 0xfeb: jns    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfeb, 0x1359, x86_l_1359);
x86_l_ff1:
	/* 0xff1: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ff4:
	/* 0xff4: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_ff9:
	/* 0xff9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_ffe:
	/* 0xffe: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1001:
	/* 0x1001: call   1006 <perf_unwind_native+0x1006> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1006:
	/* 0x1006: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1009:
	/* 0x1009: je     114e <perf_unwind_native+0x114e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1009, 0x114e, x86_l_114e);
x86_l_100f:
	/* 0x100f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1016:
	/* 0x1016: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1019:
	/* 0x1019: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_1021:
	/* 0x1021: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1026:
	/* 0x1026: jne    19ad <perf_unwind_native+0x19ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1026, 0x19ad, x86_l_19ad);
x86_l_102c:
	/* 0x102c: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_102f:
	/* 0x102f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1032:
	/* 0x1032: jmp    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JMP(0x1032, 0x1359, x86_l_1359);
x86_l_1037:
	/* 0x1037: mov    QWORD PTR [rsp+0x148],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_103f:
	/* 0x103f: mov    QWORD PTR [rsp+0x140],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_1047:
	/* 0x1047: mov    QWORD PTR [rsp+0x130],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_104f:
	/* 0x104f: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1052:
	/* 0x1052: mov    QWORD PTR [rsp+0x128],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_105a:
	/* 0x105a: mov    QWORD PTR [rsp+0x88],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1062:
	/* 0x1062: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1065:
	/* 0x1065: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1069:
	/* 0x1069: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1071:
	/* 0x1071: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1076:
	/* 0x1076: call   107b <perf_unwind_native+0x107b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_107b:
	/* 0x107b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_107e:
	/* 0x107e: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x107e, 0x1522, x86_l_1522);
x86_l_1084:
	/* 0x1084: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_108c:
	/* 0x108c: mov    QWORD PTR [rbx+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_1093:
	/* 0x1093: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_109b:
	/* 0x109b: mov    QWORD PTR [rbx+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_10a2:
	/* 0x10a2: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_10aa:
	/* 0x10aa: mov    QWORD PTR [rbx+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_10b1:
	/* 0x10b1: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_10b9:
	/* 0x10b9: mov    QWORD PTR [rbx+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_10c0:
	/* 0x10c0: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_10c8:
	/* 0x10c8: mov    QWORD PTR [rbx+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_10cf:
	/* 0x10cf: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_10d7:
	/* 0x10d7: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_10de:
	/* 0x10de: mov    rax,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_10e6:
	/* 0x10e6: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_10ed:
	/* 0x10ed: mov    rax,QWORD PTR [rsp+0x110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_10f5:
	/* 0x10f5: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_10fc:
	/* 0x10fc: mov    BYTE PTR [rbx+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_1103:
	/* 0x1103: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_110a:
	/* 0x110a: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_110f:
	/* 0x110f: je     157e <perf_unwind_native+0x157e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x110f, 0x157e, x86_l_157e);
x86_l_1115:
	/* 0x1115: movabs rax,0xa656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926270227834400ULL);
x86_l_111f:
	/* 0x111f: mov    QWORD PTR [rsp+0x16],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_1124:
	/* 0x1124: movabs rax,0x66206c616e676973 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359000956843288947ULL);
x86_l_112e:
	/* 0x112e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1133:
	/* 0x1133: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1138:
	/* 0x1138: mov    esi,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_113d:
	/* 0x113d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_113f:
	/* 0x113f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1141:
	/* 0x1141: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1144:
	/* 0x1144: call   1149 <perf_unwind_native+0x1149> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1149:
	/* 0x1149: jmp    157e <perf_unwind_native+0x157e> */
	X86_SIM_X86_JMP(0x1149, 0x157e, x86_l_157e);
x86_l_114e:
	/* 0x114e: shl    r13d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1152:
	/* 0x1152: and    r13d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_1156:
	/* 0x1156: add    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_115b:
	/* 0x115b: mov    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_115e:
	/* 0x115e: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_1166:
	/* 0x1166: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1169:
	/* 0x1169: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_116e:
	/* 0x116e: jmp    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JMP(0x116e, 0x1359, x86_l_1359);
x86_l_1173:
	/* 0x1173: movabs rcx,0xa6425206f666e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387845742ULL);
x86_l_117d:
	/* 0x117d: mov    QWORD PTR [rsp+0x35],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_1182:
	/* 0x1182: movabs rcx,0x6f666e49646e6977 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8027224647331113335ULL);
x86_l_118c:
	/* 0x118c: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1191:
	/* 0x1191: movabs rcx,0x6e75202c78257830 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7959303291813591088ULL);
x86_l_119b:
	/* 0x119b: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11a0:
	/* 0x11a0: movabs rcx,0x20776f4c72646461 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2339460905569641569ULL);
x86_l_11aa:
	/* 0x11aa: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11af:
	/* 0x11af: movabs rcx,0x202c642520786564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2318338018810291556ULL);
x86_l_11b9:
	/* 0x11b9: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11be:
	/* 0x11be: movabs rcx,0x6e692061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7955925819663869284ULL);
x86_l_11c8:
	/* 0x11c8: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11cd:
	/* 0x11cd: mov    edx,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_11d1:
	/* 0x11d1: movzx  ecx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_11d4:
	/* 0x11d4: movzx  r8d,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_11d9:
	/* 0x11d9: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11de:
	/* 0x11de: mov    esi,0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 45ULL);
x86_l_11e3:
	/* 0x11e3: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e6:
	/* 0x11e6: call   11eb <perf_unwind_native+0x11eb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_11eb:
	/* 0x11eb: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11ee:
	/* 0x11ee: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_11f5:
	/* 0x11f5: jmp    b70 <perf_unwind_native+0xb70> */
	X86_SIM_X86_JMP(0x11f5, 0xb70, x86_l_b70);
x86_l_11fa:
	/* 0x11fa: movabs rcx,0xa78323023252061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 754408119914012769ULL);
x86_l_1204:
	/* 0x1204: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1209:
	/* 0x1209: movabs rcx,0x746c656420646567 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8389191686598976871ULL);
x86_l_1213:
	/* 0x1213: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1218:
	/* 0x1218: movabs rcx,0x72656d202c642520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8243114677922702624ULL);
x86_l_1222:
	/* 0x1222: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1227:
	/* 0x1227: movabs rcx,0x6666694472646441 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7378700782191010881ULL);
x86_l_1231:
	/* 0x1231: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1236:
	/* 0x1236: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_123b:
	/* 0x123b: movsxd rdx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RBP, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_123e:
	/* 0x123e: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1242:
	/* 0x1242: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1247:
	/* 0x1247: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_124c:
	/* 0x124c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_124f:
	/* 0x124f: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1252:
	/* 0x1252: call   1257 <perf_unwind_native+0x1257> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1257:
	/* 0x1257: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_125a:
	/* 0x125a: movzx  ecx,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_125f:
	/* 0x125f: jmp    d42 <perf_unwind_native+0xd42> */
	X86_SIM_X86_JMP(0x125f, 0xd42, x86_l_d42);
x86_l_1264:
	/* 0x1264: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_126e:
	/* 0x126e: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1273:
	/* 0x1273: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_127d:
	/* 0x127d: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1282:
	/* 0x1282: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_128c:
	/* 0x128c: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1291:
	/* 0x1291: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_129b:
	/* 0x129b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12a0:
	/* 0x12a0: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_12aa:
	/* 0x12aa: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12af:
	/* 0x12af: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_12b9:
	/* 0x12b9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12be:
	/* 0x12be: mov    edx,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_12c5:
	/* 0x12c5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12ca:
	/* 0x12ca: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_12cf:
	/* 0x12cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12d1:
	/* 0x12d1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12d4:
	/* 0x12d4: call   12d9 <perf_unwind_native+0x12d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_12d9:
	/* 0x12d9: jmp    bda <perf_unwind_native+0xbda> */
	X86_SIM_X86_JMP(0x12d9, 0xbda, x86_l_bda);
x86_l_12de:
	/* 0x12de: movabs rdx,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_12e8:
	/* 0x12e8: mov    QWORD PTR [rsp+0x18],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12ed:
	/* 0x12ed: movabs rdx,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_12f7:
	/* 0x12f7: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12fc:
	/* 0x12fc: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1301:
	/* 0x1301: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1305:
	/* 0x1305: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_130a:
	/* 0x130a: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_130f:
	/* 0x130f: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1312:
	/* 0x1312: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1315:
	/* 0x1315: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1318:
	/* 0x1318: call   131d <perf_unwind_native+0x131d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_131d:
	/* 0x131d: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1322:
	/* 0x1322: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1325:
	/* 0x1325: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_132d:
	/* 0x132d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1330:
	/* 0x1330: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1334:
	/* 0x1334: jle    fb5 <perf_unwind_native+0xfb5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1334, 0xfb5, x86_l_fb5);
x86_l_133a:
	/* 0x133a: mov    rcx,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_1342:
	/* 0x1342: cmp    r13d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1346:
	/* 0x1346: je     1351 <perf_unwind_native+0x1351> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1346, 0x1351, x86_l_1351);
x86_l_1348:
	/* 0x1348: cmp    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_134c:
	/* 0x134c: jne    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x134c, 0x1359, x86_l_1359);
x86_l_134e:
	/* 0x134e: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1351:
	/* 0x1351: mov    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1356:
	/* 0x1356: add    r12,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1359:
	/* 0x1359: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_135d:
	/* 0x135d: mov    r13d,DWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1361:
	/* 0x1361: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1364:
	/* 0x1364: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1366:
	/* 0x1366: jns    136e <perf_unwind_native+0x136e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1366, 0x136e, x86_l_136e);
x86_l_1368:
	/* 0x1368: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_136b:
	/* 0x136b: and    esi,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_136e:
	/* 0x136e: mov    r9d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1371:
	/* 0x1371: and    r9d,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1375:
	/* 0x1375: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1379:
	/* 0x1379: jg     139b <perf_unwind_native+0x139b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1379, 0x139b, x86_l_139b);
x86_l_137b:
	/* 0x137b: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_137e:
	/* 0x137e: cmp    r9d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1382:
	/* 0x1382: je     1404 <perf_unwind_native+0x1404> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1382, 0x1404, x86_l_1404);
x86_l_1388:
	/* 0x1388: mov    r8,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1390:
	/* 0x1390: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1394:
	/* 0x1394: je     1401 <perf_unwind_native+0x1401> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1394, 0x1401, x86_l_1401);
x86_l_1396:
	/* 0x1396: jmp    1444 <perf_unwind_native+0x1444> */
	X86_SIM_X86_JMP(0x1396, 0x1444, x86_l_1444);
x86_l_139b:
	/* 0x139b: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_139e:
	/* 0x139e: cmp    r9d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_13a2:
	/* 0x13a2: je     1401 <perf_unwind_native+0x1401> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13a2, 0x1401, x86_l_1401);
x86_l_13a4:
	/* 0x13a4: cmp    r9d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_13a8:
	/* 0x13a8: jne    1444 <perf_unwind_native+0x1444> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13a8, 0x1444, x86_l_1444);
x86_l_13ae:
	/* 0x13ae: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_13b1:
	/* 0x13b1: sar    ecx,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_13b3:
	/* 0x13b3: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_13b6:
	/* 0x13b6: movsxd rcx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_13b9:
	/* 0x13b9: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_13be:
	/* 0x13be: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_13c5:
	/* 0x13c5: cmp    DWORD PTR [rsi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13c8:
	/* 0x13c8: jne    1468 <perf_unwind_native+0x1468> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13c8, 0x1468, x86_l_1468);
x86_l_13ce:
	/* 0x13ce: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_13d2:
	/* 0x13d2: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_13d6:
	/* 0x13d6: jg     14c1 <perf_unwind_native+0x14c1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x13d6, 0x14c1, x86_l_14c1);
x86_l_13dc:
	/* 0x13dc: mov    rcx,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_13e4:
	/* 0x13e4: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_13e7:
	/* 0x13e7: je     14dc <perf_unwind_native+0x14dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13e7, 0x14dc, x86_l_14dc);
x86_l_13ed:
	/* 0x13ed: mov    rcx,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_13f5:
	/* 0x13f5: cmp    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_13f9:
	/* 0x13f9: je     14dc <perf_unwind_native+0x14dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13f9, 0x14dc, x86_l_14dc);
x86_l_13ff:
	/* 0x13ff: jmp    1444 <perf_unwind_native+0x1444> */
	X86_SIM_X86_JMP(0x13ff, 0x1444, x86_l_1444);
x86_l_1401:
	/* 0x1401: mov    r8,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1404:
	/* 0x1404: movsxd rdx,esi */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_1407:
	/* 0x1407: add    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_140a:
	/* 0x140a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_140c:
	/* 0x140c: jns    14e4 <perf_unwind_native+0x14e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x140c, 0x14e4, x86_l_14e4);
x86_l_1412:
	/* 0x1412: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1415:
	/* 0x1415: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_141a:
	/* 0x141a: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_141f:
	/* 0x141f: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1422:
	/* 0x1422: call   1427 <perf_unwind_native+0x1427> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1427:
	/* 0x1427: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_142a:
	/* 0x142a: je     144e <perf_unwind_native+0x144e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x142a, 0x144e, x86_l_144e);
x86_l_142c:
	/* 0x142c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1433:
	/* 0x1433: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1436:
	/* 0x1436: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1439:
	/* 0x1439: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_143e:
	/* 0x143e: jne    1a2f <perf_unwind_native+0x1a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x143e, 0x1a2f, x86_l_1a2f);
x86_l_1444:
	/* 0x1444: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1449:
	/* 0x1449: jmp    14fa <perf_unwind_native+0x14fa> */
	X86_SIM_X86_JMP(0x1449, 0x14fa, x86_l_14fa);
x86_l_144e:
	/* 0x144e: lea    edx,[r13*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 0ULL);
x86_l_1456:
	/* 0x1456: and    edx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_1459:
	/* 0x1459: add    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_145e:
	/* 0x145e: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1461:
	/* 0x1461: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1466:
	/* 0x1466: jmp    14e4 <perf_unwind_native+0x14e4> */
	X86_SIM_X86_JMP(0x1466, 0x14e4, x86_l_14e4);
x86_l_1468:
	/* 0x1468: movabs rdx,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_1472:
	/* 0x1472: mov    QWORD PTR [rsp+0x18],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1477:
	/* 0x1477: movabs rdx,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_1481:
	/* 0x1481: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1486:
	/* 0x1486: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_148b:
	/* 0x148b: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_148f:
	/* 0x148f: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1494:
	/* 0x1494: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1499:
	/* 0x1499: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_149c:
	/* 0x149c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_149f:
	/* 0x149f: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a2:
	/* 0x14a2: call   14a7 <perf_unwind_native+0x14a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_14a7:
	/* 0x14a7: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_14ac:
	/* 0x14ac: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_14af:
	/* 0x14af: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_14b7:
	/* 0x14b7: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_14bb:
	/* 0x14bb: jle    13dc <perf_unwind_native+0x13dc> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x14bb, 0x13dc, x86_l_13dc);
x86_l_14c1:
	/* 0x14c1: mov    rcx,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_14c9:
	/* 0x14c9: cmp    r13d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_14cd:
	/* 0x14cd: je     14dc <perf_unwind_native+0x14dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14cd, 0x14dc, x86_l_14dc);
x86_l_14cf:
	/* 0x14cf: cmp    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_14d3:
	/* 0x14d3: jne    1444 <perf_unwind_native+0x1444> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14d3, 0x1444, x86_l_1444);
x86_l_14d9:
	/* 0x14d9: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14dc:
	/* 0x14dc: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_14e1:
	/* 0x14e1: add    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_14e4:
	/* 0x14e4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14e7:
	/* 0x14e7: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_14ec:
	/* 0x14ec: je     14fa <perf_unwind_native+0x14fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14ec, 0x14fa, x86_l_14fa);
x86_l_14ee:
	/* 0x14ee: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_14f3:
	/* 0x14f3: call   14f8 <perf_unwind_native+0x14f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14f8:
	/* 0x14f8: jmp    1506 <perf_unwind_native+0x1506> */
	X86_SIM_X86_JMP(0x14f8, 0x1506, x86_l_1506);
x86_l_14fa:
	/* 0x14fa: cmp    BYTE PTR [rax],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_14fd:
	/* 0x14fd: jne    1506 <perf_unwind_native+0x1506> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14fd, 0x1506, x86_l_1506);
x86_l_14ff:
	/* 0x14ff: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1506:
	/* 0x1506: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1509:
	/* 0x1509: je     1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1509, 0x1522, x86_l_1522);
x86_l_150b:
	/* 0x150b: lea    rdx,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1510:
	/* 0x1510: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1513:
	/* 0x1513: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1518:
	/* 0x1518: call   151d <perf_unwind_native+0x151d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_151d:
	/* 0x151d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1520:
	/* 0x1520: je     1569 <perf_unwind_native+0x1569> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1520, 0x1569, x86_l_1569);
x86_l_1522:
	/* 0x1522: mov    DWORD PTR [rsp+0x70],0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337166ULL);
x86_l_152a:
	/* 0x152a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1531:
	/* 0x1531: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1536:
	/* 0x1536: call   153b <perf_unwind_native+0x153b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_153b:
	/* 0x153b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153e:
	/* 0x153e: je     154e <perf_unwind_native+0x154e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x153e, 0x154e, x86_l_154e);
x86_l_1540:
	/* 0x1540: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1543:
	/* 0x1543: mov    r13d,0xfa7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4007ULL);
x86_l_1549:
	/* 0x1549: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0x1549, 0x5417, x86_l_5417);
x86_l_154e:
	/* 0x154e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1555:
	/* 0x1555: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1558:
	/* 0x1558: jne    1676 <perf_unwind_native+0x1676> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1558, 0x1676, x86_l_1676);
x86_l_155e:
	/* 0x155e: mov    r13d,0xfa7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4007ULL);
x86_l_1564:
	/* 0x1564: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0x1564, 0x5417, x86_l_5417);
x86_l_1569:
	/* 0x1569: mov    QWORD PTR [rbx+0xed8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1570:
	/* 0x1570: mov    BYTE PTR [rbx+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_1577:
	/* 0x1577: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_157e:
	/* 0x157e: mov    DWORD PTR [rsp+0x70],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337158ULL);
x86_l_1586:
	/* 0x1586: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_158d:
	/* 0x158d: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1592:
	/* 0x1592: call   1597 <perf_unwind_native+0x1597> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1597:
	/* 0x1597: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_159a:
	/* 0x159a: je     1626 <perf_unwind_native+0x1626> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159a, 0x1626, x86_l_1626);
x86_l_15a0:
	/* 0x15a0: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_15a3:
	/* 0x15a3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a5:
	/* 0x15a5: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15aa:
	/* 0x15aa: je     1633 <perf_unwind_native+0x1633> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15aa, 0x1633, x86_l_1633);
x86_l_15b0:
	/* 0x15b0: movabs rax,0xa786c6c25203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280058ULL);
x86_l_15ba:
	/* 0x15ba: mov    QWORD PTR [rsp+0xa5],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_15c2:
	/* 0x15c2: movabs rax,0x25203a706620786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675202433082226796ULL);
x86_l_15cc:
	/* 0x15cc: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_15d4:
	/* 0x15d4: movabs rax,0x6c25203a70732078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165601296504ULL);
x86_l_15de:
	/* 0x15de: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_15e6:
	/* 0x15e6: movabs rax,0x6c6c25203a637020 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660273929744416ULL);
x86_l_15f0:
	/* 0x15f0: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_15f8:
	/* 0x15f8: mov    rdx,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15fb:
	/* 0x15fb: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1603:
	/* 0x1603: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1606:
	/* 0x1606: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_160b:
	/* 0x160b: mov    r8,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160e:
	/* 0x160e: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1616:
	/* 0x1616: mov    esi,0x1d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_161b:
	/* 0x161b: call   1620 <perf_unwind_native+0x1620> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1620:
	/* 0x1620: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1624:
	/* 0x1624: jmp    1633 <perf_unwind_native+0x1633> */
	X86_SIM_X86_JMP(0x1624, 0x1633, x86_l_1633);
x86_l_1626:
	/* 0x1626: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162b:
	/* 0x162b: jne    1929 <perf_unwind_native+0x1929> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x162b, 0x1929, x86_l_1929);
x86_l_1631:
	/* 0x1631: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1633:
	/* 0x1633: mov    r13,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1636:
	/* 0x1636: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1639:
	/* 0x1639: je     6970 <perf_unwind_native+0x6970> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1639, 0x6970, x86_l_6970);
x86_l_163f:
	/* 0x163f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1641:
	/* 0x1641: jne    16ed <perf_unwind_native+0x16ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1641, 0x16ed, x86_l_16ed);
x86_l_1647:
	/* 0x1647: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_164a:
	/* 0x164a: shr    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_164e:
	/* 0x164e: je     1792 <perf_unwind_native+0x1792> */
	X86_SIM_X86_JCC(X86_CC_E, 0x164e, 0x1792, x86_l_1792);
x86_l_1654:
	/* 0x1654: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1659:
	/* 0x1659: jne    304b <perf_unwind_native+0x304b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1659, 0x304b, x86_l_304b);
x86_l_165f:
	/* 0x165f: mov    DWORD PTR [rbx+0xf28],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108491ULL);
x86_l_1669:
	/* 0x1669: mov    ebp,0xfab */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4011ULL);
x86_l_166e:
	/* 0x166e: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1671:
	/* 0x1671: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x1671, 0x541d, x86_l_541d);
x86_l_1676:
	/* 0x1676: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_1680:
	/* 0x1680: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1685:
	/* 0x1685: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_168f:
	/* 0x168f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1694:
	/* 0x1694: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_169e:
	/* 0x169e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_16a3:
	/* 0x16a3: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_16ad:
	/* 0x16ad: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_16b2:
	/* 0x16b2: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_16bc:
	/* 0x16bc: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_16c1:
	/* 0x16c1: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_16cb:
	/* 0x16cb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16d0:
	/* 0x16d0: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_16d4:
	/* 0x16d4: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16d9:
	/* 0x16d9: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_16de:
	/* 0x16de: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16e0:
	/* 0x16e0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16e3:
	/* 0x16e3: call   16e8 <perf_unwind_native+0x16e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_16e8:
	/* 0x16e8: jmp    155e <perf_unwind_native+0x155e> */
	X86_SIM_X86_JMP(0x16e8, 0x155e, x86_l_155e);
x86_l_16ed:
	/* 0x16ed: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_16f7:
	/* 0x16f7: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_16ff:
	/* 0x16ff: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_1709:
	/* 0x1709: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1711:
	/* 0x1711: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_171b:
	/* 0x171b: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1723:
	/* 0x1723: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_172d:
	/* 0x172d: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1735:
	/* 0x1735: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_173f:
	/* 0x173f: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1747:
	/* 0x1747: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_1751:
	/* 0x1751: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1759:
	/* 0x1759: mov    BYTE PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_1761:
	/* 0x1761: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1767:
	/* 0x1767: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_176f:
	/* 0x176f: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_1774:
	/* 0x1774: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1776:
	/* 0x1776: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1779:
	/* 0x1779: call   177e <perf_unwind_native+0x177e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_177e:
	/* 0x177e: mov    r13,QWORD PTR [rbx+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1785:
	/* 0x1785: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1788:
	/* 0x1788: shr    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_178c:
	/* 0x178c: jne    1654 <perf_unwind_native+0x1654> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x178c, 0x1654, x86_l_1654);
x86_l_1792:
	/* 0x1792: cmp    r13,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1799:
	/* 0x1799: ja     17bd <perf_unwind_native+0x17bd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1799, 0x17bd, x86_l_17bd);
x86_l_179b:
	/* 0x179b: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a0:
	/* 0x17a0: jne    318b <perf_unwind_native+0x318b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17a0, 0x318b, x86_l_318b);
x86_l_17a6:
	/* 0x17a6: mov    DWORD PTR [rbx+0xf28],0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108529ULL);
x86_l_17b0:
	/* 0x17b0: mov    ebp,0xfae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4014ULL);
x86_l_17b5:
	/* 0x17b5: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17b8:
	/* 0x17b8: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x17b8, 0x541d, x86_l_541d);
x86_l_17bd:
	/* 0x17bd: mov    QWORD PTR [rsp+0x138],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_17c5:
	/* 0x17c5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c7:
	/* 0x17c7: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_17cf:
	/* 0x17cf: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_17d5:
	/* 0x17d5: movbe  QWORD PTR [rsp+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_17dc:
	/* 0x17dc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_17e3:
	/* 0x17e3: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17e8:
	/* 0x17e8: call   17ed <perf_unwind_native+0x17ed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17ed:
	/* 0x17ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f0:
	/* 0x17f0: je     6a29 <perf_unwind_native+0x6a29> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17f0, 0x6a29, x86_l_6a29);
x86_l_17f6:
	/* 0x17f6: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_1800:
	/* 0x1800: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1803:
	/* 0x1803: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1807:
	/* 0x1807: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_180a:
	/* 0x180a: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_180d:
	/* 0x180d: mov    QWORD PTR [rbx+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1814:
	/* 0x1814: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1817:
	/* 0x1817: mov    QWORD PTR [rbx+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_181e:
	/* 0x181e: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_1822:
	/* 0x1822: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1825:
	/* 0x1825: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1828:
	/* 0x1828: mov    QWORD PTR [rbx+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_182f:
	/* 0x182f: cmp    DWORD PTR [rsi],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1832:
	/* 0x1832: jne    1aa6 <perf_unwind_native+0x1aa6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1832, 0x1aa6, x86_l_1aa6);
x86_l_1838:
	/* 0x1838: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_183c:
	/* 0x183c: jne    1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x183c, 0x1c7d, x86_l_1c7d);
x86_l_1842:
	/* 0x1842: mov    rax,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1849:
	/* 0x1849: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_184e:
	/* 0x184e: mov    r14,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1855:
	/* 0x1855: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_185c:
	/* 0x185c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1861:
	/* 0x1861: call   1866 <perf_unwind_native+0x1866> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1866:
	/* 0x1866: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_186c:
	/* 0x186c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_186f:
	/* 0x186f: je     1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x186f, 0x1c7d, x86_l_1c7d);
x86_l_1875:
	/* 0x1875: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1878:
	/* 0x1878: cmp    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_187b:
	/* 0x187b: ja     1883 <perf_unwind_native+0x1883> */
	X86_SIM_X86_JCC(X86_CC_A, 0x187b, 0x1883, x86_l_1883);
x86_l_187d:
	/* 0x187d: cmp    QWORD PTR [r13+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1881:
	/* 0x1881: jae    1897 <perf_unwind_native+0x1897> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1881, 0x1897, x86_l_1897);
x86_l_1883:
	/* 0x1883: cmp    QWORD PTR [r13+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1887:
	/* 0x1887: ja     1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1887, 0x1c7d, x86_l_1c7d);
x86_l_188d:
	/* 0x188d: cmp    QWORD PTR [r13+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1891:
	/* 0x1891: jb     1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1891, 0x1c7d, x86_l_1c7d);
x86_l_1897:
	/* 0x1897: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_189e:
	/* 0x189e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18a1:
	/* 0x18a1: jne    1bce <perf_unwind_native+0x1bce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18a1, 0x1bce, x86_l_1bce);
x86_l_18a7:
	/* 0x18a7: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_18ad:
	/* 0x18ad: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18b1:
	/* 0x18b1: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_18b4:
	/* 0x18b4: jae    1c45 <perf_unwind_native+0x1c45> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x18b4, 0x1c45, x86_l_1c45);
x86_l_18ba:
	/* 0x18ba: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_18c1:
	/* 0x18c1: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18c4:
	/* 0x18c4: je     1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18c4, 0x1c7d, x86_l_1c7d);
x86_l_18ca:
	/* 0x18ca: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_18d4:
	/* 0x18d4: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_18dc:
	/* 0x18dc: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_18e6:
	/* 0x18e6: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_18ee:
	/* 0x18ee: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_18f8:
	/* 0x18f8: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1900:
	/* 0x1900: mov    DWORD PTR [rsp+0xa7],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 717260219758ULL);
x86_l_190b:
	/* 0x190b: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1913:
	/* 0x1913: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_1918:
	/* 0x1918: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_191a:
	/* 0x191a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_191c:
	/* 0x191c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_191f:
	/* 0x191f: call   1924 <perf_unwind_native+0x1924> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1924:
	/* 0x1924: jmp    1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_X86_JMP(0x1924, 0x1c7d, x86_l_1c7d);
x86_l_1929:
	/* 0x1929: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_1933:
	/* 0x1933: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_1938:
	/* 0x1938: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_1942:
	/* 0x1942: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1947:
	/* 0x1947: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_1951:
	/* 0x1951: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1956:
	/* 0x1956: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_1960:
	/* 0x1960: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1965:
	/* 0x1965: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_196f:
	/* 0x196f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1974:
	/* 0x1974: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_197e:
	/* 0x197e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1983:
	/* 0x1983: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1987:
	/* 0x1987: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_198c:
	/* 0x198c: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_1991:
	/* 0x1991: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1993:
	/* 0x1993: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1996:
	/* 0x1996: call   199b <perf_unwind_native+0x199b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_199b:
	/* 0x199b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_199d:
	/* 0x199d: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19a2:
	/* 0x19a2: je     1633 <perf_unwind_native+0x1633> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a2, 0x1633, x86_l_1633);
x86_l_19a8:
	/* 0x19a8: jmp    15b0 <perf_unwind_native+0x15b0> */
	X86_SIM_X86_JMP(0x19a8, 0x15b0, x86_l_15b0);
x86_l_19ad:
	/* 0x19ad: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_19b7:
	/* 0x19b7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_19bc:
	/* 0x19bc: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_19c6:
	/* 0x19c6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19cb:
	/* 0x19cb: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_19d5:
	/* 0x19d5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19da:
	/* 0x19da: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_19e4:
	/* 0x19e4: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19e9:
	/* 0x19e9: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_19f3:
	/* 0x19f3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19f8:
	/* 0x19f8: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_1a00:
	/* 0x1a00: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a05:
	/* 0x1a05: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_1a0a:
	/* 0x1a0a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1a0d:
	/* 0x1a0d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a0f:
	/* 0x1a0f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a12:
	/* 0x1a12: call   1a17 <perf_unwind_native+0x1a17> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1a17:
	/* 0x1a17: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a1c:
	/* 0x1a1c: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1a1f:
	/* 0x1a1f: mov    rdx,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_1a27:
	/* 0x1a27: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a2a:
	/* 0x1a2a: jmp    1359 <perf_unwind_native+0x1359> */
	X86_SIM_X86_JMP(0x1a2a, 0x1359, x86_l_1359);
x86_l_1a2f:
	/* 0x1a2f: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_1a39:
	/* 0x1a39: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a3e:
	/* 0x1a3e: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_1a48:
	/* 0x1a48: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a4d:
	/* 0x1a4d: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_1a57:
	/* 0x1a57: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a5c:
	/* 0x1a5c: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_1a66:
	/* 0x1a66: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a6b:
	/* 0x1a6b: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_1a75:
	/* 0x1a75: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a7a:
	/* 0x1a7a: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_1a82:
	/* 0x1a82: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a87:
	/* 0x1a87: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_1a8c:
	/* 0x1a8c: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a8f:
	/* 0x1a8f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a91:
	/* 0x1a91: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a94:
	/* 0x1a94: call   1a99 <perf_unwind_native+0x1a99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1a99:
	/* 0x1a99: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a9e:
	/* 0x1a9e: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1aa1:
	/* 0x1aa1: jmp    1444 <perf_unwind_native+0x1444> */
	X86_SIM_X86_JMP(0x1aa1, 0x1444, x86_l_1444);
x86_l_1aa6:
	/* 0x1aa6: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_1ab0:
	/* 0x1ab0: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1ab8:
	/* 0x1ab8: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_1ac2:
	/* 0x1ac2: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1aca:
	/* 0x1aca: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_1ad4:
	/* 0x1ad4: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1adc:
	/* 0x1adc: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_1ae6:
	/* 0x1ae6: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1aee:
	/* 0x1aee: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_1af8:
	/* 0x1af8: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1b00:
	/* 0x1b00: movabs r14,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_1b0a:
	/* 0x1b0a: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1b12:
	/* 0x1b12: mov    WORD PTR [rsp+0xc0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 824633720842ULL);
x86_l_1b1c:
	/* 0x1b1c: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1b24:
	/* 0x1b24: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_1b29:
	/* 0x1b29: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1b2c:
	/* 0x1b2c: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1b2f:
	/* 0x1b2f: call   1b34 <perf_unwind_native+0x1b34> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1b34:
	/* 0x1b34: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1b3b:
	/* 0x1b3b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b3e:
	/* 0x1b3e: je     1838 <perf_unwind_native+0x1838> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b3e, 0x1838, x86_l_1838);
x86_l_1b44:
	/* 0x1b44: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_1b4e:
	/* 0x1b4e: mov    QWORD PTR [rsp+0xb7],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 183ULL);
x86_l_1b56:
	/* 0x1b56: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_1b60:
	/* 0x1b60: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1b68:
	/* 0x1b68: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_1b72:
	/* 0x1b72: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1b7a:
	/* 0x1b7a: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_1b84:
	/* 0x1b84: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1b8c:
	/* 0x1b8c: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_1b96:
	/* 0x1b96: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1b9e:
	/* 0x1b9e: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1ba6:
	/* 0x1ba6: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1bad:
	/* 0x1bad: mov    rdx,QWORD PTR [rbx+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1bb4:
	/* 0x1bb4: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1bbc:
	/* 0x1bbc: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_1bc1:
	/* 0x1bc1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc4:
	/* 0x1bc4: call   1bc9 <perf_unwind_native+0x1bc9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1bc9:
	/* 0x1bc9: jmp    1838 <perf_unwind_native+0x1838> */
	X86_SIM_X86_JMP(0x1bc9, 0x1838, x86_l_1838);
x86_l_1bce:
	/* 0x1bce: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_1bd8:
	/* 0x1bd8: mov    QWORD PTR [rsp+0xa6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_1be0:
	/* 0x1be0: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_1bea:
	/* 0x1bea: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1bf2:
	/* 0x1bf2: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_1bfc:
	/* 0x1bfc: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1c04:
	/* 0x1c04: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_1c0e:
	/* 0x1c0e: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1c16:
	/* 0x1c16: movzx  edx,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1c1b:
	/* 0x1c1b: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1c23:
	/* 0x1c23: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_1c28:
	/* 0x1c28: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c2a:
	/* 0x1c2a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c2d:
	/* 0x1c2d: call   1c32 <perf_unwind_native+0x1c32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1c32:
	/* 0x1c32: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_1c38:
	/* 0x1c38: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c3c:
	/* 0x1c3c: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1c3f:
	/* 0x1c3f: jb     18ba <perf_unwind_native+0x18ba> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c3f, 0x18ba, x86_l_18ba);
x86_l_1c45:
	/* 0x1c45: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_1c4d:
	/* 0x1c4d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1c54:
	/* 0x1c54: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1c59:
	/* 0x1c59: call   1c5e <perf_unwind_native+0x1c5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c5e:
	/* 0x1c5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c61:
	/* 0x1c61: je     1c68 <perf_unwind_native+0x1c68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c61, 0x1c68, x86_l_1c68);
x86_l_1c63:
	/* 0x1c63: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1c66:
	/* 0x1c66: jmp    1c78 <perf_unwind_native+0x1c78> */
	X86_SIM_X86_JMP(0x1c66, 0x1c78, x86_l_1c78);
x86_l_1c68:
	/* 0x1c68: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1c6f:
	/* 0x1c6f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c72:
	/* 0x1c72: jne    23aa <perf_unwind_native+0x23aa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c72, 0x23aa, x86_l_23aa);
x86_l_1c78:
	/* 0x1c78: movzx  r12d,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1c7d:
	/* 0x1c7d: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c7f:
	/* 0x1c7f: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1c83:
	/* 0x1c83: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1c88:
	/* 0x1c88: jne    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c88, 0x541d, x86_l_541d);
x86_l_1c8e:
	/* 0x1c8e: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1c95:
	/* 0x1c95: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c9a:
	/* 0x1c9a: jne    2106 <perf_unwind_native+0x2106> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c9a, 0x2106, x86_l_2106);
x86_l_1ca0:
	/* 0x1ca0: mov    DWORD PTR [rsp+0x10],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476741ULL);
x86_l_1ca8:
	/* 0x1ca8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1caf:
	/* 0x1caf: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cb4:
	/* 0x1cb4: call   1cb9 <perf_unwind_native+0x1cb9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cb9:
	/* 0x1cb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cbc:
	/* 0x1cbc: je     1d5e <perf_unwind_native+0x1d5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cbc, 0x1d5e, x86_l_1d5e);
x86_l_1cc2:
	/* 0x1cc2: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1cc5:
	/* 0x1cc5: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cca:
	/* 0x1cca: je     1d69 <perf_unwind_native+0x1d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cca, 0x1d69, x86_l_1d69);
x86_l_1cd0:
	/* 0x1cd0: movabs rax,0x63617473206e6f20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7161132920309968672ULL);
x86_l_1cda:
	/* 0x1cda: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1ce2:
	/* 0x1ce2: movabs rax,0x7525206e6f697469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8441188735263536233ULL);
x86_l_1cec:
	/* 0x1cec: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1cf4:
	/* 0x1cf4: movabs rax,0x736f70206f742078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8317990321387741304ULL);
x86_l_1cfe:
	/* 0x1cfe: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1d06:
	/* 0x1d06: movabs rax,0x6c6c2520786c6c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274970520613ULL);
x86_l_1d10:
	/* 0x1d10: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1d18:
	/* 0x1d18: movabs rax,0x20676e6968737550 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334956330817910096ULL);
x86_l_1d22:
	/* 0x1d22: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1d2a:
	/* 0x1d2a: mov    DWORD PTR [rsp+0xb7],0xa6b63 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 785979698019ULL);
x86_l_1d35:
	/* 0x1d35: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1d3c:
	/* 0x1d3c: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1d43:
	/* 0x1d43: mov    r8d,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1d4a:
	/* 0x1d4a: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1d52:
	/* 0x1d52: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_1d57:
	/* 0x1d57: call   1d5c <perf_unwind_native+0x1d5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_1d5c:
	/* 0x1d5c: jmp    1d69 <perf_unwind_native+0x1d69> */
	X86_SIM_X86_JMP(0x1d5c, 0x1d69, x86_l_1d69);
x86_l_1d5e:
	/* 0x1d5e: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d63:
	/* 0x1d63: jne    2209 <perf_unwind_native+0x2209> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d63, 0x2209, x86_l_2209);
x86_l_1d69:
	/* 0x1d69: mov    eax,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1d6f:
	/* 0x1d6f: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_1d73:
	/* 0x1d73: ja     12d <perf_unwind_native+0x12d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d73, 0x12d, x86_l_12d);
x86_l_1d79:
	/* 0x1d79: movzx  ecx,BYTE PTR [rbx+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_1d80:
	/* 0x1d80: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1d87:
	/* 0x1d87: mov    rsi,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1d8e:
	/* 0x1d8e: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d91:
	/* 0x1d91: mov    DWORD PTR [rbx+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1d97:
	/* 0x1d97: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_1d9b:
	/* 0x1d9b: mov    QWORD PTR [rbx+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_1da3:
	/* 0x1da3: mov    QWORD PTR [rbx+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_1dab:
	/* 0x1dab: mov    BYTE PTR [rbx+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_1db3:
	/* 0x1db3: mov    BYTE PTR [rbx+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_1dba:
	/* 0x1dba: mov    DWORD PTR [rbx+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_1dc5:
	/* 0x1dc5: mov    WORD PTR [rbx+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_1dcf:
	/* 0x1dcf: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1dd7:
	/* 0x1dd7: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1dde:
	/* 0x1dde: mov    QWORD PTR [rsp+0x150],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_1de6:
	/* 0x1de6: mov    QWORD PTR [rsp+0x70],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1deb:
	/* 0x1deb: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1df2:
	/* 0x1df2: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1df5:
	/* 0x1df5: and    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709486080ULL);
x86_l_1dfb:
	/* 0x1dfb: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1e00:
	/* 0x1e00: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e05:
	/* 0x1e05: jne    21b1 <perf_unwind_native+0x21b1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e05, 0x21b1, x86_l_21b1);
x86_l_1e0b:
	/* 0x1e0b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_1e12:
	/* 0x1e12: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1e17:
	/* 0x1e17: call   1e1c <perf_unwind_native+0x1e1c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e1c:
	/* 0x1e1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e1f:
	/* 0x1e1f: je     5100 <perf_unwind_native+0x5100> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e1f, 0x5100, x86_l_5100);
x86_l_1e25:
	/* 0x1e25: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e28:
	/* 0x1e28: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_1e2c:
	/* 0x1e2c: movzx  ecx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1e2f:
	/* 0x1e2f: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1e32:
	/* 0x1e32: jg     1e60 <perf_unwind_native+0x1e60> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e32, 0x1e60, x86_l_1e60);
x86_l_1e34:
	/* 0x1e34: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1e37:
	/* 0x1e37: jg     1e8c <perf_unwind_native+0x1e8c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e37, 0x1e8c, x86_l_1e8c);
x86_l_1e39:
	/* 0x1e39: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1e3c:
	/* 0x1e3c: jg     1ed2 <perf_unwind_native+0x1ed2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e3c, 0x1ed2, x86_l_1ed2);
x86_l_1e42:
	/* 0x1e42: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1e45:
	/* 0x1e45: je     1f35 <perf_unwind_native+0x1f35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e45, 0x1f35, x86_l_1f35);
x86_l_1e4b:
	/* 0x1e4b: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1e4e:
	/* 0x1e4e: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e4e, 0x5276, x86_l_5276);
x86_l_1e54:
	/* 0x1e54: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas));
x86_l_1e5b:
	/* 0x1e5b: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1e5b, 0x1f7b, x86_l_1f7b);
x86_l_1e60:
	/* 0x1e60: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_1e63:
	/* 0x1e63: jg     1eaf <perf_unwind_native+0x1eaf> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e63, 0x1eaf, x86_l_1eaf);
x86_l_1e65:
	/* 0x1e65: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e68:
	/* 0x1e68: jg     1ef0 <perf_unwind_native+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e68, 0x1ef0, x86_l_1ef0);
x86_l_1e6e:
	/* 0x1e6e: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1e71:
	/* 0x1e71: je     1f3e <perf_unwind_native+0x1f3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e71, 0x1f3e, x86_l_1f3e);
x86_l_1e77:
	/* 0x1e77: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e7a:
	/* 0x1e7a: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e7a, 0x5276, x86_l_5276);
x86_l_1e80:
	/* 0x1e80: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas));
x86_l_1e87:
	/* 0x1e87: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1e87, 0x1f7b, x86_l_1f7b);
x86_l_1e8c:
	/* 0x1e8c: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e8f:
	/* 0x1e8f: jg     1f07 <perf_unwind_native+0x1f07> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e8f, 0x1f07, x86_l_1f07);
x86_l_1e91:
	/* 0x1e91: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1e94:
	/* 0x1e94: je     1f47 <perf_unwind_native+0x1f47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e94, 0x1f47, x86_l_1f47);
x86_l_1e9a:
	/* 0x1e9a: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e9d:
	/* 0x1e9d: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e9d, 0x5276, x86_l_5276);
x86_l_1ea3:
	/* 0x1ea3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas));
x86_l_1eaa:
	/* 0x1eaa: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1eaa, 0x1f7b, x86_l_1f7b);
x86_l_1eaf:
	/* 0x1eaf: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1eb2:
	/* 0x1eb2: jg     1f1e <perf_unwind_native+0x1f1e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1eb2, 0x1f1e, x86_l_1f1e);
x86_l_1eb4:
	/* 0x1eb4: cmp    ecx,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_1eb7:
	/* 0x1eb7: je     1f50 <perf_unwind_native+0x1f50> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb7, 0x1f50, x86_l_1f50);
x86_l_1ebd:
	/* 0x1ebd: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1ec0:
	/* 0x1ec0: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ec0, 0x5276, x86_l_5276);
x86_l_1ec6:
	/* 0x1ec6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas));
x86_l_1ecd:
	/* 0x1ecd: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1ecd, 0x1f7b, x86_l_1f7b);
x86_l_1ed2:
	/* 0x1ed2: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1ed5:
	/* 0x1ed5: je     1f59 <perf_unwind_native+0x1f59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed5, 0x1f59, x86_l_1f59);
x86_l_1edb:
	/* 0x1edb: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1ede:
	/* 0x1ede: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ede, 0x5276, x86_l_5276);
x86_l_1ee4:
	/* 0x1ee4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas));
x86_l_1eeb:
	/* 0x1eeb: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1eeb, 0x1f7b, x86_l_1f7b);
x86_l_1ef0:
	/* 0x1ef0: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_1ef3:
	/* 0x1ef3: je     1f62 <perf_unwind_native+0x1f62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef3, 0x1f62, x86_l_1f62);
x86_l_1ef5:
	/* 0x1ef5: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_1ef8:
	/* 0x1ef8: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ef8, 0x5276, x86_l_5276);
x86_l_1efe:
	/* 0x1efe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas));
x86_l_1f05:
	/* 0x1f05: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f05, 0x1f7b, x86_l_1f7b);
x86_l_1f07:
	/* 0x1f07: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_1f0a:
	/* 0x1f0a: je     1f6b <perf_unwind_native+0x1f6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f0a, 0x1f6b, x86_l_1f6b);
x86_l_1f0c:
	/* 0x1f0c: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1f0f:
	/* 0x1f0f: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f0f, 0x5276, x86_l_5276);
x86_l_1f15:
	/* 0x1f15: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas));
x86_l_1f1c:
	/* 0x1f1c: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f1c, 0x1f7b, x86_l_1f7b);
x86_l_1f1e:
	/* 0x1f1e: cmp    ecx,0x16 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_1f21:
	/* 0x1f21: je     1f74 <perf_unwind_native+0x1f74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f21, 0x1f74, x86_l_1f74);
x86_l_1f23:
	/* 0x1f23: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_1f26:
	/* 0x1f26: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f26, 0x5276, x86_l_5276);
x86_l_1f2c:
	/* 0x1f2c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas));
x86_l_1f33:
	/* 0x1f33: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f33, 0x1f7b, x86_l_1f7b);
x86_l_1f35:
	/* 0x1f35: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas));
x86_l_1f3c:
	/* 0x1f3c: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f3c, 0x1f7b, x86_l_1f7b);
x86_l_1f3e:
	/* 0x1f3e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas));
x86_l_1f45:
	/* 0x1f45: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f45, 0x1f7b, x86_l_1f7b);
x86_l_1f47:
	/* 0x1f47: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas));
x86_l_1f4e:
	/* 0x1f4e: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f4e, 0x1f7b, x86_l_1f7b);
x86_l_1f50:
	/* 0x1f50: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas));
x86_l_1f57:
	/* 0x1f57: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f57, 0x1f7b, x86_l_1f7b);
x86_l_1f59:
	/* 0x1f59: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas));
x86_l_1f60:
	/* 0x1f60: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f60, 0x1f7b, x86_l_1f7b);
x86_l_1f62:
	/* 0x1f62: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas));
x86_l_1f69:
	/* 0x1f69: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f69, 0x1f7b, x86_l_1f7b);
x86_l_1f6b:
	/* 0x1f6b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas));
x86_l_1f72:
	/* 0x1f72: jmp    1f7b <perf_unwind_native+0x1f7b> */
	X86_SIM_X86_JMP(0x1f72, 0x1f7b, x86_l_1f7b);
x86_l_1f74:
	/* 0x1f74: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas));
x86_l_1f7b:
	/* 0x1f7b: lea    rsi,[rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_1f83:
	/* 0x1f83: call   1f88 <perf_unwind_native+0x1f88> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f88:
	/* 0x1f88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f8b:
	/* 0x1f8b: je     53f1 <perf_unwind_native+0x53f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8b, 0x53f1, x86_l_53f1);
x86_l_1f91:
	/* 0x1f91: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f94:
	/* 0x1f94: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f98:
	/* 0x1f98: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_1f9d:
	/* 0x1f9d: mov    rax,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1fa4:
	/* 0x1fa4: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fa9:
	/* 0x1fa9: movzx  eax,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_1faf:
	/* 0x1faf: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1fb1:
	/* 0x1fb1: je     2652 <perf_unwind_native+0x2652> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb1, 0x2652, x86_l_2652);
x86_l_1fb7:
	/* 0x1fb7: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fba:
	/* 0x1fba: add    r14d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1fbd:
	/* 0x1fbd: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_1fc4:
	/* 0x1fc4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc7:
	/* 0x1fc7: jne    22e8 <perf_unwind_native+0x22e8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fc7, 0x22e8, x86_l_22e8);
x86_l_1fcd:
	/* 0x1fcd: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1fd1:
	/* 0x1fd1: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1fd3:
	/* 0x1fd3: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fd7:
	/* 0x1fd7: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fdc:
	/* 0x1fdc: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1fdf:
	/* 0x1fdf: call   1fe4 <perf_unwind_native+0x1fe4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1fe4:
	/* 0x1fe4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fe7:
	/* 0x1fe7: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe7, 0x5d95, x86_l_5d95);
x86_l_1fed:
	/* 0x1fed: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ff1:
	/* 0x1ff1: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ff6:
	/* 0x1ff6: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff9:
	/* 0x1ff9: ja     2002 <perf_unwind_native+0x2002> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ff9, 0x2002, x86_l_2002);
x86_l_1ffb:
	/* 0x1ffb: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1ffd:
	/* 0x1ffd: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2000:
	/* 0x2000: jmp    2005 <perf_unwind_native+0x2005> */
	X86_SIM_X86_JMP(0x2000, 0x2005, x86_l_2005);
x86_l_2002:
	/* 0x2002: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2005:
	/* 0x2005: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2008:
	/* 0x2008: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2008, 0x2646, x86_l_2646);
x86_l_200e:
	/* 0x200e: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2012:
	/* 0x2012: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2014:
	/* 0x2014: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2018:
	/* 0x2018: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_201d:
	/* 0x201d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2020:
	/* 0x2020: call   2025 <perf_unwind_native+0x2025> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2025:
	/* 0x2025: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2028:
	/* 0x2028: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2028, 0x5d95, x86_l_5d95);
x86_l_202e:
	/* 0x202e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2032:
	/* 0x2032: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2037:
	/* 0x2037: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203a:
	/* 0x203a: ja     2043 <perf_unwind_native+0x2043> */
	X86_SIM_X86_JCC(X86_CC_A, 0x203a, 0x2043, x86_l_2043);
x86_l_203c:
	/* 0x203c: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_203e:
	/* 0x203e: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2041:
	/* 0x2041: jmp    2046 <perf_unwind_native+0x2046> */
	X86_SIM_X86_JMP(0x2041, 0x2046, x86_l_2046);
x86_l_2043:
	/* 0x2043: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2046:
	/* 0x2046: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2049:
	/* 0x2049: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2049, 0x2646, x86_l_2646);
x86_l_204f:
	/* 0x204f: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2053:
	/* 0x2053: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2055:
	/* 0x2055: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2059:
	/* 0x2059: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_205e:
	/* 0x205e: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2061:
	/* 0x2061: call   2066 <perf_unwind_native+0x2066> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2066:
	/* 0x2066: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2069:
	/* 0x2069: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2069, 0x5d95, x86_l_5d95);
x86_l_206f:
	/* 0x206f: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2073:
	/* 0x2073: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2078:
	/* 0x2078: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_207b:
	/* 0x207b: ja     2084 <perf_unwind_native+0x2084> */
	X86_SIM_X86_JCC(X86_CC_A, 0x207b, 0x2084, x86_l_2084);
x86_l_207d:
	/* 0x207d: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_207f:
	/* 0x207f: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2082:
	/* 0x2082: jmp    2087 <perf_unwind_native+0x2087> */
	X86_SIM_X86_JMP(0x2082, 0x2087, x86_l_2087);
x86_l_2084:
	/* 0x2084: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2087:
	/* 0x2087: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_208a:
	/* 0x208a: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x208a, 0x2646, x86_l_2646);
x86_l_2090:
	/* 0x2090: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2094:
	/* 0x2094: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2096:
	/* 0x2096: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_209a:
	/* 0x209a: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_209f:
	/* 0x209f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_20a2:
	/* 0x20a2: call   20a7 <perf_unwind_native+0x20a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20a7:
	/* 0x20a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20aa:
	/* 0x20aa: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20aa, 0x5d95, x86_l_5d95);
x86_l_20b0:
	/* 0x20b0: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20b4:
	/* 0x20b4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b9:
	/* 0x20b9: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20bc:
	/* 0x20bc: ja     20c5 <perf_unwind_native+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x20bc, 0x20c5, x86_l_20c5);
x86_l_20be:
	/* 0x20be: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20c0:
	/* 0x20c0: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_20c3:
	/* 0x20c3: jmp    20c8 <perf_unwind_native+0x20c8> */
	X86_SIM_X86_JMP(0x20c3, 0x20c8, x86_l_20c8);
x86_l_20c5:
	/* 0x20c5: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_20c8:
	/* 0x20c8: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_20cb:
	/* 0x20cb: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x20cb, 0x2646, x86_l_2646);
x86_l_20d1:
	/* 0x20d1: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_20d5:
	/* 0x20d5: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_20d7:
	/* 0x20d7: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20db:
	/* 0x20db: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20e0:
	/* 0x20e0: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_20e3:
	/* 0x20e3: call   20e8 <perf_unwind_native+0x20e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20e8:
	/* 0x20e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20eb:
	/* 0x20eb: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20eb, 0x5d95, x86_l_5d95);
x86_l_20f1:
	/* 0x20f1: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20f5:
	/* 0x20f5: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20fa:
	/* 0x20fa: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20fd:
	/* 0x20fd: ja     2169 <perf_unwind_native+0x2169> */
	X86_SIM_X86_JCC(X86_CC_A, 0x20fd, 0x2169, x86_l_2169);
x86_l_20ff:
	/* 0x20ff: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2101:
	/* 0x2101: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2104:
	/* 0x2104: jmp    216c <perf_unwind_native+0x216c> */
	X86_SIM_X86_JMP(0x2104, 0x216c, x86_l_216c);
x86_l_2106:
	/* 0x2106: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_210c:
	/* 0x210c: movabs rax,0x3d3d206425206576 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4412718824384652662ULL);
x86_l_2116:
	/* 0x2116: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_211e:
	/* 0x211e: movabs rax,0x6974616e5f646e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7598805597955583593ULL);
x86_l_2128:
	/* 0x2128: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2130:
	/* 0x2130: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8605944719278423357ULL);
x86_l_213a:
	/* 0x213a: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2142:
	/* 0x2142: mov    DWORD PTR [rsp+0xa8],0xa3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721555176765ULL);
x86_l_214d:
	/* 0x214d: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2155:
	/* 0x2155: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_215a:
	/* 0x215a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215c:
	/* 0x215c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215f:
	/* 0x215f: call   2164 <perf_unwind_native+0x2164> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2164:
	/* 0x2164: jmp    1ca0 <perf_unwind_native+0x1ca0> */
	X86_SIM_X86_JMP(0x2164, 0x1ca0, x86_l_1ca0);
x86_l_2169:
	/* 0x2169: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_216c:
	/* 0x216c: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_216f:
	/* 0x216f: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x216f, 0x2646, x86_l_2646);
x86_l_2175:
	/* 0x2175: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2179:
	/* 0x2179: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_217b:
	/* 0x217b: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_217f:
	/* 0x217f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2184:
	/* 0x2184: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2187:
	/* 0x2187: call   218c <perf_unwind_native+0x218c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_218c:
	/* 0x218c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_218f:
	/* 0x218f: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x218f, 0x5d95, x86_l_5d95);
x86_l_2195:
	/* 0x2195: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2199:
	/* 0x2199: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_219e:
	/* 0x219e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21a1:
	/* 0x21a1: ja     22a0 <perf_unwind_native+0x22a0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x21a1, 0x22a0, x86_l_22a0);
x86_l_21a7:
	/* 0x21a7: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21a9:
	/* 0x21a9: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_21ac:
	/* 0x21ac: jmp    22a3 <perf_unwind_native+0x22a3> */
	X86_SIM_X86_JMP(0x21ac, 0x22a3, x86_l_22a3);
x86_l_21b1:
	/* 0x21b1: movabs rax,0xa786c253a786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471844735118373ULL);
x86_l_21bb:
	/* 0x21bb: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21c0:
	/* 0x21c0: movabs rax,0x20726f662061746c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338053640979313772ULL);
x86_l_21ca:
	/* 0x21ca: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21cf:
	/* 0x21cf: movabs rax,0x6564206b63617473 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7306000141102707827ULL);
x86_l_21d9:
	/* 0x21d9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21de:
	/* 0x21de: movabs rax,0x207075206b6f6f4c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337496988707155788ULL);
x86_l_21e8:
	/* 0x21e8: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21ed:
	/* 0x21ed: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_21f2:
	/* 0x21f2: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21f7:
	/* 0x21f7: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_21fc:
	/* 0x21fc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21ff:
	/* 0x21ff: call   2204 <perf_unwind_native+0x2204> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2204:
	/* 0x2204: jmp    1e0b <perf_unwind_native+0x1e0b> */
	X86_SIM_X86_JMP(0x2204, 0x1e0b, x86_l_1e0b);
x86_l_2209:
	/* 0x2209: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_2213:
	/* 0x2213: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_221b:
	/* 0x221b: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_2225:
	/* 0x2225: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_222d:
	/* 0x222d: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_2237:
	/* 0x2237: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_223f:
	/* 0x223f: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_2249:
	/* 0x2249: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2251:
	/* 0x2251: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_225b:
	/* 0x225b: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2263:
	/* 0x2263: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_226d:
	/* 0x226d: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2275:
	/* 0x2275: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2279:
	/* 0x2279: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2281:
	/* 0x2281: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2286:
	/* 0x2286: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2288:
	/* 0x2288: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_228b:
	/* 0x228b: call   2290 <perf_unwind_native+0x2290> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2290:
	/* 0x2290: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2295:
	/* 0x2295: je     1d69 <perf_unwind_native+0x1d69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2295, 0x1d69, x86_l_1d69);
x86_l_229b:
	/* 0x229b: jmp    1cd0 <perf_unwind_native+0x1cd0> */
	X86_SIM_X86_JMP(0x229b, 0x1cd0, x86_l_1cd0);
x86_l_22a0:
	/* 0x22a0: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_22a3:
	/* 0x22a3: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_22a6:
	/* 0x22a6: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x22a6, 0x2646, x86_l_2646);
x86_l_22ac:
	/* 0x22ac: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_22b0:
	/* 0x22b0: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_22b2:
	/* 0x22b2: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22b6:
	/* 0x22b6: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22bb:
	/* 0x22bb: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_22be:
	/* 0x22be: call   22c3 <perf_unwind_native+0x22c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22c3:
	/* 0x22c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22c6:
	/* 0x22c6: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c6, 0x5d95, x86_l_5d95);
x86_l_22cc:
	/* 0x22cc: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22d0:
	/* 0x22d0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d5:
	/* 0x22d5: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22d8:
	/* 0x22d8: ja     2362 <perf_unwind_native+0x2362> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22d8, 0x2362, x86_l_2362);
x86_l_22de:
	/* 0x22de: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22e0:
	/* 0x22e0: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_22e3:
	/* 0x22e3: jmp    2365 <perf_unwind_native+0x2365> */
	X86_SIM_X86_JMP(0x22e3, 0x2365, x86_l_2365);
x86_l_22e8:
	/* 0x22e8: movabs rax,0xa296425204449 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2860259863446601ULL);
x86_l_22f2:
	/* 0x22f2: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_22f7:
	/* 0x22f7: movabs rax,0x70616d2820756c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8097873624099548197ULL);
x86_l_2301:
	/* 0x2301: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2306:
	/* 0x2306: movabs rax,0x206f7420756c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337214414386373920ULL);
x86_l_2310:
	/* 0x2310: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2315:
	/* 0x2315: movabs rax,0x6d6f726620656220 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7885647255504773664ULL);
x86_l_231f:
	/* 0x231f: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2324:
	/* 0x2324: movabs rax,0x646c756f68732073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7236287822631739507ULL);
x86_l_232e:
	/* 0x232e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2333:
	/* 0x2333: movabs rax,0x6c61767265746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653462537629257ULL);
x86_l_233d:
	/* 0x233d: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2342:
	/* 0x2342: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2345:
	/* 0x2345: movzx  r8d,WORD PTR [r12+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_234b:
	/* 0x234b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2350:
	/* 0x2350: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_2355:
	/* 0x2355: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2358:
	/* 0x2358: call   235d <perf_unwind_native+0x235d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_235d:
	/* 0x235d: jmp    1fcd <perf_unwind_native+0x1fcd> */
	X86_SIM_X86_JMP(0x235d, 0x1fcd, x86_l_1fcd);
x86_l_2362:
	/* 0x2362: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2365:
	/* 0x2365: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2368:
	/* 0x2368: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2368, 0x2646, x86_l_2646);
x86_l_236e:
	/* 0x236e: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2372:
	/* 0x2372: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2374:
	/* 0x2374: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2378:
	/* 0x2378: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_237d:
	/* 0x237d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2380:
	/* 0x2380: call   2385 <perf_unwind_native+0x2385> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2385:
	/* 0x2385: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2388:
	/* 0x2388: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2388, 0x5d95, x86_l_5d95);
x86_l_238e:
	/* 0x238e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2392:
	/* 0x2392: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2397:
	/* 0x2397: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_239a:
	/* 0x239a: ja     2436 <perf_unwind_native+0x2436> */
	X86_SIM_X86_JCC(X86_CC_A, 0x239a, 0x2436, x86_l_2436);
x86_l_23a0:
	/* 0x23a0: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23a2:
	/* 0x23a2: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_23a5:
	/* 0x23a5: jmp    2439 <perf_unwind_native+0x2439> */
	X86_SIM_X86_JMP(0x23a5, 0x2439, x86_l_2439);
x86_l_23aa:
	/* 0x23aa: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_23b4:
	/* 0x23b4: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_23bc:
	/* 0x23bc: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_23c6:
	/* 0x23c6: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_23ce:
	/* 0x23ce: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_23d8:
	/* 0x23d8: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_23e0:
	/* 0x23e0: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_23ea:
	/* 0x23ea: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_23f2:
	/* 0x23f2: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_23fc:
	/* 0x23fc: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2404:
	/* 0x2404: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_240e:
	/* 0x240e: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2416:
	/* 0x2416: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_241a:
	/* 0x241a: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2422:
	/* 0x2422: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2427:
	/* 0x2427: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2429:
	/* 0x2429: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_242c:
	/* 0x242c: call   2431 <perf_unwind_native+0x2431> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2431:
	/* 0x2431: jmp    1c78 <perf_unwind_native+0x1c78> */
	X86_SIM_X86_JMP(0x2431, 0x1c78, x86_l_1c78);
x86_l_2436:
	/* 0x2436: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2439:
	/* 0x2439: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_243c:
	/* 0x243c: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x243c, 0x2646, x86_l_2646);
x86_l_2442:
	/* 0x2442: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2446:
	/* 0x2446: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2448:
	/* 0x2448: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_244c:
	/* 0x244c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2451:
	/* 0x2451: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2454:
	/* 0x2454: call   2459 <perf_unwind_native+0x2459> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2459:
	/* 0x2459: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_245c:
	/* 0x245c: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x245c, 0x5d95, x86_l_5d95);
x86_l_2462:
	/* 0x2462: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2466:
	/* 0x2466: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_246b:
	/* 0x246b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_246e:
	/* 0x246e: ja     2477 <perf_unwind_native+0x2477> */
	X86_SIM_X86_JCC(X86_CC_A, 0x246e, 0x2477, x86_l_2477);
x86_l_2470:
	/* 0x2470: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2472:
	/* 0x2472: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2475:
	/* 0x2475: jmp    247a <perf_unwind_native+0x247a> */
	X86_SIM_X86_JMP(0x2475, 0x247a, x86_l_247a);
x86_l_2477:
	/* 0x2477: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_247a:
	/* 0x247a: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_247d:
	/* 0x247d: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x247d, 0x2646, x86_l_2646);
x86_l_2483:
	/* 0x2483: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2487:
	/* 0x2487: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2489:
	/* 0x2489: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_248d:
	/* 0x248d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2492:
	/* 0x2492: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2495:
	/* 0x2495: call   249a <perf_unwind_native+0x249a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_249a:
	/* 0x249a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_249d:
	/* 0x249d: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x249d, 0x5d95, x86_l_5d95);
x86_l_24a3:
	/* 0x24a3: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a7:
	/* 0x24a7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ac:
	/* 0x24ac: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24af:
	/* 0x24af: ja     24b8 <perf_unwind_native+0x24b8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x24af, 0x24b8, x86_l_24b8);
x86_l_24b1:
	/* 0x24b1: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_24b3:
	/* 0x24b3: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_24b6:
	/* 0x24b6: jmp    24bb <perf_unwind_native+0x24bb> */
	X86_SIM_X86_JMP(0x24b6, 0x24bb, x86_l_24bb);
x86_l_24b8:
	/* 0x24b8: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_24bb:
	/* 0x24bb: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_24be:
	/* 0x24be: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x24be, 0x2646, x86_l_2646);
x86_l_24c4:
	/* 0x24c4: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_24c8:
	/* 0x24c8: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_24ca:
	/* 0x24ca: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ce:
	/* 0x24ce: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24d3:
	/* 0x24d3: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_24d6:
	/* 0x24d6: call   24db <perf_unwind_native+0x24db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24db:
	/* 0x24db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24de:
	/* 0x24de: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24de, 0x5d95, x86_l_5d95);
x86_l_24e4:
	/* 0x24e4: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24e8:
	/* 0x24e8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ed:
	/* 0x24ed: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24f0:
	/* 0x24f0: ja     24f9 <perf_unwind_native+0x24f9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x24f0, 0x24f9, x86_l_24f9);
x86_l_24f2:
	/* 0x24f2: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_24f4:
	/* 0x24f4: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_24f7:
	/* 0x24f7: jmp    24fc <perf_unwind_native+0x24fc> */
	X86_SIM_X86_JMP(0x24f7, 0x24fc, x86_l_24fc);
x86_l_24f9:
	/* 0x24f9: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_24fc:
	/* 0x24fc: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_24ff:
	/* 0x24ff: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x24ff, 0x2646, x86_l_2646);
x86_l_2505:
	/* 0x2505: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2509:
	/* 0x2509: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_250b:
	/* 0x250b: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_250f:
	/* 0x250f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2514:
	/* 0x2514: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2517:
	/* 0x2517: call   251c <perf_unwind_native+0x251c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_251c:
	/* 0x251c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_251f:
	/* 0x251f: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x251f, 0x5d95, x86_l_5d95);
x86_l_2525:
	/* 0x2525: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2529:
	/* 0x2529: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_252e:
	/* 0x252e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2531:
	/* 0x2531: ja     253a <perf_unwind_native+0x253a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2531, 0x253a, x86_l_253a);
x86_l_2533:
	/* 0x2533: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2535:
	/* 0x2535: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2538:
	/* 0x2538: jmp    253d <perf_unwind_native+0x253d> */
	X86_SIM_X86_JMP(0x2538, 0x253d, x86_l_253d);
x86_l_253a:
	/* 0x253a: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_253d:
	/* 0x253d: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2540:
	/* 0x2540: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2540, 0x2646, x86_l_2646);
x86_l_2546:
	/* 0x2546: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_254a:
	/* 0x254a: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_254c:
	/* 0x254c: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2550:
	/* 0x2550: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2555:
	/* 0x2555: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2558:
	/* 0x2558: call   255d <perf_unwind_native+0x255d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_255d:
	/* 0x255d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2560:
	/* 0x2560: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2560, 0x5d95, x86_l_5d95);
x86_l_2566:
	/* 0x2566: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_256a:
	/* 0x256a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_256f:
	/* 0x256f: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2572:
	/* 0x2572: ja     257b <perf_unwind_native+0x257b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2572, 0x257b, x86_l_257b);
x86_l_2574:
	/* 0x2574: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2576:
	/* 0x2576: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2579:
	/* 0x2579: jmp    257e <perf_unwind_native+0x257e> */
	X86_SIM_X86_JMP(0x2579, 0x257e, x86_l_257e);
x86_l_257b:
	/* 0x257b: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_257e:
	/* 0x257e: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2581:
	/* 0x2581: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2581, 0x2646, x86_l_2646);
x86_l_2587:
	/* 0x2587: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_258b:
	/* 0x258b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_258d:
	/* 0x258d: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2591:
	/* 0x2591: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2596:
	/* 0x2596: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2599:
	/* 0x2599: call   259e <perf_unwind_native+0x259e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_259e:
	/* 0x259e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25a1:
	/* 0x25a1: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a1, 0x5d95, x86_l_5d95);
x86_l_25a7:
	/* 0x25a7: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25ab:
	/* 0x25ab: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25b0:
	/* 0x25b0: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b3:
	/* 0x25b3: ja     25bc <perf_unwind_native+0x25bc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x25b3, 0x25bc, x86_l_25bc);
x86_l_25b5:
	/* 0x25b5: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_25b7:
	/* 0x25b7: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_25ba:
	/* 0x25ba: jmp    25bf <perf_unwind_native+0x25bf> */
	X86_SIM_X86_JMP(0x25ba, 0x25bf, x86_l_25bf);
x86_l_25bc:
	/* 0x25bc: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_25bf:
	/* 0x25bf: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_25c2:
	/* 0x25c2: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x25c2, 0x2646, x86_l_2646);
x86_l_25c8:
	/* 0x25c8: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_25cc:
	/* 0x25cc: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_25ce:
	/* 0x25ce: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25d2:
	/* 0x25d2: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25d7:
	/* 0x25d7: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_25da:
	/* 0x25da: call   25df <perf_unwind_native+0x25df> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25df:
	/* 0x25df: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e2:
	/* 0x25e2: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25e2, 0x5d95, x86_l_5d95);
x86_l_25e8:
	/* 0x25e8: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25ec:
	/* 0x25ec: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25f1:
	/* 0x25f1: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25f4:
	/* 0x25f4: ja     25fd <perf_unwind_native+0x25fd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x25f4, 0x25fd, x86_l_25fd);
x86_l_25f6:
	/* 0x25f6: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_25f8:
	/* 0x25f8: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_25fb:
	/* 0x25fb: jmp    2600 <perf_unwind_native+0x2600> */
	X86_SIM_X86_JMP(0x25fb, 0x2600, x86_l_2600);
x86_l_25fd:
	/* 0x25fd: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2600:
	/* 0x2600: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2603:
	/* 0x2603: jae    2646 <perf_unwind_native+0x2646> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2603, 0x2646, x86_l_2646);
x86_l_2605:
	/* 0x2605: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2609:
	/* 0x2609: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_260b:
	/* 0x260b: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_260f:
	/* 0x260f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2614:
	/* 0x2614: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2617:
	/* 0x2617: call   261c <perf_unwind_native+0x261c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_261c:
	/* 0x261c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_261f:
	/* 0x261f: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261f, 0x5d95, x86_l_5d95);
x86_l_2625:
	/* 0x2625: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2629:
	/* 0x2629: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_262e:
	/* 0x262e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2631:
	/* 0x2631: ja     263a <perf_unwind_native+0x263a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2631, 0x263a, x86_l_263a);
x86_l_2633:
	/* 0x2633: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2635:
	/* 0x2635: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2638:
	/* 0x2638: jmp    263d <perf_unwind_native+0x263d> */
	X86_SIM_X86_JMP(0x2638, 0x263d, x86_l_263d);
x86_l_263a:
	/* 0x263a: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_263d:
	/* 0x263d: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2640:
	/* 0x2640: jb     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2640, 0x5d95, x86_l_5d95);
x86_l_2646:
	/* 0x2646: mov    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2649:
	/* 0x2649: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_264c:
	/* 0x264c: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x264c, 0x5d95, x86_l_5d95);
x86_l_2652:
	/* 0x2652: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2655:
	/* 0x2655: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_265a:
	/* 0x265a: lea    rsi,[rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_265f:
	/* 0x265f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2662:
	/* 0x2662: call   2667 <perf_unwind_native+0x2667> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2667:
	/* 0x2667: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_266a:
	/* 0x266a: je     409e <perf_unwind_native+0x409e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x266a, 0x409e, x86_l_409e);
x86_l_2670:
	/* 0x2670: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2673:
	/* 0x2673: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_267a:
	/* 0x267a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_267d:
	/* 0x267d: jne    2ab0 <perf_unwind_native+0x2ab0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x267d, 0x2ab0, x86_l_2ab0);
x86_l_2683:
	/* 0x2683: movzx  r15d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_2689:
	/* 0x2689: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_268e:
	/* 0x268e: sub    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2691:
	/* 0x2691: mov    eax,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_2695:
	/* 0x2695: cmp    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_2699:
	/* 0x2699: jae    26a2 <perf_unwind_native+0x26a2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2699, 0x26a2, x86_l_26a2);
x86_l_269b:
	/* 0x269b: add    r15d,0x10000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 65536ULL);
x86_l_26a2:
	/* 0x26a2: movzx  eax,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_26a7:
	/* 0x26a7: mov    DWORD PTR [rsp+0x68],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_26ab:
	/* 0x26ab: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_26b0:
	/* 0x26b0: je     40b3 <perf_unwind_native+0x40b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26b0, 0x40b3, x86_l_40b3);
x86_l_26b6:
	/* 0x26b6: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_26bb:
	/* 0x26bb: jne    26fa <perf_unwind_native+0x26fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26bb, 0x26fa, x86_l_26fa);
x86_l_26bd:
	/* 0x26bd: mov    DWORD PTR [rsp+0x84],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683079ULL);
x86_l_26c8:
	/* 0x26c8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_26cf:
	/* 0x26cf: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_26d7:
	/* 0x26d7: call   26dc <perf_unwind_native+0x26dc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26dc:
	/* 0x26dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26df:
	/* 0x26df: je     26e6 <perf_unwind_native+0x26e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26df, 0x26e6, x86_l_26e6);
x86_l_26e1:
	/* 0x26e1: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_26e4:
	/* 0x26e4: jmp    26f6 <perf_unwind_native+0x26f6> */
	X86_SIM_X86_JMP(0x26e4, 0x26f6, x86_l_26f6);
x86_l_26e6:
	/* 0x26e6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_26ed:
	/* 0x26ed: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f0:
	/* 0x26f0: jne    2b99 <perf_unwind_native+0x2b99> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26f0, 0x2b99, x86_l_2b99);
x86_l_26f6:
	/* 0x26f6: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_26fa:
	/* 0x26fa: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_26fd:
	/* 0x26fd: js     27cf <perf_unwind_native+0x27cf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26fd, 0x27cf, x86_l_27cf);
x86_l_2703:
	/* 0x2703: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_270a:
	/* 0x270a: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_270f:
	/* 0x270f: call   2714 <perf_unwind_native+0x2714> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2714:
	/* 0x2714: mov    QWORD PTR [rsp+0x120],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_271c:
	/* 0x271c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271f:
	/* 0x271f: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2724:
	/* 0x2724: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_272b:
	/* 0x272b: je     5f07 <perf_unwind_native+0x5f07> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272b, 0x5f07, x86_l_5f07);
x86_l_2731:
	/* 0x2731: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_2739:
	/* 0x2739: mov    r12d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_273d:
	/* 0x273d: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2741:
	/* 0x2741: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2743:
	/* 0x2743: je     2783 <perf_unwind_native+0x2783> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2743, 0x2783, x86_l_2783);
x86_l_2745:
	/* 0x2745: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_274c:
	/* 0x274c: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274f:
	/* 0x274f: jne    2b2c <perf_unwind_native+0x2b2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x274f, 0x2b2c, x86_l_2b2c);
x86_l_2755:
	/* 0x2755: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2757:
	/* 0x2757: and    cl,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 127ULL);
x86_l_275a:
	/* 0x275a: movzx  ecx,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_275d:
	/* 0x275d: cmp    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2760:
	/* 0x2760: jl     2783 <perf_unwind_native+0x2783> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2760, 0x2783, x86_l_2783);
x86_l_2762:
	/* 0x2762: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2764:
	/* 0x2764: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2766:
	/* 0x2766: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_2769:
	/* 0x2769: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_276c:
	/* 0x276c: add    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_276f:
	/* 0x276f: add    r12d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_2773:
	/* 0x2773: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_277a:
	/* 0x277a: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277d:
	/* 0x277d: jne    2c13 <perf_unwind_native+0x2c13> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277d, 0x2c13, x86_l_2c13);
x86_l_2783:
	/* 0x2783: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_278b:
	/* 0x278b: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_278e:
	/* 0x278e: mov    ecx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2791:
	/* 0x2791: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2793:
	/* 0x2793: jns    279b <perf_unwind_native+0x279b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2793, 0x279b, x86_l_279b);
x86_l_2795:
	/* 0x2795: mov    ecx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2798:
	/* 0x2798: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_279b:
	/* 0x279b: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_279d:
	/* 0x279d: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_27a0:
	/* 0x27a0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a2:
	/* 0x27a2: mov    QWORD PTR [rsp+0x8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27a7:
	/* 0x27a7: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27aa:
	/* 0x27aa: jg     28d9 <perf_unwind_native+0x28d9> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27aa, 0x28d9, x86_l_28d9);
x86_l_27b0:
	/* 0x27b0: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_27b3:
	/* 0x27b3: je     2a4c <perf_unwind_native+0x2a4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b3, 0x2a4c, x86_l_2a4c);
x86_l_27b9:
	/* 0x27b9: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_27c1:
	/* 0x27c1: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27c4:
	/* 0x27c4: je     2a44 <perf_unwind_native+0x2a44> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c4, 0x2a44, x86_l_2a44);
x86_l_27ca:
	/* 0x27ca: jmp    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JMP(0x27ca, 0x2ce7, x86_l_2ce7);
x86_l_27cf:
	/* 0x27cf: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_27d4:
	/* 0x27d4: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_27da:
	/* 0x27da: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27dd:
	/* 0x27dd: jg     2873 <perf_unwind_native+0x2873> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27dd, 0x2873, x86_l_2873);
x86_l_27e3:
	/* 0x27e3: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_27e6:
	/* 0x27e6: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_27eb:
	/* 0x27eb: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_27f3:
	/* 0x27f3: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_27fb:
	/* 0x27fb: je     6052 <perf_unwind_native+0x6052> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27fb, 0x6052, x86_l_6052);
x86_l_2801:
	/* 0x2801: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2804:
	/* 0x2804: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2804, 0x5417, x86_l_5417);
x86_l_280a:
	/* 0x280a: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280d:
	/* 0x280d: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280f:
	/* 0x280f: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2812:
	/* 0x2812: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2814:
	/* 0x2814: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2817:
	/* 0x2817: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_281a:
	/* 0x281a: lea    rax,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_281e:
	/* 0x281e: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2822:
	/* 0x2822: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2827:
	/* 0x2827: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_282e:
	/* 0x282e: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2831:
	/* 0x2831: je     2ef1 <perf_unwind_native+0x2ef1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2831, 0x2ef1, x86_l_2ef1);
x86_l_2837:
	/* 0x2837: movabs rax,0xa786c2578303d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155647541309ULL);
x86_l_2841:
	/* 0x2841: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2846:
	/* 0x2846: movabs rax,0x616663202c544c50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018406059137322064ULL);
x86_l_2850:
	/* 0x2850: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2855:
	/* 0x2855: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_285a:
	/* 0x285a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_285f:
	/* 0x285f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2864:
	/* 0x2864: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2866:
	/* 0x2866: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2869:
	/* 0x2869: call   286e <perf_unwind_native+0x286e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_286e:
	/* 0x286e: jmp    2ef1 <perf_unwind_native+0x2ef1> */
	X86_SIM_X86_JMP(0x286e, 0x2ef1, x86_l_2ef1);
x86_l_2873:
	/* 0x2873: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2876:
	/* 0x2876: je     2948 <perf_unwind_native+0x2948> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2876, 0x2948, x86_l_2948);
x86_l_287c:
	/* 0x287c: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_287f:
	/* 0x287f: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2884:
	/* 0x2884: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2889:
	/* 0x2889: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2889, 0x5417, x86_l_5417);
x86_l_288f:
	/* 0x288f: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2892:
	/* 0x2892: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2897:
	/* 0x2897: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_289c:
	/* 0x289c: call   28a1 <perf_unwind_native+0x28a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_28a1:
	/* 0x28a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28a4, 0x1522, x86_l_1522);
x86_l_28aa:
	/* 0x28aa: mov    rax,QWORD PTR [rbx+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_28b1:
	/* 0x28b1: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_28b5:
	/* 0x28b5: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_28bc:
	/* 0x28bc: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c1:
	/* 0x28c1: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_28c8:
	/* 0x28c8: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28cd:
	/* 0x28cd: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_28d4:
	/* 0x28d4: jmp    2f32 <perf_unwind_native+0x2f32> */
	X86_SIM_X86_JMP(0x28d4, 0x2f32, x86_l_2f32);
x86_l_28d9:
	/* 0x28d9: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_28dc:
	/* 0x28dc: je     2a3f <perf_unwind_native+0x2a3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28dc, 0x2a3f, x86_l_2a3f);
x86_l_28e2:
	/* 0x28e2: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_28e5:
	/* 0x28e5: jne    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28e5, 0x2ce7, x86_l_2ce7);
x86_l_28eb:
	/* 0x28eb: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_28ee:
	/* 0x28ee: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_28f0:
	/* 0x28f0: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_28f3:
	/* 0x28f3: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_28f6:
	/* 0x28f6: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_28fb:
	/* 0x28fb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2902:
	/* 0x2902: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2905:
	/* 0x2905: jne    2c71 <perf_unwind_native+0x2c71> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2905, 0x2c71, x86_l_2c71);
x86_l_290b:
	/* 0x290b: and    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_290f:
	/* 0x290f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2911:
	/* 0x2911: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2916:
	/* 0x2916: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_291a:
	/* 0x291a: jg     2cbe <perf_unwind_native+0x2cbe> */
	X86_SIM_X86_JCC(X86_CC_G, 0x291a, 0x2cbe, x86_l_2cbe);
x86_l_2920:
	/* 0x2920: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_2928:
	/* 0x2928: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_292b:
	/* 0x292b: je     2cda <perf_unwind_native+0x2cda> */
	X86_SIM_X86_JCC(X86_CC_E, 0x292b, 0x2cda, x86_l_2cda);
x86_l_2931:
	/* 0x2931: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2935:
	/* 0x2935: jne    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2935, 0x2ce7, x86_l_2ce7);
x86_l_293b:
	/* 0x293b: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_2943:
	/* 0x2943: jmp    2cda <perf_unwind_native+0x2cda> */
	X86_SIM_X86_JMP(0x2943, 0x2cda, x86_l_2cda);
x86_l_2948:
	/* 0x2948: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2950:
	/* 0x2950: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2953:
	/* 0x2953: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2957:
	/* 0x2957: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_295f:
	/* 0x295f: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_2964:
	/* 0x2964: call   2969 <perf_unwind_native+0x2969> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2969:
	/* 0x2969: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_296c:
	/* 0x296c: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2971:
	/* 0x2971: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2971, 0x1522, x86_l_1522);
x86_l_2977:
	/* 0x2977: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_297f:
	/* 0x297f: mov    QWORD PTR [rbx+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_2986:
	/* 0x2986: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_298e:
	/* 0x298e: mov    QWORD PTR [rbx+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_2995:
	/* 0x2995: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_299d:
	/* 0x299d: mov    QWORD PTR [rbx+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_29a4:
	/* 0x29a4: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_29ac:
	/* 0x29ac: mov    QWORD PTR [rbx+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_29b3:
	/* 0x29b3: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_29bb:
	/* 0x29bb: mov    QWORD PTR [rbx+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_29c2:
	/* 0x29c2: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_29ca:
	/* 0x29ca: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_29d1:
	/* 0x29d1: mov    rax,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_29d9:
	/* 0x29d9: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_29e0:
	/* 0x29e0: mov    rax,QWORD PTR [rsp+0x110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_29e8:
	/* 0x29e8: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_29ef:
	/* 0x29ef: mov    BYTE PTR [rbx+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_29f6:
	/* 0x29f6: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_29fd:
	/* 0x29fd: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a00:
	/* 0x2a00: je     2f39 <perf_unwind_native+0x2f39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a00, 0x2f39, x86_l_2f39);
x86_l_2a06:
	/* 0x2a06: movabs rax,0xa656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926270227834400ULL);
x86_l_2a10:
	/* 0x2a10: mov    QWORD PTR [rsp+0x16],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_2a15:
	/* 0x2a15: movabs rax,0x66206c616e676973 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359000956843288947ULL);
x86_l_2a1f:
	/* 0x2a1f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a24:
	/* 0x2a24: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a29:
	/* 0x2a29: mov    esi,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_2a2e:
	/* 0x2a2e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a30:
	/* 0x2a30: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a32:
	/* 0x2a32: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a35:
	/* 0x2a35: call   2a3a <perf_unwind_native+0x2a3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2a3a:
	/* 0x2a3a: jmp    2f39 <perf_unwind_native+0x2f39> */
	X86_SIM_X86_JMP(0x2a3a, 0x2f39, x86_l_2f39);
x86_l_2a3f:
	/* 0x2a3f: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2a44:
	/* 0x2a44: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a47:
	/* 0x2a47: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a4c:
	/* 0x2a4c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a51:
	/* 0x2a51: movsxd rcx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2a54:
	/* 0x2a54: add    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a57:
	/* 0x2a57: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a5c:
	/* 0x2a5c: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2a5e:
	/* 0x2a5e: jns    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a5e, 0x2ce7, x86_l_2ce7);
x86_l_2a64:
	/* 0x2a64: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2a69:
	/* 0x2a69: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a73:
	/* 0x2a73: call   2a78 <perf_unwind_native+0x2a78> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a78:
	/* 0x2a78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a7b:
	/* 0x2a7b: je     2a99 <perf_unwind_native+0x2a99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a7b, 0x2a99, x86_l_2a99);
x86_l_2a7d:
	/* 0x2a7d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2a84:
	/* 0x2a84: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a87:
	/* 0x2a87: jne    33e3 <perf_unwind_native+0x33e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a87, 0x33e3, x86_l_33e3);
x86_l_2a8d:
	/* 0x2a8d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a8f:
	/* 0x2a8f: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a94:
	/* 0x2a94: jmp    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JMP(0x2a94, 0x2ce7, x86_l_2ce7);
x86_l_2a99:
	/* 0x2a99: shl    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_2a9d:
	/* 0x2a9d: and    r12d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_2aa1:
	/* 0x2aa1: add    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_2aa6:
	/* 0x2aa6: mov    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2aab:
	/* 0x2aab: jmp    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JMP(0x2aab, 0x2ce7, x86_l_2ce7);
x86_l_2ab0:
	/* 0x2ab0: movabs rax,0xa6425206f666e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387845742ULL);
x86_l_2aba:
	/* 0x2aba: mov    QWORD PTR [rsp+0x35],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_2abf:
	/* 0x2abf: movabs rax,0x6f666e49646e6977 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8027224647331113335ULL);
x86_l_2ac9:
	/* 0x2ac9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ace:
	/* 0x2ace: movabs rax,0x6e75202c78257830 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959303291813591088ULL);
x86_l_2ad8:
	/* 0x2ad8: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2add:
	/* 0x2add: movabs rax,0x20776f4c72646461 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2339460905569641569ULL);
x86_l_2ae7:
	/* 0x2ae7: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2aec:
	/* 0x2aec: movabs rax,0x202c642520786564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2318338018810291556ULL);
x86_l_2af6:
	/* 0x2af6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2afb:
	/* 0x2afb: movabs rax,0x6e692061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7955925819663869284ULL);
x86_l_2b05:
	/* 0x2b05: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b0a:
	/* 0x2b0a: mov    edx,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_2b0e:
	/* 0x2b0e: movzx  ecx,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2b13:
	/* 0x2b13: movzx  r8d,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_2b18:
	/* 0x2b18: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b1d:
	/* 0x2b1d: mov    esi,0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 45ULL);
x86_l_2b22:
	/* 0x2b22: call   2b27 <perf_unwind_native+0x2b27> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2b27:
	/* 0x2b27: jmp    2683 <perf_unwind_native+0x2683> */
	X86_SIM_X86_JMP(0x2b27, 0x2683, x86_l_2683);
x86_l_2b2c:
	/* 0x2b2c: movabs rax,0xa78323023252061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754408119914012769ULL);
x86_l_2b36:
	/* 0x2b36: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b3b:
	/* 0x2b3b: movabs rax,0x746c656420646567 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389191686598976871ULL);
x86_l_2b45:
	/* 0x2b45: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b4a:
	/* 0x2b4a: movabs rax,0x72656d202c642520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243114677922702624ULL);
x86_l_2b54:
	/* 0x2b54: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b59:
	/* 0x2b59: movabs rax,0x6666694472646441 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7378700782191010881ULL);
x86_l_2b63:
	/* 0x2b63: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b68:
	/* 0x2b68: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2b6d:
	/* 0x2b6d: movsxd rdx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2b70:
	/* 0x2b70: mov    r14,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_2b78:
	/* 0x2b78: movzx  ecx,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2b7d:
	/* 0x2b7d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b82:
	/* 0x2b82: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2b87:
	/* 0x2b87: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b8a:
	/* 0x2b8a: call   2b8f <perf_unwind_native+0x2b8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2b8f:
	/* 0x2b8f: movzx  eax,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2b94:
	/* 0x2b94: jmp    2755 <perf_unwind_native+0x2755> */
	X86_SIM_X86_JMP(0x2b94, 0x2755, x86_l_2755);
x86_l_2b99:
	/* 0x2b99: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_2ba3:
	/* 0x2ba3: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_2ba8:
	/* 0x2ba8: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_2bb2:
	/* 0x2bb2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2bb7:
	/* 0x2bb7: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_2bc1:
	/* 0x2bc1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2bc6:
	/* 0x2bc6: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_2bd0:
	/* 0x2bd0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2bd5:
	/* 0x2bd5: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_2bdf:
	/* 0x2bdf: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2be4:
	/* 0x2be4: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_2bee:
	/* 0x2bee: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bf3:
	/* 0x2bf3: mov    edx,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_2bfa:
	/* 0x2bfa: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bff:
	/* 0x2bff: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_2c04:
	/* 0x2c04: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c06:
	/* 0x2c06: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c09:
	/* 0x2c09: call   2c0e <perf_unwind_native+0x2c0e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2c0e:
	/* 0x2c0e: jmp    26f6 <perf_unwind_native+0x26f6> */
	X86_SIM_X86_JMP(0x2c0e, 0x26f6, x86_l_26f6);
x86_l_2c13:
	/* 0x2c13: movabs rax,0xa64253d61746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 748764383608597605ULL);
x86_l_2c1d:
	/* 0x2c1d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2c22:
	/* 0x2c22: movabs rax,0x44616663203a6863 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4927332043248527459ULL);
x86_l_2c2c:
	/* 0x2c2c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c31:
	/* 0x2c31: movabs rax,0x74616d2061746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8386103966981975141ULL);
x86_l_2c3b:
	/* 0x2c3b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c40:
	/* 0x2c40: movabs rax,0x642064656772654d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7214876989737559373ULL);
x86_l_2c4a:
	/* 0x2c4a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c4f:
	/* 0x2c4f: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2c54:
	/* 0x2c54: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2c58:
	/* 0x2c58: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c5d:
	/* 0x2c5d: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2c62:
	/* 0x2c62: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c64:
	/* 0x2c64: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c67:
	/* 0x2c67: call   2c6c <perf_unwind_native+0x2c6c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2c6c:
	/* 0x2c6c: jmp    2783 <perf_unwind_native+0x2783> */
	X86_SIM_X86_JMP(0x2c6c, 0x2783, x86_l_2783);
x86_l_2c71:
	/* 0x2c71: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_2c7b:
	/* 0x2c7b: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c80:
	/* 0x2c80: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_2c8a:
	/* 0x2c8a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c8f:
	/* 0x2c8f: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2c94:
	/* 0x2c94: and    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2c98:
	/* 0x2c98: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c9d:
	/* 0x2c9d: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2ca2:
	/* 0x2ca2: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ca5:
	/* 0x2ca5: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ca8:
	/* 0x2ca8: call   2cad <perf_unwind_native+0x2cad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2cad:
	/* 0x2cad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2caf:
	/* 0x2caf: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cb4:
	/* 0x2cb4: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_2cb8:
	/* 0x2cb8: jle    2920 <perf_unwind_native+0x2920> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2cb8, 0x2920, x86_l_2920);
x86_l_2cbe:
	/* 0x2cbe: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_2cc6:
	/* 0x2cc6: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2cca:
	/* 0x2cca: je     2cda <perf_unwind_native+0x2cda> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cca, 0x2cda, x86_l_2cda);
x86_l_2ccc:
	/* 0x2ccc: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_2cd4:
	/* 0x2cd4: cmp    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2cd8:
	/* 0x2cd8: jne    2ce7 <perf_unwind_native+0x2ce7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cd8, 0x2ce7, x86_l_2ce7);
x86_l_2cda:
	/* 0x2cda: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2cdf:
	/* 0x2cdf: add    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2ce2:
	/* 0x2ce2: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ce7:
	/* 0x2ce7: mov    rcx,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_2cef:
	/* 0x2cef: movzx  eax,BYTE PTR [rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2cf3:
	/* 0x2cf3: mov    r13d,DWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cf7:
	/* 0x2cf7: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2cfa:
	/* 0x2cfa: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2cfc:
	/* 0x2cfc: jns    2d04 <perf_unwind_native+0x2d04> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cfc, 0x2d04, x86_l_2d04);
x86_l_2cfe:
	/* 0x2cfe: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2d01:
	/* 0x2d01: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2d04:
	/* 0x2d04: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d06:
	/* 0x2d06: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_2d09:
	/* 0x2d09: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2d0c:
	/* 0x2d0c: jg     2d2e <perf_unwind_native+0x2d2e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d0c, 0x2d2e, x86_l_2d2e);
x86_l_2d0e:
	/* 0x2d0e: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d13:
	/* 0x2d13: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2d16:
	/* 0x2d16: je     2d9a <perf_unwind_native+0x2d9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d16, 0x2d9a, x86_l_2d9a);
x86_l_2d1c:
	/* 0x2d1c: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2d24:
	/* 0x2d24: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2d27:
	/* 0x2d27: je     2d97 <perf_unwind_native+0x2d97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d27, 0x2d97, x86_l_2d97);
x86_l_2d29:
	/* 0x2d29: jmp    2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JMP(0x2d29, 0x2ed8, x86_l_2ed8);
x86_l_2d2e:
	/* 0x2d2e: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2d31:
	/* 0x2d31: je     2d92 <perf_unwind_native+0x2d92> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d31, 0x2d92, x86_l_2d92);
x86_l_2d33:
	/* 0x2d33: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2d36:
	/* 0x2d36: jne    2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d36, 0x2ed8, x86_l_2ed8);
x86_l_2d3c:
	/* 0x2d3c: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2d3f:
	/* 0x2d3f: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_2d41:
	/* 0x2d41: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2d44:
	/* 0x2d44: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2d47:
	/* 0x2d47: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2d4c:
	/* 0x2d4c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2d53:
	/* 0x2d53: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d56:
	/* 0x2d56: jne    2e55 <perf_unwind_native+0x2e55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d56, 0x2e55, x86_l_2e55);
x86_l_2d5c:
	/* 0x2d5c: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2d60:
	/* 0x2d60: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_2d64:
	/* 0x2d64: jg     2e9b <perf_unwind_native+0x2e9b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d64, 0x2e9b, x86_l_2e9b);
x86_l_2d6a:
	/* 0x2d6a: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_2d72:
	/* 0x2d72: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2d75:
	/* 0x2d75: je     2eb7 <perf_unwind_native+0x2eb7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d75, 0x2eb7, x86_l_2eb7);
x86_l_2d7b:
	/* 0x2d7b: cmp    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2d7f:
	/* 0x2d7f: jne    2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d7f, 0x2ed8, x86_l_2ed8);
x86_l_2d85:
	/* 0x2d85: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_2d8d:
	/* 0x2d8d: jmp    2eb7 <perf_unwind_native+0x2eb7> */
	X86_SIM_X86_JMP(0x2d8d, 0x2eb7, x86_l_2eb7);
x86_l_2d92:
	/* 0x2d92: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2d97:
	/* 0x2d97: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d9a:
	/* 0x2d9a: movsxd r12,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2d9d:
	/* 0x2d9d: add    r12,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2da0:
	/* 0x2da0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2da2:
	/* 0x2da2: jns    2ebf <perf_unwind_native+0x2ebf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2da2, 0x2ebf, x86_l_2ebf);
x86_l_2da8:
	/* 0x2da8: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2dad:
	/* 0x2dad: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2db2:
	/* 0x2db2: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2db5:
	/* 0x2db5: call   2dba <perf_unwind_native+0x2dba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2dba:
	/* 0x2dba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dbd:
	/* 0x2dbd: je     2e42 <perf_unwind_native+0x2e42> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dbd, 0x2e42, x86_l_2e42);
x86_l_2dc3:
	/* 0x2dc3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2dca:
	/* 0x2dca: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dcd:
	/* 0x2dcd: je     2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dcd, 0x2ed8, x86_l_2ed8);
x86_l_2dd3:
	/* 0x2dd3: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_2ddd:
	/* 0x2ddd: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2de2:
	/* 0x2de2: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_2dec:
	/* 0x2dec: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2df1:
	/* 0x2df1: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_2dfb:
	/* 0x2dfb: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e00:
	/* 0x2e00: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_2e0a:
	/* 0x2e0a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2e0f:
	/* 0x2e0f: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_2e19:
	/* 0x2e19: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e1e:
	/* 0x2e1e: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_2e26:
	/* 0x2e26: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e2b:
	/* 0x2e2b: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_2e30:
	/* 0x2e30: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2e33:
	/* 0x2e33: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e35:
	/* 0x2e35: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e38:
	/* 0x2e38: call   2e3d <perf_unwind_native+0x2e3d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2e3d:
	/* 0x2e3d: jmp    2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JMP(0x2e3d, 0x2ed8, x86_l_2ed8);
x86_l_2e42:
	/* 0x2e42: lea    r12d,[r13*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 0ULL);
x86_l_2e4a:
	/* 0x2e4a: and    r12d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_2e4e:
	/* 0x2e4e: add    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_2e53:
	/* 0x2e53: jmp    2ebf <perf_unwind_native+0x2ebf> */
	X86_SIM_X86_JMP(0x2e53, 0x2ebf, x86_l_2ebf);
x86_l_2e55:
	/* 0x2e55: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_2e5f:
	/* 0x2e5f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2e64:
	/* 0x2e64: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_2e6e:
	/* 0x2e6e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e73:
	/* 0x2e73: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2e78:
	/* 0x2e78: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2e7c:
	/* 0x2e7c: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e81:
	/* 0x2e81: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2e86:
	/* 0x2e86: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2e89:
	/* 0x2e89: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e8c:
	/* 0x2e8c: call   2e91 <perf_unwind_native+0x2e91> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2e91:
	/* 0x2e91: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_2e95:
	/* 0x2e95: jle    2d6a <perf_unwind_native+0x2d6a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2e95, 0x2d6a, x86_l_2d6a);
x86_l_2e9b:
	/* 0x2e9b: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_2ea3:
	/* 0x2ea3: cmp    r13d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2ea7:
	/* 0x2ea7: je     2eb7 <perf_unwind_native+0x2eb7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ea7, 0x2eb7, x86_l_2eb7);
x86_l_2ea9:
	/* 0x2ea9: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_2eb1:
	/* 0x2eb1: cmp    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2eb5:
	/* 0x2eb5: jne    2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2eb5, 0x2ed8, x86_l_2ed8);
x86_l_2eb7:
	/* 0x2eb7: mov    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2ebc:
	/* 0x2ebc: add    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2ebf:
	/* 0x2ebf: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ec2:
	/* 0x2ec2: je     2ed8 <perf_unwind_native+0x2ed8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ec2, 0x2ed8, x86_l_2ed8);
x86_l_2ec4:
	/* 0x2ec4: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2ec9:
	/* 0x2ec9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2ece:
	/* 0x2ece: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ed1:
	/* 0x2ed1: call   2ed6 <perf_unwind_native+0x2ed6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ed6:
	/* 0x2ed6: jmp    2ef1 <perf_unwind_native+0x2ef1> */
	X86_SIM_X86_JMP(0x2ed6, 0x2ef1, x86_l_2ef1);
x86_l_2ed8:
	/* 0x2ed8: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_2ee0:
	/* 0x2ee0: cmp    BYTE PTR [rax],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_2ee3:
	/* 0x2ee3: jne    2ef1 <perf_unwind_native+0x2ef1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ee3, 0x2ef1, x86_l_2ef1);
x86_l_2ee5:
	/* 0x2ee5: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2eea:
	/* 0x2eea: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef1:
	/* 0x2ef1: cmp    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2ef7:
	/* 0x2ef7: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2efc:
	/* 0x2efc: je     1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2efc, 0x1522, x86_l_1522);
x86_l_2f02:
	/* 0x2f02: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f07:
	/* 0x2f07: lea    rdx,[rax-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_2f0b:
	/* 0x2f0b: mov    rdi,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_2f13:
	/* 0x2f13: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f18:
	/* 0x2f18: call   2f1d <perf_unwind_native+0x2f1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f1d:
	/* 0x2f1d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f20:
	/* 0x2f20: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f20, 0x1522, x86_l_1522);
x86_l_2f26:
	/* 0x2f26: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f2b:
	/* 0x2f2b: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2f32:
	/* 0x2f32: mov    BYTE PTR [rbx+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_2f39:
	/* 0x2f39: mov    DWORD PTR [rsp+0x70],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337158ULL);
x86_l_2f41:
	/* 0x2f41: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2f48:
	/* 0x2f48: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2f4d:
	/* 0x2f4d: call   2f52 <perf_unwind_native+0x2f52> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f52:
	/* 0x2f52: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f55:
	/* 0x2f55: je     2ff3 <perf_unwind_native+0x2ff3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f55, 0x2ff3, x86_l_2ff3);
x86_l_2f5b:
	/* 0x2f5b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2f5e:
	/* 0x2f5e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f60:
	/* 0x2f60: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2f67:
	/* 0x2f67: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f6a:
	/* 0x2f6a: je     3005 <perf_unwind_native+0x3005> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f6a, 0x3005, x86_l_3005);
x86_l_2f70:
	/* 0x2f70: movabs rax,0xa786c6c25203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280058ULL);
x86_l_2f7a:
	/* 0x2f7a: mov    QWORD PTR [rsp+0xa5],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_2f82:
	/* 0x2f82: movabs rax,0x25203a706620786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675202433082226796ULL);
x86_l_2f8c:
	/* 0x2f8c: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2f94:
	/* 0x2f94: movabs rax,0x6c25203a70732078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165601296504ULL);
x86_l_2f9e:
	/* 0x2f9e: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2fa6:
	/* 0x2fa6: movabs rax,0x6c6c25203a637020 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660273929744416ULL);
x86_l_2fb0:
	/* 0x2fb0: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2fb8:
	/* 0x2fb8: mov    rax,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_2fc0:
	/* 0x2fc0: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc3:
	/* 0x2fc3: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2fcb:
	/* 0x2fcb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fce:
	/* 0x2fce: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2fd3:
	/* 0x2fd3: mov    r8,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd6:
	/* 0x2fd6: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2fde:
	/* 0x2fde: mov    esi,0x1d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_2fe3:
	/* 0x2fe3: call   2fe8 <perf_unwind_native+0x2fe8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_2fe8:
	/* 0x2fe8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2fef:
	/* 0x2fef: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff1:
	/* 0x2ff1: jmp    3005 <perf_unwind_native+0x3005> */
	X86_SIM_X86_JMP(0x2ff1, 0x3005, x86_l_3005);
x86_l_2ff3:
	/* 0x2ff3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_2ffa:
	/* 0x2ffa: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ffd:
	/* 0x2ffd: jne    335a <perf_unwind_native+0x335a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ffd, 0x335a, x86_l_335a);
x86_l_3003:
	/* 0x3003: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3005:
	/* 0x3005: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_300d:
	/* 0x300d: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3010:
	/* 0x3010: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3013:
	/* 0x3013: je     696b <perf_unwind_native+0x696b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3013, 0x696b, x86_l_696b);
x86_l_3019:
	/* 0x3019: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_301b:
	/* 0x301b: jne    30bc <perf_unwind_native+0x30bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x301b, 0x30bc, x86_l_30bc);
x86_l_3021:
	/* 0x3021: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_302b:
	/* 0x302b: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_302e:
	/* 0x302e: jbe    3167 <perf_unwind_native+0x3167> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x302e, 0x3167, x86_l_3167);
x86_l_3034:
	/* 0x3034: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3039:
	/* 0x3039: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3040:
	/* 0x3040: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3045:
	/* 0x3045: je     165f <perf_unwind_native+0x165f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3045, 0x165f, x86_l_165f);
x86_l_304b:
	/* 0x304b: movabs rax,0x7373657264646120 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8319104478668415264ULL);
x86_l_3055:
	/* 0x3055: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_305d:
	/* 0x305d: movabs rax,0x6c656e72656b2061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7810770566350839905ULL);
x86_l_3067:
	/* 0x3067: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_306f:
	/* 0x306f: movabs rax,0x20736920786c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338328219715642656ULL);
x86_l_3079:
	/* 0x3079: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3081:
	/* 0x3081: movabs rax,0x65756c6176204350 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310868735955321680ULL);
x86_l_308b:
	/* 0x308b: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3093:
	/* 0x3093: mov    WORD PTR [rsp+0xb0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 755914244106ULL);
x86_l_309d:
	/* 0x309d: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_30a5:
	/* 0x30a5: mov    esi,0x22 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_30aa:
	/* 0x30aa: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_30ad:
	/* 0x30ad: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30af:
	/* 0x30af: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30b2:
	/* 0x30b2: call   30b7 <perf_unwind_native+0x30b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_30b7:
	/* 0x30b7: jmp    165f <perf_unwind_native+0x165f> */
	X86_SIM_X86_JMP(0x30b7, 0x165f, x86_l_165f);
x86_l_30bc:
	/* 0x30bc: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_30c6:
	/* 0x30c6: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_30ce:
	/* 0x30ce: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_30d8:
	/* 0x30d8: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_30e0:
	/* 0x30e0: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_30ea:
	/* 0x30ea: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_30f2:
	/* 0x30f2: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_30fc:
	/* 0x30fc: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3104:
	/* 0x3104: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_310e:
	/* 0x310e: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3116:
	/* 0x3116: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_3120:
	/* 0x3120: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3128:
	/* 0x3128: mov    BYTE PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_3130:
	/* 0x3130: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3136:
	/* 0x3136: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_313e:
	/* 0x313e: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_3143:
	/* 0x3143: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3145:
	/* 0x3145: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3148:
	/* 0x3148: call   314d <perf_unwind_native+0x314d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_314d:
	/* 0x314d: mov    r13,QWORD PTR [rbx+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3154:
	/* 0x3154: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_315e:
	/* 0x315e: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3161:
	/* 0x3161: ja     3034 <perf_unwind_native+0x3034> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3161, 0x3034, x86_l_3034);
x86_l_3167:
	/* 0x3167: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_316e:
	/* 0x316e: jae    31f2 <perf_unwind_native+0x31f2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x316e, 0x31f2, x86_l_31f2);
x86_l_3174:
	/* 0x3174: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3179:
	/* 0x3179: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3180:
	/* 0x3180: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3185:
	/* 0x3185: je     17a6 <perf_unwind_native+0x17a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3185, 0x17a6, x86_l_17a6);
x86_l_318b:
	/* 0x318b: movabs rax,0xa676e69726f6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2928473680277358ULL);
x86_l_3195:
	/* 0x3195: mov    QWORD PTR [rsp+0xa6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_319d:
	/* 0x319d: movabs rax,0x6f6e6769202c786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8029468886857185388ULL);
x86_l_31a7:
	/* 0x31a7: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_31af:
	/* 0x31af: movabs rax,0x252065756c617620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675249733661980192ULL);
x86_l_31b9:
	/* 0x31b9: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_31c1:
	/* 0x31c1: movabs rax,0x6370206c6c616d73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7165262657193340275ULL);
x86_l_31cb:
	/* 0x31cb: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_31d3:
	/* 0x31d3: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_31db:
	/* 0x31db: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_31e0:
	/* 0x31e0: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_31e3:
	/* 0x31e3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31e5:
	/* 0x31e5: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31e8:
	/* 0x31e8: call   31ed <perf_unwind_native+0x31ed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_31ed:
	/* 0x31ed: jmp    17a6 <perf_unwind_native+0x17a6> */
	X86_SIM_X86_JMP(0x31ed, 0x17a6, x86_l_17a6);
x86_l_31f2:
	/* 0x31f2: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f4:
	/* 0x31f4: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_31fc:
	/* 0x31fc: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_3202:
	/* 0x3202: movbe  QWORD PTR [rsp+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_3209:
	/* 0x3209: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_3210:
	/* 0x3210: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3215:
	/* 0x3215: call   321a <perf_unwind_native+0x321a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_321a:
	/* 0x321a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_321d:
	/* 0x321d: je     6a1d <perf_unwind_native+0x6a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x321d, 0x6a1d, x86_l_6a1d);
x86_l_3223:
	/* 0x3223: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3227:
	/* 0x3227: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_322a:
	/* 0x322a: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_3234:
	/* 0x3234: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3237:
	/* 0x3237: mov    QWORD PTR [rbx+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_323e:
	/* 0x323e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3241:
	/* 0x3241: mov    QWORD PTR [rbx+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3248:
	/* 0x3248: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_324c:
	/* 0x324c: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_324f:
	/* 0x324f: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_3252:
	/* 0x3252: mov    QWORD PTR [rbx+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3259:
	/* 0x3259: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3260:
	/* 0x3260: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3263:
	/* 0x3263: jne    3454 <perf_unwind_native+0x3454> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3263, 0x3454, x86_l_3454);
x86_l_3269:
	/* 0x3269: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_326d:
	/* 0x326d: jne    362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x326d, 0x362b, x86_l_362b);
x86_l_3273:
	/* 0x3273: mov    rax,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_327a:
	/* 0x327a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_327f:
	/* 0x327f: mov    r14,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3286:
	/* 0x3286: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_328d:
	/* 0x328d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3292:
	/* 0x3292: call   3297 <perf_unwind_native+0x3297> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3297:
	/* 0x3297: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_329d:
	/* 0x329d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32a0:
	/* 0x32a0: je     362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32a0, 0x362b, x86_l_362b);
x86_l_32a6:
	/* 0x32a6: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32a9:
	/* 0x32a9: cmp    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32ac:
	/* 0x32ac: ja     32b4 <perf_unwind_native+0x32b4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x32ac, 0x32b4, x86_l_32b4);
x86_l_32ae:
	/* 0x32ae: cmp    QWORD PTR [r13+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32b2:
	/* 0x32b2: jae    32c8 <perf_unwind_native+0x32c8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x32b2, 0x32c8, x86_l_32c8);
x86_l_32b4:
	/* 0x32b4: cmp    QWORD PTR [r13+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32b8:
	/* 0x32b8: ja     362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x32b8, 0x362b, x86_l_362b);
x86_l_32be:
	/* 0x32be: cmp    QWORD PTR [r13+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32c2:
	/* 0x32c2: jb     362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32c2, 0x362b, x86_l_362b);
x86_l_32c8:
	/* 0x32c8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_32cf:
	/* 0x32cf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d2:
	/* 0x32d2: jne    357c <perf_unwind_native+0x357c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32d2, 0x357c, x86_l_357c);
x86_l_32d8:
	/* 0x32d8: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_32de:
	/* 0x32de: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32e2:
	/* 0x32e2: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_32e5:
	/* 0x32e5: jae    35f3 <perf_unwind_native+0x35f3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x32e5, 0x35f3, x86_l_35f3);
x86_l_32eb:
	/* 0x32eb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_32f2:
	/* 0x32f2: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32f5:
	/* 0x32f5: je     362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f5, 0x362b, x86_l_362b);
x86_l_32fb:
	/* 0x32fb: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_3305:
	/* 0x3305: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_330d:
	/* 0x330d: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_3317:
	/* 0x3317: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_331f:
	/* 0x331f: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_3329:
	/* 0x3329: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3331:
	/* 0x3331: mov    DWORD PTR [rsp+0xa7],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 717260219758ULL);
x86_l_333c:
	/* 0x333c: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3344:
	/* 0x3344: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_3349:
	/* 0x3349: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_334b:
	/* 0x334b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_334d:
	/* 0x334d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3350:
	/* 0x3350: call   3355 <perf_unwind_native+0x3355> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3355:
	/* 0x3355: jmp    362b <perf_unwind_native+0x362b> */
	X86_SIM_X86_JMP(0x3355, 0x362b, x86_l_362b);
x86_l_335a:
	/* 0x335a: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3364:
	/* 0x3364: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_3369:
	/* 0x3369: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3373:
	/* 0x3373: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3378:
	/* 0x3378: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3382:
	/* 0x3382: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3387:
	/* 0x3387: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3391:
	/* 0x3391: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3396:
	/* 0x3396: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_33a0:
	/* 0x33a0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33a5:
	/* 0x33a5: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_33af:
	/* 0x33af: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33b4:
	/* 0x33b4: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_33b8:
	/* 0x33b8: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33bd:
	/* 0x33bd: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_33c2:
	/* 0x33c2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33c4:
	/* 0x33c4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33c7:
	/* 0x33c7: call   33cc <perf_unwind_native+0x33cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_33cc:
	/* 0x33cc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33ce:
	/* 0x33ce: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_33d5:
	/* 0x33d5: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33d8:
	/* 0x33d8: je     3005 <perf_unwind_native+0x3005> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33d8, 0x3005, x86_l_3005);
x86_l_33de:
	/* 0x33de: jmp    2f70 <perf_unwind_native+0x2f70> */
	X86_SIM_X86_JMP(0x33de, 0x2f70, x86_l_2f70);
x86_l_33e3:
	/* 0x33e3: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_33ed:
	/* 0x33ed: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33f2:
	/* 0x33f2: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_33fc:
	/* 0x33fc: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3401:
	/* 0x3401: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_340b:
	/* 0x340b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3410:
	/* 0x3410: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_341a:
	/* 0x341a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_341f:
	/* 0x341f: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_3429:
	/* 0x3429: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_342e:
	/* 0x342e: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_3436:
	/* 0x3436: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_343b:
	/* 0x343b: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_3440:
	/* 0x3440: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3445:
	/* 0x3445: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3447:
	/* 0x3447: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_344a:
	/* 0x344a: call   344f <perf_unwind_native+0x344f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_344f:
	/* 0x344f: jmp    2a8d <perf_unwind_native+0x2a8d> */
	X86_SIM_X86_JMP(0x344f, 0x2a8d, x86_l_2a8d);
x86_l_3454:
	/* 0x3454: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_345e:
	/* 0x345e: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_3466:
	/* 0x3466: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_3470:
	/* 0x3470: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3478:
	/* 0x3478: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_3482:
	/* 0x3482: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_348a:
	/* 0x348a: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_3494:
	/* 0x3494: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_349c:
	/* 0x349c: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_34a6:
	/* 0x34a6: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_34ae:
	/* 0x34ae: movabs r14,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_34b8:
	/* 0x34b8: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_34c0:
	/* 0x34c0: mov    WORD PTR [rsp+0xc0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 824633720842ULL);
x86_l_34ca:
	/* 0x34ca: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_34d2:
	/* 0x34d2: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_34d7:
	/* 0x34d7: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_34da:
	/* 0x34da: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_34dd:
	/* 0x34dd: call   34e2 <perf_unwind_native+0x34e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_34e2:
	/* 0x34e2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_34e9:
	/* 0x34e9: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34ec:
	/* 0x34ec: je     3269 <perf_unwind_native+0x3269> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34ec, 0x3269, x86_l_3269);
x86_l_34f2:
	/* 0x34f2: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_34fc:
	/* 0x34fc: mov    QWORD PTR [rsp+0xb7],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 183ULL);
x86_l_3504:
	/* 0x3504: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_350e:
	/* 0x350e: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3516:
	/* 0x3516: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_3520:
	/* 0x3520: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3528:
	/* 0x3528: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_3532:
	/* 0x3532: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_353a:
	/* 0x353a: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_3544:
	/* 0x3544: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_354c:
	/* 0x354c: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3554:
	/* 0x3554: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_355b:
	/* 0x355b: mov    rdx,QWORD PTR [rbx+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_3562:
	/* 0x3562: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_356a:
	/* 0x356a: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_356f:
	/* 0x356f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3572:
	/* 0x3572: call   3577 <perf_unwind_native+0x3577> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3577:
	/* 0x3577: jmp    3269 <perf_unwind_native+0x3269> */
	X86_SIM_X86_JMP(0x3577, 0x3269, x86_l_3269);
x86_l_357c:
	/* 0x357c: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_3586:
	/* 0x3586: mov    QWORD PTR [rsp+0xa6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_358e:
	/* 0x358e: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_3598:
	/* 0x3598: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_35a0:
	/* 0x35a0: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_35aa:
	/* 0x35aa: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_35b2:
	/* 0x35b2: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_35bc:
	/* 0x35bc: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_35c4:
	/* 0x35c4: movzx  edx,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_35c9:
	/* 0x35c9: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_35d1:
	/* 0x35d1: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_35d6:
	/* 0x35d6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35d8:
	/* 0x35d8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35db:
	/* 0x35db: call   35e0 <perf_unwind_native+0x35e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_35e0:
	/* 0x35e0: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_35e6:
	/* 0x35e6: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_35ea:
	/* 0x35ea: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_35ed:
	/* 0x35ed: jb     32eb <perf_unwind_native+0x32eb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x35ed, 0x32eb, x86_l_32eb);
x86_l_35f3:
	/* 0x35f3: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_35fb:
	/* 0x35fb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_3602:
	/* 0x3602: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3607:
	/* 0x3607: call   360c <perf_unwind_native+0x360c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_360c:
	/* 0x360c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_360f:
	/* 0x360f: je     3616 <perf_unwind_native+0x3616> */
	X86_SIM_X86_JCC(X86_CC_E, 0x360f, 0x3616, x86_l_3616);
x86_l_3611:
	/* 0x3611: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3614:
	/* 0x3614: jmp    3626 <perf_unwind_native+0x3626> */
	X86_SIM_X86_JMP(0x3614, 0x3626, x86_l_3626);
x86_l_3616:
	/* 0x3616: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_361d:
	/* 0x361d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3620:
	/* 0x3620: jne    3d6a <perf_unwind_native+0x3d6a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3620, 0x3d6a, x86_l_3d6a);
x86_l_3626:
	/* 0x3626: movzx  r12d,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_362b:
	/* 0x362b: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_362f:
	/* 0x362f: jne    6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x362f, 0x6e79, x86_l_6e79);
x86_l_3635:
	/* 0x3635: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_363c:
	/* 0x363c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_363f:
	/* 0x363f: jne    3ac1 <perf_unwind_native+0x3ac1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x363f, 0x3ac1, x86_l_3ac1);
x86_l_3645:
	/* 0x3645: mov    DWORD PTR [rsp+0x10],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476741ULL);
x86_l_364d:
	/* 0x364d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_3654:
	/* 0x3654: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3659:
	/* 0x3659: call   365e <perf_unwind_native+0x365e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_365e:
	/* 0x365e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3661:
	/* 0x3661: je     3708 <perf_unwind_native+0x3708> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3661, 0x3708, x86_l_3708);
x86_l_3667:
	/* 0x3667: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_366a:
	/* 0x366a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3671:
	/* 0x3671: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3674:
	/* 0x3674: je     3718 <perf_unwind_native+0x3718> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3674, 0x3718, x86_l_3718);
x86_l_367a:
	/* 0x367a: movabs rax,0x63617473206e6f20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7161132920309968672ULL);
x86_l_3684:
	/* 0x3684: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_368c:
	/* 0x368c: movabs rax,0x7525206e6f697469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8441188735263536233ULL);
x86_l_3696:
	/* 0x3696: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_369e:
	/* 0x369e: movabs rax,0x736f70206f742078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8317990321387741304ULL);
x86_l_36a8:
	/* 0x36a8: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_36b0:
	/* 0x36b0: movabs rax,0x6c6c2520786c6c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274970520613ULL);
x86_l_36ba:
	/* 0x36ba: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_36c2:
	/* 0x36c2: movabs rax,0x20676e6968737550 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334956330817910096ULL);
x86_l_36cc:
	/* 0x36cc: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_36d4:
	/* 0x36d4: mov    DWORD PTR [rsp+0xb7],0xa6b63 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 785979698019ULL);
x86_l_36df:
	/* 0x36df: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_36e6:
	/* 0x36e6: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_36ed:
	/* 0x36ed: mov    r8d,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_36f4:
	/* 0x36f4: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_36fc:
	/* 0x36fc: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_3701:
	/* 0x3701: call   3706 <perf_unwind_native+0x3706> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3706:
	/* 0x3706: jmp    3718 <perf_unwind_native+0x3718> */
	X86_SIM_X86_JMP(0x3706, 0x3718, x86_l_3718);
x86_l_3708:
	/* 0x3708: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_370f:
	/* 0x370f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3712:
	/* 0x3712: jne    3bc4 <perf_unwind_native+0x3bc4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3712, 0x3bc4, x86_l_3bc4);
x86_l_3718:
	/* 0x3718: mov    eax,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_371e:
	/* 0x371e: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_3722:
	/* 0x3722: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3727:
	/* 0x3727: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_372e:
	/* 0x372e: ja     12d <perf_unwind_native+0x12d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x372e, 0x12d, x86_l_12d);
x86_l_3734:
	/* 0x3734: movzx  ecx,BYTE PTR [rbx+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_373b:
	/* 0x373b: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3742:
	/* 0x3742: mov    rsi,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3749:
	/* 0x3749: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_374c:
	/* 0x374c: mov    DWORD PTR [rbx+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3752:
	/* 0x3752: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_3756:
	/* 0x3756: mov    QWORD PTR [rbx+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_375e:
	/* 0x375e: mov    QWORD PTR [rbx+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_3766:
	/* 0x3766: mov    BYTE PTR [rbx+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_376e:
	/* 0x376e: mov    BYTE PTR [rbx+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_3775:
	/* 0x3775: mov    DWORD PTR [rbx+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_3780:
	/* 0x3780: mov    WORD PTR [rbx+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_378a:
	/* 0x378a: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_3792:
	/* 0x3792: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_3799:
	/* 0x3799: mov    QWORD PTR [rsp+0x150],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_37a1:
	/* 0x37a1: mov    QWORD PTR [rsp+0x70],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_37a6:
	/* 0x37a6: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_37ad:
	/* 0x37ad: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_37b0:
	/* 0x37b0: and    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709486080ULL);
x86_l_37b6:
	/* 0x37b6: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_37bb:
	/* 0x37bb: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37c0:
	/* 0x37c0: jne    3b6c <perf_unwind_native+0x3b6c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37c0, 0x3b6c, x86_l_3b6c);
x86_l_37c6:
	/* 0x37c6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_37cd:
	/* 0x37cd: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_37d2:
	/* 0x37d2: call   37d7 <perf_unwind_native+0x37d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_37d7:
	/* 0x37d7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37da:
	/* 0x37da: je     5100 <perf_unwind_native+0x5100> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37da, 0x5100, x86_l_5100);
x86_l_37e0:
	/* 0x37e0: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37e3:
	/* 0x37e3: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_37e7:
	/* 0x37e7: movzx  ecx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_37ea:
	/* 0x37ea: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_37ed:
	/* 0x37ed: jg     381b <perf_unwind_native+0x381b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x37ed, 0x381b, x86_l_381b);
x86_l_37ef:
	/* 0x37ef: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_37f2:
	/* 0x37f2: jg     3847 <perf_unwind_native+0x3847> */
	X86_SIM_X86_JCC(X86_CC_G, 0x37f2, 0x3847, x86_l_3847);
x86_l_37f4:
	/* 0x37f4: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_37f7:
	/* 0x37f7: jg     388d <perf_unwind_native+0x388d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x37f7, 0x388d, x86_l_388d);
x86_l_37fd:
	/* 0x37fd: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3800:
	/* 0x3800: je     38f0 <perf_unwind_native+0x38f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3800, 0x38f0, x86_l_38f0);
x86_l_3806:
	/* 0x3806: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_3809:
	/* 0x3809: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3809, 0x5276, x86_l_5276);
x86_l_380f:
	/* 0x380f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas));
x86_l_3816:
	/* 0x3816: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3816, 0x3936, x86_l_3936);
x86_l_381b:
	/* 0x381b: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_381e:
	/* 0x381e: jg     386a <perf_unwind_native+0x386a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x381e, 0x386a, x86_l_386a);
x86_l_3820:
	/* 0x3820: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_3823:
	/* 0x3823: jg     38ab <perf_unwind_native+0x38ab> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3823, 0x38ab, x86_l_38ab);
x86_l_3829:
	/* 0x3829: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_382c:
	/* 0x382c: je     38f9 <perf_unwind_native+0x38f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x382c, 0x38f9, x86_l_38f9);
x86_l_3832:
	/* 0x3832: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_3835:
	/* 0x3835: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3835, 0x5276, x86_l_5276);
x86_l_383b:
	/* 0x383b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas));
x86_l_3842:
	/* 0x3842: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3842, 0x3936, x86_l_3936);
x86_l_3847:
	/* 0x3847: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_384a:
	/* 0x384a: jg     38c2 <perf_unwind_native+0x38c2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x384a, 0x38c2, x86_l_38c2);
x86_l_384c:
	/* 0x384c: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_384f:
	/* 0x384f: je     3902 <perf_unwind_native+0x3902> */
	X86_SIM_X86_JCC(X86_CC_E, 0x384f, 0x3902, x86_l_3902);
x86_l_3855:
	/* 0x3855: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_3858:
	/* 0x3858: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3858, 0x5276, x86_l_5276);
x86_l_385e:
	/* 0x385e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas));
x86_l_3865:
	/* 0x3865: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3865, 0x3936, x86_l_3936);
x86_l_386a:
	/* 0x386a: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_386d:
	/* 0x386d: jg     38d9 <perf_unwind_native+0x38d9> */
	X86_SIM_X86_JCC(X86_CC_G, 0x386d, 0x38d9, x86_l_38d9);
x86_l_386f:
	/* 0x386f: cmp    ecx,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_3872:
	/* 0x3872: je     390b <perf_unwind_native+0x390b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3872, 0x390b, x86_l_390b);
x86_l_3878:
	/* 0x3878: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_387b:
	/* 0x387b: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x387b, 0x5276, x86_l_5276);
x86_l_3881:
	/* 0x3881: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas));
x86_l_3888:
	/* 0x3888: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3888, 0x3936, x86_l_3936);
x86_l_388d:
	/* 0x388d: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_3890:
	/* 0x3890: je     3914 <perf_unwind_native+0x3914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3890, 0x3914, x86_l_3914);
x86_l_3896:
	/* 0x3896: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_3899:
	/* 0x3899: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3899, 0x5276, x86_l_5276);
x86_l_389f:
	/* 0x389f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas));
x86_l_38a6:
	/* 0x38a6: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x38a6, 0x3936, x86_l_3936);
x86_l_38ab:
	/* 0x38ab: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_38ae:
	/* 0x38ae: je     391d <perf_unwind_native+0x391d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38ae, 0x391d, x86_l_391d);
x86_l_38b0:
	/* 0x38b0: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_38b3:
	/* 0x38b3: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38b3, 0x5276, x86_l_5276);
x86_l_38b9:
	/* 0x38b9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas));
x86_l_38c0:
	/* 0x38c0: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x38c0, 0x3936, x86_l_3936);
x86_l_38c2:
	/* 0x38c2: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_38c5:
	/* 0x38c5: je     3926 <perf_unwind_native+0x3926> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38c5, 0x3926, x86_l_3926);
x86_l_38c7:
	/* 0x38c7: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_38ca:
	/* 0x38ca: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38ca, 0x5276, x86_l_5276);
x86_l_38d0:
	/* 0x38d0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas));
x86_l_38d7:
	/* 0x38d7: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x38d7, 0x3936, x86_l_3936);
x86_l_38d9:
	/* 0x38d9: cmp    ecx,0x16 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_38dc:
	/* 0x38dc: je     392f <perf_unwind_native+0x392f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38dc, 0x392f, x86_l_392f);
x86_l_38de:
	/* 0x38de: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_38e1:
	/* 0x38e1: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38e1, 0x5276, x86_l_5276);
x86_l_38e7:
	/* 0x38e7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas));
x86_l_38ee:
	/* 0x38ee: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x38ee, 0x3936, x86_l_3936);
x86_l_38f0:
	/* 0x38f0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas));
x86_l_38f7:
	/* 0x38f7: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x38f7, 0x3936, x86_l_3936);
x86_l_38f9:
	/* 0x38f9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas));
x86_l_3900:
	/* 0x3900: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3900, 0x3936, x86_l_3936);
x86_l_3902:
	/* 0x3902: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas));
x86_l_3909:
	/* 0x3909: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3909, 0x3936, x86_l_3936);
x86_l_390b:
	/* 0x390b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas));
x86_l_3912:
	/* 0x3912: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3912, 0x3936, x86_l_3936);
x86_l_3914:
	/* 0x3914: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas));
x86_l_391b:
	/* 0x391b: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x391b, 0x3936, x86_l_3936);
x86_l_391d:
	/* 0x391d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas));
x86_l_3924:
	/* 0x3924: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x3924, 0x3936, x86_l_3936);
x86_l_3926:
	/* 0x3926: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas));
x86_l_392d:
	/* 0x392d: jmp    3936 <perf_unwind_native+0x3936> */
	X86_SIM_X86_JMP(0x392d, 0x3936, x86_l_3936);
x86_l_392f:
	/* 0x392f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas));
x86_l_3936:
	/* 0x3936: lea    rsi,[rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_393e:
	/* 0x393e: call   3943 <perf_unwind_native+0x3943> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3943:
	/* 0x3943: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3946:
	/* 0x3946: je     53f1 <perf_unwind_native+0x53f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3946, 0x53f1, x86_l_53f1);
x86_l_394c:
	/* 0x394c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_394f:
	/* 0x394f: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3953:
	/* 0x3953: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_3958:
	/* 0x3958: mov    rax,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_395f:
	/* 0x395f: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3964:
	/* 0x3964: movzx  eax,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_396a:
	/* 0x396a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_396c:
	/* 0x396c: je     4012 <perf_unwind_native+0x4012> */
	X86_SIM_X86_JCC(X86_CC_E, 0x396c, 0x4012, x86_l_4012);
x86_l_3972:
	/* 0x3972: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3975:
	/* 0x3975: add    r14d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_3978:
	/* 0x3978: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_397f:
	/* 0x397f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3982:
	/* 0x3982: jne    3ca8 <perf_unwind_native+0x3ca8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3982, 0x3ca8, x86_l_3ca8);
x86_l_3988:
	/* 0x3988: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_398c:
	/* 0x398c: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_398e:
	/* 0x398e: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3992:
	/* 0x3992: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3997:
	/* 0x3997: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_399a:
	/* 0x399a: call   399f <perf_unwind_native+0x399f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_399f:
	/* 0x399f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39a2:
	/* 0x39a2: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39a2, 0x5d95, x86_l_5d95);
x86_l_39a8:
	/* 0x39a8: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39ac:
	/* 0x39ac: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_39b1:
	/* 0x39b1: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39b4:
	/* 0x39b4: ja     39bd <perf_unwind_native+0x39bd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x39b4, 0x39bd, x86_l_39bd);
x86_l_39b6:
	/* 0x39b6: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_39b8:
	/* 0x39b8: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_39bb:
	/* 0x39bb: jmp    39c0 <perf_unwind_native+0x39c0> */
	X86_SIM_X86_JMP(0x39bb, 0x39c0, x86_l_39c0);
x86_l_39bd:
	/* 0x39bd: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_39c0:
	/* 0x39c0: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_39c3:
	/* 0x39c3: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x39c3, 0x4006, x86_l_4006);
x86_l_39c9:
	/* 0x39c9: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_39cd:
	/* 0x39cd: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_39cf:
	/* 0x39cf: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39d3:
	/* 0x39d3: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39d8:
	/* 0x39d8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_39db:
	/* 0x39db: call   39e0 <perf_unwind_native+0x39e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_39e0:
	/* 0x39e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39e3:
	/* 0x39e3: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39e3, 0x5d95, x86_l_5d95);
x86_l_39e9:
	/* 0x39e9: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39ed:
	/* 0x39ed: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_39f2:
	/* 0x39f2: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39f5:
	/* 0x39f5: ja     39fe <perf_unwind_native+0x39fe> */
	X86_SIM_X86_JCC(X86_CC_A, 0x39f5, 0x39fe, x86_l_39fe);
x86_l_39f7:
	/* 0x39f7: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_39f9:
	/* 0x39f9: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_39fc:
	/* 0x39fc: jmp    3a01 <perf_unwind_native+0x3a01> */
	X86_SIM_X86_JMP(0x39fc, 0x3a01, x86_l_3a01);
x86_l_39fe:
	/* 0x39fe: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3a01:
	/* 0x3a01: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3a04:
	/* 0x3a04: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3a04, 0x4006, x86_l_4006);
x86_l_3a0a:
	/* 0x3a0a: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3a0e:
	/* 0x3a0e: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3a10:
	/* 0x3a10: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a14:
	/* 0x3a14: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a19:
	/* 0x3a19: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a1c:
	/* 0x3a1c: call   3a21 <perf_unwind_native+0x3a21> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a21:
	/* 0x3a21: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a24:
	/* 0x3a24: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a24, 0x5d95, x86_l_5d95);
x86_l_3a2a:
	/* 0x3a2a: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a2e:
	/* 0x3a2e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a33:
	/* 0x3a33: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a36:
	/* 0x3a36: ja     3a3f <perf_unwind_native+0x3a3f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3a36, 0x3a3f, x86_l_3a3f);
x86_l_3a38:
	/* 0x3a38: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3a3a:
	/* 0x3a3a: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3a3d:
	/* 0x3a3d: jmp    3a42 <perf_unwind_native+0x3a42> */
	X86_SIM_X86_JMP(0x3a3d, 0x3a42, x86_l_3a42);
x86_l_3a3f:
	/* 0x3a3f: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3a42:
	/* 0x3a42: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3a45:
	/* 0x3a45: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3a45, 0x4006, x86_l_4006);
x86_l_3a4b:
	/* 0x3a4b: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3a4f:
	/* 0x3a4f: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3a51:
	/* 0x3a51: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a55:
	/* 0x3a55: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a5a:
	/* 0x3a5a: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a5d:
	/* 0x3a5d: call   3a62 <perf_unwind_native+0x3a62> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a62:
	/* 0x3a62: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a65:
	/* 0x3a65: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a65, 0x5d95, x86_l_5d95);
x86_l_3a6b:
	/* 0x3a6b: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a6f:
	/* 0x3a6f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a74:
	/* 0x3a74: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a77:
	/* 0x3a77: ja     3a80 <perf_unwind_native+0x3a80> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3a77, 0x3a80, x86_l_3a80);
x86_l_3a79:
	/* 0x3a79: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3a7b:
	/* 0x3a7b: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3a7e:
	/* 0x3a7e: jmp    3a83 <perf_unwind_native+0x3a83> */
	X86_SIM_X86_JMP(0x3a7e, 0x3a83, x86_l_3a83);
x86_l_3a80:
	/* 0x3a80: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3a83:
	/* 0x3a83: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3a86:
	/* 0x3a86: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3a86, 0x4006, x86_l_4006);
x86_l_3a8c:
	/* 0x3a8c: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3a90:
	/* 0x3a90: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3a92:
	/* 0x3a92: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a96:
	/* 0x3a96: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a9b:
	/* 0x3a9b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a9e:
	/* 0x3a9e: call   3aa3 <perf_unwind_native+0x3aa3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3aa3:
	/* 0x3aa3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3aa6:
	/* 0x3aa6: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3aa6, 0x5d95, x86_l_5d95);
x86_l_3aac:
	/* 0x3aac: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ab0:
	/* 0x3ab0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3ab5:
	/* 0x3ab5: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ab8:
	/* 0x3ab8: ja     3b24 <perf_unwind_native+0x3b24> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3ab8, 0x3b24, x86_l_3b24);
x86_l_3aba:
	/* 0x3aba: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3abc:
	/* 0x3abc: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3abf:
	/* 0x3abf: jmp    3b27 <perf_unwind_native+0x3b27> */
	X86_SIM_X86_JMP(0x3abf, 0x3b27, x86_l_3b27);
x86_l_3ac1:
	/* 0x3ac1: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_3ac7:
	/* 0x3ac7: movabs rax,0x3d3d206425206576 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4412718824384652662ULL);
x86_l_3ad1:
	/* 0x3ad1: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3ad9:
	/* 0x3ad9: movabs rax,0x6974616e5f646e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7598805597955583593ULL);
x86_l_3ae3:
	/* 0x3ae3: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3aeb:
	/* 0x3aeb: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8605944719278423357ULL);
x86_l_3af5:
	/* 0x3af5: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3afd:
	/* 0x3afd: mov    DWORD PTR [rsp+0xa8],0xa3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721555176765ULL);
x86_l_3b08:
	/* 0x3b08: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3b10:
	/* 0x3b10: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_3b15:
	/* 0x3b15: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b17:
	/* 0x3b17: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b1a:
	/* 0x3b1a: call   3b1f <perf_unwind_native+0x3b1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3b1f:
	/* 0x3b1f: jmp    3645 <perf_unwind_native+0x3645> */
	X86_SIM_X86_JMP(0x3b1f, 0x3645, x86_l_3645);
x86_l_3b24:
	/* 0x3b24: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3b27:
	/* 0x3b27: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3b2a:
	/* 0x3b2a: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3b2a, 0x4006, x86_l_4006);
x86_l_3b30:
	/* 0x3b30: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3b34:
	/* 0x3b34: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3b36:
	/* 0x3b36: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b3a:
	/* 0x3b3a: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b3f:
	/* 0x3b3f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3b42:
	/* 0x3b42: call   3b47 <perf_unwind_native+0x3b47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3b47:
	/* 0x3b47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b4a:
	/* 0x3b4a: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b4a, 0x5d95, x86_l_5d95);
x86_l_3b50:
	/* 0x3b50: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b54:
	/* 0x3b54: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3b59:
	/* 0x3b59: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b5c:
	/* 0x3b5c: ja     3c60 <perf_unwind_native+0x3c60> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3b5c, 0x3c60, x86_l_3c60);
x86_l_3b62:
	/* 0x3b62: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3b64:
	/* 0x3b64: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3b67:
	/* 0x3b67: jmp    3c63 <perf_unwind_native+0x3c63> */
	X86_SIM_X86_JMP(0x3b67, 0x3c63, x86_l_3c63);
x86_l_3b6c:
	/* 0x3b6c: movabs rax,0xa786c253a786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471844735118373ULL);
x86_l_3b76:
	/* 0x3b76: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3b7b:
	/* 0x3b7b: movabs rax,0x20726f662061746c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338053640979313772ULL);
x86_l_3b85:
	/* 0x3b85: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b8a:
	/* 0x3b8a: movabs rax,0x6564206b63617473 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7306000141102707827ULL);
x86_l_3b94:
	/* 0x3b94: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b99:
	/* 0x3b99: movabs rax,0x207075206b6f6f4c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337496988707155788ULL);
x86_l_3ba3:
	/* 0x3ba3: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ba8:
	/* 0x3ba8: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3bad:
	/* 0x3bad: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3bb2:
	/* 0x3bb2: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_3bb7:
	/* 0x3bb7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3bba:
	/* 0x3bba: call   3bbf <perf_unwind_native+0x3bbf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3bbf:
	/* 0x3bbf: jmp    37c6 <perf_unwind_native+0x37c6> */
	X86_SIM_X86_JMP(0x3bbf, 0x37c6, x86_l_37c6);
x86_l_3bc4:
	/* 0x3bc4: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3bce:
	/* 0x3bce: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_3bd6:
	/* 0x3bd6: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3be0:
	/* 0x3be0: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3be8:
	/* 0x3be8: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3bf2:
	/* 0x3bf2: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3bfa:
	/* 0x3bfa: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3c04:
	/* 0x3c04: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3c0c:
	/* 0x3c0c: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_3c16:
	/* 0x3c16: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3c1e:
	/* 0x3c1e: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_3c28:
	/* 0x3c28: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3c30:
	/* 0x3c30: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c34:
	/* 0x3c34: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3c3c:
	/* 0x3c3c: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_3c41:
	/* 0x3c41: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c43:
	/* 0x3c43: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c46:
	/* 0x3c46: call   3c4b <perf_unwind_native+0x3c4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3c4b:
	/* 0x3c4b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_3c52:
	/* 0x3c52: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c55:
	/* 0x3c55: je     3718 <perf_unwind_native+0x3718> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c55, 0x3718, x86_l_3718);
x86_l_3c5b:
	/* 0x3c5b: jmp    367a <perf_unwind_native+0x367a> */
	X86_SIM_X86_JMP(0x3c5b, 0x367a, x86_l_367a);
x86_l_3c60:
	/* 0x3c60: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3c63:
	/* 0x3c63: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3c66:
	/* 0x3c66: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3c66, 0x4006, x86_l_4006);
x86_l_3c6c:
	/* 0x3c6c: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3c70:
	/* 0x3c70: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3c72:
	/* 0x3c72: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c76:
	/* 0x3c76: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c7b:
	/* 0x3c7b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3c7e:
	/* 0x3c7e: call   3c83 <perf_unwind_native+0x3c83> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3c83:
	/* 0x3c83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c86:
	/* 0x3c86: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c86, 0x5d95, x86_l_5d95);
x86_l_3c8c:
	/* 0x3c8c: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3c90:
	/* 0x3c90: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3c95:
	/* 0x3c95: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c98:
	/* 0x3c98: ja     3d22 <perf_unwind_native+0x3d22> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c98, 0x3d22, x86_l_3d22);
x86_l_3c9e:
	/* 0x3c9e: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3ca0:
	/* 0x3ca0: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3ca3:
	/* 0x3ca3: jmp    3d25 <perf_unwind_native+0x3d25> */
	X86_SIM_X86_JMP(0x3ca3, 0x3d25, x86_l_3d25);
x86_l_3ca8:
	/* 0x3ca8: movabs rax,0xa296425204449 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2860259863446601ULL);
x86_l_3cb2:
	/* 0x3cb2: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3cb7:
	/* 0x3cb7: movabs rax,0x70616d2820756c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8097873624099548197ULL);
x86_l_3cc1:
	/* 0x3cc1: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3cc6:
	/* 0x3cc6: movabs rax,0x206f7420756c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337214414386373920ULL);
x86_l_3cd0:
	/* 0x3cd0: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3cd5:
	/* 0x3cd5: movabs rax,0x6d6f726620656220 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7885647255504773664ULL);
x86_l_3cdf:
	/* 0x3cdf: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3ce4:
	/* 0x3ce4: movabs rax,0x646c756f68732073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7236287822631739507ULL);
x86_l_3cee:
	/* 0x3cee: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3cf3:
	/* 0x3cf3: movabs rax,0x6c61767265746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653462537629257ULL);
x86_l_3cfd:
	/* 0x3cfd: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d02:
	/* 0x3d02: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3d05:
	/* 0x3d05: movzx  r8d,WORD PTR [r12+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_3d0b:
	/* 0x3d0b: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d10:
	/* 0x3d10: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_3d15:
	/* 0x3d15: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3d18:
	/* 0x3d18: call   3d1d <perf_unwind_native+0x3d1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3d1d:
	/* 0x3d1d: jmp    3988 <perf_unwind_native+0x3988> */
	X86_SIM_X86_JMP(0x3d1d, 0x3988, x86_l_3988);
x86_l_3d22:
	/* 0x3d22: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3d25:
	/* 0x3d25: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3d28:
	/* 0x3d28: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3d28, 0x4006, x86_l_4006);
x86_l_3d2e:
	/* 0x3d2e: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3d32:
	/* 0x3d32: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3d34:
	/* 0x3d34: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d38:
	/* 0x3d38: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d3d:
	/* 0x3d3d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3d40:
	/* 0x3d40: call   3d45 <perf_unwind_native+0x3d45> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3d45:
	/* 0x3d45: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d48:
	/* 0x3d48: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d48, 0x5d95, x86_l_5d95);
x86_l_3d4e:
	/* 0x3d4e: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d52:
	/* 0x3d52: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3d57:
	/* 0x3d57: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d5a:
	/* 0x3d5a: ja     3df6 <perf_unwind_native+0x3df6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3d5a, 0x3df6, x86_l_3df6);
x86_l_3d60:
	/* 0x3d60: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3d62:
	/* 0x3d62: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3d65:
	/* 0x3d65: jmp    3df9 <perf_unwind_native+0x3df9> */
	X86_SIM_X86_JMP(0x3d65, 0x3df9, x86_l_3df9);
x86_l_3d6a:
	/* 0x3d6a: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_3d74:
	/* 0x3d74: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_3d7c:
	/* 0x3d7c: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_3d86:
	/* 0x3d86: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3d8e:
	/* 0x3d8e: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_3d98:
	/* 0x3d98: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3da0:
	/* 0x3da0: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_3daa:
	/* 0x3daa: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3db2:
	/* 0x3db2: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_3dbc:
	/* 0x3dbc: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3dc4:
	/* 0x3dc4: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_3dce:
	/* 0x3dce: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3dd6:
	/* 0x3dd6: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3dda:
	/* 0x3dda: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3de2:
	/* 0x3de2: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_3de7:
	/* 0x3de7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3de9:
	/* 0x3de9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3dec:
	/* 0x3dec: call   3df1 <perf_unwind_native+0x3df1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_3df1:
	/* 0x3df1: jmp    3626 <perf_unwind_native+0x3626> */
	X86_SIM_X86_JMP(0x3df1, 0x3626, x86_l_3626);
x86_l_3df6:
	/* 0x3df6: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3df9:
	/* 0x3df9: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3dfc:
	/* 0x3dfc: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3dfc, 0x4006, x86_l_4006);
x86_l_3e02:
	/* 0x3e02: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3e06:
	/* 0x3e06: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3e08:
	/* 0x3e08: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e0c:
	/* 0x3e0c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e11:
	/* 0x3e11: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3e14:
	/* 0x3e14: call   3e19 <perf_unwind_native+0x3e19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e19:
	/* 0x3e19: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e1c:
	/* 0x3e1c: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e1c, 0x5d95, x86_l_5d95);
x86_l_3e22:
	/* 0x3e22: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e26:
	/* 0x3e26: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3e2b:
	/* 0x3e2b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e2e:
	/* 0x3e2e: ja     3e37 <perf_unwind_native+0x3e37> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3e2e, 0x3e37, x86_l_3e37);
x86_l_3e30:
	/* 0x3e30: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3e32:
	/* 0x3e32: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3e35:
	/* 0x3e35: jmp    3e3a <perf_unwind_native+0x3e3a> */
	X86_SIM_X86_JMP(0x3e35, 0x3e3a, x86_l_3e3a);
x86_l_3e37:
	/* 0x3e37: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3e3a:
	/* 0x3e3a: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3e3d:
	/* 0x3e3d: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3e3d, 0x4006, x86_l_4006);
x86_l_3e43:
	/* 0x3e43: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3e47:
	/* 0x3e47: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3e49:
	/* 0x3e49: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e4d:
	/* 0x3e4d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e52:
	/* 0x3e52: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3e55:
	/* 0x3e55: call   3e5a <perf_unwind_native+0x3e5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e5a:
	/* 0x3e5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e5d:
	/* 0x3e5d: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e5d, 0x5d95, x86_l_5d95);
x86_l_3e63:
	/* 0x3e63: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e67:
	/* 0x3e67: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3e6c:
	/* 0x3e6c: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e6f:
	/* 0x3e6f: ja     3e78 <perf_unwind_native+0x3e78> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3e6f, 0x3e78, x86_l_3e78);
x86_l_3e71:
	/* 0x3e71: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3e73:
	/* 0x3e73: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3e76:
	/* 0x3e76: jmp    3e7b <perf_unwind_native+0x3e7b> */
	X86_SIM_X86_JMP(0x3e76, 0x3e7b, x86_l_3e7b);
x86_l_3e78:
	/* 0x3e78: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3e7b:
	/* 0x3e7b: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3e7e:
	/* 0x3e7e: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3e7e, 0x4006, x86_l_4006);
x86_l_3e84:
	/* 0x3e84: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3e88:
	/* 0x3e88: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3e8a:
	/* 0x3e8a: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e8e:
	/* 0x3e8e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e93:
	/* 0x3e93: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3e96:
	/* 0x3e96: call   3e9b <perf_unwind_native+0x3e9b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e9b:
	/* 0x3e9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e9e:
	/* 0x3e9e: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e9e, 0x5d95, x86_l_5d95);
x86_l_3ea4:
	/* 0x3ea4: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ea8:
	/* 0x3ea8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3ead:
	/* 0x3ead: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3eb0:
	/* 0x3eb0: ja     3eb9 <perf_unwind_native+0x3eb9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3eb0, 0x3eb9, x86_l_3eb9);
x86_l_3eb2:
	/* 0x3eb2: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3eb4:
	/* 0x3eb4: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3eb7:
	/* 0x3eb7: jmp    3ebc <perf_unwind_native+0x3ebc> */
	X86_SIM_X86_JMP(0x3eb7, 0x3ebc, x86_l_3ebc);
x86_l_3eb9:
	/* 0x3eb9: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3ebc:
	/* 0x3ebc: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3ebf:
	/* 0x3ebf: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3ebf, 0x4006, x86_l_4006);
x86_l_3ec5:
	/* 0x3ec5: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3ec9:
	/* 0x3ec9: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3ecb:
	/* 0x3ecb: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ecf:
	/* 0x3ecf: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ed4:
	/* 0x3ed4: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3ed7:
	/* 0x3ed7: call   3edc <perf_unwind_native+0x3edc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3edc:
	/* 0x3edc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3edf:
	/* 0x3edf: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3edf, 0x5d95, x86_l_5d95);
x86_l_3ee5:
	/* 0x3ee5: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ee9:
	/* 0x3ee9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3eee:
	/* 0x3eee: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ef1:
	/* 0x3ef1: ja     3efa <perf_unwind_native+0x3efa> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3ef1, 0x3efa, x86_l_3efa);
x86_l_3ef3:
	/* 0x3ef3: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3ef5:
	/* 0x3ef5: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3ef8:
	/* 0x3ef8: jmp    3efd <perf_unwind_native+0x3efd> */
	X86_SIM_X86_JMP(0x3ef8, 0x3efd, x86_l_3efd);
x86_l_3efa:
	/* 0x3efa: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3efd:
	/* 0x3efd: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3f00:
	/* 0x3f00: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3f00, 0x4006, x86_l_4006);
x86_l_3f06:
	/* 0x3f06: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3f0a:
	/* 0x3f0a: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3f0c:
	/* 0x3f0c: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f10:
	/* 0x3f10: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f15:
	/* 0x3f15: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3f18:
	/* 0x3f18: call   3f1d <perf_unwind_native+0x3f1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3f1d:
	/* 0x3f1d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f20:
	/* 0x3f20: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f20, 0x5d95, x86_l_5d95);
x86_l_3f26:
	/* 0x3f26: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f2a:
	/* 0x3f2a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f2f:
	/* 0x3f2f: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f32:
	/* 0x3f32: ja     3f3b <perf_unwind_native+0x3f3b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3f32, 0x3f3b, x86_l_3f3b);
x86_l_3f34:
	/* 0x3f34: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3f36:
	/* 0x3f36: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3f39:
	/* 0x3f39: jmp    3f3e <perf_unwind_native+0x3f3e> */
	X86_SIM_X86_JMP(0x3f39, 0x3f3e, x86_l_3f3e);
x86_l_3f3b:
	/* 0x3f3b: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3f3e:
	/* 0x3f3e: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3f41:
	/* 0x3f41: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3f41, 0x4006, x86_l_4006);
x86_l_3f47:
	/* 0x3f47: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3f4b:
	/* 0x3f4b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3f4d:
	/* 0x3f4d: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f51:
	/* 0x3f51: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f56:
	/* 0x3f56: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3f59:
	/* 0x3f59: call   3f5e <perf_unwind_native+0x3f5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3f5e:
	/* 0x3f5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f61:
	/* 0x3f61: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f61, 0x5d95, x86_l_5d95);
x86_l_3f67:
	/* 0x3f67: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f6b:
	/* 0x3f6b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f70:
	/* 0x3f70: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f73:
	/* 0x3f73: ja     3f7c <perf_unwind_native+0x3f7c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3f73, 0x3f7c, x86_l_3f7c);
x86_l_3f75:
	/* 0x3f75: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3f77:
	/* 0x3f77: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3f7a:
	/* 0x3f7a: jmp    3f7f <perf_unwind_native+0x3f7f> */
	X86_SIM_X86_JMP(0x3f7a, 0x3f7f, x86_l_3f7f);
x86_l_3f7c:
	/* 0x3f7c: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3f7f:
	/* 0x3f7f: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3f82:
	/* 0x3f82: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3f82, 0x4006, x86_l_4006);
x86_l_3f88:
	/* 0x3f88: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3f8c:
	/* 0x3f8c: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3f8e:
	/* 0x3f8e: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f92:
	/* 0x3f92: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f97:
	/* 0x3f97: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3f9a:
	/* 0x3f9a: call   3f9f <perf_unwind_native+0x3f9f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3f9f:
	/* 0x3f9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fa2:
	/* 0x3fa2: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fa2, 0x5d95, x86_l_5d95);
x86_l_3fa8:
	/* 0x3fa8: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fac:
	/* 0x3fac: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3fb1:
	/* 0x3fb1: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fb4:
	/* 0x3fb4: ja     3fbd <perf_unwind_native+0x3fbd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3fb4, 0x3fbd, x86_l_3fbd);
x86_l_3fb6:
	/* 0x3fb6: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3fb8:
	/* 0x3fb8: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3fbb:
	/* 0x3fbb: jmp    3fc0 <perf_unwind_native+0x3fc0> */
	X86_SIM_X86_JMP(0x3fbb, 0x3fc0, x86_l_3fc0);
x86_l_3fbd:
	/* 0x3fbd: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3fc0:
	/* 0x3fc0: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3fc3:
	/* 0x3fc3: jae    4006 <perf_unwind_native+0x4006> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3fc3, 0x4006, x86_l_4006);
x86_l_3fc5:
	/* 0x3fc5: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3fc9:
	/* 0x3fc9: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3fcb:
	/* 0x3fcb: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fcf:
	/* 0x3fcf: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fd4:
	/* 0x3fd4: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3fd7:
	/* 0x3fd7: call   3fdc <perf_unwind_native+0x3fdc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3fdc:
	/* 0x3fdc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fdf:
	/* 0x3fdf: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fdf, 0x5d95, x86_l_5d95);
x86_l_3fe5:
	/* 0x3fe5: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fe9:
	/* 0x3fe9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3fee:
	/* 0x3fee: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ff1:
	/* 0x3ff1: ja     3ffa <perf_unwind_native+0x3ffa> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3ff1, 0x3ffa, x86_l_3ffa);
x86_l_3ff3:
	/* 0x3ff3: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3ff5:
	/* 0x3ff5: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3ff8:
	/* 0x3ff8: jmp    3ffd <perf_unwind_native+0x3ffd> */
	X86_SIM_X86_JMP(0x3ff8, 0x3ffd, x86_l_3ffd);
x86_l_3ffa:
	/* 0x3ffa: mov    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3ffd:
	/* 0x3ffd: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_4000:
	/* 0x4000: jb     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4000, 0x5d95, x86_l_5d95);
x86_l_4006:
	/* 0x4006: mov    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_4009:
	/* 0x4009: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_400c:
	/* 0x400c: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x400c, 0x5d95, x86_l_5d95);
x86_l_4012:
	/* 0x4012: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_4015:
	/* 0x4015: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_401a:
	/* 0x401a: lea    rsi,[rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_401f:
	/* 0x401f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4022:
	/* 0x4022: call   4027 <perf_unwind_native+0x4027> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4027:
	/* 0x4027: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_402a:
	/* 0x402a: je     409e <perf_unwind_native+0x409e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x402a, 0x409e, x86_l_409e);
x86_l_402c:
	/* 0x402c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_402f:
	/* 0x402f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4036:
	/* 0x4036: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4039:
	/* 0x4039: jne    4492 <perf_unwind_native+0x4492> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4039, 0x4492, x86_l_4492);
x86_l_403f:
	/* 0x403f: movzx  r15d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_4045:
	/* 0x4045: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_404a:
	/* 0x404a: sub    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_404d:
	/* 0x404d: mov    eax,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_4051:
	/* 0x4051: cmp    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_4055:
	/* 0x4055: jae    405e <perf_unwind_native+0x405e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4055, 0x405e, x86_l_405e);
x86_l_4057:
	/* 0x4057: add    r15d,0x10000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 65536ULL);
x86_l_405e:
	/* 0x405e: movzx  eax,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_4063:
	/* 0x4063: mov    DWORD PTR [rsp+0x68],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_4067:
	/* 0x4067: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_406c:
	/* 0x406c: je     40b3 <perf_unwind_native+0x40b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x406c, 0x40b3, x86_l_40b3);
x86_l_406e:
	/* 0x406e: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_4073:
	/* 0x4073: jne    40dc <perf_unwind_native+0x40dc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4073, 0x40dc, x86_l_40dc);
x86_l_4075:
	/* 0x4075: mov    DWORD PTR [rsp+0x84],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683079ULL);
x86_l_4080:
	/* 0x4080: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_4087:
	/* 0x4087: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_408f:
	/* 0x408f: call   4094 <perf_unwind_native+0x4094> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4094:
	/* 0x4094: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4097:
	/* 0x4097: je     40c8 <perf_unwind_native+0x40c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4097, 0x40c8, x86_l_40c8);
x86_l_4099:
	/* 0x4099: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_409c:
	/* 0x409c: jmp    40d8 <perf_unwind_native+0x40d8> */
	X86_SIM_X86_JMP(0x409c, 0x40d8, x86_l_40d8);
x86_l_409e:
	/* 0x409e: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_40a3:
	/* 0x40a3: mov    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_40a9:
	/* 0x40a9: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_40ae:
	/* 0x40ae: jmp    c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JMP(0x40ae, 0xc82, x86_l_c82);
x86_l_40b3:
	/* 0x40b3: mov    r15d,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_40b9:
	/* 0x40b9: mov    ecx,0xfa5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4005ULL);
x86_l_40be:
	/* 0x40be: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_40c3:
	/* 0x40c3: jmp    c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JMP(0x40c3, 0xc82, x86_l_c82);
x86_l_40c8:
	/* 0x40c8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_40cf:
	/* 0x40cf: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40d2:
	/* 0x40d2: jne    457b <perf_unwind_native+0x457b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40d2, 0x457b, x86_l_457b);
x86_l_40d8:
	/* 0x40d8: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_40dc:
	/* 0x40dc: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_40df:
	/* 0x40df: js     41b1 <perf_unwind_native+0x41b1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x40df, 0x41b1, x86_l_41b1);
x86_l_40e5:
	/* 0x40e5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_40ec:
	/* 0x40ec: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_40f1:
	/* 0x40f1: call   40f6 <perf_unwind_native+0x40f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_40f6:
	/* 0x40f6: mov    QWORD PTR [rsp+0x120],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_40fe:
	/* 0x40fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4101:
	/* 0x4101: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_4106:
	/* 0x4106: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_410d:
	/* 0x410d: je     5f07 <perf_unwind_native+0x5f07> */
	X86_SIM_X86_JCC(X86_CC_E, 0x410d, 0x5f07, x86_l_5f07);
x86_l_4113:
	/* 0x4113: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_411b:
	/* 0x411b: mov    r12d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_411f:
	/* 0x411f: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_4123:
	/* 0x4123: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4125:
	/* 0x4125: je     4165 <perf_unwind_native+0x4165> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4125, 0x4165, x86_l_4165);
x86_l_4127:
	/* 0x4127: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_412e:
	/* 0x412e: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4131:
	/* 0x4131: jne    450e <perf_unwind_native+0x450e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4131, 0x450e, x86_l_450e);
x86_l_4137:
	/* 0x4137: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4139:
	/* 0x4139: and    cl,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 127ULL);
x86_l_413c:
	/* 0x413c: movzx  ecx,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_413f:
	/* 0x413f: cmp    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4142:
	/* 0x4142: jl     4165 <perf_unwind_native+0x4165> */
	X86_SIM_X86_JCC(X86_CC_L, 0x4142, 0x4165, x86_l_4165);
x86_l_4144:
	/* 0x4144: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4146:
	/* 0x4146: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4148:
	/* 0x4148: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_414b:
	/* 0x414b: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_414e:
	/* 0x414e: add    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_4151:
	/* 0x4151: add    r12d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_4155:
	/* 0x4155: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_415c:
	/* 0x415c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_415f:
	/* 0x415f: jne    45f5 <perf_unwind_native+0x45f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x415f, 0x45f5, x86_l_45f5);
x86_l_4165:
	/* 0x4165: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_416d:
	/* 0x416d: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4170:
	/* 0x4170: mov    ecx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_4173:
	/* 0x4173: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4175:
	/* 0x4175: jns    417d <perf_unwind_native+0x417d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4175, 0x417d, x86_l_417d);
x86_l_4177:
	/* 0x4177: mov    ecx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_417a:
	/* 0x417a: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_417d:
	/* 0x417d: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_417f:
	/* 0x417f: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_4182:
	/* 0x4182: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4184:
	/* 0x4184: mov    QWORD PTR [rsp+0x8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4189:
	/* 0x4189: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_418c:
	/* 0x418c: jg     42bb <perf_unwind_native+0x42bb> */
	X86_SIM_X86_JCC(X86_CC_G, 0x418c, 0x42bb, x86_l_42bb);
x86_l_4192:
	/* 0x4192: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4195:
	/* 0x4195: je     442e <perf_unwind_native+0x442e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4195, 0x442e, x86_l_442e);
x86_l_419b:
	/* 0x419b: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_41a3:
	/* 0x41a3: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_41a6:
	/* 0x41a6: je     4426 <perf_unwind_native+0x4426> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41a6, 0x4426, x86_l_4426);
x86_l_41ac:
	/* 0x41ac: jmp    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JMP(0x41ac, 0x46c9, x86_l_46c9);
x86_l_41b1:
	/* 0x41b1: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_41b6:
	/* 0x41b6: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_41bc:
	/* 0x41bc: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_41bf:
	/* 0x41bf: jg     4255 <perf_unwind_native+0x4255> */
	X86_SIM_X86_JCC(X86_CC_G, 0x41bf, 0x4255, x86_l_4255);
x86_l_41c5:
	/* 0x41c5: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_41c8:
	/* 0x41c8: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_41cd:
	/* 0x41cd: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_41d5:
	/* 0x41d5: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_41dd:
	/* 0x41dd: je     6052 <perf_unwind_native+0x6052> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41dd, 0x6052, x86_l_6052);
x86_l_41e3:
	/* 0x41e3: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_41e6:
	/* 0x41e6: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41e6, 0x5417, x86_l_5417);
x86_l_41ec:
	/* 0x41ec: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41ef:
	/* 0x41ef: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41f1:
	/* 0x41f1: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_41f4:
	/* 0x41f4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41f6:
	/* 0x41f6: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_41f9:
	/* 0x41f9: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_41fc:
	/* 0x41fc: lea    rax,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_4200:
	/* 0x4200: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4204:
	/* 0x4204: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4209:
	/* 0x4209: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4210:
	/* 0x4210: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4213:
	/* 0x4213: je     48d3 <perf_unwind_native+0x48d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4213, 0x48d3, x86_l_48d3);
x86_l_4219:
	/* 0x4219: movabs rax,0xa786c2578303d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155647541309ULL);
x86_l_4223:
	/* 0x4223: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4228:
	/* 0x4228: movabs rax,0x616663202c544c50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018406059137322064ULL);
x86_l_4232:
	/* 0x4232: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4237:
	/* 0x4237: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_423c:
	/* 0x423c: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4241:
	/* 0x4241: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4246:
	/* 0x4246: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4248:
	/* 0x4248: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_424b:
	/* 0x424b: call   4250 <perf_unwind_native+0x4250> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4250:
	/* 0x4250: jmp    48d3 <perf_unwind_native+0x48d3> */
	X86_SIM_X86_JMP(0x4250, 0x48d3, x86_l_48d3);
x86_l_4255:
	/* 0x4255: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_4258:
	/* 0x4258: je     432a <perf_unwind_native+0x432a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4258, 0x432a, x86_l_432a);
x86_l_425e:
	/* 0x425e: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_4261:
	/* 0x4261: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_4266:
	/* 0x4266: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_426b:
	/* 0x426b: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x426b, 0x5417, x86_l_5417);
x86_l_4271:
	/* 0x4271: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4274:
	/* 0x4274: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4279:
	/* 0x4279: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_427e:
	/* 0x427e: call   4283 <perf_unwind_native+0x4283> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4283:
	/* 0x4283: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4286:
	/* 0x4286: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4286, 0x1522, x86_l_1522);
x86_l_428c:
	/* 0x428c: mov    rax,QWORD PTR [rbx+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_4293:
	/* 0x4293: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4297:
	/* 0x4297: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_429e:
	/* 0x429e: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_42a3:
	/* 0x42a3: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_42aa:
	/* 0x42aa: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_42af:
	/* 0x42af: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_42b6:
	/* 0x42b6: jmp    4914 <perf_unwind_native+0x4914> */
	X86_SIM_X86_JMP(0x42b6, 0x4914, x86_l_4914);
x86_l_42bb:
	/* 0x42bb: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_42be:
	/* 0x42be: je     4421 <perf_unwind_native+0x4421> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42be, 0x4421, x86_l_4421);
x86_l_42c4:
	/* 0x42c4: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_42c7:
	/* 0x42c7: jne    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42c7, 0x46c9, x86_l_46c9);
x86_l_42cd:
	/* 0x42cd: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_42d0:
	/* 0x42d0: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_42d2:
	/* 0x42d2: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_42d5:
	/* 0x42d5: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_42d8:
	/* 0x42d8: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_42dd:
	/* 0x42dd: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_42e4:
	/* 0x42e4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_42e7:
	/* 0x42e7: jne    4653 <perf_unwind_native+0x4653> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x42e7, 0x4653, x86_l_4653);
x86_l_42ed:
	/* 0x42ed: and    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_42f1:
	/* 0x42f1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42f3:
	/* 0x42f3: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42f8:
	/* 0x42f8: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_42fc:
	/* 0x42fc: jg     46a0 <perf_unwind_native+0x46a0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x42fc, 0x46a0, x86_l_46a0);
x86_l_4302:
	/* 0x4302: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_430a:
	/* 0x430a: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_430d:
	/* 0x430d: je     46bc <perf_unwind_native+0x46bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x430d, 0x46bc, x86_l_46bc);
x86_l_4313:
	/* 0x4313: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_4317:
	/* 0x4317: jne    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4317, 0x46c9, x86_l_46c9);
x86_l_431d:
	/* 0x431d: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_4325:
	/* 0x4325: jmp    46bc <perf_unwind_native+0x46bc> */
	X86_SIM_X86_JMP(0x4325, 0x46bc, x86_l_46bc);
x86_l_432a:
	/* 0x432a: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4332:
	/* 0x4332: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4335:
	/* 0x4335: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_4339:
	/* 0x4339: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4341:
	/* 0x4341: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_4346:
	/* 0x4346: call   434b <perf_unwind_native+0x434b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_434b:
	/* 0x434b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_434e:
	/* 0x434e: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_4353:
	/* 0x4353: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4353, 0x1522, x86_l_1522);
x86_l_4359:
	/* 0x4359: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_4361:
	/* 0x4361: mov    QWORD PTR [rbx+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_4368:
	/* 0x4368: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4370:
	/* 0x4370: mov    QWORD PTR [rbx+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_4377:
	/* 0x4377: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_437f:
	/* 0x437f: mov    QWORD PTR [rbx+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_4386:
	/* 0x4386: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_438e:
	/* 0x438e: mov    QWORD PTR [rbx+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_4395:
	/* 0x4395: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_439d:
	/* 0x439d: mov    QWORD PTR [rbx+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_43a4:
	/* 0x43a4: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_43ac:
	/* 0x43ac: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_43b3:
	/* 0x43b3: mov    rax,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_43bb:
	/* 0x43bb: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_43c2:
	/* 0x43c2: mov    rax,QWORD PTR [rsp+0x110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_43ca:
	/* 0x43ca: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_43d1:
	/* 0x43d1: mov    BYTE PTR [rbx+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_43d8:
	/* 0x43d8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_43df:
	/* 0x43df: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43e2:
	/* 0x43e2: je     491b <perf_unwind_native+0x491b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43e2, 0x491b, x86_l_491b);
x86_l_43e8:
	/* 0x43e8: movabs rax,0xa656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926270227834400ULL);
x86_l_43f2:
	/* 0x43f2: mov    QWORD PTR [rsp+0x16],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_43f7:
	/* 0x43f7: movabs rax,0x66206c616e676973 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359000956843288947ULL);
x86_l_4401:
	/* 0x4401: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4406:
	/* 0x4406: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_440b:
	/* 0x440b: mov    esi,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_4410:
	/* 0x4410: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4412:
	/* 0x4412: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4414:
	/* 0x4414: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4417:
	/* 0x4417: call   441c <perf_unwind_native+0x441c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_441c:
	/* 0x441c: jmp    491b <perf_unwind_native+0x491b> */
	X86_SIM_X86_JMP(0x441c, 0x491b, x86_l_491b);
x86_l_4421:
	/* 0x4421: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4426:
	/* 0x4426: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4429:
	/* 0x4429: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_442e:
	/* 0x442e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4433:
	/* 0x4433: movsxd rcx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_4436:
	/* 0x4436: add    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4439:
	/* 0x4439: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_443e:
	/* 0x443e: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4440:
	/* 0x4440: jns    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4440, 0x46c9, x86_l_46c9);
x86_l_4446:
	/* 0x4446: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_444b:
	/* 0x444b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4450:
	/* 0x4450: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4455:
	/* 0x4455: call   445a <perf_unwind_native+0x445a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_445a:
	/* 0x445a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_445d:
	/* 0x445d: je     447b <perf_unwind_native+0x447b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x445d, 0x447b, x86_l_447b);
x86_l_445f:
	/* 0x445f: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4466:
	/* 0x4466: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4469:
	/* 0x4469: jne    4cc4 <perf_unwind_native+0x4cc4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4469, 0x4cc4, x86_l_4cc4);
x86_l_446f:
	/* 0x446f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4471:
	/* 0x4471: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4476:
	/* 0x4476: jmp    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JMP(0x4476, 0x46c9, x86_l_46c9);
x86_l_447b:
	/* 0x447b: shl    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_447f:
	/* 0x447f: and    r12d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_4483:
	/* 0x4483: add    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_4488:
	/* 0x4488: mov    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_448d:
	/* 0x448d: jmp    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JMP(0x448d, 0x46c9, x86_l_46c9);
x86_l_4492:
	/* 0x4492: movabs rax,0xa6425206f666e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387845742ULL);
x86_l_449c:
	/* 0x449c: mov    QWORD PTR [rsp+0x35],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_44a1:
	/* 0x44a1: movabs rax,0x6f666e49646e6977 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8027224647331113335ULL);
x86_l_44ab:
	/* 0x44ab: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_44b0:
	/* 0x44b0: movabs rax,0x6e75202c78257830 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959303291813591088ULL);
x86_l_44ba:
	/* 0x44ba: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_44bf:
	/* 0x44bf: movabs rax,0x20776f4c72646461 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2339460905569641569ULL);
x86_l_44c9:
	/* 0x44c9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_44ce:
	/* 0x44ce: movabs rax,0x202c642520786564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2318338018810291556ULL);
x86_l_44d8:
	/* 0x44d8: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_44dd:
	/* 0x44dd: movabs rax,0x6e692061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7955925819663869284ULL);
x86_l_44e7:
	/* 0x44e7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_44ec:
	/* 0x44ec: mov    edx,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_44f0:
	/* 0x44f0: movzx  ecx,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_44f5:
	/* 0x44f5: movzx  r8d,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_44fa:
	/* 0x44fa: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_44ff:
	/* 0x44ff: mov    esi,0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 45ULL);
x86_l_4504:
	/* 0x4504: call   4509 <perf_unwind_native+0x4509> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4509:
	/* 0x4509: jmp    403f <perf_unwind_native+0x403f> */
	X86_SIM_X86_JMP(0x4509, 0x403f, x86_l_403f);
x86_l_450e:
	/* 0x450e: movabs rax,0xa78323023252061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754408119914012769ULL);
x86_l_4518:
	/* 0x4518: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_451d:
	/* 0x451d: movabs rax,0x746c656420646567 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389191686598976871ULL);
x86_l_4527:
	/* 0x4527: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_452c:
	/* 0x452c: movabs rax,0x72656d202c642520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243114677922702624ULL);
x86_l_4536:
	/* 0x4536: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_453b:
	/* 0x453b: movabs rax,0x6666694472646441 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7378700782191010881ULL);
x86_l_4545:
	/* 0x4545: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_454a:
	/* 0x454a: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_454f:
	/* 0x454f: movsxd rdx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_4552:
	/* 0x4552: mov    r14,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_455a:
	/* 0x455a: movzx  ecx,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_455f:
	/* 0x455f: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4564:
	/* 0x4564: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_4569:
	/* 0x4569: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_456c:
	/* 0x456c: call   4571 <perf_unwind_native+0x4571> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4571:
	/* 0x4571: movzx  eax,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_4576:
	/* 0x4576: jmp    4137 <perf_unwind_native+0x4137> */
	X86_SIM_X86_JMP(0x4576, 0x4137, x86_l_4137);
x86_l_457b:
	/* 0x457b: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_4585:
	/* 0x4585: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_458a:
	/* 0x458a: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_4594:
	/* 0x4594: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4599:
	/* 0x4599: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_45a3:
	/* 0x45a3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_45a8:
	/* 0x45a8: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_45b2:
	/* 0x45b2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_45b7:
	/* 0x45b7: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_45c1:
	/* 0x45c1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_45c6:
	/* 0x45c6: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_45d0:
	/* 0x45d0: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45d5:
	/* 0x45d5: mov    edx,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_45dc:
	/* 0x45dc: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45e1:
	/* 0x45e1: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_45e6:
	/* 0x45e6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_45e8:
	/* 0x45e8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_45eb:
	/* 0x45eb: call   45f0 <perf_unwind_native+0x45f0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_45f0:
	/* 0x45f0: jmp    40d8 <perf_unwind_native+0x40d8> */
	X86_SIM_X86_JMP(0x45f0, 0x40d8, x86_l_40d8);
x86_l_45f5:
	/* 0x45f5: movabs rax,0xa64253d61746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 748764383608597605ULL);
x86_l_45ff:
	/* 0x45ff: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4604:
	/* 0x4604: movabs rax,0x44616663203a6863 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4927332043248527459ULL);
x86_l_460e:
	/* 0x460e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4613:
	/* 0x4613: movabs rax,0x74616d2061746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8386103966981975141ULL);
x86_l_461d:
	/* 0x461d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4622:
	/* 0x4622: movabs rax,0x642064656772654d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7214876989737559373ULL);
x86_l_462c:
	/* 0x462c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4631:
	/* 0x4631: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_4636:
	/* 0x4636: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_463a:
	/* 0x463a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_463f:
	/* 0x463f: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_4644:
	/* 0x4644: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4646:
	/* 0x4646: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4649:
	/* 0x4649: call   464e <perf_unwind_native+0x464e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_464e:
	/* 0x464e: jmp    4165 <perf_unwind_native+0x4165> */
	X86_SIM_X86_JMP(0x464e, 0x4165, x86_l_4165);
x86_l_4653:
	/* 0x4653: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_465d:
	/* 0x465d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4662:
	/* 0x4662: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_466c:
	/* 0x466c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4671:
	/* 0x4671: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_4676:
	/* 0x4676: and    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_467a:
	/* 0x467a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_467f:
	/* 0x467f: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_4684:
	/* 0x4684: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4687:
	/* 0x4687: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_468a:
	/* 0x468a: call   468f <perf_unwind_native+0x468f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_468f:
	/* 0x468f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4691:
	/* 0x4691: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4696:
	/* 0x4696: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_469a:
	/* 0x469a: jle    4302 <perf_unwind_native+0x4302> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x469a, 0x4302, x86_l_4302);
x86_l_46a0:
	/* 0x46a0: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_46a8:
	/* 0x46a8: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_46ac:
	/* 0x46ac: je     46bc <perf_unwind_native+0x46bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46ac, 0x46bc, x86_l_46bc);
x86_l_46ae:
	/* 0x46ae: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_46b6:
	/* 0x46b6: cmp    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_46ba:
	/* 0x46ba: jne    46c9 <perf_unwind_native+0x46c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x46ba, 0x46c9, x86_l_46c9);
x86_l_46bc:
	/* 0x46bc: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_46c1:
	/* 0x46c1: add    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_46c4:
	/* 0x46c4: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_46c9:
	/* 0x46c9: mov    rcx,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_46d1:
	/* 0x46d1: movzx  eax,BYTE PTR [rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_46d5:
	/* 0x46d5: mov    r13d,DWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_46d9:
	/* 0x46d9: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_46dc:
	/* 0x46dc: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_46de:
	/* 0x46de: jns    46e6 <perf_unwind_native+0x46e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x46de, 0x46e6, x86_l_46e6);
x86_l_46e0:
	/* 0x46e0: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_46e3:
	/* 0x46e3: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_46e6:
	/* 0x46e6: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_46e8:
	/* 0x46e8: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_46eb:
	/* 0x46eb: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_46ee:
	/* 0x46ee: jg     4710 <perf_unwind_native+0x4710> */
	X86_SIM_X86_JCC(X86_CC_G, 0x46ee, 0x4710, x86_l_4710);
x86_l_46f0:
	/* 0x46f0: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_46f5:
	/* 0x46f5: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_46f8:
	/* 0x46f8: je     477c <perf_unwind_native+0x477c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46f8, 0x477c, x86_l_477c);
x86_l_46fe:
	/* 0x46fe: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4706:
	/* 0x4706: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4709:
	/* 0x4709: je     4779 <perf_unwind_native+0x4779> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4709, 0x4779, x86_l_4779);
x86_l_470b:
	/* 0x470b: jmp    48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JMP(0x470b, 0x48ba, x86_l_48ba);
x86_l_4710:
	/* 0x4710: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_4713:
	/* 0x4713: je     4774 <perf_unwind_native+0x4774> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4713, 0x4774, x86_l_4774);
x86_l_4715:
	/* 0x4715: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_4718:
	/* 0x4718: jne    48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4718, 0x48ba, x86_l_48ba);
x86_l_471e:
	/* 0x471e: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_4721:
	/* 0x4721: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_4723:
	/* 0x4723: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_4726:
	/* 0x4726: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_4729:
	/* 0x4729: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_472e:
	/* 0x472e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4735:
	/* 0x4735: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4738:
	/* 0x4738: jne    4837 <perf_unwind_native+0x4837> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4738, 0x4837, x86_l_4837);
x86_l_473e:
	/* 0x473e: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_4742:
	/* 0x4742: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_4746:
	/* 0x4746: jg     487d <perf_unwind_native+0x487d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4746, 0x487d, x86_l_487d);
x86_l_474c:
	/* 0x474c: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_4754:
	/* 0x4754: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_4757:
	/* 0x4757: je     4899 <perf_unwind_native+0x4899> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4757, 0x4899, x86_l_4899);
x86_l_475d:
	/* 0x475d: cmp    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_4761:
	/* 0x4761: jne    48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4761, 0x48ba, x86_l_48ba);
x86_l_4767:
	/* 0x4767: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_476f:
	/* 0x476f: jmp    4899 <perf_unwind_native+0x4899> */
	X86_SIM_X86_JMP(0x476f, 0x4899, x86_l_4899);
x86_l_4774:
	/* 0x4774: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4779:
	/* 0x4779: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_477c:
	/* 0x477c: movsxd r12,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_477f:
	/* 0x477f: add    r12,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4782:
	/* 0x4782: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4784:
	/* 0x4784: jns    48a1 <perf_unwind_native+0x48a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4784, 0x48a1, x86_l_48a1);
x86_l_478a:
	/* 0x478a: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_478f:
	/* 0x478f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4794:
	/* 0x4794: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4797:
	/* 0x4797: call   479c <perf_unwind_native+0x479c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_479c:
	/* 0x479c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_479f:
	/* 0x479f: je     4824 <perf_unwind_native+0x4824> */
	X86_SIM_X86_JCC(X86_CC_E, 0x479f, 0x4824, x86_l_4824);
x86_l_47a5:
	/* 0x47a5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_47ac:
	/* 0x47ac: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47af:
	/* 0x47af: je     48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47af, 0x48ba, x86_l_48ba);
x86_l_47b5:
	/* 0x47b5: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_47bf:
	/* 0x47bf: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_47c4:
	/* 0x47c4: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_47ce:
	/* 0x47ce: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_47d3:
	/* 0x47d3: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_47dd:
	/* 0x47dd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_47e2:
	/* 0x47e2: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_47ec:
	/* 0x47ec: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_47f1:
	/* 0x47f1: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_47fb:
	/* 0x47fb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4800:
	/* 0x4800: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_4808:
	/* 0x4808: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_480d:
	/* 0x480d: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_4812:
	/* 0x4812: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4815:
	/* 0x4815: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4817:
	/* 0x4817: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_481a:
	/* 0x481a: call   481f <perf_unwind_native+0x481f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_481f:
	/* 0x481f: jmp    48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JMP(0x481f, 0x48ba, x86_l_48ba);
x86_l_4824:
	/* 0x4824: lea    r12d,[r13*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 0ULL);
x86_l_482c:
	/* 0x482c: and    r12d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_4830:
	/* 0x4830: add    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_4835:
	/* 0x4835: jmp    48a1 <perf_unwind_native+0x48a1> */
	X86_SIM_X86_JMP(0x4835, 0x48a1, x86_l_48a1);
x86_l_4837:
	/* 0x4837: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_4841:
	/* 0x4841: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4846:
	/* 0x4846: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_4850:
	/* 0x4850: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4855:
	/* 0x4855: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_485a:
	/* 0x485a: and    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_485e:
	/* 0x485e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4863:
	/* 0x4863: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_4868:
	/* 0x4868: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_486b:
	/* 0x486b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_486e:
	/* 0x486e: call   4873 <perf_unwind_native+0x4873> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4873:
	/* 0x4873: cmp    r13d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_4877:
	/* 0x4877: jle    474c <perf_unwind_native+0x474c> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x4877, 0x474c, x86_l_474c);
x86_l_487d:
	/* 0x487d: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_4885:
	/* 0x4885: cmp    r13d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_4889:
	/* 0x4889: je     4899 <perf_unwind_native+0x4899> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4889, 0x4899, x86_l_4899);
x86_l_488b:
	/* 0x488b: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_4893:
	/* 0x4893: cmp    r13d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_4897:
	/* 0x4897: jne    48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4897, 0x48ba, x86_l_48ba);
x86_l_4899:
	/* 0x4899: mov    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_489e:
	/* 0x489e: add    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_48a1:
	/* 0x48a1: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_48a4:
	/* 0x48a4: je     48ba <perf_unwind_native+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48a4, 0x48ba, x86_l_48ba);
x86_l_48a6:
	/* 0x48a6: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_48ab:
	/* 0x48ab: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_48b0:
	/* 0x48b0: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_48b3:
	/* 0x48b3: call   48b8 <perf_unwind_native+0x48b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_48b8:
	/* 0x48b8: jmp    48d3 <perf_unwind_native+0x48d3> */
	X86_SIM_X86_JMP(0x48b8, 0x48d3, x86_l_48d3);
x86_l_48ba:
	/* 0x48ba: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_48c2:
	/* 0x48c2: cmp    BYTE PTR [rax],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_48c5:
	/* 0x48c5: jne    48d3 <perf_unwind_native+0x48d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x48c5, 0x48d3, x86_l_48d3);
x86_l_48c7:
	/* 0x48c7: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_48cc:
	/* 0x48cc: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48d3:
	/* 0x48d3: cmp    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_48d9:
	/* 0x48d9: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_48de:
	/* 0x48de: je     1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48de, 0x1522, x86_l_1522);
x86_l_48e4:
	/* 0x48e4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_48e9:
	/* 0x48e9: lea    rdx,[rax-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_48ed:
	/* 0x48ed: mov    rdi,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_48f5:
	/* 0x48f5: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_48fa:
	/* 0x48fa: call   48ff <perf_unwind_native+0x48ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_48ff:
	/* 0x48ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4902:
	/* 0x4902: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4902, 0x1522, x86_l_1522);
x86_l_4908:
	/* 0x4908: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_490d:
	/* 0x490d: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_4914:
	/* 0x4914: mov    BYTE PTR [rbx+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_491b:
	/* 0x491b: mov    DWORD PTR [rsp+0x70],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337158ULL);
x86_l_4923:
	/* 0x4923: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_492a:
	/* 0x492a: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_492f:
	/* 0x492f: call   4934 <perf_unwind_native+0x4934> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4934:
	/* 0x4934: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4937:
	/* 0x4937: je     49d5 <perf_unwind_native+0x49d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4937, 0x49d5, x86_l_49d5);
x86_l_493d:
	/* 0x493d: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4940:
	/* 0x4940: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4942:
	/* 0x4942: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4949:
	/* 0x4949: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_494c:
	/* 0x494c: je     49e7 <perf_unwind_native+0x49e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x494c, 0x49e7, x86_l_49e7);
x86_l_4952:
	/* 0x4952: movabs rax,0xa786c6c25203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280058ULL);
x86_l_495c:
	/* 0x495c: mov    QWORD PTR [rsp+0xa5],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_4964:
	/* 0x4964: movabs rax,0x25203a706620786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675202433082226796ULL);
x86_l_496e:
	/* 0x496e: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4976:
	/* 0x4976: movabs rax,0x6c25203a70732078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165601296504ULL);
x86_l_4980:
	/* 0x4980: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4988:
	/* 0x4988: movabs rax,0x6c6c25203a637020 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660273929744416ULL);
x86_l_4992:
	/* 0x4992: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_499a:
	/* 0x499a: mov    rax,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_49a2:
	/* 0x49a2: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49a5:
	/* 0x49a5: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_49ad:
	/* 0x49ad: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49b0:
	/* 0x49b0: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_49b5:
	/* 0x49b5: mov    r8,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49b8:
	/* 0x49b8: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_49c0:
	/* 0x49c0: mov    esi,0x1d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_49c5:
	/* 0x49c5: call   49ca <perf_unwind_native+0x49ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_49ca:
	/* 0x49ca: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_49d1:
	/* 0x49d1: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49d3:
	/* 0x49d3: jmp    49e7 <perf_unwind_native+0x49e7> */
	X86_SIM_X86_JMP(0x49d3, 0x49e7, x86_l_49e7);
x86_l_49d5:
	/* 0x49d5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_49dc:
	/* 0x49dc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49df:
	/* 0x49df: jne    4c3b <perf_unwind_native+0x4c3b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49df, 0x4c3b, x86_l_4c3b);
x86_l_49e5:
	/* 0x49e5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49e7:
	/* 0x49e7: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_49ef:
	/* 0x49ef: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49f2:
	/* 0x49f2: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_49f5:
	/* 0x49f5: je     696b <perf_unwind_native+0x696b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49f5, 0x696b, x86_l_696b);
x86_l_49fb:
	/* 0x49fb: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_49fd:
	/* 0x49fd: jne    4b8b <perf_unwind_native+0x4b8b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49fd, 0x4b8b, x86_l_4b8b);
x86_l_4a03:
	/* 0x4a03: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4a0d:
	/* 0x4a0d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a10:
	/* 0x4a10: ja     3034 <perf_unwind_native+0x3034> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4a10, 0x3034, x86_l_3034);
x86_l_4a16:
	/* 0x4a16: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_4a1d:
	/* 0x4a1d: jb     3174 <perf_unwind_native+0x3174> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4a1d, 0x3174, x86_l_3174);
x86_l_4a23:
	/* 0x4a23: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a25:
	/* 0x4a25: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_4a2d:
	/* 0x4a2d: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_4a33:
	/* 0x4a33: movbe  QWORD PTR [rsp+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_4a3a:
	/* 0x4a3a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_4a41:
	/* 0x4a41: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4a46:
	/* 0x4a46: call   4a4b <perf_unwind_native+0x4a4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4a4b:
	/* 0x4a4b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a4e:
	/* 0x4a4e: je     6a1d <perf_unwind_native+0x6a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a4e, 0x6a1d, x86_l_6a1d);
x86_l_4a54:
	/* 0x4a54: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4a58:
	/* 0x4a58: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4a5b:
	/* 0x4a5b: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4a65:
	/* 0x4a65: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4a68:
	/* 0x4a68: mov    QWORD PTR [rbx+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4a6f:
	/* 0x4a6f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a72:
	/* 0x4a72: mov    QWORD PTR [rbx+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4a79:
	/* 0x4a79: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_4a7d:
	/* 0x4a7d: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4a80:
	/* 0x4a80: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4a83:
	/* 0x4a83: mov    QWORD PTR [rbx+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4a8a:
	/* 0x4a8a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4a91:
	/* 0x4a91: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a94:
	/* 0x4a94: jne    4d35 <perf_unwind_native+0x4d35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a94, 0x4d35, x86_l_4d35);
x86_l_4a9a:
	/* 0x4a9a: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4a9e:
	/* 0x4a9e: jne    4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a9e, 0x4f0c, x86_l_4f0c);
x86_l_4aa4:
	/* 0x4aa4: mov    rax,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4aab:
	/* 0x4aab: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ab0:
	/* 0x4ab0: mov    r14,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4ab7:
	/* 0x4ab7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_4abe:
	/* 0x4abe: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ac3:
	/* 0x4ac3: call   4ac8 <perf_unwind_native+0x4ac8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4ac8:
	/* 0x4ac8: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4ace:
	/* 0x4ace: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ad1:
	/* 0x4ad1: je     4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ad1, 0x4f0c, x86_l_4f0c);
x86_l_4ad7:
	/* 0x4ad7: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ada:
	/* 0x4ada: cmp    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4add:
	/* 0x4add: ja     4ae5 <perf_unwind_native+0x4ae5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4add, 0x4ae5, x86_l_4ae5);
x86_l_4adf:
	/* 0x4adf: cmp    QWORD PTR [r13+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ae3:
	/* 0x4ae3: jae    4af9 <perf_unwind_native+0x4af9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4ae3, 0x4af9, x86_l_4af9);
x86_l_4ae5:
	/* 0x4ae5: cmp    QWORD PTR [r13+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ae9:
	/* 0x4ae9: ja     4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4ae9, 0x4f0c, x86_l_4f0c);
x86_l_4aef:
	/* 0x4aef: cmp    QWORD PTR [r13+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4af3:
	/* 0x4af3: jb     4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4af3, 0x4f0c, x86_l_4f0c);
x86_l_4af9:
	/* 0x4af9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4b00:
	/* 0x4b00: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b03:
	/* 0x4b03: jne    4e5d <perf_unwind_native+0x4e5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4b03, 0x4e5d, x86_l_4e5d);
x86_l_4b09:
	/* 0x4b09: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_4b0f:
	/* 0x4b0f: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b13:
	/* 0x4b13: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4b16:
	/* 0x4b16: jae    4ed4 <perf_unwind_native+0x4ed4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4b16, 0x4ed4, x86_l_4ed4);
x86_l_4b1c:
	/* 0x4b1c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4b23:
	/* 0x4b23: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b26:
	/* 0x4b26: je     4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b26, 0x4f0c, x86_l_4f0c);
x86_l_4b2c:
	/* 0x4b2c: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_4b36:
	/* 0x4b36: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4b3e:
	/* 0x4b3e: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_4b48:
	/* 0x4b48: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4b50:
	/* 0x4b50: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_4b5a:
	/* 0x4b5a: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4b62:
	/* 0x4b62: mov    DWORD PTR [rsp+0xa7],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 717260219758ULL);
x86_l_4b6d:
	/* 0x4b6d: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4b75:
	/* 0x4b75: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_4b7a:
	/* 0x4b7a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b7c:
	/* 0x4b7c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b7e:
	/* 0x4b7e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b81:
	/* 0x4b81: call   4b86 <perf_unwind_native+0x4b86> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4b86:
	/* 0x4b86: jmp    4f0c <perf_unwind_native+0x4f0c> */
	X86_SIM_X86_JMP(0x4b86, 0x4f0c, x86_l_4f0c);
x86_l_4b8b:
	/* 0x4b8b: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_4b95:
	/* 0x4b95: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_4b9d:
	/* 0x4b9d: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_4ba7:
	/* 0x4ba7: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4baf:
	/* 0x4baf: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_4bb9:
	/* 0x4bb9: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_4bc1:
	/* 0x4bc1: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_4bcb:
	/* 0x4bcb: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4bd3:
	/* 0x4bd3: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_4bdd:
	/* 0x4bdd: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4be5:
	/* 0x4be5: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_4bef:
	/* 0x4bef: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4bf7:
	/* 0x4bf7: mov    BYTE PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_4bff:
	/* 0x4bff: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4c05:
	/* 0x4c05: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4c0d:
	/* 0x4c0d: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_4c12:
	/* 0x4c12: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c14:
	/* 0x4c14: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c17:
	/* 0x4c17: call   4c1c <perf_unwind_native+0x4c1c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4c1c:
	/* 0x4c1c: mov    r13,QWORD PTR [rbx+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_4c23:
	/* 0x4c23: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_4c2d:
	/* 0x4c2d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c30:
	/* 0x4c30: ja     3034 <perf_unwind_native+0x3034> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4c30, 0x3034, x86_l_3034);
x86_l_4c36:
	/* 0x4c36: jmp    4a16 <perf_unwind_native+0x4a16> */
	X86_SIM_X86_JMP(0x4c36, 0x4a16, x86_l_4a16);
x86_l_4c3b:
	/* 0x4c3b: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_4c45:
	/* 0x4c45: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_4c4a:
	/* 0x4c4a: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_4c54:
	/* 0x4c54: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4c59:
	/* 0x4c59: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_4c63:
	/* 0x4c63: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4c68:
	/* 0x4c68: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_4c72:
	/* 0x4c72: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4c77:
	/* 0x4c77: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_4c81:
	/* 0x4c81: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4c86:
	/* 0x4c86: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_4c90:
	/* 0x4c90: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c95:
	/* 0x4c95: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4c99:
	/* 0x4c99: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c9e:
	/* 0x4c9e: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_4ca3:
	/* 0x4ca3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ca5:
	/* 0x4ca5: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ca8:
	/* 0x4ca8: call   4cad <perf_unwind_native+0x4cad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4cad:
	/* 0x4cad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4caf:
	/* 0x4caf: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4cb6:
	/* 0x4cb6: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4cb9:
	/* 0x4cb9: je     49e7 <perf_unwind_native+0x49e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cb9, 0x49e7, x86_l_49e7);
x86_l_4cbf:
	/* 0x4cbf: jmp    4952 <perf_unwind_native+0x4952> */
	X86_SIM_X86_JMP(0x4cbf, 0x4952, x86_l_4952);
x86_l_4cc4:
	/* 0x4cc4: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_4cce:
	/* 0x4cce: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4cd3:
	/* 0x4cd3: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_4cdd:
	/* 0x4cdd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4ce2:
	/* 0x4ce2: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_4cec:
	/* 0x4cec: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4cf1:
	/* 0x4cf1: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_4cfb:
	/* 0x4cfb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d00:
	/* 0x4d00: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_4d0a:
	/* 0x4d0a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d0f:
	/* 0x4d0f: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_4d17:
	/* 0x4d17: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d1c:
	/* 0x4d1c: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_4d21:
	/* 0x4d21: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4d26:
	/* 0x4d26: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d28:
	/* 0x4d28: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d2b:
	/* 0x4d2b: call   4d30 <perf_unwind_native+0x4d30> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4d30:
	/* 0x4d30: jmp    446f <perf_unwind_native+0x446f> */
	X86_SIM_X86_JMP(0x4d30, 0x446f, x86_l_446f);
x86_l_4d35:
	/* 0x4d35: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_4d3f:
	/* 0x4d3f: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_4d47:
	/* 0x4d47: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_4d51:
	/* 0x4d51: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4d59:
	/* 0x4d59: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_4d63:
	/* 0x4d63: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_4d6b:
	/* 0x4d6b: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_4d75:
	/* 0x4d75: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4d7d:
	/* 0x4d7d: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_4d87:
	/* 0x4d87: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4d8f:
	/* 0x4d8f: movabs r14,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_4d99:
	/* 0x4d99: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4da1:
	/* 0x4da1: mov    WORD PTR [rsp+0xc0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 824633720842ULL);
x86_l_4dab:
	/* 0x4dab: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4db3:
	/* 0x4db3: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_4db8:
	/* 0x4db8: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4dbb:
	/* 0x4dbb: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4dbe:
	/* 0x4dbe: call   4dc3 <perf_unwind_native+0x4dc3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4dc3:
	/* 0x4dc3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4dca:
	/* 0x4dca: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4dcd:
	/* 0x4dcd: je     4a9a <perf_unwind_native+0x4a9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dcd, 0x4a9a, x86_l_4a9a);
x86_l_4dd3:
	/* 0x4dd3: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_4ddd:
	/* 0x4ddd: mov    QWORD PTR [rsp+0xb7],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 183ULL);
x86_l_4de5:
	/* 0x4de5: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_4def:
	/* 0x4def: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4df7:
	/* 0x4df7: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_4e01:
	/* 0x4e01: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_4e09:
	/* 0x4e09: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_4e13:
	/* 0x4e13: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4e1b:
	/* 0x4e1b: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_4e25:
	/* 0x4e25: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4e2d:
	/* 0x4e2d: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4e35:
	/* 0x4e35: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4e3c:
	/* 0x4e3c: mov    rdx,QWORD PTR [rbx+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_4e43:
	/* 0x4e43: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4e4b:
	/* 0x4e4b: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_4e50:
	/* 0x4e50: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e53:
	/* 0x4e53: call   4e58 <perf_unwind_native+0x4e58> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4e58:
	/* 0x4e58: jmp    4a9a <perf_unwind_native+0x4a9a> */
	X86_SIM_X86_JMP(0x4e58, 0x4a9a, x86_l_4a9a);
x86_l_4e5d:
	/* 0x4e5d: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_4e67:
	/* 0x4e67: mov    QWORD PTR [rsp+0xa6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_4e6f:
	/* 0x4e6f: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_4e79:
	/* 0x4e79: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4e81:
	/* 0x4e81: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_4e8b:
	/* 0x4e8b: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4e93:
	/* 0x4e93: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_4e9d:
	/* 0x4e9d: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4ea5:
	/* 0x4ea5: movzx  edx,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_4eaa:
	/* 0x4eaa: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4eb2:
	/* 0x4eb2: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_4eb7:
	/* 0x4eb7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4eb9:
	/* 0x4eb9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ebc:
	/* 0x4ebc: call   4ec1 <perf_unwind_native+0x4ec1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4ec1:
	/* 0x4ec1: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_4ec7:
	/* 0x4ec7: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4ecb:
	/* 0x4ecb: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4ece:
	/* 0x4ece: jb     4b1c <perf_unwind_native+0x4b1c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4ece, 0x4b1c, x86_l_4b1c);
x86_l_4ed4:
	/* 0x4ed4: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_4edc:
	/* 0x4edc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_4ee3:
	/* 0x4ee3: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4ee8:
	/* 0x4ee8: call   4eed <perf_unwind_native+0x4eed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4eed:
	/* 0x4eed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ef0:
	/* 0x4ef0: je     4ef7 <perf_unwind_native+0x4ef7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ef0, 0x4ef7, x86_l_4ef7);
x86_l_4ef2:
	/* 0x4ef2: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4ef5:
	/* 0x4ef5: jmp    4f07 <perf_unwind_native+0x4f07> */
	X86_SIM_X86_JMP(0x4ef5, 0x4f07, x86_l_4f07);
x86_l_4ef7:
	/* 0x4ef7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4efe:
	/* 0x4efe: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f01:
	/* 0x4f01: jne    5a2b <perf_unwind_native+0x5a2b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f01, 0x5a2b, x86_l_5a2b);
x86_l_4f07:
	/* 0x4f07: movzx  r12d,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_4f0c:
	/* 0x4f0c: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4f10:
	/* 0x4f10: jne    6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f10, 0x6e79, x86_l_6e79);
x86_l_4f16:
	/* 0x4f16: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4f1d:
	/* 0x4f1d: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f20:
	/* 0x4f20: jne    5782 <perf_unwind_native+0x5782> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4f20, 0x5782, x86_l_5782);
x86_l_4f26:
	/* 0x4f26: mov    DWORD PTR [rsp+0x10],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476741ULL);
x86_l_4f2e:
	/* 0x4f2e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_4f35:
	/* 0x4f35: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f3a:
	/* 0x4f3a: call   4f3f <perf_unwind_native+0x4f3f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4f3f:
	/* 0x4f3f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f42:
	/* 0x4f42: je     4fe9 <perf_unwind_native+0x4fe9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f42, 0x4fe9, x86_l_4fe9);
x86_l_4f48:
	/* 0x4f48: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_4f4b:
	/* 0x4f4b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4f52:
	/* 0x4f52: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f55:
	/* 0x4f55: je     4ff9 <perf_unwind_native+0x4ff9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f55, 0x4ff9, x86_l_4ff9);
x86_l_4f5b:
	/* 0x4f5b: movabs rax,0x63617473206e6f20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7161132920309968672ULL);
x86_l_4f65:
	/* 0x4f65: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4f6d:
	/* 0x4f6d: movabs rax,0x7525206e6f697469 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8441188735263536233ULL);
x86_l_4f77:
	/* 0x4f77: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_4f7f:
	/* 0x4f7f: movabs rax,0x736f70206f742078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8317990321387741304ULL);
x86_l_4f89:
	/* 0x4f89: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4f91:
	/* 0x4f91: movabs rax,0x6c6c2520786c6c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274970520613ULL);
x86_l_4f9b:
	/* 0x4f9b: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4fa3:
	/* 0x4fa3: movabs rax,0x20676e6968737550 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334956330817910096ULL);
x86_l_4fad:
	/* 0x4fad: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4fb5:
	/* 0x4fb5: mov    DWORD PTR [rsp+0xb7],0xa6b63 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 785979698019ULL);
x86_l_4fc0:
	/* 0x4fc0: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_4fc7:
	/* 0x4fc7: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_4fce:
	/* 0x4fce: mov    r8d,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4fd5:
	/* 0x4fd5: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4fdd:
	/* 0x4fdd: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_4fe2:
	/* 0x4fe2: call   4fe7 <perf_unwind_native+0x4fe7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_4fe7:
	/* 0x4fe7: jmp    4ff9 <perf_unwind_native+0x4ff9> */
	X86_SIM_X86_JMP(0x4fe7, 0x4ff9, x86_l_4ff9);
x86_l_4fe9:
	/* 0x4fe9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_4ff0:
	/* 0x4ff0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ff3:
	/* 0x4ff3: jne    5885 <perf_unwind_native+0x5885> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4ff3, 0x5885, x86_l_5885);
x86_l_4ff9:
	/* 0x4ff9: mov    eax,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_4fff:
	/* 0x4fff: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_5003:
	/* 0x5003: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5008:
	/* 0x5008: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_500f:
	/* 0x500f: ja     12d <perf_unwind_native+0x12d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x500f, 0x12d, x86_l_12d);
x86_l_5015:
	/* 0x5015: movzx  ecx,BYTE PTR [rbx+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_501c:
	/* 0x501c: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_5023:
	/* 0x5023: mov    rsi,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_502a:
	/* 0x502a: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_502d:
	/* 0x502d: mov    DWORD PTR [rbx+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5033:
	/* 0x5033: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_5037:
	/* 0x5037: mov    QWORD PTR [rbx+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_503f:
	/* 0x503f: mov    QWORD PTR [rbx+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_5047:
	/* 0x5047: mov    BYTE PTR [rbx+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_504f:
	/* 0x504f: mov    BYTE PTR [rbx+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_5056:
	/* 0x5056: mov    DWORD PTR [rbx+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_5061:
	/* 0x5061: mov    WORD PTR [rbx+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_506b:
	/* 0x506b: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_5073:
	/* 0x5073: mov    rdx,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_507a:
	/* 0x507a: mov    QWORD PTR [rsp+0x150],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_5082:
	/* 0x5082: mov    QWORD PTR [rsp+0x70],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5087:
	/* 0x5087: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_508e:
	/* 0x508e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5091:
	/* 0x5091: and    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_AND, 18446744073709486080ULL);
x86_l_5097:
	/* 0x5097: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_509c:
	/* 0x509c: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50a1:
	/* 0x50a1: jne    582d <perf_unwind_native+0x582d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x50a1, 0x582d, x86_l_582d);
x86_l_50a7:
	/* 0x50a7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_50ae:
	/* 0x50ae: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_50b3:
	/* 0x50b3: call   50b8 <perf_unwind_native+0x50b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_50b8:
	/* 0x50b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_50bb:
	/* 0x50bb: je     5100 <perf_unwind_native+0x5100> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50bb, 0x5100, x86_l_5100);
x86_l_50bd:
	/* 0x50bd: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_50c0:
	/* 0x50c0: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_50c4:
	/* 0x50c4: movzx  ecx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_50c7:
	/* 0x50c7: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_50ca:
	/* 0x50ca: jg     51a4 <perf_unwind_native+0x51a4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x50ca, 0x51a4, x86_l_51a4);
x86_l_50d0:
	/* 0x50d0: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_50d3:
	/* 0x50d3: jg     51cc <perf_unwind_native+0x51cc> */
	X86_SIM_X86_JCC(X86_CC_G, 0x50d3, 0x51cc, x86_l_51cc);
x86_l_50d9:
	/* 0x50d9: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_50dc:
	/* 0x50dc: jg     520e <perf_unwind_native+0x520e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x50dc, 0x520e, x86_l_520e);
x86_l_50e2:
	/* 0x50e2: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_50e5:
	/* 0x50e5: je     5323 <perf_unwind_native+0x5323> */
	X86_SIM_X86_JCC(X86_CC_E, 0x50e5, 0x5323, x86_l_5323);
x86_l_50eb:
	/* 0x50eb: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_50ee:
	/* 0x50ee: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x50ee, 0x5276, x86_l_5276);
x86_l_50f4:
	/* 0x50f4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas));
x86_l_50fb:
	/* 0x50fb: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x50fb, 0x5369, x86_l_5369);
x86_l_5100:
	/* 0x5100: mov    r13d,0xfa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4000ULL);
x86_l_5106:
	/* 0x5106: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_510b:
	/* 0x510b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5112:
	/* 0x5112: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5115:
	/* 0x5115: je     540c <perf_unwind_native+0x540c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5115, 0x540c, x86_l_540c);
x86_l_511b:
	/* 0x511b: movabs rax,0x786c252065676170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8677351403106558320ULL);
x86_l_5125:
	/* 0x5125: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_512a:
	/* 0x512a: movabs rax,0x202c786c25204449 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2318360314063635529ULL);
x86_l_5134:
	/* 0x5134: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5139:
	/* 0x5139: movabs rax,0x656c696620656761 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7308332182666569569ULL);
x86_l_5143:
	/* 0x5143: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5148:
	/* 0x5148: movabs rax,0x702061746c656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8079564884165354528ULL);
x86_l_5152:
	/* 0x5152: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5157:
	/* 0x5157: movabs rax,0x6b63617473207075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7738135737528250485ULL);
x86_l_5161:
	/* 0x5161: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5166:
	/* 0x5166: movabs rax,0x206b6f6f6c206f74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2336083356067852148ULL);
x86_l_5170:
	/* 0x5170: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5175:
	/* 0x5175: movabs rax,0x206572756c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334397830517055814ULL);
x86_l_517f:
	/* 0x517f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5184:
	/* 0x5184: mov    WORD PTR [rsp+0x48],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 309237645322ULL);
x86_l_518b:
	/* 0x518b: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5190:
	/* 0x5190: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_5195:
	/* 0x5195: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_519a:
	/* 0x519a: mov    esi,0x3a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 58ULL);
x86_l_519f:
	/* 0x519f: jmp    5671 <perf_unwind_native+0x5671> */
	X86_SIM_X86_JMP(0x519f, 0x5671, x86_l_5671);
x86_l_51a4:
	/* 0x51a4: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_51a7:
	/* 0x51a7: jg     51ef <perf_unwind_native+0x51ef> */
	X86_SIM_X86_JCC(X86_CC_G, 0x51a7, 0x51ef, x86_l_51ef);
x86_l_51a9:
	/* 0x51a9: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_51ac:
	/* 0x51ac: jg     5228 <perf_unwind_native+0x5228> */
	X86_SIM_X86_JCC(X86_CC_G, 0x51ac, 0x5228, x86_l_5228);
x86_l_51ae:
	/* 0x51ae: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_51b1:
	/* 0x51b1: je     532c <perf_unwind_native+0x532c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51b1, 0x532c, x86_l_532c);
x86_l_51b7:
	/* 0x51b7: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_51ba:
	/* 0x51ba: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51ba, 0x5276, x86_l_5276);
x86_l_51c0:
	/* 0x51c0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas));
x86_l_51c7:
	/* 0x51c7: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x51c7, 0x5369, x86_l_5369);
x86_l_51cc:
	/* 0x51cc: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_51cf:
	/* 0x51cf: jg     5242 <perf_unwind_native+0x5242> */
	X86_SIM_X86_JCC(X86_CC_G, 0x51cf, 0x5242, x86_l_5242);
x86_l_51d1:
	/* 0x51d1: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_51d4:
	/* 0x51d4: je     5335 <perf_unwind_native+0x5335> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51d4, 0x5335, x86_l_5335);
x86_l_51da:
	/* 0x51da: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_51dd:
	/* 0x51dd: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x51dd, 0x5276, x86_l_5276);
x86_l_51e3:
	/* 0x51e3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas));
x86_l_51ea:
	/* 0x51ea: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x51ea, 0x5369, x86_l_5369);
x86_l_51ef:
	/* 0x51ef: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_51f2:
	/* 0x51f2: jg     525c <perf_unwind_native+0x525c> */
	X86_SIM_X86_JCC(X86_CC_G, 0x51f2, 0x525c, x86_l_525c);
x86_l_51f4:
	/* 0x51f4: cmp    ecx,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_51f7:
	/* 0x51f7: je     533e <perf_unwind_native+0x533e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51f7, 0x533e, x86_l_533e);
x86_l_51fd:
	/* 0x51fd: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_5200:
	/* 0x5200: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5200, 0x5276, x86_l_5276);
x86_l_5202:
	/* 0x5202: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas));
x86_l_5209:
	/* 0x5209: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5209, 0x5369, x86_l_5369);
x86_l_520e:
	/* 0x520e: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_5211:
	/* 0x5211: je     5347 <perf_unwind_native+0x5347> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5211, 0x5347, x86_l_5347);
x86_l_5217:
	/* 0x5217: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_521a:
	/* 0x521a: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x521a, 0x5276, x86_l_5276);
x86_l_521c:
	/* 0x521c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas));
x86_l_5223:
	/* 0x5223: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5223, 0x5369, x86_l_5369);
x86_l_5228:
	/* 0x5228: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_522b:
	/* 0x522b: je     5350 <perf_unwind_native+0x5350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x522b, 0x5350, x86_l_5350);
x86_l_5231:
	/* 0x5231: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_5234:
	/* 0x5234: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5234, 0x5276, x86_l_5276);
x86_l_5236:
	/* 0x5236: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas));
x86_l_523d:
	/* 0x523d: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x523d, 0x5369, x86_l_5369);
x86_l_5242:
	/* 0x5242: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_5245:
	/* 0x5245: je     5359 <perf_unwind_native+0x5359> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5245, 0x5359, x86_l_5359);
x86_l_524b:
	/* 0x524b: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_524e:
	/* 0x524e: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x524e, 0x5276, x86_l_5276);
x86_l_5250:
	/* 0x5250: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas));
x86_l_5257:
	/* 0x5257: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5257, 0x5369, x86_l_5369);
x86_l_525c:
	/* 0x525c: cmp    ecx,0x16 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_525f:
	/* 0x525f: je     5362 <perf_unwind_native+0x5362> */
	X86_SIM_X86_JCC(X86_CC_E, 0x525f, 0x5362, x86_l_5362);
x86_l_5265:
	/* 0x5265: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_5268:
	/* 0x5268: jne    5276 <perf_unwind_native+0x5276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5268, 0x5276, x86_l_5276);
x86_l_526a:
	/* 0x526a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas));
x86_l_5271:
	/* 0x5271: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5271, 0x5369, x86_l_5369);
x86_l_5276:
	/* 0x5276: mov    r13d,0xfa1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4001ULL);
x86_l_527c:
	/* 0x527c: mov    ebp,0x33 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_5281:
	/* 0x5281: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5288:
	/* 0x5288: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_528b:
	/* 0x528b: je     540c <perf_unwind_native+0x540c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x528b, 0x540c, x86_l_540c);
x86_l_5291:
	/* 0x5291: movabs rcx,0xa642520444970 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020272ULL);
x86_l_529b:
	/* 0x529b: mov    QWORD PTR [rsp+0x47],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_52a0:
	/* 0x52a0: movabs rcx,0x70616d206e692078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8097873591047626872ULL);
x86_l_52aa:
	/* 0x52aa: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_52af:
	/* 0x52af: movabs rcx,0x6c25206e6f697463 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670388922184803ULL);
x86_l_52b9:
	/* 0x52b9: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_52be:
	/* 0x52be: movabs rcx,0x6573207478657420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222304760656928ULL);
x86_l_52c8:
	/* 0x52c8: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_52cd:
	/* 0x52cd: movabs rcx,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_52d7:
	/* 0x52d7: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_52dc:
	/* 0x52dc: movabs rcx,0x726574756f207075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 8243122740695953525ULL);
x86_l_52e6:
	/* 0x52e6: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_52eb:
	/* 0x52eb: movabs rcx,0x206b6f6f6c206f74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2336083356067852148ULL);
x86_l_52f5:
	/* 0x52f5: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_52fa:
	/* 0x52fa: movabs rcx,0x206572756c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2334397830517055814ULL);
x86_l_5304:
	/* 0x5304: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5309:
	/* 0x5309: mov    rdx,QWORD PTR [rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_5311:
	/* 0x5311: movzx  ecx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_5314:
	/* 0x5314: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5319:
	/* 0x5319: mov    esi,0x3f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 63ULL);
x86_l_531e:
	/* 0x531e: jmp    5671 <perf_unwind_native+0x5671> */
	X86_SIM_X86_JMP(0x531e, 0x5671, x86_l_5671);
x86_l_5323:
	/* 0x5323: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas));
x86_l_532a:
	/* 0x532a: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x532a, 0x5369, x86_l_5369);
x86_l_532c:
	/* 0x532c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas));
x86_l_5333:
	/* 0x5333: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5333, 0x5369, x86_l_5369);
x86_l_5335:
	/* 0x5335: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas));
x86_l_533c:
	/* 0x533c: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x533c, 0x5369, x86_l_5369);
x86_l_533e:
	/* 0x533e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas));
x86_l_5345:
	/* 0x5345: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5345, 0x5369, x86_l_5369);
x86_l_5347:
	/* 0x5347: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas));
x86_l_534e:
	/* 0x534e: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x534e, 0x5369, x86_l_5369);
x86_l_5350:
	/* 0x5350: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas));
x86_l_5357:
	/* 0x5357: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5357, 0x5369, x86_l_5369);
x86_l_5359:
	/* 0x5359: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas));
x86_l_5360:
	/* 0x5360: jmp    5369 <perf_unwind_native+0x5369> */
	X86_SIM_X86_JMP(0x5360, 0x5369, x86_l_5369);
x86_l_5362:
	/* 0x5362: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas));
x86_l_5369:
	/* 0x5369: lea    rsi,[rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_5371:
	/* 0x5371: call   5376 <perf_unwind_native+0x5376> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5376:
	/* 0x5376: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5379:
	/* 0x5379: je     53f1 <perf_unwind_native+0x53f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5379, 0x53f1, x86_l_53f1);
x86_l_537b:
	/* 0x537b: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_537e:
	/* 0x537e: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5382:
	/* 0x5382: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_5387:
	/* 0x5387: mov    rax,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_538e:
	/* 0x538e: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5393:
	/* 0x5393: movzx  r15d,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_5399:
	/* 0x5399: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_539c:
	/* 0x539c: je     5cd3 <perf_unwind_native+0x5cd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x539c, 0x5cd3, x86_l_5cd3);
x86_l_53a2:
	/* 0x53a2: add    r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_53a5:
	/* 0x53a5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_53ac:
	/* 0x53ac: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53af:
	/* 0x53af: jne    5969 <perf_unwind_native+0x5969> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x53af, 0x5969, x86_l_5969);
x86_l_53b5:
	/* 0x53b5: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_53b9:
	/* 0x53b9: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_53bb:
	/* 0x53bb: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53bf:
	/* 0x53bf: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53c4:
	/* 0x53c4: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_53c7:
	/* 0x53c7: call   53cc <perf_unwind_native+0x53cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53cc:
	/* 0x53cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53cf:
	/* 0x53cf: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53cf, 0x5d95, x86_l_5d95);
x86_l_53d5:
	/* 0x53d5: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53d9:
	/* 0x53d9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_53de:
	/* 0x53de: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53e1:
	/* 0x53e1: ja     567e <perf_unwind_native+0x567e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x53e1, 0x567e, x86_l_567e);
x86_l_53e7:
	/* 0x53e7: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_53e9:
	/* 0x53e9: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_53ec:
	/* 0x53ec: jmp    5681 <perf_unwind_native+0x5681> */
	X86_SIM_X86_JMP(0x53ec, 0x5681, x86_l_5681);
x86_l_53f1:
	/* 0x53f1: mov    r13d,0xfa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4002ULL);
x86_l_53f7:
	/* 0x53f7: mov    ebp,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_53fc:
	/* 0x53fc: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5403:
	/* 0x5403: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5406:
	/* 0x5406: jne    55fb <perf_unwind_native+0x55fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5406, 0x55fb, x86_l_55fb);
x86_l_540c:
	/* 0x540c: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5411:
	/* 0x5411: mov    DWORD PTR [rbx+0xf28],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3880ULL);
x86_l_5417:
	/* 0x5417: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_541a:
	/* 0x541a: mov    ebp,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_541d:
	/* 0x541d: mov    DWORD PTR [rbx+0xf2c],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3884ULL);
x86_l_5423:
	/* 0x5423: mov    DWORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_542e:
	/* 0x542e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_5435:
	/* 0x5435: lea    rsi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_543d:
	/* 0x543d: call   5442 <perf_unwind_native+0x5442> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5442:
	/* 0x5442: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5445:
	/* 0x5445: je     5486 <perf_unwind_native+0x5486> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5445, 0x5486, x86_l_5486);
x86_l_5447:
	/* 0x5447: movzx  ecx,BYTE PTR [rax+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_544e:
	/* 0x544e: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_5451:
	/* 0x5451: cmp    cl,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 29ULL);
x86_l_5454:
	/* 0x5454: jb     54a6 <perf_unwind_native+0x54a6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5454, 0x54a6, x86_l_54a6);
x86_l_5456:
	/* 0x5456: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5459:
	/* 0x5459: mov    DWORD PTR [rax+0xf2c],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16681652977669ULL);
x86_l_5463:
	/* 0x5463: mov    DWORD PTR [rsp+0x10],0x44 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476804ULL);
x86_l_546b:
	/* 0x546b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5472:
	/* 0x5472: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5477:
	/* 0x5477: call   547c <perf_unwind_native+0x547c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_547c:
	/* 0x547c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_547f:
	/* 0x547f: je     548a <perf_unwind_native+0x548a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x547f, 0x548a, x86_l_548a);
x86_l_5481:
	/* 0x5481: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5484:
	/* 0x5484: jmp    549a <perf_unwind_native+0x549a> */
	X86_SIM_X86_JMP(0x5484, 0x549a, x86_l_549a);
x86_l_5486:
	/* 0x5486: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5488:
	/* 0x5488: jmp    54ae <perf_unwind_native+0x54ae> */
	X86_SIM_X86_JMP(0x5488, 0x54ae, x86_l_54ae);
x86_l_548a:
	/* 0x548a: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5491:
	/* 0x5491: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5494:
	/* 0x5494: jne    556f <perf_unwind_native+0x556f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5494, 0x556f, x86_l_556f);
x86_l_549a:
	/* 0x549a: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_549d:
	/* 0x549d: movzx  ecx,BYTE PTR [rbx+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_54a4:
	/* 0x54a4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_54a6:
	/* 0x54a6: inc    cl */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_54a8:
	/* 0x54a8: mov    BYTE PTR [rax+0x1384],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4996ULL);
x86_l_54ae:
	/* 0x54ae: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)perf_progs));
x86_l_54b5:
	/* 0x54b5: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_54b8:
	/* 0x54b8: call   54bd <perf_unwind_native+0x54bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_54bd:
	/* 0x54bd: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_54c4:
	/* 0x54c4: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54c7:
	/* 0x54c7: jne    54e4 <perf_unwind_native+0x54e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x54c7, 0x54e4, x86_l_54e4);
x86_l_54c9:
	/* 0x54c9: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_54ce:
	/* 0x54ce: add    rsp,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_54d5:
	/* 0x54d5: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54d6:
	/* 0x54d6: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54d8:
	/* 0x54d8: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54da:
	/* 0x54da: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54dc:
	/* 0x54dc: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54de:
	/* 0x54de: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54df:
	/* 0x54df: jmp    6f0f <perf_unwind_native+0x6f0f> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_54e4:
	/* 0x54e4: movabs rax,0xa65766974616e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926309016887662ULL);
x86_l_54ee:
	/* 0x54ee: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_54f6:
	/* 0x54f6: movabs rax,0x616e5f646e69776e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7020653754070955886ULL);
x86_l_5500:
	/* 0x5500: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_5508:
	/* 0x5508: movabs rax,0x75206e6920642520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8439867099486364960ULL);
x86_l_5512:
	/* 0x5512: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_551a:
	/* 0x551a: movabs rax,0x726f662064656c69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732048022633ULL);
x86_l_5524:
	/* 0x5524: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_552c:
	/* 0x552c: movabs rax,0x6166206c6c616320 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018332719350375200ULL);
x86_l_5536:
	/* 0x5536: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_553e:
	/* 0x553e: movabs rax,0x6c6961745f667062 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7811882181095485538ULL);
x86_l_5548:
	/* 0x5548: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_5550:
	/* 0x5550: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_5553:
	/* 0x5553: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_555b:
	/* 0x555b: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5560:
	/* 0x5560: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5562:
	/* 0x5562: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5565:
	/* 0x5565: call   556a <perf_unwind_native+0x556a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_556a:
	/* 0x556a: jmp    54c9 <perf_unwind_native+0x54c9> */
	X86_SIM_X86_JMP(0x556a, 0x54c9, x86_l_54c9);
x86_l_556f:
	/* 0x556f: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_5579:
	/* 0x5579: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_5581:
	/* 0x5581: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_558b:
	/* 0x558b: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_5593:
	/* 0x5593: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_559d:
	/* 0x559d: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_55a5:
	/* 0x55a5: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_55af:
	/* 0x55af: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_55b7:
	/* 0x55b7: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_55c1:
	/* 0x55c1: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_55c9:
	/* 0x55c9: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_55d3:
	/* 0x55d3: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_55db:
	/* 0x55db: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_55df:
	/* 0x55df: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_55e7:
	/* 0x55e7: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_55ec:
	/* 0x55ec: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_55ee:
	/* 0x55ee: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_55f1:
	/* 0x55f1: call   55f6 <perf_unwind_native+0x55f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_55f6:
	/* 0x55f6: jmp    549a <perf_unwind_native+0x549a> */
	X86_SIM_X86_JMP(0x55f6, 0x549a, x86_l_549a);
x86_l_55fb:
	/* 0x55fb: movabs rax,0x6c25206e6f697463 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670388922184803ULL);
x86_l_5605:
	/* 0x5605: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_560a:
	/* 0x560a: movabs rax,0x6573207478657420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310222304760656928ULL);
x86_l_5614:
	/* 0x5614: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5619:
	/* 0x5619: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5623:
	/* 0x5623: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5628:
	/* 0x5628: movabs rax,0x72656e6e69207075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243116113460752501ULL);
x86_l_5632:
	/* 0x5632: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5637:
	/* 0x5637: movabs rax,0x206b6f6f6c206f74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2336083356067852148ULL);
x86_l_5641:
	/* 0x5641: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5646:
	/* 0x5646: movabs rax,0x206572756c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334397830517055814ULL);
x86_l_5650:
	/* 0x5650: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5655:
	/* 0x5655: mov    DWORD PTR [rsp+0x3f],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 270583625836ULL);
x86_l_565d:
	/* 0x565d: mov    rdx,QWORD PTR [rsp+0x150] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_5665:
	/* 0x5665: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_566a:
	/* 0x566a: mov    esi,0x33 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_566f:
	/* 0x566f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5671:
	/* 0x5671: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5674:
	/* 0x5674: call   5679 <perf_unwind_native+0x5679> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5679:
	/* 0x5679: jmp    540c <perf_unwind_native+0x540c> */
	X86_SIM_X86_JMP(0x5679, 0x540c, x86_l_540c);
x86_l_567e:
	/* 0x567e: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5681:
	/* 0x5681: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5684:
	/* 0x5684: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5684, 0x5cc7, x86_l_5cc7);
x86_l_568a:
	/* 0x568a: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_568e:
	/* 0x568e: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5690:
	/* 0x5690: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5694:
	/* 0x5694: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5699:
	/* 0x5699: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_569c:
	/* 0x569c: call   56a1 <perf_unwind_native+0x56a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56a1:
	/* 0x56a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56a4:
	/* 0x56a4: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56a4, 0x5d95, x86_l_5d95);
x86_l_56aa:
	/* 0x56aa: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_56ae:
	/* 0x56ae: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_56b3:
	/* 0x56b3: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56b6:
	/* 0x56b6: ja     56bf <perf_unwind_native+0x56bf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x56b6, 0x56bf, x86_l_56bf);
x86_l_56b8:
	/* 0x56b8: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_56ba:
	/* 0x56ba: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_56bd:
	/* 0x56bd: jmp    56c2 <perf_unwind_native+0x56c2> */
	X86_SIM_X86_JMP(0x56bd, 0x56c2, x86_l_56c2);
x86_l_56bf:
	/* 0x56bf: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_56c2:
	/* 0x56c2: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_56c5:
	/* 0x56c5: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x56c5, 0x5cc7, x86_l_5cc7);
x86_l_56cb:
	/* 0x56cb: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_56cf:
	/* 0x56cf: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_56d1:
	/* 0x56d1: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_56d5:
	/* 0x56d5: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_56da:
	/* 0x56da: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_56dd:
	/* 0x56dd: call   56e2 <perf_unwind_native+0x56e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56e2:
	/* 0x56e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56e5:
	/* 0x56e5: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56e5, 0x5d95, x86_l_5d95);
x86_l_56eb:
	/* 0x56eb: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_56ef:
	/* 0x56ef: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_56f4:
	/* 0x56f4: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56f7:
	/* 0x56f7: ja     5700 <perf_unwind_native+0x5700> */
	X86_SIM_X86_JCC(X86_CC_A, 0x56f7, 0x5700, x86_l_5700);
x86_l_56f9:
	/* 0x56f9: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_56fb:
	/* 0x56fb: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_56fe:
	/* 0x56fe: jmp    5703 <perf_unwind_native+0x5703> */
	X86_SIM_X86_JMP(0x56fe, 0x5703, x86_l_5703);
x86_l_5700:
	/* 0x5700: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5703:
	/* 0x5703: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5706:
	/* 0x5706: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5706, 0x5cc7, x86_l_5cc7);
x86_l_570c:
	/* 0x570c: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5710:
	/* 0x5710: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5712:
	/* 0x5712: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5716:
	/* 0x5716: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_571b:
	/* 0x571b: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_571e:
	/* 0x571e: call   5723 <perf_unwind_native+0x5723> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5723:
	/* 0x5723: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5726:
	/* 0x5726: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5726, 0x5d95, x86_l_5d95);
x86_l_572c:
	/* 0x572c: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5730:
	/* 0x5730: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5735:
	/* 0x5735: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5738:
	/* 0x5738: ja     5741 <perf_unwind_native+0x5741> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5738, 0x5741, x86_l_5741);
x86_l_573a:
	/* 0x573a: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_573c:
	/* 0x573c: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_573f:
	/* 0x573f: jmp    5744 <perf_unwind_native+0x5744> */
	X86_SIM_X86_JMP(0x573f, 0x5744, x86_l_5744);
x86_l_5741:
	/* 0x5741: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5744:
	/* 0x5744: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5747:
	/* 0x5747: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5747, 0x5cc7, x86_l_5cc7);
x86_l_574d:
	/* 0x574d: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5751:
	/* 0x5751: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5753:
	/* 0x5753: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5757:
	/* 0x5757: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_575c:
	/* 0x575c: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_575f:
	/* 0x575f: call   5764 <perf_unwind_native+0x5764> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5764:
	/* 0x5764: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5767:
	/* 0x5767: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5767, 0x5d95, x86_l_5d95);
x86_l_576d:
	/* 0x576d: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5771:
	/* 0x5771: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5776:
	/* 0x5776: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5779:
	/* 0x5779: ja     57e5 <perf_unwind_native+0x57e5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5779, 0x57e5, x86_l_57e5);
x86_l_577b:
	/* 0x577b: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_577d:
	/* 0x577d: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5780:
	/* 0x5780: jmp    57e8 <perf_unwind_native+0x57e8> */
	X86_SIM_X86_JMP(0x5780, 0x57e8, x86_l_57e8);
x86_l_5782:
	/* 0x5782: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_5788:
	/* 0x5788: movabs rax,0x3d3d206425206576 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4412718824384652662ULL);
x86_l_5792:
	/* 0x5792: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_579a:
	/* 0x579a: movabs rax,0x6974616e5f646e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7598805597955583593ULL);
x86_l_57a4:
	/* 0x57a4: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_57ac:
	/* 0x57ac: movabs rax,0x776e75203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8605944719278423357ULL);
x86_l_57b6:
	/* 0x57b6: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_57be:
	/* 0x57be: mov    DWORD PTR [rsp+0xa8],0xa3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721555176765ULL);
x86_l_57c9:
	/* 0x57c9: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_57d1:
	/* 0x57d1: mov    esi,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_57d6:
	/* 0x57d6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57d8:
	/* 0x57d8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57db:
	/* 0x57db: call   57e0 <perf_unwind_native+0x57e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_57e0:
	/* 0x57e0: jmp    4f26 <perf_unwind_native+0x4f26> */
	X86_SIM_X86_JMP(0x57e0, 0x4f26, x86_l_4f26);
x86_l_57e5:
	/* 0x57e5: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_57e8:
	/* 0x57e8: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_57eb:
	/* 0x57eb: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x57eb, 0x5cc7, x86_l_5cc7);
x86_l_57f1:
	/* 0x57f1: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_57f5:
	/* 0x57f5: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_57f7:
	/* 0x57f7: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57fb:
	/* 0x57fb: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5800:
	/* 0x5800: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5803:
	/* 0x5803: call   5808 <perf_unwind_native+0x5808> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5808:
	/* 0x5808: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_580b:
	/* 0x580b: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x580b, 0x5d95, x86_l_5d95);
x86_l_5811:
	/* 0x5811: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5815:
	/* 0x5815: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_581a:
	/* 0x581a: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_581d:
	/* 0x581d: ja     5921 <perf_unwind_native+0x5921> */
	X86_SIM_X86_JCC(X86_CC_A, 0x581d, 0x5921, x86_l_5921);
x86_l_5823:
	/* 0x5823: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5825:
	/* 0x5825: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5828:
	/* 0x5828: jmp    5924 <perf_unwind_native+0x5924> */
	X86_SIM_X86_JMP(0x5828, 0x5924, x86_l_5924);
x86_l_582d:
	/* 0x582d: movabs rax,0xa786c253a786c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471844735118373ULL);
x86_l_5837:
	/* 0x5837: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_583c:
	/* 0x583c: movabs rax,0x20726f662061746c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2338053640979313772ULL);
x86_l_5846:
	/* 0x5846: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_584b:
	/* 0x584b: movabs rax,0x6564206b63617473 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7306000141102707827ULL);
x86_l_5855:
	/* 0x5855: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_585a:
	/* 0x585a: movabs rax,0x207075206b6f6f4c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337496988707155788ULL);
x86_l_5864:
	/* 0x5864: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5869:
	/* 0x5869: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_586e:
	/* 0x586e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5873:
	/* 0x5873: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_5878:
	/* 0x5878: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_587b:
	/* 0x587b: call   5880 <perf_unwind_native+0x5880> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5880:
	/* 0x5880: jmp    50a7 <perf_unwind_native+0x50a7> */
	X86_SIM_X86_JMP(0x5880, 0x50a7, x86_l_50a7);
x86_l_5885:
	/* 0x5885: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_588f:
	/* 0x588f: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_5897:
	/* 0x5897: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_58a1:
	/* 0x58a1: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_58a9:
	/* 0x58a9: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_58b3:
	/* 0x58b3: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_58bb:
	/* 0x58bb: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_58c5:
	/* 0x58c5: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_58cd:
	/* 0x58cd: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_58d7:
	/* 0x58d7: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_58df:
	/* 0x58df: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_58e9:
	/* 0x58e9: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_58f1:
	/* 0x58f1: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58f5:
	/* 0x58f5: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_58fd:
	/* 0x58fd: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5902:
	/* 0x5902: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5904:
	/* 0x5904: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5907:
	/* 0x5907: call   590c <perf_unwind_native+0x590c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_590c:
	/* 0x590c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5913:
	/* 0x5913: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5916:
	/* 0x5916: je     4ff9 <perf_unwind_native+0x4ff9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5916, 0x4ff9, x86_l_4ff9);
x86_l_591c:
	/* 0x591c: jmp    4f5b <perf_unwind_native+0x4f5b> */
	X86_SIM_X86_JMP(0x591c, 0x4f5b, x86_l_4f5b);
x86_l_5921:
	/* 0x5921: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5924:
	/* 0x5924: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5927:
	/* 0x5927: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5927, 0x5cc7, x86_l_5cc7);
x86_l_592d:
	/* 0x592d: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5931:
	/* 0x5931: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5933:
	/* 0x5933: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5937:
	/* 0x5937: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_593c:
	/* 0x593c: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_593f:
	/* 0x593f: call   5944 <perf_unwind_native+0x5944> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5944:
	/* 0x5944: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5947:
	/* 0x5947: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5947, 0x5d95, x86_l_5d95);
x86_l_594d:
	/* 0x594d: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5951:
	/* 0x5951: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5956:
	/* 0x5956: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5959:
	/* 0x5959: ja     59e3 <perf_unwind_native+0x59e3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5959, 0x59e3, x86_l_59e3);
x86_l_595f:
	/* 0x595f: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5961:
	/* 0x5961: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5964:
	/* 0x5964: jmp    59e6 <perf_unwind_native+0x59e6> */
	X86_SIM_X86_JMP(0x5964, 0x59e6, x86_l_59e6);
x86_l_5969:
	/* 0x5969: movabs rax,0xa296425204449 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2860259863446601ULL);
x86_l_5973:
	/* 0x5973: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5978:
	/* 0x5978: movabs rax,0x70616d2820756c25 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8097873624099548197ULL);
x86_l_5982:
	/* 0x5982: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5987:
	/* 0x5987: movabs rax,0x206f7420756c2520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2337214414386373920ULL);
x86_l_5991:
	/* 0x5991: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5996:
	/* 0x5996: movabs rax,0x6d6f726620656220 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7885647255504773664ULL);
x86_l_59a0:
	/* 0x59a0: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_59a5:
	/* 0x59a5: movabs rax,0x646c756f68732073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7236287822631739507ULL);
x86_l_59af:
	/* 0x59af: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_59b4:
	/* 0x59b4: movabs rax,0x6c61767265746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7809653462537629257ULL);
x86_l_59be:
	/* 0x59be: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_59c3:
	/* 0x59c3: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_59c6:
	/* 0x59c6: movzx  r8d,WORD PTR [r12+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_59cc:
	/* 0x59cc: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_59d1:
	/* 0x59d1: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_59d6:
	/* 0x59d6: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_59d9:
	/* 0x59d9: call   59de <perf_unwind_native+0x59de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_59de:
	/* 0x59de: jmp    53b5 <perf_unwind_native+0x53b5> */
	X86_SIM_X86_JMP(0x59de, 0x53b5, x86_l_53b5);
x86_l_59e3:
	/* 0x59e3: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_59e6:
	/* 0x59e6: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_59e9:
	/* 0x59e9: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x59e9, 0x5cc7, x86_l_5cc7);
x86_l_59ef:
	/* 0x59ef: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_59f3:
	/* 0x59f3: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_59f5:
	/* 0x59f5: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_59f9:
	/* 0x59f9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_59fe:
	/* 0x59fe: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5a01:
	/* 0x5a01: call   5a06 <perf_unwind_native+0x5a06> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5a06:
	/* 0x5a06: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a09:
	/* 0x5a09: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a09, 0x5d95, x86_l_5d95);
x86_l_5a0f:
	/* 0x5a0f: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5a13:
	/* 0x5a13: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5a18:
	/* 0x5a18: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a1b:
	/* 0x5a1b: ja     5ab7 <perf_unwind_native+0x5ab7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5a1b, 0x5ab7, x86_l_5ab7);
x86_l_5a21:
	/* 0x5a21: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5a23:
	/* 0x5a23: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5a26:
	/* 0x5a26: jmp    5aba <perf_unwind_native+0x5aba> */
	X86_SIM_X86_JMP(0x5a26, 0x5aba, x86_l_5aba);
x86_l_5a2b:
	/* 0x5a2b: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_5a35:
	/* 0x5a35: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_5a3d:
	/* 0x5a3d: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_5a47:
	/* 0x5a47: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_5a4f:
	/* 0x5a4f: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5a59:
	/* 0x5a59: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_5a61:
	/* 0x5a61: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_5a6b:
	/* 0x5a6b: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_5a73:
	/* 0x5a73: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_5a7d:
	/* 0x5a7d: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_5a85:
	/* 0x5a85: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_5a8f:
	/* 0x5a8f: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_5a97:
	/* 0x5a97: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5a9b:
	/* 0x5a9b: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_5aa3:
	/* 0x5aa3: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5aa8:
	/* 0x5aa8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5aaa:
	/* 0x5aaa: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5aad:
	/* 0x5aad: call   5ab2 <perf_unwind_native+0x5ab2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5ab2:
	/* 0x5ab2: jmp    4f07 <perf_unwind_native+0x4f07> */
	X86_SIM_X86_JMP(0x5ab2, 0x4f07, x86_l_4f07);
x86_l_5ab7:
	/* 0x5ab7: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5aba:
	/* 0x5aba: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5abd:
	/* 0x5abd: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5abd, 0x5cc7, x86_l_5cc7);
x86_l_5ac3:
	/* 0x5ac3: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5ac7:
	/* 0x5ac7: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5ac9:
	/* 0x5ac9: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5acd:
	/* 0x5acd: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5ad2:
	/* 0x5ad2: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5ad5:
	/* 0x5ad5: call   5ada <perf_unwind_native+0x5ada> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5ada:
	/* 0x5ada: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5add:
	/* 0x5add: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5add, 0x5d95, x86_l_5d95);
x86_l_5ae3:
	/* 0x5ae3: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5ae7:
	/* 0x5ae7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5aec:
	/* 0x5aec: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aef:
	/* 0x5aef: ja     5af8 <perf_unwind_native+0x5af8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5aef, 0x5af8, x86_l_5af8);
x86_l_5af1:
	/* 0x5af1: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5af3:
	/* 0x5af3: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5af6:
	/* 0x5af6: jmp    5afb <perf_unwind_native+0x5afb> */
	X86_SIM_X86_JMP(0x5af6, 0x5afb, x86_l_5afb);
x86_l_5af8:
	/* 0x5af8: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5afb:
	/* 0x5afb: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5afe:
	/* 0x5afe: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5afe, 0x5cc7, x86_l_5cc7);
x86_l_5b04:
	/* 0x5b04: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5b08:
	/* 0x5b08: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5b0a:
	/* 0x5b0a: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b0e:
	/* 0x5b0e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b13:
	/* 0x5b13: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5b16:
	/* 0x5b16: call   5b1b <perf_unwind_native+0x5b1b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b1b:
	/* 0x5b1b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b1e:
	/* 0x5b1e: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b1e, 0x5d95, x86_l_5d95);
x86_l_5b24:
	/* 0x5b24: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b28:
	/* 0x5b28: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5b2d:
	/* 0x5b2d: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b30:
	/* 0x5b30: ja     5b39 <perf_unwind_native+0x5b39> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5b30, 0x5b39, x86_l_5b39);
x86_l_5b32:
	/* 0x5b32: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5b34:
	/* 0x5b34: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5b37:
	/* 0x5b37: jmp    5b3c <perf_unwind_native+0x5b3c> */
	X86_SIM_X86_JMP(0x5b37, 0x5b3c, x86_l_5b3c);
x86_l_5b39:
	/* 0x5b39: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5b3c:
	/* 0x5b3c: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5b3f:
	/* 0x5b3f: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5b3f, 0x5cc7, x86_l_5cc7);
x86_l_5b45:
	/* 0x5b45: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5b49:
	/* 0x5b49: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5b4b:
	/* 0x5b4b: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b4f:
	/* 0x5b4f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b54:
	/* 0x5b54: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5b57:
	/* 0x5b57: call   5b5c <perf_unwind_native+0x5b5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b5c:
	/* 0x5b5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b5f:
	/* 0x5b5f: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b5f, 0x5d95, x86_l_5d95);
x86_l_5b65:
	/* 0x5b65: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b69:
	/* 0x5b69: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5b6e:
	/* 0x5b6e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b71:
	/* 0x5b71: ja     5b7a <perf_unwind_native+0x5b7a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5b71, 0x5b7a, x86_l_5b7a);
x86_l_5b73:
	/* 0x5b73: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5b75:
	/* 0x5b75: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5b78:
	/* 0x5b78: jmp    5b7d <perf_unwind_native+0x5b7d> */
	X86_SIM_X86_JMP(0x5b78, 0x5b7d, x86_l_5b7d);
x86_l_5b7a:
	/* 0x5b7a: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5b7d:
	/* 0x5b7d: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5b80:
	/* 0x5b80: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5b80, 0x5cc7, x86_l_5cc7);
x86_l_5b86:
	/* 0x5b86: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5b8a:
	/* 0x5b8a: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5b8c:
	/* 0x5b8c: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b90:
	/* 0x5b90: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b95:
	/* 0x5b95: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5b98:
	/* 0x5b98: call   5b9d <perf_unwind_native+0x5b9d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b9d:
	/* 0x5b9d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ba0:
	/* 0x5ba0: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ba0, 0x5d95, x86_l_5d95);
x86_l_5ba6:
	/* 0x5ba6: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5baa:
	/* 0x5baa: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5baf:
	/* 0x5baf: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5bb2:
	/* 0x5bb2: ja     5bbb <perf_unwind_native+0x5bbb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5bb2, 0x5bbb, x86_l_5bbb);
x86_l_5bb4:
	/* 0x5bb4: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5bb6:
	/* 0x5bb6: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5bb9:
	/* 0x5bb9: jmp    5bbe <perf_unwind_native+0x5bbe> */
	X86_SIM_X86_JMP(0x5bb9, 0x5bbe, x86_l_5bbe);
x86_l_5bbb:
	/* 0x5bbb: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5bbe:
	/* 0x5bbe: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5bc1:
	/* 0x5bc1: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5bc1, 0x5cc7, x86_l_5cc7);
x86_l_5bc7:
	/* 0x5bc7: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5bcb:
	/* 0x5bcb: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5bcd:
	/* 0x5bcd: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5bd1:
	/* 0x5bd1: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5bd6:
	/* 0x5bd6: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5bd9:
	/* 0x5bd9: call   5bde <perf_unwind_native+0x5bde> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5bde:
	/* 0x5bde: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5be1:
	/* 0x5be1: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5be1, 0x5d95, x86_l_5d95);
x86_l_5be7:
	/* 0x5be7: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5beb:
	/* 0x5beb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5bf0:
	/* 0x5bf0: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5bf3:
	/* 0x5bf3: ja     5bfc <perf_unwind_native+0x5bfc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5bf3, 0x5bfc, x86_l_5bfc);
x86_l_5bf5:
	/* 0x5bf5: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5bf7:
	/* 0x5bf7: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5bfa:
	/* 0x5bfa: jmp    5bff <perf_unwind_native+0x5bff> */
	X86_SIM_X86_JMP(0x5bfa, 0x5bff, x86_l_5bff);
x86_l_5bfc:
	/* 0x5bfc: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5bff:
	/* 0x5bff: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5c02:
	/* 0x5c02: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c02, 0x5cc7, x86_l_5cc7);
x86_l_5c08:
	/* 0x5c08: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5c0c:
	/* 0x5c0c: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5c0e:
	/* 0x5c0e: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c12:
	/* 0x5c12: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c17:
	/* 0x5c17: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5c1a:
	/* 0x5c1a: call   5c1f <perf_unwind_native+0x5c1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c1f:
	/* 0x5c1f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c22:
	/* 0x5c22: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c22, 0x5d95, x86_l_5d95);
x86_l_5c28:
	/* 0x5c28: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c2c:
	/* 0x5c2c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c31:
	/* 0x5c31: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c34:
	/* 0x5c34: ja     5c3d <perf_unwind_native+0x5c3d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c34, 0x5c3d, x86_l_5c3d);
x86_l_5c36:
	/* 0x5c36: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5c38:
	/* 0x5c38: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5c3b:
	/* 0x5c3b: jmp    5c40 <perf_unwind_native+0x5c40> */
	X86_SIM_X86_JMP(0x5c3b, 0x5c40, x86_l_5c40);
x86_l_5c3d:
	/* 0x5c3d: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5c40:
	/* 0x5c40: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5c43:
	/* 0x5c43: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c43, 0x5cc7, x86_l_5cc7);
x86_l_5c49:
	/* 0x5c49: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5c4d:
	/* 0x5c4d: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5c4f:
	/* 0x5c4f: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c53:
	/* 0x5c53: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c58:
	/* 0x5c58: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5c5b:
	/* 0x5c5b: call   5c60 <perf_unwind_native+0x5c60> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c60:
	/* 0x5c60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c63:
	/* 0x5c63: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c63, 0x5d95, x86_l_5d95);
x86_l_5c69:
	/* 0x5c69: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c6d:
	/* 0x5c6d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c72:
	/* 0x5c72: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c75:
	/* 0x5c75: ja     5c7e <perf_unwind_native+0x5c7e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5c75, 0x5c7e, x86_l_5c7e);
x86_l_5c77:
	/* 0x5c77: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5c79:
	/* 0x5c79: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5c7c:
	/* 0x5c7c: jmp    5c81 <perf_unwind_native+0x5c81> */
	X86_SIM_X86_JMP(0x5c7c, 0x5c81, x86_l_5c81);
x86_l_5c7e:
	/* 0x5c7e: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5c81:
	/* 0x5c81: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5c84:
	/* 0x5c84: jae    5cc7 <perf_unwind_native+0x5cc7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5c84, 0x5cc7, x86_l_5cc7);
x86_l_5c86:
	/* 0x5c86: lea    eax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_5c8a:
	/* 0x5c8a: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_5c8c:
	/* 0x5c8c: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c90:
	/* 0x5c90: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c95:
	/* 0x5c95: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5c98:
	/* 0x5c98: call   5c9d <perf_unwind_native+0x5c9d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c9d:
	/* 0x5c9d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ca0:
	/* 0x5ca0: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ca0, 0x5d95, x86_l_5d95);
x86_l_5ca6:
	/* 0x5ca6: mov    ecx,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5caa:
	/* 0x5caa: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5caf:
	/* 0x5caf: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5cb2:
	/* 0x5cb2: ja     5cbb <perf_unwind_native+0x5cbb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5cb2, 0x5cbb, x86_l_5cbb);
x86_l_5cb4:
	/* 0x5cb4: inc    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_5cb6:
	/* 0x5cb6: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5cb9:
	/* 0x5cb9: jmp    5cbe <perf_unwind_native+0x5cbe> */
	X86_SIM_X86_JMP(0x5cb9, 0x5cbe, x86_l_5cbe);
x86_l_5cbb:
	/* 0x5cbb: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5cbe:
	/* 0x5cbe: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5cc1:
	/* 0x5cc1: jb     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5cc1, 0x5d95, x86_l_5d95);
x86_l_5cc7:
	/* 0x5cc7: mov    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5cca:
	/* 0x5cca: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5ccd:
	/* 0x5ccd: je     5d95 <perf_unwind_native+0x5d95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ccd, 0x5d95, x86_l_5d95);
x86_l_5cd3:
	/* 0x5cd3: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_5cd6:
	/* 0x5cd6: mov    DWORD PTR [rsp+0x6c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_5cdb:
	/* 0x5cdb: lea    rsi,[rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_5ce0:
	/* 0x5ce0: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5ce3:
	/* 0x5ce3: call   5ce8 <perf_unwind_native+0x5ce8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5ce8:
	/* 0x5ce8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ceb:
	/* 0x5ceb: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5cf0:
	/* 0x5cf0: mov    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_5cf6:
	/* 0x5cf6: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_5cfb:
	/* 0x5cfb: je     c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5cfb, 0xc82, x86_l_c82);
x86_l_5d01:
	/* 0x5d01: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d04:
	/* 0x5d04: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5d0b:
	/* 0x5d0b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d0e:
	/* 0x5d0e: jne    627f <perf_unwind_native+0x627f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5d0e, 0x627f, x86_l_627f);
x86_l_5d14:
	/* 0x5d14: movzx  ecx,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_5d19:
	/* 0x5d19: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_5d1e:
	/* 0x5d1e: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_5d20:
	/* 0x5d20: mov    DWORD PTR [rsp+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5d24:
	/* 0x5d24: mov    eax,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_5d28:
	/* 0x5d28: cmp    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_5d2c:
	/* 0x5d2c: jae    5d36 <perf_unwind_native+0x5d36> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5d2c, 0x5d36, x86_l_5d36);
x86_l_5d2e:
	/* 0x5d2e: add    DWORD PTR [rsp+0x8],0x10000 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 34359803904ULL);
x86_l_5d36:
	/* 0x5d36: movzx  eax,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_5d3b:
	/* 0x5d3b: mov    DWORD PTR [rsp+0x68],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5d3f:
	/* 0x5d3f: mov    r15d,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_5d45:
	/* 0x5d45: mov    ecx,0xfa5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4005ULL);
x86_l_5d4a:
	/* 0x5d4a: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_5d4f:
	/* 0x5d4f: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5d54:
	/* 0x5d54: je     c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d54, 0xc82, x86_l_c82);
x86_l_5d5a:
	/* 0x5d5a: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_5d5f:
	/* 0x5d5f: jne    5e35 <perf_unwind_native+0x5e35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5d5f, 0x5e35, x86_l_5e35);
x86_l_5d65:
	/* 0x5d65: mov    DWORD PTR [rsp+0x84],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683079ULL);
x86_l_5d70:
	/* 0x5d70: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5d77:
	/* 0x5d77: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_5d7f:
	/* 0x5d7f: call   5d84 <perf_unwind_native+0x5d84> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5d84:
	/* 0x5d84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d87:
	/* 0x5d87: je     5e21 <perf_unwind_native+0x5e21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d87, 0x5e21, x86_l_5e21);
x86_l_5d8d:
	/* 0x5d8d: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5d90:
	/* 0x5d90: jmp    5e31 <perf_unwind_native+0x5e31> */
	X86_SIM_X86_JMP(0x5d90, 0x5e31, x86_l_5e31);
x86_l_5d95:
	/* 0x5d95: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5d9c:
	/* 0x5d9c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d9f:
	/* 0x5d9f: jne    5db6 <perf_unwind_native+0x5db6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5d9f, 0x5db6, x86_l_5db6);
x86_l_5da1:
	/* 0x5da1: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5da6:
	/* 0x5da6: mov    r15d,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_5dac:
	/* 0x5dac: mov    ecx,0xfa3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4003ULL);
x86_l_5db1:
	/* 0x5db1: jmp    c82 <perf_unwind_native+0xc82> */
	X86_SIM_X86_JMP(0x5db1, 0xc82, x86_l_c82);
x86_l_5db6:
	/* 0x5db6: movabs rax,0x6174616420747075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7022344801646571637ULL);
x86_l_5dc0:
	/* 0x5dc0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5dc5:
	/* 0x5dc5: movabs rax,0x72726f43202e7370 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8246776201762206576ULL);
x86_l_5dcf:
	/* 0x5dcf: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5dd4:
	/* 0x5dd4: movabs rax,0x657473203631206e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310594677314494574ULL);
x86_l_5dde:
	/* 0x5dde: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5de3:
	/* 0x5de3: movabs rax,0x6920686372616573 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7575169349567210867ULL);
x86_l_5ded:
	/* 0x5ded: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5df2:
	/* 0x5df2: movabs rax,0x622064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7070761801744998726ULL);
x86_l_5dfc:
	/* 0x5dfc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e01:
	/* 0x5e01: mov    DWORD PTR [rsp+0x37],0xa3f61 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 236223872865ULL);
x86_l_5e09:
	/* 0x5e09: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e0e:
	/* 0x5e0e: mov    esi,0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_5e13:
	/* 0x5e13: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e15:
	/* 0x5e15: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e17:
	/* 0x5e17: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e1a:
	/* 0x5e1a: call   5e1f <perf_unwind_native+0x5e1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5e1f:
	/* 0x5e1f: jmp    5da1 <perf_unwind_native+0x5da1> */
	X86_SIM_X86_JMP(0x5e1f, 0x5da1, x86_l_5da1);
x86_l_5e21:
	/* 0x5e21: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5e28:
	/* 0x5e28: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e2b:
	/* 0x5e2b: jne    636a <perf_unwind_native+0x636a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5e2b, 0x636a, x86_l_636a);
x86_l_5e31:
	/* 0x5e31: mov    eax,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5e35:
	/* 0x5e35: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_5e38:
	/* 0x5e38: js     5fb9 <perf_unwind_native+0x5fb9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5e38, 0x5fb9, x86_l_5fb9);
x86_l_5e3e:
	/* 0x5e3e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_5e45:
	/* 0x5e45: lea    rsi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5e4a:
	/* 0x5e4a: call   5e4f <perf_unwind_native+0x5e4f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5e4f:
	/* 0x5e4f: mov    QWORD PTR [rsp+0x120],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_5e57:
	/* 0x5e57: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5e5a:
	/* 0x5e5a: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5e5f:
	/* 0x5e5f: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5e66:
	/* 0x5e66: je     5f07 <perf_unwind_native+0x5f07> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5e66, 0x5f07, x86_l_5f07);
x86_l_5e6c:
	/* 0x5e6c: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_5e74:
	/* 0x5e74: mov    r15d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5e78:
	/* 0x5e78: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_5e7c:
	/* 0x5e7c: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_5e7e:
	/* 0x5e7e: je     5ebf <perf_unwind_native+0x5ebf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5e7e, 0x5ebf, x86_l_5ebf);
x86_l_5e80:
	/* 0x5e80: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5e87:
	/* 0x5e87: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e8a:
	/* 0x5e8a: jne    62fb <perf_unwind_native+0x62fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5e8a, 0x62fb, x86_l_62fb);
x86_l_5e90:
	/* 0x5e90: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5e92:
	/* 0x5e92: and    cl,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 127ULL);
x86_l_5e95:
	/* 0x5e95: movzx  ecx,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_5e98:
	/* 0x5e98: cmp    DWORD PTR [rsp+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e9c:
	/* 0x5e9c: jl     5ebf <perf_unwind_native+0x5ebf> */
	X86_SIM_X86_JCC(X86_CC_L, 0x5e9c, 0x5ebf, x86_l_5ebf);
x86_l_5e9e:
	/* 0x5e9e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ea0:
	/* 0x5ea0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_5ea2:
	/* 0x5ea2: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_5ea5:
	/* 0x5ea5: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_5ea8:
	/* 0x5ea8: add    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_5eab:
	/* 0x5eab: add    r15d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_5eaf:
	/* 0x5eaf: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_5eb6:
	/* 0x5eb6: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5eb9:
	/* 0x5eb9: jne    63e4 <perf_unwind_native+0x63e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5eb9, 0x63e4, x86_l_63e4);
x86_l_5ebf:
	/* 0x5ebf: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_5ec7:
	/* 0x5ec7: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_5eca:
	/* 0x5eca: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5ecd:
	/* 0x5ecd: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_5ecf:
	/* 0x5ecf: jns    5ed7 <perf_unwind_native+0x5ed7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5ecf, 0x5ed7, x86_l_5ed7);
x86_l_5ed1:
	/* 0x5ed1: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5ed4:
	/* 0x5ed4: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_5ed7:
	/* 0x5ed7: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5ed9:
	/* 0x5ed9: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_5edc:
	/* 0x5edc: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5edf:
	/* 0x5edf: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5ee2:
	/* 0x5ee2: jg     60c0 <perf_unwind_native+0x60c0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x5ee2, 0x60c0, x86_l_60c0);
x86_l_5ee8:
	/* 0x5ee8: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5eeb:
	/* 0x5eeb: je     622a <perf_unwind_native+0x622a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5eeb, 0x622a, x86_l_622a);
x86_l_5ef1:
	/* 0x5ef1: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_5ef9:
	/* 0x5ef9: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5efc:
	/* 0x5efc: je     6227 <perf_unwind_native+0x6227> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5efc, 0x6227, x86_l_6227);
x86_l_5f02:
	/* 0x5f02: jmp    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JMP(0x5f02, 0x64af, x86_l_64af);
x86_l_5f07:
	/* 0x5f07: mov    DWORD PTR [rsp+0x70],0x55 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337237ULL);
x86_l_5f0f:
	/* 0x5f0f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_5f16:
	/* 0x5f16: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5f1b:
	/* 0x5f1b: call   5f20 <perf_unwind_native+0x5f20> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5f20:
	/* 0x5f20: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f23:
	/* 0x5f23: je     5f2a <perf_unwind_native+0x5f2a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f23, 0x5f2a, x86_l_5f2a);
x86_l_5f25:
	/* 0x5f25: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5f28:
	/* 0x5f28: jmp    5f31 <perf_unwind_native+0x5f31> */
	X86_SIM_X86_JMP(0x5f28, 0x5f31, x86_l_5f31);
x86_l_5f2a:
	/* 0x5f2a: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5f2f:
	/* 0x5f2f: jne    5f3c <perf_unwind_native+0x5f3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5f2f, 0x5f3c, x86_l_5f3c);
x86_l_5f31:
	/* 0x5f31: mov    r13d,0xfaf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4015ULL);
x86_l_5f37:
	/* 0x5f37: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0x5f37, 0x5417, x86_l_5417);
x86_l_5f3c:
	/* 0x5f3c: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_5f46:
	/* 0x5f46: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_5f4b:
	/* 0x5f4b: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_5f55:
	/* 0x5f55: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5f5a:
	/* 0x5f5a: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_5f64:
	/* 0x5f64: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5f69:
	/* 0x5f69: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_5f73:
	/* 0x5f73: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f78:
	/* 0x5f78: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_5f82:
	/* 0x5f82: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5f87:
	/* 0x5f87: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_5f91:
	/* 0x5f91: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f96:
	/* 0x5f96: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5f9a:
	/* 0x5f9a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f9f:
	/* 0x5f9f: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_5fa4:
	/* 0x5fa4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5fa6:
	/* 0x5fa6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5fa9:
	/* 0x5fa9: call   5fae <perf_unwind_native+0x5fae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_5fae:
	/* 0x5fae: mov    r13d,0xfaf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4015ULL);
x86_l_5fb4:
	/* 0x5fb4: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0x5fb4, 0x5417, x86_l_5417);
x86_l_5fb9:
	/* 0x5fb9: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_5fbe:
	/* 0x5fbe: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5fc4:
	/* 0x5fc4: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5fc7:
	/* 0x5fc7: jg     605a <perf_unwind_native+0x605a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x5fc7, 0x605a, x86_l_605a);
x86_l_5fcd:
	/* 0x5fcd: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5fd0:
	/* 0x5fd0: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5fd5:
	/* 0x5fd5: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_5fdd:
	/* 0x5fdd: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_5fe5:
	/* 0x5fe5: je     6052 <perf_unwind_native+0x6052> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5fe5, 0x6052, x86_l_6052);
x86_l_5fe7:
	/* 0x5fe7: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5fea:
	/* 0x5fea: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5fea, 0x5417, x86_l_5417);
x86_l_5ff0:
	/* 0x5ff0: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ff3:
	/* 0x5ff3: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ff5:
	/* 0x5ff5: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_5ff8:
	/* 0x5ff8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ffa:
	/* 0x5ffa: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_5ffd:
	/* 0x5ffd: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_6000:
	/* 0x6000: lea    r13,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_6004:
	/* 0x6004: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_6008:
	/* 0x6008: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_600f:
	/* 0x600f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6012:
	/* 0x6012: je     6744 <perf_unwind_native+0x6744> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6012, 0x6744, x86_l_6744);
x86_l_6018:
	/* 0x6018: movabs rax,0xa786c2578303d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947155647541309ULL);
x86_l_6022:
	/* 0x6022: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6027:
	/* 0x6027: movabs rax,0x616663202c544c50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018406059137322064ULL);
x86_l_6031:
	/* 0x6031: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6036:
	/* 0x6036: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_603b:
	/* 0x603b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_6040:
	/* 0x6040: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6043:
	/* 0x6043: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6045:
	/* 0x6045: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6048:
	/* 0x6048: call   604d <perf_unwind_native+0x604d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_604d:
	/* 0x604d: jmp    6744 <perf_unwind_native+0x6744> */
	X86_SIM_X86_JMP(0x604d, 0x6744, x86_l_6744);
x86_l_6052:
	/* 0x6052: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6055:
	/* 0x6055: jmp    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JMP(0x6055, 0x5417, x86_l_5417);
x86_l_605a:
	/* 0x605a: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_605d:
	/* 0x605d: je     612b <perf_unwind_native+0x612b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x605d, 0x612b, x86_l_612b);
x86_l_6063:
	/* 0x6063: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_6066:
	/* 0x6066: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_606b:
	/* 0x606b: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_6070:
	/* 0x6070: jne    5417 <perf_unwind_native+0x5417> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6070, 0x5417, x86_l_5417);
x86_l_6076:
	/* 0x6076: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6079:
	/* 0x6079: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_607e:
	/* 0x607e: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_6083:
	/* 0x6083: call   6088 <perf_unwind_native+0x6088> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6088:
	/* 0x6088: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_608b:
	/* 0x608b: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x608b, 0x1522, x86_l_1522);
x86_l_6091:
	/* 0x6091: mov    rax,QWORD PTR [rbx+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_6098:
	/* 0x6098: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_609c:
	/* 0x609c: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_60a3:
	/* 0x60a3: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_60a8:
	/* 0x60a8: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_60af:
	/* 0x60af: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_60b4:
	/* 0x60b4: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_60bb:
	/* 0x60bb: jmp    6778 <perf_unwind_native+0x6778> */
	X86_SIM_X86_JMP(0x60bb, 0x6778, x86_l_6778);
x86_l_60c0:
	/* 0x60c0: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_60c3:
	/* 0x60c3: je     6222 <perf_unwind_native+0x6222> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60c3, 0x6222, x86_l_6222);
x86_l_60c9:
	/* 0x60c9: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_60cc:
	/* 0x60cc: jne    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x60cc, 0x64af, x86_l_64af);
x86_l_60d2:
	/* 0x60d2: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_60d5:
	/* 0x60d5: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_60d7:
	/* 0x60d7: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_60da:
	/* 0x60da: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_60dd:
	/* 0x60dd: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_60e2:
	/* 0x60e2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_60e9:
	/* 0x60e9: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60ec:
	/* 0x60ec: jne    6442 <perf_unwind_native+0x6442> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x60ec, 0x6442, x86_l_6442);
x86_l_60f2:
	/* 0x60f2: and    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_60f6:
	/* 0x60f6: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_60f9:
	/* 0x60f9: cmp    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_60fd:
	/* 0x60fd: jg     648b <perf_unwind_native+0x648b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x60fd, 0x648b, x86_l_648b);
x86_l_6103:
	/* 0x6103: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_610b:
	/* 0x610b: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_610e:
	/* 0x610e: je     64a7 <perf_unwind_native+0x64a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x610e, 0x64a7, x86_l_64a7);
x86_l_6114:
	/* 0x6114: cmp    r15d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_6118:
	/* 0x6118: jne    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6118, 0x64af, x86_l_64af);
x86_l_611e:
	/* 0x611e: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_6126:
	/* 0x6126: jmp    64a7 <perf_unwind_native+0x64a7> */
	X86_SIM_X86_JMP(0x6126, 0x64a7, x86_l_64a7);
x86_l_612b:
	/* 0x612b: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_6133:
	/* 0x6133: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6136:
	/* 0x6136: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_613a:
	/* 0x613a: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6142:
	/* 0x6142: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6147:
	/* 0x6147: call   614c <perf_unwind_native+0x614c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_614c:
	/* 0x614c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_614f:
	/* 0x614f: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_6154:
	/* 0x6154: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6154, 0x1522, x86_l_1522);
x86_l_615a:
	/* 0x615a: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_6162:
	/* 0x6162: mov    QWORD PTR [rbx+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_6169:
	/* 0x6169: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6171:
	/* 0x6171: mov    QWORD PTR [rbx+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_6178:
	/* 0x6178: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6180:
	/* 0x6180: mov    QWORD PTR [rbx+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_6187:
	/* 0x6187: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_618f:
	/* 0x618f: mov    QWORD PTR [rbx+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_6196:
	/* 0x6196: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_619e:
	/* 0x619e: mov    QWORD PTR [rbx+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_61a5:
	/* 0x61a5: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_61ad:
	/* 0x61ad: mov    QWORD PTR [rbx+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_61b4:
	/* 0x61b4: mov    rax,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_61bc:
	/* 0x61bc: mov    QWORD PTR [rbx+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_61c3:
	/* 0x61c3: mov    rax,QWORD PTR [rsp+0x110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_61cb:
	/* 0x61cb: mov    QWORD PTR [rbx+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_61d2:
	/* 0x61d2: mov    BYTE PTR [rbx+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_61d9:
	/* 0x61d9: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_61e0:
	/* 0x61e0: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61e3:
	/* 0x61e3: je     677f <perf_unwind_native+0x677f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61e3, 0x677f, x86_l_677f);
x86_l_61e9:
	/* 0x61e9: movabs rax,0xa656d61726620 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2926270227834400ULL);
x86_l_61f3:
	/* 0x61f3: mov    QWORD PTR [rsp+0x16],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_61f8:
	/* 0x61f8: movabs rax,0x66206c616e676973 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7359000956843288947ULL);
x86_l_6202:
	/* 0x6202: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6207:
	/* 0x6207: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_620c:
	/* 0x620c: mov    esi,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_6211:
	/* 0x6211: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6213:
	/* 0x6213: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6215:
	/* 0x6215: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6218:
	/* 0x6218: call   621d <perf_unwind_native+0x621d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_621d:
	/* 0x621d: jmp    677f <perf_unwind_native+0x677f> */
	X86_SIM_X86_JMP(0x621d, 0x677f, x86_l_677f);
x86_l_6222:
	/* 0x6222: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_6227:
	/* 0x6227: mov    r13,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_622a:
	/* 0x622a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_622d:
	/* 0x622d: movsxd r13,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_6230:
	/* 0x6230: add    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6233:
	/* 0x6233: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_6235:
	/* 0x6235: jns    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6235, 0x64af, x86_l_64af);
x86_l_623b:
	/* 0x623b: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6240:
	/* 0x6240: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6245:
	/* 0x6245: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6248:
	/* 0x6248: call   624d <perf_unwind_native+0x624d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_624d:
	/* 0x624d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6250:
	/* 0x6250: je     626a <perf_unwind_native+0x626a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6250, 0x626a, x86_l_626a);
x86_l_6252:
	/* 0x6252: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6259:
	/* 0x6259: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_625c:
	/* 0x625c: jne    661e <perf_unwind_native+0x661e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x625c, 0x661e, x86_l_661e);
x86_l_6262:
	/* 0x6262: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6265:
	/* 0x6265: jmp    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JMP(0x6265, 0x64af, x86_l_64af);
x86_l_626a:
	/* 0x626a: shl    r15d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_626e:
	/* 0x626e: and    r15d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_6272:
	/* 0x6272: add    r15,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_6277:
	/* 0x6277: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_627a:
	/* 0x627a: jmp    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JMP(0x627a, 0x64af, x86_l_64af);
x86_l_627f:
	/* 0x627f: movabs rax,0xa6425206f666e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387845742ULL);
x86_l_6289:
	/* 0x6289: mov    QWORD PTR [rsp+0x35],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_628e:
	/* 0x628e: movabs rax,0x6f666e49646e6977 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8027224647331113335ULL);
x86_l_6298:
	/* 0x6298: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_629d:
	/* 0x629d: movabs rax,0x6e75202c78257830 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7959303291813591088ULL);
x86_l_62a7:
	/* 0x62a7: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_62ac:
	/* 0x62ac: movabs rax,0x20776f4c72646461 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2339460905569641569ULL);
x86_l_62b6:
	/* 0x62b6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_62bb:
	/* 0x62bb: movabs rax,0x202c642520786564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2318338018810291556ULL);
x86_l_62c5:
	/* 0x62c5: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_62ca:
	/* 0x62ca: movabs rax,0x6e692061746c6564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7955925819663869284ULL);
x86_l_62d4:
	/* 0x62d4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_62d9:
	/* 0x62d9: mov    edx,DWORD PTR [rsp+0x6c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_62dd:
	/* 0x62dd: movzx  ecx,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_62e2:
	/* 0x62e2: movzx  r8d,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_62e7:
	/* 0x62e7: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_62ec:
	/* 0x62ec: mov    esi,0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 45ULL);
x86_l_62f1:
	/* 0x62f1: call   62f6 <perf_unwind_native+0x62f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_62f6:
	/* 0x62f6: jmp    5d14 <perf_unwind_native+0x5d14> */
	X86_SIM_X86_JMP(0x62f6, 0x5d14, x86_l_5d14);
x86_l_62fb:
	/* 0x62fb: movabs rax,0xa78323023252061 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754408119914012769ULL);
x86_l_6305:
	/* 0x6305: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_630a:
	/* 0x630a: movabs rax,0x746c656420646567 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8389191686598976871ULL);
x86_l_6314:
	/* 0x6314: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6319:
	/* 0x6319: movabs rax,0x72656d202c642520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243114677922702624ULL);
x86_l_6323:
	/* 0x6323: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6328:
	/* 0x6328: movabs rax,0x6666694472646441 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7378700782191010881ULL);
x86_l_6332:
	/* 0x6332: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6337:
	/* 0x6337: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_633c:
	/* 0x633c: movsxd rdx,DWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_6341:
	/* 0x6341: mov    r14,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_6349:
	/* 0x6349: movzx  ecx,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_634e:
	/* 0x634e: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6353:
	/* 0x6353: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_6358:
	/* 0x6358: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_635b:
	/* 0x635b: call   6360 <perf_unwind_native+0x6360> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6360:
	/* 0x6360: movzx  eax,BYTE PTR [r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_6365:
	/* 0x6365: jmp    5e90 <perf_unwind_native+0x5e90> */
	X86_SIM_X86_JMP(0x6365, 0x5e90, x86_l_5e90);
x86_l_636a:
	/* 0x636a: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_6374:
	/* 0x6374: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_6379:
	/* 0x6379: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_6383:
	/* 0x6383: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6388:
	/* 0x6388: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_6392:
	/* 0x6392: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6397:
	/* 0x6397: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_63a1:
	/* 0x63a1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_63a6:
	/* 0x63a6: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_63b0:
	/* 0x63b0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_63b5:
	/* 0x63b5: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_63bf:
	/* 0x63bf: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_63c4:
	/* 0x63c4: mov    edx,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_63cb:
	/* 0x63cb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_63d0:
	/* 0x63d0: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_63d5:
	/* 0x63d5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_63d7:
	/* 0x63d7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_63da:
	/* 0x63da: call   63df <perf_unwind_native+0x63df> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_63df:
	/* 0x63df: jmp    5e31 <perf_unwind_native+0x5e31> */
	X86_SIM_X86_JMP(0x63df, 0x5e31, x86_l_5e31);
x86_l_63e4:
	/* 0x63e4: movabs rax,0xa64253d61746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 748764383608597605ULL);
x86_l_63ee:
	/* 0x63ee: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_63f3:
	/* 0x63f3: movabs rax,0x44616663203a6863 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4927332043248527459ULL);
x86_l_63fd:
	/* 0x63fd: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6402:
	/* 0x6402: movabs rax,0x74616d2061746c65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8386103966981975141ULL);
x86_l_640c:
	/* 0x640c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6411:
	/* 0x6411: movabs rax,0x642064656772654d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7214876989737559373ULL);
x86_l_641b:
	/* 0x641b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6420:
	/* 0x6420: mov    BYTE PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_6425:
	/* 0x6425: mov    edx,DWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_6429:
	/* 0x6429: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_642e:
	/* 0x642e: mov    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_6433:
	/* 0x6433: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6435:
	/* 0x6435: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6438:
	/* 0x6438: call   643d <perf_unwind_native+0x643d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_643d:
	/* 0x643d: jmp    5ebf <perf_unwind_native+0x5ebf> */
	X86_SIM_X86_JMP(0x643d, 0x5ebf, x86_l_5ebf);
x86_l_6442:
	/* 0x6442: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_644c:
	/* 0x644c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6451:
	/* 0x6451: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_645b:
	/* 0x645b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6460:
	/* 0x6460: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_6465:
	/* 0x6465: and    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_6469:
	/* 0x6469: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_646e:
	/* 0x646e: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6473:
	/* 0x6473: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6476:
	/* 0x6476: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6479:
	/* 0x6479: call   647e <perf_unwind_native+0x647e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_647e:
	/* 0x647e: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6481:
	/* 0x6481: cmp    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_6485:
	/* 0x6485: jle    6103 <perf_unwind_native+0x6103> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x6485, 0x6103, x86_l_6103);
x86_l_648b:
	/* 0x648b: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_6493:
	/* 0x6493: cmp    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_6497:
	/* 0x6497: je     64a7 <perf_unwind_native+0x64a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6497, 0x64a7, x86_l_64a7);
x86_l_6499:
	/* 0x6499: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_64a1:
	/* 0x64a1: cmp    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_64a5:
	/* 0x64a5: jne    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64a5, 0x64af, x86_l_64af);
x86_l_64a7:
	/* 0x64a7: mov    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_64ac:
	/* 0x64ac: add    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_64af:
	/* 0x64af: mov    rcx,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_64b7:
	/* 0x64b7: movzx  eax,BYTE PTR [rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_64bb:
	/* 0x64bb: mov    r15d,DWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_64bf:
	/* 0x64bf: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_64c2:
	/* 0x64c2: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_64c4:
	/* 0x64c4: jns    64cc <perf_unwind_native+0x64cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x64c4, 0x64cc, x86_l_64cc);
x86_l_64c6:
	/* 0x64c6: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_64c9:
	/* 0x64c9: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_64cc:
	/* 0x64cc: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_64ce:
	/* 0x64ce: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_64d1:
	/* 0x64d1: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_64d4:
	/* 0x64d4: jg     64f4 <perf_unwind_native+0x64f4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x64d4, 0x64f4, x86_l_64f4);
x86_l_64d6:
	/* 0x64d6: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_64d9:
	/* 0x64d9: cmp    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_64dc:
	/* 0x64dc: je     6560 <perf_unwind_native+0x6560> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64dc, 0x6560, x86_l_6560);
x86_l_64e2:
	/* 0x64e2: mov    rsi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_64ea:
	/* 0x64ea: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_64ed:
	/* 0x64ed: je     655d <perf_unwind_native+0x655d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64ed, 0x655d, x86_l_655d);
x86_l_64ef:
	/* 0x64ef: jmp    672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JMP(0x64ef, 0x672b, x86_l_672b);
x86_l_64f4:
	/* 0x64f4: cmp    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_64f7:
	/* 0x64f7: je     6558 <perf_unwind_native+0x6558> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64f7, 0x6558, x86_l_6558);
x86_l_64f9:
	/* 0x64f9: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_64fc:
	/* 0x64fc: jne    672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64fc, 0x672b, x86_l_672b);
x86_l_6502:
	/* 0x6502: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6505:
	/* 0x6505: sar    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_6507:
	/* 0x6507: and    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_650a:
	/* 0x650a: movsxd rcx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_650d:
	/* 0x650d: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6512:
	/* 0x6512: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6519:
	/* 0x6519: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_651c:
	/* 0x651c: jne    6690 <perf_unwind_native+0x6690> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x651c, 0x6690, x86_l_6690);
x86_l_6522:
	/* 0x6522: and    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_6526:
	/* 0x6526: cmp    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_652a:
	/* 0x652a: jg     66d6 <perf_unwind_native+0x66d6> */
	X86_SIM_X86_JCC(X86_CC_G, 0x652a, 0x66d6, x86_l_66d6);
x86_l_6530:
	/* 0x6530: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_6533:
	/* 0x6533: je     6702 <perf_unwind_native+0x6702> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6533, 0x6702, x86_l_6702);
x86_l_6539:
	/* 0x6539: cmp    r15d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_653d:
	/* 0x653d: jne    672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x653d, 0x672b, x86_l_672b);
x86_l_6543:
	/* 0x6543: mov    rax,QWORD PTR [rsp+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_654b:
	/* 0x654b: mov    QWORD PTR [rsp+0x130],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_6553:
	/* 0x6553: jmp    6702 <perf_unwind_native+0x6702> */
	X86_SIM_X86_JMP(0x6553, 0x6702, x86_l_6702);
x86_l_6558:
	/* 0x6558: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_655d:
	/* 0x655d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6560:
	/* 0x6560: movsxd r12,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_6563:
	/* 0x6563: add    r12,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6566:
	/* 0x6566: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_6568:
	/* 0x6568: jns    6712 <perf_unwind_native+0x6712> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6568, 0x6712, x86_l_6712);
x86_l_656e:
	/* 0x656e: lea    rdi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6573:
	/* 0x6573: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6578:
	/* 0x6578: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_657b:
	/* 0x657b: call   6580 <perf_unwind_native+0x6580> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6580:
	/* 0x6580: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6583:
	/* 0x6583: je     6608 <perf_unwind_native+0x6608> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6583, 0x6608, x86_l_6608);
x86_l_6589:
	/* 0x6589: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6590:
	/* 0x6590: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6593:
	/* 0x6593: je     672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6593, 0x672b, x86_l_672b);
x86_l_6599:
	/* 0x6599: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_65a3:
	/* 0x65a3: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_65a8:
	/* 0x65a8: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_65b2:
	/* 0x65b2: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_65b7:
	/* 0x65b7: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_65c1:
	/* 0x65c1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_65c6:
	/* 0x65c6: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_65d0:
	/* 0x65d0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_65d5:
	/* 0x65d5: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_65df:
	/* 0x65df: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_65e4:
	/* 0x65e4: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_65ec:
	/* 0x65ec: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_65f1:
	/* 0x65f1: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_65f6:
	/* 0x65f6: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_65f9:
	/* 0x65f9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_65fb:
	/* 0x65fb: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_65fe:
	/* 0x65fe: call   6603 <perf_unwind_native+0x6603> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6603:
	/* 0x6603: jmp    672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JMP(0x6603, 0x672b, x86_l_672b);
x86_l_6608:
	/* 0x6608: lea    r12d,[r15*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 3), 0ULL);
x86_l_6610:
	/* 0x6610: and    r12d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_6614:
	/* 0x6614: add    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 112ULL);
x86_l_6619:
	/* 0x6619: jmp    6712 <perf_unwind_native+0x6712> */
	X86_SIM_X86_JMP(0x6619, 0x6712, x86_l_6712);
x86_l_661e:
	/* 0x661e: movabs rax,0x2578302073736572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2699960892542641522ULL);
x86_l_6628:
	/* 0x6628: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_662d:
	/* 0x662d: movabs rax,0x6464612065636e65 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7234013693231722085ULL);
x86_l_6637:
	/* 0x6637: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_663c:
	/* 0x663c: movabs rax,0x7265666572656420 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243107278868538400ULL);
x86_l_6646:
	/* 0x6646: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_664b:
	/* 0x664b: movabs rax,0x6f742064656c6961 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8031079651078859105ULL);
x86_l_6655:
	/* 0x6655: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_665a:
	/* 0x665a: movabs rax,0x6620646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7358992216502005365ULL);
x86_l_6664:
	/* 0x6664: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6669:
	/* 0x6669: mov    DWORD PTR [rsp+0x38],0xa786c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518854764ULL);
x86_l_6671:
	/* 0x6671: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6676:
	/* 0x6676: mov    esi,0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_667b:
	/* 0x667b: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_667e:
	/* 0x667e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6680:
	/* 0x6680: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6683:
	/* 0x6683: call   6688 <perf_unwind_native+0x6688> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6688:
	/* 0x6688: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_668b:
	/* 0x668b: jmp    64af <perf_unwind_native+0x64af> */
	X86_SIM_X86_JMP(0x668b, 0x64af, x86_l_64af);
x86_l_6690:
	/* 0x6690: movabs rax,0xa756c252b642572 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 753627419551999346ULL);
x86_l_669a:
	/* 0x669a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_669f:
	/* 0x669f: movabs rax,0x203a646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2322278983241526901ULL);
x86_l_66a9:
	/* 0x66a9: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_66ae:
	/* 0x66ae: mov    BYTE PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_66b3:
	/* 0x66b3: and    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_66b7:
	/* 0x66b7: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_66bc:
	/* 0x66bc: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_66c1:
	/* 0x66c1: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_66c4:
	/* 0x66c4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_66c7:
	/* 0x66c7: call   66cc <perf_unwind_native+0x66cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_66cc:
	/* 0x66cc: cmp    r15d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_66d0:
	/* 0x66d0: jle    6530 <perf_unwind_native+0x6530> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x66d0, 0x6530, x86_l_6530);
x86_l_66d6:
	/* 0x66d6: mov    rax,QWORD PTR [rsp+0x148] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_66de:
	/* 0x66de: mov    QWORD PTR [rsp+0x130],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_66e6:
	/* 0x66e6: cmp    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_66ea:
	/* 0x66ea: je     6702 <perf_unwind_native+0x6702> */
	X86_SIM_X86_JCC(X86_CC_E, 0x66ea, 0x6702, x86_l_6702);
x86_l_66ec:
	/* 0x66ec: mov    rax,QWORD PTR [rsp+0x128] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_66f4:
	/* 0x66f4: mov    QWORD PTR [rsp+0x130],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_66fc:
	/* 0x66fc: cmp    r15d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_6700:
	/* 0x6700: jne    672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6700, 0x672b, x86_l_672b);
x86_l_6702:
	/* 0x6702: mov    r12,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6707:
	/* 0x6707: mov    rax,QWORD PTR [rsp+0x130] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 304ULL);
x86_l_670f:
	/* 0x670f: add    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_6712:
	/* 0x6712: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6715:
	/* 0x6715: je     672b <perf_unwind_native+0x672b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6715, 0x672b, x86_l_672b);
x86_l_6717:
	/* 0x6717: mov    rdi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_671c:
	/* 0x671c: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6721:
	/* 0x6721: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6724:
	/* 0x6724: call   6729 <perf_unwind_native+0x6729> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6729:
	/* 0x6729: jmp    6744 <perf_unwind_native+0x6744> */
	X86_SIM_X86_JMP(0x6729, 0x6744, x86_l_6744);
x86_l_672b:
	/* 0x672b: mov    rax,QWORD PTR [rsp+0x120] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_6733:
	/* 0x6733: cmp    BYTE PTR [rax],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_6736:
	/* 0x6736: jne    6744 <perf_unwind_native+0x6744> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6736, 0x6744, x86_l_6744);
x86_l_6738:
	/* 0x6738: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_673d:
	/* 0x673d: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6744:
	/* 0x6744: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6747:
	/* 0x6747: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_674c:
	/* 0x674c: je     1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_E, 0x674c, 0x1522, x86_l_1522);
x86_l_6752:
	/* 0x6752: lea    rdx,[r13-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_6756:
	/* 0x6756: mov    rdi,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_675e:
	/* 0x675e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_6763:
	/* 0x6763: call   6768 <perf_unwind_native+0x6768> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_6768:
	/* 0x6768: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_676b:
	/* 0x676b: jne    1522 <perf_unwind_native+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x676b, 0x1522, x86_l_1522);
x86_l_6771:
	/* 0x6771: mov    QWORD PTR [rbx+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_6778:
	/* 0x6778: mov    BYTE PTR [rbx+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_677f:
	/* 0x677f: mov    DWORD PTR [rsp+0x70],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337158ULL);
x86_l_6787:
	/* 0x6787: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_678e:
	/* 0x678e: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6793:
	/* 0x6793: call   6798 <perf_unwind_native+0x6798> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6798:
	/* 0x6798: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_679b:
	/* 0x679b: je     67b3 <perf_unwind_native+0x67b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x679b, 0x67b3, x86_l_67b3);
x86_l_679d:
	/* 0x679d: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_67a0:
	/* 0x67a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_67a2:
	/* 0x67a2: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_67a9:
	/* 0x67a9: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_67ac:
	/* 0x67ac: je     67c5 <perf_unwind_native+0x67c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67ac, 0x67c5, x86_l_67c5);
x86_l_67ae:
	/* 0x67ae: jmp    6b70 <perf_unwind_native+0x6b70> */
	X86_SIM_X86_JMP(0x67ae, 0x6b70, x86_l_6b70);
x86_l_67b3:
	/* 0x67b3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_67ba:
	/* 0x67ba: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_67bd:
	/* 0x67bd: jne    6aec <perf_unwind_native+0x6aec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67bd, 0x6aec, x86_l_6aec);
x86_l_67c3:
	/* 0x67c3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_67c5:
	/* 0x67c5: mov    rcx,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_67cd:
	/* 0x67cd: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_67d0:
	/* 0x67d0: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_67d3:
	/* 0x67d3: je     696b <perf_unwind_native+0x696b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67d3, 0x696b, x86_l_696b);
x86_l_67d9:
	/* 0x67d9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_67db:
	/* 0x67db: jne    6bf6 <perf_unwind_native+0x6bf6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x67db, 0x6bf6, x86_l_6bf6);
x86_l_67e1:
	/* 0x67e1: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_67eb:
	/* 0x67eb: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67ee:
	/* 0x67ee: ja     3034 <perf_unwind_native+0x3034> */
	X86_SIM_X86_JCC(X86_CC_A, 0x67ee, 0x3034, x86_l_3034);
x86_l_67f4:
	/* 0x67f4: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_67fb:
	/* 0x67fb: jb     3174 <perf_unwind_native+0x3174> */
	X86_SIM_X86_JCC(X86_CC_B, 0x67fb, 0x3174, x86_l_3174);
x86_l_6801:
	/* 0x6801: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6803:
	/* 0x6803: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_680b:
	/* 0x680b: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_6811:
	/* 0x6811: movbe  QWORD PTR [rsp+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_6818:
	/* 0x6818: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_681f:
	/* 0x681f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6824:
	/* 0x6824: call   6829 <perf_unwind_native+0x6829> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6829:
	/* 0x6829: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_682c:
	/* 0x682c: je     6a1d <perf_unwind_native+0x6a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x682c, 0x6a1d, x86_l_6a1d);
x86_l_6832:
	/* 0x6832: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6836:
	/* 0x6836: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_6840:
	/* 0x6840: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_6843:
	/* 0x6843: mov    QWORD PTR [rbx+0xf20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_684a:
	/* 0x684a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_684d:
	/* 0x684d: mov    QWORD PTR [rbx+0xf10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6854:
	/* 0x6854: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_6858:
	/* 0x6858: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_685b:
	/* 0x685b: sub    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_685e:
	/* 0x685e: mov    QWORD PTR [rbx+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6865:
	/* 0x6865: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_686c:
	/* 0x686c: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_686f:
	/* 0x686f: jne    6ca6 <perf_unwind_native+0x6ca6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x686f, 0x6ca6, x86_l_6ca6);
x86_l_6875:
	/* 0x6875: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_6879:
	/* 0x6879: jne    6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6879, 0x6e79, x86_l_6e79);
x86_l_687f:
	/* 0x687f: mov    rax,QWORD PTR [rbx+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_6886:
	/* 0x6886: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_688b:
	/* 0x688b: mov    r15,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6892:
	/* 0x6892: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_6899:
	/* 0x6899: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_689e:
	/* 0x689e: call   68a3 <perf_unwind_native+0x68a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_68a3:
	/* 0x68a3: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_68a9:
	/* 0x68a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68ac:
	/* 0x68ac: je     6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x68ac, 0x6e79, x86_l_6e79);
x86_l_68b2:
	/* 0x68b2: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68b5:
	/* 0x68b5: cmp    QWORD PTR [rax],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_68b8:
	/* 0x68b8: ja     68c0 <perf_unwind_native+0x68c0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x68b8, 0x68c0, x86_l_68c0);
x86_l_68ba:
	/* 0x68ba: cmp    QWORD PTR [r14+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_68be:
	/* 0x68be: jae    68d4 <perf_unwind_native+0x68d4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x68be, 0x68d4, x86_l_68d4);
x86_l_68c0:
	/* 0x68c0: cmp    QWORD PTR [r14+0x10],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_68c4:
	/* 0x68c4: ja     6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_A, 0x68c4, 0x6e79, x86_l_6e79);
x86_l_68ca:
	/* 0x68ca: cmp    QWORD PTR [r14+0x18],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_68ce:
	/* 0x68ce: jb     6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_B, 0x68ce, 0x6e79, x86_l_6e79);
x86_l_68d4:
	/* 0x68d4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_68db:
	/* 0x68db: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_68de:
	/* 0x68de: jne    6dce <perf_unwind_native+0x6dce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68de, 0x6dce, x86_l_6dce);
x86_l_68e4:
	/* 0x68e4: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_68ea:
	/* 0x68ea: mov    ecx,DWORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_68ee:
	/* 0x68ee: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_68f1:
	/* 0x68f1: jae    6e45 <perf_unwind_native+0x6e45> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x68f1, 0x6e45, x86_l_6e45);
x86_l_68f7:
	/* 0x68f7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_68fe:
	/* 0x68fe: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6901:
	/* 0x6901: je     6e79 <perf_unwind_native+0x6e79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6901, 0x6e79, x86_l_6e79);
x86_l_6907:
	/* 0x6907: movabs rax,0x6e6f64207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7957689157107934318ULL);
x86_l_6911:
	/* 0x6911: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6919:
	/* 0x6919: movabs rax,0x69776e7520726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345545598324ULL);
x86_l_6923:
	/* 0x6923: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_692b:
	/* 0x692b: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_6935:
	/* 0x6935: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_693d:
	/* 0x693d: mov    DWORD PTR [rsp+0xa7],0xa656e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 717260219758ULL);
x86_l_6948:
	/* 0x6948: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6950:
	/* 0x6950: mov    esi,0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_6955:
	/* 0x6955: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6957:
	/* 0x6957: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6959:
	/* 0x6959: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_695c:
	/* 0x695c: call   6961 <perf_unwind_native+0x6961> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6961:
	/* 0x6961: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_6966:
	/* 0x6966: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x6966, 0x541d, x86_l_541d);
x86_l_696b:
	/* 0x696b: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_6970:
	/* 0x6970: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_6972:
	/* 0x6972: jne    698b <perf_unwind_native+0x698b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6972, 0x698b, x86_l_698b);
x86_l_6974:
	/* 0x6974: mov    DWORD PTR [rbx+0xf28],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108481ULL);
x86_l_697e:
	/* 0x697e: mov    ebp,0xfad */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4013ULL);
x86_l_6983:
	/* 0x6983: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6986:
	/* 0x6986: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x6986, 0x541d, x86_l_541d);
x86_l_698b:
	/* 0x698b: movabs rax,0xa2930203d3d2043 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 732169329448919107ULL);
x86_l_6995:
	/* 0x6995: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_699d:
	/* 0x699d: movabs rax,0x5028206572756c69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5775902142186744937ULL);
x86_l_69a7:
	/* 0x69a7: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_69af:
	/* 0x69af: movabs rax,0x616620646e69776e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7018332685024720750ULL);
x86_l_69b9:
	/* 0x69b9: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_69c1:
	/* 0x69c1: movabs rax,0x75206f7420657564 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8439868246242719076ULL);
x86_l_69cb:
	/* 0x69cb: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_69d3:
	/* 0x69d3: movabs rax,0x20646e69776e7520 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334111906139108640ULL);
x86_l_69dd:
	/* 0x69dd: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_69e5:
	/* 0x69e5: movabs rax,0x676e6970706f7453 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7453010364988355667ULL);
x86_l_69ef:
	/* 0x69ef: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_69f7:
	/* 0x69f7: mov    BYTE PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_69ff:
	/* 0x69ff: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6a07:
	/* 0x6a07: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_6a0c:
	/* 0x6a0c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a0e:
	/* 0x6a0e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a10:
	/* 0x6a10: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a13:
	/* 0x6a13: call   6a18 <perf_unwind_native+0x6a18> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6a18:
	/* 0x6a18: jmp    6974 <perf_unwind_native+0x6974> */
	X86_SIM_X86_JMP(0x6a18, 0x6974, x86_l_6974);
x86_l_6a1d:
	/* 0x6a1d: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_6a22:
	/* 0x6a22: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6a29:
	/* 0x6a29: cmp    DWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6a2e:
	/* 0x6a2e: jne    6a47 <perf_unwind_native+0x6a47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a2e, 0x6a47, x86_l_6a47);
x86_l_6a30:
	/* 0x6a30: mov    DWORD PTR [rbx+0xf28],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108492ULL);
x86_l_6a3a:
	/* 0x6a3a: mov    ebp,0xfac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4012ULL);
x86_l_6a3f:
	/* 0x6a3f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a42:
	/* 0x6a42: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x6a42, 0x541d, x86_l_541d);
x86_l_6a47:
	/* 0x6a47: movabs rax,0xa786c2578302043 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 754471845770567747ULL);
x86_l_6a51:
	/* 0x6a51: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_6a59:
	/* 0x6a59: movabs rax,0x5020726f6620676e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5773740545069311854ULL);
x86_l_6a63:
	/* 0x6a63: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_6a6b:
	/* 0x6a6b: movabs rax,0x697070616d207972 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7597696135119010162ULL);
x86_l_6a75:
	/* 0x6a75: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_6a7d:
	/* 0x6a7d: movabs rax,0x6f6d656d206c6176 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8029185230041276790ULL);
x86_l_6a87:
	/* 0x6a87: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6a8f:
	/* 0x6a8f: movabs rax,0x7265746e69207075 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243122710530519157ULL);
x86_l_6a99:
	/* 0x6a99: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6aa1:
	/* 0x6aa1: movabs rax,0x206b6f6f6c206f74 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2336083356067852148ULL);
x86_l_6aab:
	/* 0x6aab: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6ab3:
	/* 0x6ab3: movabs rax,0x206572756c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334397830517055814ULL);
x86_l_6abd:
	/* 0x6abd: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6ac5:
	/* 0x6ac5: mov    BYTE PTR [rsp+0xc8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 858993459200ULL);
x86_l_6acd:
	/* 0x6acd: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6ad5:
	/* 0x6ad5: mov    esi,0x39 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_6ada:
	/* 0x6ada: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6add:
	/* 0x6add: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6adf:
	/* 0x6adf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ae2:
	/* 0x6ae2: call   6ae7 <perf_unwind_native+0x6ae7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6ae7:
	/* 0x6ae7: jmp    6a30 <perf_unwind_native+0x6a30> */
	X86_SIM_X86_JMP(0x6ae7, 0x6a30, x86_l_6a30);
x86_l_6aec:
	/* 0x6aec: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_6af6:
	/* 0x6af6: mov    QWORD PTR [rsp+0x36],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 54ULL);
x86_l_6afb:
	/* 0x6afb: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_6b05:
	/* 0x6b05: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6b0a:
	/* 0x6b0a: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_6b14:
	/* 0x6b14: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6b19:
	/* 0x6b19: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_6b23:
	/* 0x6b23: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6b28:
	/* 0x6b28: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_6b32:
	/* 0x6b32: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6b37:
	/* 0x6b37: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_6b41:
	/* 0x6b41: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b46:
	/* 0x6b46: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6b4a:
	/* 0x6b4a: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b4f:
	/* 0x6b4f: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_6b54:
	/* 0x6b54: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b56:
	/* 0x6b56: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b59:
	/* 0x6b59: call   6b5e <perf_unwind_native+0x6b5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6b5e:
	/* 0x6b5e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b60:
	/* 0x6b60: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6b67:
	/* 0x6b67: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b6a:
	/* 0x6b6a: je     67c5 <perf_unwind_native+0x67c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b6a, 0x67c5, x86_l_67c5);
x86_l_6b70:
	/* 0x6b70: movabs rax,0xa786c6c25203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280058ULL);
x86_l_6b7a:
	/* 0x6b7a: mov    QWORD PTR [rsp+0xa5],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_6b82:
	/* 0x6b82: movabs rax,0x25203a706620786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675202433082226796ULL);
x86_l_6b8c:
	/* 0x6b8c: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6b94:
	/* 0x6b94: movabs rax,0x6c25203a70732078 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670165601296504ULL);
x86_l_6b9e:
	/* 0x6b9e: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6ba6:
	/* 0x6ba6: movabs rax,0x6c6c25203a637020 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660273929744416ULL);
x86_l_6bb0:
	/* 0x6bb0: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6bb8:
	/* 0x6bb8: mov    rax,QWORD PTR [rsp+0x138] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 312ULL);
x86_l_6bc0:
	/* 0x6bc0: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6bc3:
	/* 0x6bc3: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_6bcb:
	/* 0x6bcb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6bce:
	/* 0x6bce: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_6bd3:
	/* 0x6bd3: mov    r8,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6bd6:
	/* 0x6bd6: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6bde:
	/* 0x6bde: mov    esi,0x1d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_6be3:
	/* 0x6be3: call   6be8 <perf_unwind_native+0x6be8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6be8:
	/* 0x6be8: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6bef:
	/* 0x6bef: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6bf1:
	/* 0x6bf1: jmp    67c5 <perf_unwind_native+0x67c5> */
	X86_SIM_X86_JMP(0x6bf1, 0x67c5, x86_l_67c5);
x86_l_6bf6:
	/* 0x6bf6: movabs rax,0xa3d3d3d3d206425 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 737813247186461733ULL);
x86_l_6c00:
	/* 0x6c00: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_6c08:
	/* 0x6c08: movabs rax,0x20656d617266203a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021050ULL);
x86_l_6c12:
	/* 0x6c12: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_6c1a:
	/* 0x6c1a: movabs rax,0x7265646e69776e75 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8243105118350175861ULL);
x86_l_6c24:
	/* 0x6c24: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6c2c:
	/* 0x6c2c: movabs rax,0x20656d6172662074 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334392247160021108ULL);
x86_l_6c36:
	/* 0x6c36: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6c3e:
	/* 0x6c3e: movabs rax,0x78656e2065766c6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8675461342619397231ULL);
x86_l_6c48:
	/* 0x6c48: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6c50:
	/* 0x6c50: movabs rax,0x736552203d3d3d3d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315142585429343549ULL);
x86_l_6c5a:
	/* 0x6c5a: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6c62:
	/* 0x6c62: mov    BYTE PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_6c6a:
	/* 0x6c6a: mov    edx,DWORD PTR [rbx+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6c70:
	/* 0x6c70: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6c78:
	/* 0x6c78: mov    esi,0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 49ULL);
x86_l_6c7d:
	/* 0x6c7d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6c7f:
	/* 0x6c7f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6c82:
	/* 0x6c82: call   6c87 <perf_unwind_native+0x6c87> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6c87:
	/* 0x6c87: mov    r13,QWORD PTR [rbx+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_6c8e:
	/* 0x6c8e: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_6c98:
	/* 0x6c98: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c9b:
	/* 0x6c9b: ja     3034 <perf_unwind_native+0x3034> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6c9b, 0x3034, x86_l_3034);
x86_l_6ca1:
	/* 0x6ca1: jmp    67f4 <perf_unwind_native+0x67f4> */
	X86_SIM_X86_JMP(0x6ca1, 0x67f4, x86_l_67f4);
x86_l_6ca6:
	/* 0x6ca6: movabs rax,0x296425207265646e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2982549674514539630ULL);
x86_l_6cb0:
	/* 0x6cb0: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_6cb8:
	/* 0x6cb8: movabs rax,0x69776e752820786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7599664345674446956ULL);
x86_l_6cc2:
	/* 0x6cc2: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_6cca:
	/* 0x6cca: movabs rax,0x6c2520736920786c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7792670410291574892ULL);
x86_l_6cd4:
	/* 0x6cd4: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6cdc:
	/* 0x6cdc: movabs rax,0x2520435020726f66 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2675212190078889830ULL);
x86_l_6ce6:
	/* 0x6ce6: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6cee:
	/* 0x6cee: movabs rax,0x206469206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2334106094897424756ULL);
x86_l_6cf8:
	/* 0x6cf8: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6d00:
	/* 0x6d00: movabs r14,0x6365732074786554 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 7162257365632836948ULL);
x86_l_6d0a:
	/* 0x6d0a: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6d12:
	/* 0x6d12: mov    WORD PTR [rsp+0xc0],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 824633720842ULL);
x86_l_6d1c:
	/* 0x6d1c: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6d24:
	/* 0x6d24: mov    esi,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_6d29:
	/* 0x6d29: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6d2c:
	/* 0x6d2c: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6d2f:
	/* 0x6d2f: call   6d34 <perf_unwind_native+0x6d34> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6d34:
	/* 0x6d34: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6d3b:
	/* 0x6d3b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d3e:
	/* 0x6d3e: je     6875 <perf_unwind_native+0x6875> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d3e, 0x6875, x86_l_6875);
x86_l_6d44:
	/* 0x6d44: movabs rax,0xa786c6c252073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2947156833280115ULL);
x86_l_6d4e:
	/* 0x6d4e: mov    QWORD PTR [rsp+0xb7],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 183ULL);
x86_l_6d56:
	/* 0x6d56: movabs rax,0x7369207465736666 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8316213871206688358ULL);
x86_l_6d60:
	/* 0x6d60: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_6d68:
	/* 0x6d68: movabs rax,0x6f20646e61202c78 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8007510562703420536ULL);
x86_l_6d72:
	/* 0x6d72: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6d7a:
	/* 0x6d7a: movabs rax,0x6c6c252073692073 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7812660274886418547ULL);
x86_l_6d84:
	/* 0x6d84: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6d8c:
	/* 0x6d8c: movabs rax,0x616962206e6f6974 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7019249385664899444ULL);
x86_l_6d96:
	/* 0x6d96: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6d9e:
	/* 0x6d9e: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6da6:
	/* 0x6da6: mov    rcx,QWORD PTR [rbx+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_6dad:
	/* 0x6dad: mov    rdx,QWORD PTR [rbx+0xf20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_6db4:
	/* 0x6db4: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6dbc:
	/* 0x6dbc: mov    esi,0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 47ULL);
x86_l_6dc1:
	/* 0x6dc1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6dc4:
	/* 0x6dc4: call   6dc9 <perf_unwind_native+0x6dc9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6dc9:
	/* 0x6dc9: jmp    6875 <perf_unwind_native+0x6875> */
	X86_SIM_X86_JMP(0x6dc9, 0x6875, x86_l_6875);
x86_l_6dce:
	/* 0x6dce: movabs rax,0xa642520686374 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860387386228ULL);
x86_l_6dd8:
	/* 0x6dd8: mov    QWORD PTR [rsp+0xa6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_6de0:
	/* 0x6de0: movabs rax,0x6374616d20737465 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7166460028377068645ULL);
x86_l_6dea:
	/* 0x6dea: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6df2:
	/* 0x6df2: movabs rax,0x7366666f5f726574 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8315446390514935156ULL);
x86_l_6dfc:
	/* 0x6dfc: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6e04:
	/* 0x6e04: movabs rax,0x6572707265746e69 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310028781806448233ULL);
x86_l_6e0e:
	/* 0x6e0e: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6e16:
	/* 0x6e16: movzx  edx,WORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6e1b:
	/* 0x6e1b: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6e23:
	/* 0x6e23: mov    esi,0x1e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_6e28:
	/* 0x6e28: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e2a:
	/* 0x6e2a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e2d:
	/* 0x6e2d: call   6e32 <perf_unwind_native+0x6e32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6e32:
	/* 0x6e32: mov    eax,DWORD PTR [rbx+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_6e38:
	/* 0x6e38: mov    ecx,DWORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6e3c:
	/* 0x6e3c: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6e3f:
	/* 0x6e3f: jb     68f7 <perf_unwind_native+0x68f7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6e3f, 0x68f7, x86_l_68f7);
x86_l_6e45:
	/* 0x6e45: mov    DWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_6e4d:
	/* 0x6e4d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_6e54:
	/* 0x6e54: lea    rsi,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6e59:
	/* 0x6e59: call   6e5e <perf_unwind_native+0x6e5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6e5e:
	/* 0x6e5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e61:
	/* 0x6e61: je     6e68 <perf_unwind_native+0x6e68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e61, 0x6e68, x86_l_6e68);
x86_l_6e63:
	/* 0x6e63: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6e66:
	/* 0x6e66: jmp    6e74 <perf_unwind_native+0x6e74> */
	X86_SIM_X86_JMP(0x6e66, 0x6e74, x86_l_6e74);
x86_l_6e68:
	/* 0x6e68: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&with_debug_output));
x86_l_6e6f:
	/* 0x6e6f: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e72:
	/* 0x6e72: jne    6e83 <perf_unwind_native+0x6e83> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e72, 0x6e83, x86_l_6e83);
x86_l_6e74:
	/* 0x6e74: movzx  r12d,WORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6e79:
	/* 0x6e79: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_6e7e:
	/* 0x6e7e: jmp    541d <perf_unwind_native+0x541d> */
	X86_SIM_X86_JMP(0x6e7e, 0x541d, x86_l_541d);
x86_l_6e83:
	/* 0x6e83: movabs rax,0xa642520444963 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 2924860385020259ULL);
x86_l_6e8d:
	/* 0x6e8d: mov    QWORD PTR [rsp+0xb6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 182ULL);
x86_l_6e95:
	/* 0x6e95: movabs rax,0x4963697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 5288186327763086624ULL);
x86_l_6e9f:
	/* 0x6e9f: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_6ea7:
	/* 0x6ea7: movabs rax,0x726f662070616d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8245921732249087264ULL);
x86_l_6eb1:
	/* 0x6eb1: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6eb9:
	/* 0x6eb9: movabs rax,0x7363697274656d20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8314605277356059936ULL);
x86_l_6ec3:
	/* 0x6ec3: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_6ecb:
	/* 0x6ecb: movabs rax,0x70756b6f6f6c206f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8103501230877974639ULL);
x86_l_6ed5:
	/* 0x6ed5: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_6edd:
	/* 0x6edd: movabs rax,0x742064656c696146 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8367798494427701574ULL);
x86_l_6ee7:
	/* 0x6ee7: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6eef:
	/* 0x6eef: mov    edx,DWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_6ef3:
	/* 0x6ef3: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6efb:
	/* 0x6efb: mov    esi,0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 46ULL);
x86_l_6f00:
	/* 0x6f00: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f02:
	/* 0x6f02: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f05:
	/* 0x6f05: call   6f0a <perf_unwind_native+0x6f0a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_trace_printk);
x86_l_6f0a:
	/* 0x6f0a: jmp    6e74 <perf_unwind_native+0x6e74> */
	X86_SIM_X86_JMP(0x6f0a, 0x6e74, x86_l_6e74);
x86_l_6f0f:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
