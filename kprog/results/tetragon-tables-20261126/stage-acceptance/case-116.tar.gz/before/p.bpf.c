#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_5:
	/* 0x5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: je     77 <bpf_strncasestr+0x77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8, 0x77, x86_l_77);
x86_l_a:
	/* 0xa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c:
	/* 0xc: jmp    19 <bpf_strncasestr+0x19> */
	X86_SIM_X86_JMP(0xc, 0x19, x86_l_19);
x86_l_e:
	/* 0xe: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_11:
	/* 0x11: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_14:
	/* 0x14: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17:
	/* 0x17: je     77 <bpf_strncasestr+0x77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17, 0x77, x86_l_77);
x86_l_19:
	/* 0x19: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c:
	/* 0x1c: lea    r9,[rcx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_20:
	/* 0x20: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23:
	/* 0x23: jae    e <bpf_strncasestr+0xe> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x23, 0xe, x86_l_e);
x86_l_25:
	/* 0x25: movsx  r9d,BYTE PTR [rsi+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R9, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_2a:
	/* 0x2a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2d:
	/* 0x2d: je     75 <bpf_strncasestr+0x75> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x75, x86_l_75);
x86_l_2f:
	/* 0x2f: movsx  r10d,BYTE PTR [rdi+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_34:
	/* 0x34: lea    r11d,[r10-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_38:
	/* 0x38: cmp    r11d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_3c:
	/* 0x3c: jb     4f <bpf_strncasestr+0x4f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3c, 0x4f, x86_l_4f);
x86_l_3e:
	/* 0x3e: lea    r11d,[r9-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_42:
	/* 0x42: cmp    r11d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_46:
	/* 0x46: jb     5d <bpf_strncasestr+0x5d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x46, 0x5d, x86_l_5d);
x86_l_48:
	/* 0x48: cmp    r10d,r9d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_4b:
	/* 0x4b: je     66 <bpf_strncasestr+0x66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b, 0x66, x86_l_66);
x86_l_4d:
	/* 0x4d: jmp    e <bpf_strncasestr+0xe> */
	X86_SIM_X86_JMP(0x4d, 0xe, x86_l_e);
x86_l_4f:
	/* 0x4f: or     r10d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_53:
	/* 0x53: lea    r11d,[r9-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_57:
	/* 0x57: cmp    r11d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_5b:
	/* 0x5b: jae    48 <bpf_strncasestr+0x48> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5b, 0x48, x86_l_48);
x86_l_5d:
	/* 0x5d: or     r9d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_61:
	/* 0x61: cmp    r10d,r9d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_64:
	/* 0x64: jne    e <bpf_strncasestr+0xe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x64, 0xe, x86_l_e);
x86_l_66:
	/* 0x66: lea    r9,[r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_6a:
	/* 0x6a: cmp    r8,0x63 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 99ULL);
x86_l_6e:
	/* 0x6e: mov    r8,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_71:
	/* 0x71: jb     1c <bpf_strncasestr+0x1c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x71, 0x1c, x86_l_1c);
x86_l_73:
	/* 0x73: jmp    e <bpf_strncasestr+0xe> */
	X86_SIM_X86_JMP(0x73, 0xe, x86_l_e);
x86_l_75:
	/* 0x75: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_77:
	/* 0x77: jmp    7c <bpf_strncasestr+0x7c> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_7c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
