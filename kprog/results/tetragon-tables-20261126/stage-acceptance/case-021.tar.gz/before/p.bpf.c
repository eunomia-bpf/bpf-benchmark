#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 cgroup_map[] __ksym;
extern __u8 data[] __ksym;
extern __u8 start[] __ksym;
static const __u8 __x86_rodata_0[32] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(7):.rodata:table_10\",\"size\":32}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tracepoint/raw_syscalls/sys_exit")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_d:
	/* 0xd: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_cg));
x86_l_17:
	/* 0x17: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a:
	/* 0x1a: je     33 <sys_exit+0x33> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a, 0x33, x86_l_33);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_map));
x86_l_23:
	/* 0x23: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25:
	/* 0x25: call   2a <sys_exit+0x2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_current_task_under_cgroup);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x280, x86_l_280);
x86_l_33:
	/* 0x33: call   38 <sys_exit+0x38> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_38:
	/* 0x38: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3c:
	/* 0x3c: cmp    QWORD PTR [r14+0x8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_41:
	/* 0x41: je     280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41, 0x280, x86_l_280);
x86_l_47:
	/* 0x47: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_pid));
x86_l_4e:
	/* 0x4e: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51:
	/* 0x51: je     64 <sys_exit+0x64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51, 0x64, x86_l_64);
x86_l_53:
	/* 0x53: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: shr    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_5a:
	/* 0x5a: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c:
	/* 0x5c: cmp    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_5e:
	/* 0x5e: jne    280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5e, 0x280, x86_l_280);
x86_l_64:
	/* 0x64: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_failed));
x86_l_6b:
	/* 0x6b: cmp    BYTE PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e:
	/* 0x6e: je     7b <sys_exit+0x7b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e, 0x7b, x86_l_7b);
x86_l_70:
	/* 0x70: cmp    QWORD PTR [r14+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_75:
	/* 0x75: jns    280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x75, 0x280, x86_l_280);
x86_l_7b:
	/* 0x7b: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_errno));
x86_l_82:
	/* 0x82: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85:
	/* 0x85: je     94 <sys_exit+0x94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85, 0x94, x86_l_94);
x86_l_87:
	/* 0x87: movsxd rcx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_8a:
	/* 0x8a: add    rcx,QWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_8e:
	/* 0x8e: jne    280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8e, 0x280, x86_l_280);
x86_l_94:
	/* 0x94: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&measure_latency));
x86_l_9b:
	/* 0x9b: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a0:
	/* 0xa0: je     e3 <sys_exit+0xe3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa0, 0xe3, x86_l_e3);
x86_l_a2:
	/* 0xa2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_a9:
	/* 0xa9: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ae:
	/* 0xae: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1:
	/* 0xb1: call   b6 <sys_exit+0xb6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b6:
	/* 0xb6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b9:
	/* 0xb9: je     280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9, 0x280, x86_l_280);
x86_l_bf:
	/* 0xbf: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c2:
	/* 0xc2: call   c7 <sys_exit+0xc7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_c7:
	/* 0xc7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ca:
	/* 0xca: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cd:
	/* 0xcd: sub    rbx,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_d0:
	/* 0xd0: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&count_by_process));
x86_l_d7:
	/* 0xd7: cmp    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_db:
	/* 0xdb: je     f2 <sys_exit+0xf2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb, 0xf2, x86_l_f2);
x86_l_dd:
	/* 0xdd: sar    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SAR, 32ULL);
x86_l_e1:
	/* 0xe1: jmp    f6 <sys_exit+0xf6> */
	X86_SIM_X86_JMP(0xe1, 0xf6, x86_l_f6);
x86_l_e3:
	/* 0xe3: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e5:
	/* 0xe5: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&count_by_process));
x86_l_ec:
	/* 0xec: cmp    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f0:
	/* 0xf0: jne    dd <sys_exit+0xdd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf0, 0xdd, x86_l_dd);
x86_l_f2:
	/* 0xf2: mov    rax,QWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f6:
	/* 0xf6: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa:
	/* 0xfa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data));
x86_l_101:
	/* 0x101: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_106:
	/* 0x106: call   10b <sys_exit+0x10b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10b:
	/* 0x10b: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e:
	/* 0x10e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_111:
	/* 0x111: je     136 <sys_exit+0x136> */
	X86_SIM_X86_JCC(X86_CC_E, 0x111, 0x136, x86_l_136);
x86_l_113:
	/* 0x113: lock inc QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_117:
	/* 0x117: cmp    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11b:
	/* 0x11b: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11b, 0x274, x86_l_274);
x86_l_121:
	/* 0x121: call   126 <sys_exit+0x126> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_126:
	/* 0x126: add    rax,0xb30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2864ULL);
x86_l_12c:
	/* 0x12c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12f:
	/* 0x12f: jns    180 <sys_exit+0x180> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f, 0x180, x86_l_180);
x86_l_131:
	/* 0x131: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_134:
	/* 0x134: jmp    182 <sys_exit+0x182> */
	X86_SIM_X86_JMP(0x134, 0x182, x86_l_182);
x86_l_136:
	/* 0x136: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data));
x86_l_13d:
	/* 0x13d: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_144:
	/* 0x144: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_149:
	/* 0x149: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_14e:
	/* 0x14e: call   153 <sys_exit+0x153> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_153:
	/* 0x153: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_156:
	/* 0x156: je     162 <sys_exit+0x162> */
	X86_SIM_X86_JCC(X86_CC_E, 0x156, 0x162, x86_l_162);
x86_l_158:
	/* 0x158: cmp    rax,0xffffffffffffffef */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551599ULL);
x86_l_15c:
	/* 0x15c: jne    280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15c, 0x280, x86_l_280);
x86_l_162:
	/* 0x162: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data));
x86_l_169:
	/* 0x169: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16e:
	/* 0x16e: call   173 <sys_exit+0x173> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_173:
	/* 0x173: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_176:
	/* 0x176: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_179:
	/* 0x179: jne    113 <sys_exit+0x113> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x179, 0x113, x86_l_113);
x86_l_17b:
	/* 0x17b: jmp    280 <sys_exit+0x280> */
	X86_SIM_X86_JMP(0x17b, 0x280, x86_l_280);
x86_l_180:
	/* 0x180: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_182:
	/* 0x182: lea    rcx,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_186:
	/* 0x186: add    rax,0xd10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3344ULL);
x86_l_18c:
	/* 0x18c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18f:
	/* 0x18f: jns    265 <sys_exit+0x265> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18f, 0x265, x86_l_265);
x86_l_195:
	/* 0x195: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_198:
	/* 0x198: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19a:
	/* 0x19a: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_19c:
	/* 0x19c: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c, 0x274, x86_l_274);
x86_l_1a2:
	/* 0x1a2: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1a6:
	/* 0x1a6: mov    BYTE PTR [r14+0x11],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17ULL);
x86_l_1aa:
	/* 0x1aa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ac:
	/* 0x1ac: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac, 0x274, x86_l_274);
x86_l_1b2:
	/* 0x1b2: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1b6:
	/* 0x1b6: mov    BYTE PTR [r14+0x12],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_1ba:
	/* 0x1ba: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1bc:
	/* 0x1bc: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc, 0x274, x86_l_274);
x86_l_1c2:
	/* 0x1c2: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1c6:
	/* 0x1c6: mov    BYTE PTR [r14+0x13],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 19ULL);
x86_l_1ca:
	/* 0x1ca: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1cc:
	/* 0x1cc: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc, 0x274, x86_l_274);
x86_l_1d2:
	/* 0x1d2: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1d6:
	/* 0x1d6: mov    BYTE PTR [r14+0x14],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1da:
	/* 0x1da: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1dc:
	/* 0x1dc: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dc, 0x274, x86_l_274);
x86_l_1e2:
	/* 0x1e2: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1e6:
	/* 0x1e6: mov    BYTE PTR [r14+0x15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 21ULL);
x86_l_1ea:
	/* 0x1ea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ec:
	/* 0x1ec: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec, 0x274, x86_l_274);
x86_l_1f2:
	/* 0x1f2: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1f6:
	/* 0x1f6: mov    BYTE PTR [r14+0x16],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_1fa:
	/* 0x1fa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1fc:
	/* 0x1fc: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc, 0x274, x86_l_274);
x86_l_1fe:
	/* 0x1fe: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_202:
	/* 0x202: mov    BYTE PTR [r14+0x17],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 23ULL);
x86_l_206:
	/* 0x206: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_208:
	/* 0x208: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x208, 0x274, x86_l_274);
x86_l_20a:
	/* 0x20a: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_20e:
	/* 0x20e: mov    BYTE PTR [r14+0x18],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_212:
	/* 0x212: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_214:
	/* 0x214: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x214, 0x274, x86_l_274);
x86_l_216:
	/* 0x216: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_21a:
	/* 0x21a: mov    BYTE PTR [r14+0x19],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 25ULL);
x86_l_21e:
	/* 0x21e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_220:
	/* 0x220: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x220, 0x274, x86_l_274);
x86_l_222:
	/* 0x222: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_226:
	/* 0x226: mov    BYTE PTR [r14+0x1a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_22a:
	/* 0x22a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22c:
	/* 0x22c: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c, 0x274, x86_l_274);
x86_l_22e:
	/* 0x22e: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_232:
	/* 0x232: mov    BYTE PTR [r14+0x1b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 27ULL);
x86_l_236:
	/* 0x236: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_238:
	/* 0x238: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x238, 0x274, x86_l_274);
x86_l_23a:
	/* 0x23a: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_23e:
	/* 0x23e: mov    BYTE PTR [r14+0x1c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_242:
	/* 0x242: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_244:
	/* 0x244: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244, 0x274, x86_l_274);
x86_l_246:
	/* 0x246: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_24a:
	/* 0x24a: mov    BYTE PTR [r14+0x1d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 29ULL);
x86_l_24e:
	/* 0x24e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_250:
	/* 0x250: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x250, 0x274, x86_l_274);
x86_l_252:
	/* 0x252: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_256:
	/* 0x256: mov    BYTE PTR [r14+0x1e],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_25a:
	/* 0x25a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_25c:
	/* 0x25c: je     274 <sys_exit+0x274> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c, 0x274, x86_l_274);
x86_l_25e:
	/* 0x25e: mov    BYTE PTR [r14+0x1f],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986176ULL);
x86_l_263:
	/* 0x263: jmp    274 <sys_exit+0x274> */
	X86_SIM_X86_JMP(0x263, 0x274, x86_l_274);
x86_l_265:
	/* 0x265: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_26d:
	/* 0x26d: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274:
	/* 0x274: cmp    BYTE PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_279:
	/* 0x279: je     280 <sys_exit+0x280> */
	X86_SIM_X86_JCC(X86_CC_E, 0x279, 0x280, x86_l_280);
x86_l_27b:
	/* 0x27b: lock add QWORD PTR [r14+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R14, X86_RBX, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_280:
	/* 0x280: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_282:
	/* 0x282: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_286:
	/* 0x286: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_287:
	/* 0x287: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_289:
	/* 0x289: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28b:
	/* 0x28b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28d:
	/* 0x28d: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28f:
	/* 0x28f: jmp    294 <sys_exit+0x294> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_294:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
