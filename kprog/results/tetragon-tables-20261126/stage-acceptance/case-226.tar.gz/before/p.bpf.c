#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 200U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bpf_attach_tmp_map[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/check_helper_call")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 152ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x84],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_check_helper_call+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x119b, x86_l_119b);
x86_l_3c:
	/* 0x3c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_check_helper_call+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x119b, x86_l_119b);
x86_l_5c:
	/* 0x5c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    WORD PTR [rbx+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_68:
	/* 0x68: mov    BYTE PTR [rbx+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_6f:
	/* 0x6f: mov    QWORD PTR [rbx+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7a:
	/* 0x7a: mov    QWORD PTR [rbx+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_85:
	/* 0x85: mov    QWORD PTR [rbx+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_90:
	/* 0x90: mov    QWORD PTR [rbx+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9b:
	/* 0x9b: mov    QWORD PTR [rbx+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a6:
	/* 0xa6: mov    QWORD PTR [rbx+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b1:
	/* 0xb1: mov    QWORD PTR [rbx+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bc:
	/* 0xbc: mov    QWORD PTR [rbx+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_c7:
	/* 0xc7: call   cc <trace_check_helper_call+0xcc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cc:
	/* 0xcc: mov    QWORD PTR [rbx+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d3:
	/* 0xd3: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_db:
	/* 0xdb: mov    QWORD PTR [rbx+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e3:
	/* 0xe3: mov    QWORD PTR [rbx+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_eb:
	/* 0xeb: mov    QWORD PTR [rbx+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f3:
	/* 0xf3: mov    QWORD PTR [rbx+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fb:
	/* 0xfb: mov    QWORD PTR [rbx+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_103:
	/* 0x103: mov    QWORD PTR [rbx+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10b:
	/* 0x10b: mov    QWORD PTR [rbx+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_113:
	/* 0x113: mov    QWORD PTR [rbx+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11b:
	/* 0x11b: mov    QWORD PTR [rbx+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_123:
	/* 0x123: mov    QWORD PTR [rbx+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12b:
	/* 0x12b: mov    QWORD PTR [rbx+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_133:
	/* 0x133: mov    QWORD PTR [rbx+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13b:
	/* 0x13b: call   140 <trace_check_helper_call+0x140> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_140:
	/* 0x140: mov    DWORD PTR [rbx+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_143:
	/* 0x143: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_147:
	/* 0x147: mov    DWORD PTR [rbx+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbx+0x70],0x30a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337930ULL);
x86_l_151:
	/* 0x151: call   156 <trace_check_helper_call+0x156> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_156:
	/* 0x156: mov    QWORD PTR [rbx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_159:
	/* 0x159: call   15e <trace_check_helper_call+0x15e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_15e:
	/* 0x15e: mov    WORD PTR [rbx+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_162:
	/* 0x162: call   167 <trace_check_helper_call+0x167> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_167:
	/* 0x167: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16a:
	/* 0x16a: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_16e:
	/* 0x16e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_171:
	/* 0x171: jns    182 <trace_check_helper_call+0x182> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x171, 0x182, x86_l_182);
x86_l_173:
	/* 0x173: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_175:
	/* 0x175: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17a:
	/* 0x17a: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_180:
	/* 0x180: jne    1bc <trace_check_helper_call+0x1bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x180, 0x1bc, x86_l_1bc);
x86_l_182:
	/* 0x182: call   187 <trace_check_helper_call+0x187> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_187:
	/* 0x187: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18a:
	/* 0x18a: call   18f <trace_check_helper_call+0x18f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_18f:
	/* 0x18f: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_193:
	/* 0x193: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_196:
	/* 0x196: jns    1a6 <trace_check_helper_call+0x1a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x196, 0x1a6, x86_l_1a6);
x86_l_198:
	/* 0x198: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19b:
	/* 0x19b: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19f:
	/* 0x19f: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1a2:
	/* 0x1a2: js     1b1 <trace_check_helper_call+0x1b1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a2, 0x1b1, x86_l_1b1);
x86_l_1a4:
	/* 0x1a4: jmp    1b8 <trace_check_helper_call+0x1b8> */
	X86_SIM_X86_JMP(0x1a4, 0x1b8, x86_l_1b8);
x86_l_1a6:
	/* 0x1a6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a8:
	/* 0x1a8: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ac:
	/* 0x1ac: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1af:
	/* 0x1af: jns    1b8 <trace_check_helper_call+0x1b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af, 0x1b8, x86_l_1b8);
x86_l_1b1:
	/* 0x1b1: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b4:
	/* 0x1b4: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b6:
	/* 0x1b6: jne    227 <trace_check_helper_call+0x227> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b6, 0x227, x86_l_227);
x86_l_1b8:
	/* 0x1b8: mov    eax,DWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bc:
	/* 0x1bc: mov    QWORD PTR [rsp+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1c4:
	/* 0x1c4: mov    DWORD PTR [rbx+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1ca:
	/* 0x1ca: mov    DWORD PTR [rsp+0x80],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1d1:
	/* 0x1d1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d8:
	/* 0x1d8: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1e0:
	/* 0x1e0: call   1e5 <trace_check_helper_call+0x1e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e5:
	/* 0x1e5: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e8:
	/* 0x1e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1eb:
	/* 0x1eb: je     24e <trace_check_helper_call+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb, 0x24e, x86_l_24e);
x86_l_1ed:
	/* 0x1ed: mov    eax,DWORD PTR [rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f0:
	/* 0x1f0: mov    DWORD PTR [rsp+0x7c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_1f4:
	/* 0x1f4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_1fb:
	/* 0x1fb: lea    rsi,[rsp+0x7c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_200:
	/* 0x200: call   205 <trace_check_helper_call+0x205> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_205:
	/* 0x205: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_208:
	/* 0x208: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20b:
	/* 0x20b: je     2cf <trace_check_helper_call+0x2cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b, 0x2cf, x86_l_2cf);
x86_l_211:
	/* 0x211: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_217:
	/* 0x217: jne    6f2 <trace_check_helper_call+0x6f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x217, 0x6f2, x86_l_6f2);
x86_l_21d:
	/* 0x21d: call   222 <trace_check_helper_call+0x222> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_222:
	/* 0x222: jmp    74a <trace_check_helper_call+0x74a> */
	X86_SIM_X86_JMP(0x222, 0x74a, x86_l_74a);
x86_l_227:
	/* 0x227: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_22e:
	/* 0x22e: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_233:
	/* 0x233: call   238 <trace_check_helper_call+0x238> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_238:
	/* 0x238: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23b:
	/* 0x23b: je     244 <trace_check_helper_call+0x244> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23b, 0x244, x86_l_244);
x86_l_23d:
	/* 0x23d: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f:
	/* 0x23f: jmp    1bc <trace_check_helper_call+0x1bc> */
	X86_SIM_X86_JMP(0x23f, 0x1bc, x86_l_1bc);
x86_l_244:
	/* 0x244: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_249:
	/* 0x249: jmp    1bc <trace_check_helper_call+0x1bc> */
	X86_SIM_X86_JMP(0x249, 0x1bc, x86_l_1bc);
x86_l_24e:
	/* 0x24e: mov    eax,DWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_255:
	/* 0x255: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_259:
	/* 0x259: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_261:
	/* 0x261: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_268:
	/* 0x268: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_26d:
	/* 0x26d: call   272 <trace_check_helper_call+0x272> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_272:
	/* 0x272: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_275:
	/* 0x275: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275, 0x119b, x86_l_119b);
x86_l_27b:
	/* 0x27b: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27e:
	/* 0x27e: mov    eax,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_282:
	/* 0x282: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_286:
	/* 0x286: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_28b:
	/* 0x28b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_28e:
	/* 0x28e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_290:
	/* 0x290: call   295 <trace_check_helper_call+0x295> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_295:
	/* 0x295: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_29c:
	/* 0x29c: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a1:
	/* 0x2a1: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2a6:
	/* 0x2a6: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2a9:
	/* 0x2a9: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2ac:
	/* 0x2ac: call   2b1 <trace_check_helper_call+0x2b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2b1:
	/* 0x2b1: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2b6:
	/* 0x2b6: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2b9:
	/* 0x2b9: call   2be <trace_check_helper_call+0x2be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2be:
	/* 0x2be: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c1:
	/* 0x2c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c4:
	/* 0x2c4: jne    1ed <trace_check_helper_call+0x1ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c4, 0x1ed, x86_l_1ed);
x86_l_2ca:
	/* 0x2ca: jmp    119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JMP(0x2ca, 0x119b, x86_l_119b);
x86_l_2cf:
	/* 0x2cf: mov    QWORD PTR [rsp+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d4:
	/* 0x2d4: mov    eax,DWORD PTR [rsp+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_2d8:
	/* 0x2d8: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2dc:
	/* 0x2dc: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2e4:
	/* 0x2e4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_2eb:
	/* 0x2eb: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2f0:
	/* 0x2f0: call   2f5 <trace_check_helper_call+0x2f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f5:
	/* 0x2f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f8:
	/* 0x2f8: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f8, 0x119b, x86_l_119b);
x86_l_2fe:
	/* 0x2fe: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_301:
	/* 0x301: mov    eax,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_305:
	/* 0x305: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_309:
	/* 0x309: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_30e:
	/* 0x30e: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_311:
	/* 0x311: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_313:
	/* 0x313: call   318 <trace_check_helper_call+0x318> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_318:
	/* 0x318: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_31f:
	/* 0x31f: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_324:
	/* 0x324: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_329:
	/* 0x329: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_32c:
	/* 0x32c: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_32f:
	/* 0x32f: call   334 <trace_check_helper_call+0x334> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_334:
	/* 0x334: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_339:
	/* 0x339: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_33c:
	/* 0x33c: call   341 <trace_check_helper_call+0x341> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_341:
	/* 0x341: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_344:
	/* 0x344: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x344, 0x119b, x86_l_119b);
x86_l_34a:
	/* 0x34a: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_34d:
	/* 0x34d: mov    r15,QWORD PTR [rbx+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_354:
	/* 0x354: lea    rax,[r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_358:
	/* 0x358: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35b:
	/* 0x35b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_35e:
	/* 0x35e: jns    365 <trace_check_helper_call+0x365> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35e, 0x365, x86_l_365);
x86_l_360:
	/* 0x360: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_363:
	/* 0x363: jmp    367 <trace_check_helper_call+0x367> */
	X86_SIM_X86_JMP(0x363, 0x367, x86_l_367);
x86_l_365:
	/* 0x365: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_367:
	/* 0x367: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_36c:
	/* 0x36c: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_370:
	/* 0x370: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_373:
	/* 0x373: jns    37a <trace_check_helper_call+0x37a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x373, 0x37a, x86_l_37a);
x86_l_375:
	/* 0x375: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_378:
	/* 0x378: jmp    37c <trace_check_helper_call+0x37c> */
	X86_SIM_X86_JMP(0x378, 0x37c, x86_l_37c);
x86_l_37a:
	/* 0x37a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37c:
	/* 0x37c: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_380:
	/* 0x380: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_382:
	/* 0x382: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_385:
	/* 0x385: jns    38c <trace_check_helper_call+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x385, 0x38c, x86_l_38c);
x86_l_387:
	/* 0x387: mov    r14,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38a:
	/* 0x38a: jmp    38f <trace_check_helper_call+0x38f> */
	X86_SIM_X86_JMP(0x38a, 0x38f, x86_l_38f);
x86_l_38c:
	/* 0x38c: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38f:
	/* 0x38f: lea    rdx,[r14+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_393:
	/* 0x393: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_396:
	/* 0x396: jns    39a <trace_check_helper_call+0x39a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x396, 0x39a, x86_l_39a);
x86_l_398:
	/* 0x398: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39a:
	/* 0x39a: mov    DWORD PTR [r13+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_39e:
	/* 0x39e: lea    rcx,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a2:
	/* 0x3a2: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3a5:
	/* 0x3a5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a7:
	/* 0x3a7: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3aa:
	/* 0x3aa: jns    3b1 <trace_check_helper_call+0x3b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3aa, 0x3b1, x86_l_3b1);
x86_l_3ac:
	/* 0x3ac: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3af:
	/* 0x3af: jmp    3b3 <trace_check_helper_call+0x3b3> */
	X86_SIM_X86_JMP(0x3af, 0x3b3, x86_l_3b3);
x86_l_3b1:
	/* 0x3b1: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b3:
	/* 0x3b3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3b6:
	/* 0x3b6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3b9:
	/* 0x3b9: jns    3bd <trace_check_helper_call+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b9, 0x3bd, x86_l_3bd);
x86_l_3bb:
	/* 0x3bb: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bd:
	/* 0x3bd: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3bf:
	/* 0x3bf: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3c3:
	/* 0x3c3: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3c6:
	/* 0x3c6: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3ca:
	/* 0x3ca: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3cc:
	/* 0x3cc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3cf:
	/* 0x3cf: jns    3d3 <trace_check_helper_call+0x3d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3cf, 0x3d3, x86_l_3d3);
x86_l_3d1:
	/* 0x3d1: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d3:
	/* 0x3d3: mov    DWORD PTR [r13+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3d7:
	/* 0x3d7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3da:
	/* 0x3da: jns    3e1 <trace_check_helper_call+0x3e1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3da, 0x3e1, x86_l_3e1);
x86_l_3dc:
	/* 0x3dc: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3df:
	/* 0x3df: jmp    3e3 <trace_check_helper_call+0x3e3> */
	X86_SIM_X86_JMP(0x3df, 0x3e3, x86_l_3e3);
x86_l_3e1:
	/* 0x3e1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e3:
	/* 0x3e3: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3e7:
	/* 0x3e7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e9:
	/* 0x3e9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ec:
	/* 0x3ec: jns    3f3 <trace_check_helper_call+0x3f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ec, 0x3f3, x86_l_3f3);
x86_l_3ee:
	/* 0x3ee: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f1:
	/* 0x3f1: jmp    3f5 <trace_check_helper_call+0x3f5> */
	X86_SIM_X86_JMP(0x3f1, 0x3f5, x86_l_3f5);
x86_l_3f3:
	/* 0x3f3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f5:
	/* 0x3f5: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3f8:
	/* 0x3f8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3fb:
	/* 0x3fb: jns    3ff <trace_check_helper_call+0x3ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3fb, 0x3ff, x86_l_3ff);
x86_l_3fd:
	/* 0x3fd: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ff:
	/* 0x3ff: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_401:
	/* 0x401: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_405:
	/* 0x405: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_408:
	/* 0x408: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_40c:
	/* 0x40c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_40e:
	/* 0x40e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_411:
	/* 0x411: jns    415 <trace_check_helper_call+0x415> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x411, 0x415, x86_l_415);
x86_l_413:
	/* 0x413: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_415:
	/* 0x415: mov    DWORD PTR [r13+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_419:
	/* 0x419: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41b:
	/* 0x41b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_41e:
	/* 0x41e: jns    425 <trace_check_helper_call+0x425> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x41e, 0x425, x86_l_425);
x86_l_420:
	/* 0x420: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_423:
	/* 0x423: jmp    427 <trace_check_helper_call+0x427> */
	X86_SIM_X86_JMP(0x423, 0x427, x86_l_427);
x86_l_425:
	/* 0x425: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_427:
	/* 0x427: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_42a:
	/* 0x42a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_42d:
	/* 0x42d: jns    431 <trace_check_helper_call+0x431> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x42d, 0x431, x86_l_431);
x86_l_42f:
	/* 0x42f: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_431:
	/* 0x431: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_433:
	/* 0x433: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_437:
	/* 0x437: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_43a:
	/* 0x43a: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_43e:
	/* 0x43e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_440:
	/* 0x440: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_443:
	/* 0x443: jns    44a <trace_check_helper_call+0x44a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x443, 0x44a, x86_l_44a);
x86_l_445:
	/* 0x445: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_448:
	/* 0x448: jmp    44c <trace_check_helper_call+0x44c> */
	X86_SIM_X86_JMP(0x448, 0x44c, x86_l_44c);
x86_l_44a:
	/* 0x44a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_44c:
	/* 0x44c: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_450:
	/* 0x450: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_453:
	/* 0x453: jns    457 <trace_check_helper_call+0x457> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x453, 0x457, x86_l_457);
x86_l_455:
	/* 0x455: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_457:
	/* 0x457: lea    rcx,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45b:
	/* 0x45b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_45e:
	/* 0x45e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_460:
	/* 0x460: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_463:
	/* 0x463: jns    46a <trace_check_helper_call+0x46a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x463, 0x46a, x86_l_46a);
x86_l_465:
	/* 0x465: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_468:
	/* 0x468: jmp    46c <trace_check_helper_call+0x46c> */
	X86_SIM_X86_JMP(0x468, 0x46c, x86_l_46c);
x86_l_46a:
	/* 0x46a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46c:
	/* 0x46c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_46f:
	/* 0x46f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_472:
	/* 0x472: jns    476 <trace_check_helper_call+0x476> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x472, 0x476, x86_l_476);
x86_l_474:
	/* 0x474: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_476:
	/* 0x476: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_478:
	/* 0x478: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_47c:
	/* 0x47c: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_47f:
	/* 0x47f: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_483:
	/* 0x483: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_485:
	/* 0x485: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_488:
	/* 0x488: jns    48f <trace_check_helper_call+0x48f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x488, 0x48f, x86_l_48f);
x86_l_48a:
	/* 0x48a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48d:
	/* 0x48d: jmp    491 <trace_check_helper_call+0x491> */
	X86_SIM_X86_JMP(0x48d, 0x491, x86_l_491);
x86_l_48f:
	/* 0x48f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_491:
	/* 0x491: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_495:
	/* 0x495: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_498:
	/* 0x498: jns    49c <trace_check_helper_call+0x49c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x498, 0x49c, x86_l_49c);
x86_l_49a:
	/* 0x49a: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49c:
	/* 0x49c: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_49e:
	/* 0x49e: jne    4d2 <trace_check_helper_call+0x4d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49e, 0x4d2, x86_l_4d2);
x86_l_4a0:
	/* 0x4a0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a2:
	/* 0x4a2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4a5:
	/* 0x4a5: jns    4ac <trace_check_helper_call+0x4ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4a5, 0x4ac, x86_l_4ac);
x86_l_4a7:
	/* 0x4a7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4aa:
	/* 0x4aa: jmp    4ae <trace_check_helper_call+0x4ae> */
	X86_SIM_X86_JMP(0x4aa, 0x4ae, x86_l_4ae);
x86_l_4ac:
	/* 0x4ac: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ae:
	/* 0x4ae: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4b1:
	/* 0x4b1: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4b4:
	/* 0x4b4: jns    4b8 <trace_check_helper_call+0x4b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4b4, 0x4b8, x86_l_4b8);
x86_l_4b6:
	/* 0x4b6: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b8:
	/* 0x4b8: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4ba:
	/* 0x4ba: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_4be:
	/* 0x4be: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4c1:
	/* 0x4c1: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4c5:
	/* 0x4c5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c7:
	/* 0x4c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4ca:
	/* 0x4ca: jns    4ce <trace_check_helper_call+0x4ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ca, 0x4ce, x86_l_4ce);
x86_l_4cc:
	/* 0x4cc: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ce:
	/* 0x4ce: mov    DWORD PTR [r13+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d2:
	/* 0x4d2: mov    DWORD PTR [r13+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d6:
	/* 0x4d6: lea    rbp,[r15+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4dd:
	/* 0x4dd: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4e0:
	/* 0x4e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e3:
	/* 0x4e3: jns    4ea <trace_check_helper_call+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4e3, 0x4ea, x86_l_4ea);
x86_l_4e5:
	/* 0x4e5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e8:
	/* 0x4e8: jmp    4ec <trace_check_helper_call+0x4ec> */
	X86_SIM_X86_JMP(0x4e8, 0x4ec, x86_l_4ec);
x86_l_4ea:
	/* 0x4ea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ec:
	/* 0x4ec: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4f0:
	/* 0x4f0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4f2:
	/* 0x4f2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4f5:
	/* 0x4f5: jns    4fc <trace_check_helper_call+0x4fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4f5, 0x4fc, x86_l_4fc);
x86_l_4f7:
	/* 0x4f7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fa:
	/* 0x4fa: jmp    4fe <trace_check_helper_call+0x4fe> */
	X86_SIM_X86_JMP(0x4fa, 0x4fe, x86_l_4fe);
x86_l_4fc:
	/* 0x4fc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4fe:
	/* 0x4fe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_501:
	/* 0x501: jns    505 <trace_check_helper_call+0x505> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x501, 0x505, x86_l_505);
x86_l_503:
	/* 0x503: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_505:
	/* 0x505: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_509:
	/* 0x509: call   50e <trace_check_helper_call+0x50e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_50e:
	/* 0x50e: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_512:
	/* 0x512: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_515:
	/* 0x515: lea    rax,[r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_519:
	/* 0x519: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51c:
	/* 0x51c: jns    523 <trace_check_helper_call+0x523> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x51c, 0x523, x86_l_523);
x86_l_51e:
	/* 0x51e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_521:
	/* 0x521: jmp    525 <trace_check_helper_call+0x525> */
	X86_SIM_X86_JMP(0x521, 0x525, x86_l_525);
x86_l_523:
	/* 0x523: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_525:
	/* 0x525: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_52a:
	/* 0x52a: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_52e:
	/* 0x52e: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_532:
	/* 0x532: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_535:
	/* 0x535: jns    53c <trace_check_helper_call+0x53c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x535, 0x53c, x86_l_53c);
x86_l_537:
	/* 0x537: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53a:
	/* 0x53a: jmp    53e <trace_check_helper_call+0x53e> */
	X86_SIM_X86_JMP(0x53a, 0x53e, x86_l_53e);
x86_l_53c:
	/* 0x53c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53e:
	/* 0x53e: mov    QWORD PTR [r13+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_542:
	/* 0x542: add    r14,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_546:
	/* 0x546: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_549:
	/* 0x549: jns    550 <trace_check_helper_call+0x550> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x549, 0x550, x86_l_550);
x86_l_54b:
	/* 0x54b: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54e:
	/* 0x54e: jmp    552 <trace_check_helper_call+0x552> */
	X86_SIM_X86_JMP(0x54e, 0x552, x86_l_552);
x86_l_550:
	/* 0x550: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_552:
	/* 0x552: mov    QWORD PTR [r13+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_556:
	/* 0x556: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_559:
	/* 0x559: jns    566 <trace_check_helper_call+0x566> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x559, 0x566, x86_l_566);
x86_l_55b:
	/* 0x55b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55d:
	/* 0x55d: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_55f:
	/* 0x55f: je     566 <trace_check_helper_call+0x566> */
	X86_SIM_X86_JCC(X86_CC_E, 0x55f, 0x566, x86_l_566);
x86_l_561:
	/* 0x561: or     BYTE PTR [r13+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_566:
	/* 0x566: lea    rdi,[r13+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_56a:
	/* 0x56a: mov    QWORD PTR [r13+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_572:
	/* 0x572: mov    QWORD PTR [r13+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_57a:
	/* 0x57a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_57f:
	/* 0x57f: call   584 <trace_check_helper_call+0x584> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_584:
	/* 0x584: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_587:
	/* 0x587: jns    58f <trace_check_helper_call+0x58f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x587, 0x58f, x86_l_58f);
x86_l_589:
	/* 0x589: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_58d:
	/* 0x58d: jmp    591 <trace_check_helper_call+0x591> */
	X86_SIM_X86_JMP(0x58d, 0x591, x86_l_591);
x86_l_58f:
	/* 0x58f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_591:
	/* 0x591: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_594:
	/* 0x594: jns    59b <trace_check_helper_call+0x59b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x594, 0x59b, x86_l_59b);
x86_l_596:
	/* 0x596: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_599:
	/* 0x599: jmp    59d <trace_check_helper_call+0x59d> */
	X86_SIM_X86_JMP(0x599, 0x59d, x86_l_59d);
x86_l_59b:
	/* 0x59b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_59d:
	/* 0x59d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a0:
	/* 0x5a0: jns    5ed <trace_check_helper_call+0x5ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5a0, 0x5ed, x86_l_5ed);
x86_l_5a2:
	/* 0x5a2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a5:
	/* 0x5a5: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5aa:
	/* 0x5aa: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5ae:
	/* 0x5ae: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5b3:
	/* 0x5b3: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b7:
	/* 0x5b7: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5bc:
	/* 0x5bc: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c0:
	/* 0x5c0: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5c5:
	/* 0x5c5: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5c9:
	/* 0x5c9: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5ce:
	/* 0x5ce: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5d2:
	/* 0x5d2: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_5d7:
	/* 0x5d7: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5db:
	/* 0x5db: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5e0:
	/* 0x5e0: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5e4:
	/* 0x5e4: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5e9:
	/* 0x5e9: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_5ed:
	/* 0x5ed: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5f0:
	/* 0x5f0: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_5f4:
	/* 0x5f4: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f9:
	/* 0x5f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5fc:
	/* 0x5fc: jns    6d2 <trace_check_helper_call+0x6d2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5fc, 0x6d2, x86_l_6d2);
x86_l_602:
	/* 0x602: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_605:
	/* 0x605: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_607:
	/* 0x607: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_609:
	/* 0x609: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x609, 0x6e1, x86_l_6e1);
x86_l_60f:
	/* 0x60f: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_613:
	/* 0x613: mov    BYTE PTR [r13+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_617:
	/* 0x617: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_619:
	/* 0x619: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x619, 0x6e1, x86_l_6e1);
x86_l_61f:
	/* 0x61f: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_623:
	/* 0x623: mov    BYTE PTR [r13+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_627:
	/* 0x627: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_629:
	/* 0x629: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x629, 0x6e1, x86_l_6e1);
x86_l_62f:
	/* 0x62f: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_633:
	/* 0x633: mov    BYTE PTR [r13+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_637:
	/* 0x637: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_639:
	/* 0x639: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x639, 0x6e1, x86_l_6e1);
x86_l_63f:
	/* 0x63f: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_643:
	/* 0x643: mov    BYTE PTR [r13+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_647:
	/* 0x647: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_649:
	/* 0x649: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x649, 0x6e1, x86_l_6e1);
x86_l_64f:
	/* 0x64f: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_653:
	/* 0x653: mov    BYTE PTR [r13+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_657:
	/* 0x657: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_659:
	/* 0x659: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x659, 0x6e1, x86_l_6e1);
x86_l_65f:
	/* 0x65f: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_663:
	/* 0x663: mov    BYTE PTR [r13+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_667:
	/* 0x667: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_669:
	/* 0x669: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x669, 0x6e1, x86_l_6e1);
x86_l_66b:
	/* 0x66b: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_66f:
	/* 0x66f: mov    BYTE PTR [r13+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_673:
	/* 0x673: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_675:
	/* 0x675: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x675, 0x6e1, x86_l_6e1);
x86_l_677:
	/* 0x677: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_67b:
	/* 0x67b: mov    BYTE PTR [r13+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_67f:
	/* 0x67f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_681:
	/* 0x681: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x681, 0x6e1, x86_l_6e1);
x86_l_683:
	/* 0x683: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_687:
	/* 0x687: mov    BYTE PTR [r13+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_68b:
	/* 0x68b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_68d:
	/* 0x68d: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x68d, 0x6e1, x86_l_6e1);
x86_l_68f:
	/* 0x68f: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_693:
	/* 0x693: mov    BYTE PTR [r13+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_697:
	/* 0x697: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_699:
	/* 0x699: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x699, 0x6e1, x86_l_6e1);
x86_l_69b:
	/* 0x69b: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_69f:
	/* 0x69f: mov    BYTE PTR [r13+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_6a3:
	/* 0x6a3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6a5:
	/* 0x6a5: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a5, 0x6e1, x86_l_6e1);
x86_l_6a7:
	/* 0x6a7: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_6ab:
	/* 0x6ab: mov    BYTE PTR [r13+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6af:
	/* 0x6af: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6b1:
	/* 0x6b1: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b1, 0x6e1, x86_l_6e1);
x86_l_6b3:
	/* 0x6b3: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_6b7:
	/* 0x6b7: mov    BYTE PTR [r13+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_6bb:
	/* 0x6bb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6bd:
	/* 0x6bd: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6bd, 0x6e1, x86_l_6e1);
x86_l_6bf:
	/* 0x6bf: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_6c3:
	/* 0x6c3: mov    BYTE PTR [r13+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_6c7:
	/* 0x6c7: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_6c9:
	/* 0x6c9: je     6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c9, 0x6e1, x86_l_6e1);
x86_l_6cb:
	/* 0x6cb: mov    BYTE PTR [r13+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_6d0:
	/* 0x6d0: jmp    6e1 <trace_check_helper_call+0x6e1> */
	X86_SIM_X86_JMP(0x6d0, 0x6e1, x86_l_6e1);
x86_l_6d2:
	/* 0x6d2: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_6da:
	/* 0x6da: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e1:
	/* 0x6e1: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e6:
	/* 0x6e6: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_6ec:
	/* 0x6ec: je     21d <trace_check_helper_call+0x21d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ec, 0x21d, x86_l_21d);
x86_l_6f2:
	/* 0x6f2: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_6f7:
	/* 0x6f7: add    rax,QWORD PTR [rbx+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6fe:
	/* 0x6fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_701:
	/* 0x701: jns    71b <trace_check_helper_call+0x71b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x701, 0x71b, x86_l_71b);
x86_l_703:
	/* 0x703: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_706:
	/* 0x706: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_709:
	/* 0x709: js     722 <trace_check_helper_call+0x722> */
	X86_SIM_X86_JCC(X86_CC_S, 0x709, 0x722, x86_l_722);
x86_l_70b:
	/* 0x70b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_70d:
	/* 0x70d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_710:
	/* 0x710: js     72a <trace_check_helper_call+0x72a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x710, 0x72a, x86_l_72a);
x86_l_712:
	/* 0x712: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_714:
	/* 0x714: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_717:
	/* 0x717: js     732 <trace_check_helper_call+0x732> */
	X86_SIM_X86_JCC(X86_CC_S, 0x717, 0x732, x86_l_732);
x86_l_719:
	/* 0x719: jmp    748 <trace_check_helper_call+0x748> */
	X86_SIM_X86_JMP(0x719, 0x748, x86_l_748);
x86_l_71b:
	/* 0x71b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71d:
	/* 0x71d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_720:
	/* 0x720: jns    70b <trace_check_helper_call+0x70b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x720, 0x70b, x86_l_70b);
x86_l_722:
	/* 0x722: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_725:
	/* 0x725: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_728:
	/* 0x728: jns    712 <trace_check_helper_call+0x712> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x728, 0x712, x86_l_712);
x86_l_72a:
	/* 0x72a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_72d:
	/* 0x72d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_730:
	/* 0x730: jns    748 <trace_check_helper_call+0x748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x730, 0x748, x86_l_748);
x86_l_732:
	/* 0x732: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_735:
	/* 0x735: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_738:
	/* 0x738: je     748 <trace_check_helper_call+0x748> */
	X86_SIM_X86_JCC(X86_CC_E, 0x738, 0x748, x86_l_748);
x86_l_73a:
	/* 0x73a: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_73e:
	/* 0x73e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_741:
	/* 0x741: jns    748 <trace_check_helper_call+0x748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x741, 0x748, x86_l_748);
x86_l_743:
	/* 0x743: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_746:
	/* 0x746: jmp    74a <trace_check_helper_call+0x74a> */
	X86_SIM_X86_JMP(0x746, 0x74a, x86_l_74a);
x86_l_748:
	/* 0x748: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_74a:
	/* 0x74a: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_74e:
	/* 0x74e: mov    QWORD PTR [r13+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_752:
	/* 0x752: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_756:
	/* 0x756: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_75d:
	/* 0x75d: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_762:
	/* 0x762: call   767 <trace_check_helper_call+0x767> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_767:
	/* 0x767: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_76a:
	/* 0x76a: je     782 <trace_check_helper_call+0x782> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76a, 0x782, x86_l_782);
x86_l_76c:
	/* 0x76c: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_76f:
	/* 0x76f: mov    BYTE PTR [r13+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_776:
	/* 0x776: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_779:
	/* 0x779: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_77c:
	/* 0x77c: jne    782 <trace_check_helper_call+0x782> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77c, 0x782, x86_l_782);
x86_l_77e:
	/* 0x77e: or     BYTE PTR [rbx+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_782:
	/* 0x782: movzx  eax,WORD PTR [rbx+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_786:
	/* 0x786: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_78c:
	/* 0x78c: jne    11b3 <trace_check_helper_call+0x11b3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78c, 0x11b3, x86_l_11b3);
x86_l_792:
	/* 0x792: mov    QWORD PTR [rbx+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_79d:
	/* 0x79d: mov    DWORD PTR [rsp+0x20],0x30a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438954250ULL);
x86_l_7a5:
	/* 0x7a5: mov    WORD PTR [rsp+0x14],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7aa:
	/* 0x7aa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_7b1:
	/* 0x7b1: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7b6:
	/* 0x7b6: call   7bb <trace_check_helper_call+0x7bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7bb:
	/* 0x7bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7be:
	/* 0x7be: je     829 <trace_check_helper_call+0x829> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7be, 0x829, x86_l_829);
x86_l_7c0:
	/* 0x7c0: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7c5:
	/* 0x7c5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c8:
	/* 0x7c8: call   7cd <trace_check_helper_call+0x7cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7cd:
	/* 0x7cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d0:
	/* 0x7d0: je     829 <trace_check_helper_call+0x829> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d0, 0x829, x86_l_829);
x86_l_7d2:
	/* 0x7d2: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d6:
	/* 0x7d6: mov    QWORD PTR [rbx+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_7dd:
	/* 0x7dd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e0:
	/* 0x7e0: mov    QWORD PTR [rbx+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_7e7:
	/* 0x7e7: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7eb:
	/* 0x7eb: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7ef:
	/* 0x7ef: mov    QWORD PTR [rbx+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_7f6:
	/* 0x7f6: mov    QWORD PTR [rbx+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_7fd:
	/* 0x7fd: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_801:
	/* 0x801: mov    QWORD PTR [rbx+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_808:
	/* 0x808: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_80c:
	/* 0x80c: mov    QWORD PTR [rbx+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_813:
	/* 0x813: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_817:
	/* 0x817: mov    QWORD PTR [rbx+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_81e:
	/* 0x81e: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_822:
	/* 0x822: mov    QWORD PTR [rbx+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_829:
	/* 0x829: mov    rax,QWORD PTR [rbx+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_830:
	/* 0x830: mov    QWORD PTR [rbx+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_837:
	/* 0x837: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_83b:
	/* 0x83b: cmp    ecx,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_83e:
	/* 0x83e: jne    858 <trace_check_helper_call+0x858> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x83e, 0x858, x86_l_858);
x86_l_840:
	/* 0x840: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_843:
	/* 0x843: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_846:
	/* 0x846: mov    QWORD PTR [rbx+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_84d:
	/* 0x84d: jne    109c <trace_check_helper_call+0x109c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84d, 0x109c, x86_l_109c);
x86_l_853:
	/* 0x853: jmp    119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JMP(0x853, 0x119b, x86_l_119b);
x86_l_858:
	/* 0x858: mov    rax,QWORD PTR [rbx+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_85f:
	/* 0x85f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_862:
	/* 0x862: je     9f3 <trace_check_helper_call+0x9f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x862, 0x9f3, x86_l_9f3);
x86_l_868:
	/* 0x868: movzx  ecx,BYTE PTR [r13+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_870:
	/* 0x870: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_873:
	/* 0x873: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_875:
	/* 0x875: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_878:
	/* 0x878: sete   dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_87b:
	/* 0x87b: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_87e:
	/* 0x87e: neg    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_881:
	/* 0x881: xor    rdx,QWORD PTR [rbx+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_888:
	/* 0x888: or     rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_88b:
	/* 0x88b: mov    rax,QWORD PTR [rbx+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_892:
	/* 0x892: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_895:
	/* 0x895: je     a0a <trace_check_helper_call+0xa0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x895, 0xa0a, x86_l_a0a);
x86_l_89b:
	/* 0x89b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_89d:
	/* 0x89d: cmp    BYTE PTR [r13+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_8a5:
	/* 0x8a5: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_8a8:
	/* 0x8a8: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8ab:
	/* 0x8ab: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_8ae:
	/* 0x8ae: xor    rcx,QWORD PTR [rbx+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_8b5:
	/* 0x8b5: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8b8:
	/* 0x8b8: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_8bb:
	/* 0x8bb: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8be:
	/* 0x8be: mov    rax,QWORD PTR [rbx+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_8c5:
	/* 0x8c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c8:
	/* 0x8c8: je     8e3 <trace_check_helper_call+0x8e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c8, 0x8e3, x86_l_8e3);
x86_l_8ca:
	/* 0x8ca: mov    ecx,DWORD PTR [rbx+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_8cd:
	/* 0x8cd: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8d0:
	/* 0x8d0: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_8d3:
	/* 0x8d3: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_8d6:
	/* 0x8d6: xor    rcx,QWORD PTR [rbx+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_8dd:
	/* 0x8dd: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8e0:
	/* 0x8e0: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8e3:
	/* 0x8e3: mov    rax,QWORD PTR [rbx+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_8ea:
	/* 0x8ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ed:
	/* 0x8ed: mov    QWORD PTR [rsp+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f2:
	/* 0x8f2: je     90b <trace_check_helper_call+0x90b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f2, 0x90b, x86_l_90b);
x86_l_8f4:
	/* 0x8f4: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8f7:
	/* 0x8f7: movsx  rcx,BYTE PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8fb:
	/* 0x8fb: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_8fe:
	/* 0x8fe: xor    rcx,QWORD PTR [rbx+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_905:
	/* 0x905: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_908:
	/* 0x908: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_90b:
	/* 0x90b: movzx  ebp,WORD PTR [rbx+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_90f:
	/* 0x90f: mov    r14,QWORD PTR [rbx+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_916:
	/* 0x916: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_919:
	/* 0x919: mov    WORD PTR [rsp+0x18],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_91e:
	/* 0x91e: je     a75 <trace_check_helper_call+0xa75> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91e, 0xa75, x86_l_a75);
x86_l_924:
	/* 0x924: mov    QWORD PTR [rsp+0x68],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_929:
	/* 0x929: mov    rax,QWORD PTR [rbx+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_930:
	/* 0x930: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_938:
	/* 0x938: mov    r13,QWORD PTR [rbx+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_93f:
	/* 0x93f: mov    rax,QWORD PTR [rbx+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_946:
	/* 0x946: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_94b:
	/* 0x94b: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_950:
	/* 0x950: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_957:
	/* 0x957: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_95c:
	/* 0x95c: call   961 <trace_check_helper_call+0x961> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_961:
	/* 0x961: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_964:
	/* 0x964: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_967:
	/* 0x967: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_96c:
	/* 0x96c: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_973:
	/* 0x973: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_976:
	/* 0x976: je     996 <trace_check_helper_call+0x996> */
	X86_SIM_X86_JCC(X86_CC_E, 0x976, 0x996, x86_l_996);
x86_l_978:
	/* 0x978: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_97d:
	/* 0x97d: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_980:
	/* 0x980: call   985 <trace_check_helper_call+0x985> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_985:
	/* 0x985: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_988:
	/* 0x988: je     996 <trace_check_helper_call+0x996> */
	X86_SIM_X86_JCC(X86_CC_E, 0x988, 0x996, x86_l_996);
x86_l_98a:
	/* 0x98a: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_98d:
	/* 0x98d: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_991:
	/* 0x991: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_994:
	/* 0x994: jmp    999 <trace_check_helper_call+0x999> */
	X86_SIM_X86_JMP(0x994, 0x999, x86_l_999);
x86_l_996:
	/* 0x996: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_999:
	/* 0x999: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_99e:
	/* 0x99e: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9a3:
	/* 0x9a3: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_9a6:
	/* 0x9a6: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9a9:
	/* 0x9a9: jb     9c1 <trace_check_helper_call+0x9c1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x9a9, 0x9c1, x86_l_9c1);
x86_l_9ab:
	/* 0x9ab: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9af:
	/* 0x9af: je     9b6 <trace_check_helper_call+0x9b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9af, 0x9b6, x86_l_9b6);
x86_l_9b1:
	/* 0x9b1: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9b4:
	/* 0x9b4: jbe    9c1 <trace_check_helper_call+0x9c1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x9b4, 0x9c1, x86_l_9c1);
x86_l_9b6:
	/* 0x9b6: and    rbp,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 136ULL);
x86_l_9be:
	/* 0x9be: or     r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9c1:
	/* 0x9c1: mov    eax,DWORD PTR [rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9c4:
	/* 0x9c4: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9c9:
	/* 0x9c9: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9d0:
	/* 0x9d0: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9d3:
	/* 0x9d3: je     a22 <trace_check_helper_call+0xa22> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d3, 0xa22, x86_l_a22);
x86_l_9d5:
	/* 0x9d5: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9da:
	/* 0x9da: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9dd:
	/* 0x9dd: call   9e2 <trace_check_helper_call+0x9e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9e2:
	/* 0x9e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9e5:
	/* 0x9e5: je     a4e <trace_check_helper_call+0xa4e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e5, 0xa4e, x86_l_a4e);
x86_l_9e7:
	/* 0x9e7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9ea:
	/* 0x9ea: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9ee:
	/* 0x9ee: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9f1:
	/* 0x9f1: jmp    a50 <trace_check_helper_call+0xa50> */
	X86_SIM_X86_JMP(0x9f1, 0xa50, x86_l_a50);
x86_l_9f3:
	/* 0x9f3: mov    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9fa:
	/* 0x9fa: mov    rax,QWORD PTR [rbx+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_a01:
	/* 0xa01: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a04:
	/* 0xa04: jne    89b <trace_check_helper_call+0x89b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa04, 0x89b, x86_l_89b);
x86_l_a0a:
	/* 0xa0a: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a0d:
	/* 0xa0d: mov    rax,QWORD PTR [rbx+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_a14:
	/* 0xa14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a17:
	/* 0xa17: jne    8ca <trace_check_helper_call+0x8ca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa17, 0x8ca, x86_l_8ca);
x86_l_a1d:
	/* 0xa1d: jmp    8e3 <trace_check_helper_call+0x8e3> */
	X86_SIM_X86_JMP(0xa1d, 0x8e3, x86_l_8e3);
x86_l_a22:
	/* 0xa22: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a24:
	/* 0xa24: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a27:
	/* 0xa27: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a2c:
	/* 0xa2c: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a2f:
	/* 0xa2f: jb     a62 <trace_check_helper_call+0xa62> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa2f, 0xa62, x86_l_a62);
x86_l_a31:
	/* 0xa31: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a35:
	/* 0xa35: mov    r13,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a3a:
	/* 0xa3a: je     a41 <trace_check_helper_call+0xa41> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa3a, 0xa41, x86_l_a41);
x86_l_a3c:
	/* 0xa3c: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a3f:
	/* 0xa3f: jbe    a67 <trace_check_helper_call+0xa67> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa3f, 0xa67, x86_l_a67);
x86_l_a41:
	/* 0xa41: and    rbp,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 136ULL);
x86_l_a49:
	/* 0xa49: or     rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a4c:
	/* 0xa4c: jmp    a67 <trace_check_helper_call+0xa67> */
	X86_SIM_X86_JMP(0xa4c, 0xa67, x86_l_a67);
x86_l_a4e:
	/* 0xa4e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a50:
	/* 0xa50: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_a55:
	/* 0xa55: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a58:
	/* 0xa58: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a5d:
	/* 0xa5d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a60:
	/* 0xa60: jae    a31 <trace_check_helper_call+0xa31> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa60, 0xa31, x86_l_a31);
x86_l_a62:
	/* 0xa62: mov    r13,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a67:
	/* 0xa67: or     r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a6a:
	/* 0xa6a: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a6d:
	/* 0xa6d: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a70:
	/* 0xa70: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_a75:
	/* 0xa75: cmp    QWORD PTR [rbx+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_a7d:
	/* 0xa7d: je     b33 <trace_check_helper_call+0xb33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7d, 0xb33, x86_l_b33);
x86_l_a83:
	/* 0xa83: mov    r15d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a86:
	/* 0xa86: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a89:
	/* 0xa89: call   a8e <trace_check_helper_call+0xa8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_a8e:
	/* 0xa8e: mov    DWORD PTR [rbx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a91:
	/* 0xa91: mov    r14,QWORD PTR [rbx+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_a98:
	/* 0xa98: mov    rax,QWORD PTR [rbx+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_a9f:
	/* 0xa9f: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_aa4:
	/* 0xaa4: mov    r13,QWORD PTR [rbx+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_aab:
	/* 0xaab: mov    r12,QWORD PTR [rbx+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_ab2:
	/* 0xab2: mov    WORD PTR [rsp+0x20],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ab8:
	/* 0xab8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_abf:
	/* 0xabf: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ac4:
	/* 0xac4: call   ac9 <trace_check_helper_call+0xac9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ac9:
	/* 0xac9: mov    ecx,DWORD PTR [rbx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_acc:
	/* 0xacc: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ad1:
	/* 0xad1: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ad8:
	/* 0xad8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adb:
	/* 0xadb: je     afb <trace_check_helper_call+0xafb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xadb, 0xafb, x86_l_afb);
x86_l_add:
	/* 0xadd: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ae2:
	/* 0xae2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae5:
	/* 0xae5: call   aea <trace_check_helper_call+0xaea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_aea:
	/* 0xaea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aed:
	/* 0xaed: je     afb <trace_check_helper_call+0xafb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaed, 0xafb, x86_l_afb);
x86_l_aef:
	/* 0xaef: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af2:
	/* 0xaf2: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_af6:
	/* 0xaf6: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_af9:
	/* 0xaf9: jmp    afd <trace_check_helper_call+0xafd> */
	X86_SIM_X86_JMP(0xaf9, 0xafd, x86_l_afd);
x86_l_afb:
	/* 0xafb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_afd:
	/* 0xafd: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b00:
	/* 0xb00: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b05:
	/* 0xb05: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_b08:
	/* 0xb08: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b0b:
	/* 0xb0b: jae    b12 <trace_check_helper_call+0xb12> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb0b, 0xb12, x86_l_b12);
x86_l_b0d:
	/* 0xb0d: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b10:
	/* 0xb10: jmp    b28 <trace_check_helper_call+0xb28> */
	X86_SIM_X86_JMP(0xb10, 0xb28, x86_l_b28);
x86_l_b12:
	/* 0xb12: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b16:
	/* 0xb16: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b19:
	/* 0xb19: je     b20 <trace_check_helper_call+0xb20> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb19, 0xb20, x86_l_b20);
x86_l_b1b:
	/* 0xb1b: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_b1e:
	/* 0xb1e: jbe    b28 <trace_check_helper_call+0xb28> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xb1e, 0xb28, x86_l_b28);
x86_l_b20:
	/* 0xb20: and    r15,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 104ULL);
x86_l_b25:
	/* 0xb25: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b28:
	/* 0xb28: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_b2d:
	/* 0xb2d: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b30:
	/* 0xb30: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b33:
	/* 0xb33: cmp    QWORD PTR [rbx+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_b3b:
	/* 0xb3b: je     bd8 <trace_check_helper_call+0xbd8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb3b, 0xbd8, x86_l_bd8);
x86_l_b41:
	/* 0xb41: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_b46:
	/* 0xb46: add    rax,QWORD PTR [rbx+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_b4d:
	/* 0xb4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b50:
	/* 0xb50: jns    b57 <trace_check_helper_call+0xb57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb50, 0xb57, x86_l_b57);
x86_l_b52:
	/* 0xb52: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b55:
	/* 0xb55: jmp    b59 <trace_check_helper_call+0xb59> */
	X86_SIM_X86_JMP(0xb55, 0xb59, x86_l_b59);
x86_l_b57:
	/* 0xb57: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b59:
	/* 0xb59: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_b5d:
	/* 0xb5d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b5f:
	/* 0xb5f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b62:
	/* 0xb62: jns    b6e <trace_check_helper_call+0xb6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb62, 0xb6e, x86_l_b6e);
x86_l_b64:
	/* 0xb64: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b67:
	/* 0xb67: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b6a:
	/* 0xb6a: js     b75 <trace_check_helper_call+0xb75> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb6a, 0xb75, x86_l_b75);
x86_l_b6c:
	/* 0xb6c: jmp    b77 <trace_check_helper_call+0xb77> */
	X86_SIM_X86_JMP(0xb6c, 0xb77, x86_l_b77);
x86_l_b6e:
	/* 0xb6e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b70:
	/* 0xb70: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b73:
	/* 0xb73: jns    b77 <trace_check_helper_call+0xb77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb73, 0xb77, x86_l_b77);
x86_l_b75:
	/* 0xb75: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b77:
	/* 0xb77: mov    DWORD PTR [rbx+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_b7a:
	/* 0xb7a: mov    r14,QWORD PTR [rbx+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_b81:
	/* 0xb81: mov    r15,QWORD PTR [rbx+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_b88:
	/* 0xb88: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b8b:
	/* 0xb8b: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b90:
	/* 0xb90: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_b97:
	/* 0xb97: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b9c:
	/* 0xb9c: call   ba1 <trace_check_helper_call+0xba1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ba1:
	/* 0xba1: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ba8:
	/* 0xba8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bab:
	/* 0xbab: je     bca <trace_check_helper_call+0xbca> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbab, 0xbca, x86_l_bca);
x86_l_bad:
	/* 0xbad: lea    rsi,[rbx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_bb1:
	/* 0xbb1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bb4:
	/* 0xbb4: call   bb9 <trace_check_helper_call+0xbb9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bb9:
	/* 0xbb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbc:
	/* 0xbbc: je     bca <trace_check_helper_call+0xbca> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbbc, 0xbca, x86_l_bca);
x86_l_bbe:
	/* 0xbbe: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bc1:
	/* 0xbc1: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bc5:
	/* 0xbc5: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bc8:
	/* 0xbc8: jmp    bcc <trace_check_helper_call+0xbcc> */
	X86_SIM_X86_JMP(0xbc8, 0xbcc, x86_l_bcc);
x86_l_bca:
	/* 0xbca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bcc:
	/* 0xbcc: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bcf:
	/* 0xbcf: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bd2:
	/* 0xbd2: or     r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bd5:
	/* 0xbd5: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bd8:
	/* 0xbd8: cmp    QWORD PTR [rbx+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_be0:
	/* 0xbe0: je     ca1 <trace_check_helper_call+0xca1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe0, 0xca1, x86_l_ca1);
x86_l_be6:
	/* 0xbe6: mov    rcx,QWORD PTR [rbx+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_bed:
	/* 0xbed: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_bf1:
	/* 0xbf1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bf3:
	/* 0xbf3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bf6:
	/* 0xbf6: jns    c05 <trace_check_helper_call+0xc05> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbf6, 0xc05, x86_l_c05);
x86_l_bf8:
	/* 0xbf8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bfb:
	/* 0xbfb: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bfe:
	/* 0xbfe: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c01:
	/* 0xc01: js     c0f <trace_check_helper_call+0xc0f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc01, 0xc0f, x86_l_c0f);
x86_l_c03:
	/* 0xc03: jmp    c11 <trace_check_helper_call+0xc11> */
	X86_SIM_X86_JMP(0xc03, 0xc11, x86_l_c11);
x86_l_c05:
	/* 0xc05: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c07:
	/* 0xc07: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c0a:
	/* 0xc0a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c0d:
	/* 0xc0d: jns    c11 <trace_check_helper_call+0xc11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc0d, 0xc11, x86_l_c11);
x86_l_c0f:
	/* 0xc0f: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c11:
	/* 0xc11: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c13:
	/* 0xc13: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_c17:
	/* 0xc17: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_c1a:
	/* 0xc1a: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c1e:
	/* 0xc1e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c20:
	/* 0xc20: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c23:
	/* 0xc23: jns    c33 <trace_check_helper_call+0xc33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc23, 0xc33, x86_l_c33);
x86_l_c25:
	/* 0xc25: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c28:
	/* 0xc28: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_c2c:
	/* 0xc2c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c2f:
	/* 0xc2f: js     c3e <trace_check_helper_call+0xc3e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc2f, 0xc3e, x86_l_c3e);
x86_l_c31:
	/* 0xc31: jmp    c40 <trace_check_helper_call+0xc40> */
	X86_SIM_X86_JMP(0xc31, 0xc40, x86_l_c40);
x86_l_c33:
	/* 0xc33: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c35:
	/* 0xc35: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_c39:
	/* 0xc39: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c3c:
	/* 0xc3c: jns    c40 <trace_check_helper_call+0xc40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc3c, 0xc40, x86_l_c40);
x86_l_c3e:
	/* 0xc3e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c40:
	/* 0xc40: mov    DWORD PTR [rbx+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c43:
	/* 0xc43: mov    r14,QWORD PTR [rbx+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_c4a:
	/* 0xc4a: mov    r15,QWORD PTR [rbx+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_c51:
	/* 0xc51: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c54:
	/* 0xc54: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c59:
	/* 0xc59: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_c60:
	/* 0xc60: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c65:
	/* 0xc65: call   c6a <trace_check_helper_call+0xc6a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c6a:
	/* 0xc6a: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c71:
	/* 0xc71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c74:
	/* 0xc74: je     c93 <trace_check_helper_call+0xc93> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc74, 0xc93, x86_l_c93);
x86_l_c76:
	/* 0xc76: lea    rsi,[rbx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c7a:
	/* 0xc7a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7d:
	/* 0xc7d: call   c82 <trace_check_helper_call+0xc82> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c82:
	/* 0xc82: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c85:
	/* 0xc85: je     c93 <trace_check_helper_call+0xc93> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc85, 0xc93, x86_l_c93);
x86_l_c87:
	/* 0xc87: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c8a:
	/* 0xc8a: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c8e:
	/* 0xc8e: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c91:
	/* 0xc91: jmp    c95 <trace_check_helper_call+0xc95> */
	X86_SIM_X86_JMP(0xc91, 0xc95, x86_l_c95);
x86_l_c93:
	/* 0xc93: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c95:
	/* 0xc95: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c98:
	/* 0xc98: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c9b:
	/* 0xc9b: or     r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c9e:
	/* 0xc9e: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ca1:
	/* 0xca1: cmp    QWORD PTR [rbx+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_ca9:
	/* 0xca9: je     e7a <trace_check_helper_call+0xe7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xca9, 0xe7a, x86_l_e7a);
x86_l_caf:
	/* 0xcaf: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_cb4:
	/* 0xcb4: add    rax,QWORD PTR [rbx+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_cbb:
	/* 0xcbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cbe:
	/* 0xcbe: jns    cd1 <trace_check_helper_call+0xcd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcbe, 0xcd1, x86_l_cd1);
x86_l_cc0:
	/* 0xcc0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc3:
	/* 0xcc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc6:
	/* 0xcc6: js     cd8 <trace_check_helper_call+0xcd8> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcc6, 0xcd8, x86_l_cd8);
x86_l_cc8:
	/* 0xcc8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cca:
	/* 0xcca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ccd:
	/* 0xccd: js     ce0 <trace_check_helper_call+0xce0> */
	X86_SIM_X86_JCC(X86_CC_S, 0xccd, 0xce0, x86_l_ce0);
x86_l_ccf:
	/* 0xccf: jmp    d2b <trace_check_helper_call+0xd2b> */
	X86_SIM_X86_JMP(0xccf, 0xd2b, x86_l_d2b);
x86_l_cd1:
	/* 0xcd1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cd3:
	/* 0xcd3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd6:
	/* 0xcd6: jns    cc8 <trace_check_helper_call+0xcc8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd6, 0xcc8, x86_l_cc8);
x86_l_cd8:
	/* 0xcd8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cdb:
	/* 0xcdb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cde:
	/* 0xcde: jns    d2b <trace_check_helper_call+0xd2b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcde, 0xd2b, x86_l_d2b);
x86_l_ce0:
	/* 0xce0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce3:
	/* 0xce3: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ce8:
	/* 0xce8: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cec:
	/* 0xcec: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_cf1:
	/* 0xcf1: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cf5:
	/* 0xcf5: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cfa:
	/* 0xcfa: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_cfe:
	/* 0xcfe: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d03:
	/* 0xd03: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d07:
	/* 0xd07: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d0c:
	/* 0xd0c: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d10:
	/* 0xd10: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_d15:
	/* 0xd15: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d19:
	/* 0xd19: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d1e:
	/* 0xd1e: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d22:
	/* 0xd22: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d27:
	/* 0xd27: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_d2b:
	/* 0xd2b: lea    r12,[rbx+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_d2f:
	/* 0xd2f: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d34:
	/* 0xd34: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d37:
	/* 0xd37: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d3a:
	/* 0xd3a: jns    dff <trace_check_helper_call+0xdff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd3a, 0xdff, x86_l_dff);
x86_l_d40:
	/* 0xd40: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_d43:
	/* 0xd43: mov    BYTE PTR [r12],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d47:
	/* 0xd47: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d49:
	/* 0xd49: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd49, 0xe10, x86_l_e10);
x86_l_d4f:
	/* 0xd4f: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_d53:
	/* 0xd53: mov    BYTE PTR [rbx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_d56:
	/* 0xd56: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d58:
	/* 0xd58: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd58, 0xe10, x86_l_e10);
x86_l_d5e:
	/* 0xd5e: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_d62:
	/* 0xd62: mov    BYTE PTR [rbx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_d65:
	/* 0xd65: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d67:
	/* 0xd67: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd67, 0xe10, x86_l_e10);
x86_l_d6d:
	/* 0xd6d: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_d71:
	/* 0xd71: mov    BYTE PTR [rbx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_d74:
	/* 0xd74: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d76:
	/* 0xd76: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd76, 0xe10, x86_l_e10);
x86_l_d7c:
	/* 0xd7c: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_d80:
	/* 0xd80: mov    BYTE PTR [rbx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d83:
	/* 0xd83: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d85:
	/* 0xd85: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd85, 0xe10, x86_l_e10);
x86_l_d8b:
	/* 0xd8b: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_d8f:
	/* 0xd8f: mov    BYTE PTR [rbx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_d92:
	/* 0xd92: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d94:
	/* 0xd94: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd94, 0xe10, x86_l_e10);
x86_l_d96:
	/* 0xd96: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_d9a:
	/* 0xd9a: mov    BYTE PTR [rbx+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_d9d:
	/* 0xd9d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d9f:
	/* 0xd9f: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd9f, 0xe10, x86_l_e10);
x86_l_da1:
	/* 0xda1: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_da5:
	/* 0xda5: mov    BYTE PTR [rbx+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_da8:
	/* 0xda8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_daa:
	/* 0xdaa: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdaa, 0xe10, x86_l_e10);
x86_l_dac:
	/* 0xdac: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_db0:
	/* 0xdb0: mov    BYTE PTR [rbx+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_db3:
	/* 0xdb3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_db5:
	/* 0xdb5: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb5, 0xe10, x86_l_e10);
x86_l_db7:
	/* 0xdb7: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_dbb:
	/* 0xdbb: mov    BYTE PTR [rbx+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_dbe:
	/* 0xdbe: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dc0:
	/* 0xdc0: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc0, 0xe10, x86_l_e10);
x86_l_dc2:
	/* 0xdc2: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_dc6:
	/* 0xdc6: mov    BYTE PTR [rbx+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_dc9:
	/* 0xdc9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dcb:
	/* 0xdcb: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdcb, 0xe10, x86_l_e10);
x86_l_dcd:
	/* 0xdcd: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_dd1:
	/* 0xdd1: mov    BYTE PTR [rbx+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_dd4:
	/* 0xdd4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dd6:
	/* 0xdd6: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdd6, 0xe10, x86_l_e10);
x86_l_dd8:
	/* 0xdd8: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_ddc:
	/* 0xddc: mov    BYTE PTR [rbx+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ddf:
	/* 0xddf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_de1:
	/* 0xde1: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde1, 0xe10, x86_l_e10);
x86_l_de3:
	/* 0xde3: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_de7:
	/* 0xde7: mov    BYTE PTR [rbx+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_dea:
	/* 0xdea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dec:
	/* 0xdec: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdec, 0xe10, x86_l_e10);
x86_l_dee:
	/* 0xdee: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_df2:
	/* 0xdf2: mov    BYTE PTR [rbx+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_df5:
	/* 0xdf5: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_df7:
	/* 0xdf7: je     e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf7, 0xe10, x86_l_e10);
x86_l_df9:
	/* 0xdf9: mov    BYTE PTR [rbx+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_dfd:
	/* 0xdfd: jmp    e10 <trace_check_helper_call+0xe10> */
	X86_SIM_X86_JMP(0xdfd, 0xe10, x86_l_e10);
x86_l_dff:
	/* 0xdff: mov    QWORD PTR [r12+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e08:
	/* 0xe08: mov    QWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e10:
	/* 0xe10: mov    r14,QWORD PTR [rbx+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_e17:
	/* 0xe17: mov    r15,QWORD PTR [rbx+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_e1e:
	/* 0xe1e: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_e21:
	/* 0xe21: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_e26:
	/* 0xe26: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e2b:
	/* 0xe2b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_e32:
	/* 0xe32: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e37:
	/* 0xe37: call   e3c <trace_check_helper_call+0xe3c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e3c:
	/* 0xe3c: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_e43:
	/* 0xe43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e46:
	/* 0xe46: je     e64 <trace_check_helper_call+0xe64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe46, 0xe64, x86_l_e64);
x86_l_e48:
	/* 0xe48: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4b:
	/* 0xe4b: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e4e:
	/* 0xe4e: call   e53 <trace_check_helper_call+0xe53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e53:
	/* 0xe53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e56:
	/* 0xe56: je     e64 <trace_check_helper_call+0xe64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe56, 0xe64, x86_l_e64);
x86_l_e58:
	/* 0xe58: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e5b:
	/* 0xe5b: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e5f:
	/* 0xe5f: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_e62:
	/* 0xe62: jmp    e66 <trace_check_helper_call+0xe66> */
	X86_SIM_X86_JMP(0xe62, 0xe66, x86_l_e66);
x86_l_e64:
	/* 0xe64: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e66:
	/* 0xe66: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_e69:
	/* 0xe69: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_e6c:
	/* 0xe6c: or     r13,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_e6f:
	/* 0xe6f: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_e72:
	/* 0xe72: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e75:
	/* 0xe75: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_e7a:
	/* 0xe7a: cmp    QWORD PTR [rbx+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_e82:
	/* 0xe82: je     f08 <trace_check_helper_call+0xf08> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe82, 0xf08, x86_l_f08);
x86_l_e88:
	/* 0xe88: mov    QWORD PTR [rsp+0x68],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_e8d:
	/* 0xe8d: lea    r12,[rbx+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_e91:
	/* 0xe91: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e94:
	/* 0xe94: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_e99:
	/* 0xe99: call   e9e <trace_check_helper_call+0xe9e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_e9e:
	/* 0xe9e: mov    r14,QWORD PTR [rbx+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_ea5:
	/* 0xea5: mov    r15,QWORD PTR [rbx+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_eac:
	/* 0xeac: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_eaf:
	/* 0xeaf: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_eb4:
	/* 0xeb4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_ebb:
	/* 0xebb: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ec0:
	/* 0xec0: call   ec5 <trace_check_helper_call+0xec5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ec5:
	/* 0xec5: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ecc:
	/* 0xecc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ecf:
	/* 0xecf: je     eed <trace_check_helper_call+0xeed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xecf, 0xeed, x86_l_eed);
x86_l_ed1:
	/* 0xed1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed4:
	/* 0xed4: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ed7:
	/* 0xed7: call   edc <trace_check_helper_call+0xedc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_edc:
	/* 0xedc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_edf:
	/* 0xedf: je     eed <trace_check_helper_call+0xeed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xedf, 0xeed, x86_l_eed);
x86_l_ee1:
	/* 0xee1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee4:
	/* 0xee4: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee8:
	/* 0xee8: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_eeb:
	/* 0xeeb: jmp    eef <trace_check_helper_call+0xeef> */
	X86_SIM_X86_JMP(0xeeb, 0xeef, x86_l_eef);
x86_l_eed:
	/* 0xeed: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eef:
	/* 0xeef: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ef2:
	/* 0xef2: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ef5:
	/* 0xef5: or     r13,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ef8:
	/* 0xef8: mov    rbp,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_efd:
	/* 0xefd: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f00:
	/* 0xf00: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f03:
	/* 0xf03: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_f08:
	/* 0xf08: mov    r14,QWORD PTR [rbx+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_f0f:
	/* 0xf0f: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f12:
	/* 0xf12: je     f73 <trace_check_helper_call+0xf73> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf12, 0xf73, x86_l_f73);
x86_l_f14:
	/* 0xf14: mov    eax,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f17:
	/* 0xf17: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f1b:
	/* 0xf1b: mov    r15,QWORD PTR [rbx+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_f22:
	/* 0xf22: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f25:
	/* 0xf25: mov    WORD PTR [rsp+0x4],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f2a:
	/* 0xf2a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_f31:
	/* 0xf31: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f36:
	/* 0xf36: call   f3b <trace_check_helper_call+0xf3b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f3b:
	/* 0xf3b: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_f42:
	/* 0xf42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f45:
	/* 0xf45: je     f65 <trace_check_helper_call+0xf65> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf45, 0xf65, x86_l_f65);
x86_l_f47:
	/* 0xf47: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f4c:
	/* 0xf4c: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f4f:
	/* 0xf4f: call   f54 <trace_check_helper_call+0xf54> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f54:
	/* 0xf54: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f57:
	/* 0xf57: je     f65 <trace_check_helper_call+0xf65> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf57, 0xf65, x86_l_f65);
x86_l_f59:
	/* 0xf59: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f5c:
	/* 0xf5c: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f60:
	/* 0xf60: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f63:
	/* 0xf63: jmp    f67 <trace_check_helper_call+0xf67> */
	X86_SIM_X86_JMP(0xf63, 0xf67, x86_l_f67);
x86_l_f65:
	/* 0xf65: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f67:
	/* 0xf67: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f6a:
	/* 0xf6a: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f6d:
	/* 0xf6d: or     r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f70:
	/* 0xf70: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f73:
	/* 0xf73: mov    r14,QWORD PTR [rbx+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_f7a:
	/* 0xf7a: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f7d:
	/* 0xf7d: je     fd9 <trace_check_helper_call+0xfd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf7d, 0xfd9, x86_l_fd9);
x86_l_f7f:
	/* 0xf7f: mov    r15,QWORD PTR [rbx+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_f86:
	/* 0xf86: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f89:
	/* 0xf89: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f8e:
	/* 0xf8e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_f95:
	/* 0xf95: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_f9a:
	/* 0xf9a: call   f9f <trace_check_helper_call+0xf9f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f9f:
	/* 0xf9f: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_fa6:
	/* 0xfa6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fa9:
	/* 0xfa9: je     fcb <trace_check_helper_call+0xfcb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfa9, 0xfcb, x86_l_fcb);
x86_l_fab:
	/* 0xfab: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fae:
	/* 0xfae: add    rsi,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_fb2:
	/* 0xfb2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fb5:
	/* 0xfb5: call   fba <trace_check_helper_call+0xfba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fba:
	/* 0xfba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fbd:
	/* 0xfbd: je     fcb <trace_check_helper_call+0xfcb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfbd, 0xfcb, x86_l_fcb);
x86_l_fbf:
	/* 0xfbf: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fc2:
	/* 0xfc2: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fc6:
	/* 0xfc6: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fc9:
	/* 0xfc9: jmp    fcd <trace_check_helper_call+0xfcd> */
	X86_SIM_X86_JMP(0xfc9, 0xfcd, x86_l_fcd);
x86_l_fcb:
	/* 0xfcb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fcd:
	/* 0xfcd: or     r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fd0:
	/* 0xfd0: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fd3:
	/* 0xfd3: or     r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fd6:
	/* 0xfd6: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fd9:
	/* 0xfd9: mov    r14,QWORD PTR [rbx+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_fe0:
	/* 0xfe0: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fe3:
	/* 0xfe3: je     1066 <trace_check_helper_call+0x1066> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe3, 0x1066, x86_l_1066);
x86_l_fe9:
	/* 0xfe9: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_feb:
	/* 0xfeb: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_fee:
	/* 0xfee: mov    r15,QWORD PTR [rbx+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_ff5:
	/* 0xff5: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ff8:
	/* 0xff8: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ffd:
	/* 0xffd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_1004:
	/* 0x1004: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1009:
	/* 0x1009: call   100e <trace_check_helper_call+0x100e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_100e:
	/* 0x100e: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1015:
	/* 0x1015: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1018:
	/* 0x1018: je     1055 <trace_check_helper_call+0x1055> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1018, 0x1055, x86_l_1055);
x86_l_101a:
	/* 0x101a: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_101d:
	/* 0x101d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1022:
	/* 0x1022: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1026:
	/* 0x1026: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1029:
	/* 0x1029: call   102e <trace_check_helper_call+0x102e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_102e:
	/* 0x102e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1031:
	/* 0x1031: jne    1049 <trace_check_helper_call+0x1049> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1031, 0x1049, x86_l_1049);
x86_l_1033:
	/* 0x1033: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1038:
	/* 0x1038: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_103c:
	/* 0x103c: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_103f:
	/* 0x103f: call   1044 <trace_check_helper_call+0x1044> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1044:
	/* 0x1044: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1047:
	/* 0x1047: je     1055 <trace_check_helper_call+0x1055> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1047, 0x1055, x86_l_1055);
x86_l_1049:
	/* 0x1049: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_104c:
	/* 0x104c: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1050:
	/* 0x1050: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1053:
	/* 0x1053: jmp    1057 <trace_check_helper_call+0x1057> */
	X86_SIM_X86_JMP(0x1053, 0x1057, x86_l_1057);
x86_l_1055:
	/* 0x1055: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1057:
	/* 0x1057: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_105a:
	/* 0x105a: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_105d:
	/* 0x105d: or     r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1060:
	/* 0x1060: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1063:
	/* 0x1063: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1066:
	/* 0x1066: mov    rax,QWORD PTR [rbx+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_106d:
	/* 0x106d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1070:
	/* 0x1070: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1075:
	/* 0x1075: je     107e <trace_check_helper_call+0x107e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1075, 0x107e, x86_l_107e);
x86_l_1077:
	/* 0x1077: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_107b:
	/* 0x107b: or     r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_107e:
	/* 0x107e: and    r13,QWORD PTR [rbx+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_1085:
	/* 0x1085: mov    rax,QWORD PTR [rbx+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_108c:
	/* 0x108c: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_108f:
	/* 0x108f: mov    QWORD PTR [rbx+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1096:
	/* 0x1096: je     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1096, 0x119b, x86_l_119b);
x86_l_109c:
	/* 0x109c: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_10a4:
	/* 0x10a4: mov    rax,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_10a8:
	/* 0x10a8: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_10ac:
	/* 0x10ac: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10af:
	/* 0x10af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10b2:
	/* 0x10b2: jns    10b7 <trace_check_helper_call+0x10b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b2, 0x10b7, x86_l_10b7);
x86_l_10b4:
	/* 0x10b4: mov    r14d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b7:
	/* 0x10b7: mov    eax,DWORD PTR [rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_10ba:
	/* 0x10ba: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10be:
	/* 0x10be: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10c7:
	/* 0x10c7: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_10d0:
	/* 0x10d0: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_10d9:
	/* 0x10d9: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_10e2:
	/* 0x10e2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bpf_attach_tmp_map));
x86_l_10e9:
	/* 0x10e9: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10ee:
	/* 0x10ee: call   10f3 <trace_check_helper_call+0x10f3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10f3:
	/* 0x10f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10f6:
	/* 0x10f6: je     111b <trace_check_helper_call+0x111b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10f6, 0x111b, x86_l_111b);
x86_l_10f8:
	/* 0x10f8: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_10fc:
	/* 0x10fc: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1101:
	/* 0x1101: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1105:
	/* 0x1105: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_110a:
	/* 0x110a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_110d:
	/* 0x110d: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1111:
	/* 0x1111: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1116:
	/* 0x1116: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_111b:
	/* 0x111b: cmp    r14d,0x40 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_111f:
	/* 0x111f: jl     1153 <trace_check_helper_call+0x1153> */
	X86_SIM_X86_JCC(X86_CC_L, 0x111f, 0x1153, x86_l_1153);
x86_l_1121:
	/* 0x1121: cmp    r14d,0x80 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 128ULL);
x86_l_1128:
	/* 0x1128: jb     1157 <trace_check_helper_call+0x1157> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1128, 0x1157, x86_l_1157);
x86_l_112a:
	/* 0x112a: cmp    r14d,0xc0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 192ULL);
x86_l_1131:
	/* 0x1131: jb     1162 <trace_check_helper_call+0x1162> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1131, 0x1162, x86_l_1162);
x86_l_1133:
	/* 0x1133: mov    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1138:
	/* 0x1138: cmp    r14d,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_113f:
	/* 0x113f: jb     116d <trace_check_helper_call+0x116d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x113f, 0x116d, x86_l_116d);
x86_l_1141:
	/* 0x1141: cmp    r14d,0x13f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 319ULL);
x86_l_1148:
	/* 0x1148: ja     119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1148, 0x119b, x86_l_119b);
x86_l_114a:
	/* 0x114a: add    r14d,0xffffff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967040ULL);
x86_l_1151:
	/* 0x1151: jmp    1174 <trace_check_helper_call+0x1174> */
	X86_SIM_X86_JMP(0x1151, 0x1174, x86_l_1174);
x86_l_1153:
	/* 0x1153: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1155:
	/* 0x1155: jmp    1174 <trace_check_helper_call+0x1174> */
	X86_SIM_X86_JMP(0x1155, 0x1174, x86_l_1174);
x86_l_1157:
	/* 0x1157: add    r14d,0xffffffc0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967232ULL);
x86_l_115b:
	/* 0x115b: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1160:
	/* 0x1160: jmp    1174 <trace_check_helper_call+0x1174> */
	X86_SIM_X86_JMP(0x1160, 0x1174, x86_l_1174);
x86_l_1162:
	/* 0x1162: add    r14d,0xffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967168ULL);
x86_l_1166:
	/* 0x1166: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_116b:
	/* 0x116b: jmp    1174 <trace_check_helper_call+0x1174> */
	X86_SIM_X86_JMP(0x116b, 0x1174, x86_l_1174);
x86_l_116d:
	/* 0x116d: add    r14d,0xffffff40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967104ULL);
x86_l_1174:
	/* 0x1174: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1179:
	/* 0x1179: shlx   rcx,rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_RCX, X86_WIDTH_64, X86_R14, X86_ALU_SHL);
x86_l_117e:
	/* 0x117e: or     QWORD PTR [rsp+rax*8+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RAX, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 32ULL);
x86_l_1183:
	/* 0x1183: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bpf_attach_tmp_map));
x86_l_118a:
	/* 0x118a: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_118f:
	/* 0x118f: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1194:
	/* 0x1194: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1196:
	/* 0x1196: call   119b <trace_check_helper_call+0x119b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_119b:
	/* 0x119b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_119d:
	/* 0x119d: add    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_11a4:
	/* 0x11a4: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11a5:
	/* 0x11a5: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11a7:
	/* 0x11a7: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11a9:
	/* 0x11a9: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11ab:
	/* 0x11ab: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11ad:
	/* 0x11ad: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11ae:
	/* 0x11ae: jmp    137c <trace_check_helper_call+0x137c> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_11b3:
	/* 0x11b3: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11b6:
	/* 0x11b6: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_11ba:
	/* 0x11ba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11bd:
	/* 0x11bd: jns    1361 <trace_check_helper_call+0x1361> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11bd, 0x1361, x86_l_1361);
x86_l_11c3:
	/* 0x11c3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11c6:
	/* 0x11c6: mov    QWORD PTR [rbx+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_11cd:
	/* 0x11cd: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11d1:
	/* 0x11d1: mov    QWORD PTR [rbx+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_11d8:
	/* 0x11d8: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11dc:
	/* 0x11dc: mov    QWORD PTR [rbx+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_11e3:
	/* 0x11e3: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11e7:
	/* 0x11e7: mov    QWORD PTR [rbx+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_11ee:
	/* 0x11ee: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11f2:
	/* 0x11f2: mov    QWORD PTR [rbx+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_11f9:
	/* 0x11f9: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11fd:
	/* 0x11fd: mov    QWORD PTR [rbx+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1204:
	/* 0x1204: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1208:
	/* 0x1208: mov    QWORD PTR [rbx+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_120f:
	/* 0x120f: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1213:
	/* 0x1213: mov    QWORD PTR [rbx+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_121a:
	/* 0x121a: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_121e:
	/* 0x121e: mov    QWORD PTR [rbx+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1225:
	/* 0x1225: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1229:
	/* 0x1229: mov    QWORD PTR [rbx+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1230:
	/* 0x1230: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1234:
	/* 0x1234: mov    QWORD PTR [rbx+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_123b:
	/* 0x123b: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_123f:
	/* 0x123f: mov    QWORD PTR [rbx+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1246:
	/* 0x1246: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_124a:
	/* 0x124a: mov    QWORD PTR [rbx+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_1251:
	/* 0x1251: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1255:
	/* 0x1255: mov    QWORD PTR [rbx+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_125c:
	/* 0x125c: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1260:
	/* 0x1260: mov    QWORD PTR [rbx+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1267:
	/* 0x1267: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_126b:
	/* 0x126b: mov    QWORD PTR [rbx+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_1272:
	/* 0x1272: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1279:
	/* 0x1279: mov    QWORD PTR [rbx+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_1280:
	/* 0x1280: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1287:
	/* 0x1287: mov    QWORD PTR [rbx+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_128e:
	/* 0x128e: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1295:
	/* 0x1295: mov    QWORD PTR [rbx+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_129c:
	/* 0x129c: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_12a3:
	/* 0x12a3: mov    QWORD PTR [rbx+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_12aa:
	/* 0x12aa: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_12b1:
	/* 0x12b1: mov    QWORD PTR [rbx+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_12b8:
	/* 0x12b8: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_12bf:
	/* 0x12bf: mov    QWORD PTR [rbx+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_12c6:
	/* 0x12c6: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_12cd:
	/* 0x12cd: mov    QWORD PTR [rbx+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_12d4:
	/* 0x12d4: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_12db:
	/* 0x12db: mov    QWORD PTR [rbx+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_12e2:
	/* 0x12e2: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_12e9:
	/* 0x12e9: mov    QWORD PTR [rbx+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_12f0:
	/* 0x12f0: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_12f7:
	/* 0x12f7: mov    QWORD PTR [rbx+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_12fe:
	/* 0x12fe: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1305:
	/* 0x1305: mov    QWORD PTR [rbx+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_130c:
	/* 0x130c: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1313:
	/* 0x1313: mov    QWORD PTR [rbx+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_131a:
	/* 0x131a: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1321:
	/* 0x1321: mov    QWORD PTR [rbx+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1328:
	/* 0x1328: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_132f:
	/* 0x132f: mov    QWORD PTR [rbx+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1336:
	/* 0x1336: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_133d:
	/* 0x133d: mov    QWORD PTR [rbx+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1344:
	/* 0x1344: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_134b:
	/* 0x134b: mov    QWORD PTR [rbx+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_1352:
	/* 0x1352: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1358:
	/* 0x1358: mov    WORD PTR [rbx+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_135c:
	/* 0x135c: jmp    792 <trace_check_helper_call+0x792> */
	X86_SIM_X86_JMP(0x135c, 0x792, x86_l_792);
x86_l_1361:
	/* 0x1361: add    rbx,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1368:
	/* 0x1368: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_136d:
	/* 0x136d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1370:
	/* 0x1370: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1372:
	/* 0x1372: call   1377 <trace_check_helper_call+0x1377> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1377:
	/* 0x1377: jmp    119b <trace_check_helper_call+0x119b> */
	X86_SIM_X86_JMP(0x1377, 0x119b, x86_l_119b);
x86_l_137c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
