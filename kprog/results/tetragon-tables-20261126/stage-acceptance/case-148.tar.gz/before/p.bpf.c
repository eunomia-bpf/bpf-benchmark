#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 heap_ro_zero[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6:
	/* 0x6: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9:
	/* 0x9: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_b:
	/* 0xb: jne    1f <filter_file_buf+0x1f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb, 0x1f, x86_l_1f);
x86_l_d:
	/* 0xd: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_f:
	/* 0xf: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_12:
	/* 0x12: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_15:
	/* 0x15: je     1f <filter_file_buf+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15, 0x1f, x86_l_1f);
x86_l_17:
	/* 0x17: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19:
	/* 0x19: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a:
	/* 0x1a: jmp    8d3 <filter_char_buf_prefix+0x123> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1f:
	/* 0x1f: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_22:
	/* 0x22: ja     5e <filter_file_buf+0x5e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22, 0x5e, x86_l_5e);
x86_l_24:
	/* 0x24: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_26:
	/* 0x26: mov    edi,0x4000100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 67109120ULL);
x86_l_2b:
	/* 0x2b: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f:
	/* 0x2f: jb     92 <filter_file_buf+0x92> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2f, 0x92, x86_l_92);
x86_l_31:
	/* 0x31: mov    edi,0x8000200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 134218240ULL);
x86_l_36:
	/* 0x36: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a:
	/* 0x3a: jb     7c <filter_file_buf+0x7c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3a, 0x7c, x86_l_7c);
x86_l_3c:
	/* 0x3c: movabs rdi,0x3000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, 206158430208ULL);
x86_l_46:
	/* 0x46: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a:
	/* 0x4a: jae    5e <filter_file_buf+0x5e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4a, 0x5e, x86_l_5e);
x86_l_4c:
	/* 0x4c: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4f:
	/* 0x4f: call   cb <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_cb, 0x54ULL);
x86_l_54:
	/* 0x54: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_57:
	/* 0x57: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_5a:
	/* 0x5a: jbe    af <filter_file_buf+0xaf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5a, 0xaf, x86_l_af);
x86_l_5c:
	/* 0x5c: jmp    c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JMP(0x5c, 0xc5, x86_l_c5);
x86_l_5e:
	/* 0x5e: lea    eax,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_61:
	/* 0x61: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_64:
	/* 0x64: jae    a8 <filter_file_buf+0xa8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x64, 0xa8, x86_l_a8);
x86_l_66:
	/* 0x66: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_6a:
	/* 0x6a: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6d:
	/* 0x6d: call   184 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_184, 0x72ULL);
x86_l_72:
	/* 0x72: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_75:
	/* 0x75: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_78:
	/* 0x78: jbe    af <filter_file_buf+0xaf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x78, 0xaf, x86_l_af);
x86_l_7a:
	/* 0x7a: jmp    c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JMP(0x7a, 0xc5, x86_l_c5);
x86_l_7c:
	/* 0x7c: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_80:
	/* 0x80: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_83:
	/* 0x83: call   66d <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_66d, 0x88ULL);
x86_l_88:
	/* 0x88: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8b:
	/* 0x8b: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_8e:
	/* 0x8e: jbe    af <filter_file_buf+0xaf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x8e, 0xaf, x86_l_af);
x86_l_90:
	/* 0x90: jmp    c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JMP(0x90, 0xc5, x86_l_c5);
x86_l_92:
	/* 0x92: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_96:
	/* 0x96: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_99:
	/* 0x99: call   7b0 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_7b0, 0x9eULL);
x86_l_9e:
	/* 0x9e: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a1:
	/* 0xa1: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_a4:
	/* 0xa4: jbe    af <filter_file_buf+0xaf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa4, 0xaf, x86_l_af);
x86_l_a6:
	/* 0xa6: jmp    c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JMP(0xa6, 0xc5, x86_l_c5);
x86_l_a8:
	/* 0xa8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aa:
	/* 0xaa: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_ad:
	/* 0xad: ja     c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JCC(X86_CC_A, 0xad, 0xc5, x86_l_c5);
x86_l_af:
	/* 0xaf: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b1:
	/* 0xb1: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_bb:
	/* 0xbb: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bf:
	/* 0xbf: jae    c5 <filter_file_buf+0xc5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xbf, 0xc5, x86_l_c5);
x86_l_c1:
	/* 0xc1: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_c5:
	/* 0xc5: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_c6:
	/* 0xc6: jmp    8d3 <filter_char_buf_prefix+0x123> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_8d3:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_cb */
x86_l_cb:
	/* 0xcb: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_cc:
	/* 0xcc: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_d0:
	/* 0xd0: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_d7:
	/* 0xd7: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d9:
	/* 0xd9: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_df:
	/* 0xdf: ja     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdf, 0x17c, x86_l_17c);
x86_l_e5:
	/* 0xe5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_eb:
	/* 0xeb: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_ef:
	/* 0xef: jns    102 <filter_file_type+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xef, 0x102, x86_l_102);
x86_l_f1:
	/* 0xf1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f4:
	/* 0xf4: jns    128 <filter_file_type+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xf4, 0x128, x86_l_128);
x86_l_f6:
	/* 0xf6: movzx  ecx,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_f9:
	/* 0xf9: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fc:
	/* 0xfc: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_fe:
	/* 0xfe: jne    131 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xfe, 0x131, x86_l_131);
x86_l_100:
	/* 0x100: jmp    17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x100, 0x17c, x86_l_17c);
x86_l_102:
	/* 0x102: lea    rax,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_107:
	/* 0x107: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10a:
	/* 0x10a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10d:
	/* 0x10d: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_112:
	/* 0x112: call   2987 <filter_char_buf_prefix+0x21d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_117:
	/* 0x117: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11a:
	/* 0x11a: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_11f:
	/* 0x11f: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_122:
	/* 0x122: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_124:
	/* 0x124: jne    131 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x124, 0x131, x86_l_131);
x86_l_126:
	/* 0x126: jmp    17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x126, 0x17c, x86_l_17c);
x86_l_128:
	/* 0x128: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12a:
	/* 0x12a: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12d:
	/* 0x12d: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_12f:
	/* 0x12f: je     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12f, 0x17c, x86_l_17c);
x86_l_131:
	/* 0x131: and    ecx,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_137:
	/* 0x137: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_13c:
	/* 0x13c: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_13e:
	/* 0x13e: je     17e <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13e, 0x17e, x86_l_17e);
x86_l_140:
	/* 0x140: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_143:
	/* 0x143: cmp    edx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_146:
	/* 0x146: jbe    17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x146, 0x17c, x86_l_17c);
x86_l_148:
	/* 0x148: mov    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_14b:
	/* 0x14b: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14d:
	/* 0x14d: je     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14d, 0x17c, x86_l_17c);
x86_l_14f:
	/* 0x14f: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_151:
	/* 0x151: je     17e <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x151, 0x17e, x86_l_17e);
x86_l_153:
	/* 0x153: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_156:
	/* 0x156: jb     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x156, 0x17c, x86_l_17c);
x86_l_158:
	/* 0x158: mov    esi,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15b:
	/* 0x15b: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_15d:
	/* 0x15d: je     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15d, 0x17c, x86_l_17c);
x86_l_15f:
	/* 0x15f: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_161:
	/* 0x161: je     17e <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x161, 0x17e, x86_l_17e);
x86_l_163:
	/* 0x163: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_166:
	/* 0x166: jb     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x166, 0x17c, x86_l_17c);
x86_l_168:
	/* 0x168: mov    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_16b:
	/* 0x16b: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_16d:
	/* 0x16d: je     17c <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16d, 0x17c, x86_l_17c);
x86_l_16f:
	/* 0x16f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_171:
	/* 0x171: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_173:
	/* 0x173: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_176:
	/* 0x176: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_17a:
	/* 0x17a: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_17b:
	/* 0x17b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_17b);
x86_l_17c:
	/* 0x17c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17e:
	/* 0x17e: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_182:
	/* 0x182: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_183:
	/* 0x183: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_17b);

	/* native subroutine native_link_sub_184 */
x86_l_184:
	/* 0x184: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_185:
	/* 0x185: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_187:
	/* 0x187: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_189:
	/* 0x189: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18b:
	/* 0x18b: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18d:
	/* 0x18d: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18f:
	/* 0x18f: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_196:
	/* 0x196: cmp    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_19c:
	/* 0x19c: ja     565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x19c, 0x565, x86_l_565);
x86_l_1a2:
	/* 0x1a2: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1a5:
	/* 0x1a5: cmp    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1aa:
	/* 0x1aa: ja     1fa <filter_char_buf_equal+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1aa, 0x1fa, x86_l_1fa);
x86_l_1ac:
	/* 0x1ac: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1af:
	/* 0x1af: imul   ecx,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_1b5:
	/* 0x1b5: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_1b8:
	/* 0x1b8: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1bb:
	/* 0x1bb: lea    ecx,[rcx+rcx*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_1be:
	/* 0x1be: sub    al,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB, 0);
x86_l_1c0:
	/* 0x1c0: test   dx,dx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_16, 0, 0);
x86_l_1c3:
	/* 0x1c3: je     1ce <filter_char_buf_equal+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c3, 0x1ce, x86_l_1ce);
x86_l_1c5:
	/* 0x1c5: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1c7:
	/* 0x1c7: mov    r15d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1ca:
	/* 0x1ca: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1cc:
	/* 0x1cc: je     1e7 <filter_char_buf_equal+0x63> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1cc, 0x1e7, x86_l_1e7);
x86_l_1ce:
	/* 0x1ce: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1d1:
	/* 0x1d1: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1d3:
	/* 0x1d3: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d5:
	/* 0x1d5: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1d7:
	/* 0x1d7: add    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_1da:
	/* 0x1da: movzx  r15d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1de:
	/* 0x1de: cmp    cx,0x78 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, 0, 120ULL);
x86_l_1e2:
	/* 0x1e2: ja     238 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e2, 0x238, x86_l_238);
x86_l_1e4:
	/* 0x1e4: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e7:
	/* 0x1e7: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1ea:
	/* 0x1ea: imul   ebp,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_1f0:
	/* 0x1f0: shr    ebp,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_1f3:
	/* 0x1f3: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1f5:
	/* 0x1f5: jmp    27e <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1f5, 0x27e, x86_l_27e);
x86_l_1fa:
	/* 0x1fa: mov    r15d,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_200:
	/* 0x200: cmp    eax,0x101 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 257ULL);
x86_l_205:
	/* 0x205: jb     238 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x205, 0x238, x86_l_238);
x86_l_207:
	/* 0x207: mov    r15d,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_20d:
	/* 0x20d: cmp    eax,0x201 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 513ULL);
x86_l_212:
	/* 0x212: jb     238 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x212, 0x238, x86_l_238);
x86_l_214:
	/* 0x214: mov    r15d,0x400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_21a:
	/* 0x21a: cmp    eax,0x401 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1025ULL);
x86_l_21f:
	/* 0x21f: jb     238 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f, 0x238, x86_l_238);
x86_l_221:
	/* 0x221: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_224:
	/* 0x224: cmp    eax,0x801 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2049ULL);
x86_l_229:
	/* 0x229: setae  r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_22d:
	/* 0x22d: shl    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_231:
	/* 0x231: add    r15d,0x800 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_238:
	/* 0x238: lea    eax,[r15-0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_23f:
	/* 0x23f: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_245:
	/* 0x245: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_248:
	/* 0x248: jg     25a <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x248, 0x25a, x86_l_25a);
x86_l_24a:
	/* 0x24a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_24c:
	/* 0x24c: je     272 <filter_char_buf_equal+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24c, 0x272, x86_l_272);
x86_l_24e:
	/* 0x24e: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_251:
	/* 0x251: jne    26b <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x251, 0x26b, x86_l_26b);
x86_l_253:
	/* 0x253: mov    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_258:
	/* 0x258: jmp    27e <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x258, 0x27e, x86_l_27e);
x86_l_25a:
	/* 0x25a: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_25d:
	/* 0x25d: je     279 <filter_char_buf_equal+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x25d, 0x279, x86_l_279);
x86_l_25f:
	/* 0x25f: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_262:
	/* 0x262: jne    26b <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x262, 0x26b, x86_l_26b);
x86_l_264:
	/* 0x264: mov    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_269:
	/* 0x269: jmp    27e <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x269, 0x27e, x86_l_27e);
x86_l_26b:
	/* 0x26b: mov    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_270:
	/* 0x270: jmp    27e <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x270, 0x27e, x86_l_27e);
x86_l_272:
	/* 0x272: mov    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_277:
	/* 0x277: jmp    27e <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x277, 0x27e, x86_l_27e);
x86_l_279:
	/* 0x279: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_27e:
	/* 0x27e: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_280:
	/* 0x280: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_283:
	/* 0x283: mov    r12d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_288:
	/* 0x288: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_28c:
	/* 0x28c: je     565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x28c, 0x565, x86_l_565);
x86_l_292:
	/* 0x292: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_295:
	/* 0x295: mov    r13d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_298:
	/* 0x298: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_heap));
x86_l_29f:
	/* 0x29f: mov    r14,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_2a2:
	/* 0x2a2: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a5:
	/* 0x2a5: call   239a <filter_char_buf_prefix+0x1bea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2aa:
	/* 0x2aa: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_2b1:
	/* 0x2b1: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2b4:
	/* 0x2b4: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b7:
	/* 0x2b7: call   23ac <filter_char_buf_prefix+0x1bfc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2bc:
	/* 0x2bc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2be:
	/* 0x2be: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2c1:
	/* 0x2c1: je     567 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c1, 0x567, x86_l_567);
x86_l_2c7:
	/* 0x2c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ca:
	/* 0x2ca: je     567 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2ca, 0x567, x86_l_567);
x86_l_2d0:
	/* 0x2d0: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2d3:
	/* 0x2d3: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2d6:
	/* 0x2d6: jg     335 <filter_char_buf_equal+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2d6, 0x335, x86_l_335);
x86_l_2d8:
	/* 0x2d8: mov    BYTE PTR [r14],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db:
	/* 0x2db: lea    rdi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2df:
	/* 0x2df: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2e2:
	/* 0x2e2: jns    38b <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2e2, 0x38b, x86_l_38b);
x86_l_2e8:
	/* 0x2e8: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2eb:
	/* 0x2eb: jns    398 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2eb, 0x398, x86_l_398);
x86_l_2f1:
	/* 0x2f1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f3:
	/* 0x2f3: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f6:
	/* 0x2f6: jb     316 <filter_char_buf_equal+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2f6, 0x316, x86_l_316);
x86_l_2f8:
	/* 0x2f8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fb:
	/* 0x2fb: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2fe:
	/* 0x2fe: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_302:
	/* 0x302: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_306:
	/* 0x306: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_30a:
	/* 0x30a: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_30e:
	/* 0x30e: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_311:
	/* 0x311: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_314:
	/* 0x314: jbe    2fb <filter_char_buf_equal+0x177> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x314, 0x2fb, x86_l_2fb);
x86_l_316:
	/* 0x316: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_31a:
	/* 0x31a: jne    579 <filter_char_buf_equal+0x3f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x31a, 0x579, x86_l_579);
x86_l_320:
	/* 0x320: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_324:
	/* 0x324: jne    591 <filter_char_buf_equal+0x40d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x324, 0x591, x86_l_591);
x86_l_32a:
	/* 0x32a: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_32e:
	/* 0x32e: je     3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x32e, 0x3aa, x86_l_3aa);
x86_l_330:
	/* 0x330: jmp    5ab <filter_char_buf_equal+0x427> */
	X86_SIM_X86_SUB_JMP(0x330, 0x5ab, x86_l_5ab);
x86_l_335:
	/* 0x335: mov    WORD PTR [r14],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_339:
	/* 0x339: lea    rdi,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_33d:
	/* 0x33d: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_340:
	/* 0x340: jns    38b <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x340, 0x38b, x86_l_38b);
x86_l_342:
	/* 0x342: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_345:
	/* 0x345: jns    398 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x345, 0x398, x86_l_398);
x86_l_347:
	/* 0x347: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_349:
	/* 0x349: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_34c:
	/* 0x34c: jb     36c <filter_char_buf_equal+0x1e8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x34c, 0x36c, x86_l_36c);
x86_l_34e:
	/* 0x34e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_351:
	/* 0x351: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_354:
	/* 0x354: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_358:
	/* 0x358: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_35c:
	/* 0x35c: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_360:
	/* 0x360: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_364:
	/* 0x364: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_367:
	/* 0x367: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_36a:
	/* 0x36a: jbe    351 <filter_char_buf_equal+0x1cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x36a, 0x351, x86_l_351);
x86_l_36c:
	/* 0x36c: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_370:
	/* 0x370: jne    5b9 <filter_char_buf_equal+0x435> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x370, 0x5b9, x86_l_5b9);
x86_l_376:
	/* 0x376: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_37a:
	/* 0x37a: jne    5d1 <filter_char_buf_equal+0x44d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x37a, 0x5d1, x86_l_5d1);
x86_l_380:
	/* 0x380: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_384:
	/* 0x384: je     3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x384, 0x3aa, x86_l_3aa);
x86_l_386:
	/* 0x386: jmp    5eb <filter_char_buf_equal+0x467> */
	X86_SIM_X86_SUB_JMP(0x386, 0x5eb, x86_l_5eb);
x86_l_38b:
	/* 0x38b: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_38e:
	/* 0x38e: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_391:
	/* 0x391: call   2499 <filter_char_buf_prefix+0x1ce9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_396:
	/* 0x396: jmp    3a4 <filter_char_buf_equal+0x220> */
	X86_SIM_X86_SUB_JMP(0x396, 0x3a4, x86_l_3a4);
x86_l_398:
	/* 0x398: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_39a:
	/* 0x39a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39c:
	/* 0x39c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39f:
	/* 0x39f: call   24a7 <filter_char_buf_prefix+0x1cf7> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_3a4:
	/* 0x3a4: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_3a7:
	/* 0x3a7: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3aa:
	/* 0x3aa: sub    r15d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3ad:
	/* 0x3ad: jle    483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x3ad, 0x483, x86_l_483);
x86_l_3b3:
	/* 0x3b3: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_3b5:
	/* 0x3b5: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3b8:
	/* 0x3b8: add    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3bb:
	/* 0x3bb: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_3be:
	/* 0x3be: and    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3c4:
	/* 0x3c4: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3c7:
	/* 0x3c7: jg     420 <filter_char_buf_equal+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x3c7, 0x420, x86_l_420);
x86_l_3c9:
	/* 0x3c9: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_3cc:
	/* 0x3cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cf:
	/* 0x3cf: jns    470 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x3cf, 0x470, x86_l_470);
x86_l_3d5:
	/* 0x3d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d8:
	/* 0x3d8: jns    47a <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x3d8, 0x47a, x86_l_47a);
x86_l_3de:
	/* 0x3de: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e0:
	/* 0x3e0: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3e3:
	/* 0x3e3: jb     401 <filter_char_buf_equal+0x27d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x3e3, 0x401, x86_l_401);
x86_l_3e5:
	/* 0x3e5: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_3e7:
	/* 0x3e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e9:
	/* 0x3e9: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3ec:
	/* 0x3ec: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3f0:
	/* 0x3f0: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3f4:
	/* 0x3f4: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f8:
	/* 0x3f8: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3fc:
	/* 0x3fc: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ff:
	/* 0x3ff: jbe    3e9 <filter_char_buf_equal+0x265> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x3ff, 0x3e9, x86_l_3e9);
x86_l_401:
	/* 0x401: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_405:
	/* 0x405: jne    5f9 <filter_char_buf_equal+0x475> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x405, 0x5f9, x86_l_5f9);
x86_l_40b:
	/* 0x40b: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_40f:
	/* 0x40f: jne    60e <filter_char_buf_equal+0x48a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x40f, 0x60e, x86_l_60e);
x86_l_415:
	/* 0x415: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_419:
	/* 0x419: je     483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x419, 0x483, x86_l_483);
x86_l_41b:
	/* 0x41b: jmp    625 <filter_char_buf_equal+0x4a1> */
	X86_SIM_X86_SUB_JMP(0x41b, 0x625, x86_l_625);
x86_l_420:
	/* 0x420: add    rdi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_424:
	/* 0x424: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_427:
	/* 0x427: jns    470 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x427, 0x470, x86_l_470);
x86_l_429:
	/* 0x429: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42c:
	/* 0x42c: jns    47a <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x42c, 0x47a, x86_l_47a);
x86_l_42e:
	/* 0x42e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_430:
	/* 0x430: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_433:
	/* 0x433: jb     451 <filter_char_buf_equal+0x2cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x433, 0x451, x86_l_451);
x86_l_435:
	/* 0x435: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_437:
	/* 0x437: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_439:
	/* 0x439: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_43c:
	/* 0x43c: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_440:
	/* 0x440: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_444:
	/* 0x444: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_448:
	/* 0x448: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_44c:
	/* 0x44c: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_44f:
	/* 0x44f: jbe    439 <filter_char_buf_equal+0x2b5> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x44f, 0x439, x86_l_439);
x86_l_451:
	/* 0x451: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_455:
	/* 0x455: jne    633 <filter_char_buf_equal+0x4af> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x455, 0x633, x86_l_633);
x86_l_45b:
	/* 0x45b: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_45f:
	/* 0x45f: jne    648 <filter_char_buf_equal+0x4c4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x45f, 0x648, x86_l_648);
x86_l_465:
	/* 0x465: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_469:
	/* 0x469: je     483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x469, 0x483, x86_l_483);
x86_l_46b:
	/* 0x46b: jmp    65f <filter_char_buf_equal+0x4db> */
	X86_SIM_X86_SUB_JMP(0x46b, 0x65f, x86_l_65f);
x86_l_470:
	/* 0x470: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_473:
	/* 0x473: call   257b <filter_char_buf_prefix+0x1dcb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_478:
	/* 0x478: jmp    483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x478, 0x483, x86_l_483);
x86_l_47a:
	/* 0x47a: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_47c:
	/* 0x47c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_47e:
	/* 0x47e: call   2586 <filter_char_buf_prefix+0x1dd6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_483:
	/* 0x483: mov    DWORD PTR [rsp+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_488:
	/* 0x488: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_48b:
	/* 0x48b: jle    4b5 <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x48b, 0x4b5, x86_l_4b5);
x86_l_48d:
	/* 0x48d: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_490:
	/* 0x490: jg     4d6 <filter_char_buf_equal+0x352> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x490, 0x4d6, x86_l_4d6);
x86_l_492:
	/* 0x492: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_495:
	/* 0x495: je     531 <filter_char_buf_equal+0x3ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x495, 0x531, x86_l_531);
x86_l_49b:
	/* 0x49b: cmp    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_49e:
	/* 0x49e: je     516 <filter_char_buf_equal+0x392> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x49e, 0x516, x86_l_516);
x86_l_4a0:
	/* 0x4a0: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_4a3:
	/* 0x4a3: jne    565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a3, 0x565, x86_l_565);
x86_l_4a9:
	/* 0x4a9: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_7));
x86_l_4b0:
	/* 0x4b0: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x4b0, 0x541, x86_l_541);
x86_l_4b5:
	/* 0x4b5: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4b8:
	/* 0x4b8: jle    4f2 <filter_char_buf_equal+0x36e> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x4b8, 0x4f2, x86_l_4f2);
x86_l_4ba:
	/* 0x4ba: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4bd:
	/* 0x4bd: je     528 <filter_char_buf_equal+0x3a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4bd, 0x528, x86_l_528);
x86_l_4bf:
	/* 0x4bf: cmp    ebp,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_4c2:
	/* 0x4c2: je     50d <filter_char_buf_equal+0x389> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4c2, 0x50d, x86_l_50d);
x86_l_4c4:
	/* 0x4c4: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_4c7:
	/* 0x4c7: jne    565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4c7, 0x565, x86_l_565);
x86_l_4cd:
	/* 0x4cd: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_4));
x86_l_4d4:
	/* 0x4d4: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x4d4, 0x541, x86_l_541);
x86_l_4d6:
	/* 0x4d6: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4d9:
	/* 0x4d9: je     53a <filter_char_buf_equal+0x3b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d9, 0x53a, x86_l_53a);
x86_l_4db:
	/* 0x4db: cmp    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_4de:
	/* 0x4de: je     51f <filter_char_buf_equal+0x39b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4de, 0x51f, x86_l_51f);
x86_l_4e0:
	/* 0x4e0: cmp    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_4e3:
	/* 0x4e3: jne    565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4e3, 0x565, x86_l_565);
x86_l_4e9:
	/* 0x4e9: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_10));
x86_l_4f0:
	/* 0x4f0: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x4f0, 0x541, x86_l_541);
x86_l_4f2:
	/* 0x4f2: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_4f4:
	/* 0x4f4: je     504 <filter_char_buf_equal+0x380> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4f4, 0x504, x86_l_504);
x86_l_4f6:
	/* 0x4f6: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4f9:
	/* 0x4f9: jne    565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4f9, 0x565, x86_l_565);
x86_l_4fb:
	/* 0x4fb: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_1));
x86_l_502:
	/* 0x502: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x502, 0x541, x86_l_541);
x86_l_504:
	/* 0x504: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_0));
x86_l_50b:
	/* 0x50b: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x50b, 0x541, x86_l_541);
x86_l_50d:
	/* 0x50d: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_3));
x86_l_514:
	/* 0x514: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x514, 0x541, x86_l_541);
x86_l_516:
	/* 0x516: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_6));
x86_l_51d:
	/* 0x51d: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x51d, 0x541, x86_l_541);
x86_l_51f:
	/* 0x51f: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_9));
x86_l_526:
	/* 0x526: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x526, 0x541, x86_l_541);
x86_l_528:
	/* 0x528: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_2));
x86_l_52f:
	/* 0x52f: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x52f, 0x541, x86_l_541);
x86_l_531:
	/* 0x531: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_5));
x86_l_538:
	/* 0x538: jmp    541 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x538, 0x541, x86_l_541);
x86_l_53a:
	/* 0x53a: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_8));
x86_l_541:
	/* 0x541: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_546:
	/* 0x546: call   264a <filter_char_buf_prefix+0x1e9a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54b:
	/* 0x54b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54e:
	/* 0x54e: je     565 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x54e, 0x565, x86_l_565);
x86_l_550:
	/* 0x550: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_553:
	/* 0x553: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_556:
	/* 0x556: call   265a <filter_char_buf_prefix+0x1eaa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_55b:
	/* 0x55b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_55d:
	/* 0x55d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_560:
	/* 0x560: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_563:
	/* 0x563: jmp    567 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JMP(0x563, 0x567, x86_l_567);
x86_l_565:
	/* 0x565: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_567:
	/* 0x567: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_56a:
	/* 0x56a: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_56e:
	/* 0x56e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_56f:
	/* 0x56f: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_571:
	/* 0x571: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_573:
	/* 0x573: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_575:
	/* 0x575: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_577:
	/* 0x577: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_578:
	/* 0x578: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_578);
x86_l_579:
	/* 0x579: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_57c:
	/* 0x57c: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_580:
	/* 0x580: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_584:
	/* 0x584: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_587:
	/* 0x587: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_58b:
	/* 0x58b: je     32a <filter_char_buf_equal+0x1a6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x58b, 0x32a, x86_l_32a);
x86_l_591:
	/* 0x591: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_594:
	/* 0x594: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_599:
	/* 0x599: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_59e:
	/* 0x59e: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_5a1:
	/* 0x5a1: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_5a5:
	/* 0x5a5: je     3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5a5, 0x3aa, x86_l_3aa);
x86_l_5ab:
	/* 0x5ab: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5ad:
	/* 0x5ad: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_5b1:
	/* 0x5b1: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_5b4:
	/* 0x5b4: jmp    3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x5b4, 0x3aa, x86_l_3aa);
x86_l_5b9:
	/* 0x5b9: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5bc:
	/* 0x5bc: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_5c0:
	/* 0x5c0: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_5c4:
	/* 0x5c4: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_5c7:
	/* 0x5c7: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_5cb:
	/* 0x5cb: je     380 <filter_char_buf_equal+0x1fc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5cb, 0x380, x86_l_380);
x86_l_5d1:
	/* 0x5d1: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5d4:
	/* 0x5d4: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_5d9:
	/* 0x5d9: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_5de:
	/* 0x5de: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_5e1:
	/* 0x5e1: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_5e5:
	/* 0x5e5: je     3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5e5, 0x3aa, x86_l_3aa);
x86_l_5eb:
	/* 0x5eb: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5ed:
	/* 0x5ed: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_5f1:
	/* 0x5f1: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_5f4:
	/* 0x5f4: jmp    3aa <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x5f4, 0x3aa, x86_l_3aa);
x86_l_5f9:
	/* 0x5f9: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5fb:
	/* 0x5fb: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_5fe:
	/* 0x5fe: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_601:
	/* 0x601: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_604:
	/* 0x604: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_608:
	/* 0x608: je     415 <filter_char_buf_equal+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x608, 0x415, x86_l_415);
x86_l_60e:
	/* 0x60e: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_610:
	/* 0x610: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_614:
	/* 0x614: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_618:
	/* 0x618: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_61b:
	/* 0x61b: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_61f:
	/* 0x61f: je     483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x61f, 0x483, x86_l_483);
x86_l_625:
	/* 0x625: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_627:
	/* 0x627: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_62b:
	/* 0x62b: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_62e:
	/* 0x62e: jmp    483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x62e, 0x483, x86_l_483);
x86_l_633:
	/* 0x633: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_635:
	/* 0x635: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_638:
	/* 0x638: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_63b:
	/* 0x63b: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_63e:
	/* 0x63e: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_642:
	/* 0x642: je     465 <filter_char_buf_equal+0x2e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x642, 0x465, x86_l_465);
x86_l_648:
	/* 0x648: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_64a:
	/* 0x64a: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_64e:
	/* 0x64e: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_652:
	/* 0x652: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_655:
	/* 0x655: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_659:
	/* 0x659: je     483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x659, 0x483, x86_l_483);
x86_l_65f:
	/* 0x65f: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_661:
	/* 0x661: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_665:
	/* 0x665: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_668:
	/* 0x668: jmp    483 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x668, 0x483, x86_l_483);

	/* native subroutine native_link_sub_66d */
x86_l_66d:
	/* 0x66d: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_66f:
	/* 0x66f: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_671:
	/* 0x671: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_672:
	/* 0x672: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_676:
	/* 0x676: mov    ebx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_678:
	/* 0x678: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_67b:
	/* 0x67b: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_67f:
	/* 0x67f: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_687:
	/* 0x687: mov    rdi,QWORD PTR [rip+0x2720] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps));
x86_l_68e:
	/* 0x68e: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_693:
	/* 0x693: call   2db8 <filter_char_buf_prefix+0x2608> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_698:
	/* 0x698: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69b:
	/* 0x69b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69d:
	/* 0x69d: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_69f:
	/* 0x69f: je     7a6 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x69f, 0x7a6, x86_l_7a6);
x86_l_6a5:
	/* 0x6a5: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6a8:
	/* 0x6a8: je     7a6 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6a8, 0x7a6, x86_l_7a6);
x86_l_6ae:
	/* 0x6ae: mov    rdi,QWORD PTR [rip+0x2720] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_6b5:
	/* 0x6b5: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6ba:
	/* 0x6ba: call   2ddf <filter_char_buf_prefix+0x262f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6bf:
	/* 0x6bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c2:
	/* 0x6c2: je     7a4 <filter_char_buf_postfix+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6c2, 0x7a4, x86_l_7a4);
x86_l_6c8:
	/* 0x6c8: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_6ca:
	/* 0x6ca: cmp    ebx,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_6cd:
	/* 0x6cd: jb     6d4 <filter_char_buf_postfix+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x6cd, 0x6d4, x86_l_6d4);
x86_l_6cf:
	/* 0x6cf: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_6d4:
	/* 0x6d4: shl    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_6d7:
	/* 0x6d7: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d9:
	/* 0x6d9: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_6db:
	/* 0x6db: lea    edx,[rbx-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_6de:
	/* 0x6de: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e1:
	/* 0x6e1: add    rsi,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_6e5:
	/* 0x6e5: lea    edi,[rbx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_6e8:
	/* 0x6e8: lea    r8d,[rbx-0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_6ec:
	/* 0x6ec: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_6ee:
	/* 0x6ee: mov    r9,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_6f5:
	/* 0x6f5: lea    r10d,[rbx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_6f9:
	/* 0x6f9: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_6fd:
	/* 0x6fd: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_704:
	/* 0x704: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_709:
	/* 0x709: mov    BYTE PTR [rsi-0x3],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_70d:
	/* 0x70d: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_711:
	/* 0x711: cmp    r10,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_715:
	/* 0x715: je     78c <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x715, 0x78c, x86_l_78c);
x86_l_717:
	/* 0x717: lea    r11d,[r8+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_71b:
	/* 0x71b: add    r11d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_71f:
	/* 0x71f: and    r11d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_726:
	/* 0x726: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_72b:
	/* 0x72b: mov    BYTE PTR [rsi-0x2],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_72f:
	/* 0x72f: cmp    r10,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_733:
	/* 0x733: je     78c <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x733, 0x78c, x86_l_78c);
x86_l_735:
	/* 0x735: lea    r10d,[rdi+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_739:
	/* 0x739: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_73d:
	/* 0x73d: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_744:
	/* 0x744: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_749:
	/* 0x749: mov    BYTE PTR [rsi-0x1],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_74d:
	/* 0x74d: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_750:
	/* 0x750: add    r10,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_753:
	/* 0x753: je     78c <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x753, 0x78c, x86_l_78c);
x86_l_755:
	/* 0x755: cmp    r9,0xffffffffffffff81 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551489ULL);
x86_l_759:
	/* 0x759: je     78c <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x759, 0x78c, x86_l_78c);
x86_l_75b:
	/* 0x75b: lea    r10d,[rdx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_75f:
	/* 0x75f: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_763:
	/* 0x763: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_76a:
	/* 0x76a: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_76f:
	/* 0x76f: mov    BYTE PTR [rsi],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_772:
	/* 0x772: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_776:
	/* 0x776: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_77a:
	/* 0x77a: add    r10,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_77e:
	/* 0x77e: add    r9,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_782:
	/* 0x782: cmp    r10,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_786:
	/* 0x786: jne    6f5 <filter_char_buf_postfix+0x88> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x786, 0x6f5, x86_l_6f5);
x86_l_78c:
	/* 0x78c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_78f:
	/* 0x78f: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_792:
	/* 0x792: call   2ebf <filter_char_buf_prefix+0x270f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_797:
	/* 0x797: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79a:
	/* 0x79a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_79c:
	/* 0x79c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_79f:
	/* 0x79f: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_7a2:
	/* 0x7a2: jmp    7a6 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JMP(0x7a2, 0x7a6, x86_l_7a6);
x86_l_7a4:
	/* 0x7a4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7a6:
	/* 0x7a6: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7aa:
	/* 0x7aa: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_7ab:
	/* 0x7ab: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_7ad:
	/* 0x7ad: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_7af:
	/* 0x7af: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_7af);

	/* native subroutine native_link_sub_7b0 */
x86_l_7b0:
	/* 0x7b0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_7b1:
	/* 0x7b1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7b3:
	/* 0x7b3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_7b5:
	/* 0x7b5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7b6:
	/* 0x7b6: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b7:
	/* 0x7b7: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_7b9:
	/* 0x7b9: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_7bc:
	/* 0x7bc: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7c0:
	/* 0x7c0: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c7:
	/* 0x7c7: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps));
x86_l_7ce:
	/* 0x7ce: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7d3:
	/* 0x7d3: call   2dc8 <filter_char_buf_prefix+0x2618> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7d8:
	/* 0x7d8: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7db:
	/* 0x7db: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7dd:
	/* 0x7dd: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_7df:
	/* 0x7df: je     8c8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7df, 0x8c8, x86_l_8c8);
x86_l_7e5:
	/* 0x7e5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7e8:
	/* 0x7e8: je     8c8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7e8, 0x8c8, x86_l_8c8);
x86_l_7ee:
	/* 0x7ee: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_7f5:
	/* 0x7f5: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_7f8:
	/* 0x7f8: call   2ded <filter_char_buf_prefix+0x263d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7fd:
	/* 0x7fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_800:
	/* 0x800: je     863 <filter_char_buf_prefix+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x800, 0x863, x86_l_863);
x86_l_802:
	/* 0x802: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_805:
	/* 0x805: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_807:
	/* 0x807: cmp    ebp,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_80d:
	/* 0x80d: jb     814 <filter_char_buf_prefix+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x80d, 0x814, x86_l_814);
x86_l_80f:
	/* 0x80f: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_814:
	/* 0x814: lea    ecx,[rsi*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_81b:
	/* 0x81b: mov    DWORD PTR [r15],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_81e:
	/* 0x81e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_822:
	/* 0x822: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_825:
	/* 0x825: jns    867 <filter_char_buf_prefix+0xb7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x825, 0x867, x86_l_867);
x86_l_827:
	/* 0x827: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_82a:
	/* 0x82a: jns    874 <filter_char_buf_prefix+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x82a, 0x874, x86_l_874);
x86_l_82c:
	/* 0x82c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82e:
	/* 0x82e: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_831:
	/* 0x831: jb     84f <filter_char_buf_prefix+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x831, 0x84f, x86_l_84f);
x86_l_833:
	/* 0x833: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_835:
	/* 0x835: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_837:
	/* 0x837: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_83a:
	/* 0x83a: mov    rcx,QWORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_83e:
	/* 0x83e: mov    QWORD PTR [rax+rdi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_842:
	/* 0x842: lea    rcx,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_846:
	/* 0x846: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_84a:
	/* 0x84a: cmp    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_84d:
	/* 0x84d: jbe    837 <filter_char_buf_prefix+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x84d, 0x837, x86_l_837);
x86_l_84f:
	/* 0x84f: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_853:
	/* 0x853: jne    882 <filter_char_buf_prefix+0xd2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x853, 0x882, x86_l_882);
x86_l_855:
	/* 0x855: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_859:
	/* 0x859: jne    894 <filter_char_buf_prefix+0xe4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x859, 0x894, x86_l_894);
x86_l_85b:
	/* 0x85b: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_85f:
	/* 0x85f: jne    8a8 <filter_char_buf_prefix+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x85f, 0x8a8, x86_l_8a8);
x86_l_861:
	/* 0x861: jmp    8b2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x861, 0x8b2, x86_l_8b2);
x86_l_863:
	/* 0x863: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_865:
	/* 0x865: jmp    8c8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JMP(0x865, 0x8c8, x86_l_8c8);
x86_l_867:
	/* 0x867: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86a:
	/* 0x86a: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_86d:
	/* 0x86d: call   2e6b <filter_char_buf_prefix+0x26bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_872:
	/* 0x872: jmp    8b2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x872, 0x8b2, x86_l_8b2);
x86_l_874:
	/* 0x874: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_876:
	/* 0x876: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_879:
	/* 0x879: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_87b:
	/* 0x87b: call   2e79 <filter_char_buf_prefix+0x26c9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_880:
	/* 0x880: jmp    8b2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x880, 0x8b2, x86_l_8b2);
x86_l_882:
	/* 0x882: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_884:
	/* 0x884: mov    edi,DWORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_888:
	/* 0x888: mov    DWORD PTR [rax+rdx*1],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_88b:
	/* 0x88b: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_88e:
	/* 0x88e: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_892:
	/* 0x892: je     85b <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x892, 0x85b, x86_l_85b);
x86_l_894:
	/* 0x894: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_896:
	/* 0x896: movzx  edi,WORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_89b:
	/* 0x89b: mov    WORD PTR [rax+rdx*1],di */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_89f:
	/* 0x89f: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_8a2:
	/* 0x8a2: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_8a6:
	/* 0x8a6: je     8b2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8a6, 0x8b2, x86_l_8b2);
x86_l_8a8:
	/* 0x8a8: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_8aa:
	/* 0x8aa: movzx  edx,BYTE PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_8af:
	/* 0x8af: mov    BYTE PTR [rax+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_8b2:
	/* 0x8b2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_8b5:
	/* 0x8b5: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_8b8:
	/* 0x8b8: call   2eb6 <filter_char_buf_prefix+0x2706> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8bd:
	/* 0x8bd: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c0:
	/* 0x8c0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8c2:
	/* 0x8c2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8c5:
	/* 0x8c5: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_8c8:
	/* 0x8c8: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_8cc:
	/* 0x8cc: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8cd:
	/* 0x8cd: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8cf:
	/* 0x8cf: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8d1:
	/* 0x8d1: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8d2:
	/* 0x8d2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8d2);

x86_sim_ret_dispatch_17b:
	switch (__x86_sim_ret_addr) {
	case 0x54ULL: goto x86_l_54;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_578:
	switch (__x86_sim_ret_addr) {
	case 0x72ULL: goto x86_l_72;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_7af:
	switch (__x86_sim_ret_addr) {
	case 0x88ULL: goto x86_l_88;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_8d2:
	switch (__x86_sim_ret_addr) {
	case 0x9eULL: goto x86_l_9e;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
