#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2)
#include "../x86_sim_local_bpf.h"

extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 signal_data_map[] __ksym;
extern __u8 signals[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/cgroup_mkdir_signal")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: sub    rsp,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 32ULL);
x86_l_d:
	/* 0xd: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: mov    DWORD PTR [rsp+0x1c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_18:
	/* 0x18: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_1f:
	/* 0x1f: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24:
	/* 0x24: call   29 <cgroup_mkdir_signal+0x29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_29:
	/* 0x29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c:
	/* 0x2c: je     2fd <cgroup_mkdir_signal+0x2fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c, 0x2fd, x86_l_2fd);
x86_l_32:
	/* 0x32: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35:
	/* 0x35: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3d:
	/* 0x3d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signal_data_map));
x86_l_44:
	/* 0x44: lea    r12,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49:
	/* 0x49: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4c:
	/* 0x4c: call   51 <cgroup_mkdir_signal+0x51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_51:
	/* 0x51: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54:
	/* 0x54: je     2fd <cgroup_mkdir_signal+0x2fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54, 0x2fd, x86_l_2fd);
x86_l_5a:
	/* 0x5a: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d:
	/* 0x5d: mov    DWORD PTR [rax],0x1388 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5000ULL);
x86_l_63:
	/* 0x63: mov    BYTE PTR [rax+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_67:
	/* 0x67: mov    WORD PTR [rax+0x7d06],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 137464723275776ULL);
x86_l_70:
	/* 0x70: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_73:
	/* 0x73: mov    r15,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_77:
	/* 0x77: lea    rdx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7b:
	/* 0x7b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d:
	/* 0x7d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_80:
	/* 0x80: jns    8c <cgroup_mkdir_signal+0x8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x80, 0x8c, x86_l_8c);
x86_l_82:
	/* 0x82: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85:
	/* 0x85: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_88:
	/* 0x88: js     93 <cgroup_mkdir_signal+0x93> */
	X86_SIM_X86_JCC(X86_CC_S, 0x88, 0x93, x86_l_93);
x86_l_8a:
	/* 0x8a: jmp    95 <cgroup_mkdir_signal+0x95> */
	X86_SIM_X86_JMP(0x8a, 0x95, x86_l_95);
x86_l_8c:
	/* 0x8c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8e:
	/* 0x8e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_91:
	/* 0x91: jns    95 <cgroup_mkdir_signal+0x95> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x91, 0x95, x86_l_95);
x86_l_93:
	/* 0x93: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95:
	/* 0x95: mov    DWORD PTR [rsp+0xc],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_99:
	/* 0x99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c:
	/* 0x9c: jns    c4 <cgroup_mkdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9c, 0xc4, x86_l_c4);
x86_l_9e:
	/* 0x9e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a1:
	/* 0xa1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a4:
	/* 0xa4: je     c4 <cgroup_mkdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa4, 0xc4, x86_l_c4);
x86_l_a6:
	/* 0xa6: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_aa:
	/* 0xaa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad:
	/* 0xad: jns    c4 <cgroup_mkdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xad, 0xc4, x86_l_c4);
x86_l_af:
	/* 0xaf: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b2:
	/* 0xb2: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b7:
	/* 0xb7: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_bb:
	/* 0xbb: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_c0:
	/* 0xc0: jne    d6 <cgroup_mkdir_signal+0xd6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc0, 0xd6, x86_l_d6);
x86_l_c2:
	/* 0xc2: jmp    e0 <cgroup_mkdir_signal+0xe0> */
	X86_SIM_X86_JMP(0xc2, 0xe0, x86_l_e0);
x86_l_c4:
	/* 0xc4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c6:
	/* 0xc6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cb:
	/* 0xcb: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_cf:
	/* 0xcf: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_d4:
	/* 0xd4: je     e0 <cgroup_mkdir_signal+0xe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd4, 0xe0, x86_l_e0);
x86_l_d6:
	/* 0xd6: mov    eax,DWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da:
	/* 0xda: cmp    eax,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 12ULL);
x86_l_de:
	/* 0xde: jne    fd <cgroup_mkdir_signal+0xfd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xde, 0xfd, x86_l_fd);
x86_l_e0:
	/* 0xe0: mov    BYTE PTR [rsp+0xb],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 47244640258ULL);
x86_l_e5:
	/* 0xe5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_ec:
	/* 0xec: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f1:
	/* 0xf1: lea    rdx,[rsp+0xb] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 11ULL);
x86_l_f6:
	/* 0xf6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8:
	/* 0xf8: call   fd <cgroup_mkdir_signal+0xfd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_fd:
	/* 0xfd: movzx  r13d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_105:
	/* 0x105: cmp    r13,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_10c:
	/* 0x10c: ja     26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10c, 0x26a, x86_l_26a);
x86_l_112:
	/* 0x112: mov    BYTE PTR [r14+r13*1+0x5],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R13, 0), 21474836480ULL);
x86_l_118:
	/* 0x118: cmp    r13d,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_11f:
	/* 0x11f: jbe    139 <cgroup_mkdir_signal+0x139> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x11f, 0x139, x86_l_139);
x86_l_121:
	/* 0x121: movzx  r13d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_129:
	/* 0x129: movzx  eax,r13w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_R13, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_12d:
	/* 0x12d: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_132:
	/* 0x132: jbe    18f <cgroup_mkdir_signal+0x18f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x132, 0x18f, x86_l_18f);
x86_l_134:
	/* 0x134: jmp    26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JMP(0x134, 0x26a, x86_l_26a);
x86_l_139:
	/* 0x139: lea    rdi,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_13d:
	/* 0x13d: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_141:
	/* 0x141: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_144:
	/* 0x144: jns    15c <cgroup_mkdir_signal+0x15c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x144, 0x15c, x86_l_15c);
x86_l_146:
	/* 0x146: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14b:
	/* 0x14b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e:
	/* 0x14e: jns    209 <cgroup_mkdir_signal+0x209> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14e, 0x209, x86_l_209);
x86_l_154:
	/* 0x154: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_157:
	/* 0x157: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15a:
	/* 0x15a: jmp    170 <cgroup_mkdir_signal+0x170> */
	X86_SIM_X86_JMP(0x15a, 0x170, x86_l_170);
x86_l_15c:
	/* 0x15c: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_161:
	/* 0x161: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_166:
	/* 0x166: call   16b <cgroup_mkdir_signal+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_16b:
	/* 0x16b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: js     121 <cgroup_mkdir_signal+0x121> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16e, 0x121, x86_l_121);
x86_l_170:
	/* 0x170: add    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_174:
	/* 0x174: mov    WORD PTR [r14+0x7d06],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_17c:
	/* 0x17c: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_180:
	/* 0x180: movzx  eax,r13w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_R13, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_184:
	/* 0x184: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_189:
	/* 0x189: ja     26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x189, 0x26a, x86_l_26a);
x86_l_18f:
	/* 0x18f: mov    BYTE PTR [r14+rax*1+0x5],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 21474836481ULL);
x86_l_195:
	/* 0x195: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_19d:
	/* 0x19d: mov    WORD PTR [r14+0x7d0a],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32010ULL);
x86_l_1a5:
	/* 0x1a5: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1ab:
	/* 0x1ab: ja     26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ab, 0x26a, x86_l_26a);
x86_l_1b1:
	/* 0x1b1: lea    rdi,[rax+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1b5:
	/* 0x1b5: add    rdi,0xa */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 10ULL);
x86_l_1b9:
	/* 0x1b9: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1bc:
	/* 0x1bc: js     215 <cgroup_mkdir_signal+0x215> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bc, 0x215, x86_l_215);
x86_l_1be:
	/* 0x1be: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1c3:
	/* 0x1c3: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c6:
	/* 0x1c6: call   1cb <cgroup_mkdir_signal+0x1cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1cb:
	/* 0x1cb: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ce:
	/* 0x1ce: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d0:
	/* 0x1d0: jle    26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1d0, 0x26a, x86_l_26a);
x86_l_1d6:
	/* 0x1d6: movzx  edx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_1de:
	/* 0x1de: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1e5:
	/* 0x1e5: ja     26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1e5, 0x26a, x86_l_26a);
x86_l_1eb:
	/* 0x1eb: mov    DWORD PTR [rdx+r14*1+0x6],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 6ULL);
x86_l_1f0:
	/* 0x1f0: add    cx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32006ULL);
x86_l_1f8:
	/* 0x1f8: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1fb:
	/* 0x1fb: mov    WORD PTR [r14+0x7d06],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_203:
	/* 0x203: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_207:
	/* 0x207: jmp    26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JMP(0x207, 0x26a, x86_l_26a);
x86_l_209:
	/* 0x209: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_210:
	/* 0x210: jmp    121 <cgroup_mkdir_signal+0x121> */
	X86_SIM_X86_JMP(0x210, 0x121, x86_l_121);
x86_l_215:
	/* 0x215: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_218:
	/* 0x218: jns    23a <cgroup_mkdir_signal+0x23a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x218, 0x23a, x86_l_23a);
x86_l_21a:
	/* 0x21a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21c:
	/* 0x21c: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_223:
	/* 0x223: je     248 <cgroup_mkdir_signal+0x248> */
	X86_SIM_X86_JCC(X86_CC_E, 0x223, 0x248, x86_l_248);
x86_l_225:
	/* 0x225: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_229:
	/* 0x229: movzx  edx,BYTE PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_22e:
	/* 0x22e: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_231:
	/* 0x231: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_234:
	/* 0x234: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_236:
	/* 0x236: jne    21c <cgroup_mkdir_signal+0x21c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x236, 0x21c, x86_l_21c);
x86_l_238:
	/* 0x238: jmp    1cb <cgroup_mkdir_signal+0x1cb> */
	X86_SIM_X86_JMP(0x238, 0x1cb, x86_l_1cb);
x86_l_23a:
	/* 0x23a: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_23f:
	/* 0x23f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_241:
	/* 0x241: call   246 <cgroup_mkdir_signal+0x246> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_246:
	/* 0x246: jmp    26a <cgroup_mkdir_signal+0x26a> */
	X86_SIM_X86_JMP(0x246, 0x26a, x86_l_26a);
x86_l_248:
	/* 0x248: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_24f:
	/* 0x24f: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_254:
	/* 0x254: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_259:
	/* 0x259: movzx  edx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_261:
	/* 0x261: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_268:
	/* 0x268: jbe    1eb <cgroup_mkdir_signal+0x1eb> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x268, 0x1eb, x86_l_1eb);
x86_l_26a:
	/* 0x26a: movzx  r15d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_272:
	/* 0x272: cmp    r15,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_279:
	/* 0x279: ja     2cb <cgroup_mkdir_signal+0x2cb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x279, 0x2cb, x86_l_2cb);
x86_l_27b:
	/* 0x27b: mov    BYTE PTR [r14+r15*1+0x5],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 21474836482ULL);
x86_l_281:
	/* 0x281: cmp    r15d,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_288:
	/* 0x288: ja     2cb <cgroup_mkdir_signal+0x2cb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x288, 0x2cb, x86_l_2cb);
x86_l_28a:
	/* 0x28a: lea    rdi,[r15+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_28e:
	/* 0x28e: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_292:
	/* 0x292: lea    rax,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_297:
	/* 0x297: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: jns    2a7 <cgroup_mkdir_signal+0x2a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29a, 0x2a7, x86_l_2a7);
x86_l_29c:
	/* 0x29c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29f:
	/* 0x29f: jns    311 <cgroup_mkdir_signal+0x311> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f, 0x311, x86_l_311);
x86_l_2a1:
	/* 0x2a1: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a3:
	/* 0x2a3: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a5:
	/* 0x2a5: jmp    2bb <cgroup_mkdir_signal+0x2bb> */
	X86_SIM_X86_JMP(0x2a5, 0x2bb, x86_l_2bb);
x86_l_2a7:
	/* 0x2a7: lea    rdx,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2ac:
	/* 0x2ac: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2b1:
	/* 0x2b1: call   2b6 <cgroup_mkdir_signal+0x2b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b6:
	/* 0x2b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b9:
	/* 0x2b9: js     2cb <cgroup_mkdir_signal+0x2cb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b9, 0x2cb, x86_l_2cb);
x86_l_2bb:
	/* 0x2bb: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2bf:
	/* 0x2bf: mov    WORD PTR [r14+0x7d06],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_2c7:
	/* 0x2c7: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_2cb:
	/* 0x2cb: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_2d3:
	/* 0x2d3: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2d8:
	/* 0x2d8: jb     2df <cgroup_mkdir_signal+0x2df> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d8, 0x2df, x86_l_2df);
x86_l_2da:
	/* 0x2da: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2df:
	/* 0x2df: add    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e2:
	/* 0x2e2: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2e6:
	/* 0x2e6: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signals));
x86_l_2ed:
	/* 0x2ed: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2f2:
	/* 0x2f2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2f5:
	/* 0x2f5: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2f8:
	/* 0x2f8: call   2fd <cgroup_mkdir_signal+0x2fd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2fd:
	/* 0x2fd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ff:
	/* 0x2ff: add    rsp,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_303:
	/* 0x303: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_304:
	/* 0x304: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_306:
	/* 0x306: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_308:
	/* 0x308: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30c:
	/* 0x30c: jmp    328 <cgroup_mkdir_signal+0x328> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_311:
	/* 0x311: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_317:
	/* 0x317: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_31f:
	/* 0x31f: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_324:
	/* 0x324: jae    2da <cgroup_mkdir_signal+0x2da> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x324, 0x2da, x86_l_2da);
x86_l_326:
	/* 0x326: jmp    2df <cgroup_mkdir_signal+0x2df> */
	X86_SIM_X86_JMP(0x326, 0x2df, x86_l_2df);
x86_l_328:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
