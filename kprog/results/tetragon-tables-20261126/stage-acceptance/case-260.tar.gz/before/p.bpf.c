#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 312U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(19) M(21) M(22) M(23) M(24) M(26) M(27) M(28) M(29) M(30) M(31) M(32)
#include "../x86_sim_local_bpf.h"

extern __u8 args_map[] __ksym;
extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kretprobe/do_mmap")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 264ULL);
x86_l_11:
	/* 0x11: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: call   19 <trace_ret_do_mmap+0x19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_19:
	/* 0x19: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b:
	/* 0x1b: movabs rcx,0x30400000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 3315714752512ULL);
x86_l_25:
	/* 0x25: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_28:
	/* 0x28: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2d:
	/* 0x2d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)args_map));
x86_l_34:
	/* 0x34: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_39:
	/* 0x39: call   3e <trace_ret_do_mmap+0x3e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e:
	/* 0x3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41:
	/* 0x41: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41, 0x142e, x86_l_142e);
x86_l_47:
	/* 0x47: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a:
	/* 0x4a: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4f:
	/* 0x4f: mov    rbx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53:
	/* 0x53: mov    r14,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_57:
	/* 0x57: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5b:
	/* 0x5b: mov    QWORD PTR [rsp+0x100],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_63:
	/* 0x63: mov    rax,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_67:
	/* 0x67: mov    QWORD PTR [rsp+0xf8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_6f:
	/* 0x6f: mov    DWORD PTR [rsp+0xb8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 790273982464ULL);
x86_l_7a:
	/* 0x7a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_81:
	/* 0x81: lea    rsi,[rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_89:
	/* 0x89: call   8e <trace_ret_do_mmap+0x8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8e:
	/* 0x8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_91:
	/* 0x91: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91, 0x142e, x86_l_142e);
x86_l_97:
	/* 0x97: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9a:
	/* 0x9a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_a1:
	/* 0xa1: lea    rsi,[rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_a9:
	/* 0xa9: call   ae <trace_ret_do_mmap+0xae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae:
	/* 0xae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1:
	/* 0xb1: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb1, 0x142e, x86_l_142e);
x86_l_b7:
	/* 0xb7: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba:
	/* 0xba: mov    QWORD PTR [rsp+0xe8],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_c2:
	/* 0xc2: mov    QWORD PTR [rsp+0xf0],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_ca:
	/* 0xca: mov    r14,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_cd:
	/* 0xcd: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_d6:
	/* 0xd6: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_dd:
	/* 0xdd: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_e8:
	/* 0xe8: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_f3:
	/* 0xf3: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_109:
	/* 0x109: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_114:
	/* 0x114: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_11f:
	/* 0x11f: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_12a:
	/* 0x12a: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_135:
	/* 0x135: call   13a <trace_ret_do_mmap+0x13a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_13a:
	/* 0x13a: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_141:
	/* 0x141: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_149:
	/* 0x149: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_151:
	/* 0x151: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_161:
	/* 0x161: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_169:
	/* 0x169: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_171:
	/* 0x171: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_179:
	/* 0x179: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_181:
	/* 0x181: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_189:
	/* 0x189: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_191:
	/* 0x191: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_199:
	/* 0x199: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1a1:
	/* 0x1a1: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1a9:
	/* 0x1a9: call   1ae <trace_ret_do_mmap+0x1ae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1ae:
	/* 0x1ae: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b1:
	/* 0x1b1: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b5:
	/* 0x1b5: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b8:
	/* 0x1b8: mov    DWORD PTR [rbp+0x70],0x304 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337924ULL);
x86_l_1bf:
	/* 0x1bf: call   1c4 <trace_ret_do_mmap+0x1c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_1c4:
	/* 0x1c4: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c8:
	/* 0x1c8: call   1cd <trace_ret_do_mmap+0x1cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_1cd:
	/* 0x1cd: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_1d1:
	/* 0x1d1: call   1d6 <trace_ret_do_mmap+0x1d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_1d6:
	/* 0x1d6: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d9:
	/* 0x1d9: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1dd:
	/* 0x1dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e0:
	/* 0x1e0: jns    1f1 <trace_ret_do_mmap+0x1f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e0, 0x1f1, x86_l_1f1);
x86_l_1e2:
	/* 0x1e2: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e4:
	/* 0x1e4: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1e9:
	/* 0x1e9: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_1ef:
	/* 0x1ef: jne    22e <trace_ret_do_mmap+0x22e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ef, 0x22e, x86_l_22e);
x86_l_1f1:
	/* 0x1f1: call   1f6 <trace_ret_do_mmap+0x1f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_1f6:
	/* 0x1f6: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f9:
	/* 0x1f9: call   1fe <trace_ret_do_mmap+0x1fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_1fe:
	/* 0x1fe: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_202:
	/* 0x202: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_205:
	/* 0x205: jns    215 <trace_ret_do_mmap+0x215> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x205, 0x215, x86_l_215);
x86_l_207:
	/* 0x207: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a:
	/* 0x20a: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_20e:
	/* 0x20e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_211:
	/* 0x211: js     220 <trace_ret_do_mmap+0x220> */
	X86_SIM_X86_JCC(X86_CC_S, 0x211, 0x220, x86_l_220);
x86_l_213:
	/* 0x213: jmp    22a <trace_ret_do_mmap+0x22a> */
	X86_SIM_X86_JMP(0x213, 0x22a, x86_l_22a);
x86_l_215:
	/* 0x215: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_217:
	/* 0x217: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_21b:
	/* 0x21b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21e:
	/* 0x21e: jns    22a <trace_ret_do_mmap+0x22a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21e, 0x22a, x86_l_22a);
x86_l_220:
	/* 0x220: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222:
	/* 0x222: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_224:
	/* 0x224: jne    5c1 <trace_ret_do_mmap+0x5c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x224, 0x5c1, x86_l_5c1);
x86_l_22a:
	/* 0x22a: mov    eax,DWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_22e:
	/* 0x22e: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_232:
	/* 0x232: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_236:
	/* 0x236: mov    DWORD PTR [rsp+0xb0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_23d:
	/* 0x23d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_244:
	/* 0x244: lea    rsi,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_24c:
	/* 0x24c: call   251 <trace_ret_do_mmap+0x251> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_251:
	/* 0x251: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_259:
	/* 0x259: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25c:
	/* 0x25c: je     1313 <trace_ret_do_mmap+0x1313> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c, 0x1313, x86_l_1313);
x86_l_262:
	/* 0x262: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_266:
	/* 0x266: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_26d:
	/* 0x26d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_274:
	/* 0x274: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_27c:
	/* 0x27c: call   281 <trace_ret_do_mmap+0x281> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_281:
	/* 0x281: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_284:
	/* 0x284: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_287:
	/* 0x287: mov    QWORD PTR [rsp+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28c:
	/* 0x28c: mov    QWORD PTR [rsp+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_291:
	/* 0x291: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_294:
	/* 0x294: mov    QWORD PTR [rsp+0x30],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_299:
	/* 0x299: mov    QWORD PTR [rsp+0x38],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29e:
	/* 0x29e: je     1399 <trace_ret_do_mmap+0x1399> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29e, 0x1399, x86_l_1399);
x86_l_2a4:
	/* 0x2a4: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_2aa:
	/* 0x2aa: jne    2b3 <trace_ret_do_mmap+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aa, 0x2b3, x86_l_2b3);
x86_l_2ac:
	/* 0x2ac: call   2b1 <trace_ret_do_mmap+0x2b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_2b1:
	/* 0x2b1: jmp    30b <trace_ret_do_mmap+0x30b> */
	X86_SIM_X86_JMP(0x2b1, 0x30b, x86_l_30b);
x86_l_2b3:
	/* 0x2b3: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2b8:
	/* 0x2b8: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_2bf:
	/* 0x2bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c2:
	/* 0x2c2: jns    2dc <trace_ret_do_mmap+0x2dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c2, 0x2dc, x86_l_2dc);
x86_l_2c4:
	/* 0x2c4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c7:
	/* 0x2c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ca:
	/* 0x2ca: js     2e3 <trace_ret_do_mmap+0x2e3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ca, 0x2e3, x86_l_2e3);
x86_l_2cc:
	/* 0x2cc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ce:
	/* 0x2ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d1:
	/* 0x2d1: js     2eb <trace_ret_do_mmap+0x2eb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d1, 0x2eb, x86_l_2eb);
x86_l_2d3:
	/* 0x2d3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d5:
	/* 0x2d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d8:
	/* 0x2d8: js     2f3 <trace_ret_do_mmap+0x2f3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d8, 0x2f3, x86_l_2f3);
x86_l_2da:
	/* 0x2da: jmp    309 <trace_ret_do_mmap+0x309> */
	X86_SIM_X86_JMP(0x2da, 0x309, x86_l_309);
x86_l_2dc:
	/* 0x2dc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2de:
	/* 0x2de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e1:
	/* 0x2e1: jns    2cc <trace_ret_do_mmap+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1, 0x2cc, x86_l_2cc);
x86_l_2e3:
	/* 0x2e3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e6:
	/* 0x2e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e9:
	/* 0x2e9: jns    2d3 <trace_ret_do_mmap+0x2d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e9, 0x2d3, x86_l_2d3);
x86_l_2eb:
	/* 0x2eb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee:
	/* 0x2ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f1:
	/* 0x2f1: jns    309 <trace_ret_do_mmap+0x309> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f1, 0x309, x86_l_309);
x86_l_2f3:
	/* 0x2f3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f6:
	/* 0x2f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: je     309 <trace_ret_do_mmap+0x309> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f9, 0x309, x86_l_309);
x86_l_2fb:
	/* 0x2fb: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ff:
	/* 0x2ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_302:
	/* 0x302: jns    309 <trace_ret_do_mmap+0x309> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x302, 0x309, x86_l_309);
x86_l_304:
	/* 0x304: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307:
	/* 0x307: jmp    30b <trace_ret_do_mmap+0x30b> */
	X86_SIM_X86_JMP(0x307, 0x30b, x86_l_30b);
x86_l_309:
	/* 0x309: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30b:
	/* 0x30b: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30f:
	/* 0x30f: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_313:
	/* 0x313: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_317:
	/* 0x317: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_31e:
	/* 0x31e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_323:
	/* 0x323: call   328 <trace_ret_do_mmap+0x328> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_328:
	/* 0x328: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32b:
	/* 0x32b: je     343 <trace_ret_do_mmap+0x343> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32b, 0x343, x86_l_343);
x86_l_32d:
	/* 0x32d: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_330:
	/* 0x330: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_336:
	/* 0x336: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_339:
	/* 0x339: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_33c:
	/* 0x33c: jne    343 <trace_ret_do_mmap+0x343> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33c, 0x343, x86_l_343);
x86_l_33e:
	/* 0x33e: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_343:
	/* 0x343: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_348:
	/* 0x348: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_34e:
	/* 0x34e: jne    1435 <trace_ret_do_mmap+0x1435> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34e, 0x1435, x86_l_1435);
x86_l_354:
	/* 0x354: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_35f:
	/* 0x35f: mov    DWORD PTR [rsp+0x50],0x304 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597384452ULL);
x86_l_367:
	/* 0x367: mov    WORD PTR [rsp+0x48],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_36c:
	/* 0x36c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_373:
	/* 0x373: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_378:
	/* 0x378: call   37d <trace_ret_do_mmap+0x37d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_37d:
	/* 0x37d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_380:
	/* 0x380: je     3eb <trace_ret_do_mmap+0x3eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x380, 0x3eb, x86_l_3eb);
x86_l_382:
	/* 0x382: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_387:
	/* 0x387: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38a:
	/* 0x38a: call   38f <trace_ret_do_mmap+0x38f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_38f:
	/* 0x38f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_392:
	/* 0x392: je     3eb <trace_ret_do_mmap+0x3eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x392, 0x3eb, x86_l_3eb);
x86_l_394:
	/* 0x394: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_398:
	/* 0x398: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_39f:
	/* 0x39f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a2:
	/* 0x3a2: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_3a9:
	/* 0x3a9: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ad:
	/* 0x3ad: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b1:
	/* 0x3b1: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_3b8:
	/* 0x3b8: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_3bf:
	/* 0x3bf: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3c3:
	/* 0x3c3: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_3ca:
	/* 0x3ca: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3ce:
	/* 0x3ce: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_3d5:
	/* 0x3d5: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3d9:
	/* 0x3d9: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_3e0:
	/* 0x3e0: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3e4:
	/* 0x3e4: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_3eb:
	/* 0x3eb: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_3f2:
	/* 0x3f2: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3f9:
	/* 0x3f9: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fd:
	/* 0x3fd: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_401:
	/* 0x401: mov    QWORD PTR [rsp+0x28],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_406:
	/* 0x406: jne    422 <trace_ret_do_mmap+0x422> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x406, 0x422, x86_l_422);
x86_l_408:
	/* 0x408: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_40b:
	/* 0x40b: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_40d:
	/* 0x40d: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_410:
	/* 0x410: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_417:
	/* 0x417: jne    cce <trace_ret_do_mmap+0xcce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x417, 0xcce, x86_l_cce);
x86_l_41d:
	/* 0x41d: jmp    3718 <trace_ret_do_mmap+0x3718> */
	X86_SIM_X86_JMP(0x41d, 0x3718, x86_l_3718);
x86_l_422:
	/* 0x422: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_429:
	/* 0x429: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42c:
	/* 0x42c: je     5e2 <trace_ret_do_mmap+0x5e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42c, 0x5e2, x86_l_5e2);
x86_l_432:
	/* 0x432: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_439:
	/* 0x439: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_43c:
	/* 0x43c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_43f:
	/* 0x43f: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_442:
	/* 0x442: sete   r12b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_446:
	/* 0x446: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_449:
	/* 0x449: neg    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_44c:
	/* 0x44c: xor    r12,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_453:
	/* 0x453: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_456:
	/* 0x456: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_45d:
	/* 0x45d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_460:
	/* 0x460: je     481 <trace_ret_do_mmap+0x481> */
	X86_SIM_X86_JCC(X86_CC_E, 0x460, 0x481, x86_l_481);
x86_l_462:
	/* 0x462: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_464:
	/* 0x464: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_46b:
	/* 0x46b: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_46e:
	/* 0x46e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_471:
	/* 0x471: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_474:
	/* 0x474: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_47b:
	/* 0x47b: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_47e:
	/* 0x47e: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_481:
	/* 0x481: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_488:
	/* 0x488: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_48b:
	/* 0x48b: je     4a7 <trace_ret_do_mmap+0x4a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48b, 0x4a7, x86_l_4a7);
x86_l_48d:
	/* 0x48d: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_491:
	/* 0x491: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_494:
	/* 0x494: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_497:
	/* 0x497: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_49a:
	/* 0x49a: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_4a1:
	/* 0x4a1: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4a4:
	/* 0x4a4: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4a7:
	/* 0x4a7: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_4ae:
	/* 0x4ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b1:
	/* 0x4b1: je     4d2 <trace_ret_do_mmap+0x4d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b1, 0x4d2, x86_l_4d2);
x86_l_4b3:
	/* 0x4b3: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4b6:
	/* 0x4b6: mov    rcx,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_4be:
	/* 0x4be: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4c2:
	/* 0x4c2: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4c5:
	/* 0x4c5: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_4cc:
	/* 0x4cc: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4cf:
	/* 0x4cf: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4d2:
	/* 0x4d2: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_4d7:
	/* 0x4d7: mov    r13,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_4de:
	/* 0x4de: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4e1:
	/* 0x4e1: mov    WORD PTR [rsp+0x8],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4e6:
	/* 0x4e6: je     64a <trace_ret_do_mmap+0x64a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e6, 0x64a, x86_l_64a);
x86_l_4ec:
	/* 0x4ec: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_4f3:
	/* 0x4f3: mov    QWORD PTR [rsp+0xe0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_4fb:
	/* 0x4fb: mov    rbp,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_502:
	/* 0x502: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_509:
	/* 0x509: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_511:
	/* 0x511: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_516:
	/* 0x516: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_51d:
	/* 0x51d: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_522:
	/* 0x522: call   527 <trace_ret_do_mmap+0x527> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_527:
	/* 0x527: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52a:
	/* 0x52a: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_52e:
	/* 0x52e: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_533:
	/* 0x533: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_53a:
	/* 0x53a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_53d:
	/* 0x53d: je     55d <trace_ret_do_mmap+0x55d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53d, 0x55d, x86_l_55d);
x86_l_53f:
	/* 0x53f: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_544:
	/* 0x544: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_547:
	/* 0x547: call   54c <trace_ret_do_mmap+0x54c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54c:
	/* 0x54c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54f:
	/* 0x54f: je     55d <trace_ret_do_mmap+0x55d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54f, 0x55d, x86_l_55d);
x86_l_551:
	/* 0x551: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_554:
	/* 0x554: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_558:
	/* 0x558: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_55b:
	/* 0x55b: jmp    55f <trace_ret_do_mmap+0x55f> */
	X86_SIM_X86_JMP(0x55b, 0x55f, x86_l_55f);
x86_l_55d:
	/* 0x55d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_55f:
	/* 0x55f: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_567:
	/* 0x567: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_56c:
	/* 0x56c: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_56f:
	/* 0x56f: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_572:
	/* 0x572: jb     58a <trace_ret_do_mmap+0x58a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x572, 0x58a, x86_l_58a);
x86_l_574:
	/* 0x574: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_578:
	/* 0x578: je     57f <trace_ret_do_mmap+0x57f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x578, 0x57f, x86_l_57f);
x86_l_57a:
	/* 0x57a: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_57d:
	/* 0x57d: jbe    58a <trace_ret_do_mmap+0x58a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x57d, 0x58a, x86_l_58a);
x86_l_57f:
	/* 0x57f: and    r14,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 224ULL);
x86_l_587:
	/* 0x587: or     rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_58a:
	/* 0x58a: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_58f:
	/* 0x58f: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_592:
	/* 0x592: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_597:
	/* 0x597: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_59e:
	/* 0x59e: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5a1:
	/* 0x5a1: je     5fe <trace_ret_do_mmap+0x5fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a1, 0x5fe, x86_l_5fe);
x86_l_5a3:
	/* 0x5a3: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5a8:
	/* 0x5a8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5ab:
	/* 0x5ab: call   5b0 <trace_ret_do_mmap+0x5b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b0:
	/* 0x5b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b3:
	/* 0x5b3: je     60f <trace_ret_do_mmap+0x60f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b3, 0x60f, x86_l_60f);
x86_l_5b5:
	/* 0x5b5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b8:
	/* 0x5b8: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5bc:
	/* 0x5bc: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5bf:
	/* 0x5bf: jmp    611 <trace_ret_do_mmap+0x611> */
	X86_SIM_X86_JMP(0x5bf, 0x611, x86_l_611);
x86_l_5c1:
	/* 0x5c1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_5c8:
	/* 0x5c8: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5cd:
	/* 0x5cd: call   5d2 <trace_ret_do_mmap+0x5d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5d2:
	/* 0x5d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d5:
	/* 0x5d5: je     e9f <trace_ret_do_mmap+0xe9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d5, 0xe9f, x86_l_e9f);
x86_l_5db:
	/* 0x5db: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5dd:
	/* 0x5dd: jmp    22e <trace_ret_do_mmap+0x22e> */
	X86_SIM_X86_JMP(0x5dd, 0x22e, x86_l_22e);
x86_l_5e2:
	/* 0x5e2: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5e9:
	/* 0x5e9: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_5f0:
	/* 0x5f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f3:
	/* 0x5f3: jne    462 <trace_ret_do_mmap+0x462> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5f3, 0x462, x86_l_462);
x86_l_5f9:
	/* 0x5f9: jmp    481 <trace_ret_do_mmap+0x481> */
	X86_SIM_X86_JMP(0x5f9, 0x481, x86_l_481);
x86_l_5fe:
	/* 0x5fe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_600:
	/* 0x600: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_603:
	/* 0x603: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_608:
	/* 0x608: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_60b:
	/* 0x60b: jae    626 <trace_ret_do_mmap+0x626> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x60b, 0x626, x86_l_626);
x86_l_60d:
	/* 0x60d: jmp    63c <trace_ret_do_mmap+0x63c> */
	X86_SIM_X86_JMP(0x60d, 0x63c, x86_l_63c);
x86_l_60f:
	/* 0x60f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_611:
	/* 0x611: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_619:
	/* 0x619: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_61c:
	/* 0x61c: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_621:
	/* 0x621: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_624:
	/* 0x624: jb     63c <trace_ret_do_mmap+0x63c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x624, 0x63c, x86_l_63c);
x86_l_626:
	/* 0x626: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_62a:
	/* 0x62a: je     631 <trace_ret_do_mmap+0x631> */
	X86_SIM_X86_JCC(X86_CC_E, 0x62a, 0x631, x86_l_631);
x86_l_62c:
	/* 0x62c: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_62f:
	/* 0x62f: jbe    63c <trace_ret_do_mmap+0x63c> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x62f, 0x63c, x86_l_63c);
x86_l_631:
	/* 0x631: and    r14,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 224ULL);
x86_l_639:
	/* 0x639: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_63c:
	/* 0x63c: or     rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_63f:
	/* 0x63f: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_642:
	/* 0x642: and    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_645:
	/* 0x645: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_64a:
	/* 0x64a: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_652:
	/* 0x652: je     6ec <trace_ret_do_mmap+0x6ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x652, 0x6ec, x86_l_6ec);
x86_l_658:
	/* 0x658: call   65d <trace_ret_do_mmap+0x65d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_65d:
	/* 0x65d: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_661:
	/* 0x661: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_668:
	/* 0x668: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_66f:
	/* 0x66f: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_677:
	/* 0x677: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_67e:
	/* 0x67e: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_685:
	/* 0x685: movzx  eax,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_68a:
	/* 0x68a: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_68f:
	/* 0x68f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_696:
	/* 0x696: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_69b:
	/* 0x69b: call   6a0 <trace_ret_do_mmap+0x6a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6a0:
	/* 0x6a0: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6a4:
	/* 0x6a4: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6a9:
	/* 0x6a9: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6b0:
	/* 0x6b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b3:
	/* 0x6b3: je     6d3 <trace_ret_do_mmap+0x6d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b3, 0x6d3, x86_l_6d3);
x86_l_6b5:
	/* 0x6b5: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6ba:
	/* 0x6ba: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6bd:
	/* 0x6bd: call   6c2 <trace_ret_do_mmap+0x6c2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6c2:
	/* 0x6c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c5:
	/* 0x6c5: je     6d3 <trace_ret_do_mmap+0x6d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c5, 0x6d3, x86_l_6d3);
x86_l_6c7:
	/* 0x6c7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6ca:
	/* 0x6ca: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6ce:
	/* 0x6ce: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6d1:
	/* 0x6d1: jmp    6d5 <trace_ret_do_mmap+0x6d5> */
	X86_SIM_X86_JMP(0x6d1, 0x6d5, x86_l_6d5);
x86_l_6d3:
	/* 0x6d3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6d5:
	/* 0x6d5: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6d8:
	/* 0x6d8: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6dd:
	/* 0x6dd: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6e0:
	/* 0x6e0: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e3:
	/* 0x6e3: jae    706 <trace_ret_do_mmap+0x706> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6e3, 0x706, x86_l_706);
x86_l_6e5:
	/* 0x6e5: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6ea:
	/* 0x6ea: jmp    721 <trace_ret_do_mmap+0x721> */
	X86_SIM_X86_JMP(0x6ea, 0x721, x86_l_721);
x86_l_6ec:
	/* 0x6ec: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f1:
	/* 0x6f1: movzx  r13d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_6f7:
	/* 0x6f7: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6ff:
	/* 0x6ff: jne    73b <trace_ret_do_mmap+0x73b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ff, 0x73b, x86_l_73b);
x86_l_701:
	/* 0x701: jmp    7d9 <trace_ret_do_mmap+0x7d9> */
	X86_SIM_X86_JMP(0x701, 0x7d9, x86_l_7d9);
x86_l_706:
	/* 0x706: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_70a:
	/* 0x70a: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_70f:
	/* 0x70f: je     716 <trace_ret_do_mmap+0x716> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70f, 0x716, x86_l_716);
x86_l_711:
	/* 0x711: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_714:
	/* 0x714: jbe    721 <trace_ret_do_mmap+0x721> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x714, 0x721, x86_l_721);
x86_l_716:
	/* 0x716: and    r15,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 152ULL);
x86_l_71e:
	/* 0x71e: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_721:
	/* 0x721: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_724:
	/* 0x724: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_727:
	/* 0x727: movzx  r13d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_72d:
	/* 0x72d: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_735:
	/* 0x735: je     7d9 <trace_ret_do_mmap+0x7d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x735, 0x7d9, x86_l_7d9);
x86_l_73b:
	/* 0x73b: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_740:
	/* 0x740: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_747:
	/* 0x747: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_74a:
	/* 0x74a: jns    751 <trace_ret_do_mmap+0x751> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x74a, 0x751, x86_l_751);
x86_l_74c:
	/* 0x74c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_74f:
	/* 0x74f: jmp    753 <trace_ret_do_mmap+0x753> */
	X86_SIM_X86_JMP(0x74f, 0x753, x86_l_753);
x86_l_751:
	/* 0x751: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_753:
	/* 0x753: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_757:
	/* 0x757: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_759:
	/* 0x759: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_75c:
	/* 0x75c: jns    768 <trace_ret_do_mmap+0x768> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x75c, 0x768, x86_l_768);
x86_l_75e:
	/* 0x75e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_761:
	/* 0x761: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_764:
	/* 0x764: js     76f <trace_ret_do_mmap+0x76f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x764, 0x76f, x86_l_76f);
x86_l_766:
	/* 0x766: jmp    771 <trace_ret_do_mmap+0x771> */
	X86_SIM_X86_JMP(0x766, 0x771, x86_l_771);
x86_l_768:
	/* 0x768: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_76a:
	/* 0x76a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_76d:
	/* 0x76d: jns    771 <trace_ret_do_mmap+0x771> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x76d, 0x771, x86_l_771);
x86_l_76f:
	/* 0x76f: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_771:
	/* 0x771: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_775:
	/* 0x775: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_77c:
	/* 0x77c: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_783:
	/* 0x783: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_786:
	/* 0x786: mov    WORD PTR [rsp+0x50],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_78c:
	/* 0x78c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_793:
	/* 0x793: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_798:
	/* 0x798: call   79d <trace_ret_do_mmap+0x79d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_79d:
	/* 0x79d: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7a4:
	/* 0x7a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a7:
	/* 0x7a7: je     7c6 <trace_ret_do_mmap+0x7c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a7, 0x7c6, x86_l_7c6);
x86_l_7a9:
	/* 0x7a9: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7ad:
	/* 0x7ad: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b0:
	/* 0x7b0: call   7b5 <trace_ret_do_mmap+0x7b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7b5:
	/* 0x7b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b8:
	/* 0x7b8: je     7c6 <trace_ret_do_mmap+0x7c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b8, 0x7c6, x86_l_7c6);
x86_l_7ba:
	/* 0x7ba: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7bd:
	/* 0x7bd: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7c1:
	/* 0x7c1: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7c4:
	/* 0x7c4: jmp    7c8 <trace_ret_do_mmap+0x7c8> */
	X86_SIM_X86_JMP(0x7c4, 0x7c8, x86_l_7c8);
x86_l_7c6:
	/* 0x7c6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c8:
	/* 0x7c8: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7cb:
	/* 0x7cb: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7ce:
	/* 0x7ce: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7d1:
	/* 0x7d1: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7d4:
	/* 0x7d4: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7d9:
	/* 0x7d9: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_7e1:
	/* 0x7e1: je     8a9 <trace_ret_do_mmap+0x8a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e1, 0x8a9, x86_l_8a9);
x86_l_7e7:
	/* 0x7e7: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_7ee:
	/* 0x7ee: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7f2:
	/* 0x7f2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f4:
	/* 0x7f4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7f7:
	/* 0x7f7: jns    806 <trace_ret_do_mmap+0x806> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7f7, 0x806, x86_l_806);
x86_l_7f9:
	/* 0x7f9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7fc:
	/* 0x7fc: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7ff:
	/* 0x7ff: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_802:
	/* 0x802: js     810 <trace_ret_do_mmap+0x810> */
	X86_SIM_X86_JCC(X86_CC_S, 0x802, 0x810, x86_l_810);
x86_l_804:
	/* 0x804: jmp    812 <trace_ret_do_mmap+0x812> */
	X86_SIM_X86_JMP(0x804, 0x812, x86_l_812);
x86_l_806:
	/* 0x806: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_808:
	/* 0x808: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_80b:
	/* 0x80b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_80e:
	/* 0x80e: jns    812 <trace_ret_do_mmap+0x812> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x80e, 0x812, x86_l_812);
x86_l_810:
	/* 0x810: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_812:
	/* 0x812: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_814:
	/* 0x814: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_818:
	/* 0x818: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_81b:
	/* 0x81b: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_81f:
	/* 0x81f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_821:
	/* 0x821: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_824:
	/* 0x824: jns    834 <trace_ret_do_mmap+0x834> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x824, 0x834, x86_l_834);
x86_l_826:
	/* 0x826: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_829:
	/* 0x829: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_82d:
	/* 0x82d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_830:
	/* 0x830: js     83f <trace_ret_do_mmap+0x83f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x830, 0x83f, x86_l_83f);
x86_l_832:
	/* 0x832: jmp    841 <trace_ret_do_mmap+0x841> */
	X86_SIM_X86_JMP(0x832, 0x841, x86_l_841);
x86_l_834:
	/* 0x834: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_836:
	/* 0x836: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_83a:
	/* 0x83a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_83d:
	/* 0x83d: jns    841 <trace_ret_do_mmap+0x841> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83d, 0x841, x86_l_841);
x86_l_83f:
	/* 0x83f: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_841:
	/* 0x841: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_845:
	/* 0x845: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_84c:
	/* 0x84c: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_853:
	/* 0x853: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_856:
	/* 0x856: mov    WORD PTR [rsp+0x50],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_85c:
	/* 0x85c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_863:
	/* 0x863: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_868:
	/* 0x868: call   86d <trace_ret_do_mmap+0x86d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_86d:
	/* 0x86d: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_874:
	/* 0x874: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_877:
	/* 0x877: je     896 <trace_ret_do_mmap+0x896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x877, 0x896, x86_l_896);
x86_l_879:
	/* 0x879: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_87d:
	/* 0x87d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_880:
	/* 0x880: call   885 <trace_ret_do_mmap+0x885> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_885:
	/* 0x885: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_888:
	/* 0x888: je     896 <trace_ret_do_mmap+0x896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x888, 0x896, x86_l_896);
x86_l_88a:
	/* 0x88a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_88d:
	/* 0x88d: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_891:
	/* 0x891: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_894:
	/* 0x894: jmp    898 <trace_ret_do_mmap+0x898> */
	X86_SIM_X86_JMP(0x894, 0x898, x86_l_898);
x86_l_896:
	/* 0x896: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_898:
	/* 0x898: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_89b:
	/* 0x89b: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_89e:
	/* 0x89e: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8a1:
	/* 0x8a1: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8a4:
	/* 0x8a4: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8a9:
	/* 0x8a9: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_8b1:
	/* 0x8b1: je     a98 <trace_ret_do_mmap+0xa98> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b1, 0xa98, x86_l_a98);
x86_l_8b7:
	/* 0x8b7: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8bc:
	/* 0x8bc: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_8c3:
	/* 0x8c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c6:
	/* 0x8c6: jns    8d9 <trace_ret_do_mmap+0x8d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c6, 0x8d9, x86_l_8d9);
x86_l_8c8:
	/* 0x8c8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8cb:
	/* 0x8cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ce:
	/* 0x8ce: js     8e0 <trace_ret_do_mmap+0x8e0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8ce, 0x8e0, x86_l_8e0);
x86_l_8d0:
	/* 0x8d0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d2:
	/* 0x8d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8d5:
	/* 0x8d5: js     8e8 <trace_ret_do_mmap+0x8e8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8d5, 0x8e8, x86_l_8e8);
x86_l_8d7:
	/* 0x8d7: jmp    939 <trace_ret_do_mmap+0x939> */
	X86_SIM_X86_JMP(0x8d7, 0x939, x86_l_939);
x86_l_8d9:
	/* 0x8d9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8db:
	/* 0x8db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8de:
	/* 0x8de: jns    8d0 <trace_ret_do_mmap+0x8d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8de, 0x8d0, x86_l_8d0);
x86_l_8e0:
	/* 0x8e0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e3:
	/* 0x8e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e6:
	/* 0x8e6: jns    939 <trace_ret_do_mmap+0x939> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e6, 0x939, x86_l_939);
x86_l_8e8:
	/* 0x8e8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8eb:
	/* 0x8eb: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8f0:
	/* 0x8f0: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f4:
	/* 0x8f4: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_8f9:
	/* 0x8f9: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8fd:
	/* 0x8fd: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_902:
	/* 0x902: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_906:
	/* 0x906: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_90b:
	/* 0x90b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_90f:
	/* 0x90f: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_914:
	/* 0x914: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_918:
	/* 0x918: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_91d:
	/* 0x91d: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_921:
	/* 0x921: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_929:
	/* 0x929: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_92d:
	/* 0x92d: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_935:
	/* 0x935: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_939:
	/* 0x939: lea    r15,[rbp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_93d:
	/* 0x93d: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_942:
	/* 0x942: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_945:
	/* 0x945: jns    a1c <trace_ret_do_mmap+0xa1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x945, 0xa1c, x86_l_a1c);
x86_l_94b:
	/* 0x94b: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_94e:
	/* 0x94e: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_951:
	/* 0x951: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_953:
	/* 0x953: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x953, 0xa2b, x86_l_a2b);
x86_l_959:
	/* 0x959: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_95d:
	/* 0x95d: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_961:
	/* 0x961: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_963:
	/* 0x963: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x963, 0xa2b, x86_l_a2b);
x86_l_969:
	/* 0x969: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_96d:
	/* 0x96d: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_971:
	/* 0x971: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_973:
	/* 0x973: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x973, 0xa2b, x86_l_a2b);
x86_l_979:
	/* 0x979: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_97d:
	/* 0x97d: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_981:
	/* 0x981: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_983:
	/* 0x983: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x983, 0xa2b, x86_l_a2b);
x86_l_989:
	/* 0x989: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_98d:
	/* 0x98d: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_991:
	/* 0x991: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_993:
	/* 0x993: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x993, 0xa2b, x86_l_a2b);
x86_l_999:
	/* 0x999: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_99d:
	/* 0x99d: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_9a1:
	/* 0x9a1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a3:
	/* 0x9a3: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a3, 0xa2b, x86_l_a2b);
x86_l_9a9:
	/* 0x9a9: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_9ad:
	/* 0x9ad: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_9b1:
	/* 0x9b1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b3:
	/* 0x9b3: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b3, 0xa2b, x86_l_a2b);
x86_l_9b5:
	/* 0x9b5: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_9b9:
	/* 0x9b9: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_9bd:
	/* 0x9bd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9bf:
	/* 0x9bf: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9bf, 0xa2b, x86_l_a2b);
x86_l_9c1:
	/* 0x9c1: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_9c5:
	/* 0x9c5: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_9c9:
	/* 0x9c9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9cb:
	/* 0x9cb: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cb, 0xa2b, x86_l_a2b);
x86_l_9cd:
	/* 0x9cd: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_9d1:
	/* 0x9d1: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_9d5:
	/* 0x9d5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d7:
	/* 0x9d7: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d7, 0xa2b, x86_l_a2b);
x86_l_9d9:
	/* 0x9d9: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_9dd:
	/* 0x9dd: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_9e1:
	/* 0x9e1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9e3:
	/* 0x9e3: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e3, 0xa2b, x86_l_a2b);
x86_l_9e5:
	/* 0x9e5: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_9e9:
	/* 0x9e9: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_9ed:
	/* 0x9ed: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9ef:
	/* 0x9ef: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ef, 0xa2b, x86_l_a2b);
x86_l_9f1:
	/* 0x9f1: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_9f5:
	/* 0x9f5: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_9f9:
	/* 0x9f9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9fb:
	/* 0x9fb: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9fb, 0xa2b, x86_l_a2b);
x86_l_9fd:
	/* 0x9fd: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_a01:
	/* 0xa01: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_a05:
	/* 0xa05: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a07:
	/* 0xa07: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa07, 0xa2b, x86_l_a2b);
x86_l_a09:
	/* 0xa09: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_a0d:
	/* 0xa0d: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_a11:
	/* 0xa11: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_a13:
	/* 0xa13: je     a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa13, 0xa2b, x86_l_a2b);
x86_l_a15:
	/* 0xa15: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_a1a:
	/* 0xa1a: jmp    a2b <trace_ret_do_mmap+0xa2b> */
	X86_SIM_X86_JMP(0xa1a, 0xa2b, x86_l_a2b);
x86_l_a1c:
	/* 0xa1c: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a24:
	/* 0xa24: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a2b:
	/* 0xa2b: mov    rbx,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a32:
	/* 0xa32: mov    r13,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a39:
	/* 0xa39: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a3c:
	/* 0xa3c: movzx  eax,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_a41:
	/* 0xa41: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a46:
	/* 0xa46: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a4d:
	/* 0xa4d: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a52:
	/* 0xa52: call   a57 <trace_ret_do_mmap+0xa57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a57:
	/* 0xa57: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a5e:
	/* 0xa5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a61:
	/* 0xa61: je     a7f <trace_ret_do_mmap+0xa7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa61, 0xa7f, x86_l_a7f);
x86_l_a63:
	/* 0xa63: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a66:
	/* 0xa66: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a69:
	/* 0xa69: call   a6e <trace_ret_do_mmap+0xa6e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a6e:
	/* 0xa6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a71:
	/* 0xa71: je     a7f <trace_ret_do_mmap+0xa7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa71, 0xa7f, x86_l_a7f);
x86_l_a73:
	/* 0xa73: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a76:
	/* 0xa76: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a7a:
	/* 0xa7a: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a7d:
	/* 0xa7d: jmp    a81 <trace_ret_do_mmap+0xa81> */
	X86_SIM_X86_JMP(0xa7d, 0xa81, x86_l_a81);
x86_l_a7f:
	/* 0xa7f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a81:
	/* 0xa81: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a84:
	/* 0xa84: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a87:
	/* 0xa87: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a8a:
	/* 0xa8a: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a8d:
	/* 0xa8d: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a92:
	/* 0xa92: movzx  r13d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_a98:
	/* 0xa98: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_aa0:
	/* 0xaa0: je     b22 <trace_ret_do_mmap+0xb22> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaa0, 0xb22, x86_l_b22);
x86_l_aa6:
	/* 0xaa6: lea    r15,[rbp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_aaa:
	/* 0xaaa: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_aad:
	/* 0xaad: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_ab2:
	/* 0xab2: call   ab7 <trace_ret_do_mmap+0xab7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_ab7:
	/* 0xab7: mov    rbx,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_abe:
	/* 0xabe: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_ac1:
	/* 0xac1: mov    r13,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_ac8:
	/* 0xac8: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_acb:
	/* 0xacb: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ad0:
	/* 0xad0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_ad7:
	/* 0xad7: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_adc:
	/* 0xadc: call   ae1 <trace_ret_do_mmap+0xae1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae1:
	/* 0xae1: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ae8:
	/* 0xae8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aeb:
	/* 0xaeb: je     b09 <trace_ret_do_mmap+0xb09> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaeb, 0xb09, x86_l_b09);
x86_l_aed:
	/* 0xaed: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af0:
	/* 0xaf0: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_af3:
	/* 0xaf3: call   af8 <trace_ret_do_mmap+0xaf8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_af8:
	/* 0xaf8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_afb:
	/* 0xafb: je     b09 <trace_ret_do_mmap+0xb09> */
	X86_SIM_X86_JCC(X86_CC_E, 0xafb, 0xb09, x86_l_b09);
x86_l_afd:
	/* 0xafd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b00:
	/* 0xb00: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b04:
	/* 0xb04: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b07:
	/* 0xb07: jmp    b0b <trace_ret_do_mmap+0xb0b> */
	X86_SIM_X86_JMP(0xb07, 0xb0b, x86_l_b0b);
x86_l_b09:
	/* 0xb09: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b0b:
	/* 0xb0b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b0e:
	/* 0xb0e: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b11:
	/* 0xb11: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b14:
	/* 0xb14: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b17:
	/* 0xb17: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b1c:
	/* 0xb1c: movzx  r13d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_b22:
	/* 0xb22: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b29:
	/* 0xb29: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b2c:
	/* 0xb2c: je     b94 <trace_ret_do_mmap+0xb94> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2c, 0xb94, x86_l_b94);
x86_l_b2e:
	/* 0xb2e: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b32:
	/* 0xb32: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b36:
	/* 0xb36: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b3d:
	/* 0xb3d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b40:
	/* 0xb40: mov    WORD PTR [rsp+0x40],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b46:
	/* 0xb46: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b4d:
	/* 0xb4d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b52:
	/* 0xb52: call   b57 <trace_ret_do_mmap+0xb57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b57:
	/* 0xb57: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b5e:
	/* 0xb5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b61:
	/* 0xb61: je     b81 <trace_ret_do_mmap+0xb81> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb61, 0xb81, x86_l_b81);
x86_l_b63:
	/* 0xb63: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b68:
	/* 0xb68: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b6b:
	/* 0xb6b: call   b70 <trace_ret_do_mmap+0xb70> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b70:
	/* 0xb70: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b73:
	/* 0xb73: je     b81 <trace_ret_do_mmap+0xb81> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb73, 0xb81, x86_l_b81);
x86_l_b75:
	/* 0xb75: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b78:
	/* 0xb78: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b7c:
	/* 0xb7c: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b7f:
	/* 0xb7f: jmp    b83 <trace_ret_do_mmap+0xb83> */
	X86_SIM_X86_JMP(0xb7f, 0xb83, x86_l_b83);
x86_l_b81:
	/* 0xb81: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b83:
	/* 0xb83: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b86:
	/* 0xb86: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b89:
	/* 0xb89: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b8c:
	/* 0xb8c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b8f:
	/* 0xb8f: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b94:
	/* 0xb94: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b9b:
	/* 0xb9b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b9e:
	/* 0xb9e: je     bfd <trace_ret_do_mmap+0xbfd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9e, 0xbfd, x86_l_bfd);
x86_l_ba0:
	/* 0xba0: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_ba7:
	/* 0xba7: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_baa:
	/* 0xbaa: mov    WORD PTR [rsp+0x50],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_bb0:
	/* 0xbb0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_bb7:
	/* 0xbb7: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_bbc:
	/* 0xbbc: call   bc1 <trace_ret_do_mmap+0xbc1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bc1:
	/* 0xbc1: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bc8:
	/* 0xbc8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bcb:
	/* 0xbcb: je     bea <trace_ret_do_mmap+0xbea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbcb, 0xbea, x86_l_bea);
x86_l_bcd:
	/* 0xbcd: lea    rsi,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_bd1:
	/* 0xbd1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd4:
	/* 0xbd4: call   bd9 <trace_ret_do_mmap+0xbd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bd9:
	/* 0xbd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bdc:
	/* 0xbdc: je     bea <trace_ret_do_mmap+0xbea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbdc, 0xbea, x86_l_bea);
x86_l_bde:
	/* 0xbde: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_be1:
	/* 0xbe1: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be5:
	/* 0xbe5: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_be8:
	/* 0xbe8: jmp    bec <trace_ret_do_mmap+0xbec> */
	X86_SIM_X86_JMP(0xbe8, 0xbec, x86_l_bec);
x86_l_bea:
	/* 0xbea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bec:
	/* 0xbec: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bef:
	/* 0xbef: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bf2:
	/* 0xbf2: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bf5:
	/* 0xbf5: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bf8:
	/* 0xbf8: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bfd:
	/* 0xbfd: mov    rbx,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c04:
	/* 0xc04: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c07:
	/* 0xc07: je     c8b <trace_ret_do_mmap+0xc8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc07, 0xc8b, x86_l_c8b);
x86_l_c0d:
	/* 0xc0d: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_c10:
	/* 0xc10: mov    r13,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c17:
	/* 0xc17: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c1a:
	/* 0xc1a: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c1f:
	/* 0xc1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_c26:
	/* 0xc26: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c2b:
	/* 0xc2b: call   c30 <trace_ret_do_mmap+0xc30> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c30:
	/* 0xc30: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c37:
	/* 0xc37: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c3a:
	/* 0xc3a: je     c7d <trace_ret_do_mmap+0xc7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3a, 0xc7d, x86_l_c7d);
x86_l_c3c:
	/* 0xc3c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c3f:
	/* 0xc3f: mov    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_c47:
	/* 0xc47: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_c4b:
	/* 0xc4b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c4e:
	/* 0xc4e: call   c53 <trace_ret_do_mmap+0xc53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c53:
	/* 0xc53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c56:
	/* 0xc56: jne    c71 <trace_ret_do_mmap+0xc71> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc56, 0xc71, x86_l_c71);
x86_l_c58:
	/* 0xc58: mov    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_c60:
	/* 0xc60: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c64:
	/* 0xc64: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c67:
	/* 0xc67: call   c6c <trace_ret_do_mmap+0xc6c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c6c:
	/* 0xc6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6f:
	/* 0xc6f: je     c7d <trace_ret_do_mmap+0xc7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6f, 0xc7d, x86_l_c7d);
x86_l_c71:
	/* 0xc71: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c74:
	/* 0xc74: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c78:
	/* 0xc78: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c7b:
	/* 0xc7b: jmp    c7f <trace_ret_do_mmap+0xc7f> */
	X86_SIM_X86_JMP(0xc7b, 0xc7f, x86_l_c7f);
x86_l_c7d:
	/* 0xc7d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c7f:
	/* 0xc7f: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c82:
	/* 0xc82: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c85:
	/* 0xc85: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c88:
	/* 0xc88: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c8b:
	/* 0xc8b: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c92:
	/* 0xc92: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c95:
	/* 0xc95: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c9a:
	/* 0xc9a: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_c9f:
	/* 0xc9f: je     cb0 <trace_ret_do_mmap+0xcb0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc9f, 0xcb0, x86_l_cb0);
x86_l_ca1:
	/* 0xca1: mov    rcx,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_ca9:
	/* 0xca9: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_cad:
	/* 0xcad: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cb0:
	/* 0xcb0: and    r12,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_cb7:
	/* 0xcb7: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cbe:
	/* 0xcbe: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cc1:
	/* 0xcc1: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cc8:
	/* 0xcc8: je     3718 <trace_ret_do_mmap+0x3718> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcc8, 0x3718, x86_l_3718);
x86_l_cce:
	/* 0xcce: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_cd3:
	/* 0xcd3: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cd6:
	/* 0xcd6: je     cea <trace_ret_do_mmap+0xcea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd6, 0xcea, x86_l_cea);
x86_l_cd8:
	/* 0xcd8: lea    rbx,[r12+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_cdd:
	/* 0xcdd: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ce0:
	/* 0xce0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce3:
	/* 0xce3: jns    cef <trace_ret_do_mmap+0xcef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xce3, 0xcef, x86_l_cef);
x86_l_ce5:
	/* 0xce5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce8:
	/* 0xce8: jmp    cf1 <trace_ret_do_mmap+0xcf1> */
	X86_SIM_X86_JMP(0xce8, 0xcf1, x86_l_cf1);
x86_l_cea:
	/* 0xcea: jmp    2bf4 <trace_ret_do_mmap+0x2bf4> */
	X86_SIM_X86_JMP(0xcea, 0x2bf4, x86_l_2bf4);
x86_l_cef:
	/* 0xcef: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf1:
	/* 0xcf1: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_cf5:
	/* 0xcf5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf7:
	/* 0xcf7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cfa:
	/* 0xcfa: jns    d06 <trace_ret_do_mmap+0xd06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcfa, 0xd06, x86_l_d06);
x86_l_cfc:
	/* 0xcfc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cff:
	/* 0xcff: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d02:
	/* 0xd02: js     d0d <trace_ret_do_mmap+0xd0d> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd02, 0xd0d, x86_l_d0d);
x86_l_d04:
	/* 0xd04: jmp    d0f <trace_ret_do_mmap+0xd0f> */
	X86_SIM_X86_JMP(0xd04, 0xd0f, x86_l_d0f);
x86_l_d06:
	/* 0xd06: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d08:
	/* 0xd08: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d0b:
	/* 0xd0b: jns    d0f <trace_ret_do_mmap+0xd0f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd0b, 0xd0f, x86_l_d0f);
x86_l_d0d:
	/* 0xd0d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d0f:
	/* 0xd0f: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_d16:
	/* 0xd16: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d19:
	/* 0xd19: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d1c:
	/* 0xd1c: jns    d2e <trace_ret_do_mmap+0xd2e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd1c, 0xd2e, x86_l_d2e);
x86_l_d1e:
	/* 0xd1e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d21:
	/* 0xd21: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_d25:
	/* 0xd25: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d28:
	/* 0xd28: js     d39 <trace_ret_do_mmap+0xd39> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd28, 0xd39, x86_l_d39);
x86_l_d2a:
	/* 0xd2a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d2c:
	/* 0xd2c: jmp    d3c <trace_ret_do_mmap+0xd3c> */
	X86_SIM_X86_JMP(0xd2c, 0xd3c, x86_l_d3c);
x86_l_d2e:
	/* 0xd2e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d30:
	/* 0xd30: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_d34:
	/* 0xd34: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d37:
	/* 0xd37: jns    d2a <trace_ret_do_mmap+0xd2a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd37, 0xd2a, x86_l_d2a);
x86_l_d39:
	/* 0xd39: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3c:
	/* 0xd3c: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d41:
	/* 0xd41: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_d49:
	/* 0xd49: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_d50:
	/* 0xd50: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d55:
	/* 0xd55: call   d5a <trace_ret_do_mmap+0xd5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d5a:
	/* 0xd5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d5d:
	/* 0xd5d: je     d79 <trace_ret_do_mmap+0xd79> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd5d, 0xd79, x86_l_d79);
x86_l_d5f:
	/* 0xd5f: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d62:
	/* 0xd62: lea    rax,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d67:
	/* 0xd67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d6a:
	/* 0xd6a: jns    d8b <trace_ret_do_mmap+0xd8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd6a, 0xd8b, x86_l_d8b);
x86_l_d6c:
	/* 0xd6c: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d6f:
	/* 0xd6f: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d72:
	/* 0xd72: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d75:
	/* 0xd75: js     d96 <trace_ret_do_mmap+0xd96> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd75, 0xd96, x86_l_d96);
x86_l_d77:
	/* 0xd77: jmp    da0 <trace_ret_do_mmap+0xda0> */
	X86_SIM_X86_JMP(0xd77, 0xda0, x86_l_da0);
x86_l_d79:
	/* 0xd79: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d7b:
	/* 0xd7b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d7e:
	/* 0xd7e: js     2b74 <trace_ret_do_mmap+0x2b74> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd7e, 0x2b74, x86_l_2b74);
x86_l_d84:
	/* 0xd84: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d86:
	/* 0xd86: jmp    2b77 <trace_ret_do_mmap+0x2b77> */
	X86_SIM_X86_JMP(0xd86, 0x2b77, x86_l_2b77);
x86_l_d8b:
	/* 0xd8b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d8e:
	/* 0xd8e: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d91:
	/* 0xd91: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d94:
	/* 0xd94: jns    da0 <trace_ret_do_mmap+0xda0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd94, 0xda0, x86_l_da0);
x86_l_d96:
	/* 0xd96: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d98:
	/* 0xd98: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_d9a:
	/* 0xd9a: jne    ea9 <trace_ret_do_mmap+0xea9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd9a, 0xea9, x86_l_ea9);
x86_l_da0:
	/* 0xda0: lea    rax,[r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da5:
	/* 0xda5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_da8:
	/* 0xda8: jns    daf <trace_ret_do_mmap+0xdaf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xda8, 0xdaf, x86_l_daf);
x86_l_daa:
	/* 0xdaa: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dad:
	/* 0xdad: jmp    db1 <trace_ret_do_mmap+0xdb1> */
	X86_SIM_X86_JMP(0xdad, 0xdb1, x86_l_db1);
x86_l_daf:
	/* 0xdaf: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_db1:
	/* 0xdb1: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_db5:
	/* 0xdb5: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_db8:
	/* 0xdb8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dbb:
	/* 0xdbb: jns    ddf <trace_ret_do_mmap+0xddf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdbb, 0xddf, x86_l_ddf);
x86_l_dbd:
	/* 0xdbd: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dc0:
	/* 0xdc0: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_dc3:
	/* 0xdc3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_dc6:
	/* 0xdc6: js     de9 <trace_ret_do_mmap+0xde9> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdc6, 0xde9, x86_l_de9);
x86_l_dc8:
	/* 0xdc8: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dca:
	/* 0xdca: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dce:
	/* 0xdce: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_dd1:
	/* 0xdd1: js     df5 <trace_ret_do_mmap+0xdf5> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdd1, 0xdf5, x86_l_df5);
x86_l_dd3:
	/* 0xdd3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd5:
	/* 0xdd5: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_dd8:
	/* 0xdd8: jne    e01 <trace_ret_do_mmap+0xe01> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdd8, 0xe01, x86_l_e01);
x86_l_dda:
	/* 0xdda: jmp    e7f <trace_ret_do_mmap+0xe7f> */
	X86_SIM_X86_JMP(0xdda, 0xe7f, x86_l_e7f);
x86_l_ddf:
	/* 0xddf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_de1:
	/* 0xde1: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_de4:
	/* 0xde4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_de7:
	/* 0xde7: jns    dc8 <trace_ret_do_mmap+0xdc8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde7, 0xdc8, x86_l_dc8);
x86_l_de9:
	/* 0xde9: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dec:
	/* 0xdec: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_df0:
	/* 0xdf0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_df3:
	/* 0xdf3: jns    dd3 <trace_ret_do_mmap+0xdd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdf3, 0xdd3, x86_l_dd3);
x86_l_df5:
	/* 0xdf5: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_df8:
	/* 0xdf8: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_dfb:
	/* 0xdfb: je     e7f <trace_ret_do_mmap+0xe7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdfb, 0xe7f, x86_l_e7f);
x86_l_e01:
	/* 0xe01: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e04:
	/* 0xe04: je     e7f <trace_ret_do_mmap+0xe7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe04, 0xe7f, x86_l_e7f);
x86_l_e06:
	/* 0xe06: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e0a:
	/* 0xe0a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e0d:
	/* 0xe0d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e13:
	/* 0xe13: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e16:
	/* 0xe16: jns    e1f <trace_ret_do_mmap+0xe1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe16, 0xe1f, x86_l_e1f);
x86_l_e18:
	/* 0xe18: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e1b:
	/* 0xe1b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e1f:
	/* 0xe1f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_e23:
	/* 0xe23: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_e26:
	/* 0xe26: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_e2d:
	/* 0xe2d: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_e30:
	/* 0xe30: je     f79 <trace_ret_do_mmap+0xf79> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe30, 0xf79, x86_l_f79);
x86_l_e36:
	/* 0xe36: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_e39:
	/* 0xe39: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_e3b:
	/* 0xe3b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_e41:
	/* 0xe41: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e44:
	/* 0xe44: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_e47:
	/* 0xe47: jns    edf <trace_ret_do_mmap+0xedf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe47, 0xedf, x86_l_edf);
x86_l_e4d:
	/* 0xe4d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_e51:
	/* 0xe51: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e54:
	/* 0xe54: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_e57:
	/* 0xe57: je     f41 <trace_ret_do_mmap+0xf41> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe57, 0xf41, x86_l_f41);
x86_l_e5d:
	/* 0xe5d: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_e61:
	/* 0xe61: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_e66:
	/* 0xe66: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_e6a:
	/* 0xe6a: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_e6d:
	/* 0xe6d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_e70:
	/* 0xe70: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e75:
	/* 0xe75: jne    e54 <trace_ret_do_mmap+0xe54> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe75, 0xe54, x86_l_e54);
x86_l_e77:
	/* 0xe77: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_e7a:
	/* 0xe7a: jmp    f46 <trace_ret_do_mmap+0xf46> */
	X86_SIM_X86_JMP(0xe7a, 0xf46, x86_l_f46);
x86_l_e7f:
	/* 0xe7f: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e82:
	/* 0xe82: jne    f79 <trace_ret_do_mmap+0xf79> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe82, 0xf79, x86_l_f79);
x86_l_e88:
	/* 0xe88: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e8b:
	/* 0xe8b: je     f79 <trace_ret_do_mmap+0xf79> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8b, 0xf79, x86_l_f79);
x86_l_e91:
	/* 0xe91: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_e95:
	/* 0xe95: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e98:
	/* 0xe98: jns    f0d <trace_ret_do_mmap+0xf0d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe98, 0xf0d, x86_l_f0d);
x86_l_e9a:
	/* 0xe9a: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e9d:
	/* 0xe9d: jmp    f0f <trace_ret_do_mmap+0xf0f> */
	X86_SIM_X86_JMP(0xe9d, 0xf0f, x86_l_f0f);
x86_l_e9f:
	/* 0xe9f: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_ea4:
	/* 0xea4: jmp    22e <trace_ret_do_mmap+0x22e> */
	X86_SIM_X86_JMP(0xea4, 0x22e, x86_l_22e);
x86_l_ea9:
	/* 0xea9: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_eb0:
	/* 0xeb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_eb3:
	/* 0xeb3: jns    f8e <trace_ret_do_mmap+0xf8e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeb3, 0xf8e, x86_l_f8e);
x86_l_eb9:
	/* 0xeb9: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ebc:
	/* 0xebc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ebe:
	/* 0xebe: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_ec5:
	/* 0xec5: je     fc8 <trace_ret_do_mmap+0xfc8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec5, 0xfc8, x86_l_fc8);
x86_l_ecb:
	/* 0xecb: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_ecf:
	/* 0xecf: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_ed3:
	/* 0xed3: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_ed6:
	/* 0xed6: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_ed8:
	/* 0xed8: jne    ebe <trace_ret_do_mmap+0xebe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xed8, 0xebe, x86_l_ebe);
x86_l_eda:
	/* 0xeda: jmp    2b61 <trace_ret_do_mmap+0x2b61> */
	X86_SIM_X86_JMP(0xeda, 0x2b61, x86_l_2b61);
x86_l_edf:
	/* 0xedf: mov    eax,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_ee4:
	/* 0xee4: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee9:
	/* 0xee9: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_eec:
	/* 0xeec: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eee:
	/* 0xeee: call   ef3 <trace_ret_do_mmap+0xef3> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_ef3:
	/* 0xef3: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ef6:
	/* 0xef6: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_efb:
	/* 0xefb: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_efe:
	/* 0xefe: cmp    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_f05:
	/* 0xf05: jne    2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf05, 0x2b4a, x86_l_2b4a);
x86_l_f0b:
	/* 0xf0b: jmp    f79 <trace_ret_do_mmap+0xf79> */
	X86_SIM_X86_JMP(0xf0b, 0xf79, x86_l_f79);
x86_l_f0d:
	/* 0xf0d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f0f:
	/* 0xf0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f12:
	/* 0xf12: jns    f19 <trace_ret_do_mmap+0xf19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf12, 0xf19, x86_l_f19);
x86_l_f14:
	/* 0xf14: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f17:
	/* 0xf17: jmp    f1b <trace_ret_do_mmap+0xf1b> */
	X86_SIM_X86_JMP(0xf17, 0xf1b, x86_l_f1b);
x86_l_f19:
	/* 0xf19: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f1b:
	/* 0xf1b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f1e:
	/* 0xf1e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f21:
	/* 0xf21: jns    f28 <trace_ret_do_mmap+0xf28> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf21, 0xf28, x86_l_f28);
x86_l_f23:
	/* 0xf23: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f26:
	/* 0xf26: jmp    f2a <trace_ret_do_mmap+0xf2a> */
	X86_SIM_X86_JMP(0xf26, 0xf2a, x86_l_f2a);
x86_l_f28:
	/* 0xf28: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f2a:
	/* 0xf2a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f2e:
	/* 0xf2e: mov    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_f34:
	/* 0xf34: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f37:
	/* 0xf37: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f3a:
	/* 0xf3a: jns    f69 <trace_ret_do_mmap+0xf69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf3a, 0xf69, x86_l_f69);
x86_l_f3c:
	/* 0xf3c: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3f:
	/* 0xf3f: jmp    f6b <trace_ret_do_mmap+0xf6b> */
	X86_SIM_X86_JMP(0xf3f, 0xf6b, x86_l_f6b);
x86_l_f41:
	/* 0xf41: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f46:
	/* 0xf46: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f4a:
	/* 0xf4a: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f4f:
	/* 0xf4f: jl     f79 <trace_ret_do_mmap+0xf79> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf4f, 0xf79, x86_l_f79);
x86_l_f51:
	/* 0xf51: mov    BYTE PTR [rbp+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_f58:
	/* 0xf58: mov    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_f5e:
	/* 0xf5e: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f61:
	/* 0xf61: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f64:
	/* 0xf64: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f67:
	/* 0xf67: js     f3c <trace_ret_do_mmap+0xf3c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf67, 0xf3c, x86_l_f3c);
x86_l_f69:
	/* 0xf69: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f6b:
	/* 0xf6b: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f6f:
	/* 0xf6f: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f72:
	/* 0xf72: jns    fd7 <trace_ret_do_mmap+0xfd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf72, 0xfd7, x86_l_fd7);
x86_l_f74:
	/* 0xf74: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f77:
	/* 0xf77: jmp    fda <trace_ret_do_mmap+0xfda> */
	X86_SIM_X86_JMP(0xf77, 0xfda, x86_l_fda);
x86_l_f79:
	/* 0xf79: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_f7d:
	/* 0xf7d: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f80:
	/* 0xf80: jns    f9f <trace_ret_do_mmap+0xf9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf80, 0xf9f, x86_l_f9f);
x86_l_f82:
	/* 0xf82: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f85:
	/* 0xf85: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f89:
	/* 0xf89: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f8c:
	/* 0xf8c: js     fa6 <trace_ret_do_mmap+0xfa6> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf8c, 0xfa6, x86_l_fa6);
x86_l_f8e:
	/* 0xf8e: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_f93:
	/* 0xf93: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f96:
	/* 0xf96: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f98:
	/* 0xf98: call   f9d <trace_ret_do_mmap+0xf9d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_f9d:
	/* 0xf9d: jmp    fcf <trace_ret_do_mmap+0xfcf> */
	X86_SIM_X86_JMP(0xf9d, 0xfcf, x86_l_fcf);
x86_l_f9f:
	/* 0xf9f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa1:
	/* 0xfa1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fa4:
	/* 0xfa4: jns    f8e <trace_ret_do_mmap+0xf8e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfa4, 0xf8e, x86_l_f8e);
x86_l_fa6:
	/* 0xfa6: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa9:
	/* 0xfa9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fab:
	/* 0xfab: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_fb2:
	/* 0xfb2: je     fc8 <trace_ret_do_mmap+0xfc8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb2, 0xfc8, x86_l_fc8);
x86_l_fb4:
	/* 0xfb4: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_fb8:
	/* 0xfb8: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_fbc:
	/* 0xfbc: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_fbf:
	/* 0xfbf: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_fc1:
	/* 0xfc1: jne    fab <trace_ret_do_mmap+0xfab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfc1, 0xfab, x86_l_fab);
x86_l_fc3:
	/* 0xfc3: jmp    2b61 <trace_ret_do_mmap+0x2b61> */
	X86_SIM_X86_JMP(0xfc3, 0x2b61, x86_l_2b61);
x86_l_fc8:
	/* 0xfc8: mov    BYTE PTR [rbp+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_fcf:
	/* 0xfcf: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fd2:
	/* 0xfd2: jmp    2b61 <trace_ret_do_mmap+0x2b61> */
	X86_SIM_X86_JMP(0xfd2, 0x2b61, x86_l_2b61);
x86_l_fd7:
	/* 0xfd7: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fda:
	/* 0xfda: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fdd:
	/* 0xfdd: je     106a <trace_ret_do_mmap+0x106a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfdd, 0x106a, x86_l_106a);
x86_l_fe3:
	/* 0xfe3: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fe6:
	/* 0xfe6: je     106a <trace_ret_do_mmap+0x106a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe6, 0x106a, x86_l_106a);
x86_l_fec:
	/* 0xfec: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ff0:
	/* 0xff0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ff3:
	/* 0xff3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_ff9:
	/* 0xff9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ffc:
	/* 0xffc: jns    1005 <trace_ret_do_mmap+0x1005> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xffc, 0x1005, x86_l_1005);
x86_l_ffe:
	/* 0xffe: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1001:
	/* 0x1001: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1005:
	/* 0x1005: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1009:
	/* 0x1009: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_100c:
	/* 0x100c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1013:
	/* 0x1013: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_1016:
	/* 0x1016: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1019:
	/* 0x1019: jb     2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1019, 0x2b4a, x86_l_2b4a);
x86_l_101f:
	/* 0x101f: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1022:
	/* 0x1022: je     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1022, 0xefb, x86_l_efb);
x86_l_1028:
	/* 0x1028: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_102d:
	/* 0x102d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1033:
	/* 0x1033: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1036:
	/* 0x1036: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1039:
	/* 0x1039: jns    12b5 <trace_ret_do_mmap+0x12b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1039, 0x12b5, x86_l_12b5);
x86_l_103f:
	/* 0x103f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1043:
	/* 0x1043: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1046:
	/* 0x1046: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1049:
	/* 0x1049: je     10b9 <trace_ret_do_mmap+0x10b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1049, 0x10b9, x86_l_10b9);
x86_l_104b:
	/* 0x104b: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_104f:
	/* 0x104f: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1054:
	/* 0x1054: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1058:
	/* 0x1058: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_105b:
	/* 0x105b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_105e:
	/* 0x105e: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1063:
	/* 0x1063: jne    1046 <trace_ret_do_mmap+0x1046> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1063, 0x1046, x86_l_1046);
x86_l_1065:
	/* 0x1065: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1068:
	/* 0x1068: jmp    10be <trace_ret_do_mmap+0x10be> */
	X86_SIM_X86_JMP(0x1068, 0x10be, x86_l_10be);
x86_l_106a:
	/* 0x106a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_106d:
	/* 0x106d: jne    efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x106d, 0xefb, x86_l_efb);
x86_l_1073:
	/* 0x1073: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1076:
	/* 0x1076: je     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1076, 0xefb, x86_l_efb);
x86_l_107c:
	/* 0x107c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1080:
	/* 0x1080: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1083:
	/* 0x1083: jns    108a <trace_ret_do_mmap+0x108a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1083, 0x108a, x86_l_108a);
x86_l_1085:
	/* 0x1085: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1088:
	/* 0x1088: jmp    108d <trace_ret_do_mmap+0x108d> */
	X86_SIM_X86_JMP(0x1088, 0x108d, x86_l_108d);
x86_l_108a:
	/* 0x108a: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108d:
	/* 0x108d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1090:
	/* 0x1090: jns    1097 <trace_ret_do_mmap+0x1097> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1090, 0x1097, x86_l_1097);
x86_l_1092:
	/* 0x1092: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1095:
	/* 0x1095: jmp    1099 <trace_ret_do_mmap+0x1099> */
	X86_SIM_X86_JMP(0x1095, 0x1099, x86_l_1099);
x86_l_1097:
	/* 0x1097: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1099:
	/* 0x1099: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_109c:
	/* 0x109c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_109f:
	/* 0x109f: jns    10a6 <trace_ret_do_mmap+0x10a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x109f, 0x10a6, x86_l_10a6);
x86_l_10a1:
	/* 0x10a1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10a4:
	/* 0x10a4: jmp    10a8 <trace_ret_do_mmap+0x10a8> */
	X86_SIM_X86_JMP(0x10a4, 0x10a8, x86_l_10a8);
x86_l_10a6:
	/* 0x10a6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10a8:
	/* 0x10a8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10ac:
	/* 0x10ac: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10af:
	/* 0x10af: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10b2:
	/* 0x10b2: jns    10ec <trace_ret_do_mmap+0x10ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b2, 0x10ec, x86_l_10ec);
x86_l_10b4:
	/* 0x10b4: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b7:
	/* 0x10b7: jmp    10ee <trace_ret_do_mmap+0x10ee> */
	X86_SIM_X86_JMP(0x10b7, 0x10ee, x86_l_10ee);
x86_l_10b9:
	/* 0x10b9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_10be:
	/* 0x10be: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_10c2:
	/* 0x10c2: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10c7:
	/* 0x10c7: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10cc:
	/* 0x10cc: jl     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_L, 0x10cc, 0xefb, x86_l_efb);
x86_l_10d2:
	/* 0x10d2: lea    edx,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10d6:
	/* 0x10d6: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_10dc:
	/* 0x10dc: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_10e1:
	/* 0x10e1: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10e4:
	/* 0x10e4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10e7:
	/* 0x10e7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10ea:
	/* 0x10ea: js     10b4 <trace_ret_do_mmap+0x10b4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10ea, 0x10b4, x86_l_10b4);
x86_l_10ec:
	/* 0x10ec: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ee:
	/* 0x10ee: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10f2:
	/* 0x10f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10f5:
	/* 0x10f5: jns    10fc <trace_ret_do_mmap+0x10fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10f5, 0x10fc, x86_l_10fc);
x86_l_10f7:
	/* 0x10f7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10fa:
	/* 0x10fa: jmp    10fe <trace_ret_do_mmap+0x10fe> */
	X86_SIM_X86_JMP(0x10fa, 0x10fe, x86_l_10fe);
x86_l_10fc:
	/* 0x10fc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10fe:
	/* 0x10fe: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1101:
	/* 0x1101: je     118e <trace_ret_do_mmap+0x118e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1101, 0x118e, x86_l_118e);
x86_l_1107:
	/* 0x1107: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_110a:
	/* 0x110a: je     118e <trace_ret_do_mmap+0x118e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x110a, 0x118e, x86_l_118e);
x86_l_1110:
	/* 0x1110: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1114:
	/* 0x1114: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1117:
	/* 0x1117: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_111d:
	/* 0x111d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1120:
	/* 0x1120: jns    1129 <trace_ret_do_mmap+0x1129> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1120, 0x1129, x86_l_1129);
x86_l_1122:
	/* 0x1122: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1125:
	/* 0x1125: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1129:
	/* 0x1129: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_112d:
	/* 0x112d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1130:
	/* 0x1130: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1137:
	/* 0x1137: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_113a:
	/* 0x113a: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_113d:
	/* 0x113d: jb     2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x113d, 0x2b4a, x86_l_2b4a);
x86_l_1143:
	/* 0x1143: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1146:
	/* 0x1146: je     184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1146, 0x184c, x86_l_184c);
x86_l_114c:
	/* 0x114c: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1151:
	/* 0x1151: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1157:
	/* 0x1157: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_115a:
	/* 0x115a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_115d:
	/* 0x115d: jns    ee9 <trace_ret_do_mmap+0xee9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x115d, 0xee9, x86_l_ee9);
x86_l_1163:
	/* 0x1163: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1167:
	/* 0x1167: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116a:
	/* 0x116a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_116d:
	/* 0x116d: je     11dc <trace_ret_do_mmap+0x11dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116d, 0x11dc, x86_l_11dc);
x86_l_116f:
	/* 0x116f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1173:
	/* 0x1173: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1178:
	/* 0x1178: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_117c:
	/* 0x117c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_117f:
	/* 0x117f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1182:
	/* 0x1182: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1187:
	/* 0x1187: jne    116a <trace_ret_do_mmap+0x116a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1187, 0x116a, x86_l_116a);
x86_l_1189:
	/* 0x1189: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_118c:
	/* 0x118c: jmp    11e1 <trace_ret_do_mmap+0x11e1> */
	X86_SIM_X86_JMP(0x118c, 0x11e1, x86_l_11e1);
x86_l_118e:
	/* 0x118e: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1191:
	/* 0x1191: jne    184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1191, 0x184c, x86_l_184c);
x86_l_1197:
	/* 0x1197: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_119a:
	/* 0x119a: je     184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x119a, 0x184c, x86_l_184c);
x86_l_11a0:
	/* 0x11a0: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11a4:
	/* 0x11a4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11a7:
	/* 0x11a7: jns    11ae <trace_ret_do_mmap+0x11ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11a7, 0x11ae, x86_l_11ae);
x86_l_11a9:
	/* 0x11a9: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ac:
	/* 0x11ac: jmp    11b0 <trace_ret_do_mmap+0x11b0> */
	X86_SIM_X86_JMP(0x11ac, 0x11b0, x86_l_11b0);
x86_l_11ae:
	/* 0x11ae: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b0:
	/* 0x11b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11b3:
	/* 0x11b3: jns    11ba <trace_ret_do_mmap+0x11ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11b3, 0x11ba, x86_l_11ba);
x86_l_11b5:
	/* 0x11b5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11b8:
	/* 0x11b8: jmp    11bc <trace_ret_do_mmap+0x11bc> */
	X86_SIM_X86_JMP(0x11b8, 0x11bc, x86_l_11bc);
x86_l_11ba:
	/* 0x11ba: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11bc:
	/* 0x11bc: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11bf:
	/* 0x11bf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11c2:
	/* 0x11c2: jns    11c9 <trace_ret_do_mmap+0x11c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11c2, 0x11c9, x86_l_11c9);
x86_l_11c4:
	/* 0x11c4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11c7:
	/* 0x11c7: jmp    11cb <trace_ret_do_mmap+0x11cb> */
	X86_SIM_X86_JMP(0x11c7, 0x11cb, x86_l_11cb);
x86_l_11c9:
	/* 0x11c9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11cb:
	/* 0x11cb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11cf:
	/* 0x11cf: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_11d2:
	/* 0x11d2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11d5:
	/* 0x11d5: jns    120f <trace_ret_do_mmap+0x120f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11d5, 0x120f, x86_l_120f);
x86_l_11d7:
	/* 0x11d7: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11da:
	/* 0x11da: jmp    1211 <trace_ret_do_mmap+0x1211> */
	X86_SIM_X86_JMP(0x11da, 0x1211, x86_l_1211);
x86_l_11dc:
	/* 0x11dc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_11e1:
	/* 0x11e1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_11e5:
	/* 0x11e5: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11ea:
	/* 0x11ea: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11ef:
	/* 0x11ef: jl     184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x11ef, 0x184c, x86_l_184c);
x86_l_11f5:
	/* 0x11f5: lea    edi,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_11f9:
	/* 0x11f9: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_11ff:
	/* 0x11ff: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1204:
	/* 0x1204: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1207:
	/* 0x1207: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_120a:
	/* 0x120a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_120d:
	/* 0x120d: js     11d7 <trace_ret_do_mmap+0x11d7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x120d, 0x11d7, x86_l_11d7);
x86_l_120f:
	/* 0x120f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1211:
	/* 0x1211: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1215:
	/* 0x1215: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1218:
	/* 0x1218: jns    121f <trace_ret_do_mmap+0x121f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1218, 0x121f, x86_l_121f);
x86_l_121a:
	/* 0x121a: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_121d:
	/* 0x121d: jmp    1222 <trace_ret_do_mmap+0x1222> */
	X86_SIM_X86_JMP(0x121d, 0x1222, x86_l_1222);
x86_l_121f:
	/* 0x121f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1222:
	/* 0x1222: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1225:
	/* 0x1225: je     12bd <trace_ret_do_mmap+0x12bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1225, 0x12bd, x86_l_12bd);
x86_l_122b:
	/* 0x122b: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_122e:
	/* 0x122e: je     12bd <trace_ret_do_mmap+0x12bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x122e, 0x12bd, x86_l_12bd);
x86_l_1234:
	/* 0x1234: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1238:
	/* 0x1238: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_123b:
	/* 0x123b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1241:
	/* 0x1241: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1244:
	/* 0x1244: jns    124d <trace_ret_do_mmap+0x124d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1244, 0x124d, x86_l_124d);
x86_l_1246:
	/* 0x1246: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1249:
	/* 0x1249: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_124d:
	/* 0x124d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1251:
	/* 0x1251: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1254:
	/* 0x1254: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_125b:
	/* 0x125b: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_125e:
	/* 0x125e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1261:
	/* 0x1261: jb     2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1261, 0x2b4a, x86_l_2b4a);
x86_l_1267:
	/* 0x1267: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_126a:
	/* 0x126a: je     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x126a, 0xefb, x86_l_efb);
x86_l_1270:
	/* 0x1270: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1275:
	/* 0x1275: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_127b:
	/* 0x127b: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_127e:
	/* 0x127e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1281:
	/* 0x1281: jns    12b5 <trace_ret_do_mmap+0x12b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1281, 0x12b5, x86_l_12b5);
x86_l_1283:
	/* 0x1283: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1287:
	/* 0x1287: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_128a:
	/* 0x128a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_128d:
	/* 0x128d: je     175d <trace_ret_do_mmap+0x175d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x128d, 0x175d, x86_l_175d);
x86_l_1293:
	/* 0x1293: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1297:
	/* 0x1297: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_129c:
	/* 0x129c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_12a0:
	/* 0x12a0: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12a3:
	/* 0x12a3: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_12a6:
	/* 0x12a6: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12ab:
	/* 0x12ab: jne    128a <trace_ret_do_mmap+0x128a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12ab, 0x128a, x86_l_128a);
x86_l_12ad:
	/* 0x12ad: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_12b0:
	/* 0x12b0: jmp    1762 <trace_ret_do_mmap+0x1762> */
	X86_SIM_X86_JMP(0x12b0, 0x1762, x86_l_1762);
x86_l_12b5:
	/* 0x12b5: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12b8:
	/* 0x12b8: jmp    ee9 <trace_ret_do_mmap+0xee9> */
	X86_SIM_X86_JMP(0x12b8, 0xee9, x86_l_ee9);
x86_l_12bd:
	/* 0x12bd: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_12c0:
	/* 0x12c0: jne    efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12c0, 0xefb, x86_l_efb);
x86_l_12c6:
	/* 0x12c6: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12c9:
	/* 0x12c9: je     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12c9, 0xefb, x86_l_efb);
x86_l_12cf:
	/* 0x12cf: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12d3:
	/* 0x12d3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12d6:
	/* 0x12d6: jns    12dd <trace_ret_do_mmap+0x12dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12d6, 0x12dd, x86_l_12dd);
x86_l_12d8:
	/* 0x12d8: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12db:
	/* 0x12db: jmp    12e0 <trace_ret_do_mmap+0x12e0> */
	X86_SIM_X86_JMP(0x12db, 0x12e0, x86_l_12e0);
x86_l_12dd:
	/* 0x12dd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12e0:
	/* 0x12e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12e3:
	/* 0x12e3: jns    12ea <trace_ret_do_mmap+0x12ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12e3, 0x12ea, x86_l_12ea);
x86_l_12e5:
	/* 0x12e5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12e8:
	/* 0x12e8: jmp    12ec <trace_ret_do_mmap+0x12ec> */
	X86_SIM_X86_JMP(0x12e8, 0x12ec, x86_l_12ec);
x86_l_12ea:
	/* 0x12ea: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ec:
	/* 0x12ec: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ef:
	/* 0x12ef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12f2:
	/* 0x12f2: jns    12f9 <trace_ret_do_mmap+0x12f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f2, 0x12f9, x86_l_12f9);
x86_l_12f4:
	/* 0x12f4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12f7:
	/* 0x12f7: jmp    12fb <trace_ret_do_mmap+0x12fb> */
	X86_SIM_X86_JMP(0x12f7, 0x12fb, x86_l_12fb);
x86_l_12f9:
	/* 0x12f9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12fb:
	/* 0x12fb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12ff:
	/* 0x12ff: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1302:
	/* 0x1302: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1305:
	/* 0x1305: jns    1794 <trace_ret_do_mmap+0x1794> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1305, 0x1794, x86_l_1794);
x86_l_130b:
	/* 0x130b: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_130e:
	/* 0x130e: jmp    1796 <trace_ret_do_mmap+0x1796> */
	X86_SIM_X86_JMP(0x130e, 0x1796, x86_l_1796);
x86_l_1313:
	/* 0x1313: mov    eax,DWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_131a:
	/* 0x131a: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_131e:
	/* 0x131e: mov    DWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1326:
	/* 0x1326: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_132d:
	/* 0x132d: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1332:
	/* 0x1332: call   1337 <trace_ret_do_mmap+0x1337> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1337:
	/* 0x1337: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_133a:
	/* 0x133a: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x133a, 0x142e, x86_l_142e);
x86_l_1340:
	/* 0x1340: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1343:
	/* 0x1343: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1347:
	/* 0x1347: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_134b:
	/* 0x134b: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1350:
	/* 0x1350: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1353:
	/* 0x1353: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1355:
	/* 0x1355: call   135a <trace_ret_do_mmap+0x135a> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_135a:
	/* 0x135a: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1361:
	/* 0x1361: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1366:
	/* 0x1366: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_136b:
	/* 0x136b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_136e:
	/* 0x136e: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1371:
	/* 0x1371: call   1376 <trace_ret_do_mmap+0x1376> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1376:
	/* 0x1376: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_137b:
	/* 0x137b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_137e:
	/* 0x137e: call   1383 <trace_ret_do_mmap+0x1383> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1383:
	/* 0x1383: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_138b:
	/* 0x138b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_138e:
	/* 0x138e: jne    262 <trace_ret_do_mmap+0x262> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x138e, 0x262, x86_l_262);
x86_l_1394:
	/* 0x1394: jmp    142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JMP(0x1394, 0x142e, x86_l_142e);
x86_l_1399:
	/* 0x1399: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_13a0:
	/* 0x13a0: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13a4:
	/* 0x13a4: mov    DWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_13ac:
	/* 0x13ac: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_13b3:
	/* 0x13b3: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_13b8:
	/* 0x13b8: call   13bd <trace_ret_do_mmap+0x13bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_13bd:
	/* 0x13bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13c0:
	/* 0x13c0: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c0, 0x142e, x86_l_142e);
x86_l_13c2:
	/* 0x13c2: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13c5:
	/* 0x13c5: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13c9:
	/* 0x13c9: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13cd:
	/* 0x13cd: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_13d2:
	/* 0x13d2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13d5:
	/* 0x13d5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13d7:
	/* 0x13d7: call   13dc <trace_ret_do_mmap+0x13dc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_13dc:
	/* 0x13dc: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_13e3:
	/* 0x13e3: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13e8:
	/* 0x13e8: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_13ed:
	/* 0x13ed: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_13f0:
	/* 0x13f0: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13f3:
	/* 0x13f3: call   13f8 <trace_ret_do_mmap+0x13f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_13f8:
	/* 0x13f8: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13fd:
	/* 0x13fd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1400:
	/* 0x1400: call   1405 <trace_ret_do_mmap+0x1405> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1405:
	/* 0x1405: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_140a:
	/* 0x140a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_140d:
	/* 0x140d: je     142e <trace_ret_do_mmap+0x142e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x140d, 0x142e, x86_l_142e);
x86_l_140f:
	/* 0x140f: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_1416:
	/* 0x1416: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_141a:
	/* 0x141a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_141d:
	/* 0x141d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1420:
	/* 0x1420: jns    1601 <trace_ret_do_mmap+0x1601> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1420, 0x1601, x86_l_1601);
x86_l_1426:
	/* 0x1426: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1429:
	/* 0x1429: jmp    1604 <trace_ret_do_mmap+0x1604> */
	X86_SIM_X86_JMP(0x1429, 0x1604, x86_l_1604);
x86_l_142e:
	/* 0x142e: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1430:
	/* 0x1430: jmp    3718 <trace_ret_do_mmap+0x3718> */
	X86_SIM_X86_JMP(0x1430, 0x3718, x86_l_3718);
x86_l_1435:
	/* 0x1435: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1438:
	/* 0x1438: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_143c:
	/* 0x143c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_143f:
	/* 0x143f: jns    15e4 <trace_ret_do_mmap+0x15e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x143f, 0x15e4, x86_l_15e4);
x86_l_1445:
	/* 0x1445: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1448:
	/* 0x1448: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_144f:
	/* 0x144f: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1453:
	/* 0x1453: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_145a:
	/* 0x145a: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_145e:
	/* 0x145e: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1465:
	/* 0x1465: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1469:
	/* 0x1469: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1470:
	/* 0x1470: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1474:
	/* 0x1474: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_147b:
	/* 0x147b: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_147f:
	/* 0x147f: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1486:
	/* 0x1486: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_148a:
	/* 0x148a: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1491:
	/* 0x1491: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1495:
	/* 0x1495: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_149c:
	/* 0x149c: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_14a0:
	/* 0x14a0: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_14a7:
	/* 0x14a7: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_14ab:
	/* 0x14ab: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_14b2:
	/* 0x14b2: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_14b6:
	/* 0x14b6: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_14bd:
	/* 0x14bd: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_14c1:
	/* 0x14c1: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_14c8:
	/* 0x14c8: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_14cc:
	/* 0x14cc: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_14d3:
	/* 0x14d3: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_14d7:
	/* 0x14d7: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_14de:
	/* 0x14de: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_14e2:
	/* 0x14e2: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_14e9:
	/* 0x14e9: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_14ed:
	/* 0x14ed: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_14f4:
	/* 0x14f4: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_14fb:
	/* 0x14fb: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_1502:
	/* 0x1502: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1509:
	/* 0x1509: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1510:
	/* 0x1510: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1517:
	/* 0x1517: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_151e:
	/* 0x151e: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1525:
	/* 0x1525: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_152c:
	/* 0x152c: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1533:
	/* 0x1533: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_153a:
	/* 0x153a: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1541:
	/* 0x1541: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1548:
	/* 0x1548: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_154f:
	/* 0x154f: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1556:
	/* 0x1556: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_155d:
	/* 0x155d: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1564:
	/* 0x1564: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_156b:
	/* 0x156b: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1572:
	/* 0x1572: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1579:
	/* 0x1579: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1580:
	/* 0x1580: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1587:
	/* 0x1587: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_158e:
	/* 0x158e: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1595:
	/* 0x1595: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_159c:
	/* 0x159c: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_15a3:
	/* 0x15a3: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_15aa:
	/* 0x15aa: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_15b1:
	/* 0x15b1: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_15b8:
	/* 0x15b8: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_15bf:
	/* 0x15bf: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_15c6:
	/* 0x15c6: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_15cd:
	/* 0x15cd: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_15d4:
	/* 0x15d4: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_15da:
	/* 0x15da: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_15df:
	/* 0x15df: jmp    354 <trace_ret_do_mmap+0x354> */
	X86_SIM_X86_JMP(0x15df, 0x354, x86_l_354);
x86_l_15e4:
	/* 0x15e4: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_15eb:
	/* 0x15eb: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15ed:
	/* 0x15ed: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_15f2:
	/* 0x15f2: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_15f5:
	/* 0x15f5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15f7:
	/* 0x15f7: call   15fc <trace_ret_do_mmap+0x15fc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_15fc:
	/* 0x15fc: jmp    3718 <trace_ret_do_mmap+0x3718> */
	X86_SIM_X86_JMP(0x15fc, 0x3718, x86_l_3718);
x86_l_1601:
	/* 0x1601: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1604:
	/* 0x1604: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1608:
	/* 0x1608: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_160b:
	/* 0x160b: jns    1612 <trace_ret_do_mmap+0x1612> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x160b, 0x1612, x86_l_1612);
x86_l_160d:
	/* 0x160d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1610:
	/* 0x1610: jmp    1614 <trace_ret_do_mmap+0x1614> */
	X86_SIM_X86_JMP(0x1610, 0x1614, x86_l_1614);
x86_l_1612:
	/* 0x1612: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1614:
	/* 0x1614: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1618:
	/* 0x1618: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_161a:
	/* 0x161a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_161d:
	/* 0x161d: jns    1624 <trace_ret_do_mmap+0x1624> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161d, 0x1624, x86_l_1624);
x86_l_161f:
	/* 0x161f: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1622:
	/* 0x1622: jmp    1627 <trace_ret_do_mmap+0x1627> */
	X86_SIM_X86_JMP(0x1622, 0x1627, x86_l_1627);
x86_l_1624:
	/* 0x1624: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1627:
	/* 0x1627: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_162c:
	/* 0x162c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_162f:
	/* 0x162f: jns    1633 <trace_ret_do_mmap+0x1633> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162f, 0x1633, x86_l_1633);
x86_l_1631:
	/* 0x1631: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1633:
	/* 0x1633: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1638:
	/* 0x1638: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_163b:
	/* 0x163b: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_163f:
	/* 0x163f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1642:
	/* 0x1642: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1644:
	/* 0x1644: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1647:
	/* 0x1647: jns    164e <trace_ret_do_mmap+0x164e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1647, 0x164e, x86_l_164e);
x86_l_1649:
	/* 0x1649: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_164c:
	/* 0x164c: jmp    1650 <trace_ret_do_mmap+0x1650> */
	X86_SIM_X86_JMP(0x164c, 0x1650, x86_l_1650);
x86_l_164e:
	/* 0x164e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1650:
	/* 0x1650: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1653:
	/* 0x1653: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1656:
	/* 0x1656: jns    165a <trace_ret_do_mmap+0x165a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1656, 0x165a, x86_l_165a);
x86_l_1658:
	/* 0x1658: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_165a:
	/* 0x165a: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_165c:
	/* 0x165c: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1660:
	/* 0x1660: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1663:
	/* 0x1663: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1667:
	/* 0x1667: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1669:
	/* 0x1669: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_166c:
	/* 0x166c: jns    1670 <trace_ret_do_mmap+0x1670> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x166c, 0x1670, x86_l_1670);
x86_l_166e:
	/* 0x166e: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1670:
	/* 0x1670: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1675:
	/* 0x1675: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1678:
	/* 0x1678: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_167b:
	/* 0x167b: jns    1682 <trace_ret_do_mmap+0x1682> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x167b, 0x1682, x86_l_1682);
x86_l_167d:
	/* 0x167d: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1680:
	/* 0x1680: jmp    1684 <trace_ret_do_mmap+0x1684> */
	X86_SIM_X86_JMP(0x1680, 0x1684, x86_l_1684);
x86_l_1682:
	/* 0x1682: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1684:
	/* 0x1684: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1688:
	/* 0x1688: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_168a:
	/* 0x168a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_168d:
	/* 0x168d: jns    1694 <trace_ret_do_mmap+0x1694> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x168d, 0x1694, x86_l_1694);
x86_l_168f:
	/* 0x168f: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1692:
	/* 0x1692: jmp    1696 <trace_ret_do_mmap+0x1696> */
	X86_SIM_X86_JMP(0x1692, 0x1696, x86_l_1696);
x86_l_1694:
	/* 0x1694: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1696:
	/* 0x1696: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1699:
	/* 0x1699: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_169c:
	/* 0x169c: jns    16a0 <trace_ret_do_mmap+0x16a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x169c, 0x16a0, x86_l_16a0);
x86_l_169e:
	/* 0x169e: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a0:
	/* 0x16a0: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16a2:
	/* 0x16a2: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16a6:
	/* 0x16a6: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16a9:
	/* 0x16a9: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16ad:
	/* 0x16ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16af:
	/* 0x16af: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16b2:
	/* 0x16b2: jns    16b6 <trace_ret_do_mmap+0x16b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16b2, 0x16b6, x86_l_16b6);
x86_l_16b4:
	/* 0x16b4: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16b6:
	/* 0x16b6: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_16bb:
	/* 0x16bb: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16be:
	/* 0x16be: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c0:
	/* 0x16c0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16c3:
	/* 0x16c3: jns    16ca <trace_ret_do_mmap+0x16ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16c3, 0x16ca, x86_l_16ca);
x86_l_16c5:
	/* 0x16c5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16c8:
	/* 0x16c8: jmp    16cc <trace_ret_do_mmap+0x16cc> */
	X86_SIM_X86_JMP(0x16c8, 0x16cc, x86_l_16cc);
x86_l_16ca:
	/* 0x16ca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16cc:
	/* 0x16cc: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16cf:
	/* 0x16cf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16d2:
	/* 0x16d2: jns    16d6 <trace_ret_do_mmap+0x16d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16d2, 0x16d6, x86_l_16d6);
x86_l_16d4:
	/* 0x16d4: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16d6:
	/* 0x16d6: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16d8:
	/* 0x16d8: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16dc:
	/* 0x16dc: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16df:
	/* 0x16df: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_16e3:
	/* 0x16e3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16e5:
	/* 0x16e5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16e8:
	/* 0x16e8: jns    16ef <trace_ret_do_mmap+0x16ef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e8, 0x16ef, x86_l_16ef);
x86_l_16ea:
	/* 0x16ea: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16ed:
	/* 0x16ed: jmp    16f1 <trace_ret_do_mmap+0x16f1> */
	X86_SIM_X86_JMP(0x16ed, 0x16f1, x86_l_16f1);
x86_l_16ef:
	/* 0x16ef: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16f1:
	/* 0x16f1: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_16f5:
	/* 0x16f5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16f8:
	/* 0x16f8: jns    16fc <trace_ret_do_mmap+0x16fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f8, 0x16fc, x86_l_16fc);
x86_l_16fa:
	/* 0x16fa: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16fc:
	/* 0x16fc: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1701:
	/* 0x1701: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1704:
	/* 0x1704: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1706:
	/* 0x1706: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1709:
	/* 0x1709: jns    1710 <trace_ret_do_mmap+0x1710> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1709, 0x1710, x86_l_1710);
x86_l_170b:
	/* 0x170b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_170e:
	/* 0x170e: jmp    1712 <trace_ret_do_mmap+0x1712> */
	X86_SIM_X86_JMP(0x170e, 0x1712, x86_l_1712);
x86_l_1710:
	/* 0x1710: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1712:
	/* 0x1712: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1715:
	/* 0x1715: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1718:
	/* 0x1718: jns    171c <trace_ret_do_mmap+0x171c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1718, 0x171c, x86_l_171c);
x86_l_171a:
	/* 0x171a: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_171c:
	/* 0x171c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_171e:
	/* 0x171e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1722:
	/* 0x1722: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1725:
	/* 0x1725: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1729:
	/* 0x1729: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_172b:
	/* 0x172b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_172e:
	/* 0x172e: jns    1735 <trace_ret_do_mmap+0x1735> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x172e, 0x1735, x86_l_1735);
x86_l_1730:
	/* 0x1730: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1733:
	/* 0x1733: jmp    1737 <trace_ret_do_mmap+0x1737> */
	X86_SIM_X86_JMP(0x1733, 0x1737, x86_l_1737);
x86_l_1735:
	/* 0x1735: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1737:
	/* 0x1737: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_173b:
	/* 0x173b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_173e:
	/* 0x173e: jns    1742 <trace_ret_do_mmap+0x1742> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x173e, 0x1742, x86_l_1742);
x86_l_1740:
	/* 0x1740: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1742:
	/* 0x1742: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1744:
	/* 0x1744: jne    18b3 <trace_ret_do_mmap+0x18b3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1744, 0x18b3, x86_l_18b3);
x86_l_174a:
	/* 0x174a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174c:
	/* 0x174c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_174f:
	/* 0x174f: jns    1889 <trace_ret_do_mmap+0x1889> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x174f, 0x1889, x86_l_1889);
x86_l_1755:
	/* 0x1755: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1758:
	/* 0x1758: jmp    188b <trace_ret_do_mmap+0x188b> */
	X86_SIM_X86_JMP(0x1758, 0x188b, x86_l_188b);
x86_l_175d:
	/* 0x175d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1762:
	/* 0x1762: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1766:
	/* 0x1766: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_176b:
	/* 0x176b: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1770:
	/* 0x1770: jl     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1770, 0xefb, x86_l_efb);
x86_l_1776:
	/* 0x1776: lea    edx,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_177a:
	/* 0x177a: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1780:
	/* 0x1780: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1785:
	/* 0x1785: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1788:
	/* 0x1788: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_178b:
	/* 0x178b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_178e:
	/* 0x178e: js     130b <trace_ret_do_mmap+0x130b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x178e, 0x130b, x86_l_130b);
x86_l_1794:
	/* 0x1794: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1796:
	/* 0x1796: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_179a:
	/* 0x179a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_179d:
	/* 0x179d: jns    17a4 <trace_ret_do_mmap+0x17a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x179d, 0x17a4, x86_l_17a4);
x86_l_179f:
	/* 0x179f: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a2:
	/* 0x17a2: jmp    17a6 <trace_ret_do_mmap+0x17a6> */
	X86_SIM_X86_JMP(0x17a2, 0x17a6, x86_l_17a6);
x86_l_17a4:
	/* 0x17a4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a6:
	/* 0x17a6: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17a9:
	/* 0x17a9: je     1834 <trace_ret_do_mmap+0x1834> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17a9, 0x1834, x86_l_1834);
x86_l_17af:
	/* 0x17af: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17b2:
	/* 0x17b2: je     1834 <trace_ret_do_mmap+0x1834> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b2, 0x1834, x86_l_1834);
x86_l_17b8:
	/* 0x17b8: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17bc:
	/* 0x17bc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17bf:
	/* 0x17bf: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_17c5:
	/* 0x17c5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17c8:
	/* 0x17c8: jns    17d1 <trace_ret_do_mmap+0x17d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c8, 0x17d1, x86_l_17d1);
x86_l_17ca:
	/* 0x17ca: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17cd:
	/* 0x17cd: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17d1:
	/* 0x17d1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_17d5:
	/* 0x17d5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_17d8:
	/* 0x17d8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_17df:
	/* 0x17df: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_17e2:
	/* 0x17e2: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_17e5:
	/* 0x17e5: jb     2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x17e5, 0x2b4a, x86_l_2b4a);
x86_l_17eb:
	/* 0x17eb: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_17ee:
	/* 0x17ee: je     184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ee, 0x184c, x86_l_184c);
x86_l_17f0:
	/* 0x17f0: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17f5:
	/* 0x17f5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_17fb:
	/* 0x17fb: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17fe:
	/* 0x17fe: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1801:
	/* 0x1801: jns    ee9 <trace_ret_do_mmap+0xee9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1801, 0xee9, x86_l_ee9);
x86_l_1807:
	/* 0x1807: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_180b:
	/* 0x180b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_180e:
	/* 0x180e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1811:
	/* 0x1811: je     1b5c <trace_ret_do_mmap+0x1b5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1811, 0x1b5c, x86_l_1b5c);
x86_l_1817:
	/* 0x1817: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_181b:
	/* 0x181b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1820:
	/* 0x1820: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1824:
	/* 0x1824: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1827:
	/* 0x1827: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_182a:
	/* 0x182a: jne    180e <trace_ret_do_mmap+0x180e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x182a, 0x180e, x86_l_180e);
x86_l_182c:
	/* 0x182c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_182f:
	/* 0x182f: jmp    1b61 <trace_ret_do_mmap+0x1b61> */
	X86_SIM_X86_JMP(0x182f, 0x1b61, x86_l_1b61);
x86_l_1834:
	/* 0x1834: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1837:
	/* 0x1837: jne    184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1837, 0x184c, x86_l_184c);
x86_l_1839:
	/* 0x1839: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_183c:
	/* 0x183c: je     184c <trace_ret_do_mmap+0x184c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x183c, 0x184c, x86_l_184c);
x86_l_183e:
	/* 0x183e: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1842:
	/* 0x1842: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1845:
	/* 0x1845: jns    1854 <trace_ret_do_mmap+0x1854> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1845, 0x1854, x86_l_1854);
x86_l_1847:
	/* 0x1847: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_184a:
	/* 0x184a: jmp    1856 <trace_ret_do_mmap+0x1856> */
	X86_SIM_X86_JMP(0x184a, 0x1856, x86_l_1856);
x86_l_184c:
	/* 0x184c: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_184f:
	/* 0x184f: jmp    efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JMP(0x184f, 0xefb, x86_l_efb);
x86_l_1854:
	/* 0x1854: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1856:
	/* 0x1856: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1859:
	/* 0x1859: jns    1860 <trace_ret_do_mmap+0x1860> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1859, 0x1860, x86_l_1860);
x86_l_185b:
	/* 0x185b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_185e:
	/* 0x185e: jmp    1862 <trace_ret_do_mmap+0x1862> */
	X86_SIM_X86_JMP(0x185e, 0x1862, x86_l_1862);
x86_l_1860:
	/* 0x1860: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1862:
	/* 0x1862: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1865:
	/* 0x1865: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1868:
	/* 0x1868: jns    186f <trace_ret_do_mmap+0x186f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1868, 0x186f, x86_l_186f);
x86_l_186a:
	/* 0x186a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_186d:
	/* 0x186d: jmp    1871 <trace_ret_do_mmap+0x1871> */
	X86_SIM_X86_JMP(0x186d, 0x1871, x86_l_1871);
x86_l_186f:
	/* 0x186f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1871:
	/* 0x1871: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1875:
	/* 0x1875: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1878:
	/* 0x1878: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_187b:
	/* 0x187b: jns    1b9d <trace_ret_do_mmap+0x1b9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x187b, 0x1b9d, x86_l_1b9d);
x86_l_1881:
	/* 0x1881: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1884:
	/* 0x1884: jmp    1b9f <trace_ret_do_mmap+0x1b9f> */
	X86_SIM_X86_JMP(0x1884, 0x1b9f, x86_l_1b9f);
x86_l_1889:
	/* 0x1889: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_188b:
	/* 0x188b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_188e:
	/* 0x188e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1891:
	/* 0x1891: jns    1895 <trace_ret_do_mmap+0x1895> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1891, 0x1895, x86_l_1895);
x86_l_1893:
	/* 0x1893: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1895:
	/* 0x1895: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1897:
	/* 0x1897: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_189b:
	/* 0x189b: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_189e:
	/* 0x189e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_18a2:
	/* 0x18a2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18a4:
	/* 0x18a4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18a7:
	/* 0x18a7: jns    18ab <trace_ret_do_mmap+0x18ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18a7, 0x18ab, x86_l_18ab);
x86_l_18a9:
	/* 0x18a9: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ab:
	/* 0x18ab: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18b0:
	/* 0x18b0: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18b3:
	/* 0x18b3: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18b8:
	/* 0x18b8: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18bb:
	/* 0x18bb: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_18c2:
	/* 0x18c2: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18c5:
	/* 0x18c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c8:
	/* 0x18c8: jns    18cf <trace_ret_do_mmap+0x18cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c8, 0x18cf, x86_l_18cf);
x86_l_18ca:
	/* 0x18ca: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18cd:
	/* 0x18cd: jmp    18d1 <trace_ret_do_mmap+0x18d1> */
	X86_SIM_X86_JMP(0x18cd, 0x18d1, x86_l_18d1);
x86_l_18cf:
	/* 0x18cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18d1:
	/* 0x18d1: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_18d5:
	/* 0x18d5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18d7:
	/* 0x18d7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18da:
	/* 0x18da: jns    18e1 <trace_ret_do_mmap+0x18e1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18da, 0x18e1, x86_l_18e1);
x86_l_18dc:
	/* 0x18dc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18df:
	/* 0x18df: jmp    18e3 <trace_ret_do_mmap+0x18e3> */
	X86_SIM_X86_JMP(0x18df, 0x18e3, x86_l_18e3);
x86_l_18e1:
	/* 0x18e1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18e3:
	/* 0x18e3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18e6:
	/* 0x18e6: jns    18ea <trace_ret_do_mmap+0x18ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18e6, 0x18ea, x86_l_18ea);
x86_l_18e8:
	/* 0x18e8: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ea:
	/* 0x18ea: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18ef:
	/* 0x18ef: mov    DWORD PTR [rbp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_18f2:
	/* 0x18f2: call   18f7 <trace_ret_do_mmap+0x18f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_18f7:
	/* 0x18f7: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18fa:
	/* 0x18fa: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18fe:
	/* 0x18fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1901:
	/* 0x1901: jns    1908 <trace_ret_do_mmap+0x1908> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1901, 0x1908, x86_l_1908);
x86_l_1903:
	/* 0x1903: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1906:
	/* 0x1906: jmp    190a <trace_ret_do_mmap+0x190a> */
	X86_SIM_X86_JMP(0x1906, 0x190a, x86_l_190a);
x86_l_1908:
	/* 0x1908: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_190a:
	/* 0x190a: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_190f:
	/* 0x190f: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1912:
	/* 0x1912: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1916:
	/* 0x1916: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1919:
	/* 0x1919: jns    1920 <trace_ret_do_mmap+0x1920> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1919, 0x1920, x86_l_1920);
x86_l_191b:
	/* 0x191b: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_191e:
	/* 0x191e: jmp    1922 <trace_ret_do_mmap+0x1922> */
	X86_SIM_X86_JMP(0x191e, 0x1922, x86_l_1922);
x86_l_1920:
	/* 0x1920: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1922:
	/* 0x1922: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1927:
	/* 0x1927: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_192b:
	/* 0x192b: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_192f:
	/* 0x192f: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1932:
	/* 0x1932: jns    193a <trace_ret_do_mmap+0x193a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1932, 0x193a, x86_l_193a);
x86_l_1934:
	/* 0x1934: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1938:
	/* 0x1938: jmp    193c <trace_ret_do_mmap+0x193c> */
	X86_SIM_X86_JMP(0x1938, 0x193c, x86_l_193c);
x86_l_193a:
	/* 0x193a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_193c:
	/* 0x193c: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1941:
	/* 0x1941: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1946:
	/* 0x1946: mov    QWORD PTR [r15+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_194a:
	/* 0x194a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_194d:
	/* 0x194d: jns    195a <trace_ret_do_mmap+0x195a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x194d, 0x195a, x86_l_195a);
x86_l_194f:
	/* 0x194f: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1951:
	/* 0x1951: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1953:
	/* 0x1953: je     195a <trace_ret_do_mmap+0x195a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1953, 0x195a, x86_l_195a);
x86_l_1955:
	/* 0x1955: or     BYTE PTR [r15+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_195a:
	/* 0x195a: lea    rdi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_195e:
	/* 0x195e: mov    QWORD PTR [r15+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_1966:
	/* 0x1966: mov    QWORD PTR [r15+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_196e:
	/* 0x196e: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1973:
	/* 0x1973: call   1978 <trace_ret_do_mmap+0x1978> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_1978:
	/* 0x1978: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_197b:
	/* 0x197b: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_197e:
	/* 0x197e: jns    1986 <trace_ret_do_mmap+0x1986> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x197e, 0x1986, x86_l_1986);
x86_l_1980:
	/* 0x1980: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1984:
	/* 0x1984: jmp    1988 <trace_ret_do_mmap+0x1988> */
	X86_SIM_X86_JMP(0x1984, 0x1988, x86_l_1988);
x86_l_1986:
	/* 0x1986: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1988:
	/* 0x1988: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_198d:
	/* 0x198d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1990:
	/* 0x1990: jns    1997 <trace_ret_do_mmap+0x1997> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1990, 0x1997, x86_l_1997);
x86_l_1992:
	/* 0x1992: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1995:
	/* 0x1995: jmp    1999 <trace_ret_do_mmap+0x1999> */
	X86_SIM_X86_JMP(0x1995, 0x1999, x86_l_1999);
x86_l_1997:
	/* 0x1997: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1999:
	/* 0x1999: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_199c:
	/* 0x199c: jns    19ef <trace_ret_do_mmap+0x19ef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x199c, 0x19ef, x86_l_19ef);
x86_l_199e:
	/* 0x199e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19a1:
	/* 0x19a1: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_19a6:
	/* 0x19a6: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19aa:
	/* 0x19aa: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_19af:
	/* 0x19af: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19b3:
	/* 0x19b3: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_19b8:
	/* 0x19b8: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19bc:
	/* 0x19bc: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_19c1:
	/* 0x19c1: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19c5:
	/* 0x19c5: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_19ca:
	/* 0x19ca: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19ce:
	/* 0x19ce: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_19d3:
	/* 0x19d3: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_19d7:
	/* 0x19d7: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_19df:
	/* 0x19df: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_19e3:
	/* 0x19e3: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_19eb:
	/* 0x19eb: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_19ef:
	/* 0x19ef: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19f2:
	/* 0x19f2: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_19f6:
	/* 0x19f6: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_19fb:
	/* 0x19fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19fe:
	/* 0x19fe: jns    1b25 <trace_ret_do_mmap+0x1b25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19fe, 0x1b25, x86_l_1b25);
x86_l_1a04:
	/* 0x1a04: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1a07:
	/* 0x1a07: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a09:
	/* 0x1a09: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1a0b:
	/* 0x1a0b: je     1b34 <trace_ret_do_mmap+0x1b34> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0b, 0x1b34, x86_l_1b34);
x86_l_1a11:
	/* 0x1a11: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1a15:
	/* 0x1a15: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_1a18:
	/* 0x1a18: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a1a:
	/* 0x1a1a: je     1b34 <trace_ret_do_mmap+0x1b34> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1a, 0x1b34, x86_l_1b34);
x86_l_1a20:
	/* 0x1a20: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1a24:
	/* 0x1a24: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_1a27:
	/* 0x1a27: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a29:
	/* 0x1a29: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a29, 0x1b3e, x86_l_1b3e);
x86_l_1a2f:
	/* 0x1a2f: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1a33:
	/* 0x1a33: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a38:
	/* 0x1a38: mov    BYTE PTR [rdx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_1a3b:
	/* 0x1a3b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a3d:
	/* 0x1a3d: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a3d, 0x1b3e, x86_l_1b3e);
x86_l_1a43:
	/* 0x1a43: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1a47:
	/* 0x1a47: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a4c:
	/* 0x1a4c: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1a4f:
	/* 0x1a4f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a51:
	/* 0x1a51: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a51, 0x1b3e, x86_l_1b3e);
x86_l_1a57:
	/* 0x1a57: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1a5b:
	/* 0x1a5b: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a60:
	/* 0x1a60: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_1a63:
	/* 0x1a63: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a65:
	/* 0x1a65: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a65, 0x1b3e, x86_l_1b3e);
x86_l_1a6b:
	/* 0x1a6b: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1a6f:
	/* 0x1a6f: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a74:
	/* 0x1a74: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_1a77:
	/* 0x1a77: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a79:
	/* 0x1a79: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a79, 0x1b3e, x86_l_1b3e);
x86_l_1a7f:
	/* 0x1a7f: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_1a83:
	/* 0x1a83: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a88:
	/* 0x1a88: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_1a8b:
	/* 0x1a8b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a8d:
	/* 0x1a8d: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8d, 0x1b3e, x86_l_1b3e);
x86_l_1a93:
	/* 0x1a93: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1a97:
	/* 0x1a97: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a9c:
	/* 0x1a9c: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_1a9f:
	/* 0x1a9f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1aa1:
	/* 0x1aa1: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aa1, 0x1b3e, x86_l_1b3e);
x86_l_1aa7:
	/* 0x1aa7: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1aab:
	/* 0x1aab: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ab0:
	/* 0x1ab0: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_1ab3:
	/* 0x1ab3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ab5:
	/* 0x1ab5: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ab5, 0x1b3e, x86_l_1b3e);
x86_l_1abb:
	/* 0x1abb: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_1abf:
	/* 0x1abf: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ac4:
	/* 0x1ac4: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1ac7:
	/* 0x1ac7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ac9:
	/* 0x1ac9: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac9, 0x1b3e, x86_l_1b3e);
x86_l_1acb:
	/* 0x1acb: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1acf:
	/* 0x1acf: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ad4:
	/* 0x1ad4: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1ad7:
	/* 0x1ad7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ad9:
	/* 0x1ad9: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ad9, 0x1b3e, x86_l_1b3e);
x86_l_1adb:
	/* 0x1adb: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1adf:
	/* 0x1adf: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ae4:
	/* 0x1ae4: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ae7:
	/* 0x1ae7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ae9:
	/* 0x1ae9: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ae9, 0x1b3e, x86_l_1b3e);
x86_l_1aeb:
	/* 0x1aeb: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1aef:
	/* 0x1aef: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1af4:
	/* 0x1af4: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1af7:
	/* 0x1af7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1af9:
	/* 0x1af9: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1af9, 0x1b3e, x86_l_1b3e);
x86_l_1afb:
	/* 0x1afb: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1aff:
	/* 0x1aff: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b04:
	/* 0x1b04: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1b07:
	/* 0x1b07: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1b09:
	/* 0x1b09: je     1b3e <trace_ret_do_mmap+0x1b3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b09, 0x1b3e, x86_l_1b3e);
x86_l_1b0b:
	/* 0x1b0b: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b10:
	/* 0x1b10: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_1b14:
	/* 0x1b14: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b19:
	/* 0x1b19: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b1e:
	/* 0x1b1e: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1b23:
	/* 0x1b23: jmp    1b34 <trace_ret_do_mmap+0x1b34> */
	X86_SIM_X86_JMP(0x1b23, 0x1b34, x86_l_1b34);
x86_l_1b25:
	/* 0x1b25: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1b2d:
	/* 0x1b2d: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b34:
	/* 0x1b34: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b39:
	/* 0x1b39: jmp    2a4 <trace_ret_do_mmap+0x2a4> */
	X86_SIM_X86_JMP(0x1b39, 0x2a4, x86_l_2a4);
x86_l_1b3e:
	/* 0x1b3e: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b43:
	/* 0x1b43: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b48:
	/* 0x1b48: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1b4d:
	/* 0x1b4d: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b52:
	/* 0x1b52: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b57:
	/* 0x1b57: jmp    2a4 <trace_ret_do_mmap+0x2a4> */
	X86_SIM_X86_JMP(0x1b57, 0x2a4, x86_l_2a4);
x86_l_1b5c:
	/* 0x1b5c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1b61:
	/* 0x1b61: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b65:
	/* 0x1b65: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1b65, 0x2ad7, x86_l_2ad7);
x86_l_1b6b:
	/* 0x1b6b: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b70:
	/* 0x1b70: lea    edi,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b74:
	/* 0x1b74: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1b7a:
	/* 0x1b7a: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1b7f:
	/* 0x1b7f: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b82:
	/* 0x1b82: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b87:
	/* 0x1b87: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b8c:
	/* 0x1b8c: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b91:
	/* 0x1b91: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b94:
	/* 0x1b94: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b97:
	/* 0x1b97: js     1881 <trace_ret_do_mmap+0x1881> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b97, 0x1881, x86_l_1881);
x86_l_1b9d:
	/* 0x1b9d: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b9f:
	/* 0x1b9f: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ba3:
	/* 0x1ba3: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ba6:
	/* 0x1ba6: jns    1bad <trace_ret_do_mmap+0x1bad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba6, 0x1bad, x86_l_1bad);
x86_l_1ba8:
	/* 0x1ba8: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bab:
	/* 0x1bab: jmp    1bb0 <trace_ret_do_mmap+0x1bb0> */
	X86_SIM_X86_JMP(0x1bab, 0x1bb0, x86_l_1bb0);
x86_l_1bad:
	/* 0x1bad: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bb0:
	/* 0x1bb0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bb3:
	/* 0x1bb3: je     1c37 <trace_ret_do_mmap+0x1c37> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bb3, 0x1c37, x86_l_1c37);
x86_l_1bb9:
	/* 0x1bb9: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1bbc:
	/* 0x1bbc: je     1c37 <trace_ret_do_mmap+0x1c37> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bbc, 0x1c37, x86_l_1c37);
x86_l_1bbe:
	/* 0x1bbe: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bc2:
	/* 0x1bc2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc5:
	/* 0x1bc5: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1bcb:
	/* 0x1bcb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bce:
	/* 0x1bce: jns    1bd7 <trace_ret_do_mmap+0x1bd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bce, 0x1bd7, x86_l_1bd7);
x86_l_1bd0:
	/* 0x1bd0: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bd3:
	/* 0x1bd3: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bd7:
	/* 0x1bd7: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1bdb:
	/* 0x1bdb: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1bde:
	/* 0x1bde: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1be5:
	/* 0x1be5: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_1be8:
	/* 0x1be8: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1beb:
	/* 0x1beb: jb     2b4a <trace_ret_do_mmap+0x2b4a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1beb, 0x2b4a, x86_l_2b4a);
x86_l_1bf1:
	/* 0x1bf1: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bf6:
	/* 0x1bf6: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1bf9:
	/* 0x1bf9: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bf9, 0x2ada, x86_l_2ada);
x86_l_1bff:
	/* 0x1bff: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c05:
	/* 0x1c05: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c08:
	/* 0x1c08: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c0b:
	/* 0x1c0b: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c0b, 0x292e, x86_l_292e);
x86_l_1c11:
	/* 0x1c11: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c15:
	/* 0x1c15: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c18:
	/* 0x1c18: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c1b:
	/* 0x1c1b: je     1c8b <trace_ret_do_mmap+0x1c8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c1b, 0x1c8b, x86_l_1c8b);
x86_l_1c1d:
	/* 0x1c1d: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c21:
	/* 0x1c21: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c26:
	/* 0x1c26: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c2a:
	/* 0x1c2a: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c2d:
	/* 0x1c2d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1c30:
	/* 0x1c30: jne    1c18 <trace_ret_do_mmap+0x1c18> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c30, 0x1c18, x86_l_1c18);
x86_l_1c32:
	/* 0x1c32: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1c35:
	/* 0x1c35: jmp    1c90 <trace_ret_do_mmap+0x1c90> */
	X86_SIM_X86_JMP(0x1c35, 0x1c90, x86_l_1c90);
x86_l_1c37:
	/* 0x1c37: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c3a:
	/* 0x1c3a: jne    efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c3a, 0xefb, x86_l_efb);
x86_l_1c40:
	/* 0x1c40: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c43:
	/* 0x1c43: je     efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c43, 0xefb, x86_l_efb);
x86_l_1c49:
	/* 0x1c49: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c4e:
	/* 0x1c4e: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c52:
	/* 0x1c52: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c55:
	/* 0x1c55: jns    1c5c <trace_ret_do_mmap+0x1c5c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c55, 0x1c5c, x86_l_1c5c);
x86_l_1c57:
	/* 0x1c57: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c5a:
	/* 0x1c5a: jmp    1c5f <trace_ret_do_mmap+0x1c5f> */
	X86_SIM_X86_JMP(0x1c5a, 0x1c5f, x86_l_1c5f);
x86_l_1c5c:
	/* 0x1c5c: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c5f:
	/* 0x1c5f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c62:
	/* 0x1c62: jns    1c69 <trace_ret_do_mmap+0x1c69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c62, 0x1c69, x86_l_1c69);
x86_l_1c64:
	/* 0x1c64: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c67:
	/* 0x1c67: jmp    1c6b <trace_ret_do_mmap+0x1c6b> */
	X86_SIM_X86_JMP(0x1c67, 0x1c6b, x86_l_1c6b);
x86_l_1c69:
	/* 0x1c69: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c6b:
	/* 0x1c6b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c6e:
	/* 0x1c6e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c71:
	/* 0x1c71: jns    1c78 <trace_ret_do_mmap+0x1c78> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c71, 0x1c78, x86_l_1c78);
x86_l_1c73:
	/* 0x1c73: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c76:
	/* 0x1c76: jmp    1c7a <trace_ret_do_mmap+0x1c7a> */
	X86_SIM_X86_JMP(0x1c76, 0x1c7a, x86_l_1c7a);
x86_l_1c78:
	/* 0x1c78: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c7a:
	/* 0x1c7a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c7e:
	/* 0x1c7e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c81:
	/* 0x1c81: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c84:
	/* 0x1c84: jns    1cbd <trace_ret_do_mmap+0x1cbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c84, 0x1cbd, x86_l_1cbd);
x86_l_1c86:
	/* 0x1c86: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c89:
	/* 0x1c89: jmp    1cbf <trace_ret_do_mmap+0x1cbf> */
	X86_SIM_X86_JMP(0x1c89, 0x1cbf, x86_l_1cbf);
x86_l_1c8b:
	/* 0x1c8b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c90:
	/* 0x1c90: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c94:
	/* 0x1c94: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c94, 0x2ada, x86_l_2ada);
x86_l_1c9a:
	/* 0x1c9a: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c9f:
	/* 0x1c9f: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ca2:
	/* 0x1ca2: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ca8:
	/* 0x1ca8: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1cad:
	/* 0x1cad: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cb0:
	/* 0x1cb0: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cb5:
	/* 0x1cb5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cb8:
	/* 0x1cb8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cbb:
	/* 0x1cbb: js     1c86 <trace_ret_do_mmap+0x1c86> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1cbb, 0x1c86, x86_l_1c86);
x86_l_1cbd:
	/* 0x1cbd: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cbf:
	/* 0x1cbf: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cc3:
	/* 0x1cc3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cc6:
	/* 0x1cc6: jns    1ccd <trace_ret_do_mmap+0x1ccd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc6, 0x1ccd, x86_l_1ccd);
x86_l_1cc8:
	/* 0x1cc8: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ccb:
	/* 0x1ccb: jmp    1ccf <trace_ret_do_mmap+0x1ccf> */
	X86_SIM_X86_JMP(0x1ccb, 0x1ccf, x86_l_1ccf);
x86_l_1ccd:
	/* 0x1ccd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ccf:
	/* 0x1ccf: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1cd2:
	/* 0x1cd2: je     1d4f <trace_ret_do_mmap+0x1d4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd2, 0x1d4f, x86_l_1d4f);
x86_l_1cd4:
	/* 0x1cd4: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cd7:
	/* 0x1cd7: je     1d4f <trace_ret_do_mmap+0x1d4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd7, 0x1d4f, x86_l_1d4f);
x86_l_1cd9:
	/* 0x1cd9: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cdd:
	/* 0x1cdd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ce0:
	/* 0x1ce0: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ce6:
	/* 0x1ce6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ce9:
	/* 0x1ce9: jns    1cf2 <trace_ret_do_mmap+0x1cf2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ce9, 0x1cf2, x86_l_1cf2);
x86_l_1ceb:
	/* 0x1ceb: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cee:
	/* 0x1cee: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cf2:
	/* 0x1cf2: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1cf6:
	/* 0x1cf6: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1cf9:
	/* 0x1cf9: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d00:
	/* 0x1d00: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d05:
	/* 0x1d05: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d08:
	/* 0x1d08: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d08, 0x2b36, x86_l_2b36);
x86_l_1d0e:
	/* 0x1d0e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1d11:
	/* 0x1d11: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d11, 0x2ad7, x86_l_2ad7);
x86_l_1d17:
	/* 0x1d17: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d1d:
	/* 0x1d1d: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d20:
	/* 0x1d20: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1d23:
	/* 0x1d23: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d23, 0x2931, x86_l_2931);
x86_l_1d29:
	/* 0x1d29: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d2d:
	/* 0x1d2d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d30:
	/* 0x1d30: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d33:
	/* 0x1d33: je     1d9d <trace_ret_do_mmap+0x1d9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d33, 0x1d9d, x86_l_1d9d);
x86_l_1d35:
	/* 0x1d35: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d39:
	/* 0x1d39: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1d3e:
	/* 0x1d3e: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1d42:
	/* 0x1d42: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d45:
	/* 0x1d45: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1d48:
	/* 0x1d48: jne    1d30 <trace_ret_do_mmap+0x1d30> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d48, 0x1d30, x86_l_1d30);
x86_l_1d4a:
	/* 0x1d4a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1d4d:
	/* 0x1d4d: jmp    1da2 <trace_ret_do_mmap+0x1da2> */
	X86_SIM_X86_JMP(0x1d4d, 0x1da2, x86_l_1da2);
x86_l_1d4f:
	/* 0x1d4f: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d52:
	/* 0x1d52: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d52, 0x2ad7, x86_l_2ad7);
x86_l_1d58:
	/* 0x1d58: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d5b:
	/* 0x1d5b: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5b, 0x2ad7, x86_l_2ad7);
x86_l_1d61:
	/* 0x1d61: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d65:
	/* 0x1d65: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d68:
	/* 0x1d68: jns    1d6f <trace_ret_do_mmap+0x1d6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d68, 0x1d6f, x86_l_1d6f);
x86_l_1d6a:
	/* 0x1d6a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d6d:
	/* 0x1d6d: jmp    1d71 <trace_ret_do_mmap+0x1d71> */
	X86_SIM_X86_JMP(0x1d6d, 0x1d71, x86_l_1d71);
x86_l_1d6f:
	/* 0x1d6f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d71:
	/* 0x1d71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d74:
	/* 0x1d74: jns    1d7b <trace_ret_do_mmap+0x1d7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d74, 0x1d7b, x86_l_1d7b);
x86_l_1d76:
	/* 0x1d76: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d79:
	/* 0x1d79: jmp    1d7d <trace_ret_do_mmap+0x1d7d> */
	X86_SIM_X86_JMP(0x1d79, 0x1d7d, x86_l_1d7d);
x86_l_1d7b:
	/* 0x1d7b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d7d:
	/* 0x1d7d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d80:
	/* 0x1d80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d83:
	/* 0x1d83: jns    1d8a <trace_ret_do_mmap+0x1d8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d83, 0x1d8a, x86_l_1d8a);
x86_l_1d85:
	/* 0x1d85: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d88:
	/* 0x1d88: jmp    1d8c <trace_ret_do_mmap+0x1d8c> */
	X86_SIM_X86_JMP(0x1d88, 0x1d8c, x86_l_1d8c);
x86_l_1d8a:
	/* 0x1d8a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d8c:
	/* 0x1d8c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d90:
	/* 0x1d90: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d93:
	/* 0x1d93: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d96:
	/* 0x1d96: jns    1dd0 <trace_ret_do_mmap+0x1dd0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d96, 0x1dd0, x86_l_1dd0);
x86_l_1d98:
	/* 0x1d98: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d9b:
	/* 0x1d9b: jmp    1dd2 <trace_ret_do_mmap+0x1dd2> */
	X86_SIM_X86_JMP(0x1d9b, 0x1dd2, x86_l_1dd2);
x86_l_1d9d:
	/* 0x1d9d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1da2:
	/* 0x1da2: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1da6:
	/* 0x1da6: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1da6, 0x2ad7, x86_l_2ad7);
x86_l_1dac:
	/* 0x1dac: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1db1:
	/* 0x1db1: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1db5:
	/* 0x1db5: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1dbb:
	/* 0x1dbb: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1dc0:
	/* 0x1dc0: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1dc3:
	/* 0x1dc3: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc8:
	/* 0x1dc8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dcb:
	/* 0x1dcb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1dce:
	/* 0x1dce: js     1d98 <trace_ret_do_mmap+0x1d98> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1dce, 0x1d98, x86_l_1d98);
x86_l_1dd0:
	/* 0x1dd0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dd2:
	/* 0x1dd2: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dd6:
	/* 0x1dd6: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1dd9:
	/* 0x1dd9: jns    1de0 <trace_ret_do_mmap+0x1de0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dd9, 0x1de0, x86_l_1de0);
x86_l_1ddb:
	/* 0x1ddb: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dde:
	/* 0x1dde: jmp    1de3 <trace_ret_do_mmap+0x1de3> */
	X86_SIM_X86_JMP(0x1dde, 0x1de3, x86_l_1de3);
x86_l_1de0:
	/* 0x1de0: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de3:
	/* 0x1de3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1de6:
	/* 0x1de6: je     1e63 <trace_ret_do_mmap+0x1e63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de6, 0x1e63, x86_l_1e63);
x86_l_1de8:
	/* 0x1de8: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1deb:
	/* 0x1deb: je     1e63 <trace_ret_do_mmap+0x1e63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1deb, 0x1e63, x86_l_1e63);
x86_l_1ded:
	/* 0x1ded: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1df1:
	/* 0x1df1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1df4:
	/* 0x1df4: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1dfa:
	/* 0x1dfa: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1dfd:
	/* 0x1dfd: jns    1e06 <trace_ret_do_mmap+0x1e06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dfd, 0x1e06, x86_l_1e06);
x86_l_1dff:
	/* 0x1dff: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e02:
	/* 0x1e02: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e06:
	/* 0x1e06: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e0a:
	/* 0x1e0a: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e0d:
	/* 0x1e0d: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e14:
	/* 0x1e14: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e19:
	/* 0x1e19: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e1c:
	/* 0x1e1c: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e1c, 0x2b36, x86_l_2b36);
x86_l_1e22:
	/* 0x1e22: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1e25:
	/* 0x1e25: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e25, 0x2ada, x86_l_2ada);
x86_l_1e2b:
	/* 0x1e2b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1e31:
	/* 0x1e31: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e34:
	/* 0x1e34: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1e37:
	/* 0x1e37: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e37, 0x292e, x86_l_292e);
x86_l_1e3d:
	/* 0x1e3d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e41:
	/* 0x1e41: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e44:
	/* 0x1e44: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1e47:
	/* 0x1e47: je     1eb2 <trace_ret_do_mmap+0x1eb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e47, 0x1eb2, x86_l_1eb2);
x86_l_1e49:
	/* 0x1e49: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e4d:
	/* 0x1e4d: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1e52:
	/* 0x1e52: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1e56:
	/* 0x1e56: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1e59:
	/* 0x1e59: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1e5c:
	/* 0x1e5c: jne    1e44 <trace_ret_do_mmap+0x1e44> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e5c, 0x1e44, x86_l_1e44);
x86_l_1e5e:
	/* 0x1e5e: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1e61:
	/* 0x1e61: jmp    1eb7 <trace_ret_do_mmap+0x1eb7> */
	X86_SIM_X86_JMP(0x1e61, 0x1eb7, x86_l_1eb7);
x86_l_1e63:
	/* 0x1e63: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e66:
	/* 0x1e66: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e66, 0x2ada, x86_l_2ada);
x86_l_1e6c:
	/* 0x1e6c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e6f:
	/* 0x1e6f: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e6f, 0x2ada, x86_l_2ada);
x86_l_1e75:
	/* 0x1e75: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e79:
	/* 0x1e79: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e7c:
	/* 0x1e7c: jns    1e83 <trace_ret_do_mmap+0x1e83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e7c, 0x1e83, x86_l_1e83);
x86_l_1e7e:
	/* 0x1e7e: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e81:
	/* 0x1e81: jmp    1e86 <trace_ret_do_mmap+0x1e86> */
	X86_SIM_X86_JMP(0x1e81, 0x1e86, x86_l_1e86);
x86_l_1e83:
	/* 0x1e83: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e86:
	/* 0x1e86: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e89:
	/* 0x1e89: jns    1e90 <trace_ret_do_mmap+0x1e90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e89, 0x1e90, x86_l_1e90);
x86_l_1e8b:
	/* 0x1e8b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8e:
	/* 0x1e8e: jmp    1e92 <trace_ret_do_mmap+0x1e92> */
	X86_SIM_X86_JMP(0x1e8e, 0x1e92, x86_l_1e92);
x86_l_1e90:
	/* 0x1e90: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e92:
	/* 0x1e92: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e95:
	/* 0x1e95: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e98:
	/* 0x1e98: jns    1e9f <trace_ret_do_mmap+0x1e9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e98, 0x1e9f, x86_l_1e9f);
x86_l_1e9a:
	/* 0x1e9a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e9d:
	/* 0x1e9d: jmp    1ea1 <trace_ret_do_mmap+0x1ea1> */
	X86_SIM_X86_JMP(0x1e9d, 0x1ea1, x86_l_1ea1);
x86_l_1e9f:
	/* 0x1e9f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ea1:
	/* 0x1ea1: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ea5:
	/* 0x1ea5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ea8:
	/* 0x1ea8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1eab:
	/* 0x1eab: jns    1ee4 <trace_ret_do_mmap+0x1ee4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eab, 0x1ee4, x86_l_1ee4);
x86_l_1ead:
	/* 0x1ead: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb0:
	/* 0x1eb0: jmp    1ee6 <trace_ret_do_mmap+0x1ee6> */
	X86_SIM_X86_JMP(0x1eb0, 0x1ee6, x86_l_1ee6);
x86_l_1eb2:
	/* 0x1eb2: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1eb7:
	/* 0x1eb7: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ebb:
	/* 0x1ebb: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ebb, 0x2ada, x86_l_2ada);
x86_l_1ec1:
	/* 0x1ec1: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ec6:
	/* 0x1ec6: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ec9:
	/* 0x1ec9: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ecf:
	/* 0x1ecf: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1ed4:
	/* 0x1ed4: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ed7:
	/* 0x1ed7: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1edc:
	/* 0x1edc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1edf:
	/* 0x1edf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ee2:
	/* 0x1ee2: js     1ead <trace_ret_do_mmap+0x1ead> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ee2, 0x1ead, x86_l_1ead);
x86_l_1ee4:
	/* 0x1ee4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ee6:
	/* 0x1ee6: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eea:
	/* 0x1eea: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1eed:
	/* 0x1eed: jns    1ef4 <trace_ret_do_mmap+0x1ef4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eed, 0x1ef4, x86_l_1ef4);
x86_l_1eef:
	/* 0x1eef: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ef2:
	/* 0x1ef2: jmp    1ef6 <trace_ret_do_mmap+0x1ef6> */
	X86_SIM_X86_JMP(0x1ef2, 0x1ef6, x86_l_1ef6);
x86_l_1ef4:
	/* 0x1ef4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ef6:
	/* 0x1ef6: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ef9:
	/* 0x1ef9: je     1f76 <trace_ret_do_mmap+0x1f76> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef9, 0x1f76, x86_l_1f76);
x86_l_1efb:
	/* 0x1efb: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1efe:
	/* 0x1efe: je     1f76 <trace_ret_do_mmap+0x1f76> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1efe, 0x1f76, x86_l_1f76);
x86_l_1f00:
	/* 0x1f00: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f04:
	/* 0x1f04: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f07:
	/* 0x1f07: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f0d:
	/* 0x1f0d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f10:
	/* 0x1f10: jns    1f19 <trace_ret_do_mmap+0x1f19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f10, 0x1f19, x86_l_1f19);
x86_l_1f12:
	/* 0x1f12: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f15:
	/* 0x1f15: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f19:
	/* 0x1f19: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f1d:
	/* 0x1f1d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f20:
	/* 0x1f20: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f27:
	/* 0x1f27: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f2c:
	/* 0x1f2c: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f2f:
	/* 0x1f2f: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f2f, 0x2b36, x86_l_2b36);
x86_l_1f35:
	/* 0x1f35: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1f38:
	/* 0x1f38: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f38, 0x2ad7, x86_l_2ad7);
x86_l_1f3e:
	/* 0x1f3e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f44:
	/* 0x1f44: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f47:
	/* 0x1f47: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1f4a:
	/* 0x1f4a: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f4a, 0x2931, x86_l_2931);
x86_l_1f50:
	/* 0x1f50: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f54:
	/* 0x1f54: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f57:
	/* 0x1f57: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1f5a:
	/* 0x1f5a: je     1fc4 <trace_ret_do_mmap+0x1fc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5a, 0x1fc4, x86_l_1fc4);
x86_l_1f5c:
	/* 0x1f5c: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f60:
	/* 0x1f60: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f65:
	/* 0x1f65: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f69:
	/* 0x1f69: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f6c:
	/* 0x1f6c: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1f6f:
	/* 0x1f6f: jne    1f57 <trace_ret_do_mmap+0x1f57> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f6f, 0x1f57, x86_l_1f57);
x86_l_1f71:
	/* 0x1f71: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1f74:
	/* 0x1f74: jmp    1fc9 <trace_ret_do_mmap+0x1fc9> */
	X86_SIM_X86_JMP(0x1f74, 0x1fc9, x86_l_1fc9);
x86_l_1f76:
	/* 0x1f76: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f79:
	/* 0x1f79: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f79, 0x2ad7, x86_l_2ad7);
x86_l_1f7f:
	/* 0x1f7f: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f82:
	/* 0x1f82: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f82, 0x2ad7, x86_l_2ad7);
x86_l_1f88:
	/* 0x1f88: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f8c:
	/* 0x1f8c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f8f:
	/* 0x1f8f: jns    1f96 <trace_ret_do_mmap+0x1f96> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f8f, 0x1f96, x86_l_1f96);
x86_l_1f91:
	/* 0x1f91: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f94:
	/* 0x1f94: jmp    1f98 <trace_ret_do_mmap+0x1f98> */
	X86_SIM_X86_JMP(0x1f94, 0x1f98, x86_l_1f98);
x86_l_1f96:
	/* 0x1f96: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f98:
	/* 0x1f98: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f9b:
	/* 0x1f9b: jns    1fa2 <trace_ret_do_mmap+0x1fa2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f9b, 0x1fa2, x86_l_1fa2);
x86_l_1f9d:
	/* 0x1f9d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fa0:
	/* 0x1fa0: jmp    1fa4 <trace_ret_do_mmap+0x1fa4> */
	X86_SIM_X86_JMP(0x1fa0, 0x1fa4, x86_l_1fa4);
x86_l_1fa2:
	/* 0x1fa2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fa4:
	/* 0x1fa4: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fa7:
	/* 0x1fa7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1faa:
	/* 0x1faa: jns    1fb1 <trace_ret_do_mmap+0x1fb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1faa, 0x1fb1, x86_l_1fb1);
x86_l_1fac:
	/* 0x1fac: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1faf:
	/* 0x1faf: jmp    1fb3 <trace_ret_do_mmap+0x1fb3> */
	X86_SIM_X86_JMP(0x1faf, 0x1fb3, x86_l_1fb3);
x86_l_1fb1:
	/* 0x1fb1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fb3:
	/* 0x1fb3: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fb7:
	/* 0x1fb7: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fba:
	/* 0x1fba: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fbd:
	/* 0x1fbd: jns    1ff7 <trace_ret_do_mmap+0x1ff7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fbd, 0x1ff7, x86_l_1ff7);
x86_l_1fbf:
	/* 0x1fbf: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc2:
	/* 0x1fc2: jmp    1ff9 <trace_ret_do_mmap+0x1ff9> */
	X86_SIM_X86_JMP(0x1fc2, 0x1ff9, x86_l_1ff9);
x86_l_1fc4:
	/* 0x1fc4: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1fc9:
	/* 0x1fc9: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1fcd:
	/* 0x1fcd: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1fcd, 0x2ad7, x86_l_2ad7);
x86_l_1fd3:
	/* 0x1fd3: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fd8:
	/* 0x1fd8: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fdc:
	/* 0x1fdc: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1fe2:
	/* 0x1fe2: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1fe7:
	/* 0x1fe7: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fea:
	/* 0x1fea: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fef:
	/* 0x1fef: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ff2:
	/* 0x1ff2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ff5:
	/* 0x1ff5: js     1fbf <trace_ret_do_mmap+0x1fbf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ff5, 0x1fbf, x86_l_1fbf);
x86_l_1ff7:
	/* 0x1ff7: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ff9:
	/* 0x1ff9: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ffd:
	/* 0x1ffd: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2000:
	/* 0x2000: jns    2007 <trace_ret_do_mmap+0x2007> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2000, 0x2007, x86_l_2007);
x86_l_2002:
	/* 0x2002: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2005:
	/* 0x2005: jmp    200a <trace_ret_do_mmap+0x200a> */
	X86_SIM_X86_JMP(0x2005, 0x200a, x86_l_200a);
x86_l_2007:
	/* 0x2007: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_200a:
	/* 0x200a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_200d:
	/* 0x200d: je     208a <trace_ret_do_mmap+0x208a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x200d, 0x208a, x86_l_208a);
x86_l_200f:
	/* 0x200f: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2012:
	/* 0x2012: je     208a <trace_ret_do_mmap+0x208a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2012, 0x208a, x86_l_208a);
x86_l_2014:
	/* 0x2014: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2018:
	/* 0x2018: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_201b:
	/* 0x201b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2021:
	/* 0x2021: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2024:
	/* 0x2024: jns    202d <trace_ret_do_mmap+0x202d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2024, 0x202d, x86_l_202d);
x86_l_2026:
	/* 0x2026: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2029:
	/* 0x2029: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_202d:
	/* 0x202d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2031:
	/* 0x2031: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2034:
	/* 0x2034: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_203b:
	/* 0x203b: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2040:
	/* 0x2040: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2043:
	/* 0x2043: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2043, 0x2b36, x86_l_2b36);
x86_l_2049:
	/* 0x2049: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_204c:
	/* 0x204c: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x204c, 0x2ada, x86_l_2ada);
x86_l_2052:
	/* 0x2052: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2058:
	/* 0x2058: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_205b:
	/* 0x205b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_205e:
	/* 0x205e: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x205e, 0x292e, x86_l_292e);
x86_l_2064:
	/* 0x2064: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2068:
	/* 0x2068: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_206b:
	/* 0x206b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_206e:
	/* 0x206e: je     20d9 <trace_ret_do_mmap+0x20d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x206e, 0x20d9, x86_l_20d9);
x86_l_2070:
	/* 0x2070: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2074:
	/* 0x2074: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2079:
	/* 0x2079: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_207d:
	/* 0x207d: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2080:
	/* 0x2080: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2083:
	/* 0x2083: jne    206b <trace_ret_do_mmap+0x206b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2083, 0x206b, x86_l_206b);
x86_l_2085:
	/* 0x2085: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2088:
	/* 0x2088: jmp    20de <trace_ret_do_mmap+0x20de> */
	X86_SIM_X86_JMP(0x2088, 0x20de, x86_l_20de);
x86_l_208a:
	/* 0x208a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_208d:
	/* 0x208d: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x208d, 0x2ada, x86_l_2ada);
x86_l_2093:
	/* 0x2093: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2096:
	/* 0x2096: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2096, 0x2ada, x86_l_2ada);
x86_l_209c:
	/* 0x209c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20a0:
	/* 0x20a0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20a3:
	/* 0x20a3: jns    20aa <trace_ret_do_mmap+0x20aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20a3, 0x20aa, x86_l_20aa);
x86_l_20a5:
	/* 0x20a5: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a8:
	/* 0x20a8: jmp    20ad <trace_ret_do_mmap+0x20ad> */
	X86_SIM_X86_JMP(0x20a8, 0x20ad, x86_l_20ad);
x86_l_20aa:
	/* 0x20aa: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20ad:
	/* 0x20ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20b0:
	/* 0x20b0: jns    20b7 <trace_ret_do_mmap+0x20b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20b0, 0x20b7, x86_l_20b7);
x86_l_20b2:
	/* 0x20b2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20b5:
	/* 0x20b5: jmp    20b9 <trace_ret_do_mmap+0x20b9> */
	X86_SIM_X86_JMP(0x20b5, 0x20b9, x86_l_20b9);
x86_l_20b7:
	/* 0x20b7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20b9:
	/* 0x20b9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20bc:
	/* 0x20bc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20bf:
	/* 0x20bf: jns    20c6 <trace_ret_do_mmap+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20bf, 0x20c6, x86_l_20c6);
x86_l_20c1:
	/* 0x20c1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c4:
	/* 0x20c4: jmp    20c8 <trace_ret_do_mmap+0x20c8> */
	X86_SIM_X86_JMP(0x20c4, 0x20c8, x86_l_20c8);
x86_l_20c6:
	/* 0x20c6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20c8:
	/* 0x20c8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20cc:
	/* 0x20cc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20cf:
	/* 0x20cf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_20d2:
	/* 0x20d2: jns    210b <trace_ret_do_mmap+0x210b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20d2, 0x210b, x86_l_210b);
x86_l_20d4:
	/* 0x20d4: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20d7:
	/* 0x20d7: jmp    210d <trace_ret_do_mmap+0x210d> */
	X86_SIM_X86_JMP(0x20d7, 0x210d, x86_l_210d);
x86_l_20d9:
	/* 0x20d9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_20de:
	/* 0x20de: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20e2:
	/* 0x20e2: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x20e2, 0x2ada, x86_l_2ada);
x86_l_20e8:
	/* 0x20e8: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20ed:
	/* 0x20ed: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20f0:
	/* 0x20f0: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_20f6:
	/* 0x20f6: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_20fb:
	/* 0x20fb: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20fe:
	/* 0x20fe: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2103:
	/* 0x2103: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2106:
	/* 0x2106: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2109:
	/* 0x2109: js     20d4 <trace_ret_do_mmap+0x20d4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2109, 0x20d4, x86_l_20d4);
x86_l_210b:
	/* 0x210b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210d:
	/* 0x210d: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2111:
	/* 0x2111: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2114:
	/* 0x2114: jns    211b <trace_ret_do_mmap+0x211b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2114, 0x211b, x86_l_211b);
x86_l_2116:
	/* 0x2116: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2119:
	/* 0x2119: jmp    211d <trace_ret_do_mmap+0x211d> */
	X86_SIM_X86_JMP(0x2119, 0x211d, x86_l_211d);
x86_l_211b:
	/* 0x211b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_211d:
	/* 0x211d: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2120:
	/* 0x2120: je     219d <trace_ret_do_mmap+0x219d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2120, 0x219d, x86_l_219d);
x86_l_2122:
	/* 0x2122: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2125:
	/* 0x2125: je     219d <trace_ret_do_mmap+0x219d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2125, 0x219d, x86_l_219d);
x86_l_2127:
	/* 0x2127: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_212b:
	/* 0x212b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212e:
	/* 0x212e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2134:
	/* 0x2134: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2137:
	/* 0x2137: jns    2140 <trace_ret_do_mmap+0x2140> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2137, 0x2140, x86_l_2140);
x86_l_2139:
	/* 0x2139: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213c:
	/* 0x213c: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2140:
	/* 0x2140: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2144:
	/* 0x2144: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2147:
	/* 0x2147: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_214e:
	/* 0x214e: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2153:
	/* 0x2153: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2156:
	/* 0x2156: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2156, 0x2b36, x86_l_2b36);
x86_l_215c:
	/* 0x215c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_215f:
	/* 0x215f: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215f, 0x2ad7, x86_l_2ad7);
x86_l_2165:
	/* 0x2165: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_216b:
	/* 0x216b: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_216e:
	/* 0x216e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2171:
	/* 0x2171: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2171, 0x2931, x86_l_2931);
x86_l_2177:
	/* 0x2177: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_217b:
	/* 0x217b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_217e:
	/* 0x217e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2181:
	/* 0x2181: je     21eb <trace_ret_do_mmap+0x21eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2181, 0x21eb, x86_l_21eb);
x86_l_2183:
	/* 0x2183: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2187:
	/* 0x2187: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_218c:
	/* 0x218c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2190:
	/* 0x2190: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2193:
	/* 0x2193: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2196:
	/* 0x2196: jne    217e <trace_ret_do_mmap+0x217e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2196, 0x217e, x86_l_217e);
x86_l_2198:
	/* 0x2198: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_219b:
	/* 0x219b: jmp    21f0 <trace_ret_do_mmap+0x21f0> */
	X86_SIM_X86_JMP(0x219b, 0x21f0, x86_l_21f0);
x86_l_219d:
	/* 0x219d: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21a0:
	/* 0x21a0: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21a0, 0x2ad7, x86_l_2ad7);
x86_l_21a6:
	/* 0x21a6: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21a9:
	/* 0x21a9: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a9, 0x2ad7, x86_l_2ad7);
x86_l_21af:
	/* 0x21af: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21b3:
	/* 0x21b3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21b6:
	/* 0x21b6: jns    21bd <trace_ret_do_mmap+0x21bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21b6, 0x21bd, x86_l_21bd);
x86_l_21b8:
	/* 0x21b8: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21bb:
	/* 0x21bb: jmp    21bf <trace_ret_do_mmap+0x21bf> */
	X86_SIM_X86_JMP(0x21bb, 0x21bf, x86_l_21bf);
x86_l_21bd:
	/* 0x21bd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21bf:
	/* 0x21bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21c2:
	/* 0x21c2: jns    21c9 <trace_ret_do_mmap+0x21c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21c2, 0x21c9, x86_l_21c9);
x86_l_21c4:
	/* 0x21c4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c7:
	/* 0x21c7: jmp    21cb <trace_ret_do_mmap+0x21cb> */
	X86_SIM_X86_JMP(0x21c7, 0x21cb, x86_l_21cb);
x86_l_21c9:
	/* 0x21c9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21cb:
	/* 0x21cb: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21ce:
	/* 0x21ce: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21d1:
	/* 0x21d1: jns    21d8 <trace_ret_do_mmap+0x21d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21d1, 0x21d8, x86_l_21d8);
x86_l_21d3:
	/* 0x21d3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21d6:
	/* 0x21d6: jmp    21da <trace_ret_do_mmap+0x21da> */
	X86_SIM_X86_JMP(0x21d6, 0x21da, x86_l_21da);
x86_l_21d8:
	/* 0x21d8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21da:
	/* 0x21da: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21de:
	/* 0x21de: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21e1:
	/* 0x21e1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21e4:
	/* 0x21e4: jns    221e <trace_ret_do_mmap+0x221e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21e4, 0x221e, x86_l_221e);
x86_l_21e6:
	/* 0x21e6: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e9:
	/* 0x21e9: jmp    2220 <trace_ret_do_mmap+0x2220> */
	X86_SIM_X86_JMP(0x21e9, 0x2220, x86_l_2220);
x86_l_21eb:
	/* 0x21eb: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_21f0:
	/* 0x21f0: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_21f4:
	/* 0x21f4: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x21f4, 0x2ad7, x86_l_2ad7);
x86_l_21fa:
	/* 0x21fa: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21ff:
	/* 0x21ff: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2203:
	/* 0x2203: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2209:
	/* 0x2209: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_220e:
	/* 0x220e: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2211:
	/* 0x2211: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2216:
	/* 0x2216: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2219:
	/* 0x2219: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_221c:
	/* 0x221c: js     21e6 <trace_ret_do_mmap+0x21e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x221c, 0x21e6, x86_l_21e6);
x86_l_221e:
	/* 0x221e: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2220:
	/* 0x2220: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2224:
	/* 0x2224: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2227:
	/* 0x2227: jns    222e <trace_ret_do_mmap+0x222e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2227, 0x222e, x86_l_222e);
x86_l_2229:
	/* 0x2229: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222c:
	/* 0x222c: jmp    2231 <trace_ret_do_mmap+0x2231> */
	X86_SIM_X86_JMP(0x222c, 0x2231, x86_l_2231);
x86_l_222e:
	/* 0x222e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2231:
	/* 0x2231: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2234:
	/* 0x2234: je     22b1 <trace_ret_do_mmap+0x22b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2234, 0x22b1, x86_l_22b1);
x86_l_2236:
	/* 0x2236: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2239:
	/* 0x2239: je     22b1 <trace_ret_do_mmap+0x22b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2239, 0x22b1, x86_l_22b1);
x86_l_223b:
	/* 0x223b: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_223f:
	/* 0x223f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2242:
	/* 0x2242: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2248:
	/* 0x2248: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_224b:
	/* 0x224b: jns    2254 <trace_ret_do_mmap+0x2254> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x224b, 0x2254, x86_l_2254);
x86_l_224d:
	/* 0x224d: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2250:
	/* 0x2250: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2254:
	/* 0x2254: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2258:
	/* 0x2258: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_225b:
	/* 0x225b: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2262:
	/* 0x2262: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2267:
	/* 0x2267: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_226a:
	/* 0x226a: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x226a, 0x2b36, x86_l_2b36);
x86_l_2270:
	/* 0x2270: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2273:
	/* 0x2273: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2273, 0x2ada, x86_l_2ada);
x86_l_2279:
	/* 0x2279: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_227f:
	/* 0x227f: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2282:
	/* 0x2282: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2285:
	/* 0x2285: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2285, 0x292e, x86_l_292e);
x86_l_228b:
	/* 0x228b: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_228f:
	/* 0x228f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2292:
	/* 0x2292: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2295:
	/* 0x2295: je     2300 <trace_ret_do_mmap+0x2300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2295, 0x2300, x86_l_2300);
x86_l_2297:
	/* 0x2297: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_229b:
	/* 0x229b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_22a0:
	/* 0x22a0: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_22a4:
	/* 0x22a4: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_22a7:
	/* 0x22a7: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_22aa:
	/* 0x22aa: jne    2292 <trace_ret_do_mmap+0x2292> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22aa, 0x2292, x86_l_2292);
x86_l_22ac:
	/* 0x22ac: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_22af:
	/* 0x22af: jmp    2305 <trace_ret_do_mmap+0x2305> */
	X86_SIM_X86_JMP(0x22af, 0x2305, x86_l_2305);
x86_l_22b1:
	/* 0x22b1: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22b4:
	/* 0x22b4: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22b4, 0x2ada, x86_l_2ada);
x86_l_22ba:
	/* 0x22ba: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22bd:
	/* 0x22bd: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22bd, 0x2ada, x86_l_2ada);
x86_l_22c3:
	/* 0x22c3: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22c7:
	/* 0x22c7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22ca:
	/* 0x22ca: jns    22d1 <trace_ret_do_mmap+0x22d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22ca, 0x22d1, x86_l_22d1);
x86_l_22cc:
	/* 0x22cc: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22cf:
	/* 0x22cf: jmp    22d4 <trace_ret_do_mmap+0x22d4> */
	X86_SIM_X86_JMP(0x22cf, 0x22d4, x86_l_22d4);
x86_l_22d1:
	/* 0x22d1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22d4:
	/* 0x22d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22d7:
	/* 0x22d7: jns    22de <trace_ret_do_mmap+0x22de> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22d7, 0x22de, x86_l_22de);
x86_l_22d9:
	/* 0x22d9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22dc:
	/* 0x22dc: jmp    22e0 <trace_ret_do_mmap+0x22e0> */
	X86_SIM_X86_JMP(0x22dc, 0x22e0, x86_l_22e0);
x86_l_22de:
	/* 0x22de: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22e0:
	/* 0x22e0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22e3:
	/* 0x22e3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22e6:
	/* 0x22e6: jns    22ed <trace_ret_do_mmap+0x22ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e6, 0x22ed, x86_l_22ed);
x86_l_22e8:
	/* 0x22e8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22eb:
	/* 0x22eb: jmp    22ef <trace_ret_do_mmap+0x22ef> */
	X86_SIM_X86_JMP(0x22eb, 0x22ef, x86_l_22ef);
x86_l_22ed:
	/* 0x22ed: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ef:
	/* 0x22ef: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22f3:
	/* 0x22f3: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22f6:
	/* 0x22f6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22f9:
	/* 0x22f9: jns    2332 <trace_ret_do_mmap+0x2332> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22f9, 0x2332, x86_l_2332);
x86_l_22fb:
	/* 0x22fb: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22fe:
	/* 0x22fe: jmp    2334 <trace_ret_do_mmap+0x2334> */
	X86_SIM_X86_JMP(0x22fe, 0x2334, x86_l_2334);
x86_l_2300:
	/* 0x2300: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2305:
	/* 0x2305: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2309:
	/* 0x2309: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2309, 0x2ada, x86_l_2ada);
x86_l_230f:
	/* 0x230f: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2314:
	/* 0x2314: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2317:
	/* 0x2317: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_231d:
	/* 0x231d: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2322:
	/* 0x2322: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2325:
	/* 0x2325: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_232a:
	/* 0x232a: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_232d:
	/* 0x232d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2330:
	/* 0x2330: js     22fb <trace_ret_do_mmap+0x22fb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2330, 0x22fb, x86_l_22fb);
x86_l_2332:
	/* 0x2332: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2334:
	/* 0x2334: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2338:
	/* 0x2338: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_233b:
	/* 0x233b: jns    2342 <trace_ret_do_mmap+0x2342> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x233b, 0x2342, x86_l_2342);
x86_l_233d:
	/* 0x233d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2340:
	/* 0x2340: jmp    2344 <trace_ret_do_mmap+0x2344> */
	X86_SIM_X86_JMP(0x2340, 0x2344, x86_l_2344);
x86_l_2342:
	/* 0x2342: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2344:
	/* 0x2344: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2347:
	/* 0x2347: je     23c4 <trace_ret_do_mmap+0x23c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2347, 0x23c4, x86_l_23c4);
x86_l_2349:
	/* 0x2349: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_234c:
	/* 0x234c: je     23c4 <trace_ret_do_mmap+0x23c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234c, 0x23c4, x86_l_23c4);
x86_l_234e:
	/* 0x234e: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2352:
	/* 0x2352: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2355:
	/* 0x2355: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_235b:
	/* 0x235b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_235e:
	/* 0x235e: jns    2367 <trace_ret_do_mmap+0x2367> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x235e, 0x2367, x86_l_2367);
x86_l_2360:
	/* 0x2360: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2363:
	/* 0x2363: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2367:
	/* 0x2367: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_236b:
	/* 0x236b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_236e:
	/* 0x236e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2375:
	/* 0x2375: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_237a:
	/* 0x237a: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_237d:
	/* 0x237d: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x237d, 0x2b36, x86_l_2b36);
x86_l_2383:
	/* 0x2383: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2386:
	/* 0x2386: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2386, 0x2ad7, x86_l_2ad7);
x86_l_238c:
	/* 0x238c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2392:
	/* 0x2392: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2395:
	/* 0x2395: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2398:
	/* 0x2398: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2398, 0x2931, x86_l_2931);
x86_l_239e:
	/* 0x239e: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23a2:
	/* 0x23a2: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23a5:
	/* 0x23a5: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_23a8:
	/* 0x23a8: je     2412 <trace_ret_do_mmap+0x2412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23a8, 0x2412, x86_l_2412);
x86_l_23aa:
	/* 0x23aa: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_23ae:
	/* 0x23ae: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_23b3:
	/* 0x23b3: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_23b7:
	/* 0x23b7: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_23ba:
	/* 0x23ba: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_23bd:
	/* 0x23bd: jne    23a5 <trace_ret_do_mmap+0x23a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23bd, 0x23a5, x86_l_23a5);
x86_l_23bf:
	/* 0x23bf: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_23c2:
	/* 0x23c2: jmp    2417 <trace_ret_do_mmap+0x2417> */
	X86_SIM_X86_JMP(0x23c2, 0x2417, x86_l_2417);
x86_l_23c4:
	/* 0x23c4: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23c7:
	/* 0x23c7: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23c7, 0x2ad7, x86_l_2ad7);
x86_l_23cd:
	/* 0x23cd: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23d0:
	/* 0x23d0: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23d0, 0x2ad7, x86_l_2ad7);
x86_l_23d6:
	/* 0x23d6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23da:
	/* 0x23da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23dd:
	/* 0x23dd: jns    23e4 <trace_ret_do_mmap+0x23e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23dd, 0x23e4, x86_l_23e4);
x86_l_23df:
	/* 0x23df: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e2:
	/* 0x23e2: jmp    23e6 <trace_ret_do_mmap+0x23e6> */
	X86_SIM_X86_JMP(0x23e2, 0x23e6, x86_l_23e6);
x86_l_23e4:
	/* 0x23e4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e6:
	/* 0x23e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23e9:
	/* 0x23e9: jns    23f0 <trace_ret_do_mmap+0x23f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23e9, 0x23f0, x86_l_23f0);
x86_l_23eb:
	/* 0x23eb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ee:
	/* 0x23ee: jmp    23f2 <trace_ret_do_mmap+0x23f2> */
	X86_SIM_X86_JMP(0x23ee, 0x23f2, x86_l_23f2);
x86_l_23f0:
	/* 0x23f0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23f2:
	/* 0x23f2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23f5:
	/* 0x23f5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23f8:
	/* 0x23f8: jns    23ff <trace_ret_do_mmap+0x23ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f8, 0x23ff, x86_l_23ff);
x86_l_23fa:
	/* 0x23fa: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fd:
	/* 0x23fd: jmp    2401 <trace_ret_do_mmap+0x2401> */
	X86_SIM_X86_JMP(0x23fd, 0x2401, x86_l_2401);
x86_l_23ff:
	/* 0x23ff: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2401:
	/* 0x2401: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2405:
	/* 0x2405: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2408:
	/* 0x2408: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_240b:
	/* 0x240b: jns    2445 <trace_ret_do_mmap+0x2445> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x240b, 0x2445, x86_l_2445);
x86_l_240d:
	/* 0x240d: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2410:
	/* 0x2410: jmp    2447 <trace_ret_do_mmap+0x2447> */
	X86_SIM_X86_JMP(0x2410, 0x2447, x86_l_2447);
x86_l_2412:
	/* 0x2412: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2417:
	/* 0x2417: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_241b:
	/* 0x241b: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x241b, 0x2ad7, x86_l_2ad7);
x86_l_2421:
	/* 0x2421: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2426:
	/* 0x2426: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_242a:
	/* 0x242a: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2430:
	/* 0x2430: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2435:
	/* 0x2435: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2438:
	/* 0x2438: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_243d:
	/* 0x243d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2440:
	/* 0x2440: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2443:
	/* 0x2443: js     240d <trace_ret_do_mmap+0x240d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2443, 0x240d, x86_l_240d);
x86_l_2445:
	/* 0x2445: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2447:
	/* 0x2447: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_244b:
	/* 0x244b: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_244e:
	/* 0x244e: jns    2455 <trace_ret_do_mmap+0x2455> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x244e, 0x2455, x86_l_2455);
x86_l_2450:
	/* 0x2450: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2453:
	/* 0x2453: jmp    2458 <trace_ret_do_mmap+0x2458> */
	X86_SIM_X86_JMP(0x2453, 0x2458, x86_l_2458);
x86_l_2455:
	/* 0x2455: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2458:
	/* 0x2458: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_245b:
	/* 0x245b: je     24d8 <trace_ret_do_mmap+0x24d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x245b, 0x24d8, x86_l_24d8);
x86_l_245d:
	/* 0x245d: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2460:
	/* 0x2460: je     24d8 <trace_ret_do_mmap+0x24d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2460, 0x24d8, x86_l_24d8);
x86_l_2462:
	/* 0x2462: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2466:
	/* 0x2466: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2469:
	/* 0x2469: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_246f:
	/* 0x246f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2472:
	/* 0x2472: jns    247b <trace_ret_do_mmap+0x247b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2472, 0x247b, x86_l_247b);
x86_l_2474:
	/* 0x2474: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2477:
	/* 0x2477: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_247b:
	/* 0x247b: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_247f:
	/* 0x247f: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2482:
	/* 0x2482: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2489:
	/* 0x2489: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_248e:
	/* 0x248e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2491:
	/* 0x2491: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2491, 0x2b36, x86_l_2b36);
x86_l_2497:
	/* 0x2497: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_249a:
	/* 0x249a: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x249a, 0x2ada, x86_l_2ada);
x86_l_24a0:
	/* 0x24a0: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_24a6:
	/* 0x24a6: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_24a9:
	/* 0x24a9: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_24ac:
	/* 0x24ac: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ac, 0x292e, x86_l_292e);
x86_l_24b2:
	/* 0x24b2: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24b6:
	/* 0x24b6: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24b9:
	/* 0x24b9: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_24bc:
	/* 0x24bc: je     2527 <trace_ret_do_mmap+0x2527> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24bc, 0x2527, x86_l_2527);
x86_l_24be:
	/* 0x24be: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_24c2:
	/* 0x24c2: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_24c7:
	/* 0x24c7: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_24cb:
	/* 0x24cb: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_24ce:
	/* 0x24ce: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_24d1:
	/* 0x24d1: jne    24b9 <trace_ret_do_mmap+0x24b9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24d1, 0x24b9, x86_l_24b9);
x86_l_24d3:
	/* 0x24d3: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_24d6:
	/* 0x24d6: jmp    252c <trace_ret_do_mmap+0x252c> */
	X86_SIM_X86_JMP(0x24d6, 0x252c, x86_l_252c);
x86_l_24d8:
	/* 0x24d8: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24db:
	/* 0x24db: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24db, 0x2ada, x86_l_2ada);
x86_l_24e1:
	/* 0x24e1: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24e4:
	/* 0x24e4: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24e4, 0x2ada, x86_l_2ada);
x86_l_24ea:
	/* 0x24ea: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ee:
	/* 0x24ee: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24f1:
	/* 0x24f1: jns    24f8 <trace_ret_do_mmap+0x24f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f1, 0x24f8, x86_l_24f8);
x86_l_24f3:
	/* 0x24f3: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24f6:
	/* 0x24f6: jmp    24fb <trace_ret_do_mmap+0x24fb> */
	X86_SIM_X86_JMP(0x24f6, 0x24fb, x86_l_24fb);
x86_l_24f8:
	/* 0x24f8: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24fb:
	/* 0x24fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24fe:
	/* 0x24fe: jns    2505 <trace_ret_do_mmap+0x2505> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24fe, 0x2505, x86_l_2505);
x86_l_2500:
	/* 0x2500: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2503:
	/* 0x2503: jmp    2507 <trace_ret_do_mmap+0x2507> */
	X86_SIM_X86_JMP(0x2503, 0x2507, x86_l_2507);
x86_l_2505:
	/* 0x2505: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2507:
	/* 0x2507: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_250a:
	/* 0x250a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_250d:
	/* 0x250d: jns    2514 <trace_ret_do_mmap+0x2514> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x250d, 0x2514, x86_l_2514);
x86_l_250f:
	/* 0x250f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2512:
	/* 0x2512: jmp    2516 <trace_ret_do_mmap+0x2516> */
	X86_SIM_X86_JMP(0x2512, 0x2516, x86_l_2516);
x86_l_2514:
	/* 0x2514: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2516:
	/* 0x2516: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_251a:
	/* 0x251a: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_251d:
	/* 0x251d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2520:
	/* 0x2520: jns    2559 <trace_ret_do_mmap+0x2559> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2520, 0x2559, x86_l_2559);
x86_l_2522:
	/* 0x2522: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2525:
	/* 0x2525: jmp    255b <trace_ret_do_mmap+0x255b> */
	X86_SIM_X86_JMP(0x2525, 0x255b, x86_l_255b);
x86_l_2527:
	/* 0x2527: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_252c:
	/* 0x252c: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2530:
	/* 0x2530: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2530, 0x2ada, x86_l_2ada);
x86_l_2536:
	/* 0x2536: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_253b:
	/* 0x253b: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_253e:
	/* 0x253e: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2544:
	/* 0x2544: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2549:
	/* 0x2549: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_254c:
	/* 0x254c: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2551:
	/* 0x2551: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2554:
	/* 0x2554: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2557:
	/* 0x2557: js     2522 <trace_ret_do_mmap+0x2522> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2557, 0x2522, x86_l_2522);
x86_l_2559:
	/* 0x2559: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_255b:
	/* 0x255b: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_255f:
	/* 0x255f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2562:
	/* 0x2562: jns    2569 <trace_ret_do_mmap+0x2569> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2562, 0x2569, x86_l_2569);
x86_l_2564:
	/* 0x2564: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2567:
	/* 0x2567: jmp    256b <trace_ret_do_mmap+0x256b> */
	X86_SIM_X86_JMP(0x2567, 0x256b, x86_l_256b);
x86_l_2569:
	/* 0x2569: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_256b:
	/* 0x256b: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_256e:
	/* 0x256e: je     25eb <trace_ret_do_mmap+0x25eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x256e, 0x25eb, x86_l_25eb);
x86_l_2570:
	/* 0x2570: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2573:
	/* 0x2573: je     25eb <trace_ret_do_mmap+0x25eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2573, 0x25eb, x86_l_25eb);
x86_l_2575:
	/* 0x2575: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2579:
	/* 0x2579: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_257c:
	/* 0x257c: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2582:
	/* 0x2582: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2585:
	/* 0x2585: jns    258e <trace_ret_do_mmap+0x258e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2585, 0x258e, x86_l_258e);
x86_l_2587:
	/* 0x2587: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_258a:
	/* 0x258a: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_258e:
	/* 0x258e: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2592:
	/* 0x2592: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2595:
	/* 0x2595: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_259c:
	/* 0x259c: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25a1:
	/* 0x25a1: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25a4:
	/* 0x25a4: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x25a4, 0x2b36, x86_l_2b36);
x86_l_25aa:
	/* 0x25aa: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_25ad:
	/* 0x25ad: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ad, 0x2ad7, x86_l_2ad7);
x86_l_25b3:
	/* 0x25b3: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_25b9:
	/* 0x25b9: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25bc:
	/* 0x25bc: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_25bf:
	/* 0x25bf: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25bf, 0x2931, x86_l_2931);
x86_l_25c5:
	/* 0x25c5: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25c9:
	/* 0x25c9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25cc:
	/* 0x25cc: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_25cf:
	/* 0x25cf: je     2639 <trace_ret_do_mmap+0x2639> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25cf, 0x2639, x86_l_2639);
x86_l_25d1:
	/* 0x25d1: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25d5:
	/* 0x25d5: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_25da:
	/* 0x25da: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_25de:
	/* 0x25de: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_25e1:
	/* 0x25e1: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_25e4:
	/* 0x25e4: jne    25cc <trace_ret_do_mmap+0x25cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25e4, 0x25cc, x86_l_25cc);
x86_l_25e6:
	/* 0x25e6: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_25e9:
	/* 0x25e9: jmp    263e <trace_ret_do_mmap+0x263e> */
	X86_SIM_X86_JMP(0x25e9, 0x263e, x86_l_263e);
x86_l_25eb:
	/* 0x25eb: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25ee:
	/* 0x25ee: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25ee, 0x2ad7, x86_l_2ad7);
x86_l_25f4:
	/* 0x25f4: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25f7:
	/* 0x25f7: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f7, 0x2ad7, x86_l_2ad7);
x86_l_25fd:
	/* 0x25fd: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2601:
	/* 0x2601: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2604:
	/* 0x2604: jns    260b <trace_ret_do_mmap+0x260b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2604, 0x260b, x86_l_260b);
x86_l_2606:
	/* 0x2606: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2609:
	/* 0x2609: jmp    260d <trace_ret_do_mmap+0x260d> */
	X86_SIM_X86_JMP(0x2609, 0x260d, x86_l_260d);
x86_l_260b:
	/* 0x260b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_260d:
	/* 0x260d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2610:
	/* 0x2610: jns    2617 <trace_ret_do_mmap+0x2617> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2610, 0x2617, x86_l_2617);
x86_l_2612:
	/* 0x2612: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2615:
	/* 0x2615: jmp    2619 <trace_ret_do_mmap+0x2619> */
	X86_SIM_X86_JMP(0x2615, 0x2619, x86_l_2619);
x86_l_2617:
	/* 0x2617: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2619:
	/* 0x2619: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_261c:
	/* 0x261c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_261f:
	/* 0x261f: jns    2626 <trace_ret_do_mmap+0x2626> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x261f, 0x2626, x86_l_2626);
x86_l_2621:
	/* 0x2621: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2624:
	/* 0x2624: jmp    2628 <trace_ret_do_mmap+0x2628> */
	X86_SIM_X86_JMP(0x2624, 0x2628, x86_l_2628);
x86_l_2626:
	/* 0x2626: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2628:
	/* 0x2628: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_262c:
	/* 0x262c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_262f:
	/* 0x262f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2632:
	/* 0x2632: jns    266c <trace_ret_do_mmap+0x266c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2632, 0x266c, x86_l_266c);
x86_l_2634:
	/* 0x2634: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2637:
	/* 0x2637: jmp    266e <trace_ret_do_mmap+0x266e> */
	X86_SIM_X86_JMP(0x2637, 0x266e, x86_l_266e);
x86_l_2639:
	/* 0x2639: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_263e:
	/* 0x263e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2642:
	/* 0x2642: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2642, 0x2ad7, x86_l_2ad7);
x86_l_2648:
	/* 0x2648: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_264d:
	/* 0x264d: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2651:
	/* 0x2651: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2657:
	/* 0x2657: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_265c:
	/* 0x265c: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_265f:
	/* 0x265f: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2664:
	/* 0x2664: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2667:
	/* 0x2667: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_266a:
	/* 0x266a: js     2634 <trace_ret_do_mmap+0x2634> */
	X86_SIM_X86_JCC(X86_CC_S, 0x266a, 0x2634, x86_l_2634);
x86_l_266c:
	/* 0x266c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_266e:
	/* 0x266e: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2672:
	/* 0x2672: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2675:
	/* 0x2675: jns    267c <trace_ret_do_mmap+0x267c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2675, 0x267c, x86_l_267c);
x86_l_2677:
	/* 0x2677: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_267a:
	/* 0x267a: jmp    267f <trace_ret_do_mmap+0x267f> */
	X86_SIM_X86_JMP(0x267a, 0x267f, x86_l_267f);
x86_l_267c:
	/* 0x267c: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_267f:
	/* 0x267f: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2682:
	/* 0x2682: je     26ff <trace_ret_do_mmap+0x26ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2682, 0x26ff, x86_l_26ff);
x86_l_2684:
	/* 0x2684: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2687:
	/* 0x2687: je     26ff <trace_ret_do_mmap+0x26ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2687, 0x26ff, x86_l_26ff);
x86_l_2689:
	/* 0x2689: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_268d:
	/* 0x268d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2690:
	/* 0x2690: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2696:
	/* 0x2696: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2699:
	/* 0x2699: jns    26a2 <trace_ret_do_mmap+0x26a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2699, 0x26a2, x86_l_26a2);
x86_l_269b:
	/* 0x269b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_269e:
	/* 0x269e: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26a2:
	/* 0x26a2: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26a6:
	/* 0x26a6: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_26a9:
	/* 0x26a9: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_26b0:
	/* 0x26b0: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26b5:
	/* 0x26b5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26b8:
	/* 0x26b8: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26b8, 0x2b36, x86_l_2b36);
x86_l_26be:
	/* 0x26be: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_26c1:
	/* 0x26c1: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26c1, 0x2ada, x86_l_2ada);
x86_l_26c7:
	/* 0x26c7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_26cd:
	/* 0x26cd: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26d0:
	/* 0x26d0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_26d3:
	/* 0x26d3: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26d3, 0x292e, x86_l_292e);
x86_l_26d9:
	/* 0x26d9: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26dd:
	/* 0x26dd: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26e0:
	/* 0x26e0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_26e3:
	/* 0x26e3: je     274e <trace_ret_do_mmap+0x274e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e3, 0x274e, x86_l_274e);
x86_l_26e5:
	/* 0x26e5: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26e9:
	/* 0x26e9: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_26ee:
	/* 0x26ee: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_26f2:
	/* 0x26f2: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_26f5:
	/* 0x26f5: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_26f8:
	/* 0x26f8: jne    26e0 <trace_ret_do_mmap+0x26e0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26f8, 0x26e0, x86_l_26e0);
x86_l_26fa:
	/* 0x26fa: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_26fd:
	/* 0x26fd: jmp    2753 <trace_ret_do_mmap+0x2753> */
	X86_SIM_X86_JMP(0x26fd, 0x2753, x86_l_2753);
x86_l_26ff:
	/* 0x26ff: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2702:
	/* 0x2702: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2702, 0x2ada, x86_l_2ada);
x86_l_2708:
	/* 0x2708: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_270b:
	/* 0x270b: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x270b, 0x2ada, x86_l_2ada);
x86_l_2711:
	/* 0x2711: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2715:
	/* 0x2715: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2718:
	/* 0x2718: jns    271f <trace_ret_do_mmap+0x271f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2718, 0x271f, x86_l_271f);
x86_l_271a:
	/* 0x271a: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_271d:
	/* 0x271d: jmp    2722 <trace_ret_do_mmap+0x2722> */
	X86_SIM_X86_JMP(0x271d, 0x2722, x86_l_2722);
x86_l_271f:
	/* 0x271f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2722:
	/* 0x2722: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2725:
	/* 0x2725: jns    272c <trace_ret_do_mmap+0x272c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2725, 0x272c, x86_l_272c);
x86_l_2727:
	/* 0x2727: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_272a:
	/* 0x272a: jmp    272e <trace_ret_do_mmap+0x272e> */
	X86_SIM_X86_JMP(0x272a, 0x272e, x86_l_272e);
x86_l_272c:
	/* 0x272c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_272e:
	/* 0x272e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2731:
	/* 0x2731: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2734:
	/* 0x2734: jns    273b <trace_ret_do_mmap+0x273b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2734, 0x273b, x86_l_273b);
x86_l_2736:
	/* 0x2736: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2739:
	/* 0x2739: jmp    273d <trace_ret_do_mmap+0x273d> */
	X86_SIM_X86_JMP(0x2739, 0x273d, x86_l_273d);
x86_l_273b:
	/* 0x273b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_273d:
	/* 0x273d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2741:
	/* 0x2741: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2744:
	/* 0x2744: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2747:
	/* 0x2747: jns    2780 <trace_ret_do_mmap+0x2780> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2747, 0x2780, x86_l_2780);
x86_l_2749:
	/* 0x2749: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274c:
	/* 0x274c: jmp    2782 <trace_ret_do_mmap+0x2782> */
	X86_SIM_X86_JMP(0x274c, 0x2782, x86_l_2782);
x86_l_274e:
	/* 0x274e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2753:
	/* 0x2753: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2757:
	/* 0x2757: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2757, 0x2ada, x86_l_2ada);
x86_l_275d:
	/* 0x275d: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2762:
	/* 0x2762: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2765:
	/* 0x2765: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_276b:
	/* 0x276b: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2770:
	/* 0x2770: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2773:
	/* 0x2773: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2778:
	/* 0x2778: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_277b:
	/* 0x277b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_277e:
	/* 0x277e: js     2749 <trace_ret_do_mmap+0x2749> */
	X86_SIM_X86_JCC(X86_CC_S, 0x277e, 0x2749, x86_l_2749);
x86_l_2780:
	/* 0x2780: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2782:
	/* 0x2782: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2786:
	/* 0x2786: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2789:
	/* 0x2789: jns    2790 <trace_ret_do_mmap+0x2790> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2789, 0x2790, x86_l_2790);
x86_l_278b:
	/* 0x278b: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278e:
	/* 0x278e: jmp    2792 <trace_ret_do_mmap+0x2792> */
	X86_SIM_X86_JMP(0x278e, 0x2792, x86_l_2792);
x86_l_2790:
	/* 0x2790: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2792:
	/* 0x2792: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2795:
	/* 0x2795: je     2812 <trace_ret_do_mmap+0x2812> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2795, 0x2812, x86_l_2812);
x86_l_2797:
	/* 0x2797: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_279a:
	/* 0x279a: je     2812 <trace_ret_do_mmap+0x2812> */
	X86_SIM_X86_JCC(X86_CC_E, 0x279a, 0x2812, x86_l_2812);
x86_l_279c:
	/* 0x279c: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27a0:
	/* 0x27a0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a3:
	/* 0x27a3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_27a9:
	/* 0x27a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27ac:
	/* 0x27ac: jns    27b5 <trace_ret_do_mmap+0x27b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ac, 0x27b5, x86_l_27b5);
x86_l_27ae:
	/* 0x27ae: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27b1:
	/* 0x27b1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27b5:
	/* 0x27b5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_27b9:
	/* 0x27b9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_27bc:
	/* 0x27bc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_27c3:
	/* 0x27c3: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27c8:
	/* 0x27c8: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27cb:
	/* 0x27cb: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27cb, 0x2b36, x86_l_2b36);
x86_l_27d1:
	/* 0x27d1: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_27d4:
	/* 0x27d4: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27d4, 0x2ad7, x86_l_2ad7);
x86_l_27da:
	/* 0x27da: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27e0:
	/* 0x27e0: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27e3:
	/* 0x27e3: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_27e6:
	/* 0x27e6: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27e6, 0x2931, x86_l_2931);
x86_l_27ec:
	/* 0x27ec: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27f0:
	/* 0x27f0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27f3:
	/* 0x27f3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_27f6:
	/* 0x27f6: je     2860 <trace_ret_do_mmap+0x2860> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f6, 0x2860, x86_l_2860);
x86_l_27f8:
	/* 0x27f8: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_27fc:
	/* 0x27fc: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2801:
	/* 0x2801: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2805:
	/* 0x2805: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2808:
	/* 0x2808: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_280b:
	/* 0x280b: jne    27f3 <trace_ret_do_mmap+0x27f3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x280b, 0x27f3, x86_l_27f3);
x86_l_280d:
	/* 0x280d: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2810:
	/* 0x2810: jmp    2865 <trace_ret_do_mmap+0x2865> */
	X86_SIM_X86_JMP(0x2810, 0x2865, x86_l_2865);
x86_l_2812:
	/* 0x2812: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2815:
	/* 0x2815: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2815, 0x2ad7, x86_l_2ad7);
x86_l_281b:
	/* 0x281b: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_281e:
	/* 0x281e: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281e, 0x2ad7, x86_l_2ad7);
x86_l_2824:
	/* 0x2824: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2828:
	/* 0x2828: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_282b:
	/* 0x282b: jns    2832 <trace_ret_do_mmap+0x2832> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x282b, 0x2832, x86_l_2832);
x86_l_282d:
	/* 0x282d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2830:
	/* 0x2830: jmp    2834 <trace_ret_do_mmap+0x2834> */
	X86_SIM_X86_JMP(0x2830, 0x2834, x86_l_2834);
x86_l_2832:
	/* 0x2832: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2834:
	/* 0x2834: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2837:
	/* 0x2837: jns    283e <trace_ret_do_mmap+0x283e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2837, 0x283e, x86_l_283e);
x86_l_2839:
	/* 0x2839: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_283c:
	/* 0x283c: jmp    2840 <trace_ret_do_mmap+0x2840> */
	X86_SIM_X86_JMP(0x283c, 0x2840, x86_l_2840);
x86_l_283e:
	/* 0x283e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2840:
	/* 0x2840: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2843:
	/* 0x2843: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2846:
	/* 0x2846: jns    284d <trace_ret_do_mmap+0x284d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2846, 0x284d, x86_l_284d);
x86_l_2848:
	/* 0x2848: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284b:
	/* 0x284b: jmp    284f <trace_ret_do_mmap+0x284f> */
	X86_SIM_X86_JMP(0x284b, 0x284f, x86_l_284f);
x86_l_284d:
	/* 0x284d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_284f:
	/* 0x284f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2853:
	/* 0x2853: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2856:
	/* 0x2856: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2859:
	/* 0x2859: jns    2893 <trace_ret_do_mmap+0x2893> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2859, 0x2893, x86_l_2893);
x86_l_285b:
	/* 0x285b: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_285e:
	/* 0x285e: jmp    2895 <trace_ret_do_mmap+0x2895> */
	X86_SIM_X86_JMP(0x285e, 0x2895, x86_l_2895);
x86_l_2860:
	/* 0x2860: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2865:
	/* 0x2865: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2869:
	/* 0x2869: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2869, 0x2ad7, x86_l_2ad7);
x86_l_286f:
	/* 0x286f: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2874:
	/* 0x2874: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2878:
	/* 0x2878: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_287e:
	/* 0x287e: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2883:
	/* 0x2883: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2886:
	/* 0x2886: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_288b:
	/* 0x288b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_288e:
	/* 0x288e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2891:
	/* 0x2891: js     285b <trace_ret_do_mmap+0x285b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2891, 0x285b, x86_l_285b);
x86_l_2893:
	/* 0x2893: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2895:
	/* 0x2895: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2899:
	/* 0x2899: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_289c:
	/* 0x289c: jns    28a3 <trace_ret_do_mmap+0x28a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x289c, 0x28a3, x86_l_28a3);
x86_l_289e:
	/* 0x289e: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a1:
	/* 0x28a1: jmp    28a6 <trace_ret_do_mmap+0x28a6> */
	X86_SIM_X86_JMP(0x28a1, 0x28a6, x86_l_28a6);
x86_l_28a3:
	/* 0x28a3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28a6:
	/* 0x28a6: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28a9:
	/* 0x28a9: je     2945 <trace_ret_do_mmap+0x2945> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a9, 0x2945, x86_l_2945);
x86_l_28af:
	/* 0x28af: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_28b2:
	/* 0x28b2: je     2945 <trace_ret_do_mmap+0x2945> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28b2, 0x2945, x86_l_2945);
x86_l_28b8:
	/* 0x28b8: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28bc:
	/* 0x28bc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28bf:
	/* 0x28bf: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_28c5:
	/* 0x28c5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28c8:
	/* 0x28c8: jns    28d1 <trace_ret_do_mmap+0x28d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c8, 0x28d1, x86_l_28d1);
x86_l_28ca:
	/* 0x28ca: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28cd:
	/* 0x28cd: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28d1:
	/* 0x28d1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28d5:
	/* 0x28d5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28d8:
	/* 0x28d8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28df:
	/* 0x28df: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28e4:
	/* 0x28e4: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28e7:
	/* 0x28e7: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28e7, 0x2b36, x86_l_2b36);
x86_l_28ed:
	/* 0x28ed: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_28f0:
	/* 0x28f0: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28f0, 0x2ada, x86_l_2ada);
x86_l_28f6:
	/* 0x28f6: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_28fc:
	/* 0x28fc: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28ff:
	/* 0x28ff: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2902:
	/* 0x2902: jns    292e <trace_ret_do_mmap+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2902, 0x292e, x86_l_292e);
x86_l_2904:
	/* 0x2904: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2908:
	/* 0x2908: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_290b:
	/* 0x290b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_290e:
	/* 0x290e: je     2994 <trace_ret_do_mmap+0x2994> */
	X86_SIM_X86_JCC(X86_CC_E, 0x290e, 0x2994, x86_l_2994);
x86_l_2914:
	/* 0x2914: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2918:
	/* 0x2918: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_291d:
	/* 0x291d: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2921:
	/* 0x2921: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2924:
	/* 0x2924: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2927:
	/* 0x2927: jne    290b <trace_ret_do_mmap+0x290b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2927, 0x290b, x86_l_290b);
x86_l_2929:
	/* 0x2929: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_292c:
	/* 0x292c: jmp    2999 <trace_ret_do_mmap+0x2999> */
	X86_SIM_X86_JMP(0x292c, 0x2999, x86_l_2999);
x86_l_292e:
	/* 0x292e: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2931:
	/* 0x2931: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2936:
	/* 0x2936: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_293b:
	/* 0x293b: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2940:
	/* 0x2940: jmp    ee9 <trace_ret_do_mmap+0xee9> */
	X86_SIM_X86_JMP(0x2940, 0xee9, x86_l_ee9);
x86_l_2945:
	/* 0x2945: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2948:
	/* 0x2948: jne    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2948, 0x2ada, x86_l_2ada);
x86_l_294e:
	/* 0x294e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2951:
	/* 0x2951: je     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2951, 0x2ada, x86_l_2ada);
x86_l_2957:
	/* 0x2957: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_295b:
	/* 0x295b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_295e:
	/* 0x295e: jns    2965 <trace_ret_do_mmap+0x2965> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x295e, 0x2965, x86_l_2965);
x86_l_2960:
	/* 0x2960: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2963:
	/* 0x2963: jmp    2968 <trace_ret_do_mmap+0x2968> */
	X86_SIM_X86_JMP(0x2963, 0x2968, x86_l_2968);
x86_l_2965:
	/* 0x2965: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2968:
	/* 0x2968: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_296b:
	/* 0x296b: jns    2972 <trace_ret_do_mmap+0x2972> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296b, 0x2972, x86_l_2972);
x86_l_296d:
	/* 0x296d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2970:
	/* 0x2970: jmp    2974 <trace_ret_do_mmap+0x2974> */
	X86_SIM_X86_JMP(0x2970, 0x2974, x86_l_2974);
x86_l_2972:
	/* 0x2972: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2974:
	/* 0x2974: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2977:
	/* 0x2977: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_297a:
	/* 0x297a: jns    2981 <trace_ret_do_mmap+0x2981> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x297a, 0x2981, x86_l_2981);
x86_l_297c:
	/* 0x297c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297f:
	/* 0x297f: jmp    2983 <trace_ret_do_mmap+0x2983> */
	X86_SIM_X86_JMP(0x297f, 0x2983, x86_l_2983);
x86_l_2981:
	/* 0x2981: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2983:
	/* 0x2983: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2987:
	/* 0x2987: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_298a:
	/* 0x298a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_298d:
	/* 0x298d: jns    29c6 <trace_ret_do_mmap+0x29c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x298d, 0x29c6, x86_l_29c6);
x86_l_298f:
	/* 0x298f: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2992:
	/* 0x2992: jmp    29c8 <trace_ret_do_mmap+0x29c8> */
	X86_SIM_X86_JMP(0x2992, 0x29c8, x86_l_29c8);
x86_l_2994:
	/* 0x2994: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2999:
	/* 0x2999: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_299d:
	/* 0x299d: jl     2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_L, 0x299d, 0x2ada, x86_l_2ada);
x86_l_29a3:
	/* 0x29a3: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29a8:
	/* 0x29a8: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29ab:
	/* 0x29ab: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_29b1:
	/* 0x29b1: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_29b6:
	/* 0x29b6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_29b9:
	/* 0x29b9: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29be:
	/* 0x29be: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29c1:
	/* 0x29c1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29c4:
	/* 0x29c4: js     298f <trace_ret_do_mmap+0x298f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29c4, 0x298f, x86_l_298f);
x86_l_29c6:
	/* 0x29c6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c8:
	/* 0x29c8: lea    rdi,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29cc:
	/* 0x29cc: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29cf:
	/* 0x29cf: jns    29d6 <trace_ret_do_mmap+0x29d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29cf, 0x29d6, x86_l_29d6);
x86_l_29d1:
	/* 0x29d1: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d4:
	/* 0x29d4: jmp    29d9 <trace_ret_do_mmap+0x29d9> */
	X86_SIM_X86_JMP(0x29d4, 0x29d9, x86_l_29d9);
x86_l_29d6:
	/* 0x29d6: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d9:
	/* 0x29d9: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29dc:
	/* 0x29dc: je     2a58 <trace_ret_do_mmap+0x2a58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29dc, 0x2a58, x86_l_2a58);
x86_l_29de:
	/* 0x29de: cmp    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_29e1:
	/* 0x29e1: je     2a58 <trace_ret_do_mmap+0x2a58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29e1, 0x2a58, x86_l_2a58);
x86_l_29e3:
	/* 0x29e3: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29e7:
	/* 0x29e7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29ea:
	/* 0x29ea: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_29ef:
	/* 0x29ef: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29f2:
	/* 0x29f2: jns    29fb <trace_ret_do_mmap+0x29fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f2, 0x29fb, x86_l_29fb);
x86_l_29f4:
	/* 0x29f4: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f7:
	/* 0x29f7: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29fb:
	/* 0x29fb: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_29ff:
	/* 0x29ff: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a02:
	/* 0x2a02: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a09:
	/* 0x2a09: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a0e:
	/* 0x2a0e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a11:
	/* 0x2a11: jb     2b36 <trace_ret_do_mmap+0x2b36> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a11, 0x2b36, x86_l_2b36);
x86_l_2a17:
	/* 0x2a17: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2a1a:
	/* 0x2a1a: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a1a, 0x2ad7, x86_l_2ad7);
x86_l_2a20:
	/* 0x2a20: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a26:
	/* 0x2a26: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a29:
	/* 0x2a29: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a2c:
	/* 0x2a2c: jns    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a2c, 0x2931, x86_l_2931);
x86_l_2a32:
	/* 0x2a32: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a36:
	/* 0x2a36: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a39:
	/* 0x2a39: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2a3c:
	/* 0x2a3c: je     2a9c <trace_ret_do_mmap+0x2a9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a3c, 0x2a9c, x86_l_2a9c);
x86_l_2a3e:
	/* 0x2a3e: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a42:
	/* 0x2a42: movzx  r12d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2a47:
	/* 0x2a47: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2a4b:
	/* 0x2a4b: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a4e:
	/* 0x2a4e: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2a51:
	/* 0x2a51: jne    2a39 <trace_ret_do_mmap+0x2a39> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a51, 0x2a39, x86_l_2a39);
x86_l_2a53:
	/* 0x2a53: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2a56:
	/* 0x2a56: jmp    2aa1 <trace_ret_do_mmap+0x2aa1> */
	X86_SIM_X86_JMP(0x2a56, 0x2aa1, x86_l_2aa1);
x86_l_2a58:
	/* 0x2a58: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a5b:
	/* 0x2a5b: jne    2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a5b, 0x2ad7, x86_l_2ad7);
x86_l_2a5d:
	/* 0x2a5d: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a60:
	/* 0x2a60: je     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a60, 0x2ad7, x86_l_2ad7);
x86_l_2a62:
	/* 0x2a62: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a66:
	/* 0x2a66: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a69:
	/* 0x2a69: jns    2a70 <trace_ret_do_mmap+0x2a70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a69, 0x2a70, x86_l_2a70);
x86_l_2a6b:
	/* 0x2a6b: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a6e:
	/* 0x2a6e: jmp    2a73 <trace_ret_do_mmap+0x2a73> */
	X86_SIM_X86_JMP(0x2a6e, 0x2a73, x86_l_2a73);
x86_l_2a70:
	/* 0x2a70: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a73:
	/* 0x2a73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a76:
	/* 0x2a76: jns    2a7d <trace_ret_do_mmap+0x2a7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a76, 0x2a7d, x86_l_2a7d);
x86_l_2a78:
	/* 0x2a78: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a7b:
	/* 0x2a7b: jmp    2a7f <trace_ret_do_mmap+0x2a7f> */
	X86_SIM_X86_JMP(0x2a7b, 0x2a7f, x86_l_2a7f);
x86_l_2a7d:
	/* 0x2a7d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a7f:
	/* 0x2a7f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a82:
	/* 0x2a82: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a85:
	/* 0x2a85: jns    2a8c <trace_ret_do_mmap+0x2a8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a85, 0x2a8c, x86_l_2a8c);
x86_l_2a87:
	/* 0x2a87: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a8a:
	/* 0x2a8a: jmp    2a8e <trace_ret_do_mmap+0x2a8e> */
	X86_SIM_X86_JMP(0x2a8a, 0x2a8e, x86_l_2a8e);
x86_l_2a8c:
	/* 0x2a8c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a8e:
	/* 0x2a8e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a92:
	/* 0x2a92: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a95:
	/* 0x2a95: jns    2ac7 <trace_ret_do_mmap+0x2ac7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a95, 0x2ac7, x86_l_2ac7);
x86_l_2a97:
	/* 0x2a97: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a9a:
	/* 0x2a9a: jmp    2ac9 <trace_ret_do_mmap+0x2ac9> */
	X86_SIM_X86_JMP(0x2a9a, 0x2ac9, x86_l_2ac9);
x86_l_2a9c:
	/* 0x2a9c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2aa1:
	/* 0x2aa1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2aa5:
	/* 0x2aa5: jl     2ad7 <trace_ret_do_mmap+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2aa5, 0x2ad7, x86_l_2ad7);
x86_l_2aa7:
	/* 0x2aa7: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2aac:
	/* 0x2aac: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2aaf:
	/* 0x2aaf: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ab5:
	/* 0x2ab5: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2aba:
	/* 0x2aba: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2abd:
	/* 0x2abd: mov    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ac2:
	/* 0x2ac2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ac5:
	/* 0x2ac5: js     2a97 <trace_ret_do_mmap+0x2a97> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ac5, 0x2a97, x86_l_2a97);
x86_l_2ac7:
	/* 0x2ac7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ac9:
	/* 0x2ac9: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2acd:
	/* 0x2acd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ad0:
	/* 0x2ad0: jns    2aee <trace_ret_do_mmap+0x2aee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad0, 0x2aee, x86_l_2aee);
x86_l_2ad2:
	/* 0x2ad2: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad5:
	/* 0x2ad5: jmp    2af0 <trace_ret_do_mmap+0x2af0> */
	X86_SIM_X86_JMP(0x2ad5, 0x2af0, x86_l_2af0);
x86_l_2ad7:
	/* 0x2ad7: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2ada:
	/* 0x2ada: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2adf:
	/* 0x2adf: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ae4:
	/* 0x2ae4: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ae9:
	/* 0x2ae9: jmp    ef6 <trace_ret_do_mmap+0xef6> */
	X86_SIM_X86_JMP(0x2ae9, 0xef6, x86_l_ef6);
x86_l_2aee:
	/* 0x2aee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2af0:
	/* 0x2af0: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2af3:
	/* 0x2af3: je     3730 <trace_ret_do_mmap+0x3730> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2af3, 0x3730, x86_l_3730);
x86_l_2af9:
	/* 0x2af9: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2afc:
	/* 0x2afc: je     3730 <trace_ret_do_mmap+0x3730> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2afc, 0x3730, x86_l_3730);
x86_l_2b02:
	/* 0x2b02: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b06:
	/* 0x2b06: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b09:
	/* 0x2b09: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2b0e:
	/* 0x2b0e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b11:
	/* 0x2b11: jns    2b1a <trace_ret_do_mmap+0x2b1a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b11, 0x2b1a, x86_l_2b1a);
x86_l_2b13:
	/* 0x2b13: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b16:
	/* 0x2b16: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b1a:
	/* 0x2b1a: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b1e:
	/* 0x2b1e: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b21:
	/* 0x2b21: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2b28:
	/* 0x2b28: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b2d:
	/* 0x2b2d: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b30:
	/* 0x2b30: jae    3750 <trace_ret_do_mmap+0x3750> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b30, 0x3750, x86_l_3750);
x86_l_2b36:
	/* 0x2b36: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b3b:
	/* 0x2b3b: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b40:
	/* 0x2b40: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b45:
	/* 0x2b45: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b4a:
	/* 0x2b4a: dec    r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2b4d:
	/* 0x2b4d: mov    eax,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_2b50:
	/* 0x2b50: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b55:
	/* 0x2b55: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2b5a:
	/* 0x2b5a: mov    BYTE PTR [rbp+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2b61:
	/* 0x2b61: and    r10d,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b68:
	/* 0x2b68: add    rbp,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b6b:
	/* 0x2b6b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2b6e:
	/* 0x2b6e: jns    d84 <trace_ret_do_mmap+0xd84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b6e, 0xd84, x86_l_d84);
x86_l_2b74:
	/* 0x2b74: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b77:
	/* 0x2b77: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_2b80:
	/* 0x2b80: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_2b89:
	/* 0x2b89: lea    rdx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b8d:
	/* 0x2b8d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b8f:
	/* 0x2b8f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b92:
	/* 0x2b92: jns    2b99 <trace_ret_do_mmap+0x2b99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b92, 0x2b99, x86_l_2b99);
x86_l_2b94:
	/* 0x2b94: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b97:
	/* 0x2b97: jmp    2b9b <trace_ret_do_mmap+0x2b9b> */
	X86_SIM_X86_JMP(0x2b97, 0x2b9b, x86_l_2b9b);
x86_l_2b99:
	/* 0x2b99: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b9b:
	/* 0x2b9b: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ba0:
	/* 0x2ba0: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2ba4:
	/* 0x2ba4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ba7:
	/* 0x2ba7: jns    2bab <trace_ret_do_mmap+0x2bab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ba7, 0x2bab, x86_l_2bab);
x86_l_2ba9:
	/* 0x2ba9: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bab:
	/* 0x2bab: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2bad:
	/* 0x2bad: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2bb2:
	/* 0x2bb2: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2bb7:
	/* 0x2bb7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bba:
	/* 0x2bba: jns    2bd7 <trace_ret_do_mmap+0x2bd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bba, 0x2bd7, x86_l_2bd7);
x86_l_2bbc:
	/* 0x2bbc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bbf:
	/* 0x2bbf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bc2:
	/* 0x2bc2: js     2d35 <trace_ret_do_mmap+0x2d35> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bc2, 0x2d35, x86_l_2d35);
x86_l_2bc8:
	/* 0x2bc8: lea    rcx,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2bcd:
	/* 0x2bcd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bd0:
	/* 0x2bd0: jns    2be3 <trace_ret_do_mmap+0x2be3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bd0, 0x2be3, x86_l_2be3);
x86_l_2bd2:
	/* 0x2bd2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bd5:
	/* 0x2bd5: jmp    2be5 <trace_ret_do_mmap+0x2be5> */
	X86_SIM_X86_JMP(0x2bd5, 0x2be5, x86_l_2be5);
x86_l_2bd7:
	/* 0x2bd7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bd9:
	/* 0x2bd9: lea    rcx,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2bde:
	/* 0x2bde: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2be1:
	/* 0x2be1: js     2bd2 <trace_ret_do_mmap+0x2bd2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2be1, 0x2bd2, x86_l_2bd2);
x86_l_2be3:
	/* 0x2be3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2be5:
	/* 0x2be5: imul   rax,rax,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_2bec:
	/* 0x2bec: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2bef:
	/* 0x2bef: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2bf4:
	/* 0x2bf4: mov    rax,QWORD PTR [rsp+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_2bfc:
	/* 0x2bfc: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2c04:
	/* 0x2c04: mov    rax,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2c0c:
	/* 0x2c0c: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2c14:
	/* 0x2c14: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_2c1c:
	/* 0x2c1c: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2c24:
	/* 0x2c24: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2c2c:
	/* 0x2c2c: mov    QWORD PTR [rsp+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2c34:
	/* 0x2c34: mov    rax,QWORD PTR [r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2c38:
	/* 0x2c38: mov    QWORD PTR [rsp+0xd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2c40:
	/* 0x2c40: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2c48:
	/* 0x2c48: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2c4f:
	/* 0x2c4f: ja     2cb9 <trace_ret_do_mmap+0x2cb9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c4f, 0x2cb9, x86_l_2cb9);
x86_l_2c51:
	/* 0x2c51: mov    BYTE PTR [r14+rbx*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519552ULL);
x86_l_2c5a:
	/* 0x2c5a: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2c60:
	/* 0x2c60: ja     2cb9 <trace_ret_do_mmap+0x2cb9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c60, 0x2cb9, x86_l_2cb9);
x86_l_2c62:
	/* 0x2c62: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c67:
	/* 0x2c67: lea    rdi,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2c6b:
	/* 0x2c6b: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2c72:
	/* 0x2c72: lea    rax,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2c7a:
	/* 0x2c7a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c7d:
	/* 0x2c7d: jns    2c90 <trace_ret_do_mmap+0x2c90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c7d, 0x2c90, x86_l_2c90);
x86_l_2c7f:
	/* 0x2c7f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c82:
	/* 0x2c82: jns    2d52 <trace_ret_do_mmap+0x2d52> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c82, 0x2d52, x86_l_2d52);
x86_l_2c88:
	/* 0x2c88: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8b:
	/* 0x2c8b: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8e:
	/* 0x2c8e: jmp    2ca7 <trace_ret_do_mmap+0x2ca7> */
	X86_SIM_X86_JMP(0x2c8e, 0x2ca7, x86_l_2ca7);
x86_l_2c90:
	/* 0x2c90: lea    rdx,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2c98:
	/* 0x2c98: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2c9d:
	/* 0x2c9d: call   2ca2 <trace_ret_do_mmap+0x2ca2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ca2:
	/* 0x2ca2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ca5:
	/* 0x2ca5: js     2cb9 <trace_ret_do_mmap+0x2cb9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ca5, 0x2cb9, x86_l_2cb9);
x86_l_2ca7:
	/* 0x2ca7: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2caa:
	/* 0x2caa: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2cb2:
	/* 0x2cb2: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2cb9:
	/* 0x2cb9: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2cbc:
	/* 0x2cbc: je     2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cbc, 0x2fc7, x86_l_2fc7);
x86_l_2cc2:
	/* 0x2cc2: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2cca:
	/* 0x2cca: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2cd0:
	/* 0x2cd0: ja     2db9 <trace_ret_do_mmap+0x2db9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cd0, 0x2db9, x86_l_2db9);
x86_l_2cd6:
	/* 0x2cd6: mov    BYTE PTR [r14+rax*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519553ULL);
x86_l_2cdf:
	/* 0x2cdf: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2ce7:
	/* 0x2ce7: mov    WORD PTR [r14+0x7d8e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32142ULL);
x86_l_2cef:
	/* 0x2cef: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2cf5:
	/* 0x2cf5: ja     2db9 <trace_ret_do_mmap+0x2db9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cf5, 0x2db9, x86_l_2db9);
x86_l_2cfb:
	/* 0x2cfb: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2d00:
	/* 0x2d00: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2d04:
	/* 0x2d04: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2d0b:
	/* 0x2d0b: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d0e:
	/* 0x2d0e: jns    2d3c <trace_ret_do_mmap+0x2d3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d0e, 0x2d3c, x86_l_2d3c);
x86_l_2d10:
	/* 0x2d10: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d13:
	/* 0x2d13: jns    2d67 <trace_ret_do_mmap+0x2d67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d13, 0x2d67, x86_l_2d67);
x86_l_2d15:
	/* 0x2d15: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d17:
	/* 0x2d17: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2d1e:
	/* 0x2d1e: je     2d75 <trace_ret_do_mmap+0x2d75> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d1e, 0x2d75, x86_l_2d75);
x86_l_2d20:
	/* 0x2d20: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d24:
	/* 0x2d24: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2d29:
	/* 0x2d29: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2d2c:
	/* 0x2d2c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d2f:
	/* 0x2d2f: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2d31:
	/* 0x2d31: jne    2d17 <trace_ret_do_mmap+0x2d17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d31, 0x2d17, x86_l_2d17);
x86_l_2d33:
	/* 0x2d33: jmp    2d49 <trace_ret_do_mmap+0x2d49> */
	X86_SIM_X86_JMP(0x2d33, 0x2d49, x86_l_2d49);
x86_l_2d35:
	/* 0x2d35: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d37:
	/* 0x2d37: jmp    2bef <trace_ret_do_mmap+0x2bef> */
	X86_SIM_X86_JMP(0x2d37, 0x2bef, x86_l_2bef);
x86_l_2d3c:
	/* 0x2d3c: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d41:
	/* 0x2d41: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d44:
	/* 0x2d44: call   2d49 <trace_ret_do_mmap+0x2d49> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2d49:
	/* 0x2d49: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d4c:
	/* 0x2d4c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d4e:
	/* 0x2d4e: jg     2d86 <trace_ret_do_mmap+0x2d86> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d4e, 0x2d86, x86_l_2d86);
x86_l_2d50:
	/* 0x2d50: jmp    2db9 <trace_ret_do_mmap+0x2db9> */
	X86_SIM_X86_JMP(0x2d50, 0x2db9, x86_l_2db9);
x86_l_2d52:
	/* 0x2d52: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d59:
	/* 0x2d59: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2d5c:
	/* 0x2d5c: jne    2cc2 <trace_ret_do_mmap+0x2cc2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d5c, 0x2cc2, x86_l_2cc2);
x86_l_2d62:
	/* 0x2d62: jmp    2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JMP(0x2d62, 0x2fc7, x86_l_2fc7);
x86_l_2d67:
	/* 0x2d67: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d6c:
	/* 0x2d6c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d6e:
	/* 0x2d6e: call   2d73 <trace_ret_do_mmap+0x2d73> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2d73:
	/* 0x2d73: jmp    2db9 <trace_ret_do_mmap+0x2db9> */
	X86_SIM_X86_JMP(0x2d73, 0x2db9, x86_l_2db9);
x86_l_2d75:
	/* 0x2d75: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2d7c:
	/* 0x2d7c: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d81:
	/* 0x2d81: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d86:
	/* 0x2d86: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d8e:
	/* 0x2d8e: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2d95:
	/* 0x2d95: ja     2db9 <trace_ret_do_mmap+0x2db9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d95, 0x2db9, x86_l_2db9);
x86_l_2d97:
	/* 0x2d97: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2d9f:
	/* 0x2d9f: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2da7:
	/* 0x2da7: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2daa:
	/* 0x2daa: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2db2:
	/* 0x2db2: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2db9:
	/* 0x2db9: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2dc1:
	/* 0x2dc1: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2dc8:
	/* 0x2dc8: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2dcd:
	/* 0x2dcd: ja     2e30 <trace_ret_do_mmap+0x2e30> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dcd, 0x2e30, x86_l_2e30);
x86_l_2dcf:
	/* 0x2dcf: mov    BYTE PTR [r14+rbx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519554ULL);
x86_l_2dd8:
	/* 0x2dd8: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2dde:
	/* 0x2dde: ja     2e30 <trace_ret_do_mmap+0x2e30> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dde, 0x2e30, x86_l_2e30);
x86_l_2de0:
	/* 0x2de0: lea    rdi,[rbx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_2de4:
	/* 0x2de4: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2deb:
	/* 0x2deb: lea    rax,[rsp+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_2df3:
	/* 0x2df3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2df6:
	/* 0x2df6: jns    2e07 <trace_ret_do_mmap+0x2e07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2df6, 0x2e07, x86_l_2e07);
x86_l_2df8:
	/* 0x2df8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dfb:
	/* 0x2dfb: jns    2ea4 <trace_ret_do_mmap+0x2ea4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dfb, 0x2ea4, x86_l_2ea4);
x86_l_2e01:
	/* 0x2e01: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e03:
	/* 0x2e03: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e05:
	/* 0x2e05: jmp    2e1e <trace_ret_do_mmap+0x2e1e> */
	X86_SIM_X86_JMP(0x2e05, 0x2e1e, x86_l_2e1e);
x86_l_2e07:
	/* 0x2e07: lea    rdx,[rsp+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_2e0f:
	/* 0x2e0f: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e14:
	/* 0x2e14: call   2e19 <trace_ret_do_mmap+0x2e19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e19:
	/* 0x2e19: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e1c:
	/* 0x2e1c: js     2e30 <trace_ret_do_mmap+0x2e30> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e1c, 0x2e30, x86_l_2e30);
x86_l_2e1e:
	/* 0x2e1e: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e21:
	/* 0x2e21: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e29:
	/* 0x2e29: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e30:
	/* 0x2e30: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e38:
	/* 0x2e38: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e3f:
	/* 0x2e3f: ja     2ec3 <trace_ret_do_mmap+0x2ec3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e3f, 0x2ec3, x86_l_2ec3);
x86_l_2e45:
	/* 0x2e45: mov    BYTE PTR [r14+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_2e4e:
	/* 0x2e4e: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2e54:
	/* 0x2e54: ja     2ec3 <trace_ret_do_mmap+0x2ec3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e54, 0x2ec3, x86_l_2ec3);
x86_l_2e56:
	/* 0x2e56: lea    rdi,[rbx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_2e5a:
	/* 0x2e5a: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2e61:
	/* 0x2e61: lea    rax,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2e69:
	/* 0x2e69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e6c:
	/* 0x2e6c: jns    2e79 <trace_ret_do_mmap+0x2e79> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e6c, 0x2e79, x86_l_2e79);
x86_l_2e6e:
	/* 0x2e6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e71:
	/* 0x2e71: jns    2ebd <trace_ret_do_mmap+0x2ebd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e71, 0x2ebd, x86_l_2ebd);
x86_l_2e73:
	/* 0x2e73: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e75:
	/* 0x2e75: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e77:
	/* 0x2e77: jmp    2e90 <trace_ret_do_mmap+0x2e90> */
	X86_SIM_X86_JMP(0x2e77, 0x2e90, x86_l_2e90);
x86_l_2e79:
	/* 0x2e79: lea    rdx,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2e81:
	/* 0x2e81: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e86:
	/* 0x2e86: call   2e8b <trace_ret_do_mmap+0x2e8b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e8b:
	/* 0x2e8b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e8e:
	/* 0x2e8e: js     2ec3 <trace_ret_do_mmap+0x2ec3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e8e, 0x2ec3, x86_l_2ec3);
x86_l_2e90:
	/* 0x2e90: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e93:
	/* 0x2e93: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e9b:
	/* 0x2e9b: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2ea2:
	/* 0x2ea2: jmp    2ec3 <trace_ret_do_mmap+0x2ec3> */
	X86_SIM_X86_JMP(0x2ea2, 0x2ec3, x86_l_2ec3);
x86_l_2ea4:
	/* 0x2ea4: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eaa:
	/* 0x2eaa: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2eb2:
	/* 0x2eb2: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2eb9:
	/* 0x2eb9: jbe    2e45 <trace_ret_do_mmap+0x2e45> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2eb9, 0x2e45, x86_l_2e45);
x86_l_2ebb:
	/* 0x2ebb: jmp    2ec3 <trace_ret_do_mmap+0x2ec3> */
	X86_SIM_X86_JMP(0x2ebb, 0x2ec3, x86_l_2ec3);
x86_l_2ebd:
	/* 0x2ebd: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ec3:
	/* 0x2ec3: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2ecb:
	/* 0x2ecb: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2ed2:
	/* 0x2ed2: ja     2f31 <trace_ret_do_mmap+0x2f31> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ed2, 0x2f31, x86_l_2f31);
x86_l_2ed4:
	/* 0x2ed4: mov    BYTE PTR [r14+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_2edd:
	/* 0x2edd: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2ee3:
	/* 0x2ee3: ja     2f31 <trace_ret_do_mmap+0x2f31> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ee3, 0x2f31, x86_l_2f31);
x86_l_2ee5:
	/* 0x2ee5: lea    rdi,[rbx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_2ee9:
	/* 0x2ee9: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2ef0:
	/* 0x2ef0: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ef5:
	/* 0x2ef5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ef8:
	/* 0x2ef8: jns    2f0b <trace_ret_do_mmap+0x2f0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ef8, 0x2f0b, x86_l_2f0b);
x86_l_2efa:
	/* 0x2efa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2efd:
	/* 0x2efd: jns    2fa6 <trace_ret_do_mmap+0x2fa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2efd, 0x2fa6, x86_l_2fa6);
x86_l_2f03:
	/* 0x2f03: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f06:
	/* 0x2f06: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f09:
	/* 0x2f09: jmp    2f1f <trace_ret_do_mmap+0x2f1f> */
	X86_SIM_X86_JMP(0x2f09, 0x2f1f, x86_l_2f1f);
x86_l_2f0b:
	/* 0x2f0b: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2f10:
	/* 0x2f10: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f15:
	/* 0x2f15: call   2f1a <trace_ret_do_mmap+0x2f1a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f1a:
	/* 0x2f1a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f1d:
	/* 0x2f1d: js     2f31 <trace_ret_do_mmap+0x2f31> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f1d, 0x2f31, x86_l_2f31);
x86_l_2f1f:
	/* 0x2f1f: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2f22:
	/* 0x2f22: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2f2a:
	/* 0x2f2a: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2f31:
	/* 0x2f31: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2f39:
	/* 0x2f39: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2f40:
	/* 0x2f40: ja     2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2f40, 0x2fc7, x86_l_2fc7);
x86_l_2f46:
	/* 0x2f46: mov    BYTE PTR [r14+rbx*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519557ULL);
x86_l_2f4f:
	/* 0x2f4f: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2f55:
	/* 0x2f55: ja     2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2f55, 0x2fc7, x86_l_2fc7);
x86_l_2f57:
	/* 0x2f57: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f5c:
	/* 0x2f5c: lea    rdi,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2f60:
	/* 0x2f60: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2f67:
	/* 0x2f67: lea    rax,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f6c:
	/* 0x2f6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f6f:
	/* 0x2f6f: jns    2f7e <trace_ret_do_mmap+0x2f7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f6f, 0x2f7e, x86_l_2f7e);
x86_l_2f71:
	/* 0x2f71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f74:
	/* 0x2f74: jns    2fc0 <trace_ret_do_mmap+0x2fc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f74, 0x2fc0, x86_l_2fc0);
x86_l_2f76:
	/* 0x2f76: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f79:
	/* 0x2f79: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f7c:
	/* 0x2f7c: jmp    2f92 <trace_ret_do_mmap+0x2f92> */
	X86_SIM_X86_JMP(0x2f7c, 0x2f92, x86_l_2f92);
x86_l_2f7e:
	/* 0x2f7e: lea    rdx,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f83:
	/* 0x2f83: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f88:
	/* 0x2f88: call   2f8d <trace_ret_do_mmap+0x2f8d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f8d:
	/* 0x2f8d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f90:
	/* 0x2f90: js     2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f90, 0x2fc7, x86_l_2fc7);
x86_l_2f92:
	/* 0x2f92: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2f95:
	/* 0x2f95: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2f9d:
	/* 0x2f9d: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2fa4:
	/* 0x2fa4: jmp    2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JMP(0x2fa4, 0x2fc7, x86_l_2fc7);
x86_l_2fa6:
	/* 0x2fa6: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fad:
	/* 0x2fad: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2fb5:
	/* 0x2fb5: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2fbc:
	/* 0x2fbc: jbe    2f46 <trace_ret_do_mmap+0x2f46> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2fbc, 0x2f46, x86_l_2f46);
x86_l_2fbe:
	/* 0x2fbe: jmp    2fc7 <trace_ret_do_mmap+0x2fc7> */
	X86_SIM_X86_JMP(0x2fbe, 0x2fc7, x86_l_2fc7);
x86_l_2fc0:
	/* 0x2fc0: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc7:
	/* 0x2fc7: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2fcf:
	/* 0x2fcf: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2fd6:
	/* 0x2fd6: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2fdb:
	/* 0x2fdb: ja     3040 <trace_ret_do_mmap+0x3040> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2fdb, 0x3040, x86_l_3040);
x86_l_2fdd:
	/* 0x2fdd: mov    BYTE PTR [r14+rbx*1+0x89],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519558ULL);
x86_l_2fe6:
	/* 0x2fe6: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2fec:
	/* 0x2fec: ja     3040 <trace_ret_do_mmap+0x3040> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2fec, 0x3040, x86_l_3040);
x86_l_2fee:
	/* 0x2fee: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2ff2:
	/* 0x2ff2: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2ff9:
	/* 0x2ff9: lea    rax,[rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_3001:
	/* 0x3001: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3004:
	/* 0x3004: jns    3017 <trace_ret_do_mmap+0x3017> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3004, 0x3017, x86_l_3017);
x86_l_3006:
	/* 0x3006: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3009:
	/* 0x3009: jns    30b6 <trace_ret_do_mmap+0x30b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3009, 0x30b6, x86_l_30b6);
x86_l_300f:
	/* 0x300f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3012:
	/* 0x3012: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3015:
	/* 0x3015: jmp    302e <trace_ret_do_mmap+0x302e> */
	X86_SIM_X86_JMP(0x3015, 0x302e, x86_l_302e);
x86_l_3017:
	/* 0x3017: lea    rdx,[rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_301f:
	/* 0x301f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3024:
	/* 0x3024: call   3029 <trace_ret_do_mmap+0x3029> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3029:
	/* 0x3029: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_302c:
	/* 0x302c: js     3040 <trace_ret_do_mmap+0x3040> */
	X86_SIM_X86_JCC(X86_CC_S, 0x302c, 0x3040, x86_l_3040);
x86_l_302e:
	/* 0x302e: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3031:
	/* 0x3031: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3039:
	/* 0x3039: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3040:
	/* 0x3040: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3048:
	/* 0x3048: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_304f:
	/* 0x304f: ja     30d7 <trace_ret_do_mmap+0x30d7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x304f, 0x30d7, x86_l_30d7);
x86_l_3055:
	/* 0x3055: mov    BYTE PTR [r14+rbx*1+0x89],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519559ULL);
x86_l_305e:
	/* 0x305e: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_3064:
	/* 0x3064: ja     30d7 <trace_ret_do_mmap+0x30d7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3064, 0x30d7, x86_l_30d7);
x86_l_3066:
	/* 0x3066: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_306a:
	/* 0x306a: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3071:
	/* 0x3071: lea    rax,[rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_3079:
	/* 0x3079: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_307c:
	/* 0x307c: jns    308b <trace_ret_do_mmap+0x308b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x307c, 0x308b, x86_l_308b);
x86_l_307e:
	/* 0x307e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3081:
	/* 0x3081: jns    30d0 <trace_ret_do_mmap+0x30d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3081, 0x30d0, x86_l_30d0);
x86_l_3083:
	/* 0x3083: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3086:
	/* 0x3086: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3089:
	/* 0x3089: jmp    30a2 <trace_ret_do_mmap+0x30a2> */
	X86_SIM_X86_JMP(0x3089, 0x30a2, x86_l_30a2);
x86_l_308b:
	/* 0x308b: lea    rdx,[rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_3093:
	/* 0x3093: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3098:
	/* 0x3098: call   309d <trace_ret_do_mmap+0x309d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_309d:
	/* 0x309d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30a0:
	/* 0x30a0: js     30d7 <trace_ret_do_mmap+0x30d7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30a0, 0x30d7, x86_l_30d7);
x86_l_30a2:
	/* 0x30a2: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_30a5:
	/* 0x30a5: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_30ad:
	/* 0x30ad: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_30b4:
	/* 0x30b4: jmp    30d7 <trace_ret_do_mmap+0x30d7> */
	X86_SIM_X86_JMP(0x30b4, 0x30d7, x86_l_30d7);
x86_l_30b6:
	/* 0x30b6: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30bd:
	/* 0x30bd: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_30c5:
	/* 0x30c5: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_30cc:
	/* 0x30cc: jbe    3055 <trace_ret_do_mmap+0x3055> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x30cc, 0x3055, x86_l_3055);
x86_l_30ce:
	/* 0x30ce: jmp    30d7 <trace_ret_do_mmap+0x30d7> */
	X86_SIM_X86_JMP(0x30ce, 0x30d7, x86_l_30d7);
x86_l_30d0:
	/* 0x30d0: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d7:
	/* 0x30d7: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_30df:
	/* 0x30df: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_30e6:
	/* 0x30e6: ja     314b <trace_ret_do_mmap+0x314b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x30e6, 0x314b, x86_l_314b);
x86_l_30e8:
	/* 0x30e8: mov    BYTE PTR [r14+rbx*1+0x89],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519560ULL);
x86_l_30f1:
	/* 0x30f1: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_30f7:
	/* 0x30f7: ja     314b <trace_ret_do_mmap+0x314b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x30f7, 0x314b, x86_l_314b);
x86_l_30f9:
	/* 0x30f9: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_30fd:
	/* 0x30fd: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3104:
	/* 0x3104: lea    rax,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_310c:
	/* 0x310c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_310f:
	/* 0x310f: jns    3122 <trace_ret_do_mmap+0x3122> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x310f, 0x3122, x86_l_3122);
x86_l_3111:
	/* 0x3111: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3114:
	/* 0x3114: jns    31c1 <trace_ret_do_mmap+0x31c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3114, 0x31c1, x86_l_31c1);
x86_l_311a:
	/* 0x311a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_311d:
	/* 0x311d: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3120:
	/* 0x3120: jmp    3139 <trace_ret_do_mmap+0x3139> */
	X86_SIM_X86_JMP(0x3120, 0x3139, x86_l_3139);
x86_l_3122:
	/* 0x3122: lea    rdx,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_312a:
	/* 0x312a: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_312f:
	/* 0x312f: call   3134 <trace_ret_do_mmap+0x3134> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3134:
	/* 0x3134: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3137:
	/* 0x3137: js     314b <trace_ret_do_mmap+0x314b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3137, 0x314b, x86_l_314b);
x86_l_3139:
	/* 0x3139: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_313c:
	/* 0x313c: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3144:
	/* 0x3144: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_314b:
	/* 0x314b: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3153:
	/* 0x3153: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_315a:
	/* 0x315a: ja     31e2 <trace_ret_do_mmap+0x31e2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x315a, 0x31e2, x86_l_31e2);
x86_l_3160:
	/* 0x3160: mov    BYTE PTR [r14+rbx*1+0x89],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519561ULL);
x86_l_3169:
	/* 0x3169: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_316f:
	/* 0x316f: ja     31e2 <trace_ret_do_mmap+0x31e2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x316f, 0x31e2, x86_l_31e2);
x86_l_3171:
	/* 0x3171: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3175:
	/* 0x3175: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_317c:
	/* 0x317c: lea    rax,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3184:
	/* 0x3184: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3187:
	/* 0x3187: jns    3196 <trace_ret_do_mmap+0x3196> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3187, 0x3196, x86_l_3196);
x86_l_3189:
	/* 0x3189: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_318c:
	/* 0x318c: jns    31db <trace_ret_do_mmap+0x31db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x318c, 0x31db, x86_l_31db);
x86_l_318e:
	/* 0x318e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3191:
	/* 0x3191: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3194:
	/* 0x3194: jmp    31ad <trace_ret_do_mmap+0x31ad> */
	X86_SIM_X86_JMP(0x3194, 0x31ad, x86_l_31ad);
x86_l_3196:
	/* 0x3196: lea    rdx,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_319e:
	/* 0x319e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_31a3:
	/* 0x31a3: call   31a8 <trace_ret_do_mmap+0x31a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_31a8:
	/* 0x31a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31ab:
	/* 0x31ab: js     31e2 <trace_ret_do_mmap+0x31e2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31ab, 0x31e2, x86_l_31e2);
x86_l_31ad:
	/* 0x31ad: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_31b0:
	/* 0x31b0: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_31b8:
	/* 0x31b8: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_31bf:
	/* 0x31bf: jmp    31e2 <trace_ret_do_mmap+0x31e2> */
	X86_SIM_X86_JMP(0x31bf, 0x31e2, x86_l_31e2);
x86_l_31c1:
	/* 0x31c1: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31c8:
	/* 0x31c8: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_31d0:
	/* 0x31d0: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_31d7:
	/* 0x31d7: jbe    3160 <trace_ret_do_mmap+0x3160> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x31d7, 0x3160, x86_l_3160);
x86_l_31d9:
	/* 0x31d9: jmp    31e2 <trace_ret_do_mmap+0x31e2> */
	X86_SIM_X86_JMP(0x31d9, 0x31e2, x86_l_31e2);
x86_l_31db:
	/* 0x31db: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31e2:
	/* 0x31e2: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_31e9:
	/* 0x31e9: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31ed:
	/* 0x31ed: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31f0:
	/* 0x31f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31f3:
	/* 0x31f3: jns    3205 <trace_ret_do_mmap+0x3205> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31f3, 0x3205, x86_l_3205);
x86_l_31f5:
	/* 0x31f5: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f8:
	/* 0x31f8: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_31fc:
	/* 0x31fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31ff:
	/* 0x31ff: js     3211 <trace_ret_do_mmap+0x3211> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31ff, 0x3211, x86_l_3211);
x86_l_3201:
	/* 0x3201: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3203:
	/* 0x3203: jmp    3214 <trace_ret_do_mmap+0x3214> */
	X86_SIM_X86_JMP(0x3203, 0x3214, x86_l_3214);
x86_l_3205:
	/* 0x3205: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3208:
	/* 0x3208: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_320c:
	/* 0x320c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_320f:
	/* 0x320f: jns    3201 <trace_ret_do_mmap+0x3201> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x320f, 0x3201, x86_l_3201);
x86_l_3211:
	/* 0x3211: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3214:
	/* 0x3214: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3218:
	/* 0x3218: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_321a:
	/* 0x321a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_321d:
	/* 0x321d: jns    322e <trace_ret_do_mmap+0x322e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x321d, 0x322e, x86_l_322e);
x86_l_321f:
	/* 0x321f: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3222:
	/* 0x3222: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3227:
	/* 0x3227: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_322a:
	/* 0x322a: js     323b <trace_ret_do_mmap+0x323b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x322a, 0x323b, x86_l_323b);
x86_l_322c:
	/* 0x322c: jmp    323d <trace_ret_do_mmap+0x323d> */
	X86_SIM_X86_JMP(0x322c, 0x323d, x86_l_323d);
x86_l_322e:
	/* 0x322e: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3231:
	/* 0x3231: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3236:
	/* 0x3236: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3239:
	/* 0x3239: jns    323d <trace_ret_do_mmap+0x323d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3239, 0x323d, x86_l_323d);
x86_l_323b:
	/* 0x323b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_323d:
	/* 0x323d: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_3241:
	/* 0x3241: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3245:
	/* 0x3245: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3248:
	/* 0x3248: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_324a:
	/* 0x324a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_324d:
	/* 0x324d: jns    325c <trace_ret_do_mmap+0x325c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x324d, 0x325c, x86_l_325c);
x86_l_324f:
	/* 0x324f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3252:
	/* 0x3252: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3255:
	/* 0x3255: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3258:
	/* 0x3258: js     3266 <trace_ret_do_mmap+0x3266> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3258, 0x3266, x86_l_3266);
x86_l_325a:
	/* 0x325a: jmp    3268 <trace_ret_do_mmap+0x3268> */
	X86_SIM_X86_JMP(0x325a, 0x3268, x86_l_3268);
x86_l_325c:
	/* 0x325c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_325e:
	/* 0x325e: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3261:
	/* 0x3261: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3264:
	/* 0x3264: jns    3268 <trace_ret_do_mmap+0x3268> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3264, 0x3268, x86_l_3268);
x86_l_3266:
	/* 0x3266: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3268:
	/* 0x3268: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_326a:
	/* 0x326a: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_326e:
	/* 0x326e: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3271:
	/* 0x3271: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3275:
	/* 0x3275: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3277:
	/* 0x3277: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_327a:
	/* 0x327a: jns    327e <trace_ret_do_mmap+0x327e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x327a, 0x327e, x86_l_327e);
x86_l_327c:
	/* 0x327c: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_327e:
	/* 0x327e: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_3282:
	/* 0x3282: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3285:
	/* 0x3285: jns    328c <trace_ret_do_mmap+0x328c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3285, 0x328c, x86_l_328c);
x86_l_3287:
	/* 0x3287: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_328a:
	/* 0x328a: jmp    328e <trace_ret_do_mmap+0x328e> */
	X86_SIM_X86_JMP(0x328a, 0x328e, x86_l_328e);
x86_l_328c:
	/* 0x328c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_328e:
	/* 0x328e: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3292:
	/* 0x3292: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3294:
	/* 0x3294: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3297:
	/* 0x3297: jns    32a6 <trace_ret_do_mmap+0x32a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3297, 0x32a6, x86_l_32a6);
x86_l_3299:
	/* 0x3299: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_329c:
	/* 0x329c: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_329f:
	/* 0x329f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_32a2:
	/* 0x32a2: js     32b0 <trace_ret_do_mmap+0x32b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32a2, 0x32b0, x86_l_32b0);
x86_l_32a4:
	/* 0x32a4: jmp    32b2 <trace_ret_do_mmap+0x32b2> */
	X86_SIM_X86_JMP(0x32a4, 0x32b2, x86_l_32b2);
x86_l_32a6:
	/* 0x32a6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32a8:
	/* 0x32a8: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_32ab:
	/* 0x32ab: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_32ae:
	/* 0x32ae: jns    32b2 <trace_ret_do_mmap+0x32b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32ae, 0x32b2, x86_l_32b2);
x86_l_32b0:
	/* 0x32b0: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32b2:
	/* 0x32b2: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_32b4:
	/* 0x32b4: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_32b8:
	/* 0x32b8: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_32bb:
	/* 0x32bb: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_32bf:
	/* 0x32bf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32c1:
	/* 0x32c1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_32c4:
	/* 0x32c4: jns    32c8 <trace_ret_do_mmap+0x32c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32c4, 0x32c8, x86_l_32c8);
x86_l_32c6:
	/* 0x32c6: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32c8:
	/* 0x32c8: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32cc:
	/* 0x32cc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32ce:
	/* 0x32ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32d1:
	/* 0x32d1: jns    32e0 <trace_ret_do_mmap+0x32e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32d1, 0x32e0, x86_l_32e0);
x86_l_32d3:
	/* 0x32d3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d6:
	/* 0x32d6: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32d9:
	/* 0x32d9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_32dc:
	/* 0x32dc: js     32ea <trace_ret_do_mmap+0x32ea> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32dc, 0x32ea, x86_l_32ea);
x86_l_32de:
	/* 0x32de: jmp    32ec <trace_ret_do_mmap+0x32ec> */
	X86_SIM_X86_JMP(0x32de, 0x32ec, x86_l_32ec);
x86_l_32e0:
	/* 0x32e0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32e2:
	/* 0x32e2: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32e5:
	/* 0x32e5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_32e8:
	/* 0x32e8: jns    32ec <trace_ret_do_mmap+0x32ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32e8, 0x32ec, x86_l_32ec);
x86_l_32ea:
	/* 0x32ea: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32ec:
	/* 0x32ec: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_32ee:
	/* 0x32ee: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_32f2:
	/* 0x32f2: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_32f5:
	/* 0x32f5: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_32f9:
	/* 0x32f9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32fb:
	/* 0x32fb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_32fe:
	/* 0x32fe: jns    330e <trace_ret_do_mmap+0x330e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32fe, 0x330e, x86_l_330e);
x86_l_3300:
	/* 0x3300: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3303:
	/* 0x3303: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3307:
	/* 0x3307: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_330a:
	/* 0x330a: js     3319 <trace_ret_do_mmap+0x3319> */
	X86_SIM_X86_JCC(X86_CC_S, 0x330a, 0x3319, x86_l_3319);
x86_l_330c:
	/* 0x330c: jmp    331b <trace_ret_do_mmap+0x331b> */
	X86_SIM_X86_JMP(0x330c, 0x331b, x86_l_331b);
x86_l_330e:
	/* 0x330e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3310:
	/* 0x3310: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3314:
	/* 0x3314: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3317:
	/* 0x3317: jns    331b <trace_ret_do_mmap+0x331b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3317, 0x331b, x86_l_331b);
x86_l_3319:
	/* 0x3319: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_331b:
	/* 0x331b: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3320:
	/* 0x3320: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3323:
	/* 0x3323: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3325:
	/* 0x3325: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3328:
	/* 0x3328: jns    3337 <trace_ret_do_mmap+0x3337> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3328, 0x3337, x86_l_3337);
x86_l_332a:
	/* 0x332a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_332d:
	/* 0x332d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3330:
	/* 0x3330: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3333:
	/* 0x3333: js     3341 <trace_ret_do_mmap+0x3341> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3333, 0x3341, x86_l_3341);
x86_l_3335:
	/* 0x3335: jmp    3343 <trace_ret_do_mmap+0x3343> */
	X86_SIM_X86_JMP(0x3335, 0x3343, x86_l_3343);
x86_l_3337:
	/* 0x3337: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3339:
	/* 0x3339: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_333c:
	/* 0x333c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_333f:
	/* 0x333f: jns    3343 <trace_ret_do_mmap+0x3343> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x333f, 0x3343, x86_l_3343);
x86_l_3341:
	/* 0x3341: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3343:
	/* 0x3343: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3345:
	/* 0x3345: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3349:
	/* 0x3349: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_334c:
	/* 0x334c: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3350:
	/* 0x3350: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3352:
	/* 0x3352: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3355:
	/* 0x3355: jns    3365 <trace_ret_do_mmap+0x3365> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3355, 0x3365, x86_l_3365);
x86_l_3357:
	/* 0x3357: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_335a:
	/* 0x335a: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_335e:
	/* 0x335e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3361:
	/* 0x3361: js     3370 <trace_ret_do_mmap+0x3370> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3361, 0x3370, x86_l_3370);
x86_l_3363:
	/* 0x3363: jmp    3372 <trace_ret_do_mmap+0x3372> */
	X86_SIM_X86_JMP(0x3363, 0x3372, x86_l_3372);
x86_l_3365:
	/* 0x3365: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3367:
	/* 0x3367: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_336b:
	/* 0x336b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_336e:
	/* 0x336e: jns    3372 <trace_ret_do_mmap+0x3372> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x336e, 0x3372, x86_l_3372);
x86_l_3370:
	/* 0x3370: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3372:
	/* 0x3372: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3374:
	/* 0x3374: jne    33b0 <trace_ret_do_mmap+0x33b0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3374, 0x33b0, x86_l_33b0);
x86_l_3376:
	/* 0x3376: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3378:
	/* 0x3378: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_337b:
	/* 0x337b: jns    338a <trace_ret_do_mmap+0x338a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x337b, 0x338a, x86_l_338a);
x86_l_337d:
	/* 0x337d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3380:
	/* 0x3380: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3383:
	/* 0x3383: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3386:
	/* 0x3386: js     3394 <trace_ret_do_mmap+0x3394> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3386, 0x3394, x86_l_3394);
x86_l_3388:
	/* 0x3388: jmp    3396 <trace_ret_do_mmap+0x3396> */
	X86_SIM_X86_JMP(0x3388, 0x3396, x86_l_3396);
x86_l_338a:
	/* 0x338a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_338c:
	/* 0x338c: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_338f:
	/* 0x338f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3392:
	/* 0x3392: jns    3396 <trace_ret_do_mmap+0x3396> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3392, 0x3396, x86_l_3396);
x86_l_3394:
	/* 0x3394: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3396:
	/* 0x3396: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3398:
	/* 0x3398: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_339c:
	/* 0x339c: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_339f:
	/* 0x339f: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_33a3:
	/* 0x33a3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33a5:
	/* 0x33a5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_33a8:
	/* 0x33a8: jns    33ac <trace_ret_do_mmap+0x33ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33a8, 0x33ac, x86_l_33ac);
x86_l_33aa:
	/* 0x33aa: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33ac:
	/* 0x33ac: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33b0:
	/* 0x33b0: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_33b4:
	/* 0x33b4: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_33bb:
	/* 0x33bb: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_33be:
	/* 0x33be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33c1:
	/* 0x33c1: jns    33c8 <trace_ret_do_mmap+0x33c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33c1, 0x33c8, x86_l_33c8);
x86_l_33c3:
	/* 0x33c3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33c6:
	/* 0x33c6: jmp    33ca <trace_ret_do_mmap+0x33ca> */
	X86_SIM_X86_JMP(0x33c6, 0x33ca, x86_l_33ca);
x86_l_33c8:
	/* 0x33c8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33ca:
	/* 0x33ca: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_33ce:
	/* 0x33ce: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33d0:
	/* 0x33d0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33d3:
	/* 0x33d3: jns    33df <trace_ret_do_mmap+0x33df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33d3, 0x33df, x86_l_33df);
x86_l_33d5:
	/* 0x33d5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33d8:
	/* 0x33d8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33db:
	/* 0x33db: js     33e6 <trace_ret_do_mmap+0x33e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x33db, 0x33e6, x86_l_33e6);
x86_l_33dd:
	/* 0x33dd: jmp    33e8 <trace_ret_do_mmap+0x33e8> */
	X86_SIM_X86_JMP(0x33dd, 0x33e8, x86_l_33e8);
x86_l_33df:
	/* 0x33df: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33e1:
	/* 0x33e1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33e4:
	/* 0x33e4: jns    33e8 <trace_ret_do_mmap+0x33e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33e4, 0x33e8, x86_l_33e8);
x86_l_33e6:
	/* 0x33e6: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33e8:
	/* 0x33e8: add    rbp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_33ec:
	/* 0x33ec: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_33f0:
	/* 0x33f0: call   33f5 <trace_ret_do_mmap+0x33f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_33f5:
	/* 0x33f5: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33f9:
	/* 0x33f9: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_33fd:
	/* 0x33fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3400:
	/* 0x3400: jns    3407 <trace_ret_do_mmap+0x3407> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3400, 0x3407, x86_l_3407);
x86_l_3402:
	/* 0x3402: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3405:
	/* 0x3405: jmp    3409 <trace_ret_do_mmap+0x3409> */
	X86_SIM_X86_JMP(0x3405, 0x3409, x86_l_3409);
x86_l_3407:
	/* 0x3407: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3409:
	/* 0x3409: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_340d:
	/* 0x340d: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3411:
	/* 0x3411: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3414:
	/* 0x3414: jns    341b <trace_ret_do_mmap+0x341b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3414, 0x341b, x86_l_341b);
x86_l_3416:
	/* 0x3416: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3419:
	/* 0x3419: jmp    341d <trace_ret_do_mmap+0x341d> */
	X86_SIM_X86_JMP(0x3419, 0x341d, x86_l_341d);
x86_l_341b:
	/* 0x341b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_341d:
	/* 0x341d: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3421:
	/* 0x3421: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3425:
	/* 0x3425: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3428:
	/* 0x3428: jns    3430 <trace_ret_do_mmap+0x3430> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3428, 0x3430, x86_l_3430);
x86_l_342a:
	/* 0x342a: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_342e:
	/* 0x342e: jmp    3432 <trace_ret_do_mmap+0x3432> */
	X86_SIM_X86_JMP(0x342e, 0x3432, x86_l_3432);
x86_l_3430:
	/* 0x3430: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3432:
	/* 0x3432: mov    r15,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3437:
	/* 0x3437: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_343b:
	/* 0x343b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_343e:
	/* 0x343e: jns    344b <trace_ret_do_mmap+0x344b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x343e, 0x344b, x86_l_344b);
x86_l_3440:
	/* 0x3440: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3442:
	/* 0x3442: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3444:
	/* 0x3444: je     344b <trace_ret_do_mmap+0x344b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3444, 0x344b, x86_l_344b);
x86_l_3446:
	/* 0x3446: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_344b:
	/* 0x344b: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3450:
	/* 0x3450: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3454:
	/* 0x3454: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_345c:
	/* 0x345c: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_3464:
	/* 0x3464: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3469:
	/* 0x3469: call   346e <trace_ret_do_mmap+0x346e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_346e:
	/* 0x346e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3471:
	/* 0x3471: jns    348a <trace_ret_do_mmap+0x348a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3471, 0x348a, x86_l_348a);
x86_l_3473:
	/* 0x3473: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3477:
	/* 0x3477: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_347c:
	/* 0x347c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_347f:
	/* 0x347f: js     3496 <trace_ret_do_mmap+0x3496> */
	X86_SIM_X86_JCC(X86_CC_S, 0x347f, 0x3496, x86_l_3496);
x86_l_3481:
	/* 0x3481: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3483:
	/* 0x3483: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3486:
	/* 0x3486: js     349e <trace_ret_do_mmap+0x349e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3486, 0x349e, x86_l_349e);
x86_l_3488:
	/* 0x3488: jmp    34df <trace_ret_do_mmap+0x34df> */
	X86_SIM_X86_JMP(0x3488, 0x34df, x86_l_34df);
x86_l_348a:
	/* 0x348a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_348c:
	/* 0x348c: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3491:
	/* 0x3491: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3494:
	/* 0x3494: jns    3481 <trace_ret_do_mmap+0x3481> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3494, 0x3481, x86_l_3481);
x86_l_3496:
	/* 0x3496: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3499:
	/* 0x3499: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_349c:
	/* 0x349c: jns    34df <trace_ret_do_mmap+0x34df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x349c, 0x34df, x86_l_34df);
x86_l_349e:
	/* 0x349e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34a1:
	/* 0x34a1: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_34a6:
	/* 0x34a6: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34aa:
	/* 0x34aa: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_34af:
	/* 0x34af: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_34b3:
	/* 0x34b3: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_34b8:
	/* 0x34b8: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_34bc:
	/* 0x34bc: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_34c1:
	/* 0x34c1: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_34c5:
	/* 0x34c5: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_34ca:
	/* 0x34ca: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_34ce:
	/* 0x34ce: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_34d3:
	/* 0x34d3: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_34d7:
	/* 0x34d7: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34db:
	/* 0x34db: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_34df:
	/* 0x34df: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_34e4:
	/* 0x34e4: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_34e8:
	/* 0x34e8: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_34ed:
	/* 0x34ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_34f0:
	/* 0x34f0: jns    35c6 <trace_ret_do_mmap+0x35c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34f0, 0x35c6, x86_l_35c6);
x86_l_34f6:
	/* 0x34f6: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_34f9:
	/* 0x34f9: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34fb:
	/* 0x34fb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_34fd:
	/* 0x34fd: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34fd, 0x35d5, x86_l_35d5);
x86_l_3503:
	/* 0x3503: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_3507:
	/* 0x3507: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_350b:
	/* 0x350b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_350d:
	/* 0x350d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x350d, 0x35d5, x86_l_35d5);
x86_l_3513:
	/* 0x3513: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_3517:
	/* 0x3517: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_351b:
	/* 0x351b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_351d:
	/* 0x351d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x351d, 0x35d5, x86_l_35d5);
x86_l_3523:
	/* 0x3523: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_3527:
	/* 0x3527: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_352b:
	/* 0x352b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_352d:
	/* 0x352d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x352d, 0x35d5, x86_l_35d5);
x86_l_3533:
	/* 0x3533: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_3537:
	/* 0x3537: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_353b:
	/* 0x353b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_353d:
	/* 0x353d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x353d, 0x35d5, x86_l_35d5);
x86_l_3543:
	/* 0x3543: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_3547:
	/* 0x3547: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_354b:
	/* 0x354b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_354d:
	/* 0x354d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x354d, 0x35d5, x86_l_35d5);
x86_l_3553:
	/* 0x3553: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3557:
	/* 0x3557: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_355b:
	/* 0x355b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_355d:
	/* 0x355d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x355d, 0x35d5, x86_l_35d5);
x86_l_355f:
	/* 0x355f: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3563:
	/* 0x3563: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_3567:
	/* 0x3567: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3569:
	/* 0x3569: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3569, 0x35d5, x86_l_35d5);
x86_l_356b:
	/* 0x356b: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_356f:
	/* 0x356f: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_3573:
	/* 0x3573: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3575:
	/* 0x3575: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3575, 0x35d5, x86_l_35d5);
x86_l_3577:
	/* 0x3577: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_357b:
	/* 0x357b: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_357f:
	/* 0x357f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3581:
	/* 0x3581: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3581, 0x35d5, x86_l_35d5);
x86_l_3583:
	/* 0x3583: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_3587:
	/* 0x3587: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_358b:
	/* 0x358b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_358d:
	/* 0x358d: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x358d, 0x35d5, x86_l_35d5);
x86_l_358f:
	/* 0x358f: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_3593:
	/* 0x3593: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_3597:
	/* 0x3597: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3599:
	/* 0x3599: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3599, 0x35d5, x86_l_35d5);
x86_l_359b:
	/* 0x359b: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_359f:
	/* 0x359f: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_35a3:
	/* 0x35a3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_35a5:
	/* 0x35a5: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35a5, 0x35d5, x86_l_35d5);
x86_l_35a7:
	/* 0x35a7: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_35ab:
	/* 0x35ab: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_35af:
	/* 0x35af: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_35b1:
	/* 0x35b1: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35b1, 0x35d5, x86_l_35d5);
x86_l_35b3:
	/* 0x35b3: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_35b7:
	/* 0x35b7: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_35bb:
	/* 0x35bb: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_35bd:
	/* 0x35bd: je     35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35bd, 0x35d5, x86_l_35d5);
x86_l_35bf:
	/* 0x35bf: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_35c4:
	/* 0x35c4: jmp    35d5 <trace_ret_do_mmap+0x35d5> */
	X86_SIM_X86_JMP(0x35c4, 0x35d5, x86_l_35d5);
x86_l_35c6:
	/* 0x35c6: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_35ce:
	/* 0x35ce: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35d5:
	/* 0x35d5: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_35d8:
	/* 0x35d8: jns    3652 <trace_ret_do_mmap+0x3652> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35d8, 0x3652, x86_l_3652);
x86_l_35da:
	/* 0x35da: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35de:
	/* 0x35de: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_35e3:
	/* 0x35e3: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35e6:
	/* 0x35e6: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35ea:
	/* 0x35ea: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35ee:
	/* 0x35ee: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35f2:
	/* 0x35f2: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35f6:
	/* 0x35f6: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_35fa:
	/* 0x35fa: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_35fe:
	/* 0x35fe: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3602:
	/* 0x3602: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3606:
	/* 0x3606: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_360a:
	/* 0x360a: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_360e:
	/* 0x360e: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3612:
	/* 0x3612: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3616:
	/* 0x3616: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_361a:
	/* 0x361a: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_361e:
	/* 0x361e: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3622:
	/* 0x3622: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3626:
	/* 0x3626: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_362a:
	/* 0x362a: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_362e:
	/* 0x362e: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3632:
	/* 0x3632: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3636:
	/* 0x3636: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_363a:
	/* 0x363a: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_363e:
	/* 0x363e: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3642:
	/* 0x3642: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3646:
	/* 0x3646: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_364b:
	/* 0x364b: jne    36c5 <trace_ret_do_mmap+0x36c5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x364b, 0x36c5, x86_l_36c5);
x86_l_364d:
	/* 0x364d: jmp    36e1 <trace_ret_do_mmap+0x36e1> */
	X86_SIM_X86_JMP(0x364d, 0x36e1, x86_l_36e1);
x86_l_3652:
	/* 0x3652: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3657:
	/* 0x3657: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_365f:
	/* 0x365f: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3667:
	/* 0x3667: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_366f:
	/* 0x366f: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_3677:
	/* 0x3677: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_367f:
	/* 0x367f: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_3687:
	/* 0x3687: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_368f:
	/* 0x368f: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_3697:
	/* 0x3697: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_369f:
	/* 0x369f: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_36a7:
	/* 0x36a7: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_36af:
	/* 0x36af: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_36b7:
	/* 0x36b7: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36be:
	/* 0x36be: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_36c3:
	/* 0x36c3: je     36e1 <trace_ret_do_mmap+0x36e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36c3, 0x36e1, x86_l_36e1);
x86_l_36c5:
	/* 0x36c5: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_36cc:
	/* 0x36cc: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_36d1:
	/* 0x36d1: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_36d4:
	/* 0x36d4: call   36d9 <trace_ret_do_mmap+0x36d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_36d9:
	/* 0x36d9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_36db:
	/* 0x36db: js     36e1 <trace_ret_do_mmap+0x36e1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x36db, 0x36e1, x86_l_36e1);
x86_l_36dd:
	/* 0x36dd: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_36e1:
	/* 0x36e1: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_36e9:
	/* 0x36e9: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_36ee:
	/* 0x36ee: jb     36f5 <trace_ret_do_mmap+0x36f5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x36ee, 0x36f5, x86_l_36f5);
x86_l_36f0:
	/* 0x36f0: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_36f5:
	/* 0x36f5: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_36fa:
	/* 0x36fa: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_36fe:
	/* 0x36fe: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_3705:
	/* 0x3705: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_370a:
	/* 0x370a: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_370d:
	/* 0x370d: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3710:
	/* 0x3710: call   3715 <trace_ret_do_mmap+0x3715> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_3715:
	/* 0x3715: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3718:
	/* 0x3718: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_371a:
	/* 0x371a: add    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 264ULL);
x86_l_3721:
	/* 0x3721: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3722:
	/* 0x3722: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3724:
	/* 0x3724: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3726:
	/* 0x3726: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3728:
	/* 0x3728: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_372a:
	/* 0x372a: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_372b:
	/* 0x372b: jmp    37ef <trace_ret_do_mmap+0x37ef> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3730:
	/* 0x3730: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3733:
	/* 0x3733: jne    37e7 <trace_ret_do_mmap+0x37e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3733, 0x37e7, x86_l_37e7);
x86_l_3739:
	/* 0x3739: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_373c:
	/* 0x373c: je     37e7 <trace_ret_do_mmap+0x37e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x373c, 0x37e7, x86_l_37e7);
x86_l_3742:
	/* 0x3742: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3746:
	/* 0x3746: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3749:
	/* 0x3749: jns    378c <trace_ret_do_mmap+0x378c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3749, 0x378c, x86_l_378c);
x86_l_374b:
	/* 0x374b: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_374e:
	/* 0x374e: jmp    378e <trace_ret_do_mmap+0x378e> */
	X86_SIM_X86_JMP(0x374e, 0x378e, x86_l_378e);
x86_l_3750:
	/* 0x3750: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_3753:
	/* 0x3753: je     37e7 <trace_ret_do_mmap+0x37e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3753, 0x37e7, x86_l_37e7);
x86_l_3759:
	/* 0x3759: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_375f:
	/* 0x375f: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3762:
	/* 0x3762: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3765:
	/* 0x3765: jns    37ab <trace_ret_do_mmap+0x37ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3765, 0x37ab, x86_l_37ab);
x86_l_3767:
	/* 0x3767: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_376b:
	/* 0x376b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_376d:
	/* 0x376d: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3770:
	/* 0x3770: je     37b3 <trace_ret_do_mmap+0x37b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3770, 0x37b3, x86_l_37b3);
x86_l_3772:
	/* 0x3772: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3776:
	/* 0x3776: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_377b:
	/* 0x377b: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_377f:
	/* 0x377f: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_3782:
	/* 0x3782: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3785:
	/* 0x3785: jne    376d <trace_ret_do_mmap+0x376d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3785, 0x376d, x86_l_376d);
x86_l_3787:
	/* 0x3787: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_378a:
	/* 0x378a: jmp    37b7 <trace_ret_do_mmap+0x37b7> */
	X86_SIM_X86_JMP(0x378a, 0x37b7, x86_l_37b7);
x86_l_378c:
	/* 0x378c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_378e:
	/* 0x378e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3791:
	/* 0x3791: jns    3798 <trace_ret_do_mmap+0x3798> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3791, 0x3798, x86_l_3798);
x86_l_3793:
	/* 0x3793: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3796:
	/* 0x3796: jmp    379a <trace_ret_do_mmap+0x379a> */
	X86_SIM_X86_JMP(0x3796, 0x379a, x86_l_379a);
x86_l_3798:
	/* 0x3798: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_379a:
	/* 0x379a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_379d:
	/* 0x379d: jns    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x379d, 0x2ada, x86_l_2ada);
x86_l_37a3:
	/* 0x37a3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37a6:
	/* 0x37a6: jmp    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JMP(0x37a6, 0x2ada, x86_l_2ada);
x86_l_37ab:
	/* 0x37ab: mov    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_37ae:
	/* 0x37ae: jmp    2931 <trace_ret_do_mmap+0x2931> */
	X86_SIM_X86_JMP(0x37ae, 0x2931, x86_l_2931);
x86_l_37b3:
	/* 0x37b3: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_37b7:
	/* 0x37b7: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_37bb:
	/* 0x37bb: jl     37e7 <trace_ret_do_mmap+0x37e7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x37bb, 0x37e7, x86_l_37e7);
x86_l_37bd:
	/* 0x37bd: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37c2:
	/* 0x37c2: lea    eax,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_37c6:
	/* 0x37c6: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_37cb:
	/* 0x37cb: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_37d0:
	/* 0x37d0: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_37d3:
	/* 0x37d3: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37d8:
	/* 0x37d8: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37dd:
	/* 0x37dd: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_37e2:
	/* 0x37e2: jmp    efb <trace_ret_do_mmap+0xefb> */
	X86_SIM_X86_JMP(0x37e2, 0xefb, x86_l_efb);
x86_l_37e7:
	/* 0x37e7: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_37ea:
	/* 0x37ea: jmp    2ada <trace_ret_do_mmap+0x2ada> */
	X86_SIM_X86_JMP(0x37ea, 0x2ada, x86_l_2ada);
x86_l_37ef:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
