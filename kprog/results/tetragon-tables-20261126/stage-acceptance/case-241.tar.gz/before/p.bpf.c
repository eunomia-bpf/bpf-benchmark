#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 200U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(6) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(18)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 prog_array[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 use_security_bprm_creds_for_exec[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/exec_binprm")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 152ULL);
x86_l_11:
	/* 0x11: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)use_security_bprm_creds_for_exec));
x86_l_18:
	/* 0x18: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a:
	/* 0x1a: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d:
	/* 0x1d: je     37 <trace_exec_binprm+0x37> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d, 0x37, x86_l_37);
x86_l_1f:
	/* 0x1f: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21:
	/* 0x21: add    rsp,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_28:
	/* 0x28: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29:
	/* 0x29: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2b:
	/* 0x2b: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2f:
	/* 0x2f: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_31:
	/* 0x31: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32:
	/* 0x32: jmp    329c <trace_exec_binprm+0x329c> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_37:
	/* 0x37: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3a:
	/* 0x3a: mov    DWORD PTR [rsp+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_42:
	/* 0x42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_49:
	/* 0x49: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_exec_binprm+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x1f, x86_l_1f);
x86_l_58:
	/* 0x58: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b:
	/* 0x5b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_62:
	/* 0x62: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_67:
	/* 0x67: call   6c <trace_exec_binprm+0x6c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6c:
	/* 0x6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f:
	/* 0x6f: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f, 0x1f, x86_l_1f);
x86_l_71:
	/* 0x71: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_74:
	/* 0x74: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_7e:
	/* 0x7e: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_86:
	/* 0x86: mov    QWORD PTR [r14+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_91:
	/* 0x91: mov    QWORD PTR [r14+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_9c:
	/* 0x9c: mov    QWORD PTR [r14+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_a7:
	/* 0xa7: mov    QWORD PTR [r14+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_b2:
	/* 0xb2: mov    QWORD PTR [r14+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_bd:
	/* 0xbd: mov    QWORD PTR [r14+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_c8:
	/* 0xc8: mov    QWORD PTR [r14+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_d3:
	/* 0xd3: mov    QWORD PTR [r14+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_de:
	/* 0xde: call   e3 <trace_exec_binprm+0xe3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_e3:
	/* 0xe3: mov    QWORD PTR [r14+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_ea:
	/* 0xea: mov    QWORD PTR [r14+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_f2:
	/* 0xf2: mov    QWORD PTR [r14+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_fa:
	/* 0xfa: mov    QWORD PTR [r14+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_102:
	/* 0x102: mov    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_10a:
	/* 0x10a: mov    QWORD PTR [r14+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_112:
	/* 0x112: mov    QWORD PTR [r14+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_11a:
	/* 0x11a: mov    QWORD PTR [r14+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_122:
	/* 0x122: mov    QWORD PTR [r14+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_12a:
	/* 0x12a: mov    QWORD PTR [r14+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_132:
	/* 0x132: mov    QWORD PTR [r14+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_13a:
	/* 0x13a: mov    QWORD PTR [r14+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_142:
	/* 0x142: mov    QWORD PTR [r14+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_14a:
	/* 0x14a: mov    QWORD PTR [r14+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_152:
	/* 0x152: call   157 <trace_exec_binprm+0x157> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_157:
	/* 0x157: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_15b:
	/* 0x15b: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_15f:
	/* 0x15f: mov    DWORD PTR [r14+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_163:
	/* 0x163: mov    DWORD PTR [r14+0x70],0x314 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337940ULL);
x86_l_16b:
	/* 0x16b: call   170 <trace_exec_binprm+0x170> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_170:
	/* 0x170: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_173:
	/* 0x173: call   178 <trace_exec_binprm+0x178> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_178:
	/* 0x178: mov    WORD PTR [r14+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_17d:
	/* 0x17d: call   182 <trace_exec_binprm+0x182> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_182:
	/* 0x182: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_185:
	/* 0x185: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_189:
	/* 0x189: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c:
	/* 0x18c: jns    19d <trace_exec_binprm+0x19d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c, 0x19d, x86_l_19d);
x86_l_18e:
	/* 0x18e: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_190:
	/* 0x190: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_195:
	/* 0x195: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_19b:
	/* 0x19b: jne    1d7 <trace_exec_binprm+0x1d7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19b, 0x1d7, x86_l_1d7);
x86_l_19d:
	/* 0x19d: call   1a2 <trace_exec_binprm+0x1a2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_1a2:
	/* 0x1a2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a5:
	/* 0x1a5: call   1aa <trace_exec_binprm+0x1aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_1aa:
	/* 0x1aa: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_1ae:
	/* 0x1ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b1:
	/* 0x1b1: jns    1c1 <trace_exec_binprm+0x1c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1, 0x1c1, x86_l_1c1);
x86_l_1b3:
	/* 0x1b3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b6:
	/* 0x1b6: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1ba:
	/* 0x1ba: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1bd:
	/* 0x1bd: js     1cc <trace_exec_binprm+0x1cc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bd, 0x1cc, x86_l_1cc);
x86_l_1bf:
	/* 0x1bf: jmp    1d3 <trace_exec_binprm+0x1d3> */
	X86_SIM_X86_JMP(0x1bf, 0x1d3, x86_l_1d3);
x86_l_1c1:
	/* 0x1c1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c7:
	/* 0x1c7: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ca:
	/* 0x1ca: jns    1d3 <trace_exec_binprm+0x1d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca, 0x1d3, x86_l_1d3);
x86_l_1cc:
	/* 0x1cc: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf:
	/* 0x1cf: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1d1:
	/* 0x1d1: jne    248 <trace_exec_binprm+0x248> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d1, 0x248, x86_l_248);
x86_l_1d3:
	/* 0x1d3: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1d7:
	/* 0x1d7: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1db:
	/* 0x1db: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1df:
	/* 0x1df: mov    DWORD PTR [rsp+0x8c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_1e6:
	/* 0x1e6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1ed:
	/* 0x1ed: lea    rsi,[rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_1f5:
	/* 0x1f5: call   1fa <trace_exec_binprm+0x1fa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1fa:
	/* 0x1fa: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe:
	/* 0x1fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201:
	/* 0x201: je     26f <trace_exec_binprm+0x26f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201, 0x26f, x86_l_26f);
x86_l_203:
	/* 0x203: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_207:
	/* 0x207: mov    DWORD PTR [rsp+0x88],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_20e:
	/* 0x20e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_215:
	/* 0x215: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_21d:
	/* 0x21d: call   222 <trace_exec_binprm+0x222> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_222:
	/* 0x222: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_225:
	/* 0x225: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: mov    QWORD PTR [rsp+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d:
	/* 0x22d: je     2f1 <trace_exec_binprm+0x2f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22d, 0x2f1, x86_l_2f1);
x86_l_233:
	/* 0x233: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_238:
	/* 0x238: jne    6f4 <trace_exec_binprm+0x6f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x238, 0x6f4, x86_l_6f4);
x86_l_23e:
	/* 0x23e: call   243 <trace_exec_binprm+0x243> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_243:
	/* 0x243: jmp    74c <trace_exec_binprm+0x74c> */
	X86_SIM_X86_JMP(0x243, 0x74c, x86_l_74c);
x86_l_248:
	/* 0x248: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_24f:
	/* 0x24f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_254:
	/* 0x254: call   259 <trace_exec_binprm+0x259> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_259:
	/* 0x259: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25c:
	/* 0x25c: je     265 <trace_exec_binprm+0x265> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c, 0x265, x86_l_265);
x86_l_25e:
	/* 0x25e: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260:
	/* 0x260: jmp    1d7 <trace_exec_binprm+0x1d7> */
	X86_SIM_X86_JMP(0x260, 0x1d7, x86_l_1d7);
x86_l_265:
	/* 0x265: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_26a:
	/* 0x26a: jmp    1d7 <trace_exec_binprm+0x1d7> */
	X86_SIM_X86_JMP(0x26a, 0x1d7, x86_l_1d7);
x86_l_26f:
	/* 0x26f: mov    eax,DWORD PTR [rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_276:
	/* 0x276: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_27a:
	/* 0x27a: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_282:
	/* 0x282: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_289:
	/* 0x289: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_28e:
	/* 0x28e: call   293 <trace_exec_binprm+0x293> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_293:
	/* 0x293: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_296:
	/* 0x296: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x296, 0x1f, x86_l_1f);
x86_l_29c:
	/* 0x29c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29f:
	/* 0x29f: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a3:
	/* 0x2a3: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2a7:
	/* 0x2a7: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_2ac:
	/* 0x2ac: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2af:
	/* 0x2af: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b1:
	/* 0x2b1: call   2b6 <trace_exec_binprm+0x2b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_2b6:
	/* 0x2b6: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_2bd:
	/* 0x2bd: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2c2:
	/* 0x2c2: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2c7:
	/* 0x2c7: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2ca:
	/* 0x2ca: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2cd:
	/* 0x2cd: call   2d2 <trace_exec_binprm+0x2d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2d2:
	/* 0x2d2: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2d7:
	/* 0x2d7: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2da:
	/* 0x2da: call   2df <trace_exec_binprm+0x2df> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2df:
	/* 0x2df: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e3:
	/* 0x2e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e6:
	/* 0x2e6: jne    203 <trace_exec_binprm+0x203> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e6, 0x203, x86_l_203);
x86_l_2ec:
	/* 0x2ec: jmp    1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JMP(0x2ec, 0x1f, x86_l_1f);
x86_l_2f1:
	/* 0x2f1: mov    eax,DWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2f8:
	/* 0x2f8: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2fc:
	/* 0x2fc: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_304:
	/* 0x304: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_30b:
	/* 0x30b: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_310:
	/* 0x310: call   315 <trace_exec_binprm+0x315> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_315:
	/* 0x315: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_318:
	/* 0x318: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x318, 0x1f, x86_l_1f);
x86_l_31e:
	/* 0x31e: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_321:
	/* 0x321: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_325:
	/* 0x325: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_329:
	/* 0x329: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_32e:
	/* 0x32e: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_331:
	/* 0x331: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_333:
	/* 0x333: call   338 <trace_exec_binprm+0x338> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_338:
	/* 0x338: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_33f:
	/* 0x33f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_344:
	/* 0x344: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_349:
	/* 0x349: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_34c:
	/* 0x34c: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_34f:
	/* 0x34f: call   354 <trace_exec_binprm+0x354> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_354:
	/* 0x354: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_359:
	/* 0x359: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_35c:
	/* 0x35c: call   361 <trace_exec_binprm+0x361> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_361:
	/* 0x361: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_364:
	/* 0x364: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x364, 0x1f, x86_l_1f);
x86_l_36a:
	/* 0x36a: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36d:
	/* 0x36d: mov    r15,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_374:
	/* 0x374: lea    rax,[r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_378:
	/* 0x378: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37b:
	/* 0x37b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_37e:
	/* 0x37e: jns    385 <trace_exec_binprm+0x385> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37e, 0x385, x86_l_385);
x86_l_380:
	/* 0x380: mov    r14,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_383:
	/* 0x383: jmp    388 <trace_exec_binprm+0x388> */
	X86_SIM_X86_JMP(0x383, 0x388, x86_l_388);
x86_l_385:
	/* 0x385: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_388:
	/* 0x388: lea    rcx,[r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_38c:
	/* 0x38c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_38f:
	/* 0x38f: jns    396 <trace_exec_binprm+0x396> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38f, 0x396, x86_l_396);
x86_l_391:
	/* 0x391: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_394:
	/* 0x394: jmp    398 <trace_exec_binprm+0x398> */
	X86_SIM_X86_JMP(0x394, 0x398, x86_l_398);
x86_l_396:
	/* 0x396: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_398:
	/* 0x398: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_39c:
	/* 0x39c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39e:
	/* 0x39e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3a1:
	/* 0x3a1: jns    3a8 <trace_exec_binprm+0x3a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a1, 0x3a8, x86_l_3a8);
x86_l_3a3:
	/* 0x3a3: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a6:
	/* 0x3a6: jmp    3aa <trace_exec_binprm+0x3aa> */
	X86_SIM_X86_JMP(0x3a6, 0x3aa, x86_l_3aa);
x86_l_3a8:
	/* 0x3a8: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3aa:
	/* 0x3aa: lea    rdx,[rbx+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3ae:
	/* 0x3ae: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3b1:
	/* 0x3b1: jns    3b5 <trace_exec_binprm+0x3b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b1, 0x3b5, x86_l_3b5);
x86_l_3b3:
	/* 0x3b3: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b5:
	/* 0x3b5: mov    DWORD PTR [rbp+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_3b8:
	/* 0x3b8: lea    rcx,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3bc:
	/* 0x3bc: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3bf:
	/* 0x3bf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c1:
	/* 0x3c1: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3c4:
	/* 0x3c4: jns    3cb <trace_exec_binprm+0x3cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c4, 0x3cb, x86_l_3cb);
x86_l_3c6:
	/* 0x3c6: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c9:
	/* 0x3c9: jmp    3cd <trace_exec_binprm+0x3cd> */
	X86_SIM_X86_JMP(0x3c9, 0x3cd, x86_l_3cd);
x86_l_3cb:
	/* 0x3cb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3cd:
	/* 0x3cd: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d0:
	/* 0x3d0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3d3:
	/* 0x3d3: jns    3d7 <trace_exec_binprm+0x3d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d3, 0x3d7, x86_l_3d7);
x86_l_3d5:
	/* 0x3d5: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d7:
	/* 0x3d7: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3d9:
	/* 0x3d9: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3dd:
	/* 0x3dd: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3e0:
	/* 0x3e0: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3e4:
	/* 0x3e4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e6:
	/* 0x3e6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3e9:
	/* 0x3e9: jns    3ed <trace_exec_binprm+0x3ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e9, 0x3ed, x86_l_3ed);
x86_l_3eb:
	/* 0x3eb: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ed:
	/* 0x3ed: mov    DWORD PTR [rbp+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3f0:
	/* 0x3f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f3:
	/* 0x3f3: jns    3fa <trace_exec_binprm+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f3, 0x3fa, x86_l_3fa);
x86_l_3f5:
	/* 0x3f5: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f8:
	/* 0x3f8: jmp    3fc <trace_exec_binprm+0x3fc> */
	X86_SIM_X86_JMP(0x3f8, 0x3fc, x86_l_3fc);
x86_l_3fa:
	/* 0x3fa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fc:
	/* 0x3fc: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_400:
	/* 0x400: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_402:
	/* 0x402: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_405:
	/* 0x405: jns    40c <trace_exec_binprm+0x40c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x405, 0x40c, x86_l_40c);
x86_l_407:
	/* 0x407: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40a:
	/* 0x40a: jmp    40e <trace_exec_binprm+0x40e> */
	X86_SIM_X86_JMP(0x40a, 0x40e, x86_l_40e);
x86_l_40c:
	/* 0x40c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_40e:
	/* 0x40e: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_411:
	/* 0x411: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_414:
	/* 0x414: jns    418 <trace_exec_binprm+0x418> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x414, 0x418, x86_l_418);
x86_l_416:
	/* 0x416: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_418:
	/* 0x418: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_41a:
	/* 0x41a: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_41e:
	/* 0x41e: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_421:
	/* 0x421: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_425:
	/* 0x425: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_427:
	/* 0x427: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_42a:
	/* 0x42a: jns    42e <trace_exec_binprm+0x42e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x42a, 0x42e, x86_l_42e);
x86_l_42c:
	/* 0x42c: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_42e:
	/* 0x42e: mov    DWORD PTR [rbp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_431:
	/* 0x431: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_433:
	/* 0x433: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_436:
	/* 0x436: jns    43d <trace_exec_binprm+0x43d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x436, 0x43d, x86_l_43d);
x86_l_438:
	/* 0x438: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43b:
	/* 0x43b: jmp    43f <trace_exec_binprm+0x43f> */
	X86_SIM_X86_JMP(0x43b, 0x43f, x86_l_43f);
x86_l_43d:
	/* 0x43d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_43f:
	/* 0x43f: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_442:
	/* 0x442: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_445:
	/* 0x445: jns    449 <trace_exec_binprm+0x449> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x445, 0x449, x86_l_449);
x86_l_447:
	/* 0x447: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_449:
	/* 0x449: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_44b:
	/* 0x44b: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_44f:
	/* 0x44f: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_452:
	/* 0x452: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_456:
	/* 0x456: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_458:
	/* 0x458: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_45b:
	/* 0x45b: jns    462 <trace_exec_binprm+0x462> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45b, 0x462, x86_l_462);
x86_l_45d:
	/* 0x45d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_460:
	/* 0x460: jmp    464 <trace_exec_binprm+0x464> */
	X86_SIM_X86_JMP(0x460, 0x464, x86_l_464);
x86_l_462:
	/* 0x462: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_464:
	/* 0x464: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_468:
	/* 0x468: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_46b:
	/* 0x46b: jns    46f <trace_exec_binprm+0x46f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x46b, 0x46f, x86_l_46f);
x86_l_46d:
	/* 0x46d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_46f:
	/* 0x46f: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_473:
	/* 0x473: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_476:
	/* 0x476: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_478:
	/* 0x478: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_47b:
	/* 0x47b: jns    482 <trace_exec_binprm+0x482> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x47b, 0x482, x86_l_482);
x86_l_47d:
	/* 0x47d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_480:
	/* 0x480: jmp    484 <trace_exec_binprm+0x484> */
	X86_SIM_X86_JMP(0x480, 0x484, x86_l_484);
x86_l_482:
	/* 0x482: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_484:
	/* 0x484: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_487:
	/* 0x487: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_48a:
	/* 0x48a: jns    48e <trace_exec_binprm+0x48e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x48a, 0x48e, x86_l_48e);
x86_l_48c:
	/* 0x48c: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48e:
	/* 0x48e: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_490:
	/* 0x490: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_494:
	/* 0x494: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_497:
	/* 0x497: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_49b:
	/* 0x49b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49d:
	/* 0x49d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4a0:
	/* 0x4a0: jns    4a7 <trace_exec_binprm+0x4a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4a0, 0x4a7, x86_l_4a7);
x86_l_4a2:
	/* 0x4a2: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a5:
	/* 0x4a5: jmp    4a9 <trace_exec_binprm+0x4a9> */
	X86_SIM_X86_JMP(0x4a5, 0x4a9, x86_l_4a9);
x86_l_4a7:
	/* 0x4a7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a9:
	/* 0x4a9: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_4ad:
	/* 0x4ad: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4b0:
	/* 0x4b0: jns    4b4 <trace_exec_binprm+0x4b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4b0, 0x4b4, x86_l_4b4);
x86_l_4b2:
	/* 0x4b2: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b4:
	/* 0x4b4: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b9:
	/* 0x4b9: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4bb:
	/* 0x4bb: jne    4ee <trace_exec_binprm+0x4ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4bb, 0x4ee, x86_l_4ee);
x86_l_4bd:
	/* 0x4bd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4bf:
	/* 0x4bf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4c2:
	/* 0x4c2: jns    4c9 <trace_exec_binprm+0x4c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4c2, 0x4c9, x86_l_4c9);
x86_l_4c4:
	/* 0x4c4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c7:
	/* 0x4c7: jmp    4cb <trace_exec_binprm+0x4cb> */
	X86_SIM_X86_JMP(0x4c7, 0x4cb, x86_l_4cb);
x86_l_4c9:
	/* 0x4c9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4cb:
	/* 0x4cb: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4ce:
	/* 0x4ce: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4d1:
	/* 0x4d1: jns    4d5 <trace_exec_binprm+0x4d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4d1, 0x4d5, x86_l_4d5);
x86_l_4d3:
	/* 0x4d3: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d5:
	/* 0x4d5: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4d7:
	/* 0x4d7: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_4db:
	/* 0x4db: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4de:
	/* 0x4de: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4e2:
	/* 0x4e2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e4:
	/* 0x4e4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4e7:
	/* 0x4e7: jns    4eb <trace_exec_binprm+0x4eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4e7, 0x4eb, x86_l_4eb);
x86_l_4e9:
	/* 0x4e9: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4eb:
	/* 0x4eb: mov    DWORD PTR [rbp+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4ee:
	/* 0x4ee: mov    DWORD PTR [rbp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4f1:
	/* 0x4f1: lea    r12,[r15+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4f8:
	/* 0x4f8: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4fb:
	/* 0x4fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4fe:
	/* 0x4fe: jns    505 <trace_exec_binprm+0x505> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4fe, 0x505, x86_l_505);
x86_l_500:
	/* 0x500: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_503:
	/* 0x503: jmp    507 <trace_exec_binprm+0x507> */
	X86_SIM_X86_JMP(0x503, 0x507, x86_l_507);
x86_l_505:
	/* 0x505: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_507:
	/* 0x507: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_50b:
	/* 0x50b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_50d:
	/* 0x50d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_510:
	/* 0x510: jns    517 <trace_exec_binprm+0x517> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x510, 0x517, x86_l_517);
x86_l_512:
	/* 0x512: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_515:
	/* 0x515: jmp    519 <trace_exec_binprm+0x519> */
	X86_SIM_X86_JMP(0x515, 0x519, x86_l_519);
x86_l_517:
	/* 0x517: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_519:
	/* 0x519: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_51c:
	/* 0x51c: jns    520 <trace_exec_binprm+0x520> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x51c, 0x520, x86_l_520);
x86_l_51e:
	/* 0x51e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_520:
	/* 0x520: mov    DWORD PTR [rbp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_523:
	/* 0x523: call   528 <trace_exec_binprm+0x528> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_528:
	/* 0x528: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_52b:
	/* 0x52b: lea    rax,[r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_52f:
	/* 0x52f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_532:
	/* 0x532: jns    539 <trace_exec_binprm+0x539> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x532, 0x539, x86_l_539);
x86_l_534:
	/* 0x534: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_537:
	/* 0x537: jmp    53b <trace_exec_binprm+0x53b> */
	X86_SIM_X86_JMP(0x537, 0x53b, x86_l_53b);
x86_l_539:
	/* 0x539: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53b:
	/* 0x53b: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53f:
	/* 0x53f: add    r14,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_543:
	/* 0x543: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_546:
	/* 0x546: jns    54d <trace_exec_binprm+0x54d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x546, 0x54d, x86_l_54d);
x86_l_548:
	/* 0x548: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54b:
	/* 0x54b: jmp    54f <trace_exec_binprm+0x54f> */
	X86_SIM_X86_JMP(0x54b, 0x54f, x86_l_54f);
x86_l_54d:
	/* 0x54d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_54f:
	/* 0x54f: mov    QWORD PTR [rbp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_553:
	/* 0x553: add    rbx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_557:
	/* 0x557: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_55a:
	/* 0x55a: jns    561 <trace_exec_binprm+0x561> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x55a, 0x561, x86_l_561);
x86_l_55c:
	/* 0x55c: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_55f:
	/* 0x55f: jmp    563 <trace_exec_binprm+0x563> */
	X86_SIM_X86_JMP(0x55f, 0x563, x86_l_563);
x86_l_561:
	/* 0x561: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_563:
	/* 0x563: mov    QWORD PTR [rbp+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_567:
	/* 0x567: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_56a:
	/* 0x56a: jns    577 <trace_exec_binprm+0x577> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x56a, 0x577, x86_l_577);
x86_l_56c:
	/* 0x56c: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56f:
	/* 0x56f: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_571:
	/* 0x571: je     577 <trace_exec_binprm+0x577> */
	X86_SIM_X86_JCC(X86_CC_E, 0x571, 0x577, x86_l_577);
x86_l_573:
	/* 0x573: or     BYTE PTR [rbp+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_577:
	/* 0x577: lea    rdi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_57b:
	/* 0x57b: mov    QWORD PTR [rbp+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_583:
	/* 0x583: mov    QWORD PTR [rbp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_58b:
	/* 0x58b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_590:
	/* 0x590: call   595 <trace_exec_binprm+0x595> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_595:
	/* 0x595: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_598:
	/* 0x598: jns    5a0 <trace_exec_binprm+0x5a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x598, 0x5a0, x86_l_5a0);
x86_l_59a:
	/* 0x59a: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59e:
	/* 0x59e: jmp    5a2 <trace_exec_binprm+0x5a2> */
	X86_SIM_X86_JMP(0x59e, 0x5a2, x86_l_5a2);
x86_l_5a0:
	/* 0x5a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5a2:
	/* 0x5a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a5:
	/* 0x5a5: jns    5ac <trace_exec_binprm+0x5ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5a5, 0x5ac, x86_l_5ac);
x86_l_5a7:
	/* 0x5a7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5aa:
	/* 0x5aa: jmp    5ae <trace_exec_binprm+0x5ae> */
	X86_SIM_X86_JMP(0x5aa, 0x5ae, x86_l_5ae);
x86_l_5ac:
	/* 0x5ac: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ae:
	/* 0x5ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b1:
	/* 0x5b1: jns    5fe <trace_exec_binprm+0x5fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5b1, 0x5fe, x86_l_5fe);
x86_l_5b3:
	/* 0x5b3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b6:
	/* 0x5b6: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5bb:
	/* 0x5bb: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5bf:
	/* 0x5bf: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_5c4:
	/* 0x5c4: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5c8:
	/* 0x5c8: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5cd:
	/* 0x5cd: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5d1:
	/* 0x5d1: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5d6:
	/* 0x5d6: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5da:
	/* 0x5da: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_5df:
	/* 0x5df: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5e3:
	/* 0x5e3: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_5e8:
	/* 0x5e8: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5ec:
	/* 0x5ec: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5f1:
	/* 0x5f1: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5f5:
	/* 0x5f5: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_5fa:
	/* 0x5fa: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_5fe:
	/* 0x5fe: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_601:
	/* 0x601: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_605:
	/* 0x605: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_60a:
	/* 0x60a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_60d:
	/* 0x60d: jns    6d0 <trace_exec_binprm+0x6d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x60d, 0x6d0, x86_l_6d0);
x86_l_613:
	/* 0x613: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_616:
	/* 0x616: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_618:
	/* 0x618: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_61a:
	/* 0x61a: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61a, 0x6df, x86_l_6df);
x86_l_620:
	/* 0x620: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_624:
	/* 0x624: mov    BYTE PTR [rbp+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_627:
	/* 0x627: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_629:
	/* 0x629: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x629, 0x6df, x86_l_6df);
x86_l_62f:
	/* 0x62f: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_633:
	/* 0x633: mov    BYTE PTR [rbp+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_636:
	/* 0x636: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_638:
	/* 0x638: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x638, 0x6df, x86_l_6df);
x86_l_63e:
	/* 0x63e: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_642:
	/* 0x642: mov    BYTE PTR [rbp+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_645:
	/* 0x645: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_647:
	/* 0x647: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x647, 0x6df, x86_l_6df);
x86_l_64d:
	/* 0x64d: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_651:
	/* 0x651: mov    BYTE PTR [rbp+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_654:
	/* 0x654: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_656:
	/* 0x656: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x656, 0x6df, x86_l_6df);
x86_l_65c:
	/* 0x65c: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_660:
	/* 0x660: mov    BYTE PTR [rbp+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_663:
	/* 0x663: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_665:
	/* 0x665: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x665, 0x6df, x86_l_6df);
x86_l_667:
	/* 0x667: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_66b:
	/* 0x66b: mov    BYTE PTR [rbp+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_66e:
	/* 0x66e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_670:
	/* 0x670: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x670, 0x6df, x86_l_6df);
x86_l_672:
	/* 0x672: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_676:
	/* 0x676: mov    BYTE PTR [rbp+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_679:
	/* 0x679: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_67b:
	/* 0x67b: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67b, 0x6df, x86_l_6df);
x86_l_67d:
	/* 0x67d: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_681:
	/* 0x681: mov    BYTE PTR [rbp+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_684:
	/* 0x684: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_686:
	/* 0x686: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x686, 0x6df, x86_l_6df);
x86_l_688:
	/* 0x688: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_68c:
	/* 0x68c: mov    BYTE PTR [rbp+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_68f:
	/* 0x68f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_691:
	/* 0x691: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x691, 0x6df, x86_l_6df);
x86_l_693:
	/* 0x693: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_697:
	/* 0x697: mov    BYTE PTR [rbp+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_69a:
	/* 0x69a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_69c:
	/* 0x69c: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69c, 0x6df, x86_l_6df);
x86_l_69e:
	/* 0x69e: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_6a2:
	/* 0x6a2: mov    BYTE PTR [rbp+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_6a5:
	/* 0x6a5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6a7:
	/* 0x6a7: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a7, 0x6df, x86_l_6df);
x86_l_6a9:
	/* 0x6a9: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_6ad:
	/* 0x6ad: mov    BYTE PTR [rbp+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6b0:
	/* 0x6b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6b2:
	/* 0x6b2: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b2, 0x6df, x86_l_6df);
x86_l_6b4:
	/* 0x6b4: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_6b8:
	/* 0x6b8: mov    BYTE PTR [rbp+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_6bb:
	/* 0x6bb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6bd:
	/* 0x6bd: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6bd, 0x6df, x86_l_6df);
x86_l_6bf:
	/* 0x6bf: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_6c3:
	/* 0x6c3: mov    BYTE PTR [rbp+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_6c6:
	/* 0x6c6: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_6c8:
	/* 0x6c8: je     6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c8, 0x6df, x86_l_6df);
x86_l_6ca:
	/* 0x6ca: mov    BYTE PTR [rbp+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_6ce:
	/* 0x6ce: jmp    6df <trace_exec_binprm+0x6df> */
	X86_SIM_X86_JMP(0x6ce, 0x6df, x86_l_6df);
x86_l_6d0:
	/* 0x6d0: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_6d8:
	/* 0x6d8: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6df:
	/* 0x6df: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6e4:
	/* 0x6e4: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e9:
	/* 0x6e9: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_6ee:
	/* 0x6ee: je     23e <trace_exec_binprm+0x23e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ee, 0x23e, x86_l_23e);
x86_l_6f4:
	/* 0x6f4: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_6f9:
	/* 0x6f9: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_700:
	/* 0x700: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_703:
	/* 0x703: jns    71d <trace_exec_binprm+0x71d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x703, 0x71d, x86_l_71d);
x86_l_705:
	/* 0x705: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_708:
	/* 0x708: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_70b:
	/* 0x70b: js     724 <trace_exec_binprm+0x724> */
	X86_SIM_X86_JCC(X86_CC_S, 0x70b, 0x724, x86_l_724);
x86_l_70d:
	/* 0x70d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_70f:
	/* 0x70f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_712:
	/* 0x712: js     72c <trace_exec_binprm+0x72c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x712, 0x72c, x86_l_72c);
x86_l_714:
	/* 0x714: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_716:
	/* 0x716: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_719:
	/* 0x719: js     734 <trace_exec_binprm+0x734> */
	X86_SIM_X86_JCC(X86_CC_S, 0x719, 0x734, x86_l_734);
x86_l_71b:
	/* 0x71b: jmp    74a <trace_exec_binprm+0x74a> */
	X86_SIM_X86_JMP(0x71b, 0x74a, x86_l_74a);
x86_l_71d:
	/* 0x71d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71f:
	/* 0x71f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_722:
	/* 0x722: jns    70d <trace_exec_binprm+0x70d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x722, 0x70d, x86_l_70d);
x86_l_724:
	/* 0x724: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_727:
	/* 0x727: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_72a:
	/* 0x72a: jns    714 <trace_exec_binprm+0x714> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x72a, 0x714, x86_l_714);
x86_l_72c:
	/* 0x72c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_72f:
	/* 0x72f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_732:
	/* 0x732: jns    74a <trace_exec_binprm+0x74a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x732, 0x74a, x86_l_74a);
x86_l_734:
	/* 0x734: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_737:
	/* 0x737: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73a:
	/* 0x73a: je     74a <trace_exec_binprm+0x74a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73a, 0x74a, x86_l_74a);
x86_l_73c:
	/* 0x73c: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_740:
	/* 0x740: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_743:
	/* 0x743: jns    74a <trace_exec_binprm+0x74a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x743, 0x74a, x86_l_74a);
x86_l_745:
	/* 0x745: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_748:
	/* 0x748: jmp    74c <trace_exec_binprm+0x74c> */
	X86_SIM_X86_JMP(0x748, 0x74c, x86_l_74c);
x86_l_74a:
	/* 0x74a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_74c:
	/* 0x74c: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_750:
	/* 0x750: mov    QWORD PTR [rbp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_754:
	/* 0x754: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_758:
	/* 0x758: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_75f:
	/* 0x75f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_764:
	/* 0x764: call   769 <trace_exec_binprm+0x769> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_769:
	/* 0x769: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_76c:
	/* 0x76c: je     784 <trace_exec_binprm+0x784> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76c, 0x784, x86_l_784);
x86_l_76e:
	/* 0x76e: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_771:
	/* 0x771: mov    BYTE PTR [rbp+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_777:
	/* 0x777: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_77a:
	/* 0x77a: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_77d:
	/* 0x77d: jne    784 <trace_exec_binprm+0x784> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77d, 0x784, x86_l_784);
x86_l_77f:
	/* 0x77f: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_784:
	/* 0x784: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_789:
	/* 0x789: cmp    ax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R13, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_78e:
	/* 0x78e: jne    17ad <trace_exec_binprm+0x17ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x78e, 0x17ad, x86_l_17ad);
x86_l_794:
	/* 0x794: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_79f:
	/* 0x79f: mov    DWORD PTR [rsp+0x40],0x314 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907732ULL);
x86_l_7a7:
	/* 0x7a7: mov    WORD PTR [rsp+0x2c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_7ac:
	/* 0x7ac: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_7b3:
	/* 0x7b3: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_7b8:
	/* 0x7b8: call   7bd <trace_exec_binprm+0x7bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7bd:
	/* 0x7bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c0:
	/* 0x7c0: je     82b <trace_exec_binprm+0x82b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c0, 0x82b, x86_l_82b);
x86_l_7c2:
	/* 0x7c2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7c7:
	/* 0x7c7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ca:
	/* 0x7ca: call   7cf <trace_exec_binprm+0x7cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7cf:
	/* 0x7cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d2:
	/* 0x7d2: je     82b <trace_exec_binprm+0x82b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d2, 0x82b, x86_l_82b);
x86_l_7d4:
	/* 0x7d4: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d8:
	/* 0x7d8: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_7df:
	/* 0x7df: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e2:
	/* 0x7e2: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_7e9:
	/* 0x7e9: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ed:
	/* 0x7ed: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7f1:
	/* 0x7f1: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_7f8:
	/* 0x7f8: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_7ff:
	/* 0x7ff: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_803:
	/* 0x803: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_80a:
	/* 0x80a: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_80e:
	/* 0x80e: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_815:
	/* 0x815: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_819:
	/* 0x819: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_820:
	/* 0x820: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_824:
	/* 0x824: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_82b:
	/* 0x82b: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_832:
	/* 0x832: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_839:
	/* 0x839: mov    ecx,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_83d:
	/* 0x83d: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_841:
	/* 0x841: jne    85f <trace_exec_binprm+0x85f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x841, 0x85f, x86_l_85f);
x86_l_843:
	/* 0x843: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_845:
	/* 0x845: and    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_848:
	/* 0x848: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_84f:
	/* 0x84f: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_854:
	/* 0x854: jne    109a <trace_exec_binprm+0x109a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x854, 0x109a, x86_l_109a);
x86_l_85a:
	/* 0x85a: jmp    1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JMP(0x85a, 0x1f, x86_l_1f);
x86_l_85f:
	/* 0x85f: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_866:
	/* 0x866: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_869:
	/* 0x869: je     9fa <trace_exec_binprm+0x9fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x869, 0x9fa, x86_l_9fa);
x86_l_86f:
	/* 0x86f: movzx  ecx,BYTE PTR [rbp+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_876:
	/* 0x876: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_879:
	/* 0x879: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_87b:
	/* 0x87b: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_87e:
	/* 0x87e: sete   bl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_881:
	/* 0x881: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_884:
	/* 0x884: neg    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_887:
	/* 0x887: xor    rbx,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_88e:
	/* 0x88e: or     rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_891:
	/* 0x891: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_898:
	/* 0x898: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89b:
	/* 0x89b: je     8bc <trace_exec_binprm+0x8bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x89b, 0x8bc, x86_l_8bc);
x86_l_89d:
	/* 0x89d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_89f:
	/* 0x89f: cmp    BYTE PTR [rbp+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_8a6:
	/* 0x8a6: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_8a9:
	/* 0x8a9: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8ac:
	/* 0x8ac: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_8af:
	/* 0x8af: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_8b6:
	/* 0x8b6: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8b9:
	/* 0x8b9: and    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8bc:
	/* 0x8bc: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_8c3:
	/* 0x8c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c6:
	/* 0x8c6: je     8e2 <trace_exec_binprm+0x8e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c6, 0x8e2, x86_l_8e2);
x86_l_8c8:
	/* 0x8c8: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_8cc:
	/* 0x8cc: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8cf:
	/* 0x8cf: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_8d2:
	/* 0x8d2: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_8d5:
	/* 0x8d5: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_8dc:
	/* 0x8dc: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8df:
	/* 0x8df: and    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8e2:
	/* 0x8e2: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_8e9:
	/* 0x8e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ec:
	/* 0x8ec: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8f1:
	/* 0x8f1: je     90e <trace_exec_binprm+0x90e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f1, 0x90e, x86_l_90e);
x86_l_8f3:
	/* 0x8f3: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8f6:
	/* 0x8f6: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8fa:
	/* 0x8fa: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8fe:
	/* 0x8fe: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_901:
	/* 0x901: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_908:
	/* 0x908: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_90b:
	/* 0x90b: and    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_90e:
	/* 0x90e: movzx  ebp,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_913:
	/* 0x913: mov    r12,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_91a:
	/* 0x91a: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_91d:
	/* 0x91d: mov    WORD PTR [rsp+0x18],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_922:
	/* 0x922: je     a69 <trace_exec_binprm+0xa69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x922, 0xa69, x86_l_a69);
x86_l_928:
	/* 0x928: mov    rax,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_92f:
	/* 0x92f: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_937:
	/* 0x937: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_939:
	/* 0x939: mov    rbp,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_940:
	/* 0x940: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_947:
	/* 0x947: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_94c:
	/* 0x94c: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_951:
	/* 0x951: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_958:
	/* 0x958: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_95d:
	/* 0x95d: call   962 <trace_exec_binprm+0x962> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_962:
	/* 0x962: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_965:
	/* 0x965: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_969:
	/* 0x969: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_96e:
	/* 0x96e: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_975:
	/* 0x975: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_978:
	/* 0x978: je     998 <trace_exec_binprm+0x998> */
	X86_SIM_X86_JCC(X86_CC_E, 0x978, 0x998, x86_l_998);
x86_l_97a:
	/* 0x97a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_97f:
	/* 0x97f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_982:
	/* 0x982: call   987 <trace_exec_binprm+0x987> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_987:
	/* 0x987: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_98a:
	/* 0x98a: je     998 <trace_exec_binprm+0x998> */
	X86_SIM_X86_JCC(X86_CC_E, 0x98a, 0x998, x86_l_998);
x86_l_98c:
	/* 0x98c: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_98f:
	/* 0x98f: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_993:
	/* 0x993: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_996:
	/* 0x996: jmp    99b <trace_exec_binprm+0x99b> */
	X86_SIM_X86_JMP(0x996, 0x99b, x86_l_99b);
x86_l_998:
	/* 0x998: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_99b:
	/* 0x99b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9a0:
	/* 0x9a0: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9a5:
	/* 0x9a5: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_9a8:
	/* 0x9a8: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ab:
	/* 0x9ab: jb     9c3 <trace_exec_binprm+0x9c3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x9ab, 0x9c3, x86_l_9c3);
x86_l_9ad:
	/* 0x9ad: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9b1:
	/* 0x9b1: je     9b8 <trace_exec_binprm+0x9b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b1, 0x9b8, x86_l_9b8);
x86_l_9b3:
	/* 0x9b3: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9b6:
	/* 0x9b6: jbe    9c3 <trace_exec_binprm+0x9c3> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x9b6, 0x9c3, x86_l_9c3);
x86_l_9b8:
	/* 0x9b8: and    r14,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 144ULL);
x86_l_9c0:
	/* 0x9c0: or     r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9c3:
	/* 0x9c3: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9c8:
	/* 0x9c8: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9cb:
	/* 0x9cb: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9d0:
	/* 0x9d0: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9d7:
	/* 0x9d7: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_9da:
	/* 0x9da: je     a16 <trace_exec_binprm+0xa16> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9da, 0xa16, x86_l_a16);
x86_l_9dc:
	/* 0x9dc: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9e1:
	/* 0x9e1: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_9e4:
	/* 0x9e4: call   9e9 <trace_exec_binprm+0x9e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9e9:
	/* 0x9e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ec:
	/* 0x9ec: je     a42 <trace_exec_binprm+0xa42> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ec, 0xa42, x86_l_a42);
x86_l_9ee:
	/* 0x9ee: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9f1:
	/* 0x9f1: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9f5:
	/* 0x9f5: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9f8:
	/* 0x9f8: jmp    a44 <trace_exec_binprm+0xa44> */
	X86_SIM_X86_JMP(0x9f8, 0xa44, x86_l_a44);
x86_l_9fa:
	/* 0x9fa: mov    rbx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a01:
	/* 0xa01: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_a08:
	/* 0xa08: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a0b:
	/* 0xa0b: jne    89d <trace_exec_binprm+0x89d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa0b, 0x89d, x86_l_89d);
x86_l_a11:
	/* 0xa11: jmp    8bc <trace_exec_binprm+0x8bc> */
	X86_SIM_X86_JMP(0xa11, 0x8bc, x86_l_8bc);
x86_l_a16:
	/* 0xa16: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a18:
	/* 0xa18: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a1b:
	/* 0xa1b: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a20:
	/* 0xa20: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a23:
	/* 0xa23: jb     a56 <trace_exec_binprm+0xa56> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa23, 0xa56, x86_l_a56);
x86_l_a25:
	/* 0xa25: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a29:
	/* 0xa29: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_a2e:
	/* 0xa2e: je     a35 <trace_exec_binprm+0xa35> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa2e, 0xa35, x86_l_a35);
x86_l_a30:
	/* 0xa30: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a33:
	/* 0xa33: jbe    a5b <trace_exec_binprm+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa33, 0xa5b, x86_l_a5b);
x86_l_a35:
	/* 0xa35: and    r14,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 144ULL);
x86_l_a3d:
	/* 0xa3d: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a40:
	/* 0xa40: jmp    a5b <trace_exec_binprm+0xa5b> */
	X86_SIM_X86_JMP(0xa40, 0xa5b, x86_l_a5b);
x86_l_a42:
	/* 0xa42: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a44:
	/* 0xa44: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a49:
	/* 0xa49: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a4c:
	/* 0xa4c: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a51:
	/* 0xa51: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a54:
	/* 0xa54: jae    a25 <trace_exec_binprm+0xa25> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa54, 0xa25, x86_l_a25);
x86_l_a56:
	/* 0xa56: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_a5b:
	/* 0xa5b: or     r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a5e:
	/* 0xa5e: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a61:
	/* 0xa61: and    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a64:
	/* 0xa64: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a69:
	/* 0xa69: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_a71:
	/* 0xa71: je     b23 <trace_exec_binprm+0xb23> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa71, 0xb23, x86_l_b23);
x86_l_a77:
	/* 0xa77: call   a7c <trace_exec_binprm+0xa7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_a7c:
	/* 0xa7c: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a80:
	/* 0xa80: mov    r15,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_a87:
	/* 0xa87: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_a8e:
	/* 0xa8e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a93:
	/* 0xa93: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a95:
	/* 0xa95: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_a9c:
	/* 0xa9c: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_aa3:
	/* 0xaa3: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_aa8:
	/* 0xaa8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_aaf:
	/* 0xaaf: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ab4:
	/* 0xab4: call   ab9 <trace_exec_binprm+0xab9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ab9:
	/* 0xab9: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_abd:
	/* 0xabd: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ac2:
	/* 0xac2: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ac9:
	/* 0xac9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_acc:
	/* 0xacc: je     aec <trace_exec_binprm+0xaec> */
	X86_SIM_X86_JCC(X86_CC_E, 0xacc, 0xaec, x86_l_aec);
x86_l_ace:
	/* 0xace: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ad3:
	/* 0xad3: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad6:
	/* 0xad6: call   adb <trace_exec_binprm+0xadb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_adb:
	/* 0xadb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ade:
	/* 0xade: je     aec <trace_exec_binprm+0xaec> */
	X86_SIM_X86_JCC(X86_CC_E, 0xade, 0xaec, x86_l_aec);
x86_l_ae0:
	/* 0xae0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae3:
	/* 0xae3: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ae7:
	/* 0xae7: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_aea:
	/* 0xaea: jmp    aee <trace_exec_binprm+0xaee> */
	X86_SIM_X86_JMP(0xaea, 0xaee, x86_l_aee);
x86_l_aec:
	/* 0xaec: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aee:
	/* 0xaee: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_af1:
	/* 0xaf1: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_af6:
	/* 0xaf6: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_af9:
	/* 0xaf9: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_afc:
	/* 0xafc: jae    b05 <trace_exec_binprm+0xb05> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xafc, 0xb05, x86_l_b05);
x86_l_afe:
	/* 0xafe: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_b03:
	/* 0xb03: jmp    b1d <trace_exec_binprm+0xb1d> */
	X86_SIM_X86_JMP(0xb03, 0xb1d, x86_l_b1d);
x86_l_b05:
	/* 0xb05: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b09:
	/* 0xb09: movzx  ebp,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_b0e:
	/* 0xb0e: je     b15 <trace_exec_binprm+0xb15> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb0e, 0xb15, x86_l_b15);
x86_l_b10:
	/* 0xb10: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b13:
	/* 0xb13: jbe    b1d <trace_exec_binprm+0xb1d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xb13, 0xb1d, x86_l_b1d);
x86_l_b15:
	/* 0xb15: and    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32ULL);
x86_l_b1a:
	/* 0xb1a: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b1d:
	/* 0xb1d: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b20:
	/* 0xb20: and    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b23:
	/* 0xb23: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_b2b:
	/* 0xb2b: je     bd1 <trace_exec_binprm+0xbd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2b, 0xbd1, x86_l_bd1);
x86_l_b31:
	/* 0xb31: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_b36:
	/* 0xb36: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_b3d:
	/* 0xb3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b40:
	/* 0xb40: jns    b47 <trace_exec_binprm+0xb47> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb40, 0xb47, x86_l_b47);
x86_l_b42:
	/* 0xb42: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b45:
	/* 0xb45: jmp    b49 <trace_exec_binprm+0xb49> */
	X86_SIM_X86_JMP(0xb45, 0xb49, x86_l_b49);
x86_l_b47:
	/* 0xb47: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b49:
	/* 0xb49: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_b4d:
	/* 0xb4d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b4f:
	/* 0xb4f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b52:
	/* 0xb52: jns    b5e <trace_exec_binprm+0xb5e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb52, 0xb5e, x86_l_b5e);
x86_l_b54:
	/* 0xb54: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b57:
	/* 0xb57: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b5a:
	/* 0xb5a: js     b65 <trace_exec_binprm+0xb65> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb5a, 0xb65, x86_l_b65);
x86_l_b5c:
	/* 0xb5c: jmp    b67 <trace_exec_binprm+0xb67> */
	X86_SIM_X86_JMP(0xb5c, 0xb67, x86_l_b67);
x86_l_b5e:
	/* 0xb5e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b60:
	/* 0xb60: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b63:
	/* 0xb63: jns    b67 <trace_exec_binprm+0xb67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb63, 0xb67, x86_l_b67);
x86_l_b65:
	/* 0xb65: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b67:
	/* 0xb67: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_b6b:
	/* 0xb6b: mov    r15,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_b72:
	/* 0xb72: mov    r12,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_b79:
	/* 0xb79: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b7c:
	/* 0xb7c: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b81:
	/* 0xb81: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_b88:
	/* 0xb88: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b8d:
	/* 0xb8d: call   b92 <trace_exec_binprm+0xb92> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b92:
	/* 0xb92: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_b95:
	/* 0xb95: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b9c:
	/* 0xb9c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b9f:
	/* 0xb9f: je     bbe <trace_exec_binprm+0xbbe> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9f, 0xbbe, x86_l_bbe);
x86_l_ba1:
	/* 0xba1: lea    rsi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_ba5:
	/* 0xba5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba8:
	/* 0xba8: call   bad <trace_exec_binprm+0xbad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bad:
	/* 0xbad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bb0:
	/* 0xbb0: je     bbe <trace_exec_binprm+0xbbe> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb0, 0xbbe, x86_l_bbe);
x86_l_bb2:
	/* 0xbb2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bb5:
	/* 0xbb5: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bb9:
	/* 0xbb9: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bbc:
	/* 0xbbc: jmp    bc0 <trace_exec_binprm+0xbc0> */
	X86_SIM_X86_JMP(0xbbc, 0xbc0, x86_l_bc0);
x86_l_bbe:
	/* 0xbbe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bc0:
	/* 0xbc0: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bc3:
	/* 0xbc3: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bc6:
	/* 0xbc6: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bc9:
	/* 0xbc9: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bcc:
	/* 0xbcc: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bd1:
	/* 0xbd1: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_bd9:
	/* 0xbd9: je     ca3 <trace_exec_binprm+0xca3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd9, 0xca3, x86_l_ca3);
x86_l_bdf:
	/* 0xbdf: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_be6:
	/* 0xbe6: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_bea:
	/* 0xbea: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bec:
	/* 0xbec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bef:
	/* 0xbef: jns    bfe <trace_exec_binprm+0xbfe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbef, 0xbfe, x86_l_bfe);
x86_l_bf1:
	/* 0xbf1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf4:
	/* 0xbf4: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bf7:
	/* 0xbf7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_bfa:
	/* 0xbfa: js     c08 <trace_exec_binprm+0xc08> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbfa, 0xc08, x86_l_c08);
x86_l_bfc:
	/* 0xbfc: jmp    c0a <trace_exec_binprm+0xc0a> */
	X86_SIM_X86_JMP(0xbfc, 0xc0a, x86_l_c0a);
x86_l_bfe:
	/* 0xbfe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c00:
	/* 0xc00: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c03:
	/* 0xc03: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c06:
	/* 0xc06: jns    c0a <trace_exec_binprm+0xc0a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc06, 0xc0a, x86_l_c0a);
x86_l_c08:
	/* 0xc08: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c0a:
	/* 0xc0a: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c0c:
	/* 0xc0c: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_c10:
	/* 0xc10: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_c13:
	/* 0xc13: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c17:
	/* 0xc17: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c19:
	/* 0xc19: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c1c:
	/* 0xc1c: jns    c2c <trace_exec_binprm+0xc2c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc1c, 0xc2c, x86_l_c2c);
x86_l_c1e:
	/* 0xc1e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c21:
	/* 0xc21: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_c25:
	/* 0xc25: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c28:
	/* 0xc28: js     c37 <trace_exec_binprm+0xc37> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc28, 0xc37, x86_l_c37);
x86_l_c2a:
	/* 0xc2a: jmp    c39 <trace_exec_binprm+0xc39> */
	X86_SIM_X86_JMP(0xc2a, 0xc39, x86_l_c39);
x86_l_c2c:
	/* 0xc2c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c2e:
	/* 0xc2e: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_c32:
	/* 0xc32: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c35:
	/* 0xc35: jns    c39 <trace_exec_binprm+0xc39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc35, 0xc39, x86_l_c39);
x86_l_c37:
	/* 0xc37: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c39:
	/* 0xc39: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c3d:
	/* 0xc3d: mov    r15,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_c44:
	/* 0xc44: mov    r12,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_c4b:
	/* 0xc4b: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c4e:
	/* 0xc4e: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c53:
	/* 0xc53: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_c5a:
	/* 0xc5a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c5f:
	/* 0xc5f: call   c64 <trace_exec_binprm+0xc64> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c64:
	/* 0xc64: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_c67:
	/* 0xc67: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c6e:
	/* 0xc6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c71:
	/* 0xc71: je     c90 <trace_exec_binprm+0xc90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc71, 0xc90, x86_l_c90);
x86_l_c73:
	/* 0xc73: lea    rsi,[rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c77:
	/* 0xc77: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7a:
	/* 0xc7a: call   c7f <trace_exec_binprm+0xc7f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c7f:
	/* 0xc7f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c82:
	/* 0xc82: je     c90 <trace_exec_binprm+0xc90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc82, 0xc90, x86_l_c90);
x86_l_c84:
	/* 0xc84: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c87:
	/* 0xc87: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c8b:
	/* 0xc8b: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c8e:
	/* 0xc8e: jmp    c92 <trace_exec_binprm+0xc92> */
	X86_SIM_X86_JMP(0xc8e, 0xc92, x86_l_c92);
x86_l_c90:
	/* 0xc90: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c92:
	/* 0xc92: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c95:
	/* 0xc95: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c98:
	/* 0xc98: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c9b:
	/* 0xc9b: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c9e:
	/* 0xc9e: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca3:
	/* 0xca3: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_cab:
	/* 0xcab: je     e83 <trace_exec_binprm+0xe83> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcab, 0xe83, x86_l_e83);
x86_l_cb1:
	/* 0xcb1: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_cb6:
	/* 0xcb6: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_cbd:
	/* 0xcbd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc0:
	/* 0xcc0: jns    cd3 <trace_exec_binprm+0xcd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcc0, 0xcd3, x86_l_cd3);
x86_l_cc2:
	/* 0xcc2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc5:
	/* 0xcc5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc8:
	/* 0xcc8: js     cda <trace_exec_binprm+0xcda> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcc8, 0xcda, x86_l_cda);
x86_l_cca:
	/* 0xcca: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ccc:
	/* 0xccc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ccf:
	/* 0xccf: js     ce2 <trace_exec_binprm+0xce2> */
	X86_SIM_X86_JCC(X86_CC_S, 0xccf, 0xce2, x86_l_ce2);
x86_l_cd1:
	/* 0xcd1: jmp    d2d <trace_exec_binprm+0xd2d> */
	X86_SIM_X86_JMP(0xcd1, 0xd2d, x86_l_d2d);
x86_l_cd3:
	/* 0xcd3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cd5:
	/* 0xcd5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd8:
	/* 0xcd8: jns    cca <trace_exec_binprm+0xcca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd8, 0xcca, x86_l_cca);
x86_l_cda:
	/* 0xcda: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cdd:
	/* 0xcdd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce0:
	/* 0xce0: jns    d2d <trace_exec_binprm+0xd2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xce0, 0xd2d, x86_l_d2d);
x86_l_ce2:
	/* 0xce2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce5:
	/* 0xce5: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_cea:
	/* 0xcea: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cee:
	/* 0xcee: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_cf3:
	/* 0xcf3: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cf7:
	/* 0xcf7: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_cfc:
	/* 0xcfc: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d00:
	/* 0xd00: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d05:
	/* 0xd05: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d09:
	/* 0xd09: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d0e:
	/* 0xd0e: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d12:
	/* 0xd12: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d17:
	/* 0xd17: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d1b:
	/* 0xd1b: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d20:
	/* 0xd20: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d24:
	/* 0xd24: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_d29:
	/* 0xd29: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_d2d:
	/* 0xd2d: lea    r13,[r14+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_d31:
	/* 0xd31: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d36:
	/* 0xd36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d39:
	/* 0xd39: jns    e11 <trace_exec_binprm+0xe11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd39, 0xe11, x86_l_e11);
x86_l_d3f:
	/* 0xd3f: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_d42:
	/* 0xd42: mov    BYTE PTR [r13+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d46:
	/* 0xd46: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d48:
	/* 0xd48: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd48, 0xe21, x86_l_e21);
x86_l_d4e:
	/* 0xd4e: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_d52:
	/* 0xd52: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_d56:
	/* 0xd56: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d58:
	/* 0xd58: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd58, 0xe21, x86_l_e21);
x86_l_d5e:
	/* 0xd5e: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_d62:
	/* 0xd62: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_d66:
	/* 0xd66: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d68:
	/* 0xd68: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd68, 0xe21, x86_l_e21);
x86_l_d6e:
	/* 0xd6e: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_d72:
	/* 0xd72: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_d76:
	/* 0xd76: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d78:
	/* 0xd78: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd78, 0xe21, x86_l_e21);
x86_l_d7e:
	/* 0xd7e: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_d82:
	/* 0xd82: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d86:
	/* 0xd86: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d88:
	/* 0xd88: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd88, 0xe21, x86_l_e21);
x86_l_d8e:
	/* 0xd8e: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_d92:
	/* 0xd92: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_d96:
	/* 0xd96: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_d98:
	/* 0xd98: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd98, 0xe21, x86_l_e21);
x86_l_d9e:
	/* 0xd9e: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_da2:
	/* 0xda2: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_da6:
	/* 0xda6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_da8:
	/* 0xda8: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda8, 0xe21, x86_l_e21);
x86_l_daa:
	/* 0xdaa: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_dae:
	/* 0xdae: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_db2:
	/* 0xdb2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_db4:
	/* 0xdb4: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb4, 0xe21, x86_l_e21);
x86_l_db6:
	/* 0xdb6: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_dba:
	/* 0xdba: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_dbe:
	/* 0xdbe: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dc0:
	/* 0xdc0: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc0, 0xe21, x86_l_e21);
x86_l_dc2:
	/* 0xdc2: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_dc6:
	/* 0xdc6: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_dca:
	/* 0xdca: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dcc:
	/* 0xdcc: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdcc, 0xe21, x86_l_e21);
x86_l_dce:
	/* 0xdce: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_dd2:
	/* 0xdd2: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_dd6:
	/* 0xdd6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dd8:
	/* 0xdd8: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdd8, 0xe21, x86_l_e21);
x86_l_dda:
	/* 0xdda: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_dde:
	/* 0xdde: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_de2:
	/* 0xde2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_de4:
	/* 0xde4: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde4, 0xe21, x86_l_e21);
x86_l_de6:
	/* 0xde6: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_dea:
	/* 0xdea: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_dee:
	/* 0xdee: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_df0:
	/* 0xdf0: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf0, 0xe21, x86_l_e21);
x86_l_df2:
	/* 0xdf2: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_df6:
	/* 0xdf6: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_dfa:
	/* 0xdfa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dfc:
	/* 0xdfc: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdfc, 0xe21, x86_l_e21);
x86_l_dfe:
	/* 0xdfe: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_e02:
	/* 0xe02: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_e06:
	/* 0xe06: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_e08:
	/* 0xe08: je     e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe08, 0xe21, x86_l_e21);
x86_l_e0a:
	/* 0xe0a: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_e0f:
	/* 0xe0f: jmp    e21 <trace_exec_binprm+0xe21> */
	X86_SIM_X86_JMP(0xe0f, 0xe21, x86_l_e21);
x86_l_e11:
	/* 0xe11: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e19:
	/* 0xe19: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e21:
	/* 0xe21: mov    r15,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_e28:
	/* 0xe28: mov    r12,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_e2f:
	/* 0xe2f: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_e32:
	/* 0xe32: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e37:
	/* 0xe37: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_e3e:
	/* 0xe3e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e43:
	/* 0xe43: call   e48 <trace_exec_binprm+0xe48> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e48:
	/* 0xe48: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_e4f:
	/* 0xe4f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e52:
	/* 0xe52: je     e70 <trace_exec_binprm+0xe70> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe52, 0xe70, x86_l_e70);
x86_l_e54:
	/* 0xe54: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e57:
	/* 0xe57: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_e5a:
	/* 0xe5a: call   e5f <trace_exec_binprm+0xe5f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e5f:
	/* 0xe5f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e62:
	/* 0xe62: je     e70 <trace_exec_binprm+0xe70> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe62, 0xe70, x86_l_e70);
x86_l_e64:
	/* 0xe64: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e67:
	/* 0xe67: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e6b:
	/* 0xe6b: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_e6e:
	/* 0xe6e: jmp    e72 <trace_exec_binprm+0xe72> */
	X86_SIM_X86_JMP(0xe6e, 0xe72, x86_l_e72);
x86_l_e70:
	/* 0xe70: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e72:
	/* 0xe72: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_e75:
	/* 0xe75: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_e78:
	/* 0xe78: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_e7b:
	/* 0xe7b: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_e7e:
	/* 0xe7e: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e83:
	/* 0xe83: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_e8b:
	/* 0xe8b: je     f00 <trace_exec_binprm+0xf00> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8b, 0xf00, x86_l_f00);
x86_l_e8d:
	/* 0xe8d: lea    r13,[r14+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_e91:
	/* 0xe91: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_e94:
	/* 0xe94: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_e99:
	/* 0xe99: call   e9e <trace_exec_binprm+0xe9e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_e9e:
	/* 0xe9e: mov    r15,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_ea5:
	/* 0xea5: mov    r12,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_eac:
	/* 0xeac: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_eaf:
	/* 0xeaf: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_eb4:
	/* 0xeb4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_ebb:
	/* 0xebb: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ec0:
	/* 0xec0: call   ec5 <trace_exec_binprm+0xec5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ec5:
	/* 0xec5: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ecc:
	/* 0xecc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ecf:
	/* 0xecf: je     eed <trace_exec_binprm+0xeed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xecf, 0xeed, x86_l_eed);
x86_l_ed1:
	/* 0xed1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed4:
	/* 0xed4: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_ed7:
	/* 0xed7: call   edc <trace_exec_binprm+0xedc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_edc:
	/* 0xedc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_edf:
	/* 0xedf: je     eed <trace_exec_binprm+0xeed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xedf, 0xeed, x86_l_eed);
x86_l_ee1:
	/* 0xee1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee4:
	/* 0xee4: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee8:
	/* 0xee8: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_eeb:
	/* 0xeeb: jmp    eef <trace_exec_binprm+0xeef> */
	X86_SIM_X86_JMP(0xeeb, 0xeef, x86_l_eef);
x86_l_eed:
	/* 0xeed: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eef:
	/* 0xeef: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ef2:
	/* 0xef2: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ef5:
	/* 0xef5: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ef8:
	/* 0xef8: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_efb:
	/* 0xefb: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f00:
	/* 0xf00: mov    r15,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_f07:
	/* 0xf07: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f0a:
	/* 0xf0a: je     f71 <trace_exec_binprm+0xf71> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0a, 0xf71, x86_l_f71);
x86_l_f0c:
	/* 0xf0c: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f10:
	/* 0xf10: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f14:
	/* 0xf14: mov    r12,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_f1b:
	/* 0xf1b: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f1e:
	/* 0xf1e: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f23:
	/* 0xf23: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_f2a:
	/* 0xf2a: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f2f:
	/* 0xf2f: call   f34 <trace_exec_binprm+0xf34> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f34:
	/* 0xf34: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_f3b:
	/* 0xf3b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f3e:
	/* 0xf3e: je     f5e <trace_exec_binprm+0xf5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf3e, 0xf5e, x86_l_f5e);
x86_l_f40:
	/* 0xf40: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f45:
	/* 0xf45: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f48:
	/* 0xf48: call   f4d <trace_exec_binprm+0xf4d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f4d:
	/* 0xf4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f50:
	/* 0xf50: je     f5e <trace_exec_binprm+0xf5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf50, 0xf5e, x86_l_f5e);
x86_l_f52:
	/* 0xf52: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f55:
	/* 0xf55: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f59:
	/* 0xf59: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f5c:
	/* 0xf5c: jmp    f60 <trace_exec_binprm+0xf60> */
	X86_SIM_X86_JMP(0xf5c, 0xf60, x86_l_f60);
x86_l_f5e:
	/* 0xf5e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f60:
	/* 0xf60: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f63:
	/* 0xf63: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f66:
	/* 0xf66: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f69:
	/* 0xf69: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f6c:
	/* 0xf6c: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f71:
	/* 0xf71: mov    r15,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_f78:
	/* 0xf78: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f7b:
	/* 0xf7b: je     fdc <trace_exec_binprm+0xfdc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf7b, 0xfdc, x86_l_fdc);
x86_l_f7d:
	/* 0xf7d: mov    r12,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_f84:
	/* 0xf84: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f87:
	/* 0xf87: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f8c:
	/* 0xf8c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_f93:
	/* 0xf93: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f98:
	/* 0xf98: call   f9d <trace_exec_binprm+0xf9d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f9d:
	/* 0xf9d: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fa0:
	/* 0xfa0: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_fa7:
	/* 0xfa7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_faa:
	/* 0xfaa: je     fc9 <trace_exec_binprm+0xfc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfaa, 0xfc9, x86_l_fc9);
x86_l_fac:
	/* 0xfac: lea    rsi,[rcx+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_fb0:
	/* 0xfb0: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fb3:
	/* 0xfb3: call   fb8 <trace_exec_binprm+0xfb8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fb8:
	/* 0xfb8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fbb:
	/* 0xfbb: je     fc9 <trace_exec_binprm+0xfc9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfbb, 0xfc9, x86_l_fc9);
x86_l_fbd:
	/* 0xfbd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fc0:
	/* 0xfc0: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fc4:
	/* 0xfc4: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fc7:
	/* 0xfc7: jmp    fcb <trace_exec_binprm+0xfcb> */
	X86_SIM_X86_JMP(0xfc7, 0xfcb, x86_l_fcb);
x86_l_fc9:
	/* 0xfc9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fcb:
	/* 0xfcb: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fce:
	/* 0xfce: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fd1:
	/* 0xfd1: or     r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fd4:
	/* 0xfd4: and    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fd7:
	/* 0xfd7: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fdc:
	/* 0xfdc: mov    r15,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_fe3:
	/* 0xfe3: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fe6:
	/* 0xfe6: je     105b <trace_exec_binprm+0x105b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe6, 0x105b, x86_l_105b);
x86_l_fe8:
	/* 0xfe8: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_fef:
	/* 0xfef: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ff2:
	/* 0xff2: mov    WORD PTR [rsp+0x40],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ff7:
	/* 0xff7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_ffe:
	/* 0xffe: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1003:
	/* 0x1003: call   1008 <trace_exec_binprm+0x1008> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1008:
	/* 0x1008: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_100f:
	/* 0x100f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1012:
	/* 0x1012: je     104d <trace_exec_binprm+0x104d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1012, 0x104d, x86_l_104d);
x86_l_1014:
	/* 0x1014: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1017:
	/* 0x1017: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_101b:
	/* 0x101b: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_101f:
	/* 0x101f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1022:
	/* 0x1022: call   1027 <trace_exec_binprm+0x1027> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1027:
	/* 0x1027: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_102a:
	/* 0x102a: jne    1041 <trace_exec_binprm+0x1041> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x102a, 0x1041, x86_l_1041);
x86_l_102c:
	/* 0x102c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1030:
	/* 0x1030: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1034:
	/* 0x1034: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1037:
	/* 0x1037: call   103c <trace_exec_binprm+0x103c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_103c:
	/* 0x103c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_103f:
	/* 0x103f: je     104d <trace_exec_binprm+0x104d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x103f, 0x104d, x86_l_104d);
x86_l_1041:
	/* 0x1041: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1044:
	/* 0x1044: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1048:
	/* 0x1048: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_104b:
	/* 0x104b: jmp    104f <trace_exec_binprm+0x104f> */
	X86_SIM_X86_JMP(0x104b, 0x104f, x86_l_104f);
x86_l_104d:
	/* 0x104d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_104f:
	/* 0x104f: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1052:
	/* 0x1052: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1055:
	/* 0x1055: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1058:
	/* 0x1058: and    rbx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_105b:
	/* 0x105b: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1062:
	/* 0x1062: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1065:
	/* 0x1065: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_106a:
	/* 0x106a: je     1077 <trace_exec_binprm+0x1077> */
	X86_SIM_X86_JCC(X86_CC_E, 0x106a, 0x1077, x86_l_1077);
x86_l_106c:
	/* 0x106c: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1070:
	/* 0x1070: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_1074:
	/* 0x1074: or     rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1077:
	/* 0x1077: and    rbx,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_107e:
	/* 0x107e: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1085:
	/* 0x1085: and    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1088:
	/* 0x1088: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_108f:
	/* 0x108f: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1094:
	/* 0x1094: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1094, 0x1f, x86_l_1f);
x86_l_109a:
	/* 0x109a: mov    r13,QWORD PTR [r12+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_109f:
	/* 0x109f: mov    ebx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_10a4:
	/* 0x10a4: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10a7:
	/* 0x10a7: je     1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10a7, 0x1f, x86_l_1f);
x86_l_10ad:
	/* 0x10ad: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10b0:
	/* 0x10b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10b3:
	/* 0x10b3: jns    10d8 <trace_exec_binprm+0x10d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b3, 0x10d8, x86_l_10d8);
x86_l_10b5:
	/* 0x10b5: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b8:
	/* 0x10b8: lea    rax,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10bc:
	/* 0x10bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10bf:
	/* 0x10bf: js     10e3 <trace_exec_binprm+0x10e3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10bf, 0x10e3, x86_l_10e3);
x86_l_10c1:
	/* 0x10c1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10c3:
	/* 0x10c3: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_10cb:
	/* 0x10cb: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_10d1:
	/* 0x10d1: jbe    10fa <trace_exec_binprm+0x10fa> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x10d1, 0x10fa, x86_l_10fa);
x86_l_10d3:
	/* 0x10d3: jmp    11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JMP(0x10d3, 0x11ba, x86_l_11ba);
x86_l_10d8:
	/* 0x10d8: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10da:
	/* 0x10da: lea    rax,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10de:
	/* 0x10de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e1:
	/* 0x10e1: jns    10c1 <trace_exec_binprm+0x10c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10e1, 0x10c1, x86_l_10c1);
x86_l_10e3:
	/* 0x10e3: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e6:
	/* 0x10e6: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_10ee:
	/* 0x10ee: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_10f4:
	/* 0x10f4: ja     11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10f4, 0x11ba, x86_l_11ba);
x86_l_10fa:
	/* 0x10fa: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_1103:
	/* 0x1103: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_110b:
	/* 0x110b: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_1113:
	/* 0x1113: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1119:
	/* 0x1119: ja     11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1119, 0x11ba, x86_l_11ba);
x86_l_111f:
	/* 0x111f: lea    rdi,[rax+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1123:
	/* 0x1123: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_112a:
	/* 0x112a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_112d:
	/* 0x112d: jns    1155 <trace_exec_binprm+0x1155> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x112d, 0x1155, x86_l_1155);
x86_l_112f:
	/* 0x112f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1132:
	/* 0x1132: jns    1168 <trace_exec_binprm+0x1168> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1132, 0x1168, x86_l_1168);
x86_l_1134:
	/* 0x1134: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1136:
	/* 0x1136: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_113d:
	/* 0x113d: je     1176 <trace_exec_binprm+0x1176> */
	X86_SIM_X86_JCC(X86_CC_E, 0x113d, 0x1176, x86_l_1176);
x86_l_113f:
	/* 0x113f: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1143:
	/* 0x1143: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1147:
	/* 0x1147: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_114b:
	/* 0x114b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_114e:
	/* 0x114e: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_1151:
	/* 0x1151: jne    1136 <trace_exec_binprm+0x1136> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1151, 0x1136, x86_l_1136);
x86_l_1153:
	/* 0x1153: jmp    115f <trace_exec_binprm+0x115f> */
	X86_SIM_X86_JMP(0x1153, 0x115f, x86_l_115f);
x86_l_1155:
	/* 0x1155: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_115a:
	/* 0x115a: call   115f <trace_exec_binprm+0x115f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_115f:
	/* 0x115f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1162:
	/* 0x1162: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1164:
	/* 0x1164: jg     1187 <trace_exec_binprm+0x1187> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1164, 0x1187, x86_l_1187);
x86_l_1166:
	/* 0x1166: jmp    11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JMP(0x1166, 0x11ba, x86_l_11ba);
x86_l_1168:
	/* 0x1168: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_116d:
	/* 0x116d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116f:
	/* 0x116f: call   1174 <trace_exec_binprm+0x1174> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_1174:
	/* 0x1174: jmp    11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JMP(0x1174, 0x11ba, x86_l_11ba);
x86_l_1176:
	/* 0x1176: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_117d:
	/* 0x117d: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1182:
	/* 0x1182: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1187:
	/* 0x1187: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_118f:
	/* 0x118f: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1196:
	/* 0x1196: ja     11ba <trace_exec_binprm+0x11ba> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1196, 0x11ba, x86_l_11ba);
x86_l_1198:
	/* 0x1198: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_11a0:
	/* 0x11a0: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_11a8:
	/* 0x11a8: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_11ab:
	/* 0x11ab: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_11b3:
	/* 0x11b3: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_11ba:
	/* 0x11ba: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_11c2:
	/* 0x11c2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_11c9:
	/* 0x11c9: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11ce:
	/* 0x11ce: call   11d3 <trace_exec_binprm+0x11d3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11d3:
	/* 0x11d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11d6:
	/* 0x11d6: je     11f1 <trace_exec_binprm+0x11f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d6, 0x11f1, x86_l_11f1);
x86_l_11d8:
	/* 0x11d8: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11db:
	/* 0x11db: lea    rax,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11df:
	/* 0x11df: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e2:
	/* 0x11e2: jns    120d <trace_exec_binprm+0x120d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11e2, 0x120d, x86_l_120d);
x86_l_11e4:
	/* 0x11e4: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11e7:
	/* 0x11e7: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11ea:
	/* 0x11ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11ed:
	/* 0x11ed: js     1217 <trace_exec_binprm+0x1217> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11ed, 0x1217, x86_l_1217);
x86_l_11ef:
	/* 0x11ef: jmp    1221 <trace_exec_binprm+0x1221> */
	X86_SIM_X86_JMP(0x11ef, 0x1221, x86_l_1221);
x86_l_11f1:
	/* 0x11f1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11f4:
	/* 0x11f4: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_11fc:
	/* 0x11fc: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1202:
	/* 0x1202: jbe    2d14 <trace_exec_binprm+0x2d14> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1202, 0x2d14, x86_l_2d14);
x86_l_1208:
	/* 0x1208: jmp    2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JMP(0x1208, 0x2dd6, x86_l_2dd6);
x86_l_120d:
	/* 0x120d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_120f:
	/* 0x120f: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1212:
	/* 0x1212: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1215:
	/* 0x1215: jns    1221 <trace_exec_binprm+0x1221> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1215, 0x1221, x86_l_1221);
x86_l_1217:
	/* 0x1217: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1219:
	/* 0x1219: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_121b:
	/* 0x121b: jne    1326 <trace_exec_binprm+0x1326> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x121b, 0x1326, x86_l_1326);
x86_l_1221:
	/* 0x1221: lea    rax,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1225:
	/* 0x1225: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1228:
	/* 0x1228: jns    122f <trace_exec_binprm+0x122f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1228, 0x122f, x86_l_122f);
x86_l_122a:
	/* 0x122a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_122d:
	/* 0x122d: jmp    1231 <trace_exec_binprm+0x1231> */
	X86_SIM_X86_JMP(0x122d, 0x1231, x86_l_1231);
x86_l_122f:
	/* 0x122f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1231:
	/* 0x1231: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_1235:
	/* 0x1235: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1238:
	/* 0x1238: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_123b:
	/* 0x123b: jns    1257 <trace_exec_binprm+0x1257> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x123b, 0x1257, x86_l_1257);
x86_l_123d:
	/* 0x123d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1240:
	/* 0x1240: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1243:
	/* 0x1243: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1246:
	/* 0x1246: js     1261 <trace_exec_binprm+0x1261> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1246, 0x1261, x86_l_1261);
x86_l_1248:
	/* 0x1248: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_124a:
	/* 0x124a: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_124e:
	/* 0x124e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1251:
	/* 0x1251: js     126d <trace_exec_binprm+0x126d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1251, 0x126d, x86_l_126d);
x86_l_1253:
	/* 0x1253: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1255:
	/* 0x1255: jmp    1270 <trace_exec_binprm+0x1270> */
	X86_SIM_X86_JMP(0x1255, 0x1270, x86_l_1270);
x86_l_1257:
	/* 0x1257: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1259:
	/* 0x1259: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_125c:
	/* 0x125c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_125f:
	/* 0x125f: jns    1248 <trace_exec_binprm+0x1248> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x125f, 0x1248, x86_l_1248);
x86_l_1261:
	/* 0x1261: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1264:
	/* 0x1264: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1268:
	/* 0x1268: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_126b:
	/* 0x126b: jns    1253 <trace_exec_binprm+0x1253> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x126b, 0x1253, x86_l_1253);
x86_l_126d:
	/* 0x126d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1270:
	/* 0x1270: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1273:
	/* 0x1273: je     1306 <trace_exec_binprm+0x1306> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1273, 0x1306, x86_l_1306);
x86_l_1279:
	/* 0x1279: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_127c:
	/* 0x127c: je     1306 <trace_exec_binprm+0x1306> */
	X86_SIM_X86_JCC(X86_CC_E, 0x127c, 0x1306, x86_l_1306);
x86_l_1282:
	/* 0x1282: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1286:
	/* 0x1286: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1289:
	/* 0x1289: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_128f:
	/* 0x128f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1292:
	/* 0x1292: jns    129b <trace_exec_binprm+0x129b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1292, 0x129b, x86_l_129b);
x86_l_1294:
	/* 0x1294: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1297:
	/* 0x1297: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_129b:
	/* 0x129b: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_129f:
	/* 0x129f: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_12a2:
	/* 0x12a2: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_12a9:
	/* 0x12a9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_12ac:
	/* 0x12ac: je     13e9 <trace_exec_binprm+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12ac, 0x13e9, x86_l_13e9);
x86_l_12b2:
	/* 0x12b2: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_12b5:
	/* 0x12b5: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_12b7:
	/* 0x12b7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_12bd:
	/* 0x12bd: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_12c0:
	/* 0x12c0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_12c3:
	/* 0x12c3: jns    135c <trace_exec_binprm+0x135c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12c3, 0x135c, x86_l_135c);
x86_l_12c9:
	/* 0x12c9: mov    QWORD PTR [rsp],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12cd:
	/* 0x12cd: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d0:
	/* 0x12d0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12d3:
	/* 0x12d3: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_12d7:
	/* 0x12d7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12da:
	/* 0x12da: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_12dd:
	/* 0x12dd: je     13b1 <trace_exec_binprm+0x13b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12dd, 0x13b1, x86_l_13b1);
x86_l_12e3:
	/* 0x12e3: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12e7:
	/* 0x12e7: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_12ea:
	/* 0x12ea: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_12ef:
	/* 0x12ef: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_12f3:
	/* 0x12f3: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12f6:
	/* 0x12f6: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_12f9:
	/* 0x12f9: mov    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12fc:
	/* 0x12fc: jne    12da <trace_exec_binprm+0x12da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12fc, 0x12da, x86_l_12da);
x86_l_12fe:
	/* 0x12fe: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1301:
	/* 0x1301: jmp    13b6 <trace_exec_binprm+0x13b6> */
	X86_SIM_X86_JMP(0x1301, 0x13b6, x86_l_13b6);
x86_l_1306:
	/* 0x1306: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1309:
	/* 0x1309: jne    13e9 <trace_exec_binprm+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1309, 0x13e9, x86_l_13e9);
x86_l_130f:
	/* 0x130f: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1312:
	/* 0x1312: je     13e9 <trace_exec_binprm+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1312, 0x13e9, x86_l_13e9);
x86_l_1318:
	/* 0x1318: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_131c:
	/* 0x131c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_131f:
	/* 0x131f: jns    1388 <trace_exec_binprm+0x1388> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x131f, 0x1388, x86_l_1388);
x86_l_1321:
	/* 0x1321: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1324:
	/* 0x1324: jmp    138a <trace_exec_binprm+0x138a> */
	X86_SIM_X86_JMP(0x1324, 0x138a, x86_l_138a);
x86_l_1326:
	/* 0x1326: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_132d:
	/* 0x132d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1330:
	/* 0x1330: jns    13fe <trace_exec_binprm+0x13fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1330, 0x13fe, x86_l_13fe);
x86_l_1336:
	/* 0x1336: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1339:
	/* 0x1339: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_133b:
	/* 0x133b: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1342:
	/* 0x1342: je     1438 <trace_exec_binprm+0x1438> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1342, 0x1438, x86_l_1438);
x86_l_1348:
	/* 0x1348: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_134c:
	/* 0x134c: mov    BYTE PTR [r15+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1350:
	/* 0x1350: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1353:
	/* 0x1353: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1355:
	/* 0x1355: jne    133b <trace_exec_binprm+0x133b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1355, 0x133b, x86_l_133b);
x86_l_1357:
	/* 0x1357: jmp    2cf6 <trace_exec_binprm+0x2cf6> */
	X86_SIM_X86_JMP(0x1357, 0x2cf6, x86_l_2cf6);
x86_l_135c:
	/* 0x135c: mov    eax,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1361:
	/* 0x1361: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1365:
	/* 0x1365: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1368:
	/* 0x1368: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_136a:
	/* 0x136a: call   136f <trace_exec_binprm+0x136f> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_136f:
	/* 0x136f: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1372:
	/* 0x1372: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1376:
	/* 0x1376: mov    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1379:
	/* 0x1379: cmp    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1380:
	/* 0x1380: jne    2cde <trace_exec_binprm+0x2cde> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1380, 0x2cde, x86_l_2cde);
x86_l_1386:
	/* 0x1386: jmp    13e9 <trace_exec_binprm+0x13e9> */
	X86_SIM_X86_JMP(0x1386, 0x13e9, x86_l_13e9);
x86_l_1388:
	/* 0x1388: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_138a:
	/* 0x138a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_138d:
	/* 0x138d: jns    1394 <trace_exec_binprm+0x1394> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138d, 0x1394, x86_l_1394);
x86_l_138f:
	/* 0x138f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1392:
	/* 0x1392: jmp    1396 <trace_exec_binprm+0x1396> */
	X86_SIM_X86_JMP(0x1392, 0x1396, x86_l_1396);
x86_l_1394:
	/* 0x1394: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1396:
	/* 0x1396: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1399:
	/* 0x1399: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_139c:
	/* 0x139c: jns    13a3 <trace_exec_binprm+0x13a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x139c, 0x13a3, x86_l_13a3);
x86_l_139e:
	/* 0x139e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13a1:
	/* 0x13a1: jmp    13a5 <trace_exec_binprm+0x13a5> */
	X86_SIM_X86_JMP(0x13a1, 0x13a5, x86_l_13a5);
x86_l_13a3:
	/* 0x13a3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13a5:
	/* 0x13a5: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13a9:
	/* 0x13a9: mov    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_13af:
	/* 0x13af: jmp    13dc <trace_exec_binprm+0x13dc> */
	X86_SIM_X86_JMP(0x13af, 0x13dc, x86_l_13dc);
x86_l_13b1:
	/* 0x13b1: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_13b6:
	/* 0x13b6: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_13ba:
	/* 0x13ba: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13bf:
	/* 0x13bf: jl     13e9 <trace_exec_binprm+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_L, 0x13bf, 0x13e9, x86_l_13e9);
x86_l_13c1:
	/* 0x13c1: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13c4:
	/* 0x13c4: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13c7:
	/* 0x13c7: mov    BYTE PTR [r15+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_13cf:
	/* 0x13cf: mov    r10d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_13d5:
	/* 0x13d5: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_13d8:
	/* 0x13d8: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13dc:
	/* 0x13dc: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_13df:
	/* 0x13df: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_13e2:
	/* 0x13e2: jns    1448 <trace_exec_binprm+0x1448> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e2, 0x1448, x86_l_1448);
x86_l_13e4:
	/* 0x13e4: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e7:
	/* 0x13e7: jmp    144a <trace_exec_binprm+0x144a> */
	X86_SIM_X86_JMP(0x13e7, 0x144a, x86_l_144a);
x86_l_13e9:
	/* 0x13e9: add    rbx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_13ed:
	/* 0x13ed: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13f0:
	/* 0x13f0: jns    140f <trace_exec_binprm+0x140f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13f0, 0x140f, x86_l_140f);
x86_l_13f2:
	/* 0x13f2: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13f5:
	/* 0x13f5: mov    rax,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13f9:
	/* 0x13f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13fc:
	/* 0x13fc: js     1416 <trace_exec_binprm+0x1416> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13fc, 0x1416, x86_l_1416);
x86_l_13fe:
	/* 0x13fe: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1403:
	/* 0x1403: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1406:
	/* 0x1406: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1408:
	/* 0x1408: call   140d <trace_exec_binprm+0x140d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_140d:
	/* 0x140d: jmp    1440 <trace_exec_binprm+0x1440> */
	X86_SIM_X86_JMP(0x140d, 0x1440, x86_l_1440);
x86_l_140f:
	/* 0x140f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1411:
	/* 0x1411: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1414:
	/* 0x1414: jns    13fe <trace_exec_binprm+0x13fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1414, 0x13fe, x86_l_13fe);
x86_l_1416:
	/* 0x1416: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1419:
	/* 0x1419: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_141b:
	/* 0x141b: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1422:
	/* 0x1422: je     1438 <trace_exec_binprm+0x1438> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1422, 0x1438, x86_l_1438);
x86_l_1424:
	/* 0x1424: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1428:
	/* 0x1428: mov    BYTE PTR [r15+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_142c:
	/* 0x142c: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_142f:
	/* 0x142f: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1431:
	/* 0x1431: jne    141b <trace_exec_binprm+0x141b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1431, 0x141b, x86_l_141b);
x86_l_1433:
	/* 0x1433: jmp    2cf6 <trace_exec_binprm+0x2cf6> */
	X86_SIM_X86_JMP(0x1433, 0x2cf6, x86_l_2cf6);
x86_l_1438:
	/* 0x1438: mov    BYTE PTR [r15+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_1440:
	/* 0x1440: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1443:
	/* 0x1443: jmp    2cf6 <trace_exec_binprm+0x2cf6> */
	X86_SIM_X86_JMP(0x1443, 0x2cf6, x86_l_2cf6);
x86_l_1448:
	/* 0x1448: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_144a:
	/* 0x144a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_144e:
	/* 0x144e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1451:
	/* 0x1451: jns    1458 <trace_exec_binprm+0x1458> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1451, 0x1458, x86_l_1458);
x86_l_1453:
	/* 0x1453: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1456:
	/* 0x1456: jmp    145a <trace_exec_binprm+0x145a> */
	X86_SIM_X86_JMP(0x1456, 0x145a, x86_l_145a);
x86_l_1458:
	/* 0x1458: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_145a:
	/* 0x145a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_145d:
	/* 0x145d: je     14f2 <trace_exec_binprm+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x145d, 0x14f2, x86_l_14f2);
x86_l_1463:
	/* 0x1463: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1466:
	/* 0x1466: je     14f2 <trace_exec_binprm+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1466, 0x14f2, x86_l_14f2);
x86_l_146c:
	/* 0x146c: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1470:
	/* 0x1470: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1473:
	/* 0x1473: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1479:
	/* 0x1479: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_147c:
	/* 0x147c: jns    1485 <trace_exec_binprm+0x1485> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x147c, 0x1485, x86_l_1485);
x86_l_147e:
	/* 0x147e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1481:
	/* 0x1481: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1485:
	/* 0x1485: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1489:
	/* 0x1489: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_148c:
	/* 0x148c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1493:
	/* 0x1493: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_1496:
	/* 0x1496: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1499:
	/* 0x1499: jb     2cde <trace_exec_binprm+0x2cde> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1499, 0x2cde, x86_l_2cde);
x86_l_149f:
	/* 0x149f: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_14a2:
	/* 0x14a2: je     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14a2, 0x1376, x86_l_1376);
x86_l_14a8:
	/* 0x14a8: mov    QWORD PTR [rsp],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ac:
	/* 0x14ac: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_14b2:
	/* 0x14b2: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_14b5:
	/* 0x14b5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_14b8:
	/* 0x14b8: jns    1750 <trace_exec_binprm+0x1750> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14b8, 0x1750, x86_l_1750);
x86_l_14be:
	/* 0x14be: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_14c3:
	/* 0x14c3: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14c6:
	/* 0x14c6: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_14ca:
	/* 0x14ca: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14cd:
	/* 0x14cd: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_14d0:
	/* 0x14d0: je     1540 <trace_exec_binprm+0x1540> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14d0, 0x1540, x86_l_1540);
x86_l_14d2:
	/* 0x14d2: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_14d6:
	/* 0x14d6: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_14d9:
	/* 0x14d9: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_14de:
	/* 0x14de: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_14e2:
	/* 0x14e2: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_14e5:
	/* 0x14e5: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_14e8:
	/* 0x14e8: mov    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14eb:
	/* 0x14eb: jne    14cd <trace_exec_binprm+0x14cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14eb, 0x14cd, x86_l_14cd);
x86_l_14ed:
	/* 0x14ed: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_14f0:
	/* 0x14f0: jmp    1545 <trace_exec_binprm+0x1545> */
	X86_SIM_X86_JMP(0x14f0, 0x1545, x86_l_1545);
x86_l_14f2:
	/* 0x14f2: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14f5:
	/* 0x14f5: jne    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14f5, 0x1376, x86_l_1376);
x86_l_14fb:
	/* 0x14fb: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14fe:
	/* 0x14fe: je     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14fe, 0x1376, x86_l_1376);
x86_l_1504:
	/* 0x1504: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1508:
	/* 0x1508: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_150b:
	/* 0x150b: jns    1512 <trace_exec_binprm+0x1512> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x150b, 0x1512, x86_l_1512);
x86_l_150d:
	/* 0x150d: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1510:
	/* 0x1510: jmp    1514 <trace_exec_binprm+0x1514> */
	X86_SIM_X86_JMP(0x1510, 0x1514, x86_l_1514);
x86_l_1512:
	/* 0x1512: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1514:
	/* 0x1514: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1517:
	/* 0x1517: jns    151e <trace_exec_binprm+0x151e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1517, 0x151e, x86_l_151e);
x86_l_1519:
	/* 0x1519: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_151c:
	/* 0x151c: jmp    1520 <trace_exec_binprm+0x1520> */
	X86_SIM_X86_JMP(0x151c, 0x1520, x86_l_1520);
x86_l_151e:
	/* 0x151e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1520:
	/* 0x1520: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1523:
	/* 0x1523: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1526:
	/* 0x1526: jns    152d <trace_exec_binprm+0x152d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1526, 0x152d, x86_l_152d);
x86_l_1528:
	/* 0x1528: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_152b:
	/* 0x152b: jmp    152f <trace_exec_binprm+0x152f> */
	X86_SIM_X86_JMP(0x152b, 0x152f, x86_l_152f);
x86_l_152d:
	/* 0x152d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_152f:
	/* 0x152f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1533:
	/* 0x1533: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1536:
	/* 0x1536: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1539:
	/* 0x1539: jns    157a <trace_exec_binprm+0x157a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1539, 0x157a, x86_l_157a);
x86_l_153b:
	/* 0x153b: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153e:
	/* 0x153e: jmp    157c <trace_exec_binprm+0x157c> */
	X86_SIM_X86_JMP(0x153e, 0x157c, x86_l_157c);
x86_l_1540:
	/* 0x1540: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1545:
	/* 0x1545: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1549:
	/* 0x1549: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_154e:
	/* 0x154e: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1552:
	/* 0x1552: jl     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1552, 0x1376, x86_l_1376);
x86_l_1558:
	/* 0x1558: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_155b:
	/* 0x155b: lea    edx,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_155f:
	/* 0x155f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1565:
	/* 0x1565: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_156a:
	/* 0x156a: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_156d:
	/* 0x156d: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1572:
	/* 0x1572: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1575:
	/* 0x1575: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1578:
	/* 0x1578: js     153b <trace_exec_binprm+0x153b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1578, 0x153b, x86_l_153b);
x86_l_157a:
	/* 0x157a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157c:
	/* 0x157c: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1580:
	/* 0x1580: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1583:
	/* 0x1583: jns    158a <trace_exec_binprm+0x158a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1583, 0x158a, x86_l_158a);
x86_l_1585:
	/* 0x1585: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1588:
	/* 0x1588: jmp    158c <trace_exec_binprm+0x158c> */
	X86_SIM_X86_JMP(0x1588, 0x158c, x86_l_158c);
x86_l_158a:
	/* 0x158a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_158c:
	/* 0x158c: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_158f:
	/* 0x158f: je     1624 <trace_exec_binprm+0x1624> */
	X86_SIM_X86_JCC(X86_CC_E, 0x158f, 0x1624, x86_l_1624);
x86_l_1595:
	/* 0x1595: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1598:
	/* 0x1598: je     1624 <trace_exec_binprm+0x1624> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1598, 0x1624, x86_l_1624);
x86_l_159e:
	/* 0x159e: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15a2:
	/* 0x15a2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a5:
	/* 0x15a5: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_15ab:
	/* 0x15ab: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15ae:
	/* 0x15ae: jns    15b7 <trace_exec_binprm+0x15b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ae, 0x15b7, x86_l_15b7);
x86_l_15b0:
	/* 0x15b0: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b3:
	/* 0x15b3: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15b7:
	/* 0x15b7: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_15bb:
	/* 0x15bb: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_15be:
	/* 0x15be: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_15c5:
	/* 0x15c5: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_15c8:
	/* 0x15c8: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_15cb:
	/* 0x15cb: jb     2cde <trace_exec_binprm+0x2cde> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15cb, 0x2cde, x86_l_2cde);
x86_l_15d1:
	/* 0x15d1: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_15d4:
	/* 0x15d4: je     1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15d4, 0x1a64, x86_l_1a64);
x86_l_15da:
	/* 0x15da: mov    QWORD PTR [rsp],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15de:
	/* 0x15de: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_15e4:
	/* 0x15e4: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15e7:
	/* 0x15e7: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_15ea:
	/* 0x15ea: jns    1365 <trace_exec_binprm+0x1365> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ea, 0x1365, x86_l_1365);
x86_l_15f0:
	/* 0x15f0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15f5:
	/* 0x15f5: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15f8:
	/* 0x15f8: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_15fc:
	/* 0x15fc: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15ff:
	/* 0x15ff: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1602:
	/* 0x1602: je     1672 <trace_exec_binprm+0x1672> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1602, 0x1672, x86_l_1672);
x86_l_1604:
	/* 0x1604: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1608:
	/* 0x1608: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_160b:
	/* 0x160b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1610:
	/* 0x1610: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1614:
	/* 0x1614: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1617:
	/* 0x1617: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_161a:
	/* 0x161a: mov    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_161d:
	/* 0x161d: jne    15ff <trace_exec_binprm+0x15ff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x161d, 0x15ff, x86_l_15ff);
x86_l_161f:
	/* 0x161f: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1622:
	/* 0x1622: jmp    1677 <trace_exec_binprm+0x1677> */
	X86_SIM_X86_JMP(0x1622, 0x1677, x86_l_1677);
x86_l_1624:
	/* 0x1624: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1627:
	/* 0x1627: jne    1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1627, 0x1a64, x86_l_1a64);
x86_l_162d:
	/* 0x162d: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1630:
	/* 0x1630: je     1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1630, 0x1a64, x86_l_1a64);
x86_l_1636:
	/* 0x1636: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_163a:
	/* 0x163a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_163d:
	/* 0x163d: jns    1644 <trace_exec_binprm+0x1644> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x163d, 0x1644, x86_l_1644);
x86_l_163f:
	/* 0x163f: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1642:
	/* 0x1642: jmp    1646 <trace_exec_binprm+0x1646> */
	X86_SIM_X86_JMP(0x1642, 0x1646, x86_l_1646);
x86_l_1644:
	/* 0x1644: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1646:
	/* 0x1646: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1649:
	/* 0x1649: jns    1650 <trace_exec_binprm+0x1650> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1649, 0x1650, x86_l_1650);
x86_l_164b:
	/* 0x164b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_164e:
	/* 0x164e: jmp    1652 <trace_exec_binprm+0x1652> */
	X86_SIM_X86_JMP(0x164e, 0x1652, x86_l_1652);
x86_l_1650:
	/* 0x1650: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1652:
	/* 0x1652: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1655:
	/* 0x1655: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1658:
	/* 0x1658: jns    165f <trace_exec_binprm+0x165f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1658, 0x165f, x86_l_165f);
x86_l_165a:
	/* 0x165a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_165d:
	/* 0x165d: jmp    1661 <trace_exec_binprm+0x1661> */
	X86_SIM_X86_JMP(0x165d, 0x1661, x86_l_1661);
x86_l_165f:
	/* 0x165f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1661:
	/* 0x1661: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1665:
	/* 0x1665: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1668:
	/* 0x1668: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_166b:
	/* 0x166b: jns    16ac <trace_exec_binprm+0x16ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x166b, 0x16ac, x86_l_16ac);
x86_l_166d:
	/* 0x166d: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1670:
	/* 0x1670: jmp    16ae <trace_exec_binprm+0x16ae> */
	X86_SIM_X86_JMP(0x1670, 0x16ae, x86_l_16ae);
x86_l_1672:
	/* 0x1672: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1677:
	/* 0x1677: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_167b:
	/* 0x167b: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1680:
	/* 0x1680: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1684:
	/* 0x1684: jl     1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1684, 0x1a64, x86_l_1a64);
x86_l_168a:
	/* 0x168a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_168d:
	/* 0x168d: lea    edi,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1691:
	/* 0x1691: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1697:
	/* 0x1697: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_169c:
	/* 0x169c: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_169f:
	/* 0x169f: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_16a4:
	/* 0x16a4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16a7:
	/* 0x16a7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16aa:
	/* 0x16aa: js     166d <trace_exec_binprm+0x166d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16aa, 0x166d, x86_l_166d);
x86_l_16ac:
	/* 0x16ac: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ae:
	/* 0x16ae: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16b2:
	/* 0x16b2: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_16b5:
	/* 0x16b5: jns    16bc <trace_exec_binprm+0x16bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16b5, 0x16bc, x86_l_16bc);
x86_l_16b7:
	/* 0x16b7: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16ba:
	/* 0x16ba: jmp    16be <trace_exec_binprm+0x16be> */
	X86_SIM_X86_JMP(0x16ba, 0x16be, x86_l_16be);
x86_l_16bc:
	/* 0x16bc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16be:
	/* 0x16be: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16c1:
	/* 0x16c1: je     1758 <trace_exec_binprm+0x1758> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16c1, 0x1758, x86_l_1758);
x86_l_16c7:
	/* 0x16c7: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16ca:
	/* 0x16ca: je     1758 <trace_exec_binprm+0x1758> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16ca, 0x1758, x86_l_1758);
x86_l_16d0:
	/* 0x16d0: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16d4:
	/* 0x16d4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d7:
	/* 0x16d7: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_16dd:
	/* 0x16dd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16e0:
	/* 0x16e0: jns    16e9 <trace_exec_binprm+0x16e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e0, 0x16e9, x86_l_16e9);
x86_l_16e2:
	/* 0x16e2: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e5:
	/* 0x16e5: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16e9:
	/* 0x16e9: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_16ed:
	/* 0x16ed: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_16f0:
	/* 0x16f0: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_16f7:
	/* 0x16f7: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_16fa:
	/* 0x16fa: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16fd:
	/* 0x16fd: jb     2cde <trace_exec_binprm+0x2cde> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16fd, 0x2cde, x86_l_2cde);
x86_l_1703:
	/* 0x1703: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1706:
	/* 0x1706: je     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1706, 0x1376, x86_l_1376);
x86_l_170c:
	/* 0x170c: mov    QWORD PTR [rsp],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1710:
	/* 0x1710: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1716:
	/* 0x1716: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1719:
	/* 0x1719: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_171c:
	/* 0x171c: jns    1750 <trace_exec_binprm+0x1750> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x171c, 0x1750, x86_l_1750);
x86_l_171e:
	/* 0x171e: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1723:
	/* 0x1723: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1727:
	/* 0x1727: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_172a:
	/* 0x172a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_172d:
	/* 0x172d: je     1978 <trace_exec_binprm+0x1978> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172d, 0x1978, x86_l_1978);
x86_l_1733:
	/* 0x1733: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1737:
	/* 0x1737: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_173c:
	/* 0x173c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1740:
	/* 0x1740: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1743:
	/* 0x1743: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1746:
	/* 0x1746: jne    172a <trace_exec_binprm+0x172a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1746, 0x172a, x86_l_172a);
x86_l_1748:
	/* 0x1748: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_174b:
	/* 0x174b: jmp    197d <trace_exec_binprm+0x197d> */
	X86_SIM_X86_JMP(0x174b, 0x197d, x86_l_197d);
x86_l_1750:
	/* 0x1750: mov    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1753:
	/* 0x1753: jmp    1365 <trace_exec_binprm+0x1365> */
	X86_SIM_X86_JMP(0x1753, 0x1365, x86_l_1365);
x86_l_1758:
	/* 0x1758: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_175b:
	/* 0x175b: jne    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x175b, 0x1376, x86_l_1376);
x86_l_1761:
	/* 0x1761: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1764:
	/* 0x1764: je     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1764, 0x1376, x86_l_1376);
x86_l_176a:
	/* 0x176a: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_176e:
	/* 0x176e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1771:
	/* 0x1771: jns    1778 <trace_exec_binprm+0x1778> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1771, 0x1778, x86_l_1778);
x86_l_1773:
	/* 0x1773: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1776:
	/* 0x1776: jmp    177a <trace_exec_binprm+0x177a> */
	X86_SIM_X86_JMP(0x1776, 0x177a, x86_l_177a);
x86_l_1778:
	/* 0x1778: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_177a:
	/* 0x177a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177d:
	/* 0x177d: jns    1784 <trace_exec_binprm+0x1784> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x177d, 0x1784, x86_l_1784);
x86_l_177f:
	/* 0x177f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1782:
	/* 0x1782: jmp    1786 <trace_exec_binprm+0x1786> */
	X86_SIM_X86_JMP(0x1782, 0x1786, x86_l_1786);
x86_l_1784:
	/* 0x1784: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1786:
	/* 0x1786: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1789:
	/* 0x1789: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_178c:
	/* 0x178c: jns    1793 <trace_exec_binprm+0x1793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178c, 0x1793, x86_l_1793);
x86_l_178e:
	/* 0x178e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1791:
	/* 0x1791: jmp    1795 <trace_exec_binprm+0x1795> */
	X86_SIM_X86_JMP(0x1791, 0x1795, x86_l_1795);
x86_l_1793:
	/* 0x1793: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1795:
	/* 0x1795: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1799:
	/* 0x1799: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_179c:
	/* 0x179c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_179f:
	/* 0x179f: jns    19b3 <trace_exec_binprm+0x19b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x179f, 0x19b3, x86_l_19b3);
x86_l_17a5:
	/* 0x17a5: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a8:
	/* 0x17a8: jmp    19b5 <trace_exec_binprm+0x19b5> */
	X86_SIM_X86_JMP(0x17a8, 0x19b5, x86_l_19b5);
x86_l_17ad:
	/* 0x17ad: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17b0:
	/* 0x17b0: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_17b4:
	/* 0x17b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17b7:
	/* 0x17b7: jns    195b <trace_exec_binprm+0x195b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17b7, 0x195b, x86_l_195b);
x86_l_17bd:
	/* 0x17bd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c0:
	/* 0x17c0: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_17c7:
	/* 0x17c7: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17cb:
	/* 0x17cb: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_17d2:
	/* 0x17d2: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d6:
	/* 0x17d6: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_17dd:
	/* 0x17dd: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17e1:
	/* 0x17e1: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_17e8:
	/* 0x17e8: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17ec:
	/* 0x17ec: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_17f3:
	/* 0x17f3: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_17f7:
	/* 0x17f7: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_17fe:
	/* 0x17fe: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1802:
	/* 0x1802: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1809:
	/* 0x1809: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_180d:
	/* 0x180d: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_1814:
	/* 0x1814: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1818:
	/* 0x1818: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_181f:
	/* 0x181f: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1823:
	/* 0x1823: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_182a:
	/* 0x182a: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_182e:
	/* 0x182e: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_1835:
	/* 0x1835: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1839:
	/* 0x1839: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1840:
	/* 0x1840: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1844:
	/* 0x1844: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_184b:
	/* 0x184b: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_184f:
	/* 0x184f: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1856:
	/* 0x1856: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_185a:
	/* 0x185a: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1861:
	/* 0x1861: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1865:
	/* 0x1865: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_186c:
	/* 0x186c: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1873:
	/* 0x1873: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_187a:
	/* 0x187a: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1881:
	/* 0x1881: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1888:
	/* 0x1888: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_188f:
	/* 0x188f: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_1896:
	/* 0x1896: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_189d:
	/* 0x189d: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_18a4:
	/* 0x18a4: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_18ab:
	/* 0x18ab: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_18b2:
	/* 0x18b2: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_18b9:
	/* 0x18b9: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_18c0:
	/* 0x18c0: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_18c7:
	/* 0x18c7: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_18ce:
	/* 0x18ce: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_18d5:
	/* 0x18d5: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_18dc:
	/* 0x18dc: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_18e3:
	/* 0x18e3: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_18ea:
	/* 0x18ea: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_18f1:
	/* 0x18f1: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_18f8:
	/* 0x18f8: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_18ff:
	/* 0x18ff: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_1906:
	/* 0x1906: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_190d:
	/* 0x190d: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_1914:
	/* 0x1914: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_191b:
	/* 0x191b: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1922:
	/* 0x1922: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1929:
	/* 0x1929: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1930:
	/* 0x1930: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1937:
	/* 0x1937: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_193e:
	/* 0x193e: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1945:
	/* 0x1945: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_194c:
	/* 0x194c: movzx  eax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1951:
	/* 0x1951: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1956:
	/* 0x1956: jmp    794 <trace_exec_binprm+0x794> */
	X86_SIM_X86_JMP(0x1956, 0x794, x86_l_794);
x86_l_195b:
	/* 0x195b: add    r14,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1962:
	/* 0x1962: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1964:
	/* 0x1964: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1969:
	/* 0x1969: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_196c:
	/* 0x196c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_196e:
	/* 0x196e: call   1973 <trace_exec_binprm+0x1973> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1973:
	/* 0x1973: jmp    1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JMP(0x1973, 0x1f, x86_l_1f);
x86_l_1978:
	/* 0x1978: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_197d:
	/* 0x197d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1981:
	/* 0x1981: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1986:
	/* 0x1986: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_198b:
	/* 0x198b: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_198f:
	/* 0x198f: jl     1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JCC(X86_CC_L, 0x198f, 0x1376, x86_l_1376);
x86_l_1995:
	/* 0x1995: lea    edx,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1999:
	/* 0x1999: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_199f:
	/* 0x199f: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_19a4:
	/* 0x19a4: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_19a7:
	/* 0x19a7: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_19aa:
	/* 0x19aa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19ad:
	/* 0x19ad: js     17a5 <trace_exec_binprm+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19ad, 0x17a5, x86_l_17a5);
x86_l_19b3:
	/* 0x19b3: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19b5:
	/* 0x19b5: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b9:
	/* 0x19b9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19bc:
	/* 0x19bc: jns    19c3 <trace_exec_binprm+0x19c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19bc, 0x19c3, x86_l_19c3);
x86_l_19be:
	/* 0x19be: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19c1:
	/* 0x19c1: jmp    19c5 <trace_exec_binprm+0x19c5> */
	X86_SIM_X86_JMP(0x19c1, 0x19c5, x86_l_19c5);
x86_l_19c3:
	/* 0x19c3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19c5:
	/* 0x19c5: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19c8:
	/* 0x19c8: je     1a4c <trace_exec_binprm+0x1a4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c8, 0x1a4c, x86_l_1a4c);
x86_l_19ce:
	/* 0x19ce: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19d1:
	/* 0x19d1: je     1a4c <trace_exec_binprm+0x1a4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d1, 0x1a4c, x86_l_1a4c);
x86_l_19d3:
	/* 0x19d3: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19d7:
	/* 0x19d7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19da:
	/* 0x19da: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_19e0:
	/* 0x19e0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19e3:
	/* 0x19e3: jns    19ec <trace_exec_binprm+0x19ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19e3, 0x19ec, x86_l_19ec);
x86_l_19e5:
	/* 0x19e5: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19e8:
	/* 0x19e8: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ec:
	/* 0x19ec: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_19f0:
	/* 0x19f0: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_19f3:
	/* 0x19f3: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_19fa:
	/* 0x19fa: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_19fd:
	/* 0x19fd: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a00:
	/* 0x1a00: jb     2cde <trace_exec_binprm+0x2cde> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a00, 0x2cde, x86_l_2cde);
x86_l_1a06:
	/* 0x1a06: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1a09:
	/* 0x1a09: je     1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a09, 0x1a64, x86_l_1a64);
x86_l_1a0b:
	/* 0x1a0b: mov    QWORD PTR [rsp],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a0f:
	/* 0x1a0f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1a15:
	/* 0x1a15: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a18:
	/* 0x1a18: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1a1b:
	/* 0x1a1b: jns    1365 <trace_exec_binprm+0x1365> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a1b, 0x1365, x86_l_1365);
x86_l_1a21:
	/* 0x1a21: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a26:
	/* 0x1a26: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a2a:
	/* 0x1a2a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a2d:
	/* 0x1a2d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1a30:
	/* 0x1a30: je     1a9a <trace_exec_binprm+0x1a9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a30, 0x1a9a, x86_l_1a9a);
x86_l_1a32:
	/* 0x1a32: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a36:
	/* 0x1a36: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1a3b:
	/* 0x1a3b: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1a3f:
	/* 0x1a3f: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1a42:
	/* 0x1a42: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1a45:
	/* 0x1a45: jne    1a2d <trace_exec_binprm+0x1a2d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a45, 0x1a2d, x86_l_1a2d);
x86_l_1a47:
	/* 0x1a47: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1a4a:
	/* 0x1a4a: jmp    1a9f <trace_exec_binprm+0x1a9f> */
	X86_SIM_X86_JMP(0x1a4a, 0x1a9f, x86_l_1a9f);
x86_l_1a4c:
	/* 0x1a4c: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a4f:
	/* 0x1a4f: jne    1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a4f, 0x1a64, x86_l_1a64);
x86_l_1a51:
	/* 0x1a51: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a54:
	/* 0x1a54: je     1a64 <trace_exec_binprm+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a54, 0x1a64, x86_l_1a64);
x86_l_1a56:
	/* 0x1a56: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a5a:
	/* 0x1a5a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a5d:
	/* 0x1a5d: jns    1a6c <trace_exec_binprm+0x1a6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a5d, 0x1a6c, x86_l_1a6c);
x86_l_1a5f:
	/* 0x1a5f: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a62:
	/* 0x1a62: jmp    1a6e <trace_exec_binprm+0x1a6e> */
	X86_SIM_X86_JMP(0x1a62, 0x1a6e, x86_l_1a6e);
x86_l_1a64:
	/* 0x1a64: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a67:
	/* 0x1a67: jmp    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JMP(0x1a67, 0x1376, x86_l_1376);
x86_l_1a6c:
	/* 0x1a6c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a6e:
	/* 0x1a6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a71:
	/* 0x1a71: jns    1a78 <trace_exec_binprm+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a71, 0x1a78, x86_l_1a78);
x86_l_1a73:
	/* 0x1a73: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a76:
	/* 0x1a76: jmp    1a7a <trace_exec_binprm+0x1a7a> */
	X86_SIM_X86_JMP(0x1a76, 0x1a7a, x86_l_1a7a);
x86_l_1a78:
	/* 0x1a78: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a7a:
	/* 0x1a7a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a7d:
	/* 0x1a7d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a80:
	/* 0x1a80: jns    1a87 <trace_exec_binprm+0x1a87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a80, 0x1a87, x86_l_1a87);
x86_l_1a82:
	/* 0x1a82: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a85:
	/* 0x1a85: jmp    1a89 <trace_exec_binprm+0x1a89> */
	X86_SIM_X86_JMP(0x1a85, 0x1a89, x86_l_1a89);
x86_l_1a87:
	/* 0x1a87: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a89:
	/* 0x1a89: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a8d:
	/* 0x1a8d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a90:
	/* 0x1a90: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a93:
	/* 0x1a93: jns    1acc <trace_exec_binprm+0x1acc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a93, 0x1acc, x86_l_1acc);
x86_l_1a95:
	/* 0x1a95: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a98:
	/* 0x1a98: jmp    1ace <trace_exec_binprm+0x1ace> */
	X86_SIM_X86_JMP(0x1a98, 0x1ace, x86_l_1ace);
x86_l_1a9a:
	/* 0x1a9a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a9f:
	/* 0x1a9f: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1aa3:
	/* 0x1aa3: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1aa3, 0x2c77, x86_l_2c77);
x86_l_1aa9:
	/* 0x1aa9: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aad:
	/* 0x1aad: lea    edi,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ab1:
	/* 0x1ab1: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ab7:
	/* 0x1ab7: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1abc:
	/* 0x1abc: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1abf:
	/* 0x1abf: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ac4:
	/* 0x1ac4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ac7:
	/* 0x1ac7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1aca:
	/* 0x1aca: js     1a95 <trace_exec_binprm+0x1a95> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1aca, 0x1a95, x86_l_1a95);
x86_l_1acc:
	/* 0x1acc: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ace:
	/* 0x1ace: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ad2:
	/* 0x1ad2: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ad5:
	/* 0x1ad5: jns    1adc <trace_exec_binprm+0x1adc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ad5, 0x1adc, x86_l_1adc);
x86_l_1ad7:
	/* 0x1ad7: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ada:
	/* 0x1ada: jmp    1ade <trace_exec_binprm+0x1ade> */
	X86_SIM_X86_JMP(0x1ada, 0x1ade, x86_l_1ade);
x86_l_1adc:
	/* 0x1adc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ade:
	/* 0x1ade: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ae1:
	/* 0x1ae1: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ae6:
	/* 0x1ae6: mov    QWORD PTR [rsp],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aea:
	/* 0x1aea: je     1b81 <trace_exec_binprm+0x1b81> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aea, 0x1b81, x86_l_1b81);
x86_l_1af0:
	/* 0x1af0: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1af3:
	/* 0x1af3: je     1b81 <trace_exec_binprm+0x1b81> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1af3, 0x1b81, x86_l_1b81);
x86_l_1af9:
	/* 0x1af9: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1afe:
	/* 0x1afe: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b03:
	/* 0x1b03: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b06:
	/* 0x1b06: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b0a:
	/* 0x1b0a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b0d:
	/* 0x1b0d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1b13:
	/* 0x1b13: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b16:
	/* 0x1b16: jns    1b1f <trace_exec_binprm+0x1b1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b16, 0x1b1f, x86_l_1b1f);
x86_l_1b18:
	/* 0x1b18: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b1b:
	/* 0x1b1b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b1f:
	/* 0x1b1f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b23:
	/* 0x1b23: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1b26:
	/* 0x1b26: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b2d:
	/* 0x1b2d: mov    edi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_1b30:
	/* 0x1b30: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b33:
	/* 0x1b33: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b33, 0x2cd0, x86_l_2cd0);
x86_l_1b39:
	/* 0x1b39: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1b3c:
	/* 0x1b3c: je     1cfb <trace_exec_binprm+0x1cfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b3c, 0x1cfb, x86_l_1cfb);
x86_l_1b42:
	/* 0x1b42: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b48:
	/* 0x1b48: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b4b:
	/* 0x1b4b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1b4e:
	/* 0x1b4e: jns    1bf7 <trace_exec_binprm+0x1bf7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b4e, 0x1bf7, x86_l_1bf7);
x86_l_1b54:
	/* 0x1b54: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b58:
	/* 0x1b58: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b5b:
	/* 0x1b5b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b5e:
	/* 0x1b5e: je     1bff <trace_exec_binprm+0x1bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5e, 0x1bff, x86_l_1bff);
x86_l_1b64:
	/* 0x1b64: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b68:
	/* 0x1b68: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b6d:
	/* 0x1b6d: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b71:
	/* 0x1b71: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1b74:
	/* 0x1b74: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1b77:
	/* 0x1b77: jne    1b5b <trace_exec_binprm+0x1b5b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b77, 0x1b5b, x86_l_1b5b);
x86_l_1b79:
	/* 0x1b79: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b7c:
	/* 0x1b7c: jmp    1c04 <trace_exec_binprm+0x1c04> */
	X86_SIM_X86_JMP(0x1b7c, 0x1c04, x86_l_1c04);
x86_l_1b81:
	/* 0x1b81: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b84:
	/* 0x1b84: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b87:
	/* 0x1b87: jne    1b9f <trace_exec_binprm+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b87, 0x1b9f, x86_l_1b9f);
x86_l_1b89:
	/* 0x1b89: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b8c:
	/* 0x1b8c: je     1b9f <trace_exec_binprm+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b8c, 0x1b9f, x86_l_1b9f);
x86_l_1b8e:
	/* 0x1b8e: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b91:
	/* 0x1b91: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b95:
	/* 0x1b95: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b98:
	/* 0x1b98: jns    1bb5 <trace_exec_binprm+0x1bb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b98, 0x1bb5, x86_l_1bb5);
x86_l_1b9a:
	/* 0x1b9a: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9d:
	/* 0x1b9d: jmp    1bb7 <trace_exec_binprm+0x1bb7> */
	X86_SIM_X86_JMP(0x1b9d, 0x1bb7, x86_l_1bb7);
x86_l_1b9f:
	/* 0x1b9f: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ba4:
	/* 0x1ba4: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ba9:
	/* 0x1ba9: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bad:
	/* 0x1bad: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bb0:
	/* 0x1bb0: jmp    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JMP(0x1bb0, 0x1376, x86_l_1376);
x86_l_1bb5:
	/* 0x1bb5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bb7:
	/* 0x1bb7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bba:
	/* 0x1bba: jns    1bc4 <trace_exec_binprm+0x1bc4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bba, 0x1bc4, x86_l_1bc4);
x86_l_1bbc:
	/* 0x1bbc: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bbf:
	/* 0x1bbf: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bc2:
	/* 0x1bc2: jmp    1bc6 <trace_exec_binprm+0x1bc6> */
	X86_SIM_X86_JMP(0x1bc2, 0x1bc6, x86_l_1bc6);
x86_l_1bc4:
	/* 0x1bc4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc6:
	/* 0x1bc6: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bcb:
	/* 0x1bcb: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bd0:
	/* 0x1bd0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bd3:
	/* 0x1bd3: jns    1bda <trace_exec_binprm+0x1bda> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bd3, 0x1bda, x86_l_1bda);
x86_l_1bd5:
	/* 0x1bd5: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bd8:
	/* 0x1bd8: jmp    1bdc <trace_exec_binprm+0x1bdc> */
	X86_SIM_X86_JMP(0x1bd8, 0x1bdc, x86_l_1bdc);
x86_l_1bda:
	/* 0x1bda: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bdc:
	/* 0x1bdc: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1be1:
	/* 0x1be1: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1be6:
	/* 0x1be6: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bea:
	/* 0x1bea: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bed:
	/* 0x1bed: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bf0:
	/* 0x1bf0: jns    1c2f <trace_exec_binprm+0x1c2f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bf0, 0x1c2f, x86_l_1c2f);
x86_l_1bf2:
	/* 0x1bf2: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf5:
	/* 0x1bf5: jmp    1c31 <trace_exec_binprm+0x1c31> */
	X86_SIM_X86_JMP(0x1bf5, 0x1c31, x86_l_1c31);
x86_l_1bf7:
	/* 0x1bf7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bfa:
	/* 0x1bfa: jmp    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JMP(0x1bfa, 0x2a7f, x86_l_2a7f);
x86_l_1bff:
	/* 0x1bff: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c04:
	/* 0x1c04: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c08:
	/* 0x1c08: jl     1cfb <trace_exec_binprm+0x1cfb> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c08, 0x1cfb, x86_l_1cfb);
x86_l_1c0e:
	/* 0x1c0e: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c12:
	/* 0x1c12: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c15:
	/* 0x1c15: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1c1b:
	/* 0x1c1b: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1c20:
	/* 0x1c20: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c23:
	/* 0x1c23: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c27:
	/* 0x1c27: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c2a:
	/* 0x1c2a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c2d:
	/* 0x1c2d: js     1bf2 <trace_exec_binprm+0x1bf2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c2d, 0x1bf2, x86_l_1bf2);
x86_l_1c2f:
	/* 0x1c2f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c31:
	/* 0x1c31: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c35:
	/* 0x1c35: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c38:
	/* 0x1c38: jns    1c3f <trace_exec_binprm+0x1c3f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c38, 0x1c3f, x86_l_1c3f);
x86_l_1c3a:
	/* 0x1c3a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c3d:
	/* 0x1c3d: jmp    1c41 <trace_exec_binprm+0x1c41> */
	X86_SIM_X86_JMP(0x1c3d, 0x1c41, x86_l_1c41);
x86_l_1c3f:
	/* 0x1c3f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c41:
	/* 0x1c41: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c44:
	/* 0x1c44: je     1ccf <trace_exec_binprm+0x1ccf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c44, 0x1ccf, x86_l_1ccf);
x86_l_1c4a:
	/* 0x1c4a: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c4d:
	/* 0x1c4d: je     1ccf <trace_exec_binprm+0x1ccf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4d, 0x1ccf, x86_l_1ccf);
x86_l_1c53:
	/* 0x1c53: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c57:
	/* 0x1c57: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c5a:
	/* 0x1c5a: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c60:
	/* 0x1c60: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c63:
	/* 0x1c63: jns    1c6c <trace_exec_binprm+0x1c6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c63, 0x1c6c, x86_l_1c6c);
x86_l_1c65:
	/* 0x1c65: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c68:
	/* 0x1c68: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c6c:
	/* 0x1c6c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c70:
	/* 0x1c70: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c73:
	/* 0x1c73: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c7a:
	/* 0x1c7a: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c7e:
	/* 0x1c7e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c81:
	/* 0x1c81: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c81, 0x2cd0, x86_l_2cd0);
x86_l_1c87:
	/* 0x1c87: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1c8a:
	/* 0x1c8a: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c8a, 0x2c77, x86_l_2c77);
x86_l_1c90:
	/* 0x1c90: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c96:
	/* 0x1c96: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c99:
	/* 0x1c99: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c9c:
	/* 0x1c9c: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c9c, 0x2a7f, x86_l_2a7f);
x86_l_1ca2:
	/* 0x1ca2: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ca6:
	/* 0x1ca6: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ca9:
	/* 0x1ca9: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1cac:
	/* 0x1cac: je     1d58 <trace_exec_binprm+0x1d58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cac, 0x1d58, x86_l_1d58);
x86_l_1cb2:
	/* 0x1cb2: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1cb6:
	/* 0x1cb6: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1cbb:
	/* 0x1cbb: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1cbf:
	/* 0x1cbf: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1cc2:
	/* 0x1cc2: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1cc5:
	/* 0x1cc5: jne    1ca9 <trace_exec_binprm+0x1ca9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cc5, 0x1ca9, x86_l_1ca9);
x86_l_1cc7:
	/* 0x1cc7: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1cca:
	/* 0x1cca: jmp    1d5d <trace_exec_binprm+0x1d5d> */
	X86_SIM_X86_JMP(0x1cca, 0x1d5d, x86_l_1d5d);
x86_l_1ccf:
	/* 0x1ccf: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1cd2:
	/* 0x1cd2: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cd2, 0x2c77, x86_l_2c77);
x86_l_1cd8:
	/* 0x1cd8: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cdd:
	/* 0x1cdd: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_1ce2:
	/* 0x1ce2: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce2, 0x2c77, x86_l_2c77);
x86_l_1ce8:
	/* 0x1ce8: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ced:
	/* 0x1ced: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cf1:
	/* 0x1cf1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cf4:
	/* 0x1cf4: jns    1d11 <trace_exec_binprm+0x1d11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cf4, 0x1d11, x86_l_1d11);
x86_l_1cf6:
	/* 0x1cf6: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf9:
	/* 0x1cf9: jmp    1d13 <trace_exec_binprm+0x1d13> */
	X86_SIM_X86_JMP(0x1cf9, 0x1d13, x86_l_1d13);
x86_l_1cfb:
	/* 0x1cfb: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d00:
	/* 0x1d00: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d05:
	/* 0x1d05: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d09:
	/* 0x1d09: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d0c:
	/* 0x1d0c: jmp    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JMP(0x1d0c, 0x1376, x86_l_1376);
x86_l_1d11:
	/* 0x1d11: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d13:
	/* 0x1d13: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d18:
	/* 0x1d18: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d1b:
	/* 0x1d1b: jns    1d25 <trace_exec_binprm+0x1d25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1b, 0x1d25, x86_l_1d25);
x86_l_1d1d:
	/* 0x1d1d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d20:
	/* 0x1d20: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d23:
	/* 0x1d23: jmp    1d27 <trace_exec_binprm+0x1d27> */
	X86_SIM_X86_JMP(0x1d23, 0x1d27, x86_l_1d27);
x86_l_1d25:
	/* 0x1d25: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d27:
	/* 0x1d27: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d2c:
	/* 0x1d2c: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d31:
	/* 0x1d31: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d34:
	/* 0x1d34: jns    1d3b <trace_exec_binprm+0x1d3b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d34, 0x1d3b, x86_l_1d3b);
x86_l_1d36:
	/* 0x1d36: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d39:
	/* 0x1d39: jmp    1d3d <trace_exec_binprm+0x1d3d> */
	X86_SIM_X86_JMP(0x1d39, 0x1d3d, x86_l_1d3d);
x86_l_1d3b:
	/* 0x1d3b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d3d:
	/* 0x1d3d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d42:
	/* 0x1d42: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d47:
	/* 0x1d47: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d4b:
	/* 0x1d4b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d4e:
	/* 0x1d4e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d51:
	/* 0x1d51: jns    1d88 <trace_exec_binprm+0x1d88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d51, 0x1d88, x86_l_1d88);
x86_l_1d53:
	/* 0x1d53: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d56:
	/* 0x1d56: jmp    1d8a <trace_exec_binprm+0x1d8a> */
	X86_SIM_X86_JMP(0x1d56, 0x1d8a, x86_l_1d8a);
x86_l_1d58:
	/* 0x1d58: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d5d:
	/* 0x1d5d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d61:
	/* 0x1d61: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d61, 0x2c77, x86_l_2c77);
x86_l_1d67:
	/* 0x1d67: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d6b:
	/* 0x1d6b: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d6e:
	/* 0x1d6e: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d74:
	/* 0x1d74: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1d79:
	/* 0x1d79: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d7c:
	/* 0x1d7c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d80:
	/* 0x1d80: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d83:
	/* 0x1d83: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d86:
	/* 0x1d86: js     1d53 <trace_exec_binprm+0x1d53> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d86, 0x1d53, x86_l_1d53);
x86_l_1d88:
	/* 0x1d88: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d8a:
	/* 0x1d8a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d8e:
	/* 0x1d8e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d91:
	/* 0x1d91: jns    1d98 <trace_exec_binprm+0x1d98> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d91, 0x1d98, x86_l_1d98);
x86_l_1d93:
	/* 0x1d93: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d96:
	/* 0x1d96: jmp    1d9a <trace_exec_binprm+0x1d9a> */
	X86_SIM_X86_JMP(0x1d96, 0x1d9a, x86_l_1d9a);
x86_l_1d98:
	/* 0x1d98: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d9a:
	/* 0x1d9a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d9d:
	/* 0x1d9d: je     1e21 <trace_exec_binprm+0x1e21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d9d, 0x1e21, x86_l_1e21);
x86_l_1da3:
	/* 0x1da3: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1da6:
	/* 0x1da6: je     1e21 <trace_exec_binprm+0x1e21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da6, 0x1e21, x86_l_1e21);
x86_l_1da8:
	/* 0x1da8: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dac:
	/* 0x1dac: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1daf:
	/* 0x1daf: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1db5:
	/* 0x1db5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1db8:
	/* 0x1db8: jns    1dc1 <trace_exec_binprm+0x1dc1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1db8, 0x1dc1, x86_l_1dc1);
x86_l_1dba:
	/* 0x1dba: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dbd:
	/* 0x1dbd: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc1:
	/* 0x1dc1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1dc5:
	/* 0x1dc5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1dc8:
	/* 0x1dc8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1dcf:
	/* 0x1dcf: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd3:
	/* 0x1dd3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1dd6:
	/* 0x1dd6: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dd6, 0x2cd0, x86_l_2cd0);
x86_l_1ddc:
	/* 0x1ddc: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1ddf:
	/* 0x1ddf: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ddf, 0x2c7a, x86_l_2c7a);
x86_l_1de5:
	/* 0x1de5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1deb:
	/* 0x1deb: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1dee:
	/* 0x1dee: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1df1:
	/* 0x1df1: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1df1, 0x2a7c, x86_l_2a7c);
x86_l_1df7:
	/* 0x1df7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1dfb:
	/* 0x1dfb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dfe:
	/* 0x1dfe: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1e01:
	/* 0x1e01: je     1e94 <trace_exec_binprm+0x1e94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e01, 0x1e94, x86_l_1e94);
x86_l_1e07:
	/* 0x1e07: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e0b:
	/* 0x1e0b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1e10:
	/* 0x1e10: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1e14:
	/* 0x1e14: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1e17:
	/* 0x1e17: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1e1a:
	/* 0x1e1a: jne    1dfe <trace_exec_binprm+0x1dfe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e1a, 0x1dfe, x86_l_1dfe);
x86_l_1e1c:
	/* 0x1e1c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1e1f:
	/* 0x1e1f: jmp    1e99 <trace_exec_binprm+0x1e99> */
	X86_SIM_X86_JMP(0x1e1f, 0x1e99, x86_l_1e99);
x86_l_1e21:
	/* 0x1e21: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e24:
	/* 0x1e24: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e24, 0x2c7a, x86_l_2c7a);
x86_l_1e2a:
	/* 0x1e2a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e2f:
	/* 0x1e2f: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_1e34:
	/* 0x1e34: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e34, 0x2c7a, x86_l_2c7a);
x86_l_1e3a:
	/* 0x1e3a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e3f:
	/* 0x1e3f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e43:
	/* 0x1e43: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e46:
	/* 0x1e46: jns    1e4d <trace_exec_binprm+0x1e4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e46, 0x1e4d, x86_l_1e4d);
x86_l_1e48:
	/* 0x1e48: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e4b:
	/* 0x1e4b: jmp    1e4f <trace_exec_binprm+0x1e4f> */
	X86_SIM_X86_JMP(0x1e4b, 0x1e4f, x86_l_1e4f);
x86_l_1e4d:
	/* 0x1e4d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e4f:
	/* 0x1e4f: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e54:
	/* 0x1e54: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e57:
	/* 0x1e57: jns    1e61 <trace_exec_binprm+0x1e61> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e57, 0x1e61, x86_l_1e61);
x86_l_1e59:
	/* 0x1e59: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e5c:
	/* 0x1e5c: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e5f:
	/* 0x1e5f: jmp    1e63 <trace_exec_binprm+0x1e63> */
	X86_SIM_X86_JMP(0x1e5f, 0x1e63, x86_l_1e63);
x86_l_1e61:
	/* 0x1e61: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e63:
	/* 0x1e63: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e68:
	/* 0x1e68: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e6d:
	/* 0x1e6d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e70:
	/* 0x1e70: jns    1e77 <trace_exec_binprm+0x1e77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e70, 0x1e77, x86_l_1e77);
x86_l_1e72:
	/* 0x1e72: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e75:
	/* 0x1e75: jmp    1e79 <trace_exec_binprm+0x1e79> */
	X86_SIM_X86_JMP(0x1e75, 0x1e79, x86_l_1e79);
x86_l_1e77:
	/* 0x1e77: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e79:
	/* 0x1e79: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e7e:
	/* 0x1e7e: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e83:
	/* 0x1e83: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e87:
	/* 0x1e87: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e8a:
	/* 0x1e8a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e8d:
	/* 0x1e8d: jns    1ec4 <trace_exec_binprm+0x1ec4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e8d, 0x1ec4, x86_l_1ec4);
x86_l_1e8f:
	/* 0x1e8f: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e92:
	/* 0x1e92: jmp    1ec6 <trace_exec_binprm+0x1ec6> */
	X86_SIM_X86_JMP(0x1e92, 0x1ec6, x86_l_1ec6);
x86_l_1e94:
	/* 0x1e94: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e99:
	/* 0x1e99: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e9d:
	/* 0x1e9d: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e9d, 0x2c7a, x86_l_2c7a);
x86_l_1ea3:
	/* 0x1ea3: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ea7:
	/* 0x1ea7: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eaa:
	/* 0x1eaa: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1eb0:
	/* 0x1eb0: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1eb5:
	/* 0x1eb5: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1eb8:
	/* 0x1eb8: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ebc:
	/* 0x1ebc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ebf:
	/* 0x1ebf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ec2:
	/* 0x1ec2: js     1e8f <trace_exec_binprm+0x1e8f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ec2, 0x1e8f, x86_l_1e8f);
x86_l_1ec4:
	/* 0x1ec4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec6:
	/* 0x1ec6: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eca:
	/* 0x1eca: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ecd:
	/* 0x1ecd: jns    1ed4 <trace_exec_binprm+0x1ed4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ecd, 0x1ed4, x86_l_1ed4);
x86_l_1ecf:
	/* 0x1ecf: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed2:
	/* 0x1ed2: jmp    1ed6 <trace_exec_binprm+0x1ed6> */
	X86_SIM_X86_JMP(0x1ed2, 0x1ed6, x86_l_1ed6);
x86_l_1ed4:
	/* 0x1ed4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ed6:
	/* 0x1ed6: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ed9:
	/* 0x1ed9: je     1f5d <trace_exec_binprm+0x1f5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed9, 0x1f5d, x86_l_1f5d);
x86_l_1edf:
	/* 0x1edf: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ee2:
	/* 0x1ee2: je     1f5d <trace_exec_binprm+0x1f5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee2, 0x1f5d, x86_l_1f5d);
x86_l_1ee4:
	/* 0x1ee4: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ee8:
	/* 0x1ee8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1eeb:
	/* 0x1eeb: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ef1:
	/* 0x1ef1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ef4:
	/* 0x1ef4: jns    1efd <trace_exec_binprm+0x1efd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ef4, 0x1efd, x86_l_1efd);
x86_l_1ef6:
	/* 0x1ef6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ef9:
	/* 0x1ef9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1efd:
	/* 0x1efd: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f01:
	/* 0x1f01: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f04:
	/* 0x1f04: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f0b:
	/* 0x1f0b: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f0f:
	/* 0x1f0f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f12:
	/* 0x1f12: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f12, 0x2cd0, x86_l_2cd0);
x86_l_1f18:
	/* 0x1f18: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1f1b:
	/* 0x1f1b: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1b, 0x2c77, x86_l_2c77);
x86_l_1f21:
	/* 0x1f21: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f27:
	/* 0x1f27: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f2a:
	/* 0x1f2a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1f2d:
	/* 0x1f2d: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f2d, 0x2a7f, x86_l_2a7f);
x86_l_1f33:
	/* 0x1f33: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f37:
	/* 0x1f37: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f3a:
	/* 0x1f3a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1f3d:
	/* 0x1f3d: je     1fd0 <trace_exec_binprm+0x1fd0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f3d, 0x1fd0, x86_l_1fd0);
x86_l_1f43:
	/* 0x1f43: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f47:
	/* 0x1f47: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f4c:
	/* 0x1f4c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f50:
	/* 0x1f50: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f53:
	/* 0x1f53: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1f56:
	/* 0x1f56: jne    1f3a <trace_exec_binprm+0x1f3a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f56, 0x1f3a, x86_l_1f3a);
x86_l_1f58:
	/* 0x1f58: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1f5b:
	/* 0x1f5b: jmp    1fd5 <trace_exec_binprm+0x1fd5> */
	X86_SIM_X86_JMP(0x1f5b, 0x1fd5, x86_l_1fd5);
x86_l_1f5d:
	/* 0x1f5d: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f60:
	/* 0x1f60: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f60, 0x2c77, x86_l_2c77);
x86_l_1f66:
	/* 0x1f66: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f6b:
	/* 0x1f6b: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_1f70:
	/* 0x1f70: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f70, 0x2c77, x86_l_2c77);
x86_l_1f76:
	/* 0x1f76: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f7b:
	/* 0x1f7b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f7f:
	/* 0x1f7f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f82:
	/* 0x1f82: jns    1f89 <trace_exec_binprm+0x1f89> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f82, 0x1f89, x86_l_1f89);
x86_l_1f84:
	/* 0x1f84: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f87:
	/* 0x1f87: jmp    1f8b <trace_exec_binprm+0x1f8b> */
	X86_SIM_X86_JMP(0x1f87, 0x1f8b, x86_l_1f8b);
x86_l_1f89:
	/* 0x1f89: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8b:
	/* 0x1f8b: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f90:
	/* 0x1f90: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f93:
	/* 0x1f93: jns    1f9d <trace_exec_binprm+0x1f9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f93, 0x1f9d, x86_l_1f9d);
x86_l_1f95:
	/* 0x1f95: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f98:
	/* 0x1f98: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f9b:
	/* 0x1f9b: jmp    1f9f <trace_exec_binprm+0x1f9f> */
	X86_SIM_X86_JMP(0x1f9b, 0x1f9f, x86_l_1f9f);
x86_l_1f9d:
	/* 0x1f9d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f9f:
	/* 0x1f9f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fa4:
	/* 0x1fa4: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fa9:
	/* 0x1fa9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fac:
	/* 0x1fac: jns    1fb3 <trace_exec_binprm+0x1fb3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fac, 0x1fb3, x86_l_1fb3);
x86_l_1fae:
	/* 0x1fae: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb1:
	/* 0x1fb1: jmp    1fb5 <trace_exec_binprm+0x1fb5> */
	X86_SIM_X86_JMP(0x1fb1, 0x1fb5, x86_l_1fb5);
x86_l_1fb3:
	/* 0x1fb3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fb5:
	/* 0x1fb5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1fba:
	/* 0x1fba: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fbf:
	/* 0x1fbf: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fc3:
	/* 0x1fc3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fc6:
	/* 0x1fc6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fc9:
	/* 0x1fc9: jns    2000 <trace_exec_binprm+0x2000> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc9, 0x2000, x86_l_2000);
x86_l_1fcb:
	/* 0x1fcb: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fce:
	/* 0x1fce: jmp    2002 <trace_exec_binprm+0x2002> */
	X86_SIM_X86_JMP(0x1fce, 0x2002, x86_l_2002);
x86_l_1fd0:
	/* 0x1fd0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1fd5:
	/* 0x1fd5: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1fd9:
	/* 0x1fd9: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1fd9, 0x2c77, x86_l_2c77);
x86_l_1fdf:
	/* 0x1fdf: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe3:
	/* 0x1fe3: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fe6:
	/* 0x1fe6: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1fec:
	/* 0x1fec: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1ff1:
	/* 0x1ff1: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ff4:
	/* 0x1ff4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff8:
	/* 0x1ff8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ffb:
	/* 0x1ffb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ffe:
	/* 0x1ffe: js     1fcb <trace_exec_binprm+0x1fcb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ffe, 0x1fcb, x86_l_1fcb);
x86_l_2000:
	/* 0x2000: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2002:
	/* 0x2002: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2006:
	/* 0x2006: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2009:
	/* 0x2009: jns    2010 <trace_exec_binprm+0x2010> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2009, 0x2010, x86_l_2010);
x86_l_200b:
	/* 0x200b: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_200e:
	/* 0x200e: jmp    2012 <trace_exec_binprm+0x2012> */
	X86_SIM_X86_JMP(0x200e, 0x2012, x86_l_2012);
x86_l_2010:
	/* 0x2010: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2012:
	/* 0x2012: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2015:
	/* 0x2015: je     2099 <trace_exec_binprm+0x2099> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2015, 0x2099, x86_l_2099);
x86_l_201b:
	/* 0x201b: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_201e:
	/* 0x201e: je     2099 <trace_exec_binprm+0x2099> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201e, 0x2099, x86_l_2099);
x86_l_2020:
	/* 0x2020: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2024:
	/* 0x2024: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2027:
	/* 0x2027: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_202d:
	/* 0x202d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2030:
	/* 0x2030: jns    2039 <trace_exec_binprm+0x2039> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2030, 0x2039, x86_l_2039);
x86_l_2032:
	/* 0x2032: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2035:
	/* 0x2035: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2039:
	/* 0x2039: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_203d:
	/* 0x203d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2040:
	/* 0x2040: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2047:
	/* 0x2047: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_204b:
	/* 0x204b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_204e:
	/* 0x204e: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x204e, 0x2cd0, x86_l_2cd0);
x86_l_2054:
	/* 0x2054: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2057:
	/* 0x2057: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2057, 0x2c7a, x86_l_2c7a);
x86_l_205d:
	/* 0x205d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2063:
	/* 0x2063: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2066:
	/* 0x2066: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2069:
	/* 0x2069: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2069, 0x2a7c, x86_l_2a7c);
x86_l_206f:
	/* 0x206f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2073:
	/* 0x2073: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2076:
	/* 0x2076: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2079:
	/* 0x2079: je     210c <trace_exec_binprm+0x210c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2079, 0x210c, x86_l_210c);
x86_l_207f:
	/* 0x207f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2083:
	/* 0x2083: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2088:
	/* 0x2088: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_208c:
	/* 0x208c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_208f:
	/* 0x208f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2092:
	/* 0x2092: jne    2076 <trace_exec_binprm+0x2076> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2092, 0x2076, x86_l_2076);
x86_l_2094:
	/* 0x2094: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2097:
	/* 0x2097: jmp    2111 <trace_exec_binprm+0x2111> */
	X86_SIM_X86_JMP(0x2097, 0x2111, x86_l_2111);
x86_l_2099:
	/* 0x2099: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_209c:
	/* 0x209c: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x209c, 0x2c7a, x86_l_2c7a);
x86_l_20a2:
	/* 0x20a2: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20a7:
	/* 0x20a7: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_20ac:
	/* 0x20ac: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ac, 0x2c7a, x86_l_2c7a);
x86_l_20b2:
	/* 0x20b2: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20b7:
	/* 0x20b7: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20bb:
	/* 0x20bb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20be:
	/* 0x20be: jns    20c5 <trace_exec_binprm+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20be, 0x20c5, x86_l_20c5);
x86_l_20c0:
	/* 0x20c0: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c3:
	/* 0x20c3: jmp    20c7 <trace_exec_binprm+0x20c7> */
	X86_SIM_X86_JMP(0x20c3, 0x20c7, x86_l_20c7);
x86_l_20c5:
	/* 0x20c5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20c7:
	/* 0x20c7: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20cc:
	/* 0x20cc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20cf:
	/* 0x20cf: jns    20d9 <trace_exec_binprm+0x20d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20cf, 0x20d9, x86_l_20d9);
x86_l_20d1:
	/* 0x20d1: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20d4:
	/* 0x20d4: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20d7:
	/* 0x20d7: jmp    20db <trace_exec_binprm+0x20db> */
	X86_SIM_X86_JMP(0x20d7, 0x20db, x86_l_20db);
x86_l_20d9:
	/* 0x20d9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20db:
	/* 0x20db: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20e0:
	/* 0x20e0: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20e5:
	/* 0x20e5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20e8:
	/* 0x20e8: jns    20ef <trace_exec_binprm+0x20ef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20e8, 0x20ef, x86_l_20ef);
x86_l_20ea:
	/* 0x20ea: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20ed:
	/* 0x20ed: jmp    20f1 <trace_exec_binprm+0x20f1> */
	X86_SIM_X86_JMP(0x20ed, 0x20f1, x86_l_20f1);
x86_l_20ef:
	/* 0x20ef: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20f1:
	/* 0x20f1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20f6:
	/* 0x20f6: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20fb:
	/* 0x20fb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20ff:
	/* 0x20ff: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2102:
	/* 0x2102: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2105:
	/* 0x2105: jns    213c <trace_exec_binprm+0x213c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2105, 0x213c, x86_l_213c);
x86_l_2107:
	/* 0x2107: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_210a:
	/* 0x210a: jmp    213e <trace_exec_binprm+0x213e> */
	X86_SIM_X86_JMP(0x210a, 0x213e, x86_l_213e);
x86_l_210c:
	/* 0x210c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2111:
	/* 0x2111: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2115:
	/* 0x2115: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2115, 0x2c7a, x86_l_2c7a);
x86_l_211b:
	/* 0x211b: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_211f:
	/* 0x211f: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2122:
	/* 0x2122: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2128:
	/* 0x2128: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_212d:
	/* 0x212d: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2130:
	/* 0x2130: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2134:
	/* 0x2134: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2137:
	/* 0x2137: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_213a:
	/* 0x213a: js     2107 <trace_exec_binprm+0x2107> */
	X86_SIM_X86_JCC(X86_CC_S, 0x213a, 0x2107, x86_l_2107);
x86_l_213c:
	/* 0x213c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_213e:
	/* 0x213e: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2142:
	/* 0x2142: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2145:
	/* 0x2145: jns    214c <trace_exec_binprm+0x214c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2145, 0x214c, x86_l_214c);
x86_l_2147:
	/* 0x2147: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_214a:
	/* 0x214a: jmp    214e <trace_exec_binprm+0x214e> */
	X86_SIM_X86_JMP(0x214a, 0x214e, x86_l_214e);
x86_l_214c:
	/* 0x214c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214e:
	/* 0x214e: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2151:
	/* 0x2151: je     21d5 <trace_exec_binprm+0x21d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2151, 0x21d5, x86_l_21d5);
x86_l_2157:
	/* 0x2157: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_215a:
	/* 0x215a: je     21d5 <trace_exec_binprm+0x21d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215a, 0x21d5, x86_l_21d5);
x86_l_215c:
	/* 0x215c: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2160:
	/* 0x2160: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2163:
	/* 0x2163: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2169:
	/* 0x2169: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_216c:
	/* 0x216c: jns    2175 <trace_exec_binprm+0x2175> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x216c, 0x2175, x86_l_2175);
x86_l_216e:
	/* 0x216e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2171:
	/* 0x2171: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2175:
	/* 0x2175: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2179:
	/* 0x2179: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_217c:
	/* 0x217c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2183:
	/* 0x2183: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2187:
	/* 0x2187: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_218a:
	/* 0x218a: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x218a, 0x2cd0, x86_l_2cd0);
x86_l_2190:
	/* 0x2190: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2193:
	/* 0x2193: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2193, 0x2c77, x86_l_2c77);
x86_l_2199:
	/* 0x2199: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_219f:
	/* 0x219f: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_21a2:
	/* 0x21a2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_21a5:
	/* 0x21a5: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21a5, 0x2a7f, x86_l_2a7f);
x86_l_21ab:
	/* 0x21ab: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21af:
	/* 0x21af: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b2:
	/* 0x21b2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_21b5:
	/* 0x21b5: je     2248 <trace_exec_binprm+0x2248> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b5, 0x2248, x86_l_2248);
x86_l_21bb:
	/* 0x21bb: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_21bf:
	/* 0x21bf: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_21c4:
	/* 0x21c4: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_21c8:
	/* 0x21c8: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_21cb:
	/* 0x21cb: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_21ce:
	/* 0x21ce: jne    21b2 <trace_exec_binprm+0x21b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21ce, 0x21b2, x86_l_21b2);
x86_l_21d0:
	/* 0x21d0: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_21d3:
	/* 0x21d3: jmp    224d <trace_exec_binprm+0x224d> */
	X86_SIM_X86_JMP(0x21d3, 0x224d, x86_l_224d);
x86_l_21d5:
	/* 0x21d5: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21d8:
	/* 0x21d8: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21d8, 0x2c77, x86_l_2c77);
x86_l_21de:
	/* 0x21de: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21e3:
	/* 0x21e3: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_21e8:
	/* 0x21e8: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e8, 0x2c77, x86_l_2c77);
x86_l_21ee:
	/* 0x21ee: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21f3:
	/* 0x21f3: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21f7:
	/* 0x21f7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21fa:
	/* 0x21fa: jns    2201 <trace_exec_binprm+0x2201> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21fa, 0x2201, x86_l_2201);
x86_l_21fc:
	/* 0x21fc: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21ff:
	/* 0x21ff: jmp    2203 <trace_exec_binprm+0x2203> */
	X86_SIM_X86_JMP(0x21ff, 0x2203, x86_l_2203);
x86_l_2201:
	/* 0x2201: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2203:
	/* 0x2203: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2208:
	/* 0x2208: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_220b:
	/* 0x220b: jns    2215 <trace_exec_binprm+0x2215> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x220b, 0x2215, x86_l_2215);
x86_l_220d:
	/* 0x220d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2210:
	/* 0x2210: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2213:
	/* 0x2213: jmp    2217 <trace_exec_binprm+0x2217> */
	X86_SIM_X86_JMP(0x2213, 0x2217, x86_l_2217);
x86_l_2215:
	/* 0x2215: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2217:
	/* 0x2217: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_221c:
	/* 0x221c: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2221:
	/* 0x2221: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2224:
	/* 0x2224: jns    222b <trace_exec_binprm+0x222b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2224, 0x222b, x86_l_222b);
x86_l_2226:
	/* 0x2226: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2229:
	/* 0x2229: jmp    222d <trace_exec_binprm+0x222d> */
	X86_SIM_X86_JMP(0x2229, 0x222d, x86_l_222d);
x86_l_222b:
	/* 0x222b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_222d:
	/* 0x222d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2232:
	/* 0x2232: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2237:
	/* 0x2237: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_223b:
	/* 0x223b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_223e:
	/* 0x223e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2241:
	/* 0x2241: jns    2278 <trace_exec_binprm+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2241, 0x2278, x86_l_2278);
x86_l_2243:
	/* 0x2243: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2246:
	/* 0x2246: jmp    227a <trace_exec_binprm+0x227a> */
	X86_SIM_X86_JMP(0x2246, 0x227a, x86_l_227a);
x86_l_2248:
	/* 0x2248: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_224d:
	/* 0x224d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2251:
	/* 0x2251: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2251, 0x2c77, x86_l_2c77);
x86_l_2257:
	/* 0x2257: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225b:
	/* 0x225b: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_225e:
	/* 0x225e: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2264:
	/* 0x2264: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2269:
	/* 0x2269: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_226c:
	/* 0x226c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2270:
	/* 0x2270: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2273:
	/* 0x2273: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2276:
	/* 0x2276: js     2243 <trace_exec_binprm+0x2243> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2276, 0x2243, x86_l_2243);
x86_l_2278:
	/* 0x2278: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_227a:
	/* 0x227a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_227e:
	/* 0x227e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2281:
	/* 0x2281: jns    2288 <trace_exec_binprm+0x2288> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2281, 0x2288, x86_l_2288);
x86_l_2283:
	/* 0x2283: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2286:
	/* 0x2286: jmp    228a <trace_exec_binprm+0x228a> */
	X86_SIM_X86_JMP(0x2286, 0x228a, x86_l_228a);
x86_l_2288:
	/* 0x2288: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_228a:
	/* 0x228a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_228d:
	/* 0x228d: je     2311 <trace_exec_binprm+0x2311> */
	X86_SIM_X86_JCC(X86_CC_E, 0x228d, 0x2311, x86_l_2311);
x86_l_2293:
	/* 0x2293: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2296:
	/* 0x2296: je     2311 <trace_exec_binprm+0x2311> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2296, 0x2311, x86_l_2311);
x86_l_2298:
	/* 0x2298: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_229c:
	/* 0x229c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_229f:
	/* 0x229f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_22a5:
	/* 0x22a5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22a8:
	/* 0x22a8: jns    22b1 <trace_exec_binprm+0x22b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a8, 0x22b1, x86_l_22b1);
x86_l_22aa:
	/* 0x22aa: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ad:
	/* 0x22ad: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22b1:
	/* 0x22b1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22b5:
	/* 0x22b5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22b8:
	/* 0x22b8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22bf:
	/* 0x22bf: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22c3:
	/* 0x22c3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22c6:
	/* 0x22c6: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22c6, 0x2cd0, x86_l_2cd0);
x86_l_22cc:
	/* 0x22cc: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_22cf:
	/* 0x22cf: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22cf, 0x2c7a, x86_l_2c7a);
x86_l_22d5:
	/* 0x22d5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_22db:
	/* 0x22db: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_22de:
	/* 0x22de: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_22e1:
	/* 0x22e1: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e1, 0x2a7c, x86_l_2a7c);
x86_l_22e7:
	/* 0x22e7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_22eb:
	/* 0x22eb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ee:
	/* 0x22ee: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_22f1:
	/* 0x22f1: je     2384 <trace_exec_binprm+0x2384> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22f1, 0x2384, x86_l_2384);
x86_l_22f7:
	/* 0x22f7: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_22fb:
	/* 0x22fb: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2300:
	/* 0x2300: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2304:
	/* 0x2304: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2307:
	/* 0x2307: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_230a:
	/* 0x230a: jne    22ee <trace_exec_binprm+0x22ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x230a, 0x22ee, x86_l_22ee);
x86_l_230c:
	/* 0x230c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_230f:
	/* 0x230f: jmp    2389 <trace_exec_binprm+0x2389> */
	X86_SIM_X86_JMP(0x230f, 0x2389, x86_l_2389);
x86_l_2311:
	/* 0x2311: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2314:
	/* 0x2314: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2314, 0x2c7a, x86_l_2c7a);
x86_l_231a:
	/* 0x231a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_231f:
	/* 0x231f: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2324:
	/* 0x2324: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2324, 0x2c7a, x86_l_2c7a);
x86_l_232a:
	/* 0x232a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_232f:
	/* 0x232f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2333:
	/* 0x2333: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2336:
	/* 0x2336: jns    233d <trace_exec_binprm+0x233d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2336, 0x233d, x86_l_233d);
x86_l_2338:
	/* 0x2338: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_233b:
	/* 0x233b: jmp    233f <trace_exec_binprm+0x233f> */
	X86_SIM_X86_JMP(0x233b, 0x233f, x86_l_233f);
x86_l_233d:
	/* 0x233d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_233f:
	/* 0x233f: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2344:
	/* 0x2344: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2347:
	/* 0x2347: jns    2351 <trace_exec_binprm+0x2351> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2347, 0x2351, x86_l_2351);
x86_l_2349:
	/* 0x2349: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_234c:
	/* 0x234c: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_234f:
	/* 0x234f: jmp    2353 <trace_exec_binprm+0x2353> */
	X86_SIM_X86_JMP(0x234f, 0x2353, x86_l_2353);
x86_l_2351:
	/* 0x2351: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2353:
	/* 0x2353: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2358:
	/* 0x2358: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_235d:
	/* 0x235d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2360:
	/* 0x2360: jns    2367 <trace_exec_binprm+0x2367> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2360, 0x2367, x86_l_2367);
x86_l_2362:
	/* 0x2362: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2365:
	/* 0x2365: jmp    2369 <trace_exec_binprm+0x2369> */
	X86_SIM_X86_JMP(0x2365, 0x2369, x86_l_2369);
x86_l_2367:
	/* 0x2367: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2369:
	/* 0x2369: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_236e:
	/* 0x236e: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2373:
	/* 0x2373: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2377:
	/* 0x2377: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_237a:
	/* 0x237a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_237d:
	/* 0x237d: jns    23b4 <trace_exec_binprm+0x23b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x237d, 0x23b4, x86_l_23b4);
x86_l_237f:
	/* 0x237f: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2382:
	/* 0x2382: jmp    23b6 <trace_exec_binprm+0x23b6> */
	X86_SIM_X86_JMP(0x2382, 0x23b6, x86_l_23b6);
x86_l_2384:
	/* 0x2384: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2389:
	/* 0x2389: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_238d:
	/* 0x238d: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x238d, 0x2c7a, x86_l_2c7a);
x86_l_2393:
	/* 0x2393: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2397:
	/* 0x2397: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_239a:
	/* 0x239a: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23a0:
	/* 0x23a0: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_23a5:
	/* 0x23a5: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23a8:
	/* 0x23a8: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ac:
	/* 0x23ac: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23af:
	/* 0x23af: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23b2:
	/* 0x23b2: js     237f <trace_exec_binprm+0x237f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23b2, 0x237f, x86_l_237f);
x86_l_23b4:
	/* 0x23b4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b6:
	/* 0x23b6: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23ba:
	/* 0x23ba: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23bd:
	/* 0x23bd: jns    23c4 <trace_exec_binprm+0x23c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23bd, 0x23c4, x86_l_23c4);
x86_l_23bf:
	/* 0x23bf: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23c2:
	/* 0x23c2: jmp    23c6 <trace_exec_binprm+0x23c6> */
	X86_SIM_X86_JMP(0x23c2, 0x23c6, x86_l_23c6);
x86_l_23c4:
	/* 0x23c4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c6:
	/* 0x23c6: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23c9:
	/* 0x23c9: je     244d <trace_exec_binprm+0x244d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23c9, 0x244d, x86_l_244d);
x86_l_23cf:
	/* 0x23cf: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23d2:
	/* 0x23d2: je     244d <trace_exec_binprm+0x244d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23d2, 0x244d, x86_l_244d);
x86_l_23d4:
	/* 0x23d4: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d8:
	/* 0x23d8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23db:
	/* 0x23db: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_23e1:
	/* 0x23e1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23e4:
	/* 0x23e4: jns    23ed <trace_exec_binprm+0x23ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23e4, 0x23ed, x86_l_23ed);
x86_l_23e6:
	/* 0x23e6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e9:
	/* 0x23e9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23ed:
	/* 0x23ed: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_23f1:
	/* 0x23f1: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23f4:
	/* 0x23f4: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_23fb:
	/* 0x23fb: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ff:
	/* 0x23ff: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2402:
	/* 0x2402: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2402, 0x2cd0, x86_l_2cd0);
x86_l_2408:
	/* 0x2408: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_240b:
	/* 0x240b: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x240b, 0x2c77, x86_l_2c77);
x86_l_2411:
	/* 0x2411: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2417:
	/* 0x2417: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_241a:
	/* 0x241a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_241d:
	/* 0x241d: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x241d, 0x2a7f, x86_l_2a7f);
x86_l_2423:
	/* 0x2423: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2427:
	/* 0x2427: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_242a:
	/* 0x242a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_242d:
	/* 0x242d: je     24c0 <trace_exec_binprm+0x24c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x242d, 0x24c0, x86_l_24c0);
x86_l_2433:
	/* 0x2433: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2437:
	/* 0x2437: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_243c:
	/* 0x243c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2440:
	/* 0x2440: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2443:
	/* 0x2443: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2446:
	/* 0x2446: jne    242a <trace_exec_binprm+0x242a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2446, 0x242a, x86_l_242a);
x86_l_2448:
	/* 0x2448: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_244b:
	/* 0x244b: jmp    24c5 <trace_exec_binprm+0x24c5> */
	X86_SIM_X86_JMP(0x244b, 0x24c5, x86_l_24c5);
x86_l_244d:
	/* 0x244d: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2450:
	/* 0x2450: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2450, 0x2c77, x86_l_2c77);
x86_l_2456:
	/* 0x2456: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_245b:
	/* 0x245b: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2460:
	/* 0x2460: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2460, 0x2c77, x86_l_2c77);
x86_l_2466:
	/* 0x2466: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_246b:
	/* 0x246b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_246f:
	/* 0x246f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2472:
	/* 0x2472: jns    2479 <trace_exec_binprm+0x2479> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2472, 0x2479, x86_l_2479);
x86_l_2474:
	/* 0x2474: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2477:
	/* 0x2477: jmp    247b <trace_exec_binprm+0x247b> */
	X86_SIM_X86_JMP(0x2477, 0x247b, x86_l_247b);
x86_l_2479:
	/* 0x2479: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_247b:
	/* 0x247b: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2480:
	/* 0x2480: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2483:
	/* 0x2483: jns    248d <trace_exec_binprm+0x248d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2483, 0x248d, x86_l_248d);
x86_l_2485:
	/* 0x2485: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2488:
	/* 0x2488: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248b:
	/* 0x248b: jmp    248f <trace_exec_binprm+0x248f> */
	X86_SIM_X86_JMP(0x248b, 0x248f, x86_l_248f);
x86_l_248d:
	/* 0x248d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_248f:
	/* 0x248f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2494:
	/* 0x2494: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2499:
	/* 0x2499: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_249c:
	/* 0x249c: jns    24a3 <trace_exec_binprm+0x24a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x249c, 0x24a3, x86_l_24a3);
x86_l_249e:
	/* 0x249e: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24a1:
	/* 0x24a1: jmp    24a5 <trace_exec_binprm+0x24a5> */
	X86_SIM_X86_JMP(0x24a1, 0x24a5, x86_l_24a5);
x86_l_24a3:
	/* 0x24a3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24a5:
	/* 0x24a5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24aa:
	/* 0x24aa: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24af:
	/* 0x24af: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24b3:
	/* 0x24b3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24b6:
	/* 0x24b6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24b9:
	/* 0x24b9: jns    24f0 <trace_exec_binprm+0x24f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24b9, 0x24f0, x86_l_24f0);
x86_l_24bb:
	/* 0x24bb: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24be:
	/* 0x24be: jmp    24f2 <trace_exec_binprm+0x24f2> */
	X86_SIM_X86_JMP(0x24be, 0x24f2, x86_l_24f2);
x86_l_24c0:
	/* 0x24c0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_24c5:
	/* 0x24c5: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24c9:
	/* 0x24c9: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x24c9, 0x2c77, x86_l_2c77);
x86_l_24cf:
	/* 0x24cf: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d3:
	/* 0x24d3: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24d6:
	/* 0x24d6: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_24dc:
	/* 0x24dc: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_24e1:
	/* 0x24e1: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24e4:
	/* 0x24e4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e8:
	/* 0x24e8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24eb:
	/* 0x24eb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24ee:
	/* 0x24ee: js     24bb <trace_exec_binprm+0x24bb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24ee, 0x24bb, x86_l_24bb);
x86_l_24f0:
	/* 0x24f0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f2:
	/* 0x24f2: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24f6:
	/* 0x24f6: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24f9:
	/* 0x24f9: jns    2500 <trace_exec_binprm+0x2500> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f9, 0x2500, x86_l_2500);
x86_l_24fb:
	/* 0x24fb: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fe:
	/* 0x24fe: jmp    2502 <trace_exec_binprm+0x2502> */
	X86_SIM_X86_JMP(0x24fe, 0x2502, x86_l_2502);
x86_l_2500:
	/* 0x2500: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2502:
	/* 0x2502: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2505:
	/* 0x2505: je     2589 <trace_exec_binprm+0x2589> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2505, 0x2589, x86_l_2589);
x86_l_250b:
	/* 0x250b: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_250e:
	/* 0x250e: je     2589 <trace_exec_binprm+0x2589> */
	X86_SIM_X86_JCC(X86_CC_E, 0x250e, 0x2589, x86_l_2589);
x86_l_2510:
	/* 0x2510: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2514:
	/* 0x2514: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2517:
	/* 0x2517: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_251d:
	/* 0x251d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2520:
	/* 0x2520: jns    2529 <trace_exec_binprm+0x2529> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2520, 0x2529, x86_l_2529);
x86_l_2522:
	/* 0x2522: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2525:
	/* 0x2525: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2529:
	/* 0x2529: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_252d:
	/* 0x252d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2530:
	/* 0x2530: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2537:
	/* 0x2537: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_253b:
	/* 0x253b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_253e:
	/* 0x253e: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x253e, 0x2cd0, x86_l_2cd0);
x86_l_2544:
	/* 0x2544: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2547:
	/* 0x2547: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2547, 0x2c7a, x86_l_2c7a);
x86_l_254d:
	/* 0x254d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2553:
	/* 0x2553: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2556:
	/* 0x2556: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2559:
	/* 0x2559: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2559, 0x2a7c, x86_l_2a7c);
x86_l_255f:
	/* 0x255f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2563:
	/* 0x2563: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2566:
	/* 0x2566: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2569:
	/* 0x2569: je     25fc <trace_exec_binprm+0x25fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2569, 0x25fc, x86_l_25fc);
x86_l_256f:
	/* 0x256f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2573:
	/* 0x2573: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2578:
	/* 0x2578: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_257c:
	/* 0x257c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_257f:
	/* 0x257f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2582:
	/* 0x2582: jne    2566 <trace_exec_binprm+0x2566> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2582, 0x2566, x86_l_2566);
x86_l_2584:
	/* 0x2584: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2587:
	/* 0x2587: jmp    2601 <trace_exec_binprm+0x2601> */
	X86_SIM_X86_JMP(0x2587, 0x2601, x86_l_2601);
x86_l_2589:
	/* 0x2589: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_258c:
	/* 0x258c: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x258c, 0x2c7a, x86_l_2c7a);
x86_l_2592:
	/* 0x2592: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2597:
	/* 0x2597: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_259c:
	/* 0x259c: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x2c7a, x86_l_2c7a);
x86_l_25a2:
	/* 0x25a2: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25a7:
	/* 0x25a7: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25ab:
	/* 0x25ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25ae:
	/* 0x25ae: jns    25b5 <trace_exec_binprm+0x25b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ae, 0x25b5, x86_l_25b5);
x86_l_25b0:
	/* 0x25b0: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b3:
	/* 0x25b3: jmp    25b7 <trace_exec_binprm+0x25b7> */
	X86_SIM_X86_JMP(0x25b3, 0x25b7, x86_l_25b7);
x86_l_25b5:
	/* 0x25b5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b7:
	/* 0x25b7: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25bc:
	/* 0x25bc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25bf:
	/* 0x25bf: jns    25c9 <trace_exec_binprm+0x25c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25bf, 0x25c9, x86_l_25c9);
x86_l_25c1:
	/* 0x25c1: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25c4:
	/* 0x25c4: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25c7:
	/* 0x25c7: jmp    25cb <trace_exec_binprm+0x25cb> */
	X86_SIM_X86_JMP(0x25c7, 0x25cb, x86_l_25cb);
x86_l_25c9:
	/* 0x25c9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25cb:
	/* 0x25cb: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25d0:
	/* 0x25d0: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25d5:
	/* 0x25d5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25d8:
	/* 0x25d8: jns    25df <trace_exec_binprm+0x25df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25d8, 0x25df, x86_l_25df);
x86_l_25da:
	/* 0x25da: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25dd:
	/* 0x25dd: jmp    25e1 <trace_exec_binprm+0x25e1> */
	X86_SIM_X86_JMP(0x25dd, 0x25e1, x86_l_25e1);
x86_l_25df:
	/* 0x25df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25e1:
	/* 0x25e1: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25e6:
	/* 0x25e6: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25eb:
	/* 0x25eb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25ef:
	/* 0x25ef: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25f2:
	/* 0x25f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25f5:
	/* 0x25f5: jns    262c <trace_exec_binprm+0x262c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25f5, 0x262c, x86_l_262c);
x86_l_25f7:
	/* 0x25f7: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25fa:
	/* 0x25fa: jmp    262e <trace_exec_binprm+0x262e> */
	X86_SIM_X86_JMP(0x25fa, 0x262e, x86_l_262e);
x86_l_25fc:
	/* 0x25fc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2601:
	/* 0x2601: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2605:
	/* 0x2605: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2605, 0x2c7a, x86_l_2c7a);
x86_l_260b:
	/* 0x260b: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260f:
	/* 0x260f: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2612:
	/* 0x2612: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2618:
	/* 0x2618: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_261d:
	/* 0x261d: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2620:
	/* 0x2620: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2624:
	/* 0x2624: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2627:
	/* 0x2627: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_262a:
	/* 0x262a: js     25f7 <trace_exec_binprm+0x25f7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x262a, 0x25f7, x86_l_25f7);
x86_l_262c:
	/* 0x262c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_262e:
	/* 0x262e: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2632:
	/* 0x2632: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2635:
	/* 0x2635: jns    263c <trace_exec_binprm+0x263c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2635, 0x263c, x86_l_263c);
x86_l_2637:
	/* 0x2637: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_263a:
	/* 0x263a: jmp    263e <trace_exec_binprm+0x263e> */
	X86_SIM_X86_JMP(0x263a, 0x263e, x86_l_263e);
x86_l_263c:
	/* 0x263c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_263e:
	/* 0x263e: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2641:
	/* 0x2641: je     26c5 <trace_exec_binprm+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2641, 0x26c5, x86_l_26c5);
x86_l_2647:
	/* 0x2647: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_264a:
	/* 0x264a: je     26c5 <trace_exec_binprm+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x264a, 0x26c5, x86_l_26c5);
x86_l_264c:
	/* 0x264c: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2650:
	/* 0x2650: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2653:
	/* 0x2653: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2659:
	/* 0x2659: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_265c:
	/* 0x265c: jns    2665 <trace_exec_binprm+0x2665> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x265c, 0x2665, x86_l_2665);
x86_l_265e:
	/* 0x265e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2661:
	/* 0x2661: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2665:
	/* 0x2665: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2669:
	/* 0x2669: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_266c:
	/* 0x266c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2673:
	/* 0x2673: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2677:
	/* 0x2677: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_267a:
	/* 0x267a: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x267a, 0x2cd0, x86_l_2cd0);
x86_l_2680:
	/* 0x2680: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2683:
	/* 0x2683: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2683, 0x2c77, x86_l_2c77);
x86_l_2689:
	/* 0x2689: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_268f:
	/* 0x268f: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2692:
	/* 0x2692: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2695:
	/* 0x2695: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2695, 0x2a7f, x86_l_2a7f);
x86_l_269b:
	/* 0x269b: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_269f:
	/* 0x269f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26a2:
	/* 0x26a2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_26a5:
	/* 0x26a5: je     2738 <trace_exec_binprm+0x2738> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a5, 0x2738, x86_l_2738);
x86_l_26ab:
	/* 0x26ab: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26af:
	/* 0x26af: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_26b4:
	/* 0x26b4: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_26b8:
	/* 0x26b8: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_26bb:
	/* 0x26bb: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_26be:
	/* 0x26be: jne    26a2 <trace_exec_binprm+0x26a2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26be, 0x26a2, x86_l_26a2);
x86_l_26c0:
	/* 0x26c0: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_26c3:
	/* 0x26c3: jmp    273d <trace_exec_binprm+0x273d> */
	X86_SIM_X86_JMP(0x26c3, 0x273d, x86_l_273d);
x86_l_26c5:
	/* 0x26c5: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26c8:
	/* 0x26c8: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26c8, 0x2c77, x86_l_2c77);
x86_l_26ce:
	/* 0x26ce: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26d3:
	/* 0x26d3: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_26d8:
	/* 0x26d8: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d8, 0x2c77, x86_l_2c77);
x86_l_26de:
	/* 0x26de: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26e3:
	/* 0x26e3: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26e7:
	/* 0x26e7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26ea:
	/* 0x26ea: jns    26f1 <trace_exec_binprm+0x26f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26ea, 0x26f1, x86_l_26f1);
x86_l_26ec:
	/* 0x26ec: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ef:
	/* 0x26ef: jmp    26f3 <trace_exec_binprm+0x26f3> */
	X86_SIM_X86_JMP(0x26ef, 0x26f3, x86_l_26f3);
x86_l_26f1:
	/* 0x26f1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26f3:
	/* 0x26f3: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26f8:
	/* 0x26f8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26fb:
	/* 0x26fb: jns    2705 <trace_exec_binprm+0x2705> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26fb, 0x2705, x86_l_2705);
x86_l_26fd:
	/* 0x26fd: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2700:
	/* 0x2700: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2703:
	/* 0x2703: jmp    2707 <trace_exec_binprm+0x2707> */
	X86_SIM_X86_JMP(0x2703, 0x2707, x86_l_2707);
x86_l_2705:
	/* 0x2705: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2707:
	/* 0x2707: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_270c:
	/* 0x270c: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2711:
	/* 0x2711: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2714:
	/* 0x2714: jns    271b <trace_exec_binprm+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2714, 0x271b, x86_l_271b);
x86_l_2716:
	/* 0x2716: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2719:
	/* 0x2719: jmp    271d <trace_exec_binprm+0x271d> */
	X86_SIM_X86_JMP(0x2719, 0x271d, x86_l_271d);
x86_l_271b:
	/* 0x271b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_271d:
	/* 0x271d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2722:
	/* 0x2722: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2727:
	/* 0x2727: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_272b:
	/* 0x272b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_272e:
	/* 0x272e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2731:
	/* 0x2731: jns    2768 <trace_exec_binprm+0x2768> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2731, 0x2768, x86_l_2768);
x86_l_2733:
	/* 0x2733: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2736:
	/* 0x2736: jmp    276a <trace_exec_binprm+0x276a> */
	X86_SIM_X86_JMP(0x2736, 0x276a, x86_l_276a);
x86_l_2738:
	/* 0x2738: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_273d:
	/* 0x273d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2741:
	/* 0x2741: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2741, 0x2c77, x86_l_2c77);
x86_l_2747:
	/* 0x2747: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274b:
	/* 0x274b: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_274e:
	/* 0x274e: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2754:
	/* 0x2754: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2759:
	/* 0x2759: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_275c:
	/* 0x275c: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2760:
	/* 0x2760: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2763:
	/* 0x2763: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2766:
	/* 0x2766: js     2733 <trace_exec_binprm+0x2733> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2766, 0x2733, x86_l_2733);
x86_l_2768:
	/* 0x2768: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_276a:
	/* 0x276a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_276e:
	/* 0x276e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2771:
	/* 0x2771: jns    2778 <trace_exec_binprm+0x2778> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2771, 0x2778, x86_l_2778);
x86_l_2773:
	/* 0x2773: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2776:
	/* 0x2776: jmp    277a <trace_exec_binprm+0x277a> */
	X86_SIM_X86_JMP(0x2776, 0x277a, x86_l_277a);
x86_l_2778:
	/* 0x2778: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_277a:
	/* 0x277a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_277d:
	/* 0x277d: je     2801 <trace_exec_binprm+0x2801> */
	X86_SIM_X86_JCC(X86_CC_E, 0x277d, 0x2801, x86_l_2801);
x86_l_2783:
	/* 0x2783: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2786:
	/* 0x2786: je     2801 <trace_exec_binprm+0x2801> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2786, 0x2801, x86_l_2801);
x86_l_2788:
	/* 0x2788: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_278c:
	/* 0x278c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_278f:
	/* 0x278f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2795:
	/* 0x2795: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2798:
	/* 0x2798: jns    27a1 <trace_exec_binprm+0x27a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2798, 0x27a1, x86_l_27a1);
x86_l_279a:
	/* 0x279a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_279d:
	/* 0x279d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27a1:
	/* 0x27a1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_27a5:
	/* 0x27a5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_27a8:
	/* 0x27a8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_27af:
	/* 0x27af: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27b3:
	/* 0x27b3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27b6:
	/* 0x27b6: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27b6, 0x2cd0, x86_l_2cd0);
x86_l_27bc:
	/* 0x27bc: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_27bf:
	/* 0x27bf: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27bf, 0x2c7a, x86_l_2c7a);
x86_l_27c5:
	/* 0x27c5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27cb:
	/* 0x27cb: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27ce:
	/* 0x27ce: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_27d1:
	/* 0x27d1: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27d1, 0x2a7c, x86_l_2a7c);
x86_l_27d7:
	/* 0x27d7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27db:
	/* 0x27db: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27de:
	/* 0x27de: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_27e1:
	/* 0x27e1: je     2874 <trace_exec_binprm+0x2874> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e1, 0x2874, x86_l_2874);
x86_l_27e7:
	/* 0x27e7: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_27eb:
	/* 0x27eb: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_27f0:
	/* 0x27f0: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_27f4:
	/* 0x27f4: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_27f7:
	/* 0x27f7: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_27fa:
	/* 0x27fa: jne    27de <trace_exec_binprm+0x27de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27fa, 0x27de, x86_l_27de);
x86_l_27fc:
	/* 0x27fc: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_27ff:
	/* 0x27ff: jmp    2879 <trace_exec_binprm+0x2879> */
	X86_SIM_X86_JMP(0x27ff, 0x2879, x86_l_2879);
x86_l_2801:
	/* 0x2801: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2804:
	/* 0x2804: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2804, 0x2c7a, x86_l_2c7a);
x86_l_280a:
	/* 0x280a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_280f:
	/* 0x280f: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2814:
	/* 0x2814: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2814, 0x2c7a, x86_l_2c7a);
x86_l_281a:
	/* 0x281a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_281f:
	/* 0x281f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2823:
	/* 0x2823: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2826:
	/* 0x2826: jns    282d <trace_exec_binprm+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2826, 0x282d, x86_l_282d);
x86_l_2828:
	/* 0x2828: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_282b:
	/* 0x282b: jmp    282f <trace_exec_binprm+0x282f> */
	X86_SIM_X86_JMP(0x282b, 0x282f, x86_l_282f);
x86_l_282d:
	/* 0x282d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_282f:
	/* 0x282f: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2834:
	/* 0x2834: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2837:
	/* 0x2837: jns    2841 <trace_exec_binprm+0x2841> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2837, 0x2841, x86_l_2841);
x86_l_2839:
	/* 0x2839: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_283c:
	/* 0x283c: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_283f:
	/* 0x283f: jmp    2843 <trace_exec_binprm+0x2843> */
	X86_SIM_X86_JMP(0x283f, 0x2843, x86_l_2843);
x86_l_2841:
	/* 0x2841: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2843:
	/* 0x2843: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2848:
	/* 0x2848: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_284d:
	/* 0x284d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2850:
	/* 0x2850: jns    2857 <trace_exec_binprm+0x2857> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2850, 0x2857, x86_l_2857);
x86_l_2852:
	/* 0x2852: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2855:
	/* 0x2855: jmp    2859 <trace_exec_binprm+0x2859> */
	X86_SIM_X86_JMP(0x2855, 0x2859, x86_l_2859);
x86_l_2857:
	/* 0x2857: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2859:
	/* 0x2859: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_285e:
	/* 0x285e: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2863:
	/* 0x2863: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2867:
	/* 0x2867: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_286a:
	/* 0x286a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_286d:
	/* 0x286d: jns    28a4 <trace_exec_binprm+0x28a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x286d, 0x28a4, x86_l_28a4);
x86_l_286f:
	/* 0x286f: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2872:
	/* 0x2872: jmp    28a6 <trace_exec_binprm+0x28a6> */
	X86_SIM_X86_JMP(0x2872, 0x28a6, x86_l_28a6);
x86_l_2874:
	/* 0x2874: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2879:
	/* 0x2879: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_287d:
	/* 0x287d: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x287d, 0x2c7a, x86_l_2c7a);
x86_l_2883:
	/* 0x2883: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2887:
	/* 0x2887: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_288a:
	/* 0x288a: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2890:
	/* 0x2890: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2895:
	/* 0x2895: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2898:
	/* 0x2898: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_289c:
	/* 0x289c: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_289f:
	/* 0x289f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28a2:
	/* 0x28a2: js     286f <trace_exec_binprm+0x286f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28a2, 0x286f, x86_l_286f);
x86_l_28a4:
	/* 0x28a4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28a6:
	/* 0x28a6: lea    rdx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28aa:
	/* 0x28aa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28ad:
	/* 0x28ad: jns    28b4 <trace_exec_binprm+0x28b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ad, 0x28b4, x86_l_28b4);
x86_l_28af:
	/* 0x28af: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b2:
	/* 0x28b2: jmp    28b6 <trace_exec_binprm+0x28b6> */
	X86_SIM_X86_JMP(0x28b2, 0x28b6, x86_l_28b6);
x86_l_28b4:
	/* 0x28b4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b6:
	/* 0x28b6: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28b9:
	/* 0x28b9: je     293d <trace_exec_binprm+0x293d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28b9, 0x293d, x86_l_293d);
x86_l_28bf:
	/* 0x28bf: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28c2:
	/* 0x28c2: je     293d <trace_exec_binprm+0x293d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c2, 0x293d, x86_l_293d);
x86_l_28c4:
	/* 0x28c4: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c8:
	/* 0x28c8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28cb:
	/* 0x28cb: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_28d1:
	/* 0x28d1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28d4:
	/* 0x28d4: jns    28dd <trace_exec_binprm+0x28dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28d4, 0x28dd, x86_l_28dd);
x86_l_28d6:
	/* 0x28d6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d9:
	/* 0x28d9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28dd:
	/* 0x28dd: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28e1:
	/* 0x28e1: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28e4:
	/* 0x28e4: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28eb:
	/* 0x28eb: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ef:
	/* 0x28ef: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28f2:
	/* 0x28f2: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28f2, 0x2cd0, x86_l_2cd0);
x86_l_28f8:
	/* 0x28f8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_28fb:
	/* 0x28fb: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28fb, 0x2c77, x86_l_2c77);
x86_l_2901:
	/* 0x2901: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2907:
	/* 0x2907: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_290a:
	/* 0x290a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_290d:
	/* 0x290d: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x290d, 0x2a7f, x86_l_2a7f);
x86_l_2913:
	/* 0x2913: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2917:
	/* 0x2917: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_291a:
	/* 0x291a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_291d:
	/* 0x291d: je     29b0 <trace_exec_binprm+0x29b0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x291d, 0x29b0, x86_l_29b0);
x86_l_2923:
	/* 0x2923: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2927:
	/* 0x2927: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_292c:
	/* 0x292c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2930:
	/* 0x2930: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2933:
	/* 0x2933: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2936:
	/* 0x2936: jne    291a <trace_exec_binprm+0x291a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2936, 0x291a, x86_l_291a);
x86_l_2938:
	/* 0x2938: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_293b:
	/* 0x293b: jmp    29b5 <trace_exec_binprm+0x29b5> */
	X86_SIM_X86_JMP(0x293b, 0x29b5, x86_l_29b5);
x86_l_293d:
	/* 0x293d: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2940:
	/* 0x2940: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2940, 0x2c77, x86_l_2c77);
x86_l_2946:
	/* 0x2946: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_294b:
	/* 0x294b: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2950:
	/* 0x2950: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2950, 0x2c77, x86_l_2c77);
x86_l_2956:
	/* 0x2956: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_295b:
	/* 0x295b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_295f:
	/* 0x295f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2962:
	/* 0x2962: jns    2969 <trace_exec_binprm+0x2969> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2962, 0x2969, x86_l_2969);
x86_l_2964:
	/* 0x2964: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2967:
	/* 0x2967: jmp    296b <trace_exec_binprm+0x296b> */
	X86_SIM_X86_JMP(0x2967, 0x296b, x86_l_296b);
x86_l_2969:
	/* 0x2969: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_296b:
	/* 0x296b: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2970:
	/* 0x2970: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2973:
	/* 0x2973: jns    297d <trace_exec_binprm+0x297d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2973, 0x297d, x86_l_297d);
x86_l_2975:
	/* 0x2975: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2978:
	/* 0x2978: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297b:
	/* 0x297b: jmp    297f <trace_exec_binprm+0x297f> */
	X86_SIM_X86_JMP(0x297b, 0x297f, x86_l_297f);
x86_l_297d:
	/* 0x297d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_297f:
	/* 0x297f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2984:
	/* 0x2984: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2989:
	/* 0x2989: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_298c:
	/* 0x298c: jns    2993 <trace_exec_binprm+0x2993> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x298c, 0x2993, x86_l_2993);
x86_l_298e:
	/* 0x298e: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2991:
	/* 0x2991: jmp    2995 <trace_exec_binprm+0x2995> */
	X86_SIM_X86_JMP(0x2991, 0x2995, x86_l_2995);
x86_l_2993:
	/* 0x2993: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2995:
	/* 0x2995: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_299a:
	/* 0x299a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_299f:
	/* 0x299f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29a3:
	/* 0x29a3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29a6:
	/* 0x29a6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29a9:
	/* 0x29a9: jns    29e0 <trace_exec_binprm+0x29e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29a9, 0x29e0, x86_l_29e0);
x86_l_29ab:
	/* 0x29ab: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ae:
	/* 0x29ae: jmp    29e2 <trace_exec_binprm+0x29e2> */
	X86_SIM_X86_JMP(0x29ae, 0x29e2, x86_l_29e2);
x86_l_29b0:
	/* 0x29b0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_29b5:
	/* 0x29b5: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_29b9:
	/* 0x29b9: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x29b9, 0x2c77, x86_l_2c77);
x86_l_29bf:
	/* 0x29bf: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c3:
	/* 0x29c3: lea    edi,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29c6:
	/* 0x29c6: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_29cc:
	/* 0x29cc: mov    BYTE PTR [r15+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_29d1:
	/* 0x29d1: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_29d4:
	/* 0x29d4: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d8:
	/* 0x29d8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29db:
	/* 0x29db: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29de:
	/* 0x29de: js     29ab <trace_exec_binprm+0x29ab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29de, 0x29ab, x86_l_29ab);
x86_l_29e0:
	/* 0x29e0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e2:
	/* 0x29e2: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29e6:
	/* 0x29e6: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_29e9:
	/* 0x29e9: jns    29f0 <trace_exec_binprm+0x29f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29e9, 0x29f0, x86_l_29f0);
x86_l_29eb:
	/* 0x29eb: mov    rbx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ee:
	/* 0x29ee: jmp    29f2 <trace_exec_binprm+0x29f2> */
	X86_SIM_X86_JMP(0x29ee, 0x29f2, x86_l_29f2);
x86_l_29f0:
	/* 0x29f0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f2:
	/* 0x29f2: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29f5:
	/* 0x29f5: je     2a8e <trace_exec_binprm+0x2a8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29f5, 0x2a8e, x86_l_2a8e);
x86_l_29fb:
	/* 0x29fb: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_29fe:
	/* 0x29fe: je     2a8e <trace_exec_binprm+0x2a8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29fe, 0x2a8e, x86_l_2a8e);
x86_l_2a04:
	/* 0x2a04: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a08:
	/* 0x2a08: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a0b:
	/* 0x2a0b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2a11:
	/* 0x2a11: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a14:
	/* 0x2a14: jns    2a1d <trace_exec_binprm+0x2a1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a14, 0x2a1d, x86_l_2a1d);
x86_l_2a16:
	/* 0x2a16: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a19:
	/* 0x2a19: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a1d:
	/* 0x2a1d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2a21:
	/* 0x2a21: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a24:
	/* 0x2a24: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a2b:
	/* 0x2a2b: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a2f:
	/* 0x2a2f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a32:
	/* 0x2a32: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a32, 0x2cd0, x86_l_2cd0);
x86_l_2a38:
	/* 0x2a38: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2a3b:
	/* 0x2a3b: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a3b, 0x2c7a, x86_l_2c7a);
x86_l_2a41:
	/* 0x2a41: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a47:
	/* 0x2a47: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a4a:
	/* 0x2a4a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2a4d:
	/* 0x2a4d: jns    2a7c <trace_exec_binprm+0x2a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a4d, 0x2a7c, x86_l_2a7c);
x86_l_2a4f:
	/* 0x2a4f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a53:
	/* 0x2a53: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a56:
	/* 0x2a56: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2a59:
	/* 0x2a59: je     2b01 <trace_exec_binprm+0x2b01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a59, 0x2b01, x86_l_2b01);
x86_l_2a5f:
	/* 0x2a5f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a63:
	/* 0x2a63: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2a68:
	/* 0x2a68: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2a6c:
	/* 0x2a6c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a6f:
	/* 0x2a6f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2a72:
	/* 0x2a72: jne    2a56 <trace_exec_binprm+0x2a56> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a72, 0x2a56, x86_l_2a56);
x86_l_2a74:
	/* 0x2a74: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2a77:
	/* 0x2a77: jmp    2b06 <trace_exec_binprm+0x2b06> */
	X86_SIM_X86_JMP(0x2a77, 0x2b06, x86_l_2b06);
x86_l_2a7c:
	/* 0x2a7c: mov    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a7f:
	/* 0x2a7f: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a84:
	/* 0x2a84: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a89:
	/* 0x2a89: jmp    1365 <trace_exec_binprm+0x1365> */
	X86_SIM_X86_JMP(0x2a89, 0x1365, x86_l_1365);
x86_l_2a8e:
	/* 0x2a8e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a91:
	/* 0x2a91: jne    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a91, 0x2c7a, x86_l_2c7a);
x86_l_2a97:
	/* 0x2a97: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a9c:
	/* 0x2a9c: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2aa1:
	/* 0x2aa1: je     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aa1, 0x2c7a, x86_l_2c7a);
x86_l_2aa7:
	/* 0x2aa7: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2aac:
	/* 0x2aac: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ab0:
	/* 0x2ab0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ab3:
	/* 0x2ab3: jns    2aba <trace_exec_binprm+0x2aba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ab3, 0x2aba, x86_l_2aba);
x86_l_2ab5:
	/* 0x2ab5: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab8:
	/* 0x2ab8: jmp    2abc <trace_exec_binprm+0x2abc> */
	X86_SIM_X86_JMP(0x2ab8, 0x2abc, x86_l_2abc);
x86_l_2aba:
	/* 0x2aba: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2abc:
	/* 0x2abc: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ac1:
	/* 0x2ac1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ac4:
	/* 0x2ac4: jns    2ace <trace_exec_binprm+0x2ace> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ac4, 0x2ace, x86_l_2ace);
x86_l_2ac6:
	/* 0x2ac6: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ac9:
	/* 0x2ac9: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2acc:
	/* 0x2acc: jmp    2ad0 <trace_exec_binprm+0x2ad0> */
	X86_SIM_X86_JMP(0x2acc, 0x2ad0, x86_l_2ad0);
x86_l_2ace:
	/* 0x2ace: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ad0:
	/* 0x2ad0: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ad5:
	/* 0x2ad5: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ada:
	/* 0x2ada: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2add:
	/* 0x2add: jns    2ae4 <trace_exec_binprm+0x2ae4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2add, 0x2ae4, x86_l_2ae4);
x86_l_2adf:
	/* 0x2adf: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae2:
	/* 0x2ae2: jmp    2ae6 <trace_exec_binprm+0x2ae6> */
	X86_SIM_X86_JMP(0x2ae2, 0x2ae6, x86_l_2ae6);
x86_l_2ae4:
	/* 0x2ae4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ae6:
	/* 0x2ae6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2aeb:
	/* 0x2aeb: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2af0:
	/* 0x2af0: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2af4:
	/* 0x2af4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2af7:
	/* 0x2af7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2afa:
	/* 0x2afa: jns    2b31 <trace_exec_binprm+0x2b31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2afa, 0x2b31, x86_l_2b31);
x86_l_2afc:
	/* 0x2afc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aff:
	/* 0x2aff: jmp    2b33 <trace_exec_binprm+0x2b33> */
	X86_SIM_X86_JMP(0x2aff, 0x2b33, x86_l_2b33);
x86_l_2b01:
	/* 0x2b01: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2b06:
	/* 0x2b06: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2b0a:
	/* 0x2b0a: jl     2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2b0a, 0x2c7a, x86_l_2c7a);
x86_l_2b10:
	/* 0x2b10: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b14:
	/* 0x2b14: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2b17:
	/* 0x2b17: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b1d:
	/* 0x2b1d: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2b22:
	/* 0x2b22: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b25:
	/* 0x2b25: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b29:
	/* 0x2b29: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b2c:
	/* 0x2b2c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b2f:
	/* 0x2b2f: js     2afc <trace_exec_binprm+0x2afc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b2f, 0x2afc, x86_l_2afc);
x86_l_2b31:
	/* 0x2b31: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b33:
	/* 0x2b33: lea    rdi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b37:
	/* 0x2b37: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2b3a:
	/* 0x2b3a: jns    2b41 <trace_exec_binprm+0x2b41> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b3a, 0x2b41, x86_l_2b41);
x86_l_2b3c:
	/* 0x2b3c: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3f:
	/* 0x2b3f: jmp    2b44 <trace_exec_binprm+0x2b44> */
	X86_SIM_X86_JMP(0x2b3f, 0x2b44, x86_l_2b44);
x86_l_2b41:
	/* 0x2b41: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b44:
	/* 0x2b44: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b47:
	/* 0x2b47: je     2bca <trace_exec_binprm+0x2bca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b47, 0x2bca, x86_l_2bca);
x86_l_2b4d:
	/* 0x2b4d: cmp    rbx,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2b50:
	/* 0x2b50: je     2bca <trace_exec_binprm+0x2bca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b50, 0x2bca, x86_l_2bca);
x86_l_2b52:
	/* 0x2b52: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b56:
	/* 0x2b56: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b59:
	/* 0x2b59: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2b5e:
	/* 0x2b5e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2b61:
	/* 0x2b61: jns    2b6a <trace_exec_binprm+0x2b6a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b61, 0x2b6a, x86_l_2b6a);
x86_l_2b63:
	/* 0x2b63: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b66:
	/* 0x2b66: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b6a:
	/* 0x2b6a: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b6e:
	/* 0x2b6e: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b71:
	/* 0x2b71: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2b78:
	/* 0x2b78: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b7c:
	/* 0x2b7c: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b7f:
	/* 0x2b7f: jb     2cd0 <trace_exec_binprm+0x2cd0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b7f, 0x2cd0, x86_l_2cd0);
x86_l_2b85:
	/* 0x2b85: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2b88:
	/* 0x2b88: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b88, 0x2c77, x86_l_2c77);
x86_l_2b8e:
	/* 0x2b8e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b94:
	/* 0x2b94: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b97:
	/* 0x2b97: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b9a:
	/* 0x2b9a: jns    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b9a, 0x2a7f, x86_l_2a7f);
x86_l_2ba0:
	/* 0x2ba0: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ba4:
	/* 0x2ba4: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ba7:
	/* 0x2ba7: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2baa:
	/* 0x2baa: je     2c3e <trace_exec_binprm+0x2c3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2baa, 0x2c3e, x86_l_2c3e);
x86_l_2bb0:
	/* 0x2bb0: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2bb4:
	/* 0x2bb4: movzx  r12d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2bb9:
	/* 0x2bb9: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2bbd:
	/* 0x2bbd: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2bc0:
	/* 0x2bc0: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2bc3:
	/* 0x2bc3: jne    2ba7 <trace_exec_binprm+0x2ba7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bc3, 0x2ba7, x86_l_2ba7);
x86_l_2bc5:
	/* 0x2bc5: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2bc8:
	/* 0x2bc8: jmp    2c43 <trace_exec_binprm+0x2c43> */
	X86_SIM_X86_JMP(0x2bc8, 0x2c43, x86_l_2c43);
x86_l_2bca:
	/* 0x2bca: cmp    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2bcd:
	/* 0x2bcd: jne    2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bcd, 0x2c77, x86_l_2c77);
x86_l_2bd3:
	/* 0x2bd3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2bd8:
	/* 0x2bd8: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_2bdd:
	/* 0x2bdd: je     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bdd, 0x2c77, x86_l_2c77);
x86_l_2be3:
	/* 0x2be3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2be8:
	/* 0x2be8: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bec:
	/* 0x2bec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bef:
	/* 0x2bef: jns    2bf6 <trace_exec_binprm+0x2bf6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bef, 0x2bf6, x86_l_2bf6);
x86_l_2bf1:
	/* 0x2bf1: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bf4:
	/* 0x2bf4: jmp    2bf9 <trace_exec_binprm+0x2bf9> */
	X86_SIM_X86_JMP(0x2bf4, 0x2bf9, x86_l_2bf9);
x86_l_2bf6:
	/* 0x2bf6: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bf9:
	/* 0x2bf9: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2bfe:
	/* 0x2bfe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c01:
	/* 0x2c01: jns    2c0b <trace_exec_binprm+0x2c0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c01, 0x2c0b, x86_l_2c0b);
x86_l_2c03:
	/* 0x2c03: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c06:
	/* 0x2c06: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c09:
	/* 0x2c09: jmp    2c0d <trace_exec_binprm+0x2c0d> */
	X86_SIM_X86_JMP(0x2c09, 0x2c0d, x86_l_2c0d);
x86_l_2c0b:
	/* 0x2c0b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c0d:
	/* 0x2c0d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c12:
	/* 0x2c12: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c17:
	/* 0x2c17: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c1a:
	/* 0x2c1a: jns    2c21 <trace_exec_binprm+0x2c21> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c1a, 0x2c21, x86_l_2c21);
x86_l_2c1c:
	/* 0x2c1c: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c1f:
	/* 0x2c1f: jmp    2c23 <trace_exec_binprm+0x2c23> */
	X86_SIM_X86_JMP(0x2c1f, 0x2c23, x86_l_2c23);
x86_l_2c21:
	/* 0x2c21: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c23:
	/* 0x2c23: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c28:
	/* 0x2c28: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c2d:
	/* 0x2c2d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c31:
	/* 0x2c31: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c34:
	/* 0x2c34: jns    2c67 <trace_exec_binprm+0x2c67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c34, 0x2c67, x86_l_2c67);
x86_l_2c36:
	/* 0x2c36: mov    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c39:
	/* 0x2c39: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c3c:
	/* 0x2c3c: jmp    2c69 <trace_exec_binprm+0x2c69> */
	X86_SIM_X86_JMP(0x2c3c, 0x2c69, x86_l_2c69);
x86_l_2c3e:
	/* 0x2c3e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2c43:
	/* 0x2c43: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c47:
	/* 0x2c47: jl     2c77 <trace_exec_binprm+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2c47, 0x2c77, x86_l_2c77);
x86_l_2c49:
	/* 0x2c49: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c4d:
	/* 0x2c4d: lea    edx,[rcx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2c50:
	/* 0x2c50: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2c56:
	/* 0x2c56: mov    BYTE PTR [r15+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2c5b:
	/* 0x2c5b: sub    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2c5e:
	/* 0x2c5e: mov    QWORD PTR [rsp],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c62:
	/* 0x2c62: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c65:
	/* 0x2c65: js     2c36 <trace_exec_binprm+0x2c36> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c65, 0x2c36, x86_l_2c36);
x86_l_2c67:
	/* 0x2c67: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c69:
	/* 0x2c69: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c6d:
	/* 0x2c6d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c70:
	/* 0x2c70: jns    2c89 <trace_exec_binprm+0x2c89> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c70, 0x2c89, x86_l_2c89);
x86_l_2c72:
	/* 0x2c72: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c75:
	/* 0x2c75: jmp    2c8b <trace_exec_binprm+0x2c8b> */
	X86_SIM_X86_JMP(0x2c75, 0x2c8b, x86_l_2c8b);
x86_l_2c77:
	/* 0x2c77: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c7a:
	/* 0x2c7a: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c7f:
	/* 0x2c7f: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c84:
	/* 0x2c84: jmp    1372 <trace_exec_binprm+0x1372> */
	X86_SIM_X86_JMP(0x2c84, 0x1372, x86_l_1372);
x86_l_2c89:
	/* 0x2c89: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c8b:
	/* 0x2c8b: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c8e:
	/* 0x2c8e: je     31cf <trace_exec_binprm+0x31cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c8e, 0x31cf, x86_l_31cf);
x86_l_2c94:
	/* 0x2c94: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c97:
	/* 0x2c97: je     31cf <trace_exec_binprm+0x31cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c97, 0x31cf, x86_l_31cf);
x86_l_2c9d:
	/* 0x2c9d: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ca1:
	/* 0x2ca1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ca4:
	/* 0x2ca4: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2ca9:
	/* 0x2ca9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2cac:
	/* 0x2cac: jns    2cb5 <trace_exec_binprm+0x2cb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cac, 0x2cb5, x86_l_2cb5);
x86_l_2cae:
	/* 0x2cae: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cb1:
	/* 0x2cb1: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cb5:
	/* 0x2cb5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2cb9:
	/* 0x2cb9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2cbc:
	/* 0x2cbc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2cc3:
	/* 0x2cc3: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cc7:
	/* 0x2cc7: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2cca:
	/* 0x2cca: jae    31fb <trace_exec_binprm+0x31fb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2cca, 0x31fb, x86_l_31fb);
x86_l_2cd0:
	/* 0x2cd0: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2cd5:
	/* 0x2cd5: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cda:
	/* 0x2cda: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cde:
	/* 0x2cde: dec    r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2ce1:
	/* 0x2ce1: mov    eax,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_2ce4:
	/* 0x2ce4: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ce9:
	/* 0x2ce9: mov    BYTE PTR [r15+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2cee:
	/* 0x2cee: mov    BYTE PTR [r15+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2cf6:
	/* 0x2cf6: and    r10d,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2cfd:
	/* 0x2cfd: add    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2d00:
	/* 0x2d00: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d08:
	/* 0x2d08: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2d0e:
	/* 0x2d0e: ja     2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d0e, 0x2dd6, x86_l_2dd6);
x86_l_2d14:
	/* 0x2d14: mov    BYTE PTR [r14+rax*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519555ULL);
x86_l_2d1d:
	/* 0x2d1d: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d25:
	/* 0x2d25: mov    WORD PTR [r14+0x7d92],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32146ULL);
x86_l_2d2d:
	/* 0x2d2d: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2d33:
	/* 0x2d33: ja     2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d33, 0x2dd6, x86_l_2dd6);
x86_l_2d39:
	/* 0x2d39: lea    rdi,[rax+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2d3d:
	/* 0x2d3d: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2d44:
	/* 0x2d44: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d47:
	/* 0x2d47: jns    2d6e <trace_exec_binprm+0x2d6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d47, 0x2d6e, x86_l_2d6e);
x86_l_2d49:
	/* 0x2d49: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d4c:
	/* 0x2d4c: jns    2d84 <trace_exec_binprm+0x2d84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d4c, 0x2d84, x86_l_2d84);
x86_l_2d4e:
	/* 0x2d4e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d50:
	/* 0x2d50: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2d57:
	/* 0x2d57: je     2d92 <trace_exec_binprm+0x2d92> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d57, 0x2d92, x86_l_2d92);
x86_l_2d59:
	/* 0x2d59: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d5d:
	/* 0x2d5d: movzx  edx,BYTE PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2d62:
	/* 0x2d62: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2d65:
	/* 0x2d65: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d68:
	/* 0x2d68: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2d6a:
	/* 0x2d6a: jne    2d50 <trace_exec_binprm+0x2d50> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d6a, 0x2d50, x86_l_2d50);
x86_l_2d6c:
	/* 0x2d6c: jmp    2d7b <trace_exec_binprm+0x2d7b> */
	X86_SIM_X86_JMP(0x2d6c, 0x2d7b, x86_l_2d7b);
x86_l_2d6e:
	/* 0x2d6e: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d73:
	/* 0x2d73: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d76:
	/* 0x2d76: call   2d7b <trace_exec_binprm+0x2d7b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2d7b:
	/* 0x2d7b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d7e:
	/* 0x2d7e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d80:
	/* 0x2d80: jg     2da3 <trace_exec_binprm+0x2da3> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d80, 0x2da3, x86_l_2da3);
x86_l_2d82:
	/* 0x2d82: jmp    2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JMP(0x2d82, 0x2dd6, x86_l_2dd6);
x86_l_2d84:
	/* 0x2d84: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d89:
	/* 0x2d89: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d8b:
	/* 0x2d8b: call   2d90 <trace_exec_binprm+0x2d90> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2d90:
	/* 0x2d90: jmp    2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JMP(0x2d90, 0x2dd6, x86_l_2dd6);
x86_l_2d92:
	/* 0x2d92: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2d99:
	/* 0x2d99: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d9e:
	/* 0x2d9e: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2da3:
	/* 0x2da3: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2dab:
	/* 0x2dab: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2db2:
	/* 0x2db2: ja     2dd6 <trace_exec_binprm+0x2dd6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2db2, 0x2dd6, x86_l_2dd6);
x86_l_2db4:
	/* 0x2db4: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2dbc:
	/* 0x2dbc: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2dc4:
	/* 0x2dc4: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2dc7:
	/* 0x2dc7: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2dcf:
	/* 0x2dcf: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2dd6:
	/* 0x2dd6: add    rbp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2dda:
	/* 0x2dda: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2ddd:
	/* 0x2ddd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2de0:
	/* 0x2de0: jns    2de7 <trace_exec_binprm+0x2de7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2de0, 0x2de7, x86_l_2de7);
x86_l_2de2:
	/* 0x2de2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de5:
	/* 0x2de5: jmp    2de9 <trace_exec_binprm+0x2de9> */
	X86_SIM_X86_JMP(0x2de5, 0x2de9, x86_l_2de9);
x86_l_2de7:
	/* 0x2de7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2de9:
	/* 0x2de9: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ded:
	/* 0x2ded: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2def:
	/* 0x2def: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2df2:
	/* 0x2df2: jns    2dfe <trace_exec_binprm+0x2dfe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2df2, 0x2dfe, x86_l_2dfe);
x86_l_2df4:
	/* 0x2df4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2df7:
	/* 0x2df7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2dfa:
	/* 0x2dfa: js     2e05 <trace_exec_binprm+0x2e05> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dfa, 0x2e05, x86_l_2e05);
x86_l_2dfc:
	/* 0x2dfc: jmp    2e07 <trace_exec_binprm+0x2e07> */
	X86_SIM_X86_JMP(0x2dfc, 0x2e07, x86_l_2e07);
x86_l_2dfe:
	/* 0x2dfe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e00:
	/* 0x2e00: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e03:
	/* 0x2e03: jns    2e07 <trace_exec_binprm+0x2e07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e03, 0x2e07, x86_l_2e07);
x86_l_2e05:
	/* 0x2e05: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e07:
	/* 0x2e07: mov    DWORD PTR [rsp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2e0b:
	/* 0x2e0b: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e13:
	/* 0x2e13: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e1a:
	/* 0x2e1a: ja     2e73 <trace_exec_binprm+0x2e73> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e1a, 0x2e73, x86_l_2e73);
x86_l_2e1c:
	/* 0x2e1c: mov    BYTE PTR [r14+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_2e25:
	/* 0x2e25: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2e2b:
	/* 0x2e2b: ja     2e73 <trace_exec_binprm+0x2e73> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e2b, 0x2e73, x86_l_2e73);
x86_l_2e2d:
	/* 0x2e2d: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2e31:
	/* 0x2e31: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2e38:
	/* 0x2e38: lea    rax,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2e3d:
	/* 0x2e3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e40:
	/* 0x2e40: jns    2e4d <trace_exec_binprm+0x2e4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e40, 0x2e4d, x86_l_2e4d);
x86_l_2e42:
	/* 0x2e42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e45:
	/* 0x2e45: jns    2e8b <trace_exec_binprm+0x2e8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e45, 0x2e8b, x86_l_2e8b);
x86_l_2e47:
	/* 0x2e47: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e49:
	/* 0x2e49: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e4b:
	/* 0x2e4b: jmp    2e61 <trace_exec_binprm+0x2e61> */
	X86_SIM_X86_JMP(0x2e4b, 0x2e61, x86_l_2e61);
x86_l_2e4d:
	/* 0x2e4d: lea    rdx,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2e52:
	/* 0x2e52: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e57:
	/* 0x2e57: call   2e5c <trace_exec_binprm+0x2e5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e5c:
	/* 0x2e5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e5f:
	/* 0x2e5f: js     2e73 <trace_exec_binprm+0x2e73> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e5f, 0x2e73, x86_l_2e73);
x86_l_2e61:
	/* 0x2e61: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e64:
	/* 0x2e64: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e6c:
	/* 0x2e6c: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e73:
	/* 0x2e73: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e76:
	/* 0x2e76: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e79:
	/* 0x2e79: jns    2e99 <trace_exec_binprm+0x2e99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e79, 0x2e99, x86_l_2e99);
x86_l_2e7b:
	/* 0x2e7b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e7e:
	/* 0x2e7e: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e82:
	/* 0x2e82: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e85:
	/* 0x2e85: js     2ea4 <trace_exec_binprm+0x2ea4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e85, 0x2ea4, x86_l_2ea4);
x86_l_2e87:
	/* 0x2e87: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e89:
	/* 0x2e89: jmp    2ea7 <trace_exec_binprm+0x2ea7> */
	X86_SIM_X86_JMP(0x2e89, 0x2ea7, x86_l_2ea7);
x86_l_2e8b:
	/* 0x2e8b: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e91:
	/* 0x2e91: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e94:
	/* 0x2e94: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e97:
	/* 0x2e97: js     2e7b <trace_exec_binprm+0x2e7b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e97, 0x2e7b, x86_l_2e7b);
x86_l_2e99:
	/* 0x2e99: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e9b:
	/* 0x2e9b: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e9f:
	/* 0x2e9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ea2:
	/* 0x2ea2: jns    2e87 <trace_exec_binprm+0x2e87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ea2, 0x2e87, x86_l_2e87);
x86_l_2ea4:
	/* 0x2ea4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea7:
	/* 0x2ea7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2eac:
	/* 0x2eac: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2eb4:
	/* 0x2eb4: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2ebb:
	/* 0x2ebb: ja     2f16 <trace_exec_binprm+0x2f16> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ebb, 0x2f16, x86_l_2f16);
x86_l_2ebd:
	/* 0x2ebd: mov    BYTE PTR [r14+rbx*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519557ULL);
x86_l_2ec6:
	/* 0x2ec6: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2ecc:
	/* 0x2ecc: ja     2f16 <trace_exec_binprm+0x2f16> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ecc, 0x2f16, x86_l_2f16);
x86_l_2ece:
	/* 0x2ece: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2ed2:
	/* 0x2ed2: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2ed9:
	/* 0x2ed9: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ede:
	/* 0x2ede: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ee1:
	/* 0x2ee1: jns    2ef0 <trace_exec_binprm+0x2ef0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee1, 0x2ef0, x86_l_2ef0);
x86_l_2ee3:
	/* 0x2ee3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ee6:
	/* 0x2ee6: jns    2f23 <trace_exec_binprm+0x2f23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee6, 0x2f23, x86_l_2f23);
x86_l_2ee8:
	/* 0x2ee8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eeb:
	/* 0x2eeb: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eee:
	/* 0x2eee: jmp    2f04 <trace_exec_binprm+0x2f04> */
	X86_SIM_X86_JMP(0x2eee, 0x2f04, x86_l_2f04);
x86_l_2ef0:
	/* 0x2ef0: lea    rdx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ef5:
	/* 0x2ef5: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2efa:
	/* 0x2efa: call   2eff <trace_exec_binprm+0x2eff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2eff:
	/* 0x2eff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f02:
	/* 0x2f02: js     2f16 <trace_exec_binprm+0x2f16> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f02, 0x2f16, x86_l_2f16);
x86_l_2f04:
	/* 0x2f04: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2f07:
	/* 0x2f07: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2f0f:
	/* 0x2f0f: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2f16:
	/* 0x2f16: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f19:
	/* 0x2f19: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f1c:
	/* 0x2f1c: jns    2f32 <trace_exec_binprm+0x2f32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f1c, 0x2f32, x86_l_2f32);
x86_l_2f1e:
	/* 0x2f1e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f21:
	/* 0x2f21: jmp    2f34 <trace_exec_binprm+0x2f34> */
	X86_SIM_X86_JMP(0x2f21, 0x2f34, x86_l_2f34);
x86_l_2f23:
	/* 0x2f23: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2a:
	/* 0x2f2a: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f2d:
	/* 0x2f2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f30:
	/* 0x2f30: js     2f1e <trace_exec_binprm+0x2f1e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f30, 0x2f1e, x86_l_2f1e);
x86_l_2f32:
	/* 0x2f32: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f34:
	/* 0x2f34: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_2f3d:
	/* 0x2f3d: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2f46:
	/* 0x2f46: lea    rdx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2f4a:
	/* 0x2f4a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f4c:
	/* 0x2f4c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f4f:
	/* 0x2f4f: jns    2f56 <trace_exec_binprm+0x2f56> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f4f, 0x2f56, x86_l_2f56);
x86_l_2f51:
	/* 0x2f51: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f54:
	/* 0x2f54: jmp    2f58 <trace_exec_binprm+0x2f58> */
	X86_SIM_X86_JMP(0x2f54, 0x2f58, x86_l_2f58);
x86_l_2f56:
	/* 0x2f56: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f58:
	/* 0x2f58: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2f5d:
	/* 0x2f5d: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2f61:
	/* 0x2f61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f64:
	/* 0x2f64: jns    2f68 <trace_exec_binprm+0x2f68> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f64, 0x2f68, x86_l_2f68);
x86_l_2f66:
	/* 0x2f66: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f68:
	/* 0x2f68: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2f6a:
	/* 0x2f6a: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f6f:
	/* 0x2f6f: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2f74:
	/* 0x2f74: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f77:
	/* 0x2f77: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f7a:
	/* 0x2f7a: jns    2f88 <trace_exec_binprm+0x2f88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f7a, 0x2f88, x86_l_2f88);
x86_l_2f7c:
	/* 0x2f7c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f7f:
	/* 0x2f7f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f82:
	/* 0x2f82: jns    2f8a <trace_exec_binprm+0x2f8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f82, 0x2f8a, x86_l_2f8a);
x86_l_2f84:
	/* 0x2f84: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f86:
	/* 0x2f86: jmp    2fa5 <trace_exec_binprm+0x2fa5> */
	X86_SIM_X86_JMP(0x2f86, 0x2fa5, x86_l_2fa5);
x86_l_2f88:
	/* 0x2f88: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f8a:
	/* 0x2f8a: lea    rdx,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f8f:
	/* 0x2f8f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f92:
	/* 0x2f92: jns    2f99 <trace_exec_binprm+0x2f99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f92, 0x2f99, x86_l_2f99);
x86_l_2f94:
	/* 0x2f94: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f97:
	/* 0x2f97: jmp    2f9b <trace_exec_binprm+0x2f9b> */
	X86_SIM_X86_JMP(0x2f97, 0x2f9b, x86_l_2f9b);
x86_l_2f99:
	/* 0x2f99: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f9b:
	/* 0x2f9b: imul   rcx,rcx,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_2fa2:
	/* 0x2fa2: add    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2fa5:
	/* 0x2fa5: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2faa:
	/* 0x2faa: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2fb2:
	/* 0x2fb2: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2fb9:
	/* 0x2fb9: ja     300f <trace_exec_binprm+0x300f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2fb9, 0x300f, x86_l_300f);
x86_l_2fbb:
	/* 0x2fbb: mov    BYTE PTR [r14+rbx*1+0x89],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519558ULL);
x86_l_2fc4:
	/* 0x2fc4: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2fca:
	/* 0x2fca: ja     300f <trace_exec_binprm+0x300f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2fca, 0x300f, x86_l_300f);
x86_l_2fcc:
	/* 0x2fcc: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2fd0:
	/* 0x2fd0: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2fd7:
	/* 0x2fd7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fda:
	/* 0x2fda: jns    2fe9 <trace_exec_binprm+0x2fe9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fda, 0x2fe9, x86_l_2fe9);
x86_l_2fdc:
	/* 0x2fdc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fdf:
	/* 0x2fdf: jns    3021 <trace_exec_binprm+0x3021> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fdf, 0x3021, x86_l_3021);
x86_l_2fe1:
	/* 0x2fe1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe4:
	/* 0x2fe4: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe7:
	/* 0x2fe7: jmp    2ffd <trace_exec_binprm+0x2ffd> */
	X86_SIM_X86_JMP(0x2fe7, 0x2ffd, x86_l_2ffd);
x86_l_2fe9:
	/* 0x2fe9: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2fee:
	/* 0x2fee: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2ff3:
	/* 0x2ff3: call   2ff8 <trace_exec_binprm+0x2ff8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ff8:
	/* 0x2ff8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ffb:
	/* 0x2ffb: js     300f <trace_exec_binprm+0x300f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ffb, 0x300f, x86_l_300f);
x86_l_2ffd:
	/* 0x2ffd: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3000:
	/* 0x3000: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3008:
	/* 0x3008: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_300f:
	/* 0x300f: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3012:
	/* 0x3012: jns    302d <trace_exec_binprm+0x302d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3012, 0x302d, x86_l_302d);
x86_l_3014:
	/* 0x3014: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3018:
	/* 0x3018: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_301b:
	/* 0x301b: js     3034 <trace_exec_binprm+0x3034> */
	X86_SIM_X86_JCC(X86_CC_S, 0x301b, 0x3034, x86_l_3034);
x86_l_301d:
	/* 0x301d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_301f:
	/* 0x301f: jmp    3037 <trace_exec_binprm+0x3037> */
	X86_SIM_X86_JMP(0x301f, 0x3037, x86_l_3037);
x86_l_3021:
	/* 0x3021: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3028:
	/* 0x3028: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_302b:
	/* 0x302b: js     3014 <trace_exec_binprm+0x3014> */
	X86_SIM_X86_JCC(X86_CC_S, 0x302b, 0x3014, x86_l_3014);
x86_l_302d:
	/* 0x302d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_302f:
	/* 0x302f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3032:
	/* 0x3032: jns    301d <trace_exec_binprm+0x301d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3032, 0x301d, x86_l_301d);
x86_l_3034:
	/* 0x3034: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3037:
	/* 0x3037: mov    WORD PTR [rsp+0x3c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_303c:
	/* 0x303c: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3044:
	/* 0x3044: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_304b:
	/* 0x304b: ja     30a6 <trace_exec_binprm+0x30a6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x304b, 0x30a6, x86_l_30a6);
x86_l_304d:
	/* 0x304d: mov    BYTE PTR [r14+rbx*1+0x89],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519559ULL);
x86_l_3056:
	/* 0x3056: cmp    ebx,0x7cfd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31997ULL);
x86_l_305c:
	/* 0x305c: ja     30a6 <trace_exec_binprm+0x30a6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x305c, 0x30a6, x86_l_30a6);
x86_l_305e:
	/* 0x305e: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_3062:
	/* 0x3062: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3069:
	/* 0x3069: lea    rax,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_306e:
	/* 0x306e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3071:
	/* 0x3071: jns    3080 <trace_exec_binprm+0x3080> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3071, 0x3080, x86_l_3080);
x86_l_3073:
	/* 0x3073: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3076:
	/* 0x3076: jns    30cd <trace_exec_binprm+0x30cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3076, 0x30cd, x86_l_30cd);
x86_l_3078:
	/* 0x3078: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_307b:
	/* 0x307b: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307e:
	/* 0x307e: jmp    3094 <trace_exec_binprm+0x3094> */
	X86_SIM_X86_JMP(0x307e, 0x3094, x86_l_3094);
x86_l_3080:
	/* 0x3080: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3085:
	/* 0x3085: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_308a:
	/* 0x308a: call   308f <trace_exec_binprm+0x308f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_308f:
	/* 0x308f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3092:
	/* 0x3092: js     30a6 <trace_exec_binprm+0x30a6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3092, 0x30a6, x86_l_30a6);
x86_l_3094:
	/* 0x3094: add    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_3097:
	/* 0x3097: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_309f:
	/* 0x309f: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_30a6:
	/* 0x30a6: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_30aa:
	/* 0x30aa: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_30ad:
	/* 0x30ad: jns    30db <trace_exec_binprm+0x30db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30ad, 0x30db, x86_l_30db);
x86_l_30af:
	/* 0x30af: mov    rdx,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30b3:
	/* 0x30b3: mov    ebx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_30b8:
	/* 0x30b8: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_30c0:
	/* 0x30c0: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_30c6:
	/* 0x30c6: jbe    30f6 <trace_exec_binprm+0x30f6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x30c6, 0x30f6, x86_l_30f6);
x86_l_30c8:
	/* 0x30c8: jmp    31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JMP(0x30c8, 0x31b6, x86_l_31b6);
x86_l_30cd:
	/* 0x30cd: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d2:
	/* 0x30d2: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_30d6:
	/* 0x30d6: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_30d9:
	/* 0x30d9: js     30af <trace_exec_binprm+0x30af> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30d9, 0x30af, x86_l_30af);
x86_l_30db:
	/* 0x30db: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30dd:
	/* 0x30dd: mov    ebx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_30e2:
	/* 0x30e2: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_30ea:
	/* 0x30ea: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_30f0:
	/* 0x30f0: ja     31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x30f0, 0x31b6, x86_l_31b6);
x86_l_30f6:
	/* 0x30f6: mov    BYTE PTR [r14+rax*1+0x89],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519560ULL);
x86_l_30ff:
	/* 0x30ff: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3107:
	/* 0x3107: mov    WORD PTR [r14+0x7d9c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32156ULL);
x86_l_310f:
	/* 0x310f: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_3115:
	/* 0x3115: ja     31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3115, 0x31b6, x86_l_31b6);
x86_l_311b:
	/* 0x311b: lea    rdi,[rax+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_311f:
	/* 0x311f: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_3126:
	/* 0x3126: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3129:
	/* 0x3129: jns    3151 <trace_exec_binprm+0x3151> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3129, 0x3151, x86_l_3151);
x86_l_312b:
	/* 0x312b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_312e:
	/* 0x312e: jns    3164 <trace_exec_binprm+0x3164> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x312e, 0x3164, x86_l_3164);
x86_l_3130:
	/* 0x3130: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3132:
	/* 0x3132: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_3139:
	/* 0x3139: je     3172 <trace_exec_binprm+0x3172> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3139, 0x3172, x86_l_3172);
x86_l_313b:
	/* 0x313b: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_313f:
	/* 0x313f: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_3143:
	/* 0x3143: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3147:
	/* 0x3147: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_314a:
	/* 0x314a: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_314d:
	/* 0x314d: jne    3132 <trace_exec_binprm+0x3132> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x314d, 0x3132, x86_l_3132);
x86_l_314f:
	/* 0x314f: jmp    315b <trace_exec_binprm+0x315b> */
	X86_SIM_X86_JMP(0x314f, 0x315b, x86_l_315b);
x86_l_3151:
	/* 0x3151: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3156:
	/* 0x3156: call   315b <trace_exec_binprm+0x315b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_315b:
	/* 0x315b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_315e:
	/* 0x315e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3160:
	/* 0x3160: jg     3183 <trace_exec_binprm+0x3183> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3160, 0x3183, x86_l_3183);
x86_l_3162:
	/* 0x3162: jmp    31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JMP(0x3162, 0x31b6, x86_l_31b6);
x86_l_3164:
	/* 0x3164: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3169:
	/* 0x3169: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_316b:
	/* 0x316b: call   3170 <trace_exec_binprm+0x3170> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_3170:
	/* 0x3170: jmp    31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JMP(0x3170, 0x31b6, x86_l_31b6);
x86_l_3172:
	/* 0x3172: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_3179:
	/* 0x3179: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_317e:
	/* 0x317e: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3183:
	/* 0x3183: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_318b:
	/* 0x318b: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_3192:
	/* 0x3192: ja     31b6 <trace_exec_binprm+0x31b6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3192, 0x31b6, x86_l_31b6);
x86_l_3194:
	/* 0x3194: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_319c:
	/* 0x319c: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_31a4:
	/* 0x31a4: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_31a7:
	/* 0x31a7: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_31af:
	/* 0x31af: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_31b6:
	/* 0x31b6: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)prog_array));
x86_l_31bd:
	/* 0x31bd: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_31c0:
	/* 0x31c0: mov    edx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_31c5:
	/* 0x31c5: call   31ca <trace_exec_binprm+0x31ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_31ca:
	/* 0x31ca: jmp    1f <trace_exec_binprm+0x1f> */
	X86_SIM_X86_JMP(0x31ca, 0x1f, x86_l_1f);
x86_l_31cf:
	/* 0x31cf: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_31d2:
	/* 0x31d2: jne    3294 <trace_exec_binprm+0x3294> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31d2, 0x3294, x86_l_3294);
x86_l_31d8:
	/* 0x31d8: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31dd:
	/* 0x31dd: cmp    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_31e2:
	/* 0x31e2: je     3294 <trace_exec_binprm+0x3294> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31e2, 0x3294, x86_l_3294);
x86_l_31e8:
	/* 0x31e8: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31ed:
	/* 0x31ed: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31f1:
	/* 0x31f1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31f4:
	/* 0x31f4: jns    3237 <trace_exec_binprm+0x3237> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31f4, 0x3237, x86_l_3237);
x86_l_31f6:
	/* 0x31f6: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f9:
	/* 0x31f9: jmp    3239 <trace_exec_binprm+0x3239> */
	X86_SIM_X86_JMP(0x31f9, 0x3239, x86_l_3239);
x86_l_31fb:
	/* 0x31fb: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_31fe:
	/* 0x31fe: je     3294 <trace_exec_binprm+0x3294> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31fe, 0x3294, x86_l_3294);
x86_l_3204:
	/* 0x3204: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_320a:
	/* 0x320a: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_320d:
	/* 0x320d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3210:
	/* 0x3210: jns    325e <trace_exec_binprm+0x325e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3210, 0x325e, x86_l_325e);
x86_l_3212:
	/* 0x3212: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3216:
	/* 0x3216: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3218:
	/* 0x3218: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_321b:
	/* 0x321b: je     3266 <trace_exec_binprm+0x3266> */
	X86_SIM_X86_JCC(X86_CC_E, 0x321b, 0x3266, x86_l_3266);
x86_l_321d:
	/* 0x321d: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3221:
	/* 0x3221: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_3226:
	/* 0x3226: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_322a:
	/* 0x322a: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_322d:
	/* 0x322d: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3230:
	/* 0x3230: jne    3218 <trace_exec_binprm+0x3218> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3230, 0x3218, x86_l_3218);
x86_l_3232:
	/* 0x3232: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_3235:
	/* 0x3235: jmp    326a <trace_exec_binprm+0x326a> */
	X86_SIM_X86_JMP(0x3235, 0x326a, x86_l_326a);
x86_l_3237:
	/* 0x3237: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3239:
	/* 0x3239: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_323e:
	/* 0x323e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3241:
	/* 0x3241: jns    324b <trace_exec_binprm+0x324b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3241, 0x324b, x86_l_324b);
x86_l_3243:
	/* 0x3243: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3246:
	/* 0x3246: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3249:
	/* 0x3249: jmp    324d <trace_exec_binprm+0x324d> */
	X86_SIM_X86_JMP(0x3249, 0x324d, x86_l_324d);
x86_l_324b:
	/* 0x324b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_324d:
	/* 0x324d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3250:
	/* 0x3250: jns    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3250, 0x2c7a, x86_l_2c7a);
x86_l_3256:
	/* 0x3256: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3259:
	/* 0x3259: jmp    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JMP(0x3259, 0x2c7a, x86_l_2c7a);
x86_l_325e:
	/* 0x325e: mov    rbx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3261:
	/* 0x3261: jmp    2a7f <trace_exec_binprm+0x2a7f> */
	X86_SIM_X86_JMP(0x3261, 0x2a7f, x86_l_2a7f);
x86_l_3266:
	/* 0x3266: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_326a:
	/* 0x326a: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_326e:
	/* 0x326e: jl     3294 <trace_exec_binprm+0x3294> */
	X86_SIM_X86_JCC(X86_CC_L, 0x326e, 0x3294, x86_l_3294);
x86_l_3270:
	/* 0x3270: mov    r10,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3274:
	/* 0x3274: lea    eax,[r10-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R10, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3278:
	/* 0x3278: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_327d:
	/* 0x327d: mov    BYTE PTR [r15+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_3282:
	/* 0x3282: sub    r10d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3285:
	/* 0x3285: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_328a:
	/* 0x328a: mov    r14,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_328f:
	/* 0x328f: jmp    1376 <trace_exec_binprm+0x1376> */
	X86_SIM_X86_JMP(0x328f, 0x1376, x86_l_1376);
x86_l_3294:
	/* 0x3294: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3297:
	/* 0x3297: jmp    2c7a <trace_exec_binprm+0x2c7a> */
	X86_SIM_X86_JMP(0x3297, 0x2c7a, x86_l_2c7a);
x86_l_329c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
