#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 232U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(3) M(4) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(17) M(18) M(21) M(22)
#include "../x86_sim_local_bpf.h"

extern __u8 args_map[] __ksym;
extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kretprobe/inotify_find_inode")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: movabs rbx,0x30900000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 3337189588992ULL);
x86_l_1e:
	/* 0x1e: call   23 <trace_ret_inotify_find_inode+0x23> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_23:
	/* 0x23: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_25:
	/* 0x25: or     rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_28:
	/* 0x28: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2d:
	/* 0x2d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)args_map));
x86_l_34:
	/* 0x34: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_39:
	/* 0x39: call   3e <trace_ret_inotify_find_inode+0x3e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e:
	/* 0x3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41:
	/* 0x41: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41, 0x1365, x86_l_1365);
x86_l_47:
	/* 0x47: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b:
	/* 0x4b: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_50:
	/* 0x50: call   55 <trace_ret_inotify_find_inode+0x55> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_55:
	/* 0x55: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_57:
	/* 0x57: or     rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5a:
	/* 0x5a: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5f:
	/* 0x5f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)args_map));
x86_l_66:
	/* 0x66: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6b:
	/* 0x6b: call   70 <trace_ret_inotify_find_inode+0x70> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_70:
	/* 0x70: mov    DWORD PTR [rsp+0xa4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_7b:
	/* 0x7b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_82:
	/* 0x82: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_8a:
	/* 0x8a: call   8f <trace_ret_inotify_find_inode+0x8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8f:
	/* 0x8f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_92:
	/* 0x92: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0x92, 0x1365, x86_l_1365);
x86_l_98:
	/* 0x98: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9b:
	/* 0x9b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_a2:
	/* 0xa2: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_aa:
	/* 0xaa: call   af <trace_ret_inotify_find_inode+0xaf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_af:
	/* 0xaf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b2:
	/* 0xb2: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2, 0x1365, x86_l_1365);
x86_l_b8:
	/* 0xb8: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bb:
	/* 0xbb: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_be:
	/* 0xbe: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_c7:
	/* 0xc7: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_ce:
	/* 0xce: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_d9:
	/* 0xd9: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_e4:
	/* 0xe4: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_ef:
	/* 0xef: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_fa:
	/* 0xfa: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_105:
	/* 0x105: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_110:
	/* 0x110: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_11b:
	/* 0x11b: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_126:
	/* 0x126: call   12b <trace_ret_inotify_find_inode+0x12b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_12b:
	/* 0x12b: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_132:
	/* 0x132: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_13a:
	/* 0x13a: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_142:
	/* 0x142: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_14a:
	/* 0x14a: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_152:
	/* 0x152: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_15a:
	/* 0x15a: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_162:
	/* 0x162: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_16a:
	/* 0x16a: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_172:
	/* 0x172: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_17a:
	/* 0x17a: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_182:
	/* 0x182: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_18a:
	/* 0x18a: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_192:
	/* 0x192: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_19a:
	/* 0x19a: call   19f <trace_ret_inotify_find_inode+0x19f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a2:
	/* 0x1a2: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a6:
	/* 0x1a6: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1a9:
	/* 0x1a9: mov    DWORD PTR [rbp+0x70],0x309 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337929ULL);
x86_l_1b0:
	/* 0x1b0: call   1b5 <trace_ret_inotify_find_inode+0x1b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_1b5:
	/* 0x1b5: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9:
	/* 0x1b9: call   1be <trace_ret_inotify_find_inode+0x1be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_1be:
	/* 0x1be: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_1c2:
	/* 0x1c2: call   1c7 <trace_ret_inotify_find_inode+0x1c7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_1c7:
	/* 0x1c7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ca:
	/* 0x1ca: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1ce:
	/* 0x1ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d1:
	/* 0x1d1: jns    1e2 <trace_ret_inotify_find_inode+0x1e2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1, 0x1e2, x86_l_1e2);
x86_l_1d3:
	/* 0x1d3: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d5:
	/* 0x1d5: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1da:
	/* 0x1da: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_1e0:
	/* 0x1e0: jne    21f <trace_ret_inotify_find_inode+0x21f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e0, 0x21f, x86_l_21f);
x86_l_1e2:
	/* 0x1e2: call   1e7 <trace_ret_inotify_find_inode+0x1e7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_1e7:
	/* 0x1e7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ea:
	/* 0x1ea: call   1ef <trace_ret_inotify_find_inode+0x1ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_1ef:
	/* 0x1ef: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_1f3:
	/* 0x1f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f6:
	/* 0x1f6: jns    206 <trace_ret_inotify_find_inode+0x206> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6, 0x206, x86_l_206);
x86_l_1f8:
	/* 0x1f8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb:
	/* 0x1fb: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1ff:
	/* 0x1ff: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_202:
	/* 0x202: js     211 <trace_ret_inotify_find_inode+0x211> */
	X86_SIM_X86_JCC(X86_CC_S, 0x202, 0x211, x86_l_211);
x86_l_204:
	/* 0x204: jmp    21b <trace_ret_inotify_find_inode+0x21b> */
	X86_SIM_X86_JMP(0x204, 0x21b, x86_l_21b);
x86_l_206:
	/* 0x206: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208:
	/* 0x208: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_20c:
	/* 0x20c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20f:
	/* 0x20f: jns    21b <trace_ret_inotify_find_inode+0x21b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20f, 0x21b, x86_l_21b);
x86_l_211:
	/* 0x211: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213:
	/* 0x213: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_215:
	/* 0x215: jne    5b7 <trace_ret_inotify_find_inode+0x5b7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x215, 0x5b7, x86_l_5b7);
x86_l_21b:
	/* 0x21b: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_21f:
	/* 0x21f: mov    DWORD PTR [r13+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_223:
	/* 0x223: mov    eax,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_227:
	/* 0x227: mov    DWORD PTR [rsp+0xa0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_22e:
	/* 0x22e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_235:
	/* 0x235: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_23d:
	/* 0x23d: call   242 <trace_ret_inotify_find_inode+0x242> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_242:
	/* 0x242: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_24a:
	/* 0x24a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24d:
	/* 0x24d: je     124a <trace_ret_inotify_find_inode+0x124a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d, 0x124a, x86_l_124a);
x86_l_253:
	/* 0x253: mov    eax,DWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_257:
	/* 0x257: mov    DWORD PTR [rsp+0x9c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_25e:
	/* 0x25e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_265:
	/* 0x265: lea    rsi,[rsp+0x9c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_26d:
	/* 0x26d: call   272 <trace_ret_inotify_find_inode+0x272> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_272:
	/* 0x272: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_275:
	/* 0x275: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_278:
	/* 0x278: mov    QWORD PTR [rsp+0xb0],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_280:
	/* 0x280: mov    QWORD PTR [rsp],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284:
	/* 0x284: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_287:
	/* 0x287: mov    QWORD PTR [rsp+0x20],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28c:
	/* 0x28c: mov    QWORD PTR [rsp+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_291:
	/* 0x291: je     12d0 <trace_ret_inotify_find_inode+0x12d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x291, 0x12d0, x86_l_12d0);
x86_l_297:
	/* 0x297: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_29d:
	/* 0x29d: jne    2a6 <trace_ret_inotify_find_inode+0x2a6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29d, 0x2a6, x86_l_2a6);
x86_l_29f:
	/* 0x29f: call   2a4 <trace_ret_inotify_find_inode+0x2a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_2a4:
	/* 0x2a4: jmp    2fe <trace_ret_inotify_find_inode+0x2fe> */
	X86_SIM_X86_JMP(0x2a4, 0x2fe, x86_l_2fe);
x86_l_2a6:
	/* 0x2a6: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2ab:
	/* 0x2ab: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_2b2:
	/* 0x2b2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b5:
	/* 0x2b5: jns    2cf <trace_ret_inotify_find_inode+0x2cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b5, 0x2cf, x86_l_2cf);
x86_l_2b7:
	/* 0x2b7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ba:
	/* 0x2ba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bd:
	/* 0x2bd: js     2d6 <trace_ret_inotify_find_inode+0x2d6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bd, 0x2d6, x86_l_2d6);
x86_l_2bf:
	/* 0x2bf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c1:
	/* 0x2c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c4:
	/* 0x2c4: js     2de <trace_ret_inotify_find_inode+0x2de> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c4, 0x2de, x86_l_2de);
x86_l_2c6:
	/* 0x2c6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c8:
	/* 0x2c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cb:
	/* 0x2cb: js     2e6 <trace_ret_inotify_find_inode+0x2e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2cb, 0x2e6, x86_l_2e6);
x86_l_2cd:
	/* 0x2cd: jmp    2fc <trace_ret_inotify_find_inode+0x2fc> */
	X86_SIM_X86_JMP(0x2cd, 0x2fc, x86_l_2fc);
x86_l_2cf:
	/* 0x2cf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d1:
	/* 0x2d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d4:
	/* 0x2d4: jns    2bf <trace_ret_inotify_find_inode+0x2bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d4, 0x2bf, x86_l_2bf);
x86_l_2d6:
	/* 0x2d6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d9:
	/* 0x2d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dc:
	/* 0x2dc: jns    2c6 <trace_ret_inotify_find_inode+0x2c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dc, 0x2c6, x86_l_2c6);
x86_l_2de:
	/* 0x2de: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e1:
	/* 0x2e1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e4:
	/* 0x2e4: jns    2fc <trace_ret_inotify_find_inode+0x2fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e4, 0x2fc, x86_l_2fc);
x86_l_2e6:
	/* 0x2e6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e9:
	/* 0x2e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ec:
	/* 0x2ec: je     2fc <trace_ret_inotify_find_inode+0x2fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ec, 0x2fc, x86_l_2fc);
x86_l_2ee:
	/* 0x2ee: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f2:
	/* 0x2f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f5:
	/* 0x2f5: jns    2fc <trace_ret_inotify_find_inode+0x2fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f5, 0x2fc, x86_l_2fc);
x86_l_2f7:
	/* 0x2f7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fa:
	/* 0x2fa: jmp    2fe <trace_ret_inotify_find_inode+0x2fe> */
	X86_SIM_X86_JMP(0x2fa, 0x2fe, x86_l_2fe);
x86_l_2fc:
	/* 0x2fc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fe:
	/* 0x2fe: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_302:
	/* 0x302: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_306:
	/* 0x306: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30a:
	/* 0x30a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_311:
	/* 0x311: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_316:
	/* 0x316: call   31b <trace_ret_inotify_find_inode+0x31b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_31b:
	/* 0x31b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31e:
	/* 0x31e: je     336 <trace_ret_inotify_find_inode+0x336> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31e, 0x336, x86_l_336);
x86_l_320:
	/* 0x320: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_323:
	/* 0x323: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_329:
	/* 0x329: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_32c:
	/* 0x32c: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_32f:
	/* 0x32f: jne    336 <trace_ret_inotify_find_inode+0x336> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32f, 0x336, x86_l_336);
x86_l_331:
	/* 0x331: or     BYTE PTR [r13+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_336:
	/* 0x336: movzx  eax,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_33b:
	/* 0x33b: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_341:
	/* 0x341: jne    136c <trace_ret_inotify_find_inode+0x136c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x341, 0x136c, x86_l_136c);
x86_l_347:
	/* 0x347: mov    QWORD PTR [r13+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_352:
	/* 0x352: mov    DWORD PTR [rsp+0x40],0x309 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907721ULL);
x86_l_35a:
	/* 0x35a: mov    WORD PTR [rsp+0x2c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_35f:
	/* 0x35f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_366:
	/* 0x366: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_36b:
	/* 0x36b: call   370 <trace_ret_inotify_find_inode+0x370> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_370:
	/* 0x370: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_373:
	/* 0x373: je     3de <trace_ret_inotify_find_inode+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x373, 0x3de, x86_l_3de);
x86_l_375:
	/* 0x375: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_37a:
	/* 0x37a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37d:
	/* 0x37d: call   382 <trace_ret_inotify_find_inode+0x382> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_382:
	/* 0x382: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_385:
	/* 0x385: je     3de <trace_ret_inotify_find_inode+0x3de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x385, 0x3de, x86_l_3de);
x86_l_387:
	/* 0x387: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38b:
	/* 0x38b: mov    QWORD PTR [r13+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_392:
	/* 0x392: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_395:
	/* 0x395: mov    QWORD PTR [r13+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_39c:
	/* 0x39c: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3a0:
	/* 0x3a0: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3a4:
	/* 0x3a4: mov    QWORD PTR [r13+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_3ab:
	/* 0x3ab: mov    QWORD PTR [r13+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_3b2:
	/* 0x3b2: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b6:
	/* 0x3b6: mov    QWORD PTR [r13+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_3bd:
	/* 0x3bd: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3c1:
	/* 0x3c1: mov    QWORD PTR [r13+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_3c8:
	/* 0x3c8: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3cc:
	/* 0x3cc: mov    QWORD PTR [r13+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_3d3:
	/* 0x3d3: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3d7:
	/* 0x3d7: mov    QWORD PTR [r13+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_3de:
	/* 0x3de: mov    rax,QWORD PTR [r13+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_3e5:
	/* 0x3e5: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3ec:
	/* 0x3ec: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f0:
	/* 0x3f0: cmp    ecx,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_3f4:
	/* 0x3f4: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3f9:
	/* 0x3f9: jne    415 <trace_ret_inotify_find_inode+0x415> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f9, 0x415, x86_l_415);
x86_l_3fb:
	/* 0x3fb: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fe:
	/* 0x3fe: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_400:
	/* 0x400: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_403:
	/* 0x403: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_40a:
	/* 0x40a: jne    cb7 <trace_ret_inotify_find_inode+0xcb7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x40a, 0xcb7, x86_l_cb7);
x86_l_410:
	/* 0x410: jmp    311f <trace_ret_inotify_find_inode+0x311f> */
	X86_SIM_X86_JMP(0x410, 0x311f, x86_l_311f);
x86_l_415:
	/* 0x415: mov    rax,QWORD PTR [r13+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_41c:
	/* 0x41c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41f:
	/* 0x41f: je     5d8 <trace_ret_inotify_find_inode+0x5d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41f, 0x5d8, x86_l_5d8);
x86_l_425:
	/* 0x425: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_42c:
	/* 0x42c: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_42f:
	/* 0x42f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_432:
	/* 0x432: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_435:
	/* 0x435: sete   r12b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_439:
	/* 0x439: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_43c:
	/* 0x43c: neg    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_43f:
	/* 0x43f: xor    r12,QWORD PTR [r13+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_446:
	/* 0x446: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_449:
	/* 0x449: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_450:
	/* 0x450: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_453:
	/* 0x453: je     474 <trace_ret_inotify_find_inode+0x474> */
	X86_SIM_X86_JCC(X86_CC_E, 0x453, 0x474, x86_l_474);
x86_l_455:
	/* 0x455: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_457:
	/* 0x457: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_45e:
	/* 0x45e: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_461:
	/* 0x461: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_464:
	/* 0x464: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_467:
	/* 0x467: xor    rcx,QWORD PTR [r13+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_46e:
	/* 0x46e: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_471:
	/* 0x471: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_474:
	/* 0x474: mov    rax,QWORD PTR [r13+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_47b:
	/* 0x47b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_47e:
	/* 0x47e: je     49a <trace_ret_inotify_find_inode+0x49a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47e, 0x49a, x86_l_49a);
x86_l_480:
	/* 0x480: mov    ecx,DWORD PTR [r13+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_484:
	/* 0x484: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_487:
	/* 0x487: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_48a:
	/* 0x48a: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_48d:
	/* 0x48d: xor    rcx,QWORD PTR [r13+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_494:
	/* 0x494: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_497:
	/* 0x497: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_49a:
	/* 0x49a: mov    rax,QWORD PTR [r13+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_4a1:
	/* 0x4a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a4:
	/* 0x4a4: je     4c5 <trace_ret_inotify_find_inode+0x4c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a4, 0x4c5, x86_l_4c5);
x86_l_4a6:
	/* 0x4a6: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4a9:
	/* 0x4a9: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4b1:
	/* 0x4b1: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4b5:
	/* 0x4b5: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4b8:
	/* 0x4b8: xor    rcx,QWORD PTR [r13+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_4bf:
	/* 0x4bf: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4c2:
	/* 0x4c2: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4c5:
	/* 0x4c5: movzx  r14d,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_4ca:
	/* 0x4ca: mov    rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4cd:
	/* 0x4cd: mov    r13,QWORD PTR [r13+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_4d4:
	/* 0x4d4: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4d7:
	/* 0x4d7: mov    WORD PTR [rsp+0x16],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_4dd:
	/* 0x4dd: je     641 <trace_ret_inotify_find_inode+0x641> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dd, 0x641, x86_l_641);
x86_l_4e3:
	/* 0x4e3: mov    rax,QWORD PTR [rbx+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_4ea:
	/* 0x4ea: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_4f2:
	/* 0x4f2: mov    rbp,QWORD PTR [rbx+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_4f9:
	/* 0x4f9: mov    rax,QWORD PTR [rbx+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_500:
	/* 0x500: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_508:
	/* 0x508: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_50e:
	/* 0x50e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_515:
	/* 0x515: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_51a:
	/* 0x51a: call   51f <trace_ret_inotify_find_inode+0x51f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_51f:
	/* 0x51f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_522:
	/* 0x522: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_525:
	/* 0x525: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_52a:
	/* 0x52a: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_531:
	/* 0x531: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_534:
	/* 0x534: je     554 <trace_ret_inotify_find_inode+0x554> */
	X86_SIM_X86_JCC(X86_CC_E, 0x534, 0x554, x86_l_554);
x86_l_536:
	/* 0x536: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_53b:
	/* 0x53b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_53e:
	/* 0x53e: call   543 <trace_ret_inotify_find_inode+0x543> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_543:
	/* 0x543: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_546:
	/* 0x546: je     554 <trace_ret_inotify_find_inode+0x554> */
	X86_SIM_X86_JCC(X86_CC_E, 0x546, 0x554, x86_l_554);
x86_l_548:
	/* 0x548: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54b:
	/* 0x54b: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_54f:
	/* 0x54f: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_552:
	/* 0x552: jmp    556 <trace_ret_inotify_find_inode+0x556> */
	X86_SIM_X86_JMP(0x552, 0x556, x86_l_556);
x86_l_554:
	/* 0x554: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_556:
	/* 0x556: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_55e:
	/* 0x55e: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_563:
	/* 0x563: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_566:
	/* 0x566: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_569:
	/* 0x569: jb     581 <trace_ret_inotify_find_inode+0x581> */
	X86_SIM_X86_JCC(X86_CC_B, 0x569, 0x581, x86_l_581);
x86_l_56b:
	/* 0x56b: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_56f:
	/* 0x56f: je     576 <trace_ret_inotify_find_inode+0x576> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56f, 0x576, x86_l_576);
x86_l_571:
	/* 0x571: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_574:
	/* 0x574: jbe    581 <trace_ret_inotify_find_inode+0x581> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x574, 0x581, x86_l_581);
x86_l_576:
	/* 0x576: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_57e:
	/* 0x57e: or     rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_581:
	/* 0x581: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_585:
	/* 0x585: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_588:
	/* 0x588: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_58d:
	/* 0x58d: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_594:
	/* 0x594: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_597:
	/* 0x597: je     5f4 <trace_ret_inotify_find_inode+0x5f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x597, 0x5f4, x86_l_5f4);
x86_l_599:
	/* 0x599: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_59e:
	/* 0x59e: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5a1:
	/* 0x5a1: call   5a6 <trace_ret_inotify_find_inode+0x5a6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5a6:
	/* 0x5a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a9:
	/* 0x5a9: je     605 <trace_ret_inotify_find_inode+0x605> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5a9, 0x605, x86_l_605);
x86_l_5ab:
	/* 0x5ab: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ae:
	/* 0x5ae: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5b2:
	/* 0x5b2: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5b5:
	/* 0x5b5: jmp    607 <trace_ret_inotify_find_inode+0x607> */
	X86_SIM_X86_JMP(0x5b5, 0x607, x86_l_607);
x86_l_5b7:
	/* 0x5b7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_5be:
	/* 0x5be: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5c3:
	/* 0x5c3: call   5c8 <trace_ret_inotify_find_inode+0x5c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c8:
	/* 0x5c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5cb:
	/* 0x5cb: je     e2a <trace_ret_inotify_find_inode+0xe2a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5cb, 0xe2a, x86_l_e2a);
x86_l_5d1:
	/* 0x5d1: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d3:
	/* 0x5d3: jmp    21f <trace_ret_inotify_find_inode+0x21f> */
	X86_SIM_X86_JMP(0x5d3, 0x21f, x86_l_21f);
x86_l_5d8:
	/* 0x5d8: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5df:
	/* 0x5df: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_5e6:
	/* 0x5e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5e9:
	/* 0x5e9: jne    455 <trace_ret_inotify_find_inode+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5e9, 0x455, x86_l_455);
x86_l_5ef:
	/* 0x5ef: jmp    474 <trace_ret_inotify_find_inode+0x474> */
	X86_SIM_X86_JMP(0x5ef, 0x474, x86_l_474);
x86_l_5f4:
	/* 0x5f4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5f6:
	/* 0x5f6: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5f9:
	/* 0x5f9: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5fe:
	/* 0x5fe: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_601:
	/* 0x601: jae    61c <trace_ret_inotify_find_inode+0x61c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x601, 0x61c, x86_l_61c);
x86_l_603:
	/* 0x603: jmp    632 <trace_ret_inotify_find_inode+0x632> */
	X86_SIM_X86_JMP(0x603, 0x632, x86_l_632);
x86_l_605:
	/* 0x605: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_607:
	/* 0x607: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_60f:
	/* 0x60f: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_612:
	/* 0x612: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_617:
	/* 0x617: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61a:
	/* 0x61a: jb     632 <trace_ret_inotify_find_inode+0x632> */
	X86_SIM_X86_JCC(X86_CC_B, 0x61a, 0x632, x86_l_632);
x86_l_61c:
	/* 0x61c: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_620:
	/* 0x620: je     627 <trace_ret_inotify_find_inode+0x627> */
	X86_SIM_X86_JCC(X86_CC_E, 0x620, 0x627, x86_l_627);
x86_l_622:
	/* 0x622: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_625:
	/* 0x625: jbe    632 <trace_ret_inotify_find_inode+0x632> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x625, 0x632, x86_l_632);
x86_l_627:
	/* 0x627: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_62f:
	/* 0x62f: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_632:
	/* 0x632: or     rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_635:
	/* 0x635: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_638:
	/* 0x638: and    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_63b:
	/* 0x63b: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_641:
	/* 0x641: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_645:
	/* 0x645: cmp    QWORD PTR [r13+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_64d:
	/* 0x64d: je     6ee <trace_ret_inotify_find_inode+0x6ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64d, 0x6ee, x86_l_6ee);
x86_l_653:
	/* 0x653: call   658 <trace_ret_inotify_find_inode+0x658> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_658:
	/* 0x658: mov    DWORD PTR [r13+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_65c:
	/* 0x65c: mov    rbx,QWORD PTR [r13+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_663:
	/* 0x663: mov    rax,QWORD PTR [r13+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_66a:
	/* 0x66a: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_672:
	/* 0x672: mov    rbp,QWORD PTR [r13+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_679:
	/* 0x679: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_67c:
	/* 0x67c: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_67f:
	/* 0x67f: mov    r13,QWORD PTR [r13+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_686:
	/* 0x686: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_68b:
	/* 0x68b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_692:
	/* 0x692: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_697:
	/* 0x697: call   69c <trace_ret_inotify_find_inode+0x69c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_69c:
	/* 0x69c: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6a0:
	/* 0x6a0: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6a5:
	/* 0x6a5: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6ac:
	/* 0x6ac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6af:
	/* 0x6af: je     6cf <trace_ret_inotify_find_inode+0x6cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6af, 0x6cf, x86_l_6cf);
x86_l_6b1:
	/* 0x6b1: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6b6:
	/* 0x6b6: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b9:
	/* 0x6b9: call   6be <trace_ret_inotify_find_inode+0x6be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6be:
	/* 0x6be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c1:
	/* 0x6c1: je     6cf <trace_ret_inotify_find_inode+0x6cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c1, 0x6cf, x86_l_6cf);
x86_l_6c3:
	/* 0x6c3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c6:
	/* 0x6c6: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6ca:
	/* 0x6ca: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6cd:
	/* 0x6cd: jmp    6d1 <trace_ret_inotify_find_inode+0x6d1> */
	X86_SIM_X86_JMP(0x6cd, 0x6d1, x86_l_6d1);
x86_l_6cf:
	/* 0x6cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6d1:
	/* 0x6d1: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_6d7:
	/* 0x6d7: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6da:
	/* 0x6da: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6df:
	/* 0x6df: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6e2:
	/* 0x6e2: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e5:
	/* 0x6e5: jae    702 <trace_ret_inotify_find_inode+0x702> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6e5, 0x702, x86_l_702);
x86_l_6e7:
	/* 0x6e7: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6ec:
	/* 0x6ec: jmp    71d <trace_ret_inotify_find_inode+0x71d> */
	X86_SIM_X86_JMP(0x6ec, 0x71d, x86_l_71d);
x86_l_6ee:
	/* 0x6ee: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6f3:
	/* 0x6f3: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6fb:
	/* 0x6fb: jne    735 <trace_ret_inotify_find_inode+0x735> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6fb, 0x735, x86_l_735);
x86_l_6fd:
	/* 0x6fd: jmp    7d4 <trace_ret_inotify_find_inode+0x7d4> */
	X86_SIM_X86_JMP(0x6fd, 0x7d4, x86_l_7d4);
x86_l_702:
	/* 0x702: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_706:
	/* 0x706: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_70b:
	/* 0x70b: je     712 <trace_ret_inotify_find_inode+0x712> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70b, 0x712, x86_l_712);
x86_l_70d:
	/* 0x70d: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_710:
	/* 0x710: jbe    71d <trace_ret_inotify_find_inode+0x71d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x710, 0x71d, x86_l_71d);
x86_l_712:
	/* 0x712: and    r15,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 136ULL);
x86_l_71a:
	/* 0x71a: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_71d:
	/* 0x71d: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_720:
	/* 0x720: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_723:
	/* 0x723: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_727:
	/* 0x727: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_72f:
	/* 0x72f: je     7d4 <trace_ret_inotify_find_inode+0x7d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x72f, 0x7d4, x86_l_7d4);
x86_l_735:
	/* 0x735: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_73a:
	/* 0x73a: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_741:
	/* 0x741: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_744:
	/* 0x744: jns    74b <trace_ret_inotify_find_inode+0x74b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x744, 0x74b, x86_l_74b);
x86_l_746:
	/* 0x746: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_749:
	/* 0x749: jmp    74d <trace_ret_inotify_find_inode+0x74d> */
	X86_SIM_X86_JMP(0x749, 0x74d, x86_l_74d);
x86_l_74b:
	/* 0x74b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_74d:
	/* 0x74d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_751:
	/* 0x751: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_753:
	/* 0x753: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_756:
	/* 0x756: jns    762 <trace_ret_inotify_find_inode+0x762> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x756, 0x762, x86_l_762);
x86_l_758:
	/* 0x758: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_75b:
	/* 0x75b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_75e:
	/* 0x75e: js     769 <trace_ret_inotify_find_inode+0x769> */
	X86_SIM_X86_JCC(X86_CC_S, 0x75e, 0x769, x86_l_769);
x86_l_760:
	/* 0x760: jmp    76b <trace_ret_inotify_find_inode+0x76b> */
	X86_SIM_X86_JMP(0x760, 0x76b, x86_l_76b);
x86_l_762:
	/* 0x762: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_764:
	/* 0x764: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_767:
	/* 0x767: jns    76b <trace_ret_inotify_find_inode+0x76b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x767, 0x76b, x86_l_76b);
x86_l_769:
	/* 0x769: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_76b:
	/* 0x76b: mov    DWORD PTR [r13+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_76f:
	/* 0x76f: mov    rbx,QWORD PTR [r13+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_776:
	/* 0x776: mov    r15,QWORD PTR [r13+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_77d:
	/* 0x77d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_780:
	/* 0x780: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_786:
	/* 0x786: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_78d:
	/* 0x78d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_792:
	/* 0x792: call   797 <trace_ret_inotify_find_inode+0x797> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_797:
	/* 0x797: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_79e:
	/* 0x79e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a1:
	/* 0x7a1: je     7c0 <trace_ret_inotify_find_inode+0x7c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a1, 0x7c0, x86_l_7c0);
x86_l_7a3:
	/* 0x7a3: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7a7:
	/* 0x7a7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7aa:
	/* 0x7aa: call   7af <trace_ret_inotify_find_inode+0x7af> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7af:
	/* 0x7af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b2:
	/* 0x7b2: je     7c0 <trace_ret_inotify_find_inode+0x7c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b2, 0x7c0, x86_l_7c0);
x86_l_7b4:
	/* 0x7b4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b7:
	/* 0x7b7: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7bb:
	/* 0x7bb: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7be:
	/* 0x7be: jmp    7c2 <trace_ret_inotify_find_inode+0x7c2> */
	X86_SIM_X86_JMP(0x7be, 0x7c2, x86_l_7c2);
x86_l_7c0:
	/* 0x7c0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c2:
	/* 0x7c2: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7c5:
	/* 0x7c5: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7c8:
	/* 0x7c8: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7cb:
	/* 0x7cb: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7ce:
	/* 0x7ce: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_7d4:
	/* 0x7d4: cmp    QWORD PTR [r13+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_7dc:
	/* 0x7dc: je     8a5 <trace_ret_inotify_find_inode+0x8a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7dc, 0x8a5, x86_l_8a5);
x86_l_7e2:
	/* 0x7e2: mov    rcx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_7e9:
	/* 0x7e9: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7ed:
	/* 0x7ed: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ef:
	/* 0x7ef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7f2:
	/* 0x7f2: jns    801 <trace_ret_inotify_find_inode+0x801> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7f2, 0x801, x86_l_801);
x86_l_7f4:
	/* 0x7f4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f7:
	/* 0x7f7: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7fa:
	/* 0x7fa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7fd:
	/* 0x7fd: js     80b <trace_ret_inotify_find_inode+0x80b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7fd, 0x80b, x86_l_80b);
x86_l_7ff:
	/* 0x7ff: jmp    80d <trace_ret_inotify_find_inode+0x80d> */
	X86_SIM_X86_JMP(0x7ff, 0x80d, x86_l_80d);
x86_l_801:
	/* 0x801: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_803:
	/* 0x803: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_806:
	/* 0x806: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_809:
	/* 0x809: jns    80d <trace_ret_inotify_find_inode+0x80d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x809, 0x80d, x86_l_80d);
x86_l_80b:
	/* 0x80b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_80d:
	/* 0x80d: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_80f:
	/* 0x80f: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_813:
	/* 0x813: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_816:
	/* 0x816: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_81a:
	/* 0x81a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_81c:
	/* 0x81c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_81f:
	/* 0x81f: jns    82f <trace_ret_inotify_find_inode+0x82f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x81f, 0x82f, x86_l_82f);
x86_l_821:
	/* 0x821: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_824:
	/* 0x824: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_828:
	/* 0x828: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_82b:
	/* 0x82b: js     83a <trace_ret_inotify_find_inode+0x83a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x82b, 0x83a, x86_l_83a);
x86_l_82d:
	/* 0x82d: jmp    83c <trace_ret_inotify_find_inode+0x83c> */
	X86_SIM_X86_JMP(0x82d, 0x83c, x86_l_83c);
x86_l_82f:
	/* 0x82f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_831:
	/* 0x831: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_835:
	/* 0x835: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_838:
	/* 0x838: jns    83c <trace_ret_inotify_find_inode+0x83c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x838, 0x83c, x86_l_83c);
x86_l_83a:
	/* 0x83a: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_83c:
	/* 0x83c: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_840:
	/* 0x840: mov    rbx,QWORD PTR [r13+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_847:
	/* 0x847: mov    r15,QWORD PTR [r13+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_84e:
	/* 0x84e: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_851:
	/* 0x851: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_857:
	/* 0x857: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_85e:
	/* 0x85e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_863:
	/* 0x863: call   868 <trace_ret_inotify_find_inode+0x868> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_868:
	/* 0x868: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_86f:
	/* 0x86f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_872:
	/* 0x872: je     891 <trace_ret_inotify_find_inode+0x891> */
	X86_SIM_X86_JCC(X86_CC_E, 0x872, 0x891, x86_l_891);
x86_l_874:
	/* 0x874: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_878:
	/* 0x878: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_87b:
	/* 0x87b: call   880 <trace_ret_inotify_find_inode+0x880> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_880:
	/* 0x880: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_883:
	/* 0x883: je     891 <trace_ret_inotify_find_inode+0x891> */
	X86_SIM_X86_JCC(X86_CC_E, 0x883, 0x891, x86_l_891);
x86_l_885:
	/* 0x885: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_888:
	/* 0x888: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_88c:
	/* 0x88c: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_88f:
	/* 0x88f: jmp    893 <trace_ret_inotify_find_inode+0x893> */
	X86_SIM_X86_JMP(0x88f, 0x893, x86_l_893);
x86_l_891:
	/* 0x891: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_893:
	/* 0x893: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_896:
	/* 0x896: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_899:
	/* 0x899: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_89c:
	/* 0x89c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_89f:
	/* 0x89f: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_8a5:
	/* 0x8a5: cmp    QWORD PTR [r13+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_8ad:
	/* 0x8ad: je     a89 <trace_ret_inotify_find_inode+0xa89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ad, 0xa89, x86_l_a89);
x86_l_8b3:
	/* 0x8b3: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8b8:
	/* 0x8b8: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_8bf:
	/* 0x8bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c2:
	/* 0x8c2: jns    8d5 <trace_ret_inotify_find_inode+0x8d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c2, 0x8d5, x86_l_8d5);
x86_l_8c4:
	/* 0x8c4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c7:
	/* 0x8c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ca:
	/* 0x8ca: js     8dc <trace_ret_inotify_find_inode+0x8dc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8ca, 0x8dc, x86_l_8dc);
x86_l_8cc:
	/* 0x8cc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8ce:
	/* 0x8ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8d1:
	/* 0x8d1: js     8e4 <trace_ret_inotify_find_inode+0x8e4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8d1, 0x8e4, x86_l_8e4);
x86_l_8d3:
	/* 0x8d3: jmp    92f <trace_ret_inotify_find_inode+0x92f> */
	X86_SIM_X86_JMP(0x8d3, 0x92f, x86_l_92f);
x86_l_8d5:
	/* 0x8d5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d7:
	/* 0x8d7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8da:
	/* 0x8da: jns    8cc <trace_ret_inotify_find_inode+0x8cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8da, 0x8cc, x86_l_8cc);
x86_l_8dc:
	/* 0x8dc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8df:
	/* 0x8df: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e2:
	/* 0x8e2: jns    92f <trace_ret_inotify_find_inode+0x92f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e2, 0x92f, x86_l_92f);
x86_l_8e4:
	/* 0x8e4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e7:
	/* 0x8e7: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_8ec:
	/* 0x8ec: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f0:
	/* 0x8f0: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_8f5:
	/* 0x8f5: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8f9:
	/* 0x8f9: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8fe:
	/* 0x8fe: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_902:
	/* 0x902: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_907:
	/* 0x907: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_90b:
	/* 0x90b: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_910:
	/* 0x910: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_914:
	/* 0x914: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_919:
	/* 0x919: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_91d:
	/* 0x91d: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_922:
	/* 0x922: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_926:
	/* 0x926: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_92b:
	/* 0x92b: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_92f:
	/* 0x92f: lea    r15,[rbp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_933:
	/* 0x933: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_938:
	/* 0x938: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_93b:
	/* 0x93b: jns    a12 <trace_ret_inotify_find_inode+0xa12> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x93b, 0xa12, x86_l_a12);
x86_l_941:
	/* 0x941: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_944:
	/* 0x944: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_947:
	/* 0x947: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_949:
	/* 0x949: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x949, 0xa21, x86_l_a21);
x86_l_94f:
	/* 0x94f: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_953:
	/* 0x953: mov    BYTE PTR [r13+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_957:
	/* 0x957: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_959:
	/* 0x959: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x959, 0xa21, x86_l_a21);
x86_l_95f:
	/* 0x95f: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_963:
	/* 0x963: mov    BYTE PTR [r13+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_967:
	/* 0x967: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_969:
	/* 0x969: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x969, 0xa21, x86_l_a21);
x86_l_96f:
	/* 0x96f: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_973:
	/* 0x973: mov    BYTE PTR [r13+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_977:
	/* 0x977: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_979:
	/* 0x979: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x979, 0xa21, x86_l_a21);
x86_l_97f:
	/* 0x97f: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_983:
	/* 0x983: mov    BYTE PTR [r13+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_987:
	/* 0x987: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_989:
	/* 0x989: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x989, 0xa21, x86_l_a21);
x86_l_98f:
	/* 0x98f: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_993:
	/* 0x993: mov    BYTE PTR [r13+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_997:
	/* 0x997: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_999:
	/* 0x999: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x999, 0xa21, x86_l_a21);
x86_l_99f:
	/* 0x99f: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_9a3:
	/* 0x9a3: mov    BYTE PTR [r13+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_9a7:
	/* 0x9a7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a9:
	/* 0x9a9: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a9, 0xa21, x86_l_a21);
x86_l_9ab:
	/* 0x9ab: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_9af:
	/* 0x9af: mov    BYTE PTR [r13+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_9b3:
	/* 0x9b3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b5:
	/* 0x9b5: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b5, 0xa21, x86_l_a21);
x86_l_9b7:
	/* 0x9b7: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_9bb:
	/* 0x9bb: mov    BYTE PTR [r13+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_9bf:
	/* 0x9bf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9c1:
	/* 0x9c1: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c1, 0xa21, x86_l_a21);
x86_l_9c3:
	/* 0x9c3: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_9c7:
	/* 0x9c7: mov    BYTE PTR [r13+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_9cb:
	/* 0x9cb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9cd:
	/* 0x9cd: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cd, 0xa21, x86_l_a21);
x86_l_9cf:
	/* 0x9cf: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_9d3:
	/* 0x9d3: mov    BYTE PTR [r13+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_9d7:
	/* 0x9d7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d9:
	/* 0x9d9: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d9, 0xa21, x86_l_a21);
x86_l_9db:
	/* 0x9db: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_9df:
	/* 0x9df: mov    BYTE PTR [r13+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_9e3:
	/* 0x9e3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9e5:
	/* 0x9e5: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e5, 0xa21, x86_l_a21);
x86_l_9e7:
	/* 0x9e7: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_9eb:
	/* 0x9eb: mov    BYTE PTR [r13+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_9ef:
	/* 0x9ef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9f1:
	/* 0x9f1: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f1, 0xa21, x86_l_a21);
x86_l_9f3:
	/* 0x9f3: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_9f7:
	/* 0x9f7: mov    BYTE PTR [r13+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_9fb:
	/* 0x9fb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9fd:
	/* 0x9fd: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9fd, 0xa21, x86_l_a21);
x86_l_9ff:
	/* 0x9ff: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_a03:
	/* 0xa03: mov    BYTE PTR [r13+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_a07:
	/* 0xa07: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_a09:
	/* 0xa09: je     a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa09, 0xa21, x86_l_a21);
x86_l_a0b:
	/* 0xa0b: mov    BYTE PTR [r13+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_a10:
	/* 0xa10: jmp    a21 <trace_ret_inotify_find_inode+0xa21> */
	X86_SIM_X86_JMP(0xa10, 0xa21, x86_l_a21);
x86_l_a12:
	/* 0xa12: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a1a:
	/* 0xa1a: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a21:
	/* 0xa21: mov    rbx,QWORD PTR [r13+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a28:
	/* 0xa28: mov    r13,QWORD PTR [r13+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a2f:
	/* 0xa2f: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a32:
	/* 0xa32: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a38:
	/* 0xa38: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a3f:
	/* 0xa3f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a44:
	/* 0xa44: call   a49 <trace_ret_inotify_find_inode+0xa49> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a49:
	/* 0xa49: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a50:
	/* 0xa50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a53:
	/* 0xa53: je     a71 <trace_ret_inotify_find_inode+0xa71> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa53, 0xa71, x86_l_a71);
x86_l_a55:
	/* 0xa55: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a58:
	/* 0xa58: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a5b:
	/* 0xa5b: call   a60 <trace_ret_inotify_find_inode+0xa60> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a60:
	/* 0xa60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a63:
	/* 0xa63: je     a71 <trace_ret_inotify_find_inode+0xa71> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa63, 0xa71, x86_l_a71);
x86_l_a65:
	/* 0xa65: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a68:
	/* 0xa68: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a6c:
	/* 0xa6c: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a6f:
	/* 0xa6f: jmp    a73 <trace_ret_inotify_find_inode+0xa73> */
	X86_SIM_X86_JMP(0xa6f, 0xa73, x86_l_a73);
x86_l_a71:
	/* 0xa71: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a73:
	/* 0xa73: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a76:
	/* 0xa76: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a79:
	/* 0xa79: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a7c:
	/* 0xa7c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a7f:
	/* 0xa7f: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a83:
	/* 0xa83: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_a89:
	/* 0xa89: cmp    QWORD PTR [r13+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a91:
	/* 0xa91: je     b0c <trace_ret_inotify_find_inode+0xb0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa91, 0xb0c, x86_l_b0c);
x86_l_a93:
	/* 0xa93: lea    r15,[rbp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a97:
	/* 0xa97: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a9a:
	/* 0xa9a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a9f:
	/* 0xa9f: call   aa4 <trace_ret_inotify_find_inode+0xaa4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_aa4:
	/* 0xaa4: mov    rbx,QWORD PTR [r13+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_aab:
	/* 0xaab: mov    r13,QWORD PTR [r13+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_ab2:
	/* 0xab2: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ab5:
	/* 0xab5: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_abb:
	/* 0xabb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_ac2:
	/* 0xac2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ac7:
	/* 0xac7: call   acc <trace_ret_inotify_find_inode+0xacc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_acc:
	/* 0xacc: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ad3:
	/* 0xad3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad6:
	/* 0xad6: je     af4 <trace_ret_inotify_find_inode+0xaf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad6, 0xaf4, x86_l_af4);
x86_l_ad8:
	/* 0xad8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adb:
	/* 0xadb: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ade:
	/* 0xade: call   ae3 <trace_ret_inotify_find_inode+0xae3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae3:
	/* 0xae3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae6:
	/* 0xae6: je     af4 <trace_ret_inotify_find_inode+0xaf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae6, 0xaf4, x86_l_af4);
x86_l_ae8:
	/* 0xae8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aeb:
	/* 0xaeb: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aef:
	/* 0xaef: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_af2:
	/* 0xaf2: jmp    af6 <trace_ret_inotify_find_inode+0xaf6> */
	X86_SIM_X86_JMP(0xaf2, 0xaf6, x86_l_af6);
x86_l_af4:
	/* 0xaf4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_af6:
	/* 0xaf6: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_af9:
	/* 0xaf9: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_afc:
	/* 0xafc: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_aff:
	/* 0xaff: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b02:
	/* 0xb02: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b06:
	/* 0xb06: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_b0c:
	/* 0xb0c: mov    rbx,QWORD PTR [r13+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b13:
	/* 0xb13: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b16:
	/* 0xb16: je     b7f <trace_ret_inotify_find_inode+0xb7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb16, 0xb7f, x86_l_b7f);
x86_l_b18:
	/* 0xb18: mov    eax,DWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b1c:
	/* 0xb1c: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b20:
	/* 0xb20: mov    r15,QWORD PTR [r13+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b27:
	/* 0xb27: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b2a:
	/* 0xb2a: mov    WORD PTR [rsp+0x38],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_b30:
	/* 0xb30: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b37:
	/* 0xb37: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_b3c:
	/* 0xb3c: call   b41 <trace_ret_inotify_find_inode+0xb41> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b41:
	/* 0xb41: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b48:
	/* 0xb48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4b:
	/* 0xb4b: je     b6b <trace_ret_inotify_find_inode+0xb6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4b, 0xb6b, x86_l_b6b);
x86_l_b4d:
	/* 0xb4d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b52:
	/* 0xb52: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b55:
	/* 0xb55: call   b5a <trace_ret_inotify_find_inode+0xb5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b5a:
	/* 0xb5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5d:
	/* 0xb5d: je     b6b <trace_ret_inotify_find_inode+0xb6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5d, 0xb6b, x86_l_b6b);
x86_l_b5f:
	/* 0xb5f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b62:
	/* 0xb62: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b66:
	/* 0xb66: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b69:
	/* 0xb69: jmp    b6d <trace_ret_inotify_find_inode+0xb6d> */
	X86_SIM_X86_JMP(0xb69, 0xb6d, x86_l_b6d);
x86_l_b6b:
	/* 0xb6b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b6d:
	/* 0xb6d: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b70:
	/* 0xb70: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b73:
	/* 0xb73: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b76:
	/* 0xb76: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b79:
	/* 0xb79: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_b7f:
	/* 0xb7f: mov    rbx,QWORD PTR [r13+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b86:
	/* 0xb86: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b89:
	/* 0xb89: je     be9 <trace_ret_inotify_find_inode+0xbe9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb89, 0xbe9, x86_l_be9);
x86_l_b8b:
	/* 0xb8b: mov    r15,QWORD PTR [r13+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_b92:
	/* 0xb92: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b95:
	/* 0xb95: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b9b:
	/* 0xb9b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_ba2:
	/* 0xba2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ba7:
	/* 0xba7: call   bac <trace_ret_inotify_find_inode+0xbac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bac:
	/* 0xbac: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bb3:
	/* 0xbb3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bb6:
	/* 0xbb6: je     bd5 <trace_ret_inotify_find_inode+0xbd5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb6, 0xbd5, x86_l_bd5);
x86_l_bb8:
	/* 0xbb8: lea    rsi,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_bbc:
	/* 0xbbc: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbf:
	/* 0xbbf: call   bc4 <trace_ret_inotify_find_inode+0xbc4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bc4:
	/* 0xbc4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc7:
	/* 0xbc7: je     bd5 <trace_ret_inotify_find_inode+0xbd5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc7, 0xbd5, x86_l_bd5);
x86_l_bc9:
	/* 0xbc9: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bcc:
	/* 0xbcc: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bd0:
	/* 0xbd0: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bd3:
	/* 0xbd3: jmp    bd7 <trace_ret_inotify_find_inode+0xbd7> */
	X86_SIM_X86_JMP(0xbd3, 0xbd7, x86_l_bd7);
x86_l_bd5:
	/* 0xbd5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bd7:
	/* 0xbd7: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bda:
	/* 0xbda: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bdd:
	/* 0xbdd: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_be0:
	/* 0xbe0: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_be3:
	/* 0xbe3: movzx  r14d,WORD PTR [rsp+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_be9:
	/* 0xbe9: mov    rbx,QWORD PTR [r13+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_bf0:
	/* 0xbf0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bf3:
	/* 0xbf3: je     c79 <trace_ret_inotify_find_inode+0xc79> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf3, 0xc79, x86_l_c79);
x86_l_bf9:
	/* 0xbf9: mov    r13,QWORD PTR [r13+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c00:
	/* 0xc00: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c03:
	/* 0xc03: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c09:
	/* 0xc09: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_c10:
	/* 0xc10: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c15:
	/* 0xc15: call   c1a <trace_ret_inotify_find_inode+0xc1a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c1a:
	/* 0xc1a: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c21:
	/* 0xc21: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c24:
	/* 0xc24: je     c67 <trace_ret_inotify_find_inode+0xc67> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc24, 0xc67, x86_l_c67);
x86_l_c26:
	/* 0xc26: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c29:
	/* 0xc29: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c31:
	/* 0xc31: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_c35:
	/* 0xc35: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c38:
	/* 0xc38: call   c3d <trace_ret_inotify_find_inode+0xc3d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c3d:
	/* 0xc3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c40:
	/* 0xc40: jne    c5b <trace_ret_inotify_find_inode+0xc5b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc40, 0xc5b, x86_l_c5b);
x86_l_c42:
	/* 0xc42: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c4a:
	/* 0xc4a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c4e:
	/* 0xc4e: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c51:
	/* 0xc51: call   c56 <trace_ret_inotify_find_inode+0xc56> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c56:
	/* 0xc56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c59:
	/* 0xc59: je     c67 <trace_ret_inotify_find_inode+0xc67> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc59, 0xc67, x86_l_c67);
x86_l_c5b:
	/* 0xc5b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5e:
	/* 0xc5e: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c62:
	/* 0xc62: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c65:
	/* 0xc65: jmp    c69 <trace_ret_inotify_find_inode+0xc69> */
	X86_SIM_X86_JMP(0xc65, 0xc69, x86_l_c69);
x86_l_c67:
	/* 0xc67: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c69:
	/* 0xc69: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c6c:
	/* 0xc6c: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c6f:
	/* 0xc6f: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c72:
	/* 0xc72: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c75:
	/* 0xc75: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c79:
	/* 0xc79: mov    rax,QWORD PTR [r13+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c80:
	/* 0xc80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c83:
	/* 0xc83: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_c88:
	/* 0xc88: je     c99 <trace_ret_inotify_find_inode+0xc99> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc88, 0xc99, x86_l_c99);
x86_l_c8a:
	/* 0xc8a: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c92:
	/* 0xc92: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_c96:
	/* 0xc96: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c99:
	/* 0xc99: and    r12,QWORD PTR [r13+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_ca0:
	/* 0xca0: mov    rax,QWORD PTR [r13+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_ca7:
	/* 0xca7: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_caa:
	/* 0xcaa: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cb1:
	/* 0xcb1: je     311f <trace_ret_inotify_find_inode+0x311f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcb1, 0x311f, x86_l_311f);
x86_l_cb7:
	/* 0xcb7: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_cbf:
	/* 0xcbf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_cc6:
	/* 0xcc6: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ccb:
	/* 0xccb: call   cd0 <trace_ret_inotify_find_inode+0xcd0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_cd0:
	/* 0xcd0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd3:
	/* 0xcd3: je     cfd <trace_ret_inotify_find_inode+0xcfd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd3, 0xcfd, x86_l_cfd);
x86_l_cd5:
	/* 0xcd5: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd8:
	/* 0xcd8: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cdd:
	/* 0xcdd: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ce0:
	/* 0xce0: je     11f5 <trace_ret_inotify_find_inode+0x11f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xce0, 0x11f5, x86_l_11f5);
x86_l_ce6:
	/* 0xce6: lea    rax,[r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ceb:
	/* 0xceb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cee:
	/* 0xcee: jns    d18 <trace_ret_inotify_find_inode+0xd18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcee, 0xd18, x86_l_d18);
x86_l_cf0:
	/* 0xcf0: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cf3:
	/* 0xcf3: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_cf6:
	/* 0xcf6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cf9:
	/* 0xcf9: js     d23 <trace_ret_inotify_find_inode+0xd23> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcf9, 0xd23, x86_l_d23);
x86_l_cfb:
	/* 0xcfb: jmp    d2d <trace_ret_inotify_find_inode+0xd2d> */
	X86_SIM_X86_JMP(0xcfb, 0xd2d, x86_l_d2d);
x86_l_cfd:
	/* 0xcfd: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cff:
	/* 0xcff: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d04:
	/* 0xd04: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_d08:
	/* 0xd08: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d0b:
	/* 0xd0b: js     299b <trace_ret_inotify_find_inode+0x299b> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd0b, 0x299b, x86_l_299b);
x86_l_d11:
	/* 0xd11: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d13:
	/* 0xd13: jmp    299f <trace_ret_inotify_find_inode+0x299f> */
	X86_SIM_X86_JMP(0xd13, 0x299f, x86_l_299f);
x86_l_d18:
	/* 0xd18: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d1b:
	/* 0xd1b: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d1e:
	/* 0xd1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d21:
	/* 0xd21: jns    d2d <trace_ret_inotify_find_inode+0xd2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd21, 0xd2d, x86_l_d2d);
x86_l_d23:
	/* 0xd23: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d25:
	/* 0xd25: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_d27:
	/* 0xd27: jne    e34 <trace_ret_inotify_find_inode+0xe34> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd27, 0xe34, x86_l_e34);
x86_l_d2d:
	/* 0xd2d: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d30:
	/* 0xd30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d33:
	/* 0xd33: jns    d3a <trace_ret_inotify_find_inode+0xd3a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd33, 0xd3a, x86_l_d3a);
x86_l_d35:
	/* 0xd35: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d38:
	/* 0xd38: jmp    d3c <trace_ret_inotify_find_inode+0xd3c> */
	X86_SIM_X86_JMP(0xd38, 0xd3c, x86_l_d3c);
x86_l_d3a:
	/* 0xd3a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d3c:
	/* 0xd3c: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_d40:
	/* 0xd40: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d43:
	/* 0xd43: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d46:
	/* 0xd46: jns    d6a <trace_ret_inotify_find_inode+0xd6a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd46, 0xd6a, x86_l_d6a);
x86_l_d48:
	/* 0xd48: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d4b:
	/* 0xd4b: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_d4e:
	/* 0xd4e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d51:
	/* 0xd51: js     d74 <trace_ret_inotify_find_inode+0xd74> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd51, 0xd74, x86_l_d74);
x86_l_d53:
	/* 0xd53: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d55:
	/* 0xd55: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d59:
	/* 0xd59: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d5c:
	/* 0xd5c: js     d80 <trace_ret_inotify_find_inode+0xd80> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd5c, 0xd80, x86_l_d80);
x86_l_d5e:
	/* 0xd5e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d60:
	/* 0xd60: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d63:
	/* 0xd63: jne    d8c <trace_ret_inotify_find_inode+0xd8c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd63, 0xd8c, x86_l_d8c);
x86_l_d65:
	/* 0xd65: jmp    e0a <trace_ret_inotify_find_inode+0xe0a> */
	X86_SIM_X86_JMP(0xd65, 0xe0a, x86_l_e0a);
x86_l_d6a:
	/* 0xd6a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d6c:
	/* 0xd6c: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_d6f:
	/* 0xd6f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d72:
	/* 0xd72: jns    d53 <trace_ret_inotify_find_inode+0xd53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd72, 0xd53, x86_l_d53);
x86_l_d74:
	/* 0xd74: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d77:
	/* 0xd77: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d7b:
	/* 0xd7b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d7e:
	/* 0xd7e: jns    d5e <trace_ret_inotify_find_inode+0xd5e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd7e, 0xd5e, x86_l_d5e);
x86_l_d80:
	/* 0xd80: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d83:
	/* 0xd83: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d86:
	/* 0xd86: je     e0a <trace_ret_inotify_find_inode+0xe0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd86, 0xe0a, x86_l_e0a);
x86_l_d8c:
	/* 0xd8c: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d8f:
	/* 0xd8f: je     e0a <trace_ret_inotify_find_inode+0xe0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd8f, 0xe0a, x86_l_e0a);
x86_l_d91:
	/* 0xd91: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d95:
	/* 0xd95: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d98:
	/* 0xd98: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_d9e:
	/* 0xd9e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_da1:
	/* 0xda1: jns    daa <trace_ret_inotify_find_inode+0xdaa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xda1, 0xdaa, x86_l_daa);
x86_l_da3:
	/* 0xda3: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_da6:
	/* 0xda6: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_daa:
	/* 0xdaa: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_dae:
	/* 0xdae: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_db1:
	/* 0xdb1: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_db8:
	/* 0xdb8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_dbb:
	/* 0xdbb: je     119b <trace_ret_inotify_find_inode+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdbb, 0x119b, x86_l_119b);
x86_l_dc1:
	/* 0xdc1: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_dc4:
	/* 0xdc4: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_dc6:
	/* 0xdc6: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_dcc:
	/* 0xdcc: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_dcf:
	/* 0xdcf: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_dd4:
	/* 0xdd4: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_dd7:
	/* 0xdd7: jns    117f <trace_ret_inotify_find_inode+0x117f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdd7, 0x117f, x86_l_117f);
x86_l_ddd:
	/* 0xddd: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_de1:
	/* 0xde1: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_de4:
	/* 0xde4: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_de7:
	/* 0xde7: je     e9c <trace_ret_inotify_find_inode+0xe9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde7, 0xe9c, x86_l_e9c);
x86_l_ded:
	/* 0xded: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_df1:
	/* 0xdf1: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_df6:
	/* 0xdf6: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_dfa:
	/* 0xdfa: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_dfd:
	/* 0xdfd: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_e00:
	/* 0xe00: jne    de4 <trace_ret_inotify_find_inode+0xde4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe00, 0xde4, x86_l_de4);
x86_l_e02:
	/* 0xe02: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_e05:
	/* 0xe05: jmp    ea1 <trace_ret_inotify_find_inode+0xea1> */
	X86_SIM_X86_JMP(0xe05, 0xea1, x86_l_ea1);
x86_l_e0a:
	/* 0xe0a: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e0d:
	/* 0xe0d: jne    119b <trace_ret_inotify_find_inode+0x119b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe0d, 0x119b, x86_l_119b);
x86_l_e13:
	/* 0xe13: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e16:
	/* 0xe16: je     119b <trace_ret_inotify_find_inode+0x119b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe16, 0x119b, x86_l_119b);
x86_l_e1c:
	/* 0xe1c: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_e20:
	/* 0xe20: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e23:
	/* 0xe23: jns    e69 <trace_ret_inotify_find_inode+0xe69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe23, 0xe69, x86_l_e69);
x86_l_e25:
	/* 0xe25: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e28:
	/* 0xe28: jmp    e6b <trace_ret_inotify_find_inode+0xe6b> */
	X86_SIM_X86_JMP(0xe28, 0xe6b, x86_l_e6b);
x86_l_e2a:
	/* 0xe2a: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_e2f:
	/* 0xe2f: jmp    21f <trace_ret_inotify_find_inode+0x21f> */
	X86_SIM_X86_JMP(0xe2f, 0x21f, x86_l_21f);
x86_l_e34:
	/* 0xe34: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_e3b:
	/* 0xe3b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e3e:
	/* 0xe3e: jns    11b0 <trace_ret_inotify_find_inode+0x11b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe3e, 0x11b0, x86_l_11b0);
x86_l_e44:
	/* 0xe44: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e46:
	/* 0xe46: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e48:
	/* 0xe48: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_e4f:
	/* 0xe4f: je     11ee <trace_ret_inotify_find_inode+0x11ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4f, 0x11ee, x86_l_11ee);
x86_l_e55:
	/* 0xe55: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_e59:
	/* 0xe59: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_e5d:
	/* 0xe5d: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e60:
	/* 0xe60: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_e62:
	/* 0xe62: jne    e48 <trace_ret_inotify_find_inode+0xe48> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe62, 0xe48, x86_l_e48);
x86_l_e64:
	/* 0xe64: jmp    2985 <trace_ret_inotify_find_inode+0x2985> */
	X86_SIM_X86_JMP(0xe64, 0x2985, x86_l_2985);
x86_l_e69:
	/* 0xe69: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e6b:
	/* 0xe6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e6e:
	/* 0xe6e: jns    e75 <trace_ret_inotify_find_inode+0xe75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe6e, 0xe75, x86_l_e75);
x86_l_e70:
	/* 0xe70: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e73:
	/* 0xe73: jmp    e77 <trace_ret_inotify_find_inode+0xe77> */
	X86_SIM_X86_JMP(0xe73, 0xe77, x86_l_e77);
x86_l_e75:
	/* 0xe75: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e77:
	/* 0xe77: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e7a:
	/* 0xe7a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e7d:
	/* 0xe7d: jns    e84 <trace_ret_inotify_find_inode+0xe84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe7d, 0xe84, x86_l_e84);
x86_l_e7f:
	/* 0xe7f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e82:
	/* 0xe82: jmp    e86 <trace_ret_inotify_find_inode+0xe86> */
	X86_SIM_X86_JMP(0xe82, 0xe86, x86_l_e86);
x86_l_e84:
	/* 0xe84: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e86:
	/* 0xe86: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e8a:
	/* 0xe8a: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e8f:
	/* 0xe8f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e92:
	/* 0xe92: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e95:
	/* 0xe95: jns    ec2 <trace_ret_inotify_find_inode+0xec2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe95, 0xec2, x86_l_ec2);
x86_l_e97:
	/* 0xe97: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e9a:
	/* 0xe9a: jmp    ec4 <trace_ret_inotify_find_inode+0xec4> */
	X86_SIM_X86_JMP(0xe9a, 0xec4, x86_l_ec4);
x86_l_e9c:
	/* 0xe9c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_ea1:
	/* 0xea1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_ea5:
	/* 0xea5: jl     119b <trace_ret_inotify_find_inode+0x119b> */
	X86_SIM_X86_JCC(X86_CC_L, 0xea5, 0x119b, x86_l_119b);
x86_l_eab:
	/* 0xeab: mov    BYTE PTR [rbp+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_eb2:
	/* 0xeb2: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_eb7:
	/* 0xeb7: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_eba:
	/* 0xeba: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ebd:
	/* 0xebd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ec0:
	/* 0xec0: js     e97 <trace_ret_inotify_find_inode+0xe97> */
	X86_SIM_X86_JCC(X86_CC_S, 0xec0, 0xe97, x86_l_e97);
x86_l_ec2:
	/* 0xec2: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ec4:
	/* 0xec4: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ec8:
	/* 0xec8: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_ecb:
	/* 0xecb: jns    ed2 <trace_ret_inotify_find_inode+0xed2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xecb, 0xed2, x86_l_ed2);
x86_l_ecd:
	/* 0xecd: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ed0:
	/* 0xed0: jmp    ed5 <trace_ret_inotify_find_inode+0xed5> */
	X86_SIM_X86_JMP(0xed0, 0xed5, x86_l_ed5);
x86_l_ed2:
	/* 0xed2: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ed5:
	/* 0xed5: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ed8:
	/* 0xed8: je     f5b <trace_ret_inotify_find_inode+0xf5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed8, 0xf5b, x86_l_f5b);
x86_l_ede:
	/* 0xede: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ee1:
	/* 0xee1: je     f5b <trace_ret_inotify_find_inode+0xf5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xee1, 0xf5b, x86_l_f5b);
x86_l_ee3:
	/* 0xee3: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ee7:
	/* 0xee7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eea:
	/* 0xeea: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_ef0:
	/* 0xef0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ef3:
	/* 0xef3: jns    efc <trace_ret_inotify_find_inode+0xefc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xef3, 0xefc, x86_l_efc);
x86_l_ef5:
	/* 0xef5: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef8:
	/* 0xef8: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_efc:
	/* 0xefc: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_f00:
	/* 0xf00: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_f03:
	/* 0xf03: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_f0a:
	/* 0xf0a: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_f0c:
	/* 0xf0c: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f0f:
	/* 0xf0f: jb     2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf0f, 0x2970, x86_l_2970);
x86_l_f15:
	/* 0xf15: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_f18:
	/* 0xf18: je     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf18, 0x118c, x86_l_118c);
x86_l_f1e:
	/* 0xf1e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_f24:
	/* 0xf24: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_f27:
	/* 0xf27: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_f2a:
	/* 0xf2a: jns    117c <trace_ret_inotify_find_inode+0x117c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf2a, 0x117c, x86_l_117c);
x86_l_f30:
	/* 0xf30: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f34:
	/* 0xf34: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f37:
	/* 0xf37: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_f3a:
	/* 0xf3a: je     faa <trace_ret_inotify_find_inode+0xfaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf3a, 0xfaa, x86_l_faa);
x86_l_f3c:
	/* 0xf3c: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_f40:
	/* 0xf40: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_f45:
	/* 0xf45: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_f49:
	/* 0xf49: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f4c:
	/* 0xf4c: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_f4f:
	/* 0xf4f: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f54:
	/* 0xf54: jne    f37 <trace_ret_inotify_find_inode+0xf37> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf54, 0xf37, x86_l_f37);
x86_l_f56:
	/* 0xf56: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_f59:
	/* 0xf59: jmp    faf <trace_ret_inotify_find_inode+0xfaf> */
	X86_SIM_X86_JMP(0xf59, 0xfaf, x86_l_faf);
x86_l_f5b:
	/* 0xf5b: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f5e:
	/* 0xf5e: jne    118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf5e, 0x118c, x86_l_118c);
x86_l_f64:
	/* 0xf64: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f67:
	/* 0xf67: je     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf67, 0x118c, x86_l_118c);
x86_l_f6d:
	/* 0xf6d: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f71:
	/* 0xf71: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f74:
	/* 0xf74: jns    f7b <trace_ret_inotify_find_inode+0xf7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf74, 0xf7b, x86_l_f7b);
x86_l_f76:
	/* 0xf76: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f79:
	/* 0xf79: jmp    f7e <trace_ret_inotify_find_inode+0xf7e> */
	X86_SIM_X86_JMP(0xf79, 0xf7e, x86_l_f7e);
x86_l_f7b:
	/* 0xf7b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f7e:
	/* 0xf7e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f81:
	/* 0xf81: jns    f88 <trace_ret_inotify_find_inode+0xf88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf81, 0xf88, x86_l_f88);
x86_l_f83:
	/* 0xf83: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f86:
	/* 0xf86: jmp    f8a <trace_ret_inotify_find_inode+0xf8a> */
	X86_SIM_X86_JMP(0xf86, 0xf8a, x86_l_f8a);
x86_l_f88:
	/* 0xf88: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8a:
	/* 0xf8a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f8d:
	/* 0xf8d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f90:
	/* 0xf90: jns    f97 <trace_ret_inotify_find_inode+0xf97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf90, 0xf97, x86_l_f97);
x86_l_f92:
	/* 0xf92: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f95:
	/* 0xf95: jmp    f99 <trace_ret_inotify_find_inode+0xf99> */
	X86_SIM_X86_JMP(0xf95, 0xf99, x86_l_f99);
x86_l_f97:
	/* 0xf97: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f99:
	/* 0xf99: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f9d:
	/* 0xf9d: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_fa0:
	/* 0xfa0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fa3:
	/* 0xfa3: jns    fd2 <trace_ret_inotify_find_inode+0xfd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfa3, 0xfd2, x86_l_fd2);
x86_l_fa5:
	/* 0xfa5: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fa8:
	/* 0xfa8: jmp    fd4 <trace_ret_inotify_find_inode+0xfd4> */
	X86_SIM_X86_JMP(0xfa8, 0xfd4, x86_l_fd4);
x86_l_faa:
	/* 0xfaa: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_faf:
	/* 0xfaf: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_fb3:
	/* 0xfb3: jl     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_L, 0xfb3, 0x118c, x86_l_118c);
x86_l_fb9:
	/* 0xfb9: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_fbc:
	/* 0xfbc: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_fc2:
	/* 0xfc2: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_fc7:
	/* 0xfc7: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_fca:
	/* 0xfca: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_fcd:
	/* 0xfcd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fd0:
	/* 0xfd0: js     fa5 <trace_ret_inotify_find_inode+0xfa5> */
	X86_SIM_X86_JCC(X86_CC_S, 0xfd0, 0xfa5, x86_l_fa5);
x86_l_fd2:
	/* 0xfd2: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fd4:
	/* 0xfd4: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fd8:
	/* 0xfd8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fdb:
	/* 0xfdb: jns    fe2 <trace_ret_inotify_find_inode+0xfe2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfdb, 0xfe2, x86_l_fe2);
x86_l_fdd:
	/* 0xfdd: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fe0:
	/* 0xfe0: jmp    fe4 <trace_ret_inotify_find_inode+0xfe4> */
	X86_SIM_X86_JMP(0xfe0, 0xfe4, x86_l_fe4);
x86_l_fe2:
	/* 0xfe2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fe4:
	/* 0xfe4: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fe7:
	/* 0xfe7: je     106a <trace_ret_inotify_find_inode+0x106a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe7, 0x106a, x86_l_106a);
x86_l_fed:
	/* 0xfed: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ff0:
	/* 0xff0: je     106a <trace_ret_inotify_find_inode+0x106a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff0, 0x106a, x86_l_106a);
x86_l_ff2:
	/* 0xff2: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ff6:
	/* 0xff6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ff9:
	/* 0xff9: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_fff:
	/* 0xfff: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1002:
	/* 0x1002: jns    100b <trace_ret_inotify_find_inode+0x100b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1002, 0x100b, x86_l_100b);
x86_l_1004:
	/* 0x1004: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1007:
	/* 0x1007: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_100b:
	/* 0x100b: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_100f:
	/* 0x100f: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1012:
	/* 0x1012: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1019:
	/* 0x1019: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_101b:
	/* 0x101b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_101e:
	/* 0x101e: jb     2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_B, 0x101e, 0x2970, x86_l_2970);
x86_l_1024:
	/* 0x1024: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1027:
	/* 0x1027: je     1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1027, 0x1189, x86_l_1189);
x86_l_102d:
	/* 0x102d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1033:
	/* 0x1033: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1036:
	/* 0x1036: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1039:
	/* 0x1039: jns    117f <trace_ret_inotify_find_inode+0x117f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1039, 0x117f, x86_l_117f);
x86_l_103f:
	/* 0x103f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1043:
	/* 0x1043: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1046:
	/* 0x1046: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1049:
	/* 0x1049: je     10b8 <trace_ret_inotify_find_inode+0x10b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1049, 0x10b8, x86_l_10b8);
x86_l_104b:
	/* 0x104b: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_104f:
	/* 0x104f: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1054:
	/* 0x1054: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1058:
	/* 0x1058: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_105b:
	/* 0x105b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_105e:
	/* 0x105e: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1063:
	/* 0x1063: jne    1046 <trace_ret_inotify_find_inode+0x1046> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1063, 0x1046, x86_l_1046);
x86_l_1065:
	/* 0x1065: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1068:
	/* 0x1068: jmp    10bd <trace_ret_inotify_find_inode+0x10bd> */
	X86_SIM_X86_JMP(0x1068, 0x10bd, x86_l_10bd);
x86_l_106a:
	/* 0x106a: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_106d:
	/* 0x106d: jne    1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x106d, 0x1189, x86_l_1189);
x86_l_1073:
	/* 0x1073: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1076:
	/* 0x1076: je     1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1076, 0x1189, x86_l_1189);
x86_l_107c:
	/* 0x107c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1080:
	/* 0x1080: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1083:
	/* 0x1083: jns    108a <trace_ret_inotify_find_inode+0x108a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1083, 0x108a, x86_l_108a);
x86_l_1085:
	/* 0x1085: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1088:
	/* 0x1088: jmp    108c <trace_ret_inotify_find_inode+0x108c> */
	X86_SIM_X86_JMP(0x1088, 0x108c, x86_l_108c);
x86_l_108a:
	/* 0x108a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108c:
	/* 0x108c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_108f:
	/* 0x108f: jns    1096 <trace_ret_inotify_find_inode+0x1096> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x108f, 0x1096, x86_l_1096);
x86_l_1091:
	/* 0x1091: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1094:
	/* 0x1094: jmp    1098 <trace_ret_inotify_find_inode+0x1098> */
	X86_SIM_X86_JMP(0x1094, 0x1098, x86_l_1098);
x86_l_1096:
	/* 0x1096: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1098:
	/* 0x1098: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_109b:
	/* 0x109b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_109e:
	/* 0x109e: jns    10a5 <trace_ret_inotify_find_inode+0x10a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x109e, 0x10a5, x86_l_10a5);
x86_l_10a0:
	/* 0x10a0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10a3:
	/* 0x10a3: jmp    10a7 <trace_ret_inotify_find_inode+0x10a7> */
	X86_SIM_X86_JMP(0x10a3, 0x10a7, x86_l_10a7);
x86_l_10a5:
	/* 0x10a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10a7:
	/* 0x10a7: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10ab:
	/* 0x10ab: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10ae:
	/* 0x10ae: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10b1:
	/* 0x10b1: jns    10e0 <trace_ret_inotify_find_inode+0x10e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b1, 0x10e0, x86_l_10e0);
x86_l_10b3:
	/* 0x10b3: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b6:
	/* 0x10b6: jmp    10e2 <trace_ret_inotify_find_inode+0x10e2> */
	X86_SIM_X86_JMP(0x10b6, 0x10e2, x86_l_10e2);
x86_l_10b8:
	/* 0x10b8: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_10bd:
	/* 0x10bd: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_10c1:
	/* 0x10c1: jl     1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_L, 0x10c1, 0x1189, x86_l_1189);
x86_l_10c7:
	/* 0x10c7: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10ca:
	/* 0x10ca: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_10d0:
	/* 0x10d0: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_10d5:
	/* 0x10d5: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10d8:
	/* 0x10d8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10db:
	/* 0x10db: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10de:
	/* 0x10de: js     10b3 <trace_ret_inotify_find_inode+0x10b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10de, 0x10b3, x86_l_10b3);
x86_l_10e0:
	/* 0x10e0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10e2:
	/* 0x10e2: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10e6:
	/* 0x10e6: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_10e9:
	/* 0x10e9: jns    10f0 <trace_ret_inotify_find_inode+0x10f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10e9, 0x10f0, x86_l_10f0);
x86_l_10eb:
	/* 0x10eb: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10ee:
	/* 0x10ee: jmp    10f3 <trace_ret_inotify_find_inode+0x10f3> */
	X86_SIM_X86_JMP(0x10ee, 0x10f3, x86_l_10f3);
x86_l_10f0:
	/* 0x10f0: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10f3:
	/* 0x10f3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10f6:
	/* 0x10f6: je     11fc <trace_ret_inotify_find_inode+0x11fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10f6, 0x11fc, x86_l_11fc);
x86_l_10fc:
	/* 0x10fc: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10ff:
	/* 0x10ff: je     11fc <trace_ret_inotify_find_inode+0x11fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10ff, 0x11fc, x86_l_11fc);
x86_l_1105:
	/* 0x1105: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1109:
	/* 0x1109: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_110c:
	/* 0x110c: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1112:
	/* 0x1112: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1115:
	/* 0x1115: jns    111e <trace_ret_inotify_find_inode+0x111e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1115, 0x111e, x86_l_111e);
x86_l_1117:
	/* 0x1117: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_111a:
	/* 0x111a: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_111e:
	/* 0x111e: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1122:
	/* 0x1122: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1125:
	/* 0x1125: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_112c:
	/* 0x112c: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_112e:
	/* 0x112e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1131:
	/* 0x1131: jb     2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1131, 0x2970, x86_l_2970);
x86_l_1137:
	/* 0x1137: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_113a:
	/* 0x113a: je     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x113a, 0x118c, x86_l_118c);
x86_l_113c:
	/* 0x113c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1142:
	/* 0x1142: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1145:
	/* 0x1145: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1148:
	/* 0x1148: jns    117c <trace_ret_inotify_find_inode+0x117c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1148, 0x117c, x86_l_117c);
x86_l_114a:
	/* 0x114a: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_114e:
	/* 0x114e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1151:
	/* 0x1151: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1154:
	/* 0x1154: je     1694 <trace_ret_inotify_find_inode+0x1694> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1154, 0x1694, x86_l_1694);
x86_l_115a:
	/* 0x115a: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_115e:
	/* 0x115e: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1163:
	/* 0x1163: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1167:
	/* 0x1167: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_116a:
	/* 0x116a: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_116d:
	/* 0x116d: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1172:
	/* 0x1172: jne    1151 <trace_ret_inotify_find_inode+0x1151> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1172, 0x1151, x86_l_1151);
x86_l_1174:
	/* 0x1174: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1177:
	/* 0x1177: jmp    1699 <trace_ret_inotify_find_inode+0x1699> */
	X86_SIM_X86_JMP(0x1177, 0x1699, x86_l_1699);
x86_l_117c:
	/* 0x117c: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_117f:
	/* 0x117f: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1182:
	/* 0x1182: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1184:
	/* 0x1184: call   1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1189:
	/* 0x1189: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_118c:
	/* 0x118c: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_118f:
	/* 0x118f: cmp    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1195:
	/* 0x1195: jne    2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1195, 0x2970, x86_l_2970);
x86_l_119b:
	/* 0x119b: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_119f:
	/* 0x119f: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11a2:
	/* 0x11a2: jns    11c6 <trace_ret_inotify_find_inode+0x11c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11a2, 0x11c6, x86_l_11c6);
x86_l_11a4:
	/* 0x11a4: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11a7:
	/* 0x11a7: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11ab:
	/* 0x11ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11ae:
	/* 0x11ae: js     11cd <trace_ret_inotify_find_inode+0x11cd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11ae, 0x11cd, x86_l_11cd);
x86_l_11b0:
	/* 0x11b0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b2:
	/* 0x11b2: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_11b7:
	/* 0x11b7: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_11ba:
	/* 0x11ba: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11bc:
	/* 0x11bc: call   11c1 <trace_ret_inotify_find_inode+0x11c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_11c1:
	/* 0x11c1: jmp    2985 <trace_ret_inotify_find_inode+0x2985> */
	X86_SIM_X86_JMP(0x11c1, 0x2985, x86_l_2985);
x86_l_11c6:
	/* 0x11c6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c8:
	/* 0x11c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11cb:
	/* 0x11cb: jns    11b0 <trace_ret_inotify_find_inode+0x11b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11cb, 0x11b0, x86_l_11b0);
x86_l_11cd:
	/* 0x11cd: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11cf:
	/* 0x11cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11d1:
	/* 0x11d1: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_11d8:
	/* 0x11d8: je     11ee <trace_ret_inotify_find_inode+0x11ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d8, 0x11ee, x86_l_11ee);
x86_l_11da:
	/* 0x11da: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_11de:
	/* 0x11de: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11e2:
	/* 0x11e2: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_11e5:
	/* 0x11e5: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_11e7:
	/* 0x11e7: jne    11d1 <trace_ret_inotify_find_inode+0x11d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11e7, 0x11d1, x86_l_11d1);
x86_l_11e9:
	/* 0x11e9: jmp    2985 <trace_ret_inotify_find_inode+0x2985> */
	X86_SIM_X86_JMP(0x11e9, 0x2985, x86_l_2985);
x86_l_11ee:
	/* 0x11ee: mov    BYTE PTR [rbp+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_11f5:
	/* 0x11f5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11f7:
	/* 0x11f7: jmp    2985 <trace_ret_inotify_find_inode+0x2985> */
	X86_SIM_X86_JMP(0x11f7, 0x2985, x86_l_2985);
x86_l_11fc:
	/* 0x11fc: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11ff:
	/* 0x11ff: jne    118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11ff, 0x118c, x86_l_118c);
x86_l_1201:
	/* 0x1201: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1204:
	/* 0x1204: je     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1204, 0x118c, x86_l_118c);
x86_l_1206:
	/* 0x1206: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_120a:
	/* 0x120a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_120d:
	/* 0x120d: jns    1214 <trace_ret_inotify_find_inode+0x1214> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x120d, 0x1214, x86_l_1214);
x86_l_120f:
	/* 0x120f: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1212:
	/* 0x1212: jmp    1217 <trace_ret_inotify_find_inode+0x1217> */
	X86_SIM_X86_JMP(0x1212, 0x1217, x86_l_1217);
x86_l_1214:
	/* 0x1214: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1217:
	/* 0x1217: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_121a:
	/* 0x121a: jns    1221 <trace_ret_inotify_find_inode+0x1221> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x121a, 0x1221, x86_l_1221);
x86_l_121c:
	/* 0x121c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_121f:
	/* 0x121f: jmp    1223 <trace_ret_inotify_find_inode+0x1223> */
	X86_SIM_X86_JMP(0x121f, 0x1223, x86_l_1223);
x86_l_1221:
	/* 0x1221: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1223:
	/* 0x1223: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1226:
	/* 0x1226: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1229:
	/* 0x1229: jns    1230 <trace_ret_inotify_find_inode+0x1230> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1229, 0x1230, x86_l_1230);
x86_l_122b:
	/* 0x122b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_122e:
	/* 0x122e: jmp    1232 <trace_ret_inotify_find_inode+0x1232> */
	X86_SIM_X86_JMP(0x122e, 0x1232, x86_l_1232);
x86_l_1230:
	/* 0x1230: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1232:
	/* 0x1232: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1236:
	/* 0x1236: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1239:
	/* 0x1239: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_123c:
	/* 0x123c: jns    16c0 <trace_ret_inotify_find_inode+0x16c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x123c, 0x16c0, x86_l_16c0);
x86_l_1242:
	/* 0x1242: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1245:
	/* 0x1245: jmp    16c2 <trace_ret_inotify_find_inode+0x16c2> */
	X86_SIM_X86_JMP(0x1245, 0x16c2, x86_l_16c2);
x86_l_124a:
	/* 0x124a: mov    eax,DWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1251:
	/* 0x1251: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1255:
	/* 0x1255: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_125d:
	/* 0x125d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1264:
	/* 0x1264: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1269:
	/* 0x1269: call   126e <trace_ret_inotify_find_inode+0x126e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_126e:
	/* 0x126e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1271:
	/* 0x1271: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1271, 0x1365, x86_l_1365);
x86_l_1277:
	/* 0x1277: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_127a:
	/* 0x127a: mov    eax,DWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_127e:
	/* 0x127e: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1282:
	/* 0x1282: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1287:
	/* 0x1287: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_128a:
	/* 0x128a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_128c:
	/* 0x128c: call   1291 <trace_ret_inotify_find_inode+0x1291> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_1291:
	/* 0x1291: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1298:
	/* 0x1298: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_129d:
	/* 0x129d: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12a2:
	/* 0x12a2: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12a5:
	/* 0x12a5: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12a8:
	/* 0x12a8: call   12ad <trace_ret_inotify_find_inode+0x12ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_12ad:
	/* 0x12ad: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12b2:
	/* 0x12b2: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12b5:
	/* 0x12b5: call   12ba <trace_ret_inotify_find_inode+0x12ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12ba:
	/* 0x12ba: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_12c2:
	/* 0x12c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12c5:
	/* 0x12c5: jne    253 <trace_ret_inotify_find_inode+0x253> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12c5, 0x253, x86_l_253);
x86_l_12cb:
	/* 0x12cb: jmp    1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JMP(0x12cb, 0x1365, x86_l_1365);
x86_l_12d0:
	/* 0x12d0: mov    eax,DWORD PTR [rsp+0x9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_12d7:
	/* 0x12d7: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12db:
	/* 0x12db: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_12e3:
	/* 0x12e3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_12ea:
	/* 0x12ea: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_12ef:
	/* 0x12ef: call   12f4 <trace_ret_inotify_find_inode+0x12f4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12f4:
	/* 0x12f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12f7:
	/* 0x12f7: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f7, 0x1365, x86_l_1365);
x86_l_12f9:
	/* 0x12f9: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12fc:
	/* 0x12fc: mov    eax,DWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1300:
	/* 0x1300: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1304:
	/* 0x1304: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_1309:
	/* 0x1309: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_130c:
	/* 0x130c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_130e:
	/* 0x130e: call   1313 <trace_ret_inotify_find_inode+0x1313> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_1313:
	/* 0x1313: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_131a:
	/* 0x131a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_131f:
	/* 0x131f: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1324:
	/* 0x1324: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1327:
	/* 0x1327: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_132a:
	/* 0x132a: call   132f <trace_ret_inotify_find_inode+0x132f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_132f:
	/* 0x132f: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1334:
	/* 0x1334: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1337:
	/* 0x1337: call   133c <trace_ret_inotify_find_inode+0x133c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_133c:
	/* 0x133c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1341:
	/* 0x1341: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1344:
	/* 0x1344: je     1365 <trace_ret_inotify_find_inode+0x1365> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1344, 0x1365, x86_l_1365);
x86_l_1346:
	/* 0x1346: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_134d:
	/* 0x134d: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1351:
	/* 0x1351: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1354:
	/* 0x1354: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1357:
	/* 0x1357: jns    1538 <trace_ret_inotify_find_inode+0x1538> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1357, 0x1538, x86_l_1538);
x86_l_135d:
	/* 0x135d: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1360:
	/* 0x1360: jmp    153b <trace_ret_inotify_find_inode+0x153b> */
	X86_SIM_X86_JMP(0x1360, 0x153b, x86_l_153b);
x86_l_1365:
	/* 0x1365: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1367:
	/* 0x1367: jmp    311f <trace_ret_inotify_find_inode+0x311f> */
	X86_SIM_X86_JMP(0x1367, 0x311f, x86_l_311f);
x86_l_136c:
	/* 0x136c: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_136f:
	/* 0x136f: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1373:
	/* 0x1373: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1376:
	/* 0x1376: jns    151b <trace_ret_inotify_find_inode+0x151b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1376, 0x151b, x86_l_151b);
x86_l_137c:
	/* 0x137c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137f:
	/* 0x137f: mov    QWORD PTR [r13+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1386:
	/* 0x1386: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_138a:
	/* 0x138a: mov    QWORD PTR [r13+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1391:
	/* 0x1391: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1395:
	/* 0x1395: mov    QWORD PTR [r13+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_139c:
	/* 0x139c: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_13a0:
	/* 0x13a0: mov    QWORD PTR [r13+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_13a7:
	/* 0x13a7: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13ab:
	/* 0x13ab: mov    QWORD PTR [r13+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_13b2:
	/* 0x13b2: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13b6:
	/* 0x13b6: mov    QWORD PTR [r13+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_13bd:
	/* 0x13bd: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13c1:
	/* 0x13c1: mov    QWORD PTR [r13+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_13c8:
	/* 0x13c8: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_13cc:
	/* 0x13cc: mov    QWORD PTR [r13+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_13d3:
	/* 0x13d3: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13d7:
	/* 0x13d7: mov    QWORD PTR [r13+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_13de:
	/* 0x13de: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_13e2:
	/* 0x13e2: mov    QWORD PTR [r13+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_13e9:
	/* 0x13e9: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13ed:
	/* 0x13ed: mov    QWORD PTR [r13+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_13f4:
	/* 0x13f4: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_13f8:
	/* 0x13f8: mov    QWORD PTR [r13+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_13ff:
	/* 0x13ff: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1403:
	/* 0x1403: mov    QWORD PTR [r13+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_140a:
	/* 0x140a: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_140e:
	/* 0x140e: mov    QWORD PTR [r13+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1415:
	/* 0x1415: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1419:
	/* 0x1419: mov    QWORD PTR [r13+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1420:
	/* 0x1420: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1424:
	/* 0x1424: mov    QWORD PTR [r13+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_142b:
	/* 0x142b: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1432:
	/* 0x1432: mov    QWORD PTR [r13+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_1439:
	/* 0x1439: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1440:
	/* 0x1440: mov    QWORD PTR [r13+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1447:
	/* 0x1447: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_144e:
	/* 0x144e: mov    QWORD PTR [r13+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_1455:
	/* 0x1455: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_145c:
	/* 0x145c: mov    QWORD PTR [r13+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1463:
	/* 0x1463: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_146a:
	/* 0x146a: mov    QWORD PTR [r13+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1471:
	/* 0x1471: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1478:
	/* 0x1478: mov    QWORD PTR [r13+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_147f:
	/* 0x147f: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1486:
	/* 0x1486: mov    QWORD PTR [r13+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_148d:
	/* 0x148d: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1494:
	/* 0x1494: mov    QWORD PTR [r13+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_149b:
	/* 0x149b: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_14a2:
	/* 0x14a2: mov    QWORD PTR [r13+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_14a9:
	/* 0x14a9: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_14b0:
	/* 0x14b0: mov    QWORD PTR [r13+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_14b7:
	/* 0x14b7: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_14be:
	/* 0x14be: mov    QWORD PTR [r13+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_14c5:
	/* 0x14c5: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_14cc:
	/* 0x14cc: mov    QWORD PTR [r13+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_14d3:
	/* 0x14d3: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_14da:
	/* 0x14da: mov    QWORD PTR [r13+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_14e1:
	/* 0x14e1: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_14e8:
	/* 0x14e8: mov    QWORD PTR [r13+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_14ef:
	/* 0x14ef: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_14f6:
	/* 0x14f6: mov    QWORD PTR [r13+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_14fd:
	/* 0x14fd: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1504:
	/* 0x1504: mov    QWORD PTR [r13+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_150b:
	/* 0x150b: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1511:
	/* 0x1511: mov    WORD PTR [r13+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1516:
	/* 0x1516: jmp    347 <trace_ret_inotify_find_inode+0x347> */
	X86_SIM_X86_JMP(0x1516, 0x347, x86_l_347);
x86_l_151b:
	/* 0x151b: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1522:
	/* 0x1522: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1524:
	/* 0x1524: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1529:
	/* 0x1529: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_152c:
	/* 0x152c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_152e:
	/* 0x152e: call   1533 <trace_ret_inotify_find_inode+0x1533> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1533:
	/* 0x1533: jmp    311f <trace_ret_inotify_find_inode+0x311f> */
	X86_SIM_X86_JMP(0x1533, 0x311f, x86_l_311f);
x86_l_1538:
	/* 0x1538: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_153b:
	/* 0x153b: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_153f:
	/* 0x153f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1542:
	/* 0x1542: jns    1549 <trace_ret_inotify_find_inode+0x1549> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1542, 0x1549, x86_l_1549);
x86_l_1544:
	/* 0x1544: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1547:
	/* 0x1547: jmp    154b <trace_ret_inotify_find_inode+0x154b> */
	X86_SIM_X86_JMP(0x1547, 0x154b, x86_l_154b);
x86_l_1549:
	/* 0x1549: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_154b:
	/* 0x154b: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_154f:
	/* 0x154f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1551:
	/* 0x1551: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1554:
	/* 0x1554: jns    155b <trace_ret_inotify_find_inode+0x155b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1554, 0x155b, x86_l_155b);
x86_l_1556:
	/* 0x1556: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1559:
	/* 0x1559: jmp    155e <trace_ret_inotify_find_inode+0x155e> */
	X86_SIM_X86_JMP(0x1559, 0x155e, x86_l_155e);
x86_l_155b:
	/* 0x155b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_155e:
	/* 0x155e: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1563:
	/* 0x1563: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1566:
	/* 0x1566: jns    156a <trace_ret_inotify_find_inode+0x156a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1566, 0x156a, x86_l_156a);
x86_l_1568:
	/* 0x1568: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_156a:
	/* 0x156a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_156f:
	/* 0x156f: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1572:
	/* 0x1572: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1576:
	/* 0x1576: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1579:
	/* 0x1579: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157b:
	/* 0x157b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: jns    1585 <trace_ret_inotify_find_inode+0x1585> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157e, 0x1585, x86_l_1585);
x86_l_1580:
	/* 0x1580: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1583:
	/* 0x1583: jmp    1587 <trace_ret_inotify_find_inode+0x1587> */
	X86_SIM_X86_JMP(0x1583, 0x1587, x86_l_1587);
x86_l_1585:
	/* 0x1585: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1587:
	/* 0x1587: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_158a:
	/* 0x158a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_158d:
	/* 0x158d: jns    1591 <trace_ret_inotify_find_inode+0x1591> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x158d, 0x1591, x86_l_1591);
x86_l_158f:
	/* 0x158f: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1591:
	/* 0x1591: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1593:
	/* 0x1593: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1597:
	/* 0x1597: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_159a:
	/* 0x159a: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_159e:
	/* 0x159e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a0:
	/* 0x15a0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15a3:
	/* 0x15a3: jns    15a7 <trace_ret_inotify_find_inode+0x15a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15a3, 0x15a7, x86_l_15a7);
x86_l_15a5:
	/* 0x15a5: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15a7:
	/* 0x15a7: mov    rsi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15ac:
	/* 0x15ac: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_15af:
	/* 0x15af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15b2:
	/* 0x15b2: jns    15b9 <trace_ret_inotify_find_inode+0x15b9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15b2, 0x15b9, x86_l_15b9);
x86_l_15b4:
	/* 0x15b4: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b7:
	/* 0x15b7: jmp    15bb <trace_ret_inotify_find_inode+0x15bb> */
	X86_SIM_X86_JMP(0x15b7, 0x15bb, x86_l_15bb);
x86_l_15b9:
	/* 0x15b9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15bb:
	/* 0x15bb: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15bf:
	/* 0x15bf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c1:
	/* 0x15c1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15c4:
	/* 0x15c4: jns    15cb <trace_ret_inotify_find_inode+0x15cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c4, 0x15cb, x86_l_15cb);
x86_l_15c6:
	/* 0x15c6: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15c9:
	/* 0x15c9: jmp    15cd <trace_ret_inotify_find_inode+0x15cd> */
	X86_SIM_X86_JMP(0x15c9, 0x15cd, x86_l_15cd);
x86_l_15cb:
	/* 0x15cb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15cd:
	/* 0x15cd: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15d0:
	/* 0x15d0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15d3:
	/* 0x15d3: jns    15d7 <trace_ret_inotify_find_inode+0x15d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15d3, 0x15d7, x86_l_15d7);
x86_l_15d5:
	/* 0x15d5: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d7:
	/* 0x15d7: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15d9:
	/* 0x15d9: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15dd:
	/* 0x15dd: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15e0:
	/* 0x15e0: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_15e4:
	/* 0x15e4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15e6:
	/* 0x15e6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15e9:
	/* 0x15e9: jns    15ed <trace_ret_inotify_find_inode+0x15ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15e9, 0x15ed, x86_l_15ed);
x86_l_15eb:
	/* 0x15eb: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ed:
	/* 0x15ed: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15f2:
	/* 0x15f2: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15f5:
	/* 0x15f5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15f7:
	/* 0x15f7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: jns    1601 <trace_ret_inotify_find_inode+0x1601> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15fa, 0x1601, x86_l_1601);
x86_l_15fc:
	/* 0x15fc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ff:
	/* 0x15ff: jmp    1603 <trace_ret_inotify_find_inode+0x1603> */
	X86_SIM_X86_JMP(0x15ff, 0x1603, x86_l_1603);
x86_l_1601:
	/* 0x1601: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1603:
	/* 0x1603: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1606:
	/* 0x1606: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1609:
	/* 0x1609: jns    160d <trace_ret_inotify_find_inode+0x160d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1609, 0x160d, x86_l_160d);
x86_l_160b:
	/* 0x160b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160d:
	/* 0x160d: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_160f:
	/* 0x160f: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1613:
	/* 0x1613: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1616:
	/* 0x1616: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_161a:
	/* 0x161a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_161c:
	/* 0x161c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_161f:
	/* 0x161f: jns    1626 <trace_ret_inotify_find_inode+0x1626> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161f, 0x1626, x86_l_1626);
x86_l_1621:
	/* 0x1621: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1624:
	/* 0x1624: jmp    1628 <trace_ret_inotify_find_inode+0x1628> */
	X86_SIM_X86_JMP(0x1624, 0x1628, x86_l_1628);
x86_l_1626:
	/* 0x1626: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1628:
	/* 0x1628: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_162c:
	/* 0x162c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_162f:
	/* 0x162f: jns    1633 <trace_ret_inotify_find_inode+0x1633> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162f, 0x1633, x86_l_1633);
x86_l_1631:
	/* 0x1631: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1633:
	/* 0x1633: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1638:
	/* 0x1638: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_163b:
	/* 0x163b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_163d:
	/* 0x163d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1640:
	/* 0x1640: jns    1647 <trace_ret_inotify_find_inode+0x1647> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1640, 0x1647, x86_l_1647);
x86_l_1642:
	/* 0x1642: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1645:
	/* 0x1645: jmp    1649 <trace_ret_inotify_find_inode+0x1649> */
	X86_SIM_X86_JMP(0x1645, 0x1649, x86_l_1649);
x86_l_1647:
	/* 0x1647: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1649:
	/* 0x1649: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_164c:
	/* 0x164c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_164f:
	/* 0x164f: jns    1653 <trace_ret_inotify_find_inode+0x1653> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x164f, 0x1653, x86_l_1653);
x86_l_1651:
	/* 0x1651: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1653:
	/* 0x1653: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1655:
	/* 0x1655: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1659:
	/* 0x1659: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_165c:
	/* 0x165c: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1660:
	/* 0x1660: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1662:
	/* 0x1662: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1665:
	/* 0x1665: jns    166c <trace_ret_inotify_find_inode+0x166c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1665, 0x166c, x86_l_166c);
x86_l_1667:
	/* 0x1667: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_166a:
	/* 0x166a: jmp    166e <trace_ret_inotify_find_inode+0x166e> */
	X86_SIM_X86_JMP(0x166a, 0x166e, x86_l_166e);
x86_l_166c:
	/* 0x166c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_166e:
	/* 0x166e: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1672:
	/* 0x1672: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1675:
	/* 0x1675: jns    1679 <trace_ret_inotify_find_inode+0x1679> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1675, 0x1679, x86_l_1679);
x86_l_1677:
	/* 0x1677: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1679:
	/* 0x1679: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_167b:
	/* 0x167b: jne    17d9 <trace_ret_inotify_find_inode+0x17d9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x167b, 0x17d9, x86_l_17d9);
x86_l_1681:
	/* 0x1681: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1683:
	/* 0x1683: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1686:
	/* 0x1686: jns    17af <trace_ret_inotify_find_inode+0x17af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1686, 0x17af, x86_l_17af);
x86_l_168c:
	/* 0x168c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_168f:
	/* 0x168f: jmp    17b1 <trace_ret_inotify_find_inode+0x17b1> */
	X86_SIM_X86_JMP(0x168f, 0x17b1, x86_l_17b1);
x86_l_1694:
	/* 0x1694: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1699:
	/* 0x1699: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_169d:
	/* 0x169d: jl     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x169d, 0x118c, x86_l_118c);
x86_l_16a3:
	/* 0x16a3: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_16a6:
	/* 0x16a6: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_16ac:
	/* 0x16ac: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_16b1:
	/* 0x16b1: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16b4:
	/* 0x16b4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16b7:
	/* 0x16b7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16ba:
	/* 0x16ba: js     1242 <trace_ret_inotify_find_inode+0x1242> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16ba, 0x1242, x86_l_1242);
x86_l_16c0:
	/* 0x16c0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c2:
	/* 0x16c2: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16c6:
	/* 0x16c6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16c9:
	/* 0x16c9: jns    16d0 <trace_ret_inotify_find_inode+0x16d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16c9, 0x16d0, x86_l_16d0);
x86_l_16cb:
	/* 0x16cb: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16ce:
	/* 0x16ce: jmp    16d2 <trace_ret_inotify_find_inode+0x16d2> */
	X86_SIM_X86_JMP(0x16ce, 0x16d2, x86_l_16d2);
x86_l_16d0:
	/* 0x16d0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d2:
	/* 0x16d2: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16d5:
	/* 0x16d5: je     175a <trace_ret_inotify_find_inode+0x175a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d5, 0x175a, x86_l_175a);
x86_l_16db:
	/* 0x16db: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16de:
	/* 0x16de: je     175a <trace_ret_inotify_find_inode+0x175a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16de, 0x175a, x86_l_175a);
x86_l_16e0:
	/* 0x16e0: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16e4:
	/* 0x16e4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16e7:
	/* 0x16e7: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_16ed:
	/* 0x16ed: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16f0:
	/* 0x16f0: jns    16f9 <trace_ret_inotify_find_inode+0x16f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f0, 0x16f9, x86_l_16f9);
x86_l_16f2:
	/* 0x16f2: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16f5:
	/* 0x16f5: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16f9:
	/* 0x16f9: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_16fd:
	/* 0x16fd: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1700:
	/* 0x1700: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1707:
	/* 0x1707: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1709:
	/* 0x1709: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_170c:
	/* 0x170c: jb     2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_B, 0x170c, 0x2970, x86_l_2970);
x86_l_1712:
	/* 0x1712: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1715:
	/* 0x1715: je     1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1715, 0x1189, x86_l_1189);
x86_l_171b:
	/* 0x171b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1721:
	/* 0x1721: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1724:
	/* 0x1724: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1727:
	/* 0x1727: jns    117f <trace_ret_inotify_find_inode+0x117f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1727, 0x117f, x86_l_117f);
x86_l_172d:
	/* 0x172d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1731:
	/* 0x1731: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1734:
	/* 0x1734: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1737:
	/* 0x1737: je     1a74 <trace_ret_inotify_find_inode+0x1a74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1737, 0x1a74, x86_l_1a74);
x86_l_173d:
	/* 0x173d: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1741:
	/* 0x1741: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1746:
	/* 0x1746: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_174a:
	/* 0x174a: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_174d:
	/* 0x174d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1750:
	/* 0x1750: jne    1734 <trace_ret_inotify_find_inode+0x1734> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1750, 0x1734, x86_l_1734);
x86_l_1752:
	/* 0x1752: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1755:
	/* 0x1755: jmp    1a79 <trace_ret_inotify_find_inode+0x1a79> */
	X86_SIM_X86_JMP(0x1755, 0x1a79, x86_l_1a79);
x86_l_175a:
	/* 0x175a: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_175d:
	/* 0x175d: jne    1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x175d, 0x1189, x86_l_1189);
x86_l_1763:
	/* 0x1763: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1766:
	/* 0x1766: je     1189 <trace_ret_inotify_find_inode+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1766, 0x1189, x86_l_1189);
x86_l_176c:
	/* 0x176c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1770:
	/* 0x1770: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1773:
	/* 0x1773: jns    177a <trace_ret_inotify_find_inode+0x177a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1773, 0x177a, x86_l_177a);
x86_l_1775:
	/* 0x1775: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1778:
	/* 0x1778: jmp    177c <trace_ret_inotify_find_inode+0x177c> */
	X86_SIM_X86_JMP(0x1778, 0x177c, x86_l_177c);
x86_l_177a:
	/* 0x177a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_177c:
	/* 0x177c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177f:
	/* 0x177f: jns    1786 <trace_ret_inotify_find_inode+0x1786> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x177f, 0x1786, x86_l_1786);
x86_l_1781:
	/* 0x1781: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1784:
	/* 0x1784: jmp    1788 <trace_ret_inotify_find_inode+0x1788> */
	X86_SIM_X86_JMP(0x1784, 0x1788, x86_l_1788);
x86_l_1786:
	/* 0x1786: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1788:
	/* 0x1788: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_178b:
	/* 0x178b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_178e:
	/* 0x178e: jns    1795 <trace_ret_inotify_find_inode+0x1795> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178e, 0x1795, x86_l_1795);
x86_l_1790:
	/* 0x1790: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1793:
	/* 0x1793: jmp    1797 <trace_ret_inotify_find_inode+0x1797> */
	X86_SIM_X86_JMP(0x1793, 0x1797, x86_l_1797);
x86_l_1795:
	/* 0x1795: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1797:
	/* 0x1797: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_179b:
	/* 0x179b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_179e:
	/* 0x179e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17a1:
	/* 0x17a1: jns    1aa9 <trace_ret_inotify_find_inode+0x1aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17a1, 0x1aa9, x86_l_1aa9);
x86_l_17a7:
	/* 0x17a7: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17aa:
	/* 0x17aa: jmp    1aab <trace_ret_inotify_find_inode+0x1aab> */
	X86_SIM_X86_JMP(0x17aa, 0x1aab, x86_l_1aab);
x86_l_17af:
	/* 0x17af: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17b1:
	/* 0x17b1: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17b4:
	/* 0x17b4: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17b7:
	/* 0x17b7: jns    17bb <trace_ret_inotify_find_inode+0x17bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17b7, 0x17bb, x86_l_17bb);
x86_l_17b9:
	/* 0x17b9: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17bb:
	/* 0x17bb: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17bd:
	/* 0x17bd: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_17c1:
	/* 0x17c1: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17c4:
	/* 0x17c4: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17c8:
	/* 0x17c8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17ca:
	/* 0x17ca: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17cd:
	/* 0x17cd: jns    17d1 <trace_ret_inotify_find_inode+0x17d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17cd, 0x17d1, x86_l_17d1);
x86_l_17cf:
	/* 0x17cf: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17d1:
	/* 0x17d1: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17d6:
	/* 0x17d6: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17d9:
	/* 0x17d9: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17de:
	/* 0x17de: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_17e1:
	/* 0x17e1: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_17e8:
	/* 0x17e8: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17eb:
	/* 0x17eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17ee:
	/* 0x17ee: jns    17f5 <trace_ret_inotify_find_inode+0x17f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ee, 0x17f5, x86_l_17f5);
x86_l_17f0:
	/* 0x17f0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17f3:
	/* 0x17f3: jmp    17f7 <trace_ret_inotify_find_inode+0x17f7> */
	X86_SIM_X86_JMP(0x17f3, 0x17f7, x86_l_17f7);
x86_l_17f5:
	/* 0x17f5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f7:
	/* 0x17f7: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_17fb:
	/* 0x17fb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17fd:
	/* 0x17fd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1800:
	/* 0x1800: jns    1807 <trace_ret_inotify_find_inode+0x1807> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1800, 0x1807, x86_l_1807);
x86_l_1802:
	/* 0x1802: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1805:
	/* 0x1805: jmp    1809 <trace_ret_inotify_find_inode+0x1809> */
	X86_SIM_X86_JMP(0x1805, 0x1809, x86_l_1809);
x86_l_1807:
	/* 0x1807: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1809:
	/* 0x1809: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_180c:
	/* 0x180c: jns    1810 <trace_ret_inotify_find_inode+0x1810> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x180c, 0x1810, x86_l_1810);
x86_l_180e:
	/* 0x180e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1810:
	/* 0x1810: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1815:
	/* 0x1815: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1819:
	/* 0x1819: call   181e <trace_ret_inotify_find_inode+0x181e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_181e:
	/* 0x181e: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1822:
	/* 0x1822: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1826:
	/* 0x1826: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1829:
	/* 0x1829: jns    1830 <trace_ret_inotify_find_inode+0x1830> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1829, 0x1830, x86_l_1830);
x86_l_182b:
	/* 0x182b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_182e:
	/* 0x182e: jmp    1832 <trace_ret_inotify_find_inode+0x1832> */
	X86_SIM_X86_JMP(0x182e, 0x1832, x86_l_1832);
x86_l_1830:
	/* 0x1830: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1832:
	/* 0x1832: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1837:
	/* 0x1837: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_183a:
	/* 0x183a: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_183e:
	/* 0x183e: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1841:
	/* 0x1841: jns    1848 <trace_ret_inotify_find_inode+0x1848> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1841, 0x1848, x86_l_1848);
x86_l_1843:
	/* 0x1843: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1846:
	/* 0x1846: jmp    184a <trace_ret_inotify_find_inode+0x184a> */
	X86_SIM_X86_JMP(0x1846, 0x184a, x86_l_184a);
x86_l_1848:
	/* 0x1848: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_184a:
	/* 0x184a: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_184f:
	/* 0x184f: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1853:
	/* 0x1853: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1857:
	/* 0x1857: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_185a:
	/* 0x185a: jns    1862 <trace_ret_inotify_find_inode+0x1862> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x185a, 0x1862, x86_l_1862);
x86_l_185c:
	/* 0x185c: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1860:
	/* 0x1860: jmp    1864 <trace_ret_inotify_find_inode+0x1864> */
	X86_SIM_X86_JMP(0x1860, 0x1864, x86_l_1864);
x86_l_1862:
	/* 0x1862: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1864:
	/* 0x1864: mov    r12,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1869:
	/* 0x1869: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_186e:
	/* 0x186e: mov    QWORD PTR [r15+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1872:
	/* 0x1872: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1875:
	/* 0x1875: jns    1882 <trace_ret_inotify_find_inode+0x1882> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1875, 0x1882, x86_l_1882);
x86_l_1877:
	/* 0x1877: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1879:
	/* 0x1879: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_187b:
	/* 0x187b: je     1882 <trace_ret_inotify_find_inode+0x1882> */
	X86_SIM_X86_JCC(X86_CC_E, 0x187b, 0x1882, x86_l_1882);
x86_l_187d:
	/* 0x187d: or     BYTE PTR [r15+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_1882:
	/* 0x1882: lea    rdi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1886:
	/* 0x1886: mov    QWORD PTR [r15+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_188e:
	/* 0x188e: mov    QWORD PTR [r15+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_1896:
	/* 0x1896: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_189b:
	/* 0x189b: call   18a0 <trace_ret_inotify_find_inode+0x18a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_18a0:
	/* 0x18a0: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18a3:
	/* 0x18a3: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_18a6:
	/* 0x18a6: jns    18ae <trace_ret_inotify_find_inode+0x18ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18a6, 0x18ae, x86_l_18ae);
x86_l_18a8:
	/* 0x18a8: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ac:
	/* 0x18ac: jmp    18b0 <trace_ret_inotify_find_inode+0x18b0> */
	X86_SIM_X86_JMP(0x18ac, 0x18b0, x86_l_18b0);
x86_l_18ae:
	/* 0x18ae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b0:
	/* 0x18b0: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18b4:
	/* 0x18b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18b7:
	/* 0x18b7: jns    18be <trace_ret_inotify_find_inode+0x18be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18b7, 0x18be, x86_l_18be);
x86_l_18b9:
	/* 0x18b9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18bc:
	/* 0x18bc: jmp    18c0 <trace_ret_inotify_find_inode+0x18c0> */
	X86_SIM_X86_JMP(0x18bc, 0x18c0, x86_l_18c0);
x86_l_18be:
	/* 0x18be: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c0:
	/* 0x18c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c3:
	/* 0x18c3: jns    1910 <trace_ret_inotify_find_inode+0x1910> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c3, 0x1910, x86_l_1910);
x86_l_18c5:
	/* 0x18c5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18c8:
	/* 0x18c8: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_18cd:
	/* 0x18cd: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18d1:
	/* 0x18d1: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_18d6:
	/* 0x18d6: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18da:
	/* 0x18da: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18df:
	/* 0x18df: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18e3:
	/* 0x18e3: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18e8:
	/* 0x18e8: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18ec:
	/* 0x18ec: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_18f1:
	/* 0x18f1: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18f5:
	/* 0x18f5: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_18fa:
	/* 0x18fa: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18fe:
	/* 0x18fe: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1903:
	/* 0x1903: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1907:
	/* 0x1907: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_190c:
	/* 0x190c: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1910:
	/* 0x1910: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1913:
	/* 0x1913: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_1917:
	/* 0x1917: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_191c:
	/* 0x191c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_191f:
	/* 0x191f: jns    1a48 <trace_ret_inotify_find_inode+0x1a48> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x191f, 0x1a48, x86_l_1a48);
x86_l_1925:
	/* 0x1925: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1928:
	/* 0x1928: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_192a:
	/* 0x192a: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_192c:
	/* 0x192c: je     297 <trace_ret_inotify_find_inode+0x297> */
	X86_SIM_X86_JCC(X86_CC_E, 0x192c, 0x297, x86_l_297);
x86_l_1932:
	/* 0x1932: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1936:
	/* 0x1936: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_1939:
	/* 0x1939: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_193b:
	/* 0x193b: je     297 <trace_ret_inotify_find_inode+0x297> */
	X86_SIM_X86_JCC(X86_CC_E, 0x193b, 0x297, x86_l_297);
x86_l_1941:
	/* 0x1941: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1945:
	/* 0x1945: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_1948:
	/* 0x1948: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_194a:
	/* 0x194a: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194a, 0x1a5c, x86_l_1a5c);
x86_l_1950:
	/* 0x1950: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1954:
	/* 0x1954: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1959:
	/* 0x1959: mov    BYTE PTR [rdx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_195c:
	/* 0x195c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_195e:
	/* 0x195e: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x195e, 0x1a5c, x86_l_1a5c);
x86_l_1964:
	/* 0x1964: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1968:
	/* 0x1968: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_196d:
	/* 0x196d: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1970:
	/* 0x1970: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1972:
	/* 0x1972: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1972, 0x1a5c, x86_l_1a5c);
x86_l_1978:
	/* 0x1978: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_197c:
	/* 0x197c: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1981:
	/* 0x1981: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_1984:
	/* 0x1984: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1986:
	/* 0x1986: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1986, 0x1a5c, x86_l_1a5c);
x86_l_198c:
	/* 0x198c: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1990:
	/* 0x1990: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1995:
	/* 0x1995: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_1998:
	/* 0x1998: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_199a:
	/* 0x199a: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x199a, 0x1a5c, x86_l_1a5c);
x86_l_19a0:
	/* 0x19a0: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_19a4:
	/* 0x19a4: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19a9:
	/* 0x19a9: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_19ac:
	/* 0x19ac: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19ae:
	/* 0x19ae: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ae, 0x1a5c, x86_l_1a5c);
x86_l_19b4:
	/* 0x19b4: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19b8:
	/* 0x19b8: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19bd:
	/* 0x19bd: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_19c0:
	/* 0x19c0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19c2:
	/* 0x19c2: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c2, 0x1a5c, x86_l_1a5c);
x86_l_19c8:
	/* 0x19c8: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_19cc:
	/* 0x19cc: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19d1:
	/* 0x19d1: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_19d4:
	/* 0x19d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19d6:
	/* 0x19d6: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d6, 0x1a5c, x86_l_1a5c);
x86_l_19dc:
	/* 0x19dc: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_19e0:
	/* 0x19e0: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19e5:
	/* 0x19e5: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_19e8:
	/* 0x19e8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19ea:
	/* 0x19ea: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ea, 0x1a5c, x86_l_1a5c);
x86_l_19ec:
	/* 0x19ec: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_19f0:
	/* 0x19f0: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19f5:
	/* 0x19f5: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_19f8:
	/* 0x19f8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19fa:
	/* 0x19fa: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19fa, 0x1a5c, x86_l_1a5c);
x86_l_19fc:
	/* 0x19fc: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1a00:
	/* 0x1a00: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a05:
	/* 0x1a05: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a08:
	/* 0x1a08: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a0a:
	/* 0x1a0a: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0a, 0x1a5c, x86_l_1a5c);
x86_l_1a0c:
	/* 0x1a0c: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1a10:
	/* 0x1a10: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a15:
	/* 0x1a15: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1a18:
	/* 0x1a18: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a1a:
	/* 0x1a1a: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1a, 0x1a5c, x86_l_1a5c);
x86_l_1a1c:
	/* 0x1a1c: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1a20:
	/* 0x1a20: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a25:
	/* 0x1a25: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1a28:
	/* 0x1a28: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a2a:
	/* 0x1a2a: je     1a5c <trace_ret_inotify_find_inode+0x1a5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a2a, 0x1a5c, x86_l_1a5c);
x86_l_1a2c:
	/* 0x1a2c: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a31:
	/* 0x1a31: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_1a35:
	/* 0x1a35: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a39:
	/* 0x1a39: mov    r12,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a3e:
	/* 0x1a3e: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a43:
	/* 0x1a43: jmp    297 <trace_ret_inotify_find_inode+0x297> */
	X86_SIM_X86_JMP(0x1a43, 0x297, x86_l_297);
x86_l_1a48:
	/* 0x1a48: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1a50:
	/* 0x1a50: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a57:
	/* 0x1a57: jmp    297 <trace_ret_inotify_find_inode+0x297> */
	X86_SIM_X86_JMP(0x1a57, 0x297, x86_l_297);
x86_l_1a5c:
	/* 0x1a5c: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a60:
	/* 0x1a60: mov    r12,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a65:
	/* 0x1a65: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a6a:
	/* 0x1a6a: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a6f:
	/* 0x1a6f: jmp    297 <trace_ret_inotify_find_inode+0x297> */
	X86_SIM_X86_JMP(0x1a6f, 0x297, x86_l_297);
x86_l_1a74:
	/* 0x1a74: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a79:
	/* 0x1a79: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a7d:
	/* 0x1a7d: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a7d, 0x2911, x86_l_2911);
x86_l_1a83:
	/* 0x1a83: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a86:
	/* 0x1a86: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1a8c:
	/* 0x1a8c: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1a91:
	/* 0x1a91: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a94:
	/* 0x1a94: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a98:
	/* 0x1a98: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a9d:
	/* 0x1a9d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1aa0:
	/* 0x1aa0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1aa3:
	/* 0x1aa3: js     17a7 <trace_ret_inotify_find_inode+0x17a7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1aa3, 0x17a7, x86_l_17a7);
x86_l_1aa9:
	/* 0x1aa9: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aab:
	/* 0x1aab: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aaf:
	/* 0x1aaf: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ab2:
	/* 0x1ab2: jns    1ab9 <trace_ret_inotify_find_inode+0x1ab9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ab2, 0x1ab9, x86_l_1ab9);
x86_l_1ab4:
	/* 0x1ab4: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab7:
	/* 0x1ab7: jmp    1abc <trace_ret_inotify_find_inode+0x1abc> */
	X86_SIM_X86_JMP(0x1ab7, 0x1abc, x86_l_1abc);
x86_l_1ab9:
	/* 0x1ab9: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1abc:
	/* 0x1abc: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1abf:
	/* 0x1abf: je     1b39 <trace_ret_inotify_find_inode+0x1b39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1abf, 0x1b39, x86_l_1b39);
x86_l_1ac1:
	/* 0x1ac1: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ac4:
	/* 0x1ac4: je     1b39 <trace_ret_inotify_find_inode+0x1b39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac4, 0x1b39, x86_l_1b39);
x86_l_1ac6:
	/* 0x1ac6: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1aca:
	/* 0x1aca: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1acd:
	/* 0x1acd: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ad3:
	/* 0x1ad3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ad6:
	/* 0x1ad6: jns    1adf <trace_ret_inotify_find_inode+0x1adf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ad6, 0x1adf, x86_l_1adf);
x86_l_1ad8:
	/* 0x1ad8: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1adb:
	/* 0x1adb: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1adf:
	/* 0x1adf: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1ae3:
	/* 0x1ae3: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1ae6:
	/* 0x1ae6: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1aed:
	/* 0x1aed: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1aef:
	/* 0x1aef: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1af2:
	/* 0x1af2: jb     2970 <trace_ret_inotify_find_inode+0x2970> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1af2, 0x2970, x86_l_2970);
x86_l_1af8:
	/* 0x1af8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1afb:
	/* 0x1afb: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1afb, 0x2914, x86_l_2914);
x86_l_1b01:
	/* 0x1b01: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b07:
	/* 0x1b07: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b0a:
	/* 0x1b0a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1b0d:
	/* 0x1b0d: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b0d, 0x2785, x86_l_2785);
x86_l_1b13:
	/* 0x1b13: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b17:
	/* 0x1b17: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b1a:
	/* 0x1b1a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b1d:
	/* 0x1b1d: je     1b88 <trace_ret_inotify_find_inode+0x1b88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b1d, 0x1b88, x86_l_1b88);
x86_l_1b1f:
	/* 0x1b1f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b23:
	/* 0x1b23: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b28:
	/* 0x1b28: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b2c:
	/* 0x1b2c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1b2f:
	/* 0x1b2f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1b32:
	/* 0x1b32: jne    1b1a <trace_ret_inotify_find_inode+0x1b1a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b32, 0x1b1a, x86_l_1b1a);
x86_l_1b34:
	/* 0x1b34: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b37:
	/* 0x1b37: jmp    1b8d <trace_ret_inotify_find_inode+0x1b8d> */
	X86_SIM_X86_JMP(0x1b37, 0x1b8d, x86_l_1b8d);
x86_l_1b39:
	/* 0x1b39: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b3c:
	/* 0x1b3c: jne    118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b3c, 0x118c, x86_l_118c);
x86_l_1b42:
	/* 0x1b42: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b45:
	/* 0x1b45: je     118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b45, 0x118c, x86_l_118c);
x86_l_1b4b:
	/* 0x1b4b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b4f:
	/* 0x1b4f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b52:
	/* 0x1b52: jns    1b59 <trace_ret_inotify_find_inode+0x1b59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b52, 0x1b59, x86_l_1b59);
x86_l_1b54:
	/* 0x1b54: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b57:
	/* 0x1b57: jmp    1b5c <trace_ret_inotify_find_inode+0x1b5c> */
	X86_SIM_X86_JMP(0x1b57, 0x1b5c, x86_l_1b5c);
x86_l_1b59:
	/* 0x1b59: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b5c:
	/* 0x1b5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b5f:
	/* 0x1b5f: jns    1b66 <trace_ret_inotify_find_inode+0x1b66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b5f, 0x1b66, x86_l_1b66);
x86_l_1b61:
	/* 0x1b61: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b64:
	/* 0x1b64: jmp    1b68 <trace_ret_inotify_find_inode+0x1b68> */
	X86_SIM_X86_JMP(0x1b64, 0x1b68, x86_l_1b68);
x86_l_1b66:
	/* 0x1b66: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b68:
	/* 0x1b68: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b6b:
	/* 0x1b6b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b6e:
	/* 0x1b6e: jns    1b75 <trace_ret_inotify_find_inode+0x1b75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b6e, 0x1b75, x86_l_1b75);
x86_l_1b70:
	/* 0x1b70: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b73:
	/* 0x1b73: jmp    1b77 <trace_ret_inotify_find_inode+0x1b77> */
	X86_SIM_X86_JMP(0x1b73, 0x1b77, x86_l_1b77);
x86_l_1b75:
	/* 0x1b75: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b77:
	/* 0x1b77: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b7b:
	/* 0x1b7b: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b7e:
	/* 0x1b7e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b81:
	/* 0x1b81: jns    1bb0 <trace_ret_inotify_find_inode+0x1bb0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b81, 0x1bb0, x86_l_1bb0);
x86_l_1b83:
	/* 0x1b83: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b86:
	/* 0x1b86: jmp    1bb2 <trace_ret_inotify_find_inode+0x1bb2> */
	X86_SIM_X86_JMP(0x1b86, 0x1bb2, x86_l_1bb2);
x86_l_1b88:
	/* 0x1b88: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1b8d:
	/* 0x1b8d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b91:
	/* 0x1b91: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1b91, 0x2914, x86_l_2914);
x86_l_1b97:
	/* 0x1b97: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b9a:
	/* 0x1b9a: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ba0:
	/* 0x1ba0: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1ba5:
	/* 0x1ba5: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ba8:
	/* 0x1ba8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bab:
	/* 0x1bab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bae:
	/* 0x1bae: js     1b83 <trace_ret_inotify_find_inode+0x1b83> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bae, 0x1b83, x86_l_1b83);
x86_l_1bb0:
	/* 0x1bb0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bb2:
	/* 0x1bb2: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bb6:
	/* 0x1bb6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bb9:
	/* 0x1bb9: jns    1bc0 <trace_ret_inotify_find_inode+0x1bc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bb9, 0x1bc0, x86_l_1bc0);
x86_l_1bbb:
	/* 0x1bbb: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bbe:
	/* 0x1bbe: jmp    1bc2 <trace_ret_inotify_find_inode+0x1bc2> */
	X86_SIM_X86_JMP(0x1bbe, 0x1bc2, x86_l_1bc2);
x86_l_1bc0:
	/* 0x1bc0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc2:
	/* 0x1bc2: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bc5:
	/* 0x1bc5: je     1c3f <trace_ret_inotify_find_inode+0x1c3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc5, 0x1c3f, x86_l_1c3f);
x86_l_1bc7:
	/* 0x1bc7: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bca:
	/* 0x1bca: je     1c3f <trace_ret_inotify_find_inode+0x1c3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bca, 0x1c3f, x86_l_1c3f);
x86_l_1bcc:
	/* 0x1bcc: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bd0:
	/* 0x1bd0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bd3:
	/* 0x1bd3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1bd9:
	/* 0x1bd9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bdc:
	/* 0x1bdc: jns    1be5 <trace_ret_inotify_find_inode+0x1be5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bdc, 0x1be5, x86_l_1be5);
x86_l_1bde:
	/* 0x1bde: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1be1:
	/* 0x1be1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1be5:
	/* 0x1be5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1be9:
	/* 0x1be9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1bec:
	/* 0x1bec: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1bf3:
	/* 0x1bf3: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1bf5:
	/* 0x1bf5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1bf8:
	/* 0x1bf8: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1bf8, 0x2967, x86_l_2967);
x86_l_1bfe:
	/* 0x1bfe: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1c01:
	/* 0x1c01: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c01, 0x2911, x86_l_2911);
x86_l_1c07:
	/* 0x1c07: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c0d:
	/* 0x1c0d: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c10:
	/* 0x1c10: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c13:
	/* 0x1c13: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c13, 0x2788, x86_l_2788);
x86_l_1c19:
	/* 0x1c19: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c1d:
	/* 0x1c1d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c20:
	/* 0x1c20: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c23:
	/* 0x1c23: je     1c8d <trace_ret_inotify_find_inode+0x1c8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c23, 0x1c8d, x86_l_1c8d);
x86_l_1c25:
	/* 0x1c25: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c29:
	/* 0x1c29: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c2e:
	/* 0x1c2e: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c32:
	/* 0x1c32: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c35:
	/* 0x1c35: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1c38:
	/* 0x1c38: jne    1c20 <trace_ret_inotify_find_inode+0x1c20> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c38, 0x1c20, x86_l_1c20);
x86_l_1c3a:
	/* 0x1c3a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1c3d:
	/* 0x1c3d: jmp    1c92 <trace_ret_inotify_find_inode+0x1c92> */
	X86_SIM_X86_JMP(0x1c3d, 0x1c92, x86_l_1c92);
x86_l_1c3f:
	/* 0x1c3f: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c42:
	/* 0x1c42: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c42, 0x2911, x86_l_2911);
x86_l_1c48:
	/* 0x1c48: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c4b:
	/* 0x1c4b: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4b, 0x2911, x86_l_2911);
x86_l_1c51:
	/* 0x1c51: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c55:
	/* 0x1c55: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c58:
	/* 0x1c58: jns    1c5f <trace_ret_inotify_find_inode+0x1c5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c58, 0x1c5f, x86_l_1c5f);
x86_l_1c5a:
	/* 0x1c5a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c5d:
	/* 0x1c5d: jmp    1c61 <trace_ret_inotify_find_inode+0x1c61> */
	X86_SIM_X86_JMP(0x1c5d, 0x1c61, x86_l_1c61);
x86_l_1c5f:
	/* 0x1c5f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c61:
	/* 0x1c61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c64:
	/* 0x1c64: jns    1c6b <trace_ret_inotify_find_inode+0x1c6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c64, 0x1c6b, x86_l_1c6b);
x86_l_1c66:
	/* 0x1c66: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c69:
	/* 0x1c69: jmp    1c6d <trace_ret_inotify_find_inode+0x1c6d> */
	X86_SIM_X86_JMP(0x1c69, 0x1c6d, x86_l_1c6d);
x86_l_1c6b:
	/* 0x1c6b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c6d:
	/* 0x1c6d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c70:
	/* 0x1c70: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c73:
	/* 0x1c73: jns    1c7a <trace_ret_inotify_find_inode+0x1c7a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c73, 0x1c7a, x86_l_1c7a);
x86_l_1c75:
	/* 0x1c75: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c78:
	/* 0x1c78: jmp    1c7c <trace_ret_inotify_find_inode+0x1c7c> */
	X86_SIM_X86_JMP(0x1c78, 0x1c7c, x86_l_1c7c);
x86_l_1c7a:
	/* 0x1c7a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c7c:
	/* 0x1c7c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c80:
	/* 0x1c80: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c83:
	/* 0x1c83: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c86:
	/* 0x1c86: jns    1cb5 <trace_ret_inotify_find_inode+0x1cb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c86, 0x1cb5, x86_l_1cb5);
x86_l_1c88:
	/* 0x1c88: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c8b:
	/* 0x1c8b: jmp    1cb7 <trace_ret_inotify_find_inode+0x1cb7> */
	X86_SIM_X86_JMP(0x1c8b, 0x1cb7, x86_l_1cb7);
x86_l_1c8d:
	/* 0x1c8d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c92:
	/* 0x1c92: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c96:
	/* 0x1c96: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c96, 0x2911, x86_l_2911);
x86_l_1c9c:
	/* 0x1c9c: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c9f:
	/* 0x1c9f: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ca5:
	/* 0x1ca5: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1caa:
	/* 0x1caa: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cad:
	/* 0x1cad: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cb0:
	/* 0x1cb0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1cb3:
	/* 0x1cb3: js     1c88 <trace_ret_inotify_find_inode+0x1c88> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1cb3, 0x1c88, x86_l_1c88);
x86_l_1cb5:
	/* 0x1cb5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cb7:
	/* 0x1cb7: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cbb:
	/* 0x1cbb: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1cbe:
	/* 0x1cbe: jns    1cc5 <trace_ret_inotify_find_inode+0x1cc5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cbe, 0x1cc5, x86_l_1cc5);
x86_l_1cc0:
	/* 0x1cc0: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cc3:
	/* 0x1cc3: jmp    1cc8 <trace_ret_inotify_find_inode+0x1cc8> */
	X86_SIM_X86_JMP(0x1cc3, 0x1cc8, x86_l_1cc8);
x86_l_1cc5:
	/* 0x1cc5: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cc8:
	/* 0x1cc8: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ccb:
	/* 0x1ccb: je     1d45 <trace_ret_inotify_find_inode+0x1d45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ccb, 0x1d45, x86_l_1d45);
x86_l_1ccd:
	/* 0x1ccd: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1cd0:
	/* 0x1cd0: je     1d45 <trace_ret_inotify_find_inode+0x1d45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd0, 0x1d45, x86_l_1d45);
x86_l_1cd2:
	/* 0x1cd2: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cd6:
	/* 0x1cd6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cd9:
	/* 0x1cd9: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1cdf:
	/* 0x1cdf: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ce2:
	/* 0x1ce2: jns    1ceb <trace_ret_inotify_find_inode+0x1ceb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ce2, 0x1ceb, x86_l_1ceb);
x86_l_1ce4:
	/* 0x1ce4: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ce7:
	/* 0x1ce7: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ceb:
	/* 0x1ceb: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1cef:
	/* 0x1cef: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1cf2:
	/* 0x1cf2: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1cf9:
	/* 0x1cf9: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1cfb:
	/* 0x1cfb: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cfe:
	/* 0x1cfe: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cfe, 0x2967, x86_l_2967);
x86_l_1d04:
	/* 0x1d04: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1d07:
	/* 0x1d07: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d07, 0x2914, x86_l_2914);
x86_l_1d0d:
	/* 0x1d0d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d13:
	/* 0x1d13: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d16:
	/* 0x1d16: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1d19:
	/* 0x1d19: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d19, 0x2785, x86_l_2785);
x86_l_1d1f:
	/* 0x1d1f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d23:
	/* 0x1d23: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d26:
	/* 0x1d26: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d29:
	/* 0x1d29: je     1d94 <trace_ret_inotify_find_inode+0x1d94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d29, 0x1d94, x86_l_1d94);
x86_l_1d2b:
	/* 0x1d2b: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d2f:
	/* 0x1d2f: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1d34:
	/* 0x1d34: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1d38:
	/* 0x1d38: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d3b:
	/* 0x1d3b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1d3e:
	/* 0x1d3e: jne    1d26 <trace_ret_inotify_find_inode+0x1d26> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d3e, 0x1d26, x86_l_1d26);
x86_l_1d40:
	/* 0x1d40: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1d43:
	/* 0x1d43: jmp    1d99 <trace_ret_inotify_find_inode+0x1d99> */
	X86_SIM_X86_JMP(0x1d43, 0x1d99, x86_l_1d99);
x86_l_1d45:
	/* 0x1d45: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d48:
	/* 0x1d48: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d48, 0x2914, x86_l_2914);
x86_l_1d4e:
	/* 0x1d4e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d51:
	/* 0x1d51: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d51, 0x2914, x86_l_2914);
x86_l_1d57:
	/* 0x1d57: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d5b:
	/* 0x1d5b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d5e:
	/* 0x1d5e: jns    1d65 <trace_ret_inotify_find_inode+0x1d65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d5e, 0x1d65, x86_l_1d65);
x86_l_1d60:
	/* 0x1d60: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d63:
	/* 0x1d63: jmp    1d68 <trace_ret_inotify_find_inode+0x1d68> */
	X86_SIM_X86_JMP(0x1d63, 0x1d68, x86_l_1d68);
x86_l_1d65:
	/* 0x1d65: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d68:
	/* 0x1d68: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d6b:
	/* 0x1d6b: jns    1d72 <trace_ret_inotify_find_inode+0x1d72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d6b, 0x1d72, x86_l_1d72);
x86_l_1d6d:
	/* 0x1d6d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d70:
	/* 0x1d70: jmp    1d74 <trace_ret_inotify_find_inode+0x1d74> */
	X86_SIM_X86_JMP(0x1d70, 0x1d74, x86_l_1d74);
x86_l_1d72:
	/* 0x1d72: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d74:
	/* 0x1d74: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d77:
	/* 0x1d77: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d7a:
	/* 0x1d7a: jns    1d81 <trace_ret_inotify_find_inode+0x1d81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d7a, 0x1d81, x86_l_1d81);
x86_l_1d7c:
	/* 0x1d7c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d7f:
	/* 0x1d7f: jmp    1d83 <trace_ret_inotify_find_inode+0x1d83> */
	X86_SIM_X86_JMP(0x1d7f, 0x1d83, x86_l_1d83);
x86_l_1d81:
	/* 0x1d81: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d83:
	/* 0x1d83: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d87:
	/* 0x1d87: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d8a:
	/* 0x1d8a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d8d:
	/* 0x1d8d: jns    1dbc <trace_ret_inotify_find_inode+0x1dbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d8d, 0x1dbc, x86_l_1dbc);
x86_l_1d8f:
	/* 0x1d8f: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d92:
	/* 0x1d92: jmp    1dbe <trace_ret_inotify_find_inode+0x1dbe> */
	X86_SIM_X86_JMP(0x1d92, 0x1dbe, x86_l_1dbe);
x86_l_1d94:
	/* 0x1d94: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d99:
	/* 0x1d99: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d9d:
	/* 0x1d9d: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d9d, 0x2914, x86_l_2914);
x86_l_1da3:
	/* 0x1da3: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1da6:
	/* 0x1da6: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1dac:
	/* 0x1dac: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1db1:
	/* 0x1db1: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1db4:
	/* 0x1db4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1db7:
	/* 0x1db7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1dba:
	/* 0x1dba: js     1d8f <trace_ret_inotify_find_inode+0x1d8f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1dba, 0x1d8f, x86_l_1d8f);
x86_l_1dbc:
	/* 0x1dbc: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dbe:
	/* 0x1dbe: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc2:
	/* 0x1dc2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1dc5:
	/* 0x1dc5: jns    1dcc <trace_ret_inotify_find_inode+0x1dcc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dc5, 0x1dcc, x86_l_1dcc);
x86_l_1dc7:
	/* 0x1dc7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dca:
	/* 0x1dca: jmp    1dce <trace_ret_inotify_find_inode+0x1dce> */
	X86_SIM_X86_JMP(0x1dca, 0x1dce, x86_l_1dce);
x86_l_1dcc:
	/* 0x1dcc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dce:
	/* 0x1dce: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1dd1:
	/* 0x1dd1: je     1e4b <trace_ret_inotify_find_inode+0x1e4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dd1, 0x1e4b, x86_l_1e4b);
x86_l_1dd3:
	/* 0x1dd3: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1dd6:
	/* 0x1dd6: je     1e4b <trace_ret_inotify_find_inode+0x1e4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dd6, 0x1e4b, x86_l_1e4b);
x86_l_1dd8:
	/* 0x1dd8: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ddc:
	/* 0x1ddc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ddf:
	/* 0x1ddf: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1de5:
	/* 0x1de5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1de8:
	/* 0x1de8: jns    1df1 <trace_ret_inotify_find_inode+0x1df1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1de8, 0x1df1, x86_l_1df1);
x86_l_1dea:
	/* 0x1dea: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ded:
	/* 0x1ded: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1df1:
	/* 0x1df1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1df5:
	/* 0x1df5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1df8:
	/* 0x1df8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1dff:
	/* 0x1dff: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1e01:
	/* 0x1e01: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e04:
	/* 0x1e04: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e04, 0x2967, x86_l_2967);
x86_l_1e0a:
	/* 0x1e0a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1e0d:
	/* 0x1e0d: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e0d, 0x2911, x86_l_2911);
x86_l_1e13:
	/* 0x1e13: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1e19:
	/* 0x1e19: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e1c:
	/* 0x1e1c: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1e1f:
	/* 0x1e1f: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e1f, 0x2788, x86_l_2788);
x86_l_1e25:
	/* 0x1e25: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e29:
	/* 0x1e29: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e2c:
	/* 0x1e2c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1e2f:
	/* 0x1e2f: je     1e99 <trace_ret_inotify_find_inode+0x1e99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e2f, 0x1e99, x86_l_1e99);
x86_l_1e31:
	/* 0x1e31: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e35:
	/* 0x1e35: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1e3a:
	/* 0x1e3a: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1e3e:
	/* 0x1e3e: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1e41:
	/* 0x1e41: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1e44:
	/* 0x1e44: jne    1e2c <trace_ret_inotify_find_inode+0x1e2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e44, 0x1e2c, x86_l_1e2c);
x86_l_1e46:
	/* 0x1e46: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1e49:
	/* 0x1e49: jmp    1e9e <trace_ret_inotify_find_inode+0x1e9e> */
	X86_SIM_X86_JMP(0x1e49, 0x1e9e, x86_l_1e9e);
x86_l_1e4b:
	/* 0x1e4b: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e4e:
	/* 0x1e4e: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e4e, 0x2911, x86_l_2911);
x86_l_1e54:
	/* 0x1e54: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e57:
	/* 0x1e57: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e57, 0x2911, x86_l_2911);
x86_l_1e5d:
	/* 0x1e5d: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e61:
	/* 0x1e61: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e64:
	/* 0x1e64: jns    1e6b <trace_ret_inotify_find_inode+0x1e6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e64, 0x1e6b, x86_l_1e6b);
x86_l_1e66:
	/* 0x1e66: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e69:
	/* 0x1e69: jmp    1e6d <trace_ret_inotify_find_inode+0x1e6d> */
	X86_SIM_X86_JMP(0x1e69, 0x1e6d, x86_l_1e6d);
x86_l_1e6b:
	/* 0x1e6b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e6d:
	/* 0x1e6d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e70:
	/* 0x1e70: jns    1e77 <trace_ret_inotify_find_inode+0x1e77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e70, 0x1e77, x86_l_1e77);
x86_l_1e72:
	/* 0x1e72: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e75:
	/* 0x1e75: jmp    1e79 <trace_ret_inotify_find_inode+0x1e79> */
	X86_SIM_X86_JMP(0x1e75, 0x1e79, x86_l_1e79);
x86_l_1e77:
	/* 0x1e77: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e79:
	/* 0x1e79: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e7c:
	/* 0x1e7c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e7f:
	/* 0x1e7f: jns    1e86 <trace_ret_inotify_find_inode+0x1e86> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e7f, 0x1e86, x86_l_1e86);
x86_l_1e81:
	/* 0x1e81: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e84:
	/* 0x1e84: jmp    1e88 <trace_ret_inotify_find_inode+0x1e88> */
	X86_SIM_X86_JMP(0x1e84, 0x1e88, x86_l_1e88);
x86_l_1e86:
	/* 0x1e86: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e88:
	/* 0x1e88: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e8c:
	/* 0x1e8c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e8f:
	/* 0x1e8f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e92:
	/* 0x1e92: jns    1ec1 <trace_ret_inotify_find_inode+0x1ec1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e92, 0x1ec1, x86_l_1ec1);
x86_l_1e94:
	/* 0x1e94: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e97:
	/* 0x1e97: jmp    1ec3 <trace_ret_inotify_find_inode+0x1ec3> */
	X86_SIM_X86_JMP(0x1e97, 0x1ec3, x86_l_1ec3);
x86_l_1e99:
	/* 0x1e99: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e9e:
	/* 0x1e9e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ea2:
	/* 0x1ea2: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ea2, 0x2911, x86_l_2911);
x86_l_1ea8:
	/* 0x1ea8: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eab:
	/* 0x1eab: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1eb1:
	/* 0x1eb1: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1eb6:
	/* 0x1eb6: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1eb9:
	/* 0x1eb9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ebc:
	/* 0x1ebc: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ebf:
	/* 0x1ebf: js     1e94 <trace_ret_inotify_find_inode+0x1e94> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ebf, 0x1e94, x86_l_1e94);
x86_l_1ec1:
	/* 0x1ec1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec3:
	/* 0x1ec3: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ec7:
	/* 0x1ec7: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1eca:
	/* 0x1eca: jns    1ed1 <trace_ret_inotify_find_inode+0x1ed1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eca, 0x1ed1, x86_l_1ed1);
x86_l_1ecc:
	/* 0x1ecc: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ecf:
	/* 0x1ecf: jmp    1ed4 <trace_ret_inotify_find_inode+0x1ed4> */
	X86_SIM_X86_JMP(0x1ecf, 0x1ed4, x86_l_1ed4);
x86_l_1ed1:
	/* 0x1ed1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ed4:
	/* 0x1ed4: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ed7:
	/* 0x1ed7: je     1f51 <trace_ret_inotify_find_inode+0x1f51> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed7, 0x1f51, x86_l_1f51);
x86_l_1ed9:
	/* 0x1ed9: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1edc:
	/* 0x1edc: je     1f51 <trace_ret_inotify_find_inode+0x1f51> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1edc, 0x1f51, x86_l_1f51);
x86_l_1ede:
	/* 0x1ede: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ee2:
	/* 0x1ee2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ee5:
	/* 0x1ee5: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1eeb:
	/* 0x1eeb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1eee:
	/* 0x1eee: jns    1ef7 <trace_ret_inotify_find_inode+0x1ef7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eee, 0x1ef7, x86_l_1ef7);
x86_l_1ef0:
	/* 0x1ef0: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ef3:
	/* 0x1ef3: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ef7:
	/* 0x1ef7: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1efb:
	/* 0x1efb: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1efe:
	/* 0x1efe: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f05:
	/* 0x1f05: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f07:
	/* 0x1f07: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f0a:
	/* 0x1f0a: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f0a, 0x2967, x86_l_2967);
x86_l_1f10:
	/* 0x1f10: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1f13:
	/* 0x1f13: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f13, 0x2914, x86_l_2914);
x86_l_1f19:
	/* 0x1f19: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f1f:
	/* 0x1f1f: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f22:
	/* 0x1f22: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1f25:
	/* 0x1f25: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f25, 0x2785, x86_l_2785);
x86_l_1f2b:
	/* 0x1f2b: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f2f:
	/* 0x1f2f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f32:
	/* 0x1f32: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1f35:
	/* 0x1f35: je     1fa0 <trace_ret_inotify_find_inode+0x1fa0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f35, 0x1fa0, x86_l_1fa0);
x86_l_1f37:
	/* 0x1f37: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f3b:
	/* 0x1f3b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f40:
	/* 0x1f40: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f44:
	/* 0x1f44: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f47:
	/* 0x1f47: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1f4a:
	/* 0x1f4a: jne    1f32 <trace_ret_inotify_find_inode+0x1f32> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f4a, 0x1f32, x86_l_1f32);
x86_l_1f4c:
	/* 0x1f4c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1f4f:
	/* 0x1f4f: jmp    1fa5 <trace_ret_inotify_find_inode+0x1fa5> */
	X86_SIM_X86_JMP(0x1f4f, 0x1fa5, x86_l_1fa5);
x86_l_1f51:
	/* 0x1f51: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f54:
	/* 0x1f54: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f54, 0x2914, x86_l_2914);
x86_l_1f5a:
	/* 0x1f5a: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f5d:
	/* 0x1f5d: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5d, 0x2914, x86_l_2914);
x86_l_1f63:
	/* 0x1f63: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f67:
	/* 0x1f67: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f6a:
	/* 0x1f6a: jns    1f71 <trace_ret_inotify_find_inode+0x1f71> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6a, 0x1f71, x86_l_1f71);
x86_l_1f6c:
	/* 0x1f6c: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f6f:
	/* 0x1f6f: jmp    1f74 <trace_ret_inotify_find_inode+0x1f74> */
	X86_SIM_X86_JMP(0x1f6f, 0x1f74, x86_l_1f74);
x86_l_1f71:
	/* 0x1f71: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f74:
	/* 0x1f74: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f77:
	/* 0x1f77: jns    1f7e <trace_ret_inotify_find_inode+0x1f7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f77, 0x1f7e, x86_l_1f7e);
x86_l_1f79:
	/* 0x1f79: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f7c:
	/* 0x1f7c: jmp    1f80 <trace_ret_inotify_find_inode+0x1f80> */
	X86_SIM_X86_JMP(0x1f7c, 0x1f80, x86_l_1f80);
x86_l_1f7e:
	/* 0x1f7e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f80:
	/* 0x1f80: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f83:
	/* 0x1f83: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f86:
	/* 0x1f86: jns    1f8d <trace_ret_inotify_find_inode+0x1f8d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f86, 0x1f8d, x86_l_1f8d);
x86_l_1f88:
	/* 0x1f88: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f8b:
	/* 0x1f8b: jmp    1f8f <trace_ret_inotify_find_inode+0x1f8f> */
	X86_SIM_X86_JMP(0x1f8b, 0x1f8f, x86_l_1f8f);
x86_l_1f8d:
	/* 0x1f8d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8f:
	/* 0x1f8f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f93:
	/* 0x1f93: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f96:
	/* 0x1f96: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f99:
	/* 0x1f99: jns    1fc8 <trace_ret_inotify_find_inode+0x1fc8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f99, 0x1fc8, x86_l_1fc8);
x86_l_1f9b:
	/* 0x1f9b: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f9e:
	/* 0x1f9e: jmp    1fca <trace_ret_inotify_find_inode+0x1fca> */
	X86_SIM_X86_JMP(0x1f9e, 0x1fca, x86_l_1fca);
x86_l_1fa0:
	/* 0x1fa0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1fa5:
	/* 0x1fa5: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1fa9:
	/* 0x1fa9: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1fa9, 0x2914, x86_l_2914);
x86_l_1faf:
	/* 0x1faf: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fb2:
	/* 0x1fb2: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1fb8:
	/* 0x1fb8: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1fbd:
	/* 0x1fbd: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fc0:
	/* 0x1fc0: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fc3:
	/* 0x1fc3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1fc6:
	/* 0x1fc6: js     1f9b <trace_ret_inotify_find_inode+0x1f9b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1fc6, 0x1f9b, x86_l_1f9b);
x86_l_1fc8:
	/* 0x1fc8: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fca:
	/* 0x1fca: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fce:
	/* 0x1fce: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1fd1:
	/* 0x1fd1: jns    1fd8 <trace_ret_inotify_find_inode+0x1fd8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd1, 0x1fd8, x86_l_1fd8);
x86_l_1fd3:
	/* 0x1fd3: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fd6:
	/* 0x1fd6: jmp    1fda <trace_ret_inotify_find_inode+0x1fda> */
	X86_SIM_X86_JMP(0x1fd6, 0x1fda, x86_l_1fda);
x86_l_1fd8:
	/* 0x1fd8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fda:
	/* 0x1fda: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fdd:
	/* 0x1fdd: je     2057 <trace_ret_inotify_find_inode+0x2057> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fdd, 0x2057, x86_l_2057);
x86_l_1fdf:
	/* 0x1fdf: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1fe2:
	/* 0x1fe2: je     2057 <trace_ret_inotify_find_inode+0x2057> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe2, 0x2057, x86_l_2057);
x86_l_1fe4:
	/* 0x1fe4: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fe8:
	/* 0x1fe8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1feb:
	/* 0x1feb: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ff1:
	/* 0x1ff1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ff4:
	/* 0x1ff4: jns    1ffd <trace_ret_inotify_find_inode+0x1ffd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff4, 0x1ffd, x86_l_1ffd);
x86_l_1ff6:
	/* 0x1ff6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff9:
	/* 0x1ff9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ffd:
	/* 0x1ffd: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2001:
	/* 0x2001: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2004:
	/* 0x2004: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_200b:
	/* 0x200b: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_200d:
	/* 0x200d: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2010:
	/* 0x2010: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2010, 0x2967, x86_l_2967);
x86_l_2016:
	/* 0x2016: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2019:
	/* 0x2019: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2019, 0x2911, x86_l_2911);
x86_l_201f:
	/* 0x201f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2025:
	/* 0x2025: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2028:
	/* 0x2028: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_202b:
	/* 0x202b: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x202b, 0x2788, x86_l_2788);
x86_l_2031:
	/* 0x2031: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2035:
	/* 0x2035: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2038:
	/* 0x2038: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_203b:
	/* 0x203b: je     20a5 <trace_ret_inotify_find_inode+0x20a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x203b, 0x20a5, x86_l_20a5);
x86_l_203d:
	/* 0x203d: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2041:
	/* 0x2041: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2046:
	/* 0x2046: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_204a:
	/* 0x204a: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_204d:
	/* 0x204d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2050:
	/* 0x2050: jne    2038 <trace_ret_inotify_find_inode+0x2038> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2050, 0x2038, x86_l_2038);
x86_l_2052:
	/* 0x2052: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2055:
	/* 0x2055: jmp    20aa <trace_ret_inotify_find_inode+0x20aa> */
	X86_SIM_X86_JMP(0x2055, 0x20aa, x86_l_20aa);
x86_l_2057:
	/* 0x2057: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_205a:
	/* 0x205a: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x205a, 0x2911, x86_l_2911);
x86_l_2060:
	/* 0x2060: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2063:
	/* 0x2063: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2063, 0x2911, x86_l_2911);
x86_l_2069:
	/* 0x2069: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_206d:
	/* 0x206d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2070:
	/* 0x2070: jns    2077 <trace_ret_inotify_find_inode+0x2077> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2070, 0x2077, x86_l_2077);
x86_l_2072:
	/* 0x2072: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2075:
	/* 0x2075: jmp    2079 <trace_ret_inotify_find_inode+0x2079> */
	X86_SIM_X86_JMP(0x2075, 0x2079, x86_l_2079);
x86_l_2077:
	/* 0x2077: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2079:
	/* 0x2079: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_207c:
	/* 0x207c: jns    2083 <trace_ret_inotify_find_inode+0x2083> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x207c, 0x2083, x86_l_2083);
x86_l_207e:
	/* 0x207e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2081:
	/* 0x2081: jmp    2085 <trace_ret_inotify_find_inode+0x2085> */
	X86_SIM_X86_JMP(0x2081, 0x2085, x86_l_2085);
x86_l_2083:
	/* 0x2083: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2085:
	/* 0x2085: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2088:
	/* 0x2088: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_208b:
	/* 0x208b: jns    2092 <trace_ret_inotify_find_inode+0x2092> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x208b, 0x2092, x86_l_2092);
x86_l_208d:
	/* 0x208d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2090:
	/* 0x2090: jmp    2094 <trace_ret_inotify_find_inode+0x2094> */
	X86_SIM_X86_JMP(0x2090, 0x2094, x86_l_2094);
x86_l_2092:
	/* 0x2092: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2094:
	/* 0x2094: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2098:
	/* 0x2098: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_209b:
	/* 0x209b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_209e:
	/* 0x209e: jns    20cd <trace_ret_inotify_find_inode+0x20cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x209e, 0x20cd, x86_l_20cd);
x86_l_20a0:
	/* 0x20a0: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a3:
	/* 0x20a3: jmp    20cf <trace_ret_inotify_find_inode+0x20cf> */
	X86_SIM_X86_JMP(0x20a3, 0x20cf, x86_l_20cf);
x86_l_20a5:
	/* 0x20a5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_20aa:
	/* 0x20aa: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20ae:
	/* 0x20ae: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x20ae, 0x2911, x86_l_2911);
x86_l_20b4:
	/* 0x20b4: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20b7:
	/* 0x20b7: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_20bd:
	/* 0x20bd: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_20c2:
	/* 0x20c2: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20c5:
	/* 0x20c5: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20c8:
	/* 0x20c8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20cb:
	/* 0x20cb: js     20a0 <trace_ret_inotify_find_inode+0x20a0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20cb, 0x20a0, x86_l_20a0);
x86_l_20cd:
	/* 0x20cd: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20cf:
	/* 0x20cf: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20d3:
	/* 0x20d3: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_20d6:
	/* 0x20d6: jns    20dd <trace_ret_inotify_find_inode+0x20dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20d6, 0x20dd, x86_l_20dd);
x86_l_20d8:
	/* 0x20d8: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20db:
	/* 0x20db: jmp    20e0 <trace_ret_inotify_find_inode+0x20e0> */
	X86_SIM_X86_JMP(0x20db, 0x20e0, x86_l_20e0);
x86_l_20dd:
	/* 0x20dd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20e0:
	/* 0x20e0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20e3:
	/* 0x20e3: je     215d <trace_ret_inotify_find_inode+0x215d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e3, 0x215d, x86_l_215d);
x86_l_20e5:
	/* 0x20e5: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_20e8:
	/* 0x20e8: je     215d <trace_ret_inotify_find_inode+0x215d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e8, 0x215d, x86_l_215d);
x86_l_20ea:
	/* 0x20ea: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20ee:
	/* 0x20ee: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20f1:
	/* 0x20f1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_20f7:
	/* 0x20f7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20fa:
	/* 0x20fa: jns    2103 <trace_ret_inotify_find_inode+0x2103> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20fa, 0x2103, x86_l_2103);
x86_l_20fc:
	/* 0x20fc: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20ff:
	/* 0x20ff: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2103:
	/* 0x2103: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2107:
	/* 0x2107: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_210a:
	/* 0x210a: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2111:
	/* 0x2111: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2113:
	/* 0x2113: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2116:
	/* 0x2116: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2116, 0x2967, x86_l_2967);
x86_l_211c:
	/* 0x211c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_211f:
	/* 0x211f: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x211f, 0x2914, x86_l_2914);
x86_l_2125:
	/* 0x2125: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_212b:
	/* 0x212b: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_212e:
	/* 0x212e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2131:
	/* 0x2131: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2131, 0x2785, x86_l_2785);
x86_l_2137:
	/* 0x2137: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_213b:
	/* 0x213b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_213e:
	/* 0x213e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2141:
	/* 0x2141: je     21ac <trace_ret_inotify_find_inode+0x21ac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2141, 0x21ac, x86_l_21ac);
x86_l_2143:
	/* 0x2143: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2147:
	/* 0x2147: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_214c:
	/* 0x214c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2150:
	/* 0x2150: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2153:
	/* 0x2153: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2156:
	/* 0x2156: jne    213e <trace_ret_inotify_find_inode+0x213e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2156, 0x213e, x86_l_213e);
x86_l_2158:
	/* 0x2158: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_215b:
	/* 0x215b: jmp    21b1 <trace_ret_inotify_find_inode+0x21b1> */
	X86_SIM_X86_JMP(0x215b, 0x21b1, x86_l_21b1);
x86_l_215d:
	/* 0x215d: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2160:
	/* 0x2160: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2160, 0x2914, x86_l_2914);
x86_l_2166:
	/* 0x2166: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2169:
	/* 0x2169: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2169, 0x2914, x86_l_2914);
x86_l_216f:
	/* 0x216f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2173:
	/* 0x2173: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2176:
	/* 0x2176: jns    217d <trace_ret_inotify_find_inode+0x217d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2176, 0x217d, x86_l_217d);
x86_l_2178:
	/* 0x2178: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217b:
	/* 0x217b: jmp    2180 <trace_ret_inotify_find_inode+0x2180> */
	X86_SIM_X86_JMP(0x217b, 0x2180, x86_l_2180);
x86_l_217d:
	/* 0x217d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2180:
	/* 0x2180: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2183:
	/* 0x2183: jns    218a <trace_ret_inotify_find_inode+0x218a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2183, 0x218a, x86_l_218a);
x86_l_2185:
	/* 0x2185: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2188:
	/* 0x2188: jmp    218c <trace_ret_inotify_find_inode+0x218c> */
	X86_SIM_X86_JMP(0x2188, 0x218c, x86_l_218c);
x86_l_218a:
	/* 0x218a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_218c:
	/* 0x218c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_218f:
	/* 0x218f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2192:
	/* 0x2192: jns    2199 <trace_ret_inotify_find_inode+0x2199> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2192, 0x2199, x86_l_2199);
x86_l_2194:
	/* 0x2194: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2197:
	/* 0x2197: jmp    219b <trace_ret_inotify_find_inode+0x219b> */
	X86_SIM_X86_JMP(0x2197, 0x219b, x86_l_219b);
x86_l_2199:
	/* 0x2199: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_219b:
	/* 0x219b: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_219f:
	/* 0x219f: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21a2:
	/* 0x21a2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21a5:
	/* 0x21a5: jns    21d4 <trace_ret_inotify_find_inode+0x21d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21a5, 0x21d4, x86_l_21d4);
x86_l_21a7:
	/* 0x21a7: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21aa:
	/* 0x21aa: jmp    21d6 <trace_ret_inotify_find_inode+0x21d6> */
	X86_SIM_X86_JMP(0x21aa, 0x21d6, x86_l_21d6);
x86_l_21ac:
	/* 0x21ac: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_21b1:
	/* 0x21b1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_21b5:
	/* 0x21b5: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x21b5, 0x2914, x86_l_2914);
x86_l_21bb:
	/* 0x21bb: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21be:
	/* 0x21be: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_21c4:
	/* 0x21c4: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_21c9:
	/* 0x21c9: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21cc:
	/* 0x21cc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21cf:
	/* 0x21cf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21d2:
	/* 0x21d2: js     21a7 <trace_ret_inotify_find_inode+0x21a7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21d2, 0x21a7, x86_l_21a7);
x86_l_21d4:
	/* 0x21d4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d6:
	/* 0x21d6: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21da:
	/* 0x21da: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21dd:
	/* 0x21dd: jns    21e4 <trace_ret_inotify_find_inode+0x21e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21dd, 0x21e4, x86_l_21e4);
x86_l_21df:
	/* 0x21df: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e2:
	/* 0x21e2: jmp    21e6 <trace_ret_inotify_find_inode+0x21e6> */
	X86_SIM_X86_JMP(0x21e2, 0x21e6, x86_l_21e6);
x86_l_21e4:
	/* 0x21e4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21e6:
	/* 0x21e6: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21e9:
	/* 0x21e9: je     2263 <trace_ret_inotify_find_inode+0x2263> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e9, 0x2263, x86_l_2263);
x86_l_21eb:
	/* 0x21eb: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21ee:
	/* 0x21ee: je     2263 <trace_ret_inotify_find_inode+0x2263> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ee, 0x2263, x86_l_2263);
x86_l_21f0:
	/* 0x21f0: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21f4:
	/* 0x21f4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21f7:
	/* 0x21f7: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_21fd:
	/* 0x21fd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2200:
	/* 0x2200: jns    2209 <trace_ret_inotify_find_inode+0x2209> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2200, 0x2209, x86_l_2209);
x86_l_2202:
	/* 0x2202: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2205:
	/* 0x2205: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2209:
	/* 0x2209: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_220d:
	/* 0x220d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2210:
	/* 0x2210: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2217:
	/* 0x2217: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2219:
	/* 0x2219: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_221c:
	/* 0x221c: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x221c, 0x2967, x86_l_2967);
x86_l_2222:
	/* 0x2222: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2225:
	/* 0x2225: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2225, 0x2911, x86_l_2911);
x86_l_222b:
	/* 0x222b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2231:
	/* 0x2231: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2234:
	/* 0x2234: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2237:
	/* 0x2237: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2237, 0x2788, x86_l_2788);
x86_l_223d:
	/* 0x223d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2241:
	/* 0x2241: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2244:
	/* 0x2244: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2247:
	/* 0x2247: je     22b1 <trace_ret_inotify_find_inode+0x22b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2247, 0x22b1, x86_l_22b1);
x86_l_2249:
	/* 0x2249: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_224d:
	/* 0x224d: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2252:
	/* 0x2252: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2256:
	/* 0x2256: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2259:
	/* 0x2259: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_225c:
	/* 0x225c: jne    2244 <trace_ret_inotify_find_inode+0x2244> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x225c, 0x2244, x86_l_2244);
x86_l_225e:
	/* 0x225e: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2261:
	/* 0x2261: jmp    22b6 <trace_ret_inotify_find_inode+0x22b6> */
	X86_SIM_X86_JMP(0x2261, 0x22b6, x86_l_22b6);
x86_l_2263:
	/* 0x2263: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2266:
	/* 0x2266: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2266, 0x2911, x86_l_2911);
x86_l_226c:
	/* 0x226c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_226f:
	/* 0x226f: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x226f, 0x2911, x86_l_2911);
x86_l_2275:
	/* 0x2275: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2279:
	/* 0x2279: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_227c:
	/* 0x227c: jns    2283 <trace_ret_inotify_find_inode+0x2283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x227c, 0x2283, x86_l_2283);
x86_l_227e:
	/* 0x227e: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2281:
	/* 0x2281: jmp    2285 <trace_ret_inotify_find_inode+0x2285> */
	X86_SIM_X86_JMP(0x2281, 0x2285, x86_l_2285);
x86_l_2283:
	/* 0x2283: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2285:
	/* 0x2285: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2288:
	/* 0x2288: jns    228f <trace_ret_inotify_find_inode+0x228f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2288, 0x228f, x86_l_228f);
x86_l_228a:
	/* 0x228a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_228d:
	/* 0x228d: jmp    2291 <trace_ret_inotify_find_inode+0x2291> */
	X86_SIM_X86_JMP(0x228d, 0x2291, x86_l_2291);
x86_l_228f:
	/* 0x228f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2291:
	/* 0x2291: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2294:
	/* 0x2294: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2297:
	/* 0x2297: jns    229e <trace_ret_inotify_find_inode+0x229e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2297, 0x229e, x86_l_229e);
x86_l_2299:
	/* 0x2299: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_229c:
	/* 0x229c: jmp    22a0 <trace_ret_inotify_find_inode+0x22a0> */
	X86_SIM_X86_JMP(0x229c, 0x22a0, x86_l_22a0);
x86_l_229e:
	/* 0x229e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22a0:
	/* 0x22a0: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22a4:
	/* 0x22a4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22a7:
	/* 0x22a7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22aa:
	/* 0x22aa: jns    22d9 <trace_ret_inotify_find_inode+0x22d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22aa, 0x22d9, x86_l_22d9);
x86_l_22ac:
	/* 0x22ac: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22af:
	/* 0x22af: jmp    22db <trace_ret_inotify_find_inode+0x22db> */
	X86_SIM_X86_JMP(0x22af, 0x22db, x86_l_22db);
x86_l_22b1:
	/* 0x22b1: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_22b6:
	/* 0x22b6: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_22ba:
	/* 0x22ba: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x22ba, 0x2911, x86_l_2911);
x86_l_22c0:
	/* 0x22c0: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_22c3:
	/* 0x22c3: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_22c9:
	/* 0x22c9: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_22ce:
	/* 0x22ce: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22d1:
	/* 0x22d1: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22d4:
	/* 0x22d4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22d7:
	/* 0x22d7: js     22ac <trace_ret_inotify_find_inode+0x22ac> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22d7, 0x22ac, x86_l_22ac);
x86_l_22d9:
	/* 0x22d9: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22db:
	/* 0x22db: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22df:
	/* 0x22df: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_22e2:
	/* 0x22e2: jns    22e9 <trace_ret_inotify_find_inode+0x22e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e2, 0x22e9, x86_l_22e9);
x86_l_22e4:
	/* 0x22e4: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22e7:
	/* 0x22e7: jmp    22ec <trace_ret_inotify_find_inode+0x22ec> */
	X86_SIM_X86_JMP(0x22e7, 0x22ec, x86_l_22ec);
x86_l_22e9:
	/* 0x22e9: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ec:
	/* 0x22ec: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22ef:
	/* 0x22ef: je     2369 <trace_ret_inotify_find_inode+0x2369> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22ef, 0x2369, x86_l_2369);
x86_l_22f1:
	/* 0x22f1: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_22f4:
	/* 0x22f4: je     2369 <trace_ret_inotify_find_inode+0x2369> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22f4, 0x2369, x86_l_2369);
x86_l_22f6:
	/* 0x22f6: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22fa:
	/* 0x22fa: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22fd:
	/* 0x22fd: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2303:
	/* 0x2303: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2306:
	/* 0x2306: jns    230f <trace_ret_inotify_find_inode+0x230f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2306, 0x230f, x86_l_230f);
x86_l_2308:
	/* 0x2308: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_230b:
	/* 0x230b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_230f:
	/* 0x230f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2313:
	/* 0x2313: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2316:
	/* 0x2316: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_231d:
	/* 0x231d: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_231f:
	/* 0x231f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2322:
	/* 0x2322: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2322, 0x2967, x86_l_2967);
x86_l_2328:
	/* 0x2328: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_232b:
	/* 0x232b: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x232b, 0x2914, x86_l_2914);
x86_l_2331:
	/* 0x2331: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2337:
	/* 0x2337: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_233a:
	/* 0x233a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_233d:
	/* 0x233d: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x233d, 0x2785, x86_l_2785);
x86_l_2343:
	/* 0x2343: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2347:
	/* 0x2347: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_234a:
	/* 0x234a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_234d:
	/* 0x234d: je     23b8 <trace_ret_inotify_find_inode+0x23b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234d, 0x23b8, x86_l_23b8);
x86_l_234f:
	/* 0x234f: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2353:
	/* 0x2353: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2358:
	/* 0x2358: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_235c:
	/* 0x235c: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_235f:
	/* 0x235f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2362:
	/* 0x2362: jne    234a <trace_ret_inotify_find_inode+0x234a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2362, 0x234a, x86_l_234a);
x86_l_2364:
	/* 0x2364: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2367:
	/* 0x2367: jmp    23bd <trace_ret_inotify_find_inode+0x23bd> */
	X86_SIM_X86_JMP(0x2367, 0x23bd, x86_l_23bd);
x86_l_2369:
	/* 0x2369: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_236c:
	/* 0x236c: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x236c, 0x2914, x86_l_2914);
x86_l_2372:
	/* 0x2372: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2375:
	/* 0x2375: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2375, 0x2914, x86_l_2914);
x86_l_237b:
	/* 0x237b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_237f:
	/* 0x237f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2382:
	/* 0x2382: jns    2389 <trace_ret_inotify_find_inode+0x2389> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2382, 0x2389, x86_l_2389);
x86_l_2384:
	/* 0x2384: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2387:
	/* 0x2387: jmp    238c <trace_ret_inotify_find_inode+0x238c> */
	X86_SIM_X86_JMP(0x2387, 0x238c, x86_l_238c);
x86_l_2389:
	/* 0x2389: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_238c:
	/* 0x238c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_238f:
	/* 0x238f: jns    2396 <trace_ret_inotify_find_inode+0x2396> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x238f, 0x2396, x86_l_2396);
x86_l_2391:
	/* 0x2391: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2394:
	/* 0x2394: jmp    2398 <trace_ret_inotify_find_inode+0x2398> */
	X86_SIM_X86_JMP(0x2394, 0x2398, x86_l_2398);
x86_l_2396:
	/* 0x2396: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2398:
	/* 0x2398: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_239b:
	/* 0x239b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_239e:
	/* 0x239e: jns    23a5 <trace_ret_inotify_find_inode+0x23a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x239e, 0x23a5, x86_l_23a5);
x86_l_23a0:
	/* 0x23a0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23a3:
	/* 0x23a3: jmp    23a7 <trace_ret_inotify_find_inode+0x23a7> */
	X86_SIM_X86_JMP(0x23a3, 0x23a7, x86_l_23a7);
x86_l_23a5:
	/* 0x23a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23a7:
	/* 0x23a7: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23ab:
	/* 0x23ab: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23ae:
	/* 0x23ae: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23b1:
	/* 0x23b1: jns    23e0 <trace_ret_inotify_find_inode+0x23e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23b1, 0x23e0, x86_l_23e0);
x86_l_23b3:
	/* 0x23b3: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23b6:
	/* 0x23b6: jmp    23e2 <trace_ret_inotify_find_inode+0x23e2> */
	X86_SIM_X86_JMP(0x23b6, 0x23e2, x86_l_23e2);
x86_l_23b8:
	/* 0x23b8: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_23bd:
	/* 0x23bd: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_23c1:
	/* 0x23c1: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x23c1, 0x2914, x86_l_2914);
x86_l_23c7:
	/* 0x23c7: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23ca:
	/* 0x23ca: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23d0:
	/* 0x23d0: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_23d5:
	/* 0x23d5: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23d8:
	/* 0x23d8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23db:
	/* 0x23db: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23de:
	/* 0x23de: js     23b3 <trace_ret_inotify_find_inode+0x23b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23de, 0x23b3, x86_l_23b3);
x86_l_23e0:
	/* 0x23e0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e2:
	/* 0x23e2: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23e6:
	/* 0x23e6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23e9:
	/* 0x23e9: jns    23f0 <trace_ret_inotify_find_inode+0x23f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23e9, 0x23f0, x86_l_23f0);
x86_l_23eb:
	/* 0x23eb: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ee:
	/* 0x23ee: jmp    23f2 <trace_ret_inotify_find_inode+0x23f2> */
	X86_SIM_X86_JMP(0x23ee, 0x23f2, x86_l_23f2);
x86_l_23f0:
	/* 0x23f0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23f2:
	/* 0x23f2: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23f5:
	/* 0x23f5: je     246f <trace_ret_inotify_find_inode+0x246f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f5, 0x246f, x86_l_246f);
x86_l_23f7:
	/* 0x23f7: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23fa:
	/* 0x23fa: je     246f <trace_ret_inotify_find_inode+0x246f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23fa, 0x246f, x86_l_246f);
x86_l_23fc:
	/* 0x23fc: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2400:
	/* 0x2400: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2403:
	/* 0x2403: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2409:
	/* 0x2409: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_240c:
	/* 0x240c: jns    2415 <trace_ret_inotify_find_inode+0x2415> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x240c, 0x2415, x86_l_2415);
x86_l_240e:
	/* 0x240e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2411:
	/* 0x2411: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2415:
	/* 0x2415: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2419:
	/* 0x2419: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_241c:
	/* 0x241c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2423:
	/* 0x2423: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2425:
	/* 0x2425: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2428:
	/* 0x2428: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2428, 0x2967, x86_l_2967);
x86_l_242e:
	/* 0x242e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2431:
	/* 0x2431: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2431, 0x2911, x86_l_2911);
x86_l_2437:
	/* 0x2437: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_243d:
	/* 0x243d: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2440:
	/* 0x2440: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2443:
	/* 0x2443: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2443, 0x2788, x86_l_2788);
x86_l_2449:
	/* 0x2449: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_244d:
	/* 0x244d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2450:
	/* 0x2450: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2453:
	/* 0x2453: je     24bd <trace_ret_inotify_find_inode+0x24bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2453, 0x24bd, x86_l_24bd);
x86_l_2455:
	/* 0x2455: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2459:
	/* 0x2459: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_245e:
	/* 0x245e: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2462:
	/* 0x2462: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2465:
	/* 0x2465: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2468:
	/* 0x2468: jne    2450 <trace_ret_inotify_find_inode+0x2450> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2468, 0x2450, x86_l_2450);
x86_l_246a:
	/* 0x246a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_246d:
	/* 0x246d: jmp    24c2 <trace_ret_inotify_find_inode+0x24c2> */
	X86_SIM_X86_JMP(0x246d, 0x24c2, x86_l_24c2);
x86_l_246f:
	/* 0x246f: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2472:
	/* 0x2472: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2472, 0x2911, x86_l_2911);
x86_l_2478:
	/* 0x2478: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_247b:
	/* 0x247b: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x247b, 0x2911, x86_l_2911);
x86_l_2481:
	/* 0x2481: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2485:
	/* 0x2485: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2488:
	/* 0x2488: jns    248f <trace_ret_inotify_find_inode+0x248f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2488, 0x248f, x86_l_248f);
x86_l_248a:
	/* 0x248a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248d:
	/* 0x248d: jmp    2491 <trace_ret_inotify_find_inode+0x2491> */
	X86_SIM_X86_JMP(0x248d, 0x2491, x86_l_2491);
x86_l_248f:
	/* 0x248f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2491:
	/* 0x2491: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2494:
	/* 0x2494: jns    249b <trace_ret_inotify_find_inode+0x249b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2494, 0x249b, x86_l_249b);
x86_l_2496:
	/* 0x2496: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2499:
	/* 0x2499: jmp    249d <trace_ret_inotify_find_inode+0x249d> */
	X86_SIM_X86_JMP(0x2499, 0x249d, x86_l_249d);
x86_l_249b:
	/* 0x249b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_249d:
	/* 0x249d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24a0:
	/* 0x24a0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24a3:
	/* 0x24a3: jns    24aa <trace_ret_inotify_find_inode+0x24aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24a3, 0x24aa, x86_l_24aa);
x86_l_24a5:
	/* 0x24a5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24a8:
	/* 0x24a8: jmp    24ac <trace_ret_inotify_find_inode+0x24ac> */
	X86_SIM_X86_JMP(0x24a8, 0x24ac, x86_l_24ac);
x86_l_24aa:
	/* 0x24aa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ac:
	/* 0x24ac: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24b0:
	/* 0x24b0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24b3:
	/* 0x24b3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24b6:
	/* 0x24b6: jns    24e5 <trace_ret_inotify_find_inode+0x24e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24b6, 0x24e5, x86_l_24e5);
x86_l_24b8:
	/* 0x24b8: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24bb:
	/* 0x24bb: jmp    24e7 <trace_ret_inotify_find_inode+0x24e7> */
	X86_SIM_X86_JMP(0x24bb, 0x24e7, x86_l_24e7);
x86_l_24bd:
	/* 0x24bd: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_24c2:
	/* 0x24c2: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24c6:
	/* 0x24c6: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x24c6, 0x2911, x86_l_2911);
x86_l_24cc:
	/* 0x24cc: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24cf:
	/* 0x24cf: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_24d5:
	/* 0x24d5: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_24da:
	/* 0x24da: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24dd:
	/* 0x24dd: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24e0:
	/* 0x24e0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24e3:
	/* 0x24e3: js     24b8 <trace_ret_inotify_find_inode+0x24b8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24e3, 0x24b8, x86_l_24b8);
x86_l_24e5:
	/* 0x24e5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e7:
	/* 0x24e7: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24eb:
	/* 0x24eb: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24ee:
	/* 0x24ee: jns    24f5 <trace_ret_inotify_find_inode+0x24f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ee, 0x24f5, x86_l_24f5);
x86_l_24f0:
	/* 0x24f0: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24f3:
	/* 0x24f3: jmp    24f8 <trace_ret_inotify_find_inode+0x24f8> */
	X86_SIM_X86_JMP(0x24f3, 0x24f8, x86_l_24f8);
x86_l_24f5:
	/* 0x24f5: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f8:
	/* 0x24f8: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24fb:
	/* 0x24fb: je     2575 <trace_ret_inotify_find_inode+0x2575> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24fb, 0x2575, x86_l_2575);
x86_l_24fd:
	/* 0x24fd: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2500:
	/* 0x2500: je     2575 <trace_ret_inotify_find_inode+0x2575> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2500, 0x2575, x86_l_2575);
x86_l_2502:
	/* 0x2502: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2506:
	/* 0x2506: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2509:
	/* 0x2509: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_250f:
	/* 0x250f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2512:
	/* 0x2512: jns    251b <trace_ret_inotify_find_inode+0x251b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2512, 0x251b, x86_l_251b);
x86_l_2514:
	/* 0x2514: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2517:
	/* 0x2517: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_251b:
	/* 0x251b: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_251f:
	/* 0x251f: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2522:
	/* 0x2522: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2529:
	/* 0x2529: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_252b:
	/* 0x252b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_252e:
	/* 0x252e: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x252e, 0x2967, x86_l_2967);
x86_l_2534:
	/* 0x2534: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2537:
	/* 0x2537: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2537, 0x2914, x86_l_2914);
x86_l_253d:
	/* 0x253d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2543:
	/* 0x2543: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2546:
	/* 0x2546: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2549:
	/* 0x2549: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2549, 0x2785, x86_l_2785);
x86_l_254f:
	/* 0x254f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2553:
	/* 0x2553: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2556:
	/* 0x2556: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2559:
	/* 0x2559: je     25c4 <trace_ret_inotify_find_inode+0x25c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2559, 0x25c4, x86_l_25c4);
x86_l_255b:
	/* 0x255b: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_255f:
	/* 0x255f: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2564:
	/* 0x2564: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2568:
	/* 0x2568: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_256b:
	/* 0x256b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_256e:
	/* 0x256e: jne    2556 <trace_ret_inotify_find_inode+0x2556> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x256e, 0x2556, x86_l_2556);
x86_l_2570:
	/* 0x2570: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2573:
	/* 0x2573: jmp    25c9 <trace_ret_inotify_find_inode+0x25c9> */
	X86_SIM_X86_JMP(0x2573, 0x25c9, x86_l_25c9);
x86_l_2575:
	/* 0x2575: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2578:
	/* 0x2578: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2578, 0x2914, x86_l_2914);
x86_l_257e:
	/* 0x257e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2581:
	/* 0x2581: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2581, 0x2914, x86_l_2914);
x86_l_2587:
	/* 0x2587: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_258b:
	/* 0x258b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_258e:
	/* 0x258e: jns    2595 <trace_ret_inotify_find_inode+0x2595> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x258e, 0x2595, x86_l_2595);
x86_l_2590:
	/* 0x2590: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2593:
	/* 0x2593: jmp    2598 <trace_ret_inotify_find_inode+0x2598> */
	X86_SIM_X86_JMP(0x2593, 0x2598, x86_l_2598);
x86_l_2595:
	/* 0x2595: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2598:
	/* 0x2598: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_259b:
	/* 0x259b: jns    25a2 <trace_ret_inotify_find_inode+0x25a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x259b, 0x25a2, x86_l_25a2);
x86_l_259d:
	/* 0x259d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25a0:
	/* 0x25a0: jmp    25a4 <trace_ret_inotify_find_inode+0x25a4> */
	X86_SIM_X86_JMP(0x25a0, 0x25a4, x86_l_25a4);
x86_l_25a2:
	/* 0x25a2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25a4:
	/* 0x25a4: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25a7:
	/* 0x25a7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25aa:
	/* 0x25aa: jns    25b1 <trace_ret_inotify_find_inode+0x25b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25aa, 0x25b1, x86_l_25b1);
x86_l_25ac:
	/* 0x25ac: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25af:
	/* 0x25af: jmp    25b3 <trace_ret_inotify_find_inode+0x25b3> */
	X86_SIM_X86_JMP(0x25af, 0x25b3, x86_l_25b3);
x86_l_25b1:
	/* 0x25b1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b3:
	/* 0x25b3: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25b7:
	/* 0x25b7: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25ba:
	/* 0x25ba: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25bd:
	/* 0x25bd: jns    25ec <trace_ret_inotify_find_inode+0x25ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25bd, 0x25ec, x86_l_25ec);
x86_l_25bf:
	/* 0x25bf: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25c2:
	/* 0x25c2: jmp    25ee <trace_ret_inotify_find_inode+0x25ee> */
	X86_SIM_X86_JMP(0x25c2, 0x25ee, x86_l_25ee);
x86_l_25c4:
	/* 0x25c4: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_25c9:
	/* 0x25c9: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_25cd:
	/* 0x25cd: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x25cd, 0x2914, x86_l_2914);
x86_l_25d3:
	/* 0x25d3: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25d6:
	/* 0x25d6: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_25dc:
	/* 0x25dc: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_25e1:
	/* 0x25e1: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25e4:
	/* 0x25e4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25e7:
	/* 0x25e7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25ea:
	/* 0x25ea: js     25bf <trace_ret_inotify_find_inode+0x25bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25ea, 0x25bf, x86_l_25bf);
x86_l_25ec:
	/* 0x25ec: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25ee:
	/* 0x25ee: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25f2:
	/* 0x25f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25f5:
	/* 0x25f5: jns    25fc <trace_ret_inotify_find_inode+0x25fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25f5, 0x25fc, x86_l_25fc);
x86_l_25f7:
	/* 0x25f7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25fa:
	/* 0x25fa: jmp    25fe <trace_ret_inotify_find_inode+0x25fe> */
	X86_SIM_X86_JMP(0x25fa, 0x25fe, x86_l_25fe);
x86_l_25fc:
	/* 0x25fc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25fe:
	/* 0x25fe: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2601:
	/* 0x2601: je     267b <trace_ret_inotify_find_inode+0x267b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2601, 0x267b, x86_l_267b);
x86_l_2603:
	/* 0x2603: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2606:
	/* 0x2606: je     267b <trace_ret_inotify_find_inode+0x267b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2606, 0x267b, x86_l_267b);
x86_l_2608:
	/* 0x2608: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_260c:
	/* 0x260c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_260f:
	/* 0x260f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2615:
	/* 0x2615: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2618:
	/* 0x2618: jns    2621 <trace_ret_inotify_find_inode+0x2621> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2618, 0x2621, x86_l_2621);
x86_l_261a:
	/* 0x261a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_261d:
	/* 0x261d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2621:
	/* 0x2621: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2625:
	/* 0x2625: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2628:
	/* 0x2628: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_262f:
	/* 0x262f: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2631:
	/* 0x2631: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2634:
	/* 0x2634: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2634, 0x2967, x86_l_2967);
x86_l_263a:
	/* 0x263a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_263d:
	/* 0x263d: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x263d, 0x2911, x86_l_2911);
x86_l_2643:
	/* 0x2643: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2649:
	/* 0x2649: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_264c:
	/* 0x264c: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_264f:
	/* 0x264f: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x264f, 0x2788, x86_l_2788);
x86_l_2655:
	/* 0x2655: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2659:
	/* 0x2659: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_265c:
	/* 0x265c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_265f:
	/* 0x265f: je     26c9 <trace_ret_inotify_find_inode+0x26c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x265f, 0x26c9, x86_l_26c9);
x86_l_2661:
	/* 0x2661: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2665:
	/* 0x2665: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_266a:
	/* 0x266a: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_266e:
	/* 0x266e: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2671:
	/* 0x2671: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2674:
	/* 0x2674: jne    265c <trace_ret_inotify_find_inode+0x265c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2674, 0x265c, x86_l_265c);
x86_l_2676:
	/* 0x2676: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2679:
	/* 0x2679: jmp    26ce <trace_ret_inotify_find_inode+0x26ce> */
	X86_SIM_X86_JMP(0x2679, 0x26ce, x86_l_26ce);
x86_l_267b:
	/* 0x267b: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_267e:
	/* 0x267e: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x267e, 0x2911, x86_l_2911);
x86_l_2684:
	/* 0x2684: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2687:
	/* 0x2687: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2687, 0x2911, x86_l_2911);
x86_l_268d:
	/* 0x268d: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2691:
	/* 0x2691: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2694:
	/* 0x2694: jns    269b <trace_ret_inotify_find_inode+0x269b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2694, 0x269b, x86_l_269b);
x86_l_2696:
	/* 0x2696: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2699:
	/* 0x2699: jmp    269d <trace_ret_inotify_find_inode+0x269d> */
	X86_SIM_X86_JMP(0x2699, 0x269d, x86_l_269d);
x86_l_269b:
	/* 0x269b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269d:
	/* 0x269d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a0:
	/* 0x26a0: jns    26a7 <trace_ret_inotify_find_inode+0x26a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26a0, 0x26a7, x86_l_26a7);
x86_l_26a2:
	/* 0x26a2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a5:
	/* 0x26a5: jmp    26a9 <trace_ret_inotify_find_inode+0x26a9> */
	X86_SIM_X86_JMP(0x26a5, 0x26a9, x86_l_26a9);
x86_l_26a7:
	/* 0x26a7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26a9:
	/* 0x26a9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26ac:
	/* 0x26ac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26af:
	/* 0x26af: jns    26b6 <trace_ret_inotify_find_inode+0x26b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26af, 0x26b6, x86_l_26b6);
x86_l_26b1:
	/* 0x26b1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b4:
	/* 0x26b4: jmp    26b8 <trace_ret_inotify_find_inode+0x26b8> */
	X86_SIM_X86_JMP(0x26b4, 0x26b8, x86_l_26b8);
x86_l_26b6:
	/* 0x26b6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b8:
	/* 0x26b8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26bc:
	/* 0x26bc: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26bf:
	/* 0x26bf: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26c2:
	/* 0x26c2: jns    26f1 <trace_ret_inotify_find_inode+0x26f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26c2, 0x26f1, x86_l_26f1);
x86_l_26c4:
	/* 0x26c4: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c7:
	/* 0x26c7: jmp    26f3 <trace_ret_inotify_find_inode+0x26f3> */
	X86_SIM_X86_JMP(0x26c7, 0x26f3, x86_l_26f3);
x86_l_26c9:
	/* 0x26c9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_26ce:
	/* 0x26ce: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_26d2:
	/* 0x26d2: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x26d2, 0x2911, x86_l_2911);
x86_l_26d8:
	/* 0x26d8: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26db:
	/* 0x26db: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_26e1:
	/* 0x26e1: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_26e6:
	/* 0x26e6: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26e9:
	/* 0x26e9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26ec:
	/* 0x26ec: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26ef:
	/* 0x26ef: js     26c4 <trace_ret_inotify_find_inode+0x26c4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26ef, 0x26c4, x86_l_26c4);
x86_l_26f1:
	/* 0x26f1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26f3:
	/* 0x26f3: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26f7:
	/* 0x26f7: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26fa:
	/* 0x26fa: jns    2701 <trace_ret_inotify_find_inode+0x2701> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26fa, 0x2701, x86_l_2701);
x86_l_26fc:
	/* 0x26fc: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ff:
	/* 0x26ff: jmp    2704 <trace_ret_inotify_find_inode+0x2704> */
	X86_SIM_X86_JMP(0x26ff, 0x2704, x86_l_2704);
x86_l_2701:
	/* 0x2701: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2704:
	/* 0x2704: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2707:
	/* 0x2707: je     2796 <trace_ret_inotify_find_inode+0x2796> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2707, 0x2796, x86_l_2796);
x86_l_270d:
	/* 0x270d: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2710:
	/* 0x2710: je     2796 <trace_ret_inotify_find_inode+0x2796> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2710, 0x2796, x86_l_2796);
x86_l_2716:
	/* 0x2716: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_271a:
	/* 0x271a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_271d:
	/* 0x271d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2723:
	/* 0x2723: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2726:
	/* 0x2726: jns    272f <trace_ret_inotify_find_inode+0x272f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2726, 0x272f, x86_l_272f);
x86_l_2728:
	/* 0x2728: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_272b:
	/* 0x272b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_272f:
	/* 0x272f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2733:
	/* 0x2733: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2736:
	/* 0x2736: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_273d:
	/* 0x273d: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_273f:
	/* 0x273f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2742:
	/* 0x2742: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2742, 0x2967, x86_l_2967);
x86_l_2748:
	/* 0x2748: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_274b:
	/* 0x274b: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x274b, 0x2914, x86_l_2914);
x86_l_2751:
	/* 0x2751: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2757:
	/* 0x2757: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_275a:
	/* 0x275a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_275d:
	/* 0x275d: jns    2785 <trace_ret_inotify_find_inode+0x2785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x275d, 0x2785, x86_l_2785);
x86_l_275f:
	/* 0x275f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2763:
	/* 0x2763: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2766:
	/* 0x2766: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2769:
	/* 0x2769: je     27e5 <trace_ret_inotify_find_inode+0x27e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2769, 0x27e5, x86_l_27e5);
x86_l_276b:
	/* 0x276b: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_276f:
	/* 0x276f: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2774:
	/* 0x2774: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2778:
	/* 0x2778: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_277b:
	/* 0x277b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_277e:
	/* 0x277e: jne    2766 <trace_ret_inotify_find_inode+0x2766> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277e, 0x2766, x86_l_2766);
x86_l_2780:
	/* 0x2780: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2783:
	/* 0x2783: jmp    27ea <trace_ret_inotify_find_inode+0x27ea> */
	X86_SIM_X86_JMP(0x2783, 0x27ea, x86_l_27ea);
x86_l_2785:
	/* 0x2785: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2788:
	/* 0x2788: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278c:
	/* 0x278c: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2791:
	/* 0x2791: jmp    117f <trace_ret_inotify_find_inode+0x117f> */
	X86_SIM_X86_JMP(0x2791, 0x117f, x86_l_117f);
x86_l_2796:
	/* 0x2796: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2799:
	/* 0x2799: jne    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2799, 0x2914, x86_l_2914);
x86_l_279f:
	/* 0x279f: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27a2:
	/* 0x27a2: je     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a2, 0x2914, x86_l_2914);
x86_l_27a8:
	/* 0x27a8: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27ac:
	/* 0x27ac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27af:
	/* 0x27af: jns    27b6 <trace_ret_inotify_find_inode+0x27b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27af, 0x27b6, x86_l_27b6);
x86_l_27b1:
	/* 0x27b1: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27b4:
	/* 0x27b4: jmp    27b9 <trace_ret_inotify_find_inode+0x27b9> */
	X86_SIM_X86_JMP(0x27b4, 0x27b9, x86_l_27b9);
x86_l_27b6:
	/* 0x27b6: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b9:
	/* 0x27b9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27bc:
	/* 0x27bc: jns    27c3 <trace_ret_inotify_find_inode+0x27c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27bc, 0x27c3, x86_l_27c3);
x86_l_27be:
	/* 0x27be: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c1:
	/* 0x27c1: jmp    27c5 <trace_ret_inotify_find_inode+0x27c5> */
	X86_SIM_X86_JMP(0x27c1, 0x27c5, x86_l_27c5);
x86_l_27c3:
	/* 0x27c3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27c5:
	/* 0x27c5: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27c8:
	/* 0x27c8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27cb:
	/* 0x27cb: jns    27d2 <trace_ret_inotify_find_inode+0x27d2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27cb, 0x27d2, x86_l_27d2);
x86_l_27cd:
	/* 0x27cd: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d0:
	/* 0x27d0: jmp    27d4 <trace_ret_inotify_find_inode+0x27d4> */
	X86_SIM_X86_JMP(0x27d0, 0x27d4, x86_l_27d4);
x86_l_27d2:
	/* 0x27d2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27d4:
	/* 0x27d4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27d8:
	/* 0x27d8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27db:
	/* 0x27db: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27de:
	/* 0x27de: jns    280d <trace_ret_inotify_find_inode+0x280d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27de, 0x280d, x86_l_280d);
x86_l_27e0:
	/* 0x27e0: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27e3:
	/* 0x27e3: jmp    280f <trace_ret_inotify_find_inode+0x280f> */
	X86_SIM_X86_JMP(0x27e3, 0x280f, x86_l_280f);
x86_l_27e5:
	/* 0x27e5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_27ea:
	/* 0x27ea: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27ee:
	/* 0x27ee: jl     2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_L, 0x27ee, 0x2914, x86_l_2914);
x86_l_27f4:
	/* 0x27f4: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27f7:
	/* 0x27f7: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_27fd:
	/* 0x27fd: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2802:
	/* 0x2802: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2805:
	/* 0x2805: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2808:
	/* 0x2808: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_280b:
	/* 0x280b: js     27e0 <trace_ret_inotify_find_inode+0x27e0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x280b, 0x27e0, x86_l_27e0);
x86_l_280d:
	/* 0x280d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_280f:
	/* 0x280f: lea    rdi,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2813:
	/* 0x2813: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2816:
	/* 0x2816: jns    281d <trace_ret_inotify_find_inode+0x281d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2816, 0x281d, x86_l_281d);
x86_l_2818:
	/* 0x2818: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_281b:
	/* 0x281b: jmp    2820 <trace_ret_inotify_find_inode+0x2820> */
	X86_SIM_X86_JMP(0x281b, 0x2820, x86_l_2820);
x86_l_281d:
	/* 0x281d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2820:
	/* 0x2820: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2823:
	/* 0x2823: je     289c <trace_ret_inotify_find_inode+0x289c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2823, 0x289c, x86_l_289c);
x86_l_2825:
	/* 0x2825: cmp    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2828:
	/* 0x2828: je     289c <trace_ret_inotify_find_inode+0x289c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2828, 0x289c, x86_l_289c);
x86_l_282a:
	/* 0x282a: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_282e:
	/* 0x282e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2831:
	/* 0x2831: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2836:
	/* 0x2836: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2839:
	/* 0x2839: jns    2842 <trace_ret_inotify_find_inode+0x2842> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2839, 0x2842, x86_l_2842);
x86_l_283b:
	/* 0x283b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_283e:
	/* 0x283e: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2842:
	/* 0x2842: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2846:
	/* 0x2846: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2849:
	/* 0x2849: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2850:
	/* 0x2850: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2852:
	/* 0x2852: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2855:
	/* 0x2855: jb     2967 <trace_ret_inotify_find_inode+0x2967> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2855, 0x2967, x86_l_2967);
x86_l_285b:
	/* 0x285b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_285e:
	/* 0x285e: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285e, 0x2911, x86_l_2911);
x86_l_2864:
	/* 0x2864: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_286a:
	/* 0x286a: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_286d:
	/* 0x286d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2870:
	/* 0x2870: jns    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2870, 0x2788, x86_l_2788);
x86_l_2876:
	/* 0x2876: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_287a:
	/* 0x287a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_287d:
	/* 0x287d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2880:
	/* 0x2880: je     28e0 <trace_ret_inotify_find_inode+0x28e0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2880, 0x28e0, x86_l_28e0);
x86_l_2882:
	/* 0x2882: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2886:
	/* 0x2886: movzx  r12d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_288b:
	/* 0x288b: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_288f:
	/* 0x288f: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2892:
	/* 0x2892: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2895:
	/* 0x2895: jne    287d <trace_ret_inotify_find_inode+0x287d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2895, 0x287d, x86_l_287d);
x86_l_2897:
	/* 0x2897: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_289a:
	/* 0x289a: jmp    28e5 <trace_ret_inotify_find_inode+0x28e5> */
	X86_SIM_X86_JMP(0x289a, 0x28e5, x86_l_28e5);
x86_l_289c:
	/* 0x289c: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_289f:
	/* 0x289f: jne    2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x289f, 0x2911, x86_l_2911);
x86_l_28a1:
	/* 0x28a1: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: je     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a4, 0x2911, x86_l_2911);
x86_l_28a6:
	/* 0x28a6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28aa:
	/* 0x28aa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28ad:
	/* 0x28ad: jns    28b4 <trace_ret_inotify_find_inode+0x28b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ad, 0x28b4, x86_l_28b4);
x86_l_28af:
	/* 0x28af: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b2:
	/* 0x28b2: jmp    28b7 <trace_ret_inotify_find_inode+0x28b7> */
	X86_SIM_X86_JMP(0x28b2, 0x28b7, x86_l_28b7);
x86_l_28b4:
	/* 0x28b4: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b7:
	/* 0x28b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28ba:
	/* 0x28ba: jns    28c1 <trace_ret_inotify_find_inode+0x28c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ba, 0x28c1, x86_l_28c1);
x86_l_28bc:
	/* 0x28bc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28bf:
	/* 0x28bf: jmp    28c3 <trace_ret_inotify_find_inode+0x28c3> */
	X86_SIM_X86_JMP(0x28bf, 0x28c3, x86_l_28c3);
x86_l_28c1:
	/* 0x28c1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c3:
	/* 0x28c3: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28c6:
	/* 0x28c6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28c9:
	/* 0x28c9: jns    28d0 <trace_ret_inotify_find_inode+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c9, 0x28d0, x86_l_28d0);
x86_l_28cb:
	/* 0x28cb: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ce:
	/* 0x28ce: jmp    28d2 <trace_ret_inotify_find_inode+0x28d2> */
	X86_SIM_X86_JMP(0x28ce, 0x28d2, x86_l_28d2);
x86_l_28d0:
	/* 0x28d0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d2:
	/* 0x28d2: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28d6:
	/* 0x28d6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28d9:
	/* 0x28d9: jns    2901 <trace_ret_inotify_find_inode+0x2901> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28d9, 0x2901, x86_l_2901);
x86_l_28db:
	/* 0x28db: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28de:
	/* 0x28de: jmp    2903 <trace_ret_inotify_find_inode+0x2903> */
	X86_SIM_X86_JMP(0x28de, 0x2903, x86_l_2903);
x86_l_28e0:
	/* 0x28e0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_28e5:
	/* 0x28e5: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_28e9:
	/* 0x28e9: jl     2911 <trace_ret_inotify_find_inode+0x2911> */
	X86_SIM_X86_JCC(X86_CC_L, 0x28e9, 0x2911, x86_l_2911);
x86_l_28eb:
	/* 0x28eb: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_28ee:
	/* 0x28ee: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_28f4:
	/* 0x28f4: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_28f9:
	/* 0x28f9: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28fc:
	/* 0x28fc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28ff:
	/* 0x28ff: js     28db <trace_ret_inotify_find_inode+0x28db> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ff, 0x28db, x86_l_28db);
x86_l_2901:
	/* 0x2901: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2903:
	/* 0x2903: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2907:
	/* 0x2907: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_290a:
	/* 0x290a: jns    2922 <trace_ret_inotify_find_inode+0x2922> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x290a, 0x2922, x86_l_2922);
x86_l_290c:
	/* 0x290c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_290f:
	/* 0x290f: jmp    2924 <trace_ret_inotify_find_inode+0x2924> */
	X86_SIM_X86_JMP(0x290f, 0x2924, x86_l_2924);
x86_l_2911:
	/* 0x2911: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2914:
	/* 0x2914: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2918:
	/* 0x2918: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_291d:
	/* 0x291d: jmp    118c <trace_ret_inotify_find_inode+0x118c> */
	X86_SIM_X86_JMP(0x291d, 0x118c, x86_l_118c);
x86_l_2922:
	/* 0x2922: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2924:
	/* 0x2924: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2927:
	/* 0x2927: je     3137 <trace_ret_inotify_find_inode+0x3137> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2927, 0x3137, x86_l_3137);
x86_l_292d:
	/* 0x292d: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2930:
	/* 0x2930: je     3137 <trace_ret_inotify_find_inode+0x3137> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2930, 0x3137, x86_l_3137);
x86_l_2936:
	/* 0x2936: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_293a:
	/* 0x293a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_293d:
	/* 0x293d: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2942:
	/* 0x2942: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2945:
	/* 0x2945: jns    294e <trace_ret_inotify_find_inode+0x294e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2945, 0x294e, x86_l_294e);
x86_l_2947:
	/* 0x2947: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_294a:
	/* 0x294a: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_294e:
	/* 0x294e: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2952:
	/* 0x2952: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2955:
	/* 0x2955: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_295c:
	/* 0x295c: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_295e:
	/* 0x295e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2961:
	/* 0x2961: jae    3157 <trace_ret_inotify_find_inode+0x3157> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2961, 0x3157, x86_l_3157);
x86_l_2967:
	/* 0x2967: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_296b:
	/* 0x296b: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2970:
	/* 0x2970: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2972:
	/* 0x2972: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2974:
	/* 0x2974: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2979:
	/* 0x2979: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_297e:
	/* 0x297e: mov    BYTE PTR [rbp+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2985:
	/* 0x2985: and    ebx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_298b:
	/* 0x298b: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_298e:
	/* 0x298e: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2992:
	/* 0x2992: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2995:
	/* 0x2995: jns    d11 <trace_ret_inotify_find_inode+0xd11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2995, 0xd11, x86_l_d11);
x86_l_299b:
	/* 0x299b: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_299f:
	/* 0x299f: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_29a3:
	/* 0x29a3: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29a6:
	/* 0x29a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29a9:
	/* 0x29a9: jns    29c7 <trace_ret_inotify_find_inode+0x29c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29a9, 0x29c7, x86_l_29c7);
x86_l_29ab:
	/* 0x29ab: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ae:
	/* 0x29ae: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29b2:
	/* 0x29b2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29b5:
	/* 0x29b5: js     29d2 <trace_ret_inotify_find_inode+0x29d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29b5, 0x29d2, x86_l_29d2);
x86_l_29b7:
	/* 0x29b7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29b9:
	/* 0x29b9: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29be:
	/* 0x29be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29c1:
	/* 0x29c1: js     29df <trace_ret_inotify_find_inode+0x29df> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29c1, 0x29df, x86_l_29df);
x86_l_29c3:
	/* 0x29c3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c5:
	/* 0x29c5: jmp    29e2 <trace_ret_inotify_find_inode+0x29e2> */
	X86_SIM_X86_JMP(0x29c5, 0x29e2, x86_l_29e2);
x86_l_29c7:
	/* 0x29c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c9:
	/* 0x29c9: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29cd:
	/* 0x29cd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29d0:
	/* 0x29d0: jns    29b7 <trace_ret_inotify_find_inode+0x29b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d0, 0x29b7, x86_l_29b7);
x86_l_29d2:
	/* 0x29d2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d5:
	/* 0x29d5: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29da:
	/* 0x29da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29dd:
	/* 0x29dd: jns    29c3 <trace_ret_inotify_find_inode+0x29c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29dd, 0x29c3, x86_l_29c3);
x86_l_29df:
	/* 0x29df: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29e2:
	/* 0x29e2: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29e6:
	/* 0x29e6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e8:
	/* 0x29e8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29eb:
	/* 0x29eb: jns    29f7 <trace_ret_inotify_find_inode+0x29f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29eb, 0x29f7, x86_l_29f7);
x86_l_29ed:
	/* 0x29ed: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f0:
	/* 0x29f0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29f3:
	/* 0x29f3: js     29fe <trace_ret_inotify_find_inode+0x29fe> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29f3, 0x29fe, x86_l_29fe);
x86_l_29f5:
	/* 0x29f5: jmp    2a00 <trace_ret_inotify_find_inode+0x2a00> */
	X86_SIM_X86_JMP(0x29f5, 0x2a00, x86_l_2a00);
x86_l_29f7:
	/* 0x29f7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f9:
	/* 0x29f9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29fc:
	/* 0x29fc: jns    2a00 <trace_ret_inotify_find_inode+0x2a00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29fc, 0x2a00, x86_l_2a00);
x86_l_29fe:
	/* 0x29fe: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a00:
	/* 0x2a00: mov    DWORD PTR [rsp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2a04:
	/* 0x2a04: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a0c:
	/* 0x2a0c: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2a12:
	/* 0x2a12: ja     2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a12, 0x2af0, x86_l_2af0);
x86_l_2a18:
	/* 0x2a18: mov    BYTE PTR [r13+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_2a21:
	/* 0x2a21: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a29:
	/* 0x2a29: mov    WORD PTR [r13+0x7d8c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2a31:
	/* 0x2a31: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2a37:
	/* 0x2a37: ja     2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a37, 0x2af0, x86_l_2af0);
x86_l_2a3d:
	/* 0x2a3d: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a42:
	/* 0x2a42: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2a46:
	/* 0x2a46: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2a4d:
	/* 0x2a4d: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a50:
	/* 0x2a50: jns    2a77 <trace_ret_inotify_find_inode+0x2a77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a50, 0x2a77, x86_l_2a77);
x86_l_2a52:
	/* 0x2a52: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a55:
	/* 0x2a55: jns    2ac0 <trace_ret_inotify_find_inode+0x2ac0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a55, 0x2ac0, x86_l_2ac0);
x86_l_2a57:
	/* 0x2a57: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a59:
	/* 0x2a59: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2a60:
	/* 0x2a60: je     2ace <trace_ret_inotify_find_inode+0x2ace> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a60, 0x2ace, x86_l_2ace);
x86_l_2a62:
	/* 0x2a62: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a66:
	/* 0x2a66: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2a6b:
	/* 0x2a6b: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a71:
	/* 0x2a71: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2a73:
	/* 0x2a73: jne    2a59 <trace_ret_inotify_find_inode+0x2a59> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a73, 0x2a59, x86_l_2a59);
x86_l_2a75:
	/* 0x2a75: jmp    2a84 <trace_ret_inotify_find_inode+0x2a84> */
	X86_SIM_X86_JMP(0x2a75, 0x2a84, x86_l_2a84);
x86_l_2a77:
	/* 0x2a77: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2a7c:
	/* 0x2a7c: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a7f:
	/* 0x2a7f: call   2a84 <trace_ret_inotify_find_inode+0x2a84> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2a84:
	/* 0x2a84: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a87:
	/* 0x2a87: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2a89:
	/* 0x2a89: jle    2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2a89, 0x2af0, x86_l_2af0);
x86_l_2a8b:
	/* 0x2a8b: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a93:
	/* 0x2a93: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2a9a:
	/* 0x2a9a: ja     2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a9a, 0x2af0, x86_l_2af0);
x86_l_2a9c:
	/* 0x2a9c: mov    DWORD PTR [rdx+r13*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 138ULL);
x86_l_2aa4:
	/* 0x2aa4: add    cx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2aac:
	/* 0x2aac: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2aaf:
	/* 0x2aaf: mov    WORD PTR [r13+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2ab7:
	/* 0x2ab7: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2abe:
	/* 0x2abe: jmp    2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JMP(0x2abe, 0x2af0, x86_l_2af0);
x86_l_2ac0:
	/* 0x2ac0: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2ac5:
	/* 0x2ac5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ac7:
	/* 0x2ac7: call   2acc <trace_ret_inotify_find_inode+0x2acc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2acc:
	/* 0x2acc: jmp    2af0 <trace_ret_inotify_find_inode+0x2af0> */
	X86_SIM_X86_JMP(0x2acc, 0x2af0, x86_l_2af0);
x86_l_2ace:
	/* 0x2ace: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2ad5:
	/* 0x2ad5: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2ada:
	/* 0x2ada: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2adf:
	/* 0x2adf: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2ae7:
	/* 0x2ae7: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2aee:
	/* 0x2aee: jbe    2a9c <trace_ret_inotify_find_inode+0x2a9c> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2aee, 0x2a9c, x86_l_2a9c);
x86_l_2af0:
	/* 0x2af0: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2af8:
	/* 0x2af8: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2aff:
	/* 0x2aff: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b04:
	/* 0x2b04: ja     2b63 <trace_ret_inotify_find_inode+0x2b63> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b04, 0x2b63, x86_l_2b63);
x86_l_2b06:
	/* 0x2b06: mov    BYTE PTR [r13+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_2b0f:
	/* 0x2b0f: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2b15:
	/* 0x2b15: ja     2b63 <trace_ret_inotify_find_inode+0x2b63> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b15, 0x2b63, x86_l_2b63);
x86_l_2b17:
	/* 0x2b17: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2b1b:
	/* 0x2b1b: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2b22:
	/* 0x2b22: lea    rax,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b27:
	/* 0x2b27: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b2a:
	/* 0x2b2a: jns    2b3d <trace_ret_inotify_find_inode+0x2b3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b2a, 0x2b3d, x86_l_2b3d);
x86_l_2b2c:
	/* 0x2b2c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b2f:
	/* 0x2b2f: jns    2bcd <trace_ret_inotify_find_inode+0x2bcd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b2f, 0x2bcd, x86_l_2bcd);
x86_l_2b35:
	/* 0x2b35: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b38:
	/* 0x2b38: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3b:
	/* 0x2b3b: jmp    2b51 <trace_ret_inotify_find_inode+0x2b51> */
	X86_SIM_X86_JMP(0x2b3b, 0x2b51, x86_l_2b51);
x86_l_2b3d:
	/* 0x2b3d: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b42:
	/* 0x2b42: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2b47:
	/* 0x2b47: call   2b4c <trace_ret_inotify_find_inode+0x2b4c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b4c:
	/* 0x2b4c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b4f:
	/* 0x2b4f: js     2b63 <trace_ret_inotify_find_inode+0x2b63> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b4f, 0x2b63, x86_l_2b63);
x86_l_2b51:
	/* 0x2b51: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2b54:
	/* 0x2b54: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2b5c:
	/* 0x2b5c: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2b63:
	/* 0x2b63: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2b6b:
	/* 0x2b6b: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2b72:
	/* 0x2b72: ja     2bed <trace_ret_inotify_find_inode+0x2bed> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b72, 0x2bed, x86_l_2bed);
x86_l_2b74:
	/* 0x2b74: mov    BYTE PTR [r13+rbx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519554ULL);
x86_l_2b7d:
	/* 0x2b7d: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2b83:
	/* 0x2b83: ja     2bed <trace_ret_inotify_find_inode+0x2bed> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b83, 0x2bed, x86_l_2bed);
x86_l_2b85:
	/* 0x2b85: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2b89:
	/* 0x2b89: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2b90:
	/* 0x2b90: lea    rax,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2b95:
	/* 0x2b95: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b98:
	/* 0x2b98: jns    2ba5 <trace_ret_inotify_find_inode+0x2ba5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b98, 0x2ba5, x86_l_2ba5);
x86_l_2b9a:
	/* 0x2b9a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b9d:
	/* 0x2b9d: jns    2be7 <trace_ret_inotify_find_inode+0x2be7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b9d, 0x2be7, x86_l_2be7);
x86_l_2b9f:
	/* 0x2b9f: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ba1:
	/* 0x2ba1: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ba3:
	/* 0x2ba3: jmp    2bb9 <trace_ret_inotify_find_inode+0x2bb9> */
	X86_SIM_X86_JMP(0x2ba3, 0x2bb9, x86_l_2bb9);
x86_l_2ba5:
	/* 0x2ba5: lea    rdx,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2baa:
	/* 0x2baa: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2baf:
	/* 0x2baf: call   2bb4 <trace_ret_inotify_find_inode+0x2bb4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2bb4:
	/* 0x2bb4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bb7:
	/* 0x2bb7: js     2bed <trace_ret_inotify_find_inode+0x2bed> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bb7, 0x2bed, x86_l_2bed);
x86_l_2bb9:
	/* 0x2bb9: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2bbc:
	/* 0x2bbc: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2bc4:
	/* 0x2bc4: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2bcb:
	/* 0x2bcb: jmp    2bed <trace_ret_inotify_find_inode+0x2bed> */
	X86_SIM_X86_JMP(0x2bcb, 0x2bed, x86_l_2bed);
x86_l_2bcd:
	/* 0x2bcd: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bd4:
	/* 0x2bd4: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2bdc:
	/* 0x2bdc: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2be3:
	/* 0x2be3: jbe    2b74 <trace_ret_inotify_find_inode+0x2b74> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2be3, 0x2b74, x86_l_2b74);
x86_l_2be5:
	/* 0x2be5: jmp    2bed <trace_ret_inotify_find_inode+0x2bed> */
	X86_SIM_X86_JMP(0x2be5, 0x2bed, x86_l_2bed);
x86_l_2be7:
	/* 0x2be7: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bed:
	/* 0x2bed: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2bf4:
	/* 0x2bf4: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2bf8:
	/* 0x2bf8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bfb:
	/* 0x2bfb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bfe:
	/* 0x2bfe: jns    2c10 <trace_ret_inotify_find_inode+0x2c10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bfe, 0x2c10, x86_l_2c10);
x86_l_2c00:
	/* 0x2c00: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c03:
	/* 0x2c03: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c07:
	/* 0x2c07: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c0a:
	/* 0x2c0a: js     2c1c <trace_ret_inotify_find_inode+0x2c1c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c0a, 0x2c1c, x86_l_2c1c);
x86_l_2c0c:
	/* 0x2c0c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c0e:
	/* 0x2c0e: jmp    2c1f <trace_ret_inotify_find_inode+0x2c1f> */
	X86_SIM_X86_JMP(0x2c0e, 0x2c1f, x86_l_2c1f);
x86_l_2c10:
	/* 0x2c10: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c13:
	/* 0x2c13: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c17:
	/* 0x2c17: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c1a:
	/* 0x2c1a: jns    2c0c <trace_ret_inotify_find_inode+0x2c0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c1a, 0x2c0c, x86_l_2c0c);
x86_l_2c1c:
	/* 0x2c1c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c1f:
	/* 0x2c1f: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2c23:
	/* 0x2c23: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c25:
	/* 0x2c25: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c28:
	/* 0x2c28: jns    2c39 <trace_ret_inotify_find_inode+0x2c39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c28, 0x2c39, x86_l_2c39);
x86_l_2c2a:
	/* 0x2c2a: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c2d:
	/* 0x2c2d: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2c32:
	/* 0x2c32: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c35:
	/* 0x2c35: js     2c46 <trace_ret_inotify_find_inode+0x2c46> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c35, 0x2c46, x86_l_2c46);
x86_l_2c37:
	/* 0x2c37: jmp    2c48 <trace_ret_inotify_find_inode+0x2c48> */
	X86_SIM_X86_JMP(0x2c37, 0x2c48, x86_l_2c48);
x86_l_2c39:
	/* 0x2c39: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c3c:
	/* 0x2c3c: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2c41:
	/* 0x2c41: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c44:
	/* 0x2c44: jns    2c48 <trace_ret_inotify_find_inode+0x2c48> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c44, 0x2c48, x86_l_2c48);
x86_l_2c46:
	/* 0x2c46: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c48:
	/* 0x2c48: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2c4c:
	/* 0x2c4c: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c50:
	/* 0x2c50: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c53:
	/* 0x2c53: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c55:
	/* 0x2c55: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c58:
	/* 0x2c58: jns    2c67 <trace_ret_inotify_find_inode+0x2c67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c58, 0x2c67, x86_l_2c67);
x86_l_2c5a:
	/* 0x2c5a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c5d:
	/* 0x2c5d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c60:
	/* 0x2c60: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c63:
	/* 0x2c63: js     2c71 <trace_ret_inotify_find_inode+0x2c71> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c63, 0x2c71, x86_l_2c71);
x86_l_2c65:
	/* 0x2c65: jmp    2c73 <trace_ret_inotify_find_inode+0x2c73> */
	X86_SIM_X86_JMP(0x2c65, 0x2c73, x86_l_2c73);
x86_l_2c67:
	/* 0x2c67: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c69:
	/* 0x2c69: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c6c:
	/* 0x2c6c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c6f:
	/* 0x2c6f: jns    2c73 <trace_ret_inotify_find_inode+0x2c73> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c6f, 0x2c73, x86_l_2c73);
x86_l_2c71:
	/* 0x2c71: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c73:
	/* 0x2c73: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2c75:
	/* 0x2c75: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2c79:
	/* 0x2c79: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c7c:
	/* 0x2c7c: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2c80:
	/* 0x2c80: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c82:
	/* 0x2c82: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c85:
	/* 0x2c85: jns    2c89 <trace_ret_inotify_find_inode+0x2c89> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c85, 0x2c89, x86_l_2c89);
x86_l_2c87:
	/* 0x2c87: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c89:
	/* 0x2c89: mov    DWORD PTR [r13+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2c8d:
	/* 0x2c8d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c90:
	/* 0x2c90: jns    2c97 <trace_ret_inotify_find_inode+0x2c97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c90, 0x2c97, x86_l_2c97);
x86_l_2c92:
	/* 0x2c92: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c95:
	/* 0x2c95: jmp    2c99 <trace_ret_inotify_find_inode+0x2c99> */
	X86_SIM_X86_JMP(0x2c95, 0x2c99, x86_l_2c99);
x86_l_2c97:
	/* 0x2c97: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c99:
	/* 0x2c99: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2c9d:
	/* 0x2c9d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c9f:
	/* 0x2c9f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ca2:
	/* 0x2ca2: jns    2cb1 <trace_ret_inotify_find_inode+0x2cb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ca2, 0x2cb1, x86_l_2cb1);
x86_l_2ca4:
	/* 0x2ca4: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ca7:
	/* 0x2ca7: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2caa:
	/* 0x2caa: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2cad:
	/* 0x2cad: js     2cbb <trace_ret_inotify_find_inode+0x2cbb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2cad, 0x2cbb, x86_l_2cbb);
x86_l_2caf:
	/* 0x2caf: jmp    2cbd <trace_ret_inotify_find_inode+0x2cbd> */
	X86_SIM_X86_JMP(0x2caf, 0x2cbd, x86_l_2cbd);
x86_l_2cb1:
	/* 0x2cb1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cb3:
	/* 0x2cb3: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2cb6:
	/* 0x2cb6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2cb9:
	/* 0x2cb9: jns    2cbd <trace_ret_inotify_find_inode+0x2cbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cb9, 0x2cbd, x86_l_2cbd);
x86_l_2cbb:
	/* 0x2cbb: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cbd:
	/* 0x2cbd: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2cbf:
	/* 0x2cbf: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2cc3:
	/* 0x2cc3: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2cc6:
	/* 0x2cc6: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2cca:
	/* 0x2cca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ccc:
	/* 0x2ccc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ccf:
	/* 0x2ccf: jns    2cd3 <trace_ret_inotify_find_inode+0x2cd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ccf, 0x2cd3, x86_l_2cd3);
x86_l_2cd1:
	/* 0x2cd1: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cd3:
	/* 0x2cd3: mov    DWORD PTR [r13+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2cd7:
	/* 0x2cd7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cd9:
	/* 0x2cd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cdc:
	/* 0x2cdc: jns    2ceb <trace_ret_inotify_find_inode+0x2ceb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cdc, 0x2ceb, x86_l_2ceb);
x86_l_2cde:
	/* 0x2cde: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ce1:
	/* 0x2ce1: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ce4:
	/* 0x2ce4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ce7:
	/* 0x2ce7: js     2cf5 <trace_ret_inotify_find_inode+0x2cf5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ce7, 0x2cf5, x86_l_2cf5);
x86_l_2ce9:
	/* 0x2ce9: jmp    2cf7 <trace_ret_inotify_find_inode+0x2cf7> */
	X86_SIM_X86_JMP(0x2ce9, 0x2cf7, x86_l_2cf7);
x86_l_2ceb:
	/* 0x2ceb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ced:
	/* 0x2ced: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cf0:
	/* 0x2cf0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2cf3:
	/* 0x2cf3: jns    2cf7 <trace_ret_inotify_find_inode+0x2cf7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cf3, 0x2cf7, x86_l_2cf7);
x86_l_2cf5:
	/* 0x2cf5: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cf7:
	/* 0x2cf7: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2cf9:
	/* 0x2cf9: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2cfd:
	/* 0x2cfd: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2d00:
	/* 0x2d00: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2d04:
	/* 0x2d04: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d06:
	/* 0x2d06: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d09:
	/* 0x2d09: jns    2d19 <trace_ret_inotify_find_inode+0x2d19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d09, 0x2d19, x86_l_2d19);
x86_l_2d0b:
	/* 0x2d0b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d0e:
	/* 0x2d0e: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2d12:
	/* 0x2d12: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d15:
	/* 0x2d15: js     2d24 <trace_ret_inotify_find_inode+0x2d24> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d15, 0x2d24, x86_l_2d24);
x86_l_2d17:
	/* 0x2d17: jmp    2d26 <trace_ret_inotify_find_inode+0x2d26> */
	X86_SIM_X86_JMP(0x2d17, 0x2d26, x86_l_2d26);
x86_l_2d19:
	/* 0x2d19: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d1b:
	/* 0x2d1b: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2d1f:
	/* 0x2d1f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d22:
	/* 0x2d22: jns    2d26 <trace_ret_inotify_find_inode+0x2d26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d22, 0x2d26, x86_l_2d26);
x86_l_2d24:
	/* 0x2d24: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d26:
	/* 0x2d26: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d2b:
	/* 0x2d2b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d2e:
	/* 0x2d2e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d30:
	/* 0x2d30: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d33:
	/* 0x2d33: jns    2d42 <trace_ret_inotify_find_inode+0x2d42> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d33, 0x2d42, x86_l_2d42);
x86_l_2d35:
	/* 0x2d35: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d38:
	/* 0x2d38: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d3b:
	/* 0x2d3b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2d3e:
	/* 0x2d3e: js     2d4c <trace_ret_inotify_find_inode+0x2d4c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d3e, 0x2d4c, x86_l_2d4c);
x86_l_2d40:
	/* 0x2d40: jmp    2d4e <trace_ret_inotify_find_inode+0x2d4e> */
	X86_SIM_X86_JMP(0x2d40, 0x2d4e, x86_l_2d4e);
x86_l_2d42:
	/* 0x2d42: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d44:
	/* 0x2d44: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d47:
	/* 0x2d47: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2d4a:
	/* 0x2d4a: jns    2d4e <trace_ret_inotify_find_inode+0x2d4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d4a, 0x2d4e, x86_l_2d4e);
x86_l_2d4c:
	/* 0x2d4c: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d4e:
	/* 0x2d4e: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2d50:
	/* 0x2d50: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2d54:
	/* 0x2d54: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2d57:
	/* 0x2d57: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2d5b:
	/* 0x2d5b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d5d:
	/* 0x2d5d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d60:
	/* 0x2d60: jns    2d70 <trace_ret_inotify_find_inode+0x2d70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d60, 0x2d70, x86_l_2d70);
x86_l_2d62:
	/* 0x2d62: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d65:
	/* 0x2d65: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2d69:
	/* 0x2d69: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d6c:
	/* 0x2d6c: js     2d7b <trace_ret_inotify_find_inode+0x2d7b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d6c, 0x2d7b, x86_l_2d7b);
x86_l_2d6e:
	/* 0x2d6e: jmp    2d7d <trace_ret_inotify_find_inode+0x2d7d> */
	X86_SIM_X86_JMP(0x2d6e, 0x2d7d, x86_l_2d7d);
x86_l_2d70:
	/* 0x2d70: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d72:
	/* 0x2d72: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2d76:
	/* 0x2d76: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d79:
	/* 0x2d79: jns    2d7d <trace_ret_inotify_find_inode+0x2d7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d79, 0x2d7d, x86_l_2d7d);
x86_l_2d7b:
	/* 0x2d7b: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d7d:
	/* 0x2d7d: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2d7f:
	/* 0x2d7f: jne    2dbb <trace_ret_inotify_find_inode+0x2dbb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d7f, 0x2dbb, x86_l_2dbb);
x86_l_2d81:
	/* 0x2d81: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d83:
	/* 0x2d83: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d86:
	/* 0x2d86: jns    2d95 <trace_ret_inotify_find_inode+0x2d95> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d86, 0x2d95, x86_l_2d95);
x86_l_2d88:
	/* 0x2d88: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d8b:
	/* 0x2d8b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d8e:
	/* 0x2d8e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d91:
	/* 0x2d91: js     2d9f <trace_ret_inotify_find_inode+0x2d9f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d91, 0x2d9f, x86_l_2d9f);
x86_l_2d93:
	/* 0x2d93: jmp    2da1 <trace_ret_inotify_find_inode+0x2da1> */
	X86_SIM_X86_JMP(0x2d93, 0x2da1, x86_l_2da1);
x86_l_2d95:
	/* 0x2d95: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d97:
	/* 0x2d97: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d9a:
	/* 0x2d9a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2d9d:
	/* 0x2d9d: jns    2da1 <trace_ret_inotify_find_inode+0x2da1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d9d, 0x2da1, x86_l_2da1);
x86_l_2d9f:
	/* 0x2d9f: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da1:
	/* 0x2da1: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2da3:
	/* 0x2da3: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2da7:
	/* 0x2da7: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2daa:
	/* 0x2daa: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2dae:
	/* 0x2dae: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2db0:
	/* 0x2db0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2db3:
	/* 0x2db3: jns    2db7 <trace_ret_inotify_find_inode+0x2db7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2db3, 0x2db7, x86_l_2db7);
x86_l_2db5:
	/* 0x2db5: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db7:
	/* 0x2db7: mov    DWORD PTR [r13+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2dbb:
	/* 0x2dbb: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2dbf:
	/* 0x2dbf: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2dc6:
	/* 0x2dc6: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2dc9:
	/* 0x2dc9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dcc:
	/* 0x2dcc: jns    2dd3 <trace_ret_inotify_find_inode+0x2dd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dcc, 0x2dd3, x86_l_2dd3);
x86_l_2dce:
	/* 0x2dce: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dd1:
	/* 0x2dd1: jmp    2dd5 <trace_ret_inotify_find_inode+0x2dd5> */
	X86_SIM_X86_JMP(0x2dd1, 0x2dd5, x86_l_2dd5);
x86_l_2dd3:
	/* 0x2dd3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dd5:
	/* 0x2dd5: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2dd9:
	/* 0x2dd9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ddb:
	/* 0x2ddb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2dde:
	/* 0x2dde: jns    2dea <trace_ret_inotify_find_inode+0x2dea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dde, 0x2dea, x86_l_2dea);
x86_l_2de0:
	/* 0x2de0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de3:
	/* 0x2de3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2de6:
	/* 0x2de6: js     2df1 <trace_ret_inotify_find_inode+0x2df1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2de6, 0x2df1, x86_l_2df1);
x86_l_2de8:
	/* 0x2de8: jmp    2df3 <trace_ret_inotify_find_inode+0x2df3> */
	X86_SIM_X86_JMP(0x2de8, 0x2df3, x86_l_2df3);
x86_l_2dea:
	/* 0x2dea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dec:
	/* 0x2dec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2def:
	/* 0x2def: jns    2df3 <trace_ret_inotify_find_inode+0x2df3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2def, 0x2df3, x86_l_2df3);
x86_l_2df1:
	/* 0x2df1: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2df3:
	/* 0x2df3: lea    rbp,[r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2df7:
	/* 0x2df7: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dfb:
	/* 0x2dfb: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2dff:
	/* 0x2dff: call   2e04 <trace_ret_inotify_find_inode+0x2e04> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2e04:
	/* 0x2e04: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e08:
	/* 0x2e08: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2e0c:
	/* 0x2e0c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e0f:
	/* 0x2e0f: jns    2e16 <trace_ret_inotify_find_inode+0x2e16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e0f, 0x2e16, x86_l_2e16);
x86_l_2e11:
	/* 0x2e11: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e14:
	/* 0x2e14: jmp    2e18 <trace_ret_inotify_find_inode+0x2e18> */
	X86_SIM_X86_JMP(0x2e14, 0x2e18, x86_l_2e18);
x86_l_2e16:
	/* 0x2e16: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e18:
	/* 0x2e18: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e1c:
	/* 0x2e1c: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2e20:
	/* 0x2e20: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2e23:
	/* 0x2e23: jns    2e2a <trace_ret_inotify_find_inode+0x2e2a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e23, 0x2e2a, x86_l_2e2a);
x86_l_2e25:
	/* 0x2e25: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e28:
	/* 0x2e28: jmp    2e2c <trace_ret_inotify_find_inode+0x2e2c> */
	X86_SIM_X86_JMP(0x2e28, 0x2e2c, x86_l_2e2c);
x86_l_2e2a:
	/* 0x2e2a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e2c:
	/* 0x2e2c: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e30:
	/* 0x2e30: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2e34:
	/* 0x2e34: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2e38:
	/* 0x2e38: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2e3b:
	/* 0x2e3b: jns    2e43 <trace_ret_inotify_find_inode+0x2e43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e3b, 0x2e43, x86_l_2e43);
x86_l_2e3d:
	/* 0x2e3d: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e41:
	/* 0x2e41: jmp    2e45 <trace_ret_inotify_find_inode+0x2e45> */
	X86_SIM_X86_JMP(0x2e41, 0x2e45, x86_l_2e45);
x86_l_2e43:
	/* 0x2e43: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e45:
	/* 0x2e45: mov    r14,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2e4d:
	/* 0x2e4d: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e52:
	/* 0x2e52: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e56:
	/* 0x2e56: mov    QWORD PTR [rcx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2e5a:
	/* 0x2e5a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2e5d:
	/* 0x2e5d: jns    2e69 <trace_ret_inotify_find_inode+0x2e69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e5d, 0x2e69, x86_l_2e69);
x86_l_2e5f:
	/* 0x2e5f: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e61:
	/* 0x2e61: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2e63:
	/* 0x2e63: je     2e69 <trace_ret_inotify_find_inode+0x2e69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e63, 0x2e69, x86_l_2e69);
x86_l_2e65:
	/* 0x2e65: or     BYTE PTR [rcx+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_2e69:
	/* 0x2e69: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e6e:
	/* 0x2e6e: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_2e72:
	/* 0x2e72: mov    QWORD PTR [rcx+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_2e7a:
	/* 0x2e7a: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_2e82:
	/* 0x2e82: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2e87:
	/* 0x2e87: call   2e8c <trace_ret_inotify_find_inode+0x2e8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_2e8c:
	/* 0x2e8c: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2e8f:
	/* 0x2e8f: jns    2ea7 <trace_ret_inotify_find_inode+0x2ea7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e8f, 0x2ea7, x86_l_2ea7);
x86_l_2e91:
	/* 0x2e91: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e95:
	/* 0x2e95: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e98:
	/* 0x2e98: mov    rbx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e9c:
	/* 0x2e9c: js     2eb2 <trace_ret_inotify_find_inode+0x2eb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e9c, 0x2eb2, x86_l_2eb2);
x86_l_2e9e:
	/* 0x2e9e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ea0:
	/* 0x2ea0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ea3:
	/* 0x2ea3: js     2eba <trace_ret_inotify_find_inode+0x2eba> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ea3, 0x2eba, x86_l_2eba);
x86_l_2ea5:
	/* 0x2ea5: jmp    2efb <trace_ret_inotify_find_inode+0x2efb> */
	X86_SIM_X86_JMP(0x2ea5, 0x2efb, x86_l_2efb);
x86_l_2ea7:
	/* 0x2ea7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ea9:
	/* 0x2ea9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eac:
	/* 0x2eac: mov    rbx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb0:
	/* 0x2eb0: jns    2e9e <trace_ret_inotify_find_inode+0x2e9e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb0, 0x2e9e, x86_l_2e9e);
x86_l_2eb2:
	/* 0x2eb2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb5:
	/* 0x2eb5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eb8:
	/* 0x2eb8: jns    2efb <trace_ret_inotify_find_inode+0x2efb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb8, 0x2efb, x86_l_2efb);
x86_l_2eba:
	/* 0x2eba: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ebd:
	/* 0x2ebd: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ec2:
	/* 0x2ec2: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ec6:
	/* 0x2ec6: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2ecb:
	/* 0x2ecb: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ecf:
	/* 0x2ecf: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ed4:
	/* 0x2ed4: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ed8:
	/* 0x2ed8: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2edd:
	/* 0x2edd: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ee1:
	/* 0x2ee1: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2ee6:
	/* 0x2ee6: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2eea:
	/* 0x2eea: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2eef:
	/* 0x2eef: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ef3:
	/* 0x2ef3: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ef7:
	/* 0x2ef7: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2efb:
	/* 0x2efb: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f00:
	/* 0x2f00: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_2f04:
	/* 0x2f04: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2f09:
	/* 0x2f09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f0c:
	/* 0x2f0c: jns    2fcf <trace_ret_inotify_find_inode+0x2fcf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f0c, 0x2fcf, x86_l_2fcf);
x86_l_2f12:
	/* 0x2f12: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2f15:
	/* 0x2f15: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f17:
	/* 0x2f17: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f19:
	/* 0x2f19: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f19, 0x2fde, x86_l_2fde);
x86_l_2f1f:
	/* 0x2f1f: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2f23:
	/* 0x2f23: mov    BYTE PTR [rbx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_2f26:
	/* 0x2f26: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f28:
	/* 0x2f28: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f28, 0x2fde, x86_l_2fde);
x86_l_2f2e:
	/* 0x2f2e: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2f32:
	/* 0x2f32: mov    BYTE PTR [rbx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_2f35:
	/* 0x2f35: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f37:
	/* 0x2f37: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f37, 0x2fde, x86_l_2fde);
x86_l_2f3d:
	/* 0x2f3d: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2f41:
	/* 0x2f41: mov    BYTE PTR [rbx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2f44:
	/* 0x2f44: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f46:
	/* 0x2f46: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f46, 0x2fde, x86_l_2fde);
x86_l_2f4c:
	/* 0x2f4c: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2f50:
	/* 0x2f50: mov    BYTE PTR [rbx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2f53:
	/* 0x2f53: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f55:
	/* 0x2f55: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f55, 0x2fde, x86_l_2fde);
x86_l_2f5b:
	/* 0x2f5b: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2f5f:
	/* 0x2f5f: mov    BYTE PTR [rbx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2f62:
	/* 0x2f62: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f64:
	/* 0x2f64: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f64, 0x2fde, x86_l_2fde);
x86_l_2f66:
	/* 0x2f66: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2f6a:
	/* 0x2f6a: mov    BYTE PTR [rbx+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2f6d:
	/* 0x2f6d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f6f:
	/* 0x2f6f: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f6f, 0x2fde, x86_l_2fde);
x86_l_2f71:
	/* 0x2f71: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2f75:
	/* 0x2f75: mov    BYTE PTR [rbx+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_2f78:
	/* 0x2f78: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f7a:
	/* 0x2f7a: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f7a, 0x2fde, x86_l_2fde);
x86_l_2f7c:
	/* 0x2f7c: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2f80:
	/* 0x2f80: mov    BYTE PTR [rbx+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_2f83:
	/* 0x2f83: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f85:
	/* 0x2f85: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f85, 0x2fde, x86_l_2fde);
x86_l_2f87:
	/* 0x2f87: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2f8b:
	/* 0x2f8b: mov    BYTE PTR [rbx+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_2f8e:
	/* 0x2f8e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f90:
	/* 0x2f90: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f90, 0x2fde, x86_l_2fde);
x86_l_2f92:
	/* 0x2f92: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2f96:
	/* 0x2f96: mov    BYTE PTR [rbx+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_2f99:
	/* 0x2f99: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2f9b:
	/* 0x2f9b: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f9b, 0x2fde, x86_l_2fde);
x86_l_2f9d:
	/* 0x2f9d: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2fa1:
	/* 0x2fa1: mov    BYTE PTR [rbx+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_2fa4:
	/* 0x2fa4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2fa6:
	/* 0x2fa6: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fa6, 0x2fde, x86_l_2fde);
x86_l_2fa8:
	/* 0x2fa8: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2fac:
	/* 0x2fac: mov    BYTE PTR [rbx+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2faf:
	/* 0x2faf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2fb1:
	/* 0x2fb1: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fb1, 0x2fde, x86_l_2fde);
x86_l_2fb3:
	/* 0x2fb3: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2fb7:
	/* 0x2fb7: mov    BYTE PTR [rbx+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_2fba:
	/* 0x2fba: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2fbc:
	/* 0x2fbc: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fbc, 0x2fde, x86_l_2fde);
x86_l_2fbe:
	/* 0x2fbe: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2fc2:
	/* 0x2fc2: mov    BYTE PTR [rbx+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_2fc5:
	/* 0x2fc5: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2fc7:
	/* 0x2fc7: je     2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fc7, 0x2fde, x86_l_2fde);
x86_l_2fc9:
	/* 0x2fc9: mov    BYTE PTR [rbx+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_2fcd:
	/* 0x2fcd: jmp    2fde <trace_ret_inotify_find_inode+0x2fde> */
	X86_SIM_X86_JMP(0x2fcd, 0x2fde, x86_l_2fde);
x86_l_2fcf:
	/* 0x2fcf: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2fd7:
	/* 0x2fd7: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fde:
	/* 0x2fde: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2fe1:
	/* 0x2fe1: jns    305b <trace_ret_inotify_find_inode+0x305b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fe1, 0x305b, x86_l_305b);
x86_l_2fe3:
	/* 0x2fe3: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe7:
	/* 0x2fe7: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2fec:
	/* 0x2fec: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fef:
	/* 0x2fef: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ff3:
	/* 0x2ff3: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ff7:
	/* 0x2ff7: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ffb:
	/* 0x2ffb: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fff:
	/* 0x2fff: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3003:
	/* 0x3003: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3007:
	/* 0x3007: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_300b:
	/* 0x300b: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_300f:
	/* 0x300f: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3013:
	/* 0x3013: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3017:
	/* 0x3017: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_301b:
	/* 0x301b: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_301f:
	/* 0x301f: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3023:
	/* 0x3023: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3027:
	/* 0x3027: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_302b:
	/* 0x302b: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_302f:
	/* 0x302f: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3033:
	/* 0x3033: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3037:
	/* 0x3037: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_303b:
	/* 0x303b: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_303f:
	/* 0x303f: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3043:
	/* 0x3043: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3047:
	/* 0x3047: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_304b:
	/* 0x304b: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_304f:
	/* 0x304f: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_3054:
	/* 0x3054: jne    30ce <trace_ret_inotify_find_inode+0x30ce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3054, 0x30ce, x86_l_30ce);
x86_l_3056:
	/* 0x3056: jmp    30e9 <trace_ret_inotify_find_inode+0x30e9> */
	X86_SIM_X86_JMP(0x3056, 0x30e9, x86_l_30e9);
x86_l_305b:
	/* 0x305b: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3060:
	/* 0x3060: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3068:
	/* 0x3068: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3070:
	/* 0x3070: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3078:
	/* 0x3078: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_3080:
	/* 0x3080: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3088:
	/* 0x3088: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_3090:
	/* 0x3090: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3098:
	/* 0x3098: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_30a0:
	/* 0x30a0: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_30a8:
	/* 0x30a8: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_30b0:
	/* 0x30b0: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_30b8:
	/* 0x30b8: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_30c0:
	/* 0x30c0: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30c7:
	/* 0x30c7: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_30cc:
	/* 0x30cc: je     30e9 <trace_ret_inotify_find_inode+0x30e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30cc, 0x30e9, x86_l_30e9);
x86_l_30ce:
	/* 0x30ce: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_30d5:
	/* 0x30d5: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_30da:
	/* 0x30da: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_30dd:
	/* 0x30dd: call   30e2 <trace_ret_inotify_find_inode+0x30e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_30e2:
	/* 0x30e2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_30e4:
	/* 0x30e4: js     30e9 <trace_ret_inotify_find_inode+0x30e9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30e4, 0x30e9, x86_l_30e9);
x86_l_30e6:
	/* 0x30e6: mov    DWORD PTR [rbx+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_30e9:
	/* 0x30e9: movzx  eax,WORD PTR [rbx+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_30f0:
	/* 0x30f0: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_30f5:
	/* 0x30f5: jb     30fc <trace_ret_inotify_find_inode+0x30fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x30f5, 0x30fc, x86_l_30fc);
x86_l_30f7:
	/* 0x30f7: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_30fc:
	/* 0x30fc: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_3101:
	/* 0x3101: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_3105:
	/* 0x3105: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_310c:
	/* 0x310c: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_3111:
	/* 0x3111: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3114:
	/* 0x3114: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3117:
	/* 0x3117: call   311c <trace_ret_inotify_find_inode+0x311c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_311c:
	/* 0x311c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_311f:
	/* 0x311f: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_3121:
	/* 0x3121: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_3128:
	/* 0x3128: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3129:
	/* 0x3129: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_312b:
	/* 0x312b: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_312d:
	/* 0x312d: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_312f:
	/* 0x312f: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3131:
	/* 0x3131: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3132:
	/* 0x3132: jmp    31dd <trace_ret_inotify_find_inode+0x31dd> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3137:
	/* 0x3137: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_313a:
	/* 0x313a: jne    31d5 <trace_ret_inotify_find_inode+0x31d5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x313a, 0x31d5, x86_l_31d5);
x86_l_3140:
	/* 0x3140: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3143:
	/* 0x3143: je     31d5 <trace_ret_inotify_find_inode+0x31d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3143, 0x31d5, x86_l_31d5);
x86_l_3149:
	/* 0x3149: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_314d:
	/* 0x314d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3150:
	/* 0x3150: jns    318f <trace_ret_inotify_find_inode+0x318f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3150, 0x318f, x86_l_318f);
x86_l_3152:
	/* 0x3152: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3155:
	/* 0x3155: jmp    3191 <trace_ret_inotify_find_inode+0x3191> */
	X86_SIM_X86_JMP(0x3155, 0x3191, x86_l_3191);
x86_l_3157:
	/* 0x3157: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_315a:
	/* 0x315a: je     31d5 <trace_ret_inotify_find_inode+0x31d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x315a, 0x31d5, x86_l_31d5);
x86_l_315c:
	/* 0x315c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3162:
	/* 0x3162: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3165:
	/* 0x3165: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3168:
	/* 0x3168: jns    31ae <trace_ret_inotify_find_inode+0x31ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3168, 0x31ae, x86_l_31ae);
x86_l_316a:
	/* 0x316a: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_316e:
	/* 0x316e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3170:
	/* 0x3170: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3173:
	/* 0x3173: je     31b6 <trace_ret_inotify_find_inode+0x31b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3173, 0x31b6, x86_l_31b6);
x86_l_3175:
	/* 0x3175: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3179:
	/* 0x3179: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_317e:
	/* 0x317e: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3182:
	/* 0x3182: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_3185:
	/* 0x3185: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3188:
	/* 0x3188: jne    3170 <trace_ret_inotify_find_inode+0x3170> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3188, 0x3170, x86_l_3170);
x86_l_318a:
	/* 0x318a: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_318d:
	/* 0x318d: jmp    31ba <trace_ret_inotify_find_inode+0x31ba> */
	X86_SIM_X86_JMP(0x318d, 0x31ba, x86_l_31ba);
x86_l_318f:
	/* 0x318f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3191:
	/* 0x3191: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3194:
	/* 0x3194: jns    319b <trace_ret_inotify_find_inode+0x319b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3194, 0x319b, x86_l_319b);
x86_l_3196:
	/* 0x3196: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3199:
	/* 0x3199: jmp    319d <trace_ret_inotify_find_inode+0x319d> */
	X86_SIM_X86_JMP(0x3199, 0x319d, x86_l_319d);
x86_l_319b:
	/* 0x319b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_319d:
	/* 0x319d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31a0:
	/* 0x31a0: jns    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31a0, 0x2914, x86_l_2914);
x86_l_31a6:
	/* 0x31a6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31a9:
	/* 0x31a9: jmp    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JMP(0x31a9, 0x2914, x86_l_2914);
x86_l_31ae:
	/* 0x31ae: mov    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_31b1:
	/* 0x31b1: jmp    2788 <trace_ret_inotify_find_inode+0x2788> */
	X86_SIM_X86_JMP(0x31b1, 0x2788, x86_l_2788);
x86_l_31b6:
	/* 0x31b6: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_31ba:
	/* 0x31ba: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_31be:
	/* 0x31be: jl     31d5 <trace_ret_inotify_find_inode+0x31d5> */
	X86_SIM_X86_JCC(X86_CC_L, 0x31be, 0x31d5, x86_l_31d5);
x86_l_31c0:
	/* 0x31c0: lea    eax,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_31c3:
	/* 0x31c3: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_31c8:
	/* 0x31c8: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_31cd:
	/* 0x31cd: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_31d0:
	/* 0x31d0: jmp    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JMP(0x31d0, 0x2914, x86_l_2914);
x86_l_31d5:
	/* 0x31d5: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_31d8:
	/* 0x31d8: jmp    2914 <trace_ret_inotify_find_inode+0x2914> */
	X86_SIM_X86_JMP(0x31d8, 0x2914, x86_l_2914);
x86_l_31dd:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
