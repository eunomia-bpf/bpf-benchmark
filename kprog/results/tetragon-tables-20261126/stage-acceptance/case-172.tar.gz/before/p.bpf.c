#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(10) M(11) M(12) M(14) M(20) M(22) M(23) M(24)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
extern __u8 usdt_calls[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ANDN_MEM, X86_OP_ANDN_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_REG, X86_OP_TEST_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("uprobe.multi")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x7a10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_25:
	/* 0x25: call   7a3a <filter_file_type+0x5460> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     3d1 <generic_usdt_filter_arg+0x3d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x3d1, x86_l_3d1);
x86_l_33:
	/* 0x33: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: mov    r12d,DWORD PTR [rax+0x5f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_3d:
	/* 0x3d: lea    rsi,[rax+0x5ef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x7a10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_4b:
	/* 0x4b: call   7a60 <filter_file_type+0x5486> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_50:
	/* 0x50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: je     3bd <generic_usdt_filter_arg+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53, 0x3bd, x86_l_3bd);
x86_l_59:
	/* 0x59: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_61:
	/* 0x61: je     3bd <generic_usdt_filter_arg+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61, 0x3bd, x86_l_3bd);
x86_l_67:
	/* 0x67: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a:
	/* 0x6a: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_6d:
	/* 0x6d: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_70:
	/* 0x70: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_79:
	/* 0x79: je     108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_E, 0x79, 0x108, x86_l_108);
x86_l_7f:
	/* 0x7f: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_81:
	/* 0x81: mov    ecx,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_86:
	/* 0x86: lea    rdx,[rcx+rax*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_8a:
	/* 0x8a: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_8e:
	/* 0x8e: lea    rax,[rcx+rax*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_92:
	/* 0x92: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_96:
	/* 0x96: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_9b:
	/* 0x9b: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_9f:
	/* 0x9f: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a2:
	/* 0xa2: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_a6:
	/* 0xa6: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a8:
	/* 0xa8: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_ae:
	/* 0xae: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_b2:
	/* 0xb2: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b5:
	/* 0xb5: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b7:
	/* 0xb7: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_bc:
	/* 0xbc: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_c0:
	/* 0xc0: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_c3:
	/* 0xc3: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c5:
	/* 0xc5: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_cb:
	/* 0xcb: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_cf:
	/* 0xcf: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d2:
	/* 0xd2: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d4:
	/* 0xd4: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_d9:
	/* 0xd9: mov    ebp,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_dd:
	/* 0xdd: add    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e0:
	/* 0xe0: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_e2:
	/* 0xe2: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_e7:
	/* 0xe7: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eb:
	/* 0xeb: cmp    DWORD PTR [r15+rax*1],0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 25ULL);
x86_l_f0:
	/* 0xf0: jae    15d <generic_usdt_filter_arg+0x15d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf0, 0x15d, x86_l_15d);
x86_l_f2:
	/* 0xf2: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f6:
	/* 0xf6: cmp    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_fa:
	/* 0xfa: je     3bd <generic_usdt_filter_arg+0x3bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfa, 0x3bd, x86_l_3bd);
x86_l_100:
	/* 0x100: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_102:
	/* 0x102: jne    39e <generic_usdt_filter_arg+0x39e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x102, 0x39e, x86_l_39e);
x86_l_108:
	/* 0x108: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_10c:
	/* 0x10c: jg     12d <generic_usdt_filter_arg+0x12d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x10c, 0x12d, x86_l_12d);
x86_l_10e:
	/* 0x10e: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_112:
	/* 0x112: je     3e6 <generic_usdt_filter_arg+0x3e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x112, 0x3e6, x86_l_3e6);
x86_l_118:
	/* 0x118: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_11b:
	/* 0x11b: je     3f3 <generic_usdt_filter_arg+0x3f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11b, 0x3f3, x86_l_3f3);
x86_l_121:
	/* 0x121: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_125:
	/* 0x125: je     403 <generic_usdt_filter_arg+0x403> */
	X86_SIM_X86_JCC(X86_CC_E, 0x125, 0x403, x86_l_403);
x86_l_12b:
	/* 0x12b: jmp    14b <generic_usdt_filter_arg+0x14b> */
	X86_SIM_X86_JMP(0x12b, 0x14b, x86_l_14b);
x86_l_12d:
	/* 0x12d: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_131:
	/* 0x131: je     413 <generic_usdt_filter_arg+0x413> */
	X86_SIM_X86_JCC(X86_CC_E, 0x131, 0x413, x86_l_413);
x86_l_137:
	/* 0x137: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_13b:
	/* 0x13b: je     423 <generic_usdt_filter_arg+0x423> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13b, 0x423, x86_l_423);
x86_l_141:
	/* 0x141: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_145:
	/* 0x145: je     433 <generic_usdt_filter_arg+0x433> */
	X86_SIM_X86_JCC(X86_CC_E, 0x145, 0x433, x86_l_433);
x86_l_14b:
	/* 0x14b: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14f:
	/* 0x14f: jg     45e <generic_usdt_filter_arg+0x45e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x14f, 0x45e, x86_l_45e);
x86_l_155:
	/* 0x155: inc    r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_158:
	/* 0x158: jmp    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JMP(0x158, 0x443, x86_l_443);
x86_l_15d:
	/* 0x15d: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_161:
	/* 0x161: add    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_164:
	/* 0x164: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_169:
	/* 0x169: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_16f:
	/* 0x16f: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_174:
	/* 0x174: mov    edi,DWORD PTR [rax+r13*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 0ULL);
x86_l_178:
	/* 0x178: test   edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 1023ULL);
x86_l_17e:
	/* 0x17e: je     f2 <generic_usdt_filter_arg+0xf2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17e, 0xf2, x86_l_f2);
x86_l_184:
	/* 0x184: add    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_186:
	/* 0x186: and    edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_18c:
	/* 0x18c: mov    ecx,DWORD PTR [r15+rdi*1+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 4ULL);
x86_l_191:
	/* 0x191: cmp    ecx,0x23 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_194:
	/* 0x194: je     108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194, 0x108, x86_l_108);
x86_l_19a:
	/* 0x19a: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_19d:
	/* 0x19d: mov    eax,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: cmp    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_1a3:
	/* 0x1a3: ja     108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a3, 0x108, x86_l_108);
x86_l_1a9:
	/* 0x1a9: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_1b2:
	/* 0x1b2: jne    108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b2, 0x108, x86_l_108);
x86_l_1b8:
	/* 0x1b8: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_1c0:
	/* 0x1c0: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_1c5:
	/* 0x1c5: lea    rsi,[r14+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c9:
	/* 0x1c9: add    rsi,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_1d0:
	/* 0x1d0: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d3:
	/* 0x1d3: cmp    eax,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_1d6:
	/* 0x1d6: jle    1f7 <generic_usdt_filter_arg+0x1f7> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1d6, 0x1f7, x86_l_1f7);
x86_l_1d8:
	/* 0x1d8: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1db:
	/* 0x1db: jg     227 <generic_usdt_filter_arg+0x227> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1db, 0x227, x86_l_227);
x86_l_1dd:
	/* 0x1dd: lea    edx,[rax-0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_1e0:
	/* 0x1e0: cmp    edx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1e3:
	/* 0x1e3: jb     26d <generic_usdt_filter_arg+0x26d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e3, 0x26d, x86_l_26d);
x86_l_1e9:
	/* 0x1e9: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1ec:
	/* 0x1ec: je     350 <generic_usdt_filter_arg+0x350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec, 0x350, x86_l_350);
x86_l_1f2:
	/* 0x1f2: jmp    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JMP(0x1f2, 0x38c, x86_l_38c);
x86_l_1f7:
	/* 0x1f7: cmp    eax,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1fa:
	/* 0x1fa: jle    24d <generic_usdt_filter_arg+0x24d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1fa, 0x24d, x86_l_24d);
x86_l_1fc:
	/* 0x1fc: lea    edx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_1ff:
	/* 0x1ff: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_202:
	/* 0x202: jb     26d <generic_usdt_filter_arg+0x26d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x202, 0x26d, x86_l_26d);
x86_l_204:
	/* 0x204: lea    ecx,[rax-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_207:
	/* 0x207: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20a:
	/* 0x20a: jb     350 <generic_usdt_filter_arg+0x350> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20a, 0x350, x86_l_350);
x86_l_210:
	/* 0x210: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_213:
	/* 0x213: jne    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x213, 0x38c, x86_l_38c);
x86_l_219:
	/* 0x219: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_21d:
	/* 0x21d: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4a1, 0x222ULL);
x86_l_222:
	/* 0x222: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x222, 0x383, x86_l_383);
x86_l_227:
	/* 0x227: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_22a:
	/* 0x22a: jg     33f <generic_usdt_filter_arg+0x33f> */
	X86_SIM_X86_JCC(X86_CC_G, 0x22a, 0x33f, x86_l_33f);
x86_l_230:
	/* 0x230: lea    ecx,[rax-0x26] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_233:
	/* 0x233: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_236:
	/* 0x236: jb     2fa <generic_usdt_filter_arg+0x2fa> */
	X86_SIM_X86_JCC(X86_CC_B, 0x236, 0x2fa, x86_l_2fa);
x86_l_23c:
	/* 0x23c: add    eax,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967256ULL);
x86_l_23f:
	/* 0x23f: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_242:
	/* 0x242: jb     2f0 <generic_usdt_filter_arg+0x2f0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x242, 0x2f0, x86_l_2f0);
x86_l_248:
	/* 0x248: jmp    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JMP(0x248, 0x38c, x86_l_38c);
x86_l_24d:
	/* 0x24d: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_250:
	/* 0x250: jg     2dd <generic_usdt_filter_arg+0x2dd> */
	X86_SIM_X86_JCC(X86_CC_G, 0x250, 0x2dd, x86_l_2dd);
x86_l_256:
	/* 0x256: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_259:
	/* 0x259: je     26d <generic_usdt_filter_arg+0x26d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259, 0x26d, x86_l_26d);
x86_l_25b:
	/* 0x25b: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_25e:
	/* 0x25e: je     36d <generic_usdt_filter_arg+0x36d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25e, 0x36d, x86_l_36d);
x86_l_264:
	/* 0x264: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_267:
	/* 0x267: jne    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x267, 0x38c, x86_l_38c);
x86_l_26d:
	/* 0x26d: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_270:
	/* 0x270: jle    2ba <generic_usdt_filter_arg+0x2ba> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x270, 0x2ba, x86_l_2ba);
x86_l_272:
	/* 0x272: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_275:
	/* 0x275: ja     357 <generic_usdt_filter_arg+0x357> */
	X86_SIM_X86_JCC(X86_CC_A, 0x275, 0x357, x86_l_357);
x86_l_27b:
	/* 0x27b: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_27d:
	/* 0x27d: movabs r8,0x1e00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 128849018880ULL);
x86_l_287:
	/* 0x287: bt     r8,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28b:
	/* 0x28b: jb     301 <generic_usdt_filter_arg+0x301> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28b, 0x301, x86_l_301);
x86_l_28d:
	/* 0x28d: mov    ecx,0x60000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1610612736ULL);
x86_l_292:
	/* 0x292: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_296:
	/* 0x296: jb     366 <generic_usdt_filter_arg+0x366> */
	X86_SIM_X86_JCC(X86_CC_B, 0x296, 0x366, x86_l_366);
x86_l_29c:
	/* 0x29c: movabs rcx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_2a6:
	/* 0x2a6: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2aa:
	/* 0x2aa: jae    357 <generic_usdt_filter_arg+0x357> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2aa, 0x357, x86_l_357);
x86_l_2b0:
	/* 0x2b0: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_564, 0x2b5ULL);
x86_l_2b5:
	/* 0x2b5: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x2b5, 0x383, x86_l_383);
x86_l_2ba:
	/* 0x2ba: lea    ecx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_2bd:
	/* 0x2bd: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c0:
	/* 0x2c0: jb     37e <generic_usdt_filter_arg+0x37e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c0, 0x37e, x86_l_37e);
x86_l_2c6:
	/* 0x2c6: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2c9:
	/* 0x2c9: je     35f <generic_usdt_filter_arg+0x35f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c9, 0x35f, x86_l_35f);
x86_l_2cf:
	/* 0x2cf: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d2:
	/* 0x2d2: je     35f <generic_usdt_filter_arg+0x35f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d2, 0x35f, x86_l_35f);
x86_l_2d8:
	/* 0x2d8: jmp    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JMP(0x2d8, 0x38c, x86_l_38c);
x86_l_2dd:
	/* 0x2dd: cmp    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2e0:
	/* 0x2e0: je     2f0 <generic_usdt_filter_arg+0x2f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e0, 0x2f0, x86_l_2f0);
x86_l_2e2:
	/* 0x2e2: cmp    eax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_2e5:
	/* 0x2e5: je     2fa <generic_usdt_filter_arg+0x2fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e5, 0x2fa, x86_l_2fa);
x86_l_2e7:
	/* 0x2e7: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_2ea:
	/* 0x2ea: jne    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ea, 0x38c, x86_l_38c);
x86_l_2f0:
	/* 0x2f0: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_5ab, 0x2f5ULL);
x86_l_2f5:
	/* 0x2f5: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x2f5, 0x383, x86_l_383);
x86_l_2fa:
	/* 0x2fa: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2ff:
	/* 0x2ff: jmp    372 <generic_usdt_filter_arg+0x372> */
	X86_SIM_X86_JMP(0x2ff, 0x372, x86_l_372);
x86_l_301:
	/* 0x301: cmp    ecx,0x1e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_304:
	/* 0x304: jne    37e <generic_usdt_filter_arg+0x37e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x304, 0x37e, x86_l_37e);
x86_l_306:
	/* 0x306: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_309:
	/* 0x309: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_30c:
	/* 0x30c: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_30e:
	/* 0x30e: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_317:
	/* 0x317: jne    108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x317, 0x108, x86_l_108);
x86_l_31d:
	/* 0x31d: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_320:
	/* 0x320: mov    rdx,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_328:
	/* 0x328: and    edx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_32e:
	/* 0x32e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_330:
	/* 0x330: andn   rcx,rcx,QWORD PTR [r14+rdx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_ANDN_MEM, X86_RCX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 618475290624ULL);
x86_l_33a:
	/* 0x33a: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_33d:
	/* 0x33d: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x33d, 0x383, x86_l_383);
x86_l_33f:
	/* 0x33f: cmp    eax,0x2a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 42ULL);
x86_l_342:
	/* 0x342: je     350 <generic_usdt_filter_arg+0x350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x342, 0x350, x86_l_350);
x86_l_344:
	/* 0x344: cmp    eax,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_347:
	/* 0x347: jne    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x347, 0x38c, x86_l_38c);
x86_l_349:
	/* 0x349: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_8e3, 0x34eULL);
x86_l_34e:
	/* 0x34e: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x34e, 0x383, x86_l_383);
x86_l_350:
	/* 0x350: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4a1, 0x355ULL);
x86_l_355:
	/* 0x355: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x355, 0x383, x86_l_383);
x86_l_357:
	/* 0x357: lea    ecx,[rax-0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_35a:
	/* 0x35a: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_35d:
	/* 0x35d: jae    379 <generic_usdt_filter_arg+0x379> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x35d, 0x379, x86_l_379);
x86_l_35f:
	/* 0x35f: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_98e, 0x364ULL);
x86_l_364:
	/* 0x364: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x364, 0x383, x86_l_383);
x86_l_366:
	/* 0x366: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_9d5, 0x36bULL);
x86_l_36b:
	/* 0x36b: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x36b, 0x383, x86_l_383);
x86_l_36d:
	/* 0x36d: mov    edx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_372:
	/* 0x372: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a1c, 0x377ULL);
x86_l_377:
	/* 0x377: jmp    383 <generic_usdt_filter_arg+0x383> */
	X86_SIM_X86_JMP(0x377, 0x383, x86_l_383);
x86_l_379:
	/* 0x379: cmp    eax,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_37c:
	/* 0x37c: jne    38c <generic_usdt_filter_arg+0x38c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37c, 0x38c, x86_l_38c);
x86_l_37e:
	/* 0x37e: call   0 <generic_usdt_filter_arg> */
	X86_SIM_X86_CALL(x86_l_abf, 0x383ULL);
x86_l_383:
	/* 0x383: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_386:
	/* 0x386: je     108 <generic_usdt_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_E, 0x386, 0x108, x86_l_108);
x86_l_38c:
	/* 0x38c: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_38f:
	/* 0x38f: cmp    r13,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 6ULL);
x86_l_393:
	/* 0x393: jne    16f <generic_usdt_filter_arg+0x16f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x393, 0x16f, x86_l_16f);
x86_l_399:
	/* 0x399: jmp    f2 <generic_usdt_filter_arg+0xf2> */
	X86_SIM_X86_JMP(0x399, 0xf2, x86_l_f2);
x86_l_39e:
	/* 0x39e: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a2:
	/* 0x3a2: mov    DWORD PTR [r14+0x5f04],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_3a9:
	/* 0x3a9: mov    rsi,QWORD PTR [rip+0x7a1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)usdt_calls));
x86_l_3b0:
	/* 0x3b0: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3b3:
	/* 0x3b3: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3b8:
	/* 0x3b8: call   7dda <filter_file_type+0x5800> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_3bd:
	/* 0x3bd: mov    rsi,QWORD PTR [rip+0x7a1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)usdt_calls));
x86_l_3c4:
	/* 0x3c4: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3c7:
	/* 0x3c7: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3cc:
	/* 0x3cc: call   7dee <filter_file_type+0x5814> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_3d1:
	/* 0x3d1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d3:
	/* 0x3d3: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3d7:
	/* 0x3d7: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3d8:
	/* 0x3d8: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3da:
	/* 0x3da: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3dc:
	/* 0x3dc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3de:
	/* 0x3de: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3e0:
	/* 0x3e0: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3e1:
	/* 0x3e1: jmp    2693 <filter_file_type+0xb9> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3e6:
	/* 0x3e6: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e9:
	/* 0x3e9: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_3f1:
	/* 0x3f1: jne    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3f1, 0x443, x86_l_443);
x86_l_3f3:
	/* 0x3f3: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3f9:
	/* 0x3f9: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_401:
	/* 0x401: jne    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x401, 0x443, x86_l_443);
x86_l_403:
	/* 0x403: mov    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_409:
	/* 0x409: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_411:
	/* 0x411: jne    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x411, 0x443, x86_l_443);
x86_l_413:
	/* 0x413: mov    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_419:
	/* 0x419: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_421:
	/* 0x421: jne    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x421, 0x443, x86_l_443);
x86_l_423:
	/* 0x423: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_429:
	/* 0x429: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_431:
	/* 0x431: jne    443 <generic_usdt_filter_arg+0x443> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x431, 0x443, x86_l_443);
x86_l_433:
	/* 0x433: mov    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_439:
	/* 0x439: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_441:
	/* 0x441: je     45e <generic_usdt_filter_arg+0x45e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x441, 0x45e, x86_l_45e);
x86_l_443:
	/* 0x443: mov    DWORD PTR [r14+0x5f00],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_44a:
	/* 0x44a: mov    rsi,QWORD PTR [rip+0x7a19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)usdt_calls));
x86_l_451:
	/* 0x451: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_454:
	/* 0x454: mov    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_459:
	/* 0x459: call   7e77 <filter_file_type+0x589d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_45e:
	/* 0x45e: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_462:
	/* 0x462: call   7e80 <filter_file_type+0x58a6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_467:
	/* 0x467: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_46c:
	/* 0x46c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_471:
	/* 0x471: mov    rdi,QWORD PTR [rip+0x7a19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_478:
	/* 0x478: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_47d:
	/* 0x47d: call   7e9b <filter_file_type+0x58c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_482:
	/* 0x482: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_485:
	/* 0x485: je     3d1 <generic_usdt_filter_arg+0x3d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x485, 0x3d1, x86_l_3d1);
x86_l_48b:
	/* 0x48b: mov    rdi,QWORD PTR [rip+0x7a19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_492:
	/* 0x492: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_497:
	/* 0x497: call   7eb5 <filter_file_type+0x58db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_49c:
	/* 0x49c: jmp    3d1 <generic_usdt_filter_arg+0x3d1> */
	X86_SIM_X86_JMP(0x49c, 0x3d1, x86_l_3d1);
x86_l_2693:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_4a1 */
x86_l_4a1:
	/* 0x4a1: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4a2:
	/* 0x4a2: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4a5:
	/* 0x4a5: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a7:
	/* 0x4a7: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4aa:
	/* 0x4aa: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4ac:
	/* 0x4ac: jne    4bc <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4ac, 0x4bc, x86_l_4bc);
x86_l_4ae:
	/* 0x4ae: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4b0:
	/* 0x4b0: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_4b3:
	/* 0x4b3: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_4b6:
	/* 0x4b6: je     4bc <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4b6, 0x4bc, x86_l_4bc);
x86_l_4b8:
	/* 0x4b8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ba:
	/* 0x4ba: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4bb:
	/* 0x4bb: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4bb);
x86_l_4bc:
	/* 0x4bc: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4bf:
	/* 0x4bf: ja     4fb <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4bf, 0x4fb, x86_l_4fb);
x86_l_4c1:
	/* 0x4c1: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4c3:
	/* 0x4c3: mov    edi,0x4000100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 67109120ULL);
x86_l_4c8:
	/* 0x4c8: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cc:
	/* 0x4cc: jb     52f <filter_file_buf+0x8e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4cc, 0x52f, x86_l_52f);
x86_l_4ce:
	/* 0x4ce: mov    edi,0x8000200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 134218240ULL);
x86_l_4d3:
	/* 0x4d3: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4d7:
	/* 0x4d7: jb     519 <filter_file_buf+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4d7, 0x519, x86_l_519);
x86_l_4d9:
	/* 0x4d9: movabs rdi,0x3000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, 206158430208ULL);
x86_l_4e3:
	/* 0x4e3: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e7:
	/* 0x4e7: jae    4fb <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x4e7, 0x4fb, x86_l_4fb);
x86_l_4e9:
	/* 0x4e9: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4ec:
	/* 0x4ec: call   25da <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_25da, 0x4f1ULL);
x86_l_4f1:
	/* 0x4f1: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4f4:
	/* 0x4f4: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4f7:
	/* 0x4f7: jbe    54c <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4f7, 0x54c, x86_l_54c);
x86_l_4f9:
	/* 0x4f9: jmp    562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x4f9, 0x562, x86_l_562);
x86_l_4fb:
	/* 0x4fb: lea    eax,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_4fe:
	/* 0x4fe: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_501:
	/* 0x501: jae    545 <filter_file_buf+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x501, 0x545, x86_l_545);
x86_l_503:
	/* 0x503: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_507:
	/* 0x507: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_50a:
	/* 0x50a: call   11ed <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_11ed, 0x50fULL);
x86_l_50f:
	/* 0x50f: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_512:
	/* 0x512: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_515:
	/* 0x515: jbe    54c <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x515, 0x54c, x86_l_54c);
x86_l_517:
	/* 0x517: jmp    562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x517, 0x562, x86_l_562);
x86_l_519:
	/* 0x519: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_51d:
	/* 0x51d: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_520:
	/* 0x520: call   f87 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_f87, 0x525ULL);
x86_l_525:
	/* 0x525: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_528:
	/* 0x528: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_52b:
	/* 0x52b: jbe    54c <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x52b, 0x54c, x86_l_54c);
x86_l_52d:
	/* 0x52d: jmp    562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x52d, 0x562, x86_l_562);
x86_l_52f:
	/* 0x52f: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_533:
	/* 0x533: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_536:
	/* 0x536: call   10ca <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10ca, 0x53bULL);
x86_l_53b:
	/* 0x53b: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_53e:
	/* 0x53e: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_541:
	/* 0x541: jbe    54c <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x541, 0x54c, x86_l_54c);
x86_l_543:
	/* 0x543: jmp    562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x543, 0x562, x86_l_562);
x86_l_545:
	/* 0x545: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_547:
	/* 0x547: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_54a:
	/* 0x54a: ja     562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x54a, 0x562, x86_l_562);
x86_l_54c:
	/* 0x54c: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_54e:
	/* 0x54e: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_558:
	/* 0x558: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_55c:
	/* 0x55c: jae    562 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x55c, 0x562, x86_l_562);
x86_l_55e:
	/* 0x55e: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_562:
	/* 0x562: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_563:
	/* 0x563: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4bb);

	/* native subroutine native_link_sub_564 */
x86_l_564:
	/* 0x564: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_565:
	/* 0x565: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_568:
	/* 0x568: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_56a:
	/* 0x56a: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_56e:
	/* 0x56e: ja     5a9 <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x56e, 0x5a9, x86_l_5a9);
x86_l_570:
	/* 0x570: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_575:
	/* 0x575: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_579:
	/* 0x579: jae    582 <filter_8ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x579, 0x582, x86_l_582);
x86_l_57b:
	/* 0x57b: call   2186 <filter_8ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_2186, 0x580ULL);
x86_l_580:
	/* 0x580: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_581:
	/* 0x581: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_581);
x86_l_582:
	/* 0x582: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_587:
	/* 0x587: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_58b:
	/* 0x58b: jb     5a4 <filter_8ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x58b, 0x5a4, x86_l_5a4);
x86_l_58d:
	/* 0x58d: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_597:
	/* 0x597: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_59b:
	/* 0x59b: jae    5a9 <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x59b, 0x5a9, x86_l_5a9);
x86_l_59d:
	/* 0x59d: call   23a0 <filter_8ty_range> */
	X86_SIM_X86_CALL(x86_l_23a0, 0x5a2ULL);
x86_l_5a2:
	/* 0x5a2: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5a3:
	/* 0x5a3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_581);
x86_l_5a4:
	/* 0x5a4: call   2558 <filter_8ty_map> */
	X86_SIM_X86_CALL(x86_l_2558, 0x5a9ULL);
x86_l_5a9:
	/* 0x5a9: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5aa:
	/* 0x5aa: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_581);

	/* native subroutine native_link_sub_5ab */
x86_l_5ab:
	/* 0x5ab: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5ad:
	/* 0x5ad: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5af:
	/* 0x5af: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5b1:
	/* 0x5b1: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5b2:
	/* 0x5b2: sub    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_5b6:
	/* 0x5b6: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_5bf:
	/* 0x5bf: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_5c8:
	/* 0x5c8: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_5d1:
	/* 0x5d1: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_5da:
	/* 0x5da: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_5e3:
	/* 0x5e3: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ea:
	/* 0x5ea: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_5f2:
	/* 0x5f2: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5f5:
	/* 0x5f5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5f7:
	/* 0x5f7: cmp    edx,0x27 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 39ULL);
x86_l_5fa:
	/* 0x5fa: jg     612 <filter_inet+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x5fa, 0x612, x86_l_612);
x86_l_5fc:
	/* 0x5fc: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_5ff:
	/* 0x5ff: je     697 <filter_inet+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5ff, 0x697, x86_l_697);
x86_l_605:
	/* 0x605: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_608:
	/* 0x608: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_60b:
	/* 0x60b: je     623 <filter_inet+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x60b, 0x623, x86_l_623);
x86_l_60d:
	/* 0x60d: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x60d, 0x89f, x86_l_89f);
x86_l_612:
	/* 0x612: cmp    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_615:
	/* 0x615: je     66f <filter_inet+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x615, 0x66f, x86_l_66f);
x86_l_617:
	/* 0x617: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_61a:
	/* 0x61a: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_61d:
	/* 0x61d: jne    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x61d, 0x89f, x86_l_89f);
x86_l_623:
	/* 0x623: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_626:
	/* 0x626: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_628:
	/* 0x628: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_62b:
	/* 0x62b: jle    6a4 <filter_inet+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x62b, 0x6a4, x86_l_6a4);
x86_l_62d:
	/* 0x62d: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_630:
	/* 0x630: jg     64f <filter_inet+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x630, 0x64f, x86_l_64f);
x86_l_632:
	/* 0x632: lea    edx,[rcx-0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_635:
	/* 0x635: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_638:
	/* 0x638: jb     6f5 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x638, 0x6f5, x86_l_6f5);
x86_l_63e:
	/* 0x63e: lea    edx,[rcx-0x16] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_641:
	/* 0x641: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_644:
	/* 0x644: jb     6ef <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x644, 0x6ef, x86_l_6ef);
x86_l_64a:
	/* 0x64a: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x64a, 0x89f, x86_l_89f);
x86_l_64f:
	/* 0x64f: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_652:
	/* 0x652: jg     732 <filter_inet+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x652, 0x732, x86_l_732);
x86_l_658:
	/* 0x658: cmp    ecx,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_65b:
	/* 0x65b: je     765 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x65b, 0x765, x86_l_765);
x86_l_661:
	/* 0x661: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_664:
	/* 0x664: je     75b <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x664, 0x75b, x86_l_75b);
x86_l_66a:
	/* 0x66a: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x66a, 0x89f, x86_l_89f);
x86_l_66f:
	/* 0x66f: movzx  eax,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_672:
	/* 0x672: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_677:
	/* 0x677: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_67b:
	/* 0x67b: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_680:
	/* 0x680: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_684:
	/* 0x684: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_689:
	/* 0x689: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_68d:
	/* 0x68d: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_692:
	/* 0x692: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_697:
	/* 0x697: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69a:
	/* 0x69a: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_69d:
	/* 0x69d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69f:
	/* 0x69f: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_6a2:
	/* 0x6a2: jg     62d <filter_inet+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6a2, 0x62d, x86_l_62d);
x86_l_6a4:
	/* 0x6a4: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_6a7:
	/* 0x6a7: jle    6c5 <filter_inet+0x11a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x6a7, 0x6c5, x86_l_6c5);
x86_l_6a9:
	/* 0x6a9: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6ac:
	/* 0x6ac: jg     6e1 <filter_inet+0x136> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6ac, 0x6e1, x86_l_6e1);
x86_l_6ae:
	/* 0x6ae: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_6b1:
	/* 0x6b1: je     6ef <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6b1, 0x6ef, x86_l_6ef);
x86_l_6b3:
	/* 0x6b3: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6b6:
	/* 0x6b6: jne    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6b6, 0x89f, x86_l_89f);
x86_l_6bc:
	/* 0x6bc: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_6c0:
	/* 0x6c0: jmp    894 <filter_inet+0x2e9> */
	X86_SIM_X86_SUB_JMP(0x6c0, 0x894, x86_l_894);
x86_l_6c5:
	/* 0x6c5: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_6c8:
	/* 0x6c8: je     765 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6c8, 0x765, x86_l_765);
x86_l_6ce:
	/* 0x6ce: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_6d1:
	/* 0x6d1: je     75b <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6d1, 0x75b, x86_l_75b);
x86_l_6d7:
	/* 0x6d7: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_6da:
	/* 0x6da: je     6f5 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6da, 0x6f5, x86_l_6f5);
x86_l_6dc:
	/* 0x6dc: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x6dc, 0x89f, x86_l_89f);
x86_l_6e1:
	/* 0x6e1: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_6e4:
	/* 0x6e4: je     6f5 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6e4, 0x6f5, x86_l_6f5);
x86_l_6e6:
	/* 0x6e6: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_6e9:
	/* 0x6e9: jne    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6e9, 0x89f, x86_l_89f);
x86_l_6ef:
	/* 0x6ef: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_6f3:
	/* 0x6f3: jmp    6f9 <filter_inet+0x14e> */
	X86_SIM_X86_SUB_JMP(0x6f3, 0x6f9, x86_l_6f9);
x86_l_6f5:
	/* 0x6f5: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6f9:
	/* 0x6f9: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_6fd:
	/* 0x6fd: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ff:
	/* 0x6ff: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_702:
	/* 0x702: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_705:
	/* 0x705: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_707:
	/* 0x707: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_70a:
	/* 0x70a: jg     77c <filter_inet+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x70a, 0x77c, x86_l_77c);
x86_l_70c:
	/* 0x70c: lea    edx,[rcx-0xd] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_70f:
	/* 0x70f: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_712:
	/* 0x712: jb     7a3 <filter_inet+0x1f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x712, 0x7a3, x86_l_7a3);
x86_l_718:
	/* 0x718: lea    edx,[rcx-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_71b:
	/* 0x71b: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_71e:
	/* 0x71e: jb     7f3 <filter_inet+0x248> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x71e, 0x7f3, x86_l_7f3);
x86_l_724:
	/* 0x724: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_727:
	/* 0x727: je     897 <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x727, 0x897, x86_l_897);
x86_l_72d:
	/* 0x72d: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x72d, 0x89f, x86_l_89f);
x86_l_732:
	/* 0x732: cmp    ecx,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_735:
	/* 0x735: je     890 <filter_inet+0x2e5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x735, 0x890, x86_l_890);
x86_l_73b:
	/* 0x73b: cmp    ecx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_73e:
	/* 0x73e: jne    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x73e, 0x89f, x86_l_89f);
x86_l_744:
	/* 0x744: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_747:
	/* 0x747: jne    8c3 <filter_inet+0x318> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x747, 0x8c3, x86_l_8c3);
x86_l_74d:
	/* 0x74d: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_750:
	/* 0x750: jne    8cd <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x750, 0x8cd, x86_l_8cd);
x86_l_756:
	/* 0x756: jmp    897 <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JMP(0x756, 0x897, x86_l_897);
x86_l_75b:
	/* 0x75b: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75f:
	/* 0x75f: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_763:
	/* 0x763: jmp    76c <filter_inet+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x763, 0x76c, x86_l_76c);
x86_l_765:
	/* 0x765: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_768:
	/* 0x768: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_76c:
	/* 0x76c: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_76f:
	/* 0x76f: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_773:
	/* 0x773: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_775:
	/* 0x775: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_777:
	/* 0x777: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_77a:
	/* 0x77a: jle    70c <filter_inet+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x77a, 0x70c, x86_l_70c);
x86_l_77c:
	/* 0x77c: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_77f:
	/* 0x77f: ja     7e7 <filter_inet+0x23c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x77f, 0x7e7, x86_l_7e7);
x86_l_781:
	/* 0x781: mov    r8d,0x500000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 5242880ULL);
x86_l_787:
	/* 0x787: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_78b:
	/* 0x78b: jb     7fd <filter_inet+0x252> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x78b, 0x7fd, x86_l_7fd);
x86_l_78d:
	/* 0x78d: mov    r8d,0xa00000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 10485760ULL);
x86_l_793:
	/* 0x793: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_797:
	/* 0x797: jb     80d <filter_inet+0x262> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x797, 0x80d, x86_l_80d);
x86_l_799:
	/* 0x799: mov    edx,0x3000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 50331648ULL);
x86_l_79e:
	/* 0x79e: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7a1:
	/* 0x7a1: jae    7e7 <filter_inet+0x23c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x7a1, 0x7e7, x86_l_7e7);
x86_l_7a3:
	/* 0x7a3: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_7a7:
	/* 0x7a7: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_7aa:
	/* 0x7aa: je     81d <filter_inet+0x272> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7aa, 0x81d, x86_l_81d);
x86_l_7ac:
	/* 0x7ac: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7af:
	/* 0x7af: jne    889 <filter_inet+0x2de> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7af, 0x889, x86_l_889);
x86_l_7b5:
	/* 0x7b5: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_7b8:
	/* 0x7b8: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7bb:
	/* 0x7bb: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7bf:
	/* 0x7bf: mov    rdi,QWORD PTR [rip+0x1d00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr4lpm_maps));
x86_l_7c6:
	/* 0x7c6: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7cb:
	/* 0x7cb: call   24d0 <filter_8ty_range+0x130> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7d0:
	/* 0x7d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d3:
	/* 0x7d3: je     8ab <filter_inet+0x300> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7d3, 0x8ab, x86_l_8ab);
x86_l_7d9:
	/* 0x7d9: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_7e1:
	/* 0x7e1: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7e5:
	/* 0x7e5: jmp    85c <filter_inet+0x2b1> */
	X86_SIM_X86_SUB_JMP(0x7e5, 0x85c, x86_l_85c);
x86_l_7e7:
	/* 0x7e7: add    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_7ea:
	/* 0x7ea: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7ed:
	/* 0x7ed: jae    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x7ed, 0x89f, x86_l_89f);
x86_l_7f3:
	/* 0x7f3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7f8:
	/* 0x7f8: jmp    89a <filter_inet+0x2ef> */
	X86_SIM_X86_SUB_JMP(0x7f8, 0x89a, x86_l_89a);
x86_l_7fd:
	/* 0x7fd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ff:
	/* 0x7ff: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_805:
	/* 0x805: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_808:
	/* 0x808: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x808, 0x89f, x86_l_89f);
x86_l_80d:
	/* 0x80d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80f:
	/* 0x80f: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_815:
	/* 0x815: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_818:
	/* 0x818: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x818, 0x89f, x86_l_89f);
x86_l_81d:
	/* 0x81d: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_820:
	/* 0x820: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_823:
	/* 0x823: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_827:
	/* 0x827: mov    rdi,QWORD PTR [rip+0x1d00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr6lpm_maps));
x86_l_82e:
	/* 0x82e: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_833:
	/* 0x833: call   2538 <filter_8ty_range+0x198> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_838:
	/* 0x838: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_83b:
	/* 0x83b: je     8ab <filter_inet+0x300> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x83b, 0x8ab, x86_l_8ab);
x86_l_83d:
	/* 0x83d: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_845:
	/* 0x845: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_849:
	/* 0x849: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_84e:
	/* 0x84e: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_853:
	/* 0x853: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_857:
	/* 0x857: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_85c:
	/* 0x85c: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_861:
	/* 0x861: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_864:
	/* 0x864: call   2569 <filter_8ty_map+0x11> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_869:
	/* 0x869: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_86e:
	/* 0x86e: lea    edx,[rcx-0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_871:
	/* 0x871: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_874:
	/* 0x874: jb     8b8 <filter_inet+0x30d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x874, 0x8b8, x86_l_8b8);
x86_l_876:
	/* 0x876: add    ecx,0xfffffff3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_879:
	/* 0x879: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_87c:
	/* 0x87c: ja     889 <filter_inet+0x2de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x87c, 0x889, x86_l_889);
x86_l_87e:
	/* 0x87e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_881:
	/* 0x881: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_884:
	/* 0x884: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_887:
	/* 0x887: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x887, 0x89f, x86_l_89f);
x86_l_889:
	/* 0x889: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_88b:
	/* 0x88b: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_88e:
	/* 0x88e: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x88e, 0x89f, x86_l_89f);
x86_l_890:
	/* 0x890: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_894:
	/* 0x894: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_897:
	/* 0x897: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_89a:
	/* 0x89a: call   2105 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2105, 0x89fULL);
x86_l_89f:
	/* 0x89f: add    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_8a3:
	/* 0x8a3: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8a4:
	/* 0x8a4: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8a6:
	/* 0x8a6: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8a8:
	/* 0x8a8: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8aa:
	/* 0x8aa: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8aa);
x86_l_8ab:
	/* 0x8ab: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8b0:
	/* 0x8b0: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_8b3:
	/* 0x8b3: cmp    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_8b6:
	/* 0x8b6: jmp    8bb <filter_inet+0x310> */
	X86_SIM_X86_SUB_JMP(0x8b6, 0x8bb, x86_l_8bb);
x86_l_8b8:
	/* 0x8b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8bb:
	/* 0x8bb: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_8be:
	/* 0x8be: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_8c1:
	/* 0x8c1: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x8c1, 0x89f, x86_l_89f);
x86_l_8c3:
	/* 0x8c3: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_8c6:
	/* 0x8c6: jne    8d5 <filter_inet+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x8c6, 0x8d5, x86_l_8d5);
x86_l_8c8:
	/* 0x8c8: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_8cb:
	/* 0x8cb: je     8d5 <filter_inet+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8cb, 0x8d5, x86_l_8d5);
x86_l_8cd:
	/* 0x8cd: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_8d2:
	/* 0x8d2: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8d5:
	/* 0x8d5: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_8d8:
	/* 0x8d8: je     897 <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8d8, 0x897, x86_l_897);
x86_l_8da:
	/* 0x8da: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_8dd:
	/* 0x8dd: je     897 <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8dd, 0x897, x86_l_897);
x86_l_8df:
	/* 0x8df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8e1:
	/* 0x8e1: jmp    89f <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x8e1, 0x89f, x86_l_89f);

	/* native subroutine native_link_sub_8e3 */
x86_l_8e3:
	/* 0x8e3: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_8e4:
	/* 0x8e4: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_8e8:
	/* 0x8e8: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_8eb:
	/* 0x8eb: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_8ef:
	/* 0x8ef: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_8f3:
	/* 0x8f3: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8f7:
	/* 0x8f7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8f9:
	/* 0x8f9: cmp    r8d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_8fd:
	/* 0x8fd: jg     933 <filter_sockaddr_un+0x50> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x8fd, 0x933, x86_l_933);
x86_l_8ff:
	/* 0x8ff: lea    ecx,[r8-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_903:
	/* 0x903: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_906:
	/* 0x906: jae    941 <filter_sockaddr_un+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x906, 0x941, x86_l_941);
x86_l_908:
	/* 0x908: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_90b:
	/* 0x90b: call   11ed <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_11ed, 0x910ULL);
x86_l_910:
	/* 0x910: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_913:
	/* 0x913: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_917:
	/* 0x917: ja     92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x917, 0x92d, x86_l_92d);
x86_l_919:
	/* 0x919: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_923:
	/* 0x923: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_927:
	/* 0x927: jae    92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x927, 0x92d, x86_l_92d);
x86_l_929:
	/* 0x929: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_92d:
	/* 0x92d: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_931:
	/* 0x931: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_932:
	/* 0x932: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_932);
x86_l_933:
	/* 0x933: cmp    r8d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_937:
	/* 0x937: je     977 <filter_sockaddr_un+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x937, 0x977, x86_l_977);
x86_l_939:
	/* 0x939: cmp    r8d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_93d:
	/* 0x93d: je     947 <filter_sockaddr_un+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x93d, 0x947, x86_l_947);
x86_l_93f:
	/* 0x93f: jmp    92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JMP(0x93f, 0x92d, x86_l_92d);
x86_l_941:
	/* 0x941: cmp    r8d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_945:
	/* 0x945: jne    92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x945, 0x92d, x86_l_92d);
x86_l_947:
	/* 0x947: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_94a:
	/* 0x94a: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_94d:
	/* 0x94d: mov    edi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_94f:
	/* 0x94f: call   10ca <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10ca, 0x954ULL);
x86_l_954:
	/* 0x954: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_957:
	/* 0x957: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_95b:
	/* 0x95b: ja     92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x95b, 0x92d, x86_l_92d);
x86_l_95d:
	/* 0x95d: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_967:
	/* 0x967: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_96b:
	/* 0x96b: jae    92d <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x96b, 0x92d, x86_l_92d);
x86_l_96d:
	/* 0x96d: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_971:
	/* 0x971: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_975:
	/* 0x975: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_976:
	/* 0x976: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_932);
x86_l_977:
	/* 0x977: movzx  eax,WORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_97a:
	/* 0x97a: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_97e:
	/* 0x97e: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_983:
	/* 0x983: call   2105 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2105, 0x988ULL);
x86_l_988:
	/* 0x988: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_98c:
	/* 0x98c: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_98d:
	/* 0x98d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_932);

	/* native subroutine native_link_sub_98e */
x86_l_98e:
	/* 0x98e: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_98f:
	/* 0x98f: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_992:
	/* 0x992: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_994:
	/* 0x994: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_998:
	/* 0x998: ja     9d3 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x998, 0x9d3, x86_l_9d3);
x86_l_99a:
	/* 0x99a: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_99f:
	/* 0x99f: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9a3:
	/* 0x9a3: jae    9ac <filter_32ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9a3, 0x9ac, x86_l_9ac);
x86_l_9a5:
	/* 0x9a5: call   1d3b <filter_32ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1d3b, 0x9aaULL);
x86_l_9aa:
	/* 0x9aa: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9ab:
	/* 0x9ab: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9ab);
x86_l_9ac:
	/* 0x9ac: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_9b1:
	/* 0x9b1: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9b5:
	/* 0x9b5: jb     9ce <filter_32ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9b5, 0x9ce, x86_l_9ce);
x86_l_9b7:
	/* 0x9b7: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_9c1:
	/* 0x9c1: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9c5:
	/* 0x9c5: jae    9d3 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9c5, 0x9d3, x86_l_9d3);
x86_l_9c7:
	/* 0x9c7: call   1f4f <filter_32ty_range> */
	X86_SIM_X86_CALL(x86_l_1f4f, 0x9ccULL);
x86_l_9cc:
	/* 0x9cc: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9cd:
	/* 0x9cd: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9ab);
x86_l_9ce:
	/* 0x9ce: call   2105 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_2105, 0x9d3ULL);
x86_l_9d3:
	/* 0x9d3: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9d4:
	/* 0x9d4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9ab);

	/* native subroutine native_link_sub_9d5 */
x86_l_9d5:
	/* 0x9d5: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d6:
	/* 0x9d6: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9d9:
	/* 0x9d9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9db:
	/* 0x9db: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_9df:
	/* 0x9df: ja     a1a <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x9df, 0xa1a, x86_l_a1a);
x86_l_9e1:
	/* 0x9e1: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_9e6:
	/* 0x9e6: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9ea:
	/* 0x9ea: jae    9f3 <filter_16ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9ea, 0x9f3, x86_l_9f3);
x86_l_9ec:
	/* 0x9ec: call   18e7 <filter_16ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_18e7, 0x9f1ULL);
x86_l_9f1:
	/* 0x9f1: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9f2:
	/* 0x9f2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9f2);
x86_l_9f3:
	/* 0x9f3: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_9f8:
	/* 0x9f8: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9fc:
	/* 0x9fc: jb     a15 <filter_16ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9fc, 0xa15, x86_l_a15);
x86_l_9fe:
	/* 0x9fe: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_a08:
	/* 0xa08: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a0c:
	/* 0xa0c: jae    a1a <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa0c, 0xa1a, x86_l_a1a);
x86_l_a0e:
	/* 0xa0e: call   1b01 <filter_16ty_range> */
	X86_SIM_X86_CALL(x86_l_1b01, 0xa13ULL);
x86_l_a13:
	/* 0xa13: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a14:
	/* 0xa14: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9f2);
x86_l_a15:
	/* 0xa15: call   1cb9 <filter_16ty_map> */
	X86_SIM_X86_CALL(x86_l_1cb9, 0xa1aULL);
x86_l_a1a:
	/* 0xa1a: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a1b:
	/* 0xa1b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9f2);

	/* native subroutine native_link_sub_a1c */
x86_l_a1c:
	/* 0xa1c: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a1d:
	/* 0xa1d: mov    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_a20:
	/* 0xa20: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a23:
	/* 0xa23: movsxd rcx,edx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_a26:
	/* 0xa26: mov    edx,DWORD PTR [rsi+rcx*1-0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 18446744073709551612ULL);
x86_l_a2a:
	/* 0xa2a: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a2c:
	/* 0xa2c: add    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a2f:
	/* 0xa2f: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a32:
	/* 0xa32: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a34:
	/* 0xa34: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_a37:
	/* 0xa37: jg     a4d <filter_char_buf+0x31> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xa37, 0xa4d, x86_l_a4d);
x86_l_a39:
	/* 0xa39: lea    edi,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_a3c:
	/* 0xa3c: cmp    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_a3f:
	/* 0xa3f: jb     a84 <filter_char_buf+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa3f, 0xa84, x86_l_a84);
x86_l_a41:
	/* 0xa41: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_a44:
	/* 0xa44: je     a7a <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa44, 0xa7a, x86_l_a7a);
x86_l_a46:
	/* 0xa46: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_a49:
	/* 0xa49: je     a5c <filter_char_buf+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa49, 0xa5c, x86_l_a5c);
x86_l_a4b:
	/* 0xa4b: jmp    a9b <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JMP(0xa4b, 0xa9b, x86_l_a9b);
x86_l_a4d:
	/* 0xa4d: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_a50:
	/* 0xa50: jg     a66 <filter_char_buf+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xa50, 0xa66, x86_l_a66);
x86_l_a52:
	/* 0xa52: cmp    ecx,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_a55:
	/* 0xa55: je     a7a <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa55, 0xa7a, x86_l_a7a);
x86_l_a57:
	/* 0xa57: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_a5a:
	/* 0xa5a: jne    a9b <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xa5a, 0xa9b, x86_l_a9b);
x86_l_a5c:
	/* 0xa5c: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a5f:
	/* 0xa5f: call   f87 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_f87, 0xa64ULL);
x86_l_a64:
	/* 0xa64: jmp    a98 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa64, 0xa98, x86_l_a98);
x86_l_a66:
	/* 0xa66: cmp    ecx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_a69:
	/* 0xa69: je     a8e <filter_char_buf+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa69, 0xa8e, x86_l_a8e);
x86_l_a6b:
	/* 0xa6b: cmp    ecx,0x22 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_a6e:
	/* 0xa6e: jne    a9b <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xa6e, 0xa9b, x86_l_a9b);
x86_l_a70:
	/* 0xa70: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a73:
	/* 0xa73: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_a78:
	/* 0xa78: jmp    a93 <filter_char_buf+0x77> */
	X86_SIM_X86_SUB_JMP(0xa78, 0xa93, x86_l_a93);
x86_l_a7a:
	/* 0xa7a: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a7d:
	/* 0xa7d: call   10ca <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10ca, 0xa82ULL);
x86_l_a82:
	/* 0xa82: jmp    a98 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa82, 0xa98, x86_l_a98);
x86_l_a84:
	/* 0xa84: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a87:
	/* 0xa87: call   11ed <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_11ed, 0xa8cULL);
x86_l_a8c:
	/* 0xa8c: jmp    a98 <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa8c, 0xa98, x86_l_a98);
x86_l_a8e:
	/* 0xa8e: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a91:
	/* 0xa91: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a93:
	/* 0xa93: call   16d6 <filter_char_substring> */
	X86_SIM_X86_CALL(x86_l_16d6, 0xa98ULL);
x86_l_a98:
	/* 0xa98: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a9b:
	/* 0xa9b: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_a9e:
	/* 0xa9e: ja     abd <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa9e, 0xabd, x86_l_abd);
x86_l_aa0:
	/* 0xaa0: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_aa2:
	/* 0xaa2: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_aac:
	/* 0xaac: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ab0:
	/* 0xab0: jae    abd <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xab0, 0xabd, x86_l_abd);
x86_l_ab2:
	/* 0xab2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ab4:
	/* 0xab4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ab7:
	/* 0xab7: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_aba:
	/* 0xaba: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_abd:
	/* 0xabd: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_abe:
	/* 0xabe: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_abe);

	/* native subroutine native_link_sub_abf */
x86_l_abf:
	/* 0xabf: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac0:
	/* 0xac0: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ac3:
	/* 0xac3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac5:
	/* 0xac5: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_ac9:
	/* 0xac9: ja     b04 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xac9, 0xb04, x86_l_b04);
x86_l_acb:
	/* 0xacb: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_ad0:
	/* 0xad0: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ad4:
	/* 0xad4: jae    add <filter_64ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xad4, 0xadd, x86_l_add);
x86_l_ad6:
	/* 0xad6: call   b06 <filter_64ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_b06, 0xadbULL);
x86_l_adb:
	/* 0xadb: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_adc:
	/* 0xadc: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_adc);
x86_l_add:
	/* 0xadd: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_ae2:
	/* 0xae2: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ae6:
	/* 0xae6: jb     aff <filter_64ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xae6, 0xaff, x86_l_aff);
x86_l_ae8:
	/* 0xae8: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_af2:
	/* 0xaf2: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_af6:
	/* 0xaf6: jae    b04 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xaf6, 0xb04, x86_l_b04);
x86_l_af8:
	/* 0xaf8: call   d38 <filter_64ty_range> */
	X86_SIM_X86_CALL(x86_l_d38, 0xafdULL);
x86_l_afd:
	/* 0xafd: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_afe:
	/* 0xafe: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_adc);
x86_l_aff:
	/* 0xaff: call   f13 <filter_64ty_map> */
	X86_SIM_X86_CALL(x86_l_f13, 0xb04ULL);
x86_l_b04:
	/* 0xb04: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b05:
	/* 0xb05: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_adc);

	/* native subroutine native_link_sub_b06 */
x86_l_b06:
	/* 0xb06: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b09:
	/* 0xb09: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b0e:
	/* 0xb0e: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_b12:
	/* 0xb12: ja     b8a <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb12, 0xb8a, x86_l_b8a);
x86_l_b14:
	/* 0xb14: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_b1e:
	/* 0xb1e: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b22:
	/* 0xb22: jae    b25 <filter_64ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb22, 0xb25, x86_l_b25);
x86_l_b24:
	/* 0xb24: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b24);
x86_l_b25:
	/* 0xb25: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_b2a:
	/* 0xb2a: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b2e:
	/* 0xb2e: jae    b46 <filter_64ty_selector_val+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb2e, 0xb46, x86_l_b46);
x86_l_b30:
	/* 0xb30: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b33:
	/* 0xb33: cmp    rdx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_b37:
	/* 0xb37: jne    c68 <filter_64ty_selector_val+0x162> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb37, 0xc68, x86_l_c68);
x86_l_b3d:
	/* 0xb3d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b3f:
	/* 0xb3f: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_b42:
	/* 0xb42: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_b45:
	/* 0xb45: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b24);
x86_l_b46:
	/* 0xb46: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_b4a:
	/* 0xb4a: jne    b8a <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb4a, 0xb8a, x86_l_b8a);
x86_l_b4c:
	/* 0xb4c: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b4f:
	/* 0xb4f: test   QWORD PTR [rdi+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_b53:
	/* 0xb53: jne    b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb53, 0xb24, x86_l_b24);
x86_l_b55:
	/* 0xb55: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b58:
	/* 0xb58: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_b5b:
	/* 0xb5b: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb5b, 0xd35, x86_l_d35);
x86_l_b61:
	/* 0xb61: test   QWORD PTR [rdi+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_b65:
	/* 0xb65: jne    b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb65, 0xb24, x86_l_b24);
x86_l_b67:
	/* 0xb67: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_b6a:
	/* 0xb6a: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb6a, 0xd35, x86_l_d35);
x86_l_b70:
	/* 0xb70: test   QWORD PTR [rdi+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_b74:
	/* 0xb74: jne    b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb74, 0xb24, x86_l_b24);
x86_l_b76:
	/* 0xb76: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_b79:
	/* 0xb79: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb79, 0xd35, x86_l_d35);
x86_l_b7f:
	/* 0xb7f: test   QWORD PTR [rdi+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_b83:
	/* 0xb83: jne    b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb83, 0xb24, x86_l_b24);
x86_l_b85:
	/* 0xb85: jmp    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xb85, 0xd35, x86_l_d35);
x86_l_b8a:
	/* 0xb8a: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b8d:
	/* 0xb8d: je     c00 <filter_64ty_selector_val+0xfa> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb8d, 0xc00, x86_l_c00);
x86_l_b8f:
	/* 0xb8f: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_b92:
	/* 0xb92: jne    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb92, 0xd35, x86_l_d35);
x86_l_b98:
	/* 0xb98: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b9b:
	/* 0xb9b: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_b9e:
	/* 0xb9e: ja     cf8 <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb9e, 0xcf8, x86_l_cf8);
x86_l_ba4:
	/* 0xba4: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_ba9:
	/* 0xba9: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_bac:
	/* 0xbac: jae    cf8 <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xbac, 0xcf8, x86_l_cf8);
x86_l_bb2:
	/* 0xbb2: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bb5:
	/* 0xbb5: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_bb9:
	/* 0xbb9: jl     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbb9, 0xb24, x86_l_b24);
x86_l_bbf:
	/* 0xbbf: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bc2:
	/* 0xbc2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_bc5:
	/* 0xbc5: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbc5, 0xd35, x86_l_d35);
x86_l_bcb:
	/* 0xbcb: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_bcf:
	/* 0xbcf: jl     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbcf, 0xb24, x86_l_b24);
x86_l_bd5:
	/* 0xbd5: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_bd8:
	/* 0xbd8: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbd8, 0xd35, x86_l_d35);
x86_l_bde:
	/* 0xbde: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_be2:
	/* 0xbe2: jl     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbe2, 0xb24, x86_l_b24);
x86_l_be8:
	/* 0xbe8: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_beb:
	/* 0xbeb: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbeb, 0xd35, x86_l_d35);
x86_l_bf1:
	/* 0xbf1: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_bf5:
	/* 0xbf5: jl     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbf5, 0xb24, x86_l_b24);
x86_l_bfb:
	/* 0xbfb: jmp    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xbfb, 0xd35, x86_l_d35);
x86_l_c00:
	/* 0xc00: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_c03:
	/* 0xc03: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_c06:
	/* 0xc06: ja     cb9 <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc06, 0xcb9, x86_l_cb9);
x86_l_c0c:
	/* 0xc0c: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_c11:
	/* 0xc11: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c14:
	/* 0xc14: jae    cb9 <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc14, 0xcb9, x86_l_cb9);
x86_l_c1a:
	/* 0xc1a: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c1d:
	/* 0xc1d: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c21:
	/* 0xc21: jg     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc21, 0xb24, x86_l_b24);
x86_l_c27:
	/* 0xc27: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c2a:
	/* 0xc2a: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c2d:
	/* 0xc2d: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc2d, 0xd35, x86_l_d35);
x86_l_c33:
	/* 0xc33: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c37:
	/* 0xc37: jg     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc37, 0xb24, x86_l_b24);
x86_l_c3d:
	/* 0xc3d: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_c40:
	/* 0xc40: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc40, 0xd35, x86_l_d35);
x86_l_c46:
	/* 0xc46: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c4a:
	/* 0xc4a: jg     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc4a, 0xb24, x86_l_b24);
x86_l_c50:
	/* 0xc50: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c53:
	/* 0xc53: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc53, 0xd35, x86_l_d35);
x86_l_c59:
	/* 0xc59: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c5d:
	/* 0xc5d: jg     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc5d, 0xb24, x86_l_b24);
x86_l_c63:
	/* 0xc63: jmp    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc63, 0xd35, x86_l_d35);
x86_l_c68:
	/* 0xc68: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c6b:
	/* 0xc6b: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c6e:
	/* 0xc6e: jb     c98 <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc6e, 0xc98, x86_l_c98);
x86_l_c70:
	/* 0xc70: cmp    rdx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c74:
	/* 0xc74: je     b3d <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc74, 0xb3d, x86_l_b3d);
x86_l_c7a:
	/* 0xc7a: cmp    esi,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_c7d:
	/* 0xc7d: jb     c98 <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc7d, 0xc98, x86_l_c98);
x86_l_c7f:
	/* 0xc7f: cmp    rdx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c83:
	/* 0xc83: je     b3d <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc83, 0xb3d, x86_l_b3d);
x86_l_c89:
	/* 0xc89: cmp    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c8c:
	/* 0xc8c: jb     c98 <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc8c, 0xc98, x86_l_c98);
x86_l_c8e:
	/* 0xc8e: cmp    rdx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c92:
	/* 0xc92: je     b3d <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc92, 0xb3d, x86_l_b3d);
x86_l_c98:
	/* 0xc98: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_c9b:
	/* 0xc9b: ja     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc9b, 0xd35, x86_l_d35);
x86_l_ca1:
	/* 0xca1: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_ca3:
	/* 0xca3: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_cad:
	/* 0xcad: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cb1:
	/* 0xcb1: jb     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcb1, 0xb24, x86_l_b24);
x86_l_cb7:
	/* 0xcb7: jmp    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xcb7, 0xd35, x86_l_d35);
x86_l_cb9:
	/* 0xcb9: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cbc:
	/* 0xcbc: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_cc0:
	/* 0xcc0: ja     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcc0, 0xb24, x86_l_b24);
x86_l_cc6:
	/* 0xcc6: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cc9:
	/* 0xcc9: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_ccc:
	/* 0xccc: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xccc, 0xd35, x86_l_d35);
x86_l_cce:
	/* 0xcce: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_cd2:
	/* 0xcd2: ja     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcd2, 0xb24, x86_l_b24);
x86_l_cd8:
	/* 0xcd8: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_cdb:
	/* 0xcdb: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcdb, 0xd35, x86_l_d35);
x86_l_cdd:
	/* 0xcdd: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_ce1:
	/* 0xce1: ja     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xce1, 0xb24, x86_l_b24);
x86_l_ce7:
	/* 0xce7: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_cea:
	/* 0xcea: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcea, 0xd35, x86_l_d35);
x86_l_cec:
	/* 0xcec: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_cf0:
	/* 0xcf0: ja     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcf0, 0xb24, x86_l_b24);
x86_l_cf6:
	/* 0xcf6: jmp    d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xcf6, 0xd35, x86_l_d35);
x86_l_cf8:
	/* 0xcf8: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cfb:
	/* 0xcfb: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_cff:
	/* 0xcff: jb     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcff, 0xb24, x86_l_b24);
x86_l_d05:
	/* 0xd05: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d08:
	/* 0xd08: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_d0b:
	/* 0xd0b: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd0b, 0xd35, x86_l_d35);
x86_l_d0d:
	/* 0xd0d: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d11:
	/* 0xd11: jb     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd11, 0xb24, x86_l_b24);
x86_l_d17:
	/* 0xd17: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d1a:
	/* 0xd1a: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd1a, 0xd35, x86_l_d35);
x86_l_d1c:
	/* 0xd1c: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d20:
	/* 0xd20: jb     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd20, 0xb24, x86_l_b24);
x86_l_d26:
	/* 0xd26: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_d29:
	/* 0xd29: jb     d35 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd29, 0xd35, x86_l_d35);
x86_l_d2b:
	/* 0xd2b: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d2f:
	/* 0xd2f: jb     b24 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd2f, 0xb24, x86_l_b24);
x86_l_d35:
	/* 0xd35: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d37:
	/* 0xd37: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b24);

	/* native subroutine native_link_sub_d38 */
x86_l_d38:
	/* 0xd38: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_d3b:
	/* 0xd3b: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_d3e:
	/* 0xd3e: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_d41:
	/* 0xd41: ja     e3b <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd41, 0xe3b, x86_l_e3b);
x86_l_d47:
	/* 0xd47: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_d4c:
	/* 0xd4c: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d4f:
	/* 0xd4f: jae    e3b <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xd4f, 0xe3b, x86_l_e3b);
x86_l_d55:
	/* 0xd55: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d58:
	/* 0xd58: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_d5b:
	/* 0xd5b: jne    dcb <filter_64ty_range+0x93> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd5b, 0xdcb, x86_l_dcb);
x86_l_d5d:
	/* 0xd5d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d62:
	/* 0xd62: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d66:
	/* 0xd66: jg     d72 <filter_64ty_range+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd66, 0xd72, x86_l_d72);
x86_l_d68:
	/* 0xd68: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d6c:
	/* 0xd6c: jle    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd6c, 0xe54, x86_l_e54);
x86_l_d72:
	/* 0xd72: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d75:
	/* 0xd75: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d78:
	/* 0xd78: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd78, 0xf02, x86_l_f02);
x86_l_d7e:
	/* 0xd7e: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d82:
	/* 0xd82: jg     d8e <filter_64ty_range+0x56> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd82, 0xd8e, x86_l_d8e);
x86_l_d84:
	/* 0xd84: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d88:
	/* 0xd88: jle    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd88, 0xe54, x86_l_e54);
x86_l_d8e:
	/* 0xd8e: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_d91:
	/* 0xd91: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd91, 0xf02, x86_l_f02);
x86_l_d97:
	/* 0xd97: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d9b:
	/* 0xd9b: jg     da7 <filter_64ty_range+0x6f> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd9b, 0xda7, x86_l_da7);
x86_l_d9d:
	/* 0xd9d: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_da1:
	/* 0xda1: jle    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xda1, 0xe54, x86_l_e54);
x86_l_da7:
	/* 0xda7: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_daa:
	/* 0xdaa: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdaa, 0xf02, x86_l_f02);
x86_l_db0:
	/* 0xdb0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_db2:
	/* 0xdb2: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_db6:
	/* 0xdb6: jg     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xdb6, 0xf04, x86_l_f04);
x86_l_dbc:
	/* 0xdbc: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_dc0:
	/* 0xdc0: jle    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xdc0, 0xe54, x86_l_e54);
x86_l_dc6:
	/* 0xdc6: jmp    f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xdc6, 0xf04, x86_l_f04);
x86_l_dcb:
	/* 0xdcb: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dce:
	/* 0xdce: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dd2:
	/* 0xdd2: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_dd6:
	/* 0xdd6: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_dda:
	/* 0xdda: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_ddd:
	/* 0xddd: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_de0:
	/* 0xde0: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_de3:
	/* 0xde3: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xde3, 0xf04, x86_l_f04);
x86_l_de9:
	/* 0xde9: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ded:
	/* 0xded: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_df1:
	/* 0xdf1: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_df5:
	/* 0xdf5: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_df9:
	/* 0xdf9: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_dfc:
	/* 0xdfc: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_dff:
	/* 0xdff: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_e02:
	/* 0xe02: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe02, 0xf04, x86_l_f04);
x86_l_e08:
	/* 0xe08: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e0c:
	/* 0xe0c: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e10:
	/* 0xe10: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e14:
	/* 0xe14: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e18:
	/* 0xe18: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e1b:
	/* 0xe1b: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e1e:
	/* 0xe1e: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_e21:
	/* 0xe21: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe21, 0xf04, x86_l_f04);
x86_l_e27:
	/* 0xe27: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e2b:
	/* 0xe2b: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e2e:
	/* 0xe2e: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e32:
	/* 0xe32: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e36:
	/* 0xe36: jmp    eb8 <filter_64ty_range+0x180> */
	X86_SIM_X86_SUB_JMP(0xe36, 0xeb8, x86_l_eb8);
x86_l_e3b:
	/* 0xe3b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e3e:
	/* 0xe3e: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_e41:
	/* 0xe41: jne    e55 <filter_64ty_range+0x11d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xe41, 0xe55, x86_l_e55);
x86_l_e43:
	/* 0xe43: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_e48:
	/* 0xe48: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e4c:
	/* 0xe4c: ja     ec0 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe4c, 0xec0, x86_l_ec0);
x86_l_e4e:
	/* 0xe4e: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e52:
	/* 0xe52: ja     ec0 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe52, 0xec0, x86_l_ec0);
x86_l_e54:
	/* 0xe54: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_e54);
x86_l_e55:
	/* 0xe55: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e58:
	/* 0xe58: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e5c:
	/* 0xe5c: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e60:
	/* 0xe60: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e64:
	/* 0xe64: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e67:
	/* 0xe67: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e6a:
	/* 0xe6a: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_e6d:
	/* 0xe6d: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe6d, 0xf04, x86_l_f04);
x86_l_e73:
	/* 0xe73: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e77:
	/* 0xe77: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e7b:
	/* 0xe7b: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e7f:
	/* 0xe7f: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e83:
	/* 0xe83: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e86:
	/* 0xe86: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e89:
	/* 0xe89: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_e8c:
	/* 0xe8c: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe8c, 0xf04, x86_l_f04);
x86_l_e8e:
	/* 0xe8e: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e92:
	/* 0xe92: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e96:
	/* 0xe96: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e9a:
	/* 0xe9a: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e9e:
	/* 0xe9e: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_ea1:
	/* 0xea1: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_ea4:
	/* 0xea4: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_ea7:
	/* 0xea7: jb     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xea7, 0xf04, x86_l_f04);
x86_l_ea9:
	/* 0xea9: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ead:
	/* 0xead: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_eb0:
	/* 0xeb0: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_eb4:
	/* 0xeb4: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_eb8:
	/* 0xeb8: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_ebb:
	/* 0xebb: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_ebe:
	/* 0xebe: jmp    f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xebe, 0xf04, x86_l_f04);
x86_l_ec0:
	/* 0xec0: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ec3:
	/* 0xec3: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_ec6:
	/* 0xec6: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xec6, 0xf02, x86_l_f02);
x86_l_ec8:
	/* 0xec8: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ecc:
	/* 0xecc: ja     ed4 <filter_64ty_range+0x19c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xecc, 0xed4, x86_l_ed4);
x86_l_ece:
	/* 0xece: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_ed2:
	/* 0xed2: jbe    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xed2, 0xe54, x86_l_e54);
x86_l_ed4:
	/* 0xed4: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_ed7:
	/* 0xed7: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xed7, 0xf02, x86_l_f02);
x86_l_ed9:
	/* 0xed9: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_edd:
	/* 0xedd: ja     ee9 <filter_64ty_range+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xedd, 0xee9, x86_l_ee9);
x86_l_edf:
	/* 0xedf: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_ee3:
	/* 0xee3: jbe    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xee3, 0xe54, x86_l_e54);
x86_l_ee9:
	/* 0xee9: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_eec:
	/* 0xeec: jb     f02 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xeec, 0xf02, x86_l_f02);
x86_l_eee:
	/* 0xeee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef0:
	/* 0xef0: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ef4:
	/* 0xef4: ja     f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xef4, 0xf04, x86_l_f04);
x86_l_ef6:
	/* 0xef6: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_efa:
	/* 0xefa: jbe    e54 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xefa, 0xe54, x86_l_e54);
x86_l_f00:
	/* 0xf00: jmp    f04 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xf00, 0xf04, x86_l_f04);
x86_l_f02:
	/* 0xf02: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f04:
	/* 0xf04: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_f07:
	/* 0xf07: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_f0a:
	/* 0xf0a: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_f0d:
	/* 0xf0d: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_f0f:
	/* 0xf0f: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_f12:
	/* 0xf12: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_e54);

	/* native subroutine native_link_sub_f13 */
x86_l_f13:
	/* 0xf13: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f15:
	/* 0xf15: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f16:
	/* 0xf16: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_f1a:
	/* 0xf1a: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f1d:
	/* 0xf1d: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f20:
	/* 0xf20: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_f24:
	/* 0xf24: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f28:
	/* 0xf28: mov    rdi,QWORD PTR [rip+0xbd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_f2f:
	/* 0xf2f: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f34:
	/* 0xf34: call   1b09 <filter_16ty_range+0x8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f39:
	/* 0xf39: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f3c:
	/* 0xf3c: je     f68 <filter_64ty_map+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf3c, 0xf68, x86_l_f68);
x86_l_f3e:
	/* 0xf3e: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f41:
	/* 0xf41: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f46:
	/* 0xf46: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f4b:
	/* 0xf4b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f4e:
	/* 0xf4e: call   1b23 <filter_16ty_range+0x22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f53:
	/* 0xf53: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f56:
	/* 0xf56: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_f59:
	/* 0xf59: je     f72 <filter_64ty_map+0x5f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf59, 0xf72, x86_l_f72);
x86_l_f5b:
	/* 0xf5b: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_f5e:
	/* 0xf5e: jne    f7a <filter_64ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xf5e, 0xf7a, x86_l_f7a);
x86_l_f60:
	/* 0xf60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f63:
	/* 0xf63: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_f66:
	/* 0xf66: jmp    f7c <filter_64ty_map+0x69> */
	X86_SIM_X86_SUB_JMP(0xf66, 0xf7c, x86_l_f7c);
x86_l_f68:
	/* 0xf68: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f6a:
	/* 0xf6a: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f6e:
	/* 0xf6e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f6f:
	/* 0xf6f: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f71:
	/* 0xf71: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f71);
x86_l_f72:
	/* 0xf72: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f75:
	/* 0xf75: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_f78:
	/* 0xf78: jmp    f7c <filter_64ty_map+0x69> */
	X86_SIM_X86_SUB_JMP(0xf78, 0xf7c, x86_l_f7c);
x86_l_f7a:
	/* 0xf7a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f7c:
	/* 0xf7c: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_f7f:
	/* 0xf7f: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f83:
	/* 0xf83: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f84:
	/* 0xf84: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f86:
	/* 0xf86: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f71);

	/* native subroutine native_link_sub_f87 */
x86_l_f87:
	/* 0xf87: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f89:
	/* 0xf89: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f8b:
	/* 0xf8b: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f8c:
	/* 0xf8c: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_f90:
	/* 0xf90: mov    ebx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_f92:
	/* 0xf92: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f95:
	/* 0xf95: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f99:
	/* 0xf99: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_fa1:
	/* 0xfa1: mov    rdi,QWORD PTR [rip+0x2720] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps));
x86_l_fa8:
	/* 0xfa8: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_fad:
	/* 0xfad: call   36d2 <filter_file_type+0x10f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fb2:
	/* 0xfb2: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fb5:
	/* 0xfb5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb7:
	/* 0xfb7: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_fb9:
	/* 0xfb9: je     10c0 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfb9, 0x10c0, x86_l_10c0);
x86_l_fbf:
	/* 0xfbf: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fc2:
	/* 0xfc2: je     10c0 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfc2, 0x10c0, x86_l_10c0);
x86_l_fc8:
	/* 0xfc8: mov    rdi,QWORD PTR [rip+0x2720] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_fcf:
	/* 0xfcf: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fd4:
	/* 0xfd4: call   36f9 <filter_file_type+0x111f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fd9:
	/* 0xfd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fdc:
	/* 0xfdc: je     10be <filter_char_buf_postfix+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfdc, 0x10be, x86_l_10be);
x86_l_fe2:
	/* 0xfe2: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_fe4:
	/* 0xfe4: cmp    ebx,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_fe7:
	/* 0xfe7: jb     fee <filter_char_buf_postfix+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xfe7, 0xfee, x86_l_fee);
x86_l_fe9:
	/* 0xfe9: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_fee:
	/* 0xfee: shl    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_ff1:
	/* 0xff1: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ff3:
	/* 0xff3: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_ff5:
	/* 0xff5: lea    edx,[rbx-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_ff8:
	/* 0xff8: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ffb:
	/* 0xffb: add    rsi,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_fff:
	/* 0xfff: lea    edi,[rbx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1002:
	/* 0x1002: lea    r8d,[rbx-0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1006:
	/* 0x1006: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1008:
	/* 0x1008: mov    r9,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_100f:
	/* 0x100f: lea    r10d,[rbx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1013:
	/* 0x1013: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1017:
	/* 0x1017: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_101e:
	/* 0x101e: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1023:
	/* 0x1023: mov    BYTE PTR [rsi-0x3],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1027:
	/* 0x1027: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_102b:
	/* 0x102b: cmp    r10,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_102f:
	/* 0x102f: je     10a6 <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x102f, 0x10a6, x86_l_10a6);
x86_l_1031:
	/* 0x1031: lea    r11d,[r8+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1035:
	/* 0x1035: add    r11d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1039:
	/* 0x1039: and    r11d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1040:
	/* 0x1040: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1045:
	/* 0x1045: mov    BYTE PTR [rsi-0x2],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1049:
	/* 0x1049: cmp    r10,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_104d:
	/* 0x104d: je     10a6 <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x104d, 0x10a6, x86_l_10a6);
x86_l_104f:
	/* 0x104f: lea    r10d,[rdi+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1053:
	/* 0x1053: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1057:
	/* 0x1057: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_105e:
	/* 0x105e: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1063:
	/* 0x1063: mov    BYTE PTR [rsi-0x1],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1067:
	/* 0x1067: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_106a:
	/* 0x106a: add    r10,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_106d:
	/* 0x106d: je     10a6 <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x106d, 0x10a6, x86_l_10a6);
x86_l_106f:
	/* 0x106f: cmp    r9,0xffffffffffffff81 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551489ULL);
x86_l_1073:
	/* 0x1073: je     10a6 <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1073, 0x10a6, x86_l_10a6);
x86_l_1075:
	/* 0x1075: lea    r10d,[rdx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1079:
	/* 0x1079: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_107d:
	/* 0x107d: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1084:
	/* 0x1084: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1089:
	/* 0x1089: mov    BYTE PTR [rsi],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_108c:
	/* 0x108c: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1090:
	/* 0x1090: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1094:
	/* 0x1094: add    r10,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_1098:
	/* 0x1098: add    r9,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_109c:
	/* 0x109c: cmp    r10,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_10a0:
	/* 0x10a0: jne    100f <filter_char_buf_postfix+0x88> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x10a0, 0x100f, x86_l_100f);
x86_l_10a6:
	/* 0x10a6: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10a9:
	/* 0x10a9: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10ac:
	/* 0x10ac: call   37d9 <filter_file_type+0x11ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10b1:
	/* 0x10b1: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10b4:
	/* 0x10b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b6:
	/* 0x10b6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10b9:
	/* 0x10b9: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_10bc:
	/* 0x10bc: jmp    10c0 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JMP(0x10bc, 0x10c0, x86_l_10c0);
x86_l_10be:
	/* 0x10be: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10c0:
	/* 0x10c0: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_10c4:
	/* 0x10c4: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10c5:
	/* 0x10c5: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10c7:
	/* 0x10c7: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10c9:
	/* 0x10c9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_10c9);

	/* native subroutine native_link_sub_10ca */
x86_l_10ca:
	/* 0x10ca: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_10cb:
	/* 0x10cb: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10cd:
	/* 0x10cd: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_10cf:
	/* 0x10cf: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10d0:
	/* 0x10d0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10d1:
	/* 0x10d1: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_10d3:
	/* 0x10d3: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10d6:
	/* 0x10d6: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10da:
	/* 0x10da: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e1:
	/* 0x10e1: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps));
x86_l_10e8:
	/* 0x10e8: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10ed:
	/* 0x10ed: call   36e2 <filter_file_type+0x1108> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10f2:
	/* 0x10f2: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10f5:
	/* 0x10f5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10f7:
	/* 0x10f7: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_10f9:
	/* 0x10f9: je     11e2 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10f9, 0x11e2, x86_l_11e2);
x86_l_10ff:
	/* 0x10ff: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1102:
	/* 0x1102: je     11e2 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1102, 0x11e2, x86_l_11e2);
x86_l_1108:
	/* 0x1108: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_110f:
	/* 0x110f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1112:
	/* 0x1112: call   3707 <filter_file_type+0x112d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1117:
	/* 0x1117: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_111a:
	/* 0x111a: je     117d <filter_char_buf_prefix+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x111a, 0x117d, x86_l_117d);
x86_l_111c:
	/* 0x111c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_111f:
	/* 0x111f: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1121:
	/* 0x1121: cmp    ebp,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_1127:
	/* 0x1127: jb     112e <filter_char_buf_prefix+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1127, 0x112e, x86_l_112e);
x86_l_1129:
	/* 0x1129: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_112e:
	/* 0x112e: lea    ecx,[rsi*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_1135:
	/* 0x1135: mov    DWORD PTR [r15],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1138:
	/* 0x1138: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_113c:
	/* 0x113c: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_113f:
	/* 0x113f: jns    1181 <filter_char_buf_prefix+0xb7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x113f, 0x1181, x86_l_1181);
x86_l_1141:
	/* 0x1141: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1144:
	/* 0x1144: jns    118e <filter_char_buf_prefix+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1144, 0x118e, x86_l_118e);
x86_l_1146:
	/* 0x1146: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1148:
	/* 0x1148: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_114b:
	/* 0x114b: jb     1169 <filter_char_buf_prefix+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x114b, 0x1169, x86_l_1169);
x86_l_114d:
	/* 0x114d: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_114f:
	/* 0x114f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1151:
	/* 0x1151: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1154:
	/* 0x1154: mov    rcx,QWORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1158:
	/* 0x1158: mov    QWORD PTR [rax+rdi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_115c:
	/* 0x115c: lea    rcx,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1160:
	/* 0x1160: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1164:
	/* 0x1164: cmp    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1167:
	/* 0x1167: jbe    1151 <filter_char_buf_prefix+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1167, 0x1151, x86_l_1151);
x86_l_1169:
	/* 0x1169: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_116d:
	/* 0x116d: jne    119c <filter_char_buf_prefix+0xd2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x116d, 0x119c, x86_l_119c);
x86_l_116f:
	/* 0x116f: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1173:
	/* 0x1173: jne    11ae <filter_char_buf_prefix+0xe4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1173, 0x11ae, x86_l_11ae);
x86_l_1175:
	/* 0x1175: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1179:
	/* 0x1179: jne    11c2 <filter_char_buf_prefix+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1179, 0x11c2, x86_l_11c2);
x86_l_117b:
	/* 0x117b: jmp    11cc <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x117b, 0x11cc, x86_l_11cc);
x86_l_117d:
	/* 0x117d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_117f:
	/* 0x117f: jmp    11e2 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JMP(0x117f, 0x11e2, x86_l_11e2);
x86_l_1181:
	/* 0x1181: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1184:
	/* 0x1184: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1187:
	/* 0x1187: call   3785 <filter_file_type+0x11ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_118c:
	/* 0x118c: jmp    11cc <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x118c, 0x11cc, x86_l_11cc);
x86_l_118e:
	/* 0x118e: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1190:
	/* 0x1190: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1193:
	/* 0x1193: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1195:
	/* 0x1195: call   3793 <filter_file_type+0x11b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_119a:
	/* 0x119a: jmp    11cc <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x119a, 0x11cc, x86_l_11cc);
x86_l_119c:
	/* 0x119c: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_119e:
	/* 0x119e: mov    edi,DWORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_11a2:
	/* 0x11a2: mov    DWORD PTR [rax+rdx*1],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_11a5:
	/* 0x11a5: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_11a8:
	/* 0x11a8: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11ac:
	/* 0x11ac: je     1175 <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11ac, 0x1175, x86_l_1175);
x86_l_11ae:
	/* 0x11ae: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_11b0:
	/* 0x11b0: movzx  edi,WORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_11b5:
	/* 0x11b5: mov    WORD PTR [rax+rdx*1],di */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_11b9:
	/* 0x11b9: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_11bc:
	/* 0x11bc: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_11c0:
	/* 0x11c0: je     11cc <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11c0, 0x11cc, x86_l_11cc);
x86_l_11c2:
	/* 0x11c2: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_11c4:
	/* 0x11c4: movzx  edx,BYTE PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_11c9:
	/* 0x11c9: mov    BYTE PTR [rax+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11cc:
	/* 0x11cc: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11cf:
	/* 0x11cf: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11d2:
	/* 0x11d2: call   37d0 <filter_file_type+0x11f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11d7:
	/* 0x11d7: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11da:
	/* 0x11da: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11dc:
	/* 0x11dc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11df:
	/* 0x11df: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_11e2:
	/* 0x11e2: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_11e6:
	/* 0x11e6: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11e7:
	/* 0x11e7: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11e9:
	/* 0x11e9: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11eb:
	/* 0x11eb: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11ec:
	/* 0x11ec: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_11ec);

	/* native subroutine native_link_sub_11ed */
x86_l_11ed:
	/* 0x11ed: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_11ee:
	/* 0x11ee: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11f0:
	/* 0x11f0: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_11f2:
	/* 0x11f2: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_11f4:
	/* 0x11f4: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11f6:
	/* 0x11f6: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11f7:
	/* 0x11f7: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11f8:
	/* 0x11f8: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ff:
	/* 0x11ff: cmp    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1205:
	/* 0x1205: ja     15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1205, 0x15ce, x86_l_15ce);
x86_l_120b:
	/* 0x120b: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_120e:
	/* 0x120e: cmp    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1213:
	/* 0x1213: ja     1263 <filter_char_buf_equal+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1213, 0x1263, x86_l_1263);
x86_l_1215:
	/* 0x1215: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1218:
	/* 0x1218: imul   ecx,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_121e:
	/* 0x121e: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_1221:
	/* 0x1221: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1224:
	/* 0x1224: lea    ecx,[rcx+rcx*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_1227:
	/* 0x1227: sub    al,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB, 0);
x86_l_1229:
	/* 0x1229: test   dx,dx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_16, 0, 0);
x86_l_122c:
	/* 0x122c: je     1237 <filter_char_buf_equal+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x122c, 0x1237, x86_l_1237);
x86_l_122e:
	/* 0x122e: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1230:
	/* 0x1230: mov    r15d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1233:
	/* 0x1233: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1235:
	/* 0x1235: je     1250 <filter_char_buf_equal+0x63> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1235, 0x1250, x86_l_1250);
x86_l_1237:
	/* 0x1237: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_123a:
	/* 0x123a: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_123c:
	/* 0x123c: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_123e:
	/* 0x123e: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1240:
	/* 0x1240: add    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_1243:
	/* 0x1243: movzx  r15d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1247:
	/* 0x1247: cmp    cx,0x78 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, 0, 120ULL);
x86_l_124b:
	/* 0x124b: ja     12a1 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x124b, 0x12a1, x86_l_12a1);
x86_l_124d:
	/* 0x124d: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1250:
	/* 0x1250: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1253:
	/* 0x1253: imul   ebp,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_1259:
	/* 0x1259: shr    ebp,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_125c:
	/* 0x125c: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_125e:
	/* 0x125e: jmp    12e7 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x125e, 0x12e7, x86_l_12e7);
x86_l_1263:
	/* 0x1263: mov    r15d,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1269:
	/* 0x1269: cmp    eax,0x101 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 257ULL);
x86_l_126e:
	/* 0x126e: jb     12a1 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x126e, 0x12a1, x86_l_12a1);
x86_l_1270:
	/* 0x1270: mov    r15d,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_1276:
	/* 0x1276: cmp    eax,0x201 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 513ULL);
x86_l_127b:
	/* 0x127b: jb     12a1 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x127b, 0x12a1, x86_l_12a1);
x86_l_127d:
	/* 0x127d: mov    r15d,0x400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_1283:
	/* 0x1283: cmp    eax,0x401 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1025ULL);
x86_l_1288:
	/* 0x1288: jb     12a1 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1288, 0x12a1, x86_l_12a1);
x86_l_128a:
	/* 0x128a: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_128d:
	/* 0x128d: cmp    eax,0x801 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2049ULL);
x86_l_1292:
	/* 0x1292: setae  r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1296:
	/* 0x1296: shl    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_129a:
	/* 0x129a: add    r15d,0x800 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_12a1:
	/* 0x12a1: lea    eax,[r15-0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_12a8:
	/* 0x12a8: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_12ae:
	/* 0x12ae: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_12b1:
	/* 0x12b1: jg     12c3 <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x12b1, 0x12c3, x86_l_12c3);
x86_l_12b3:
	/* 0x12b3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_12b5:
	/* 0x12b5: je     12db <filter_char_buf_equal+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12b5, 0x12db, x86_l_12db);
x86_l_12b7:
	/* 0x12b7: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12ba:
	/* 0x12ba: jne    12d4 <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x12ba, 0x12d4, x86_l_12d4);
x86_l_12bc:
	/* 0x12bc: mov    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_12c1:
	/* 0x12c1: jmp    12e7 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x12c1, 0x12e7, x86_l_12e7);
x86_l_12c3:
	/* 0x12c3: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_12c6:
	/* 0x12c6: je     12e2 <filter_char_buf_equal+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12c6, 0x12e2, x86_l_12e2);
x86_l_12c8:
	/* 0x12c8: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_12cb:
	/* 0x12cb: jne    12d4 <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x12cb, 0x12d4, x86_l_12d4);
x86_l_12cd:
	/* 0x12cd: mov    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_12d2:
	/* 0x12d2: jmp    12e7 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x12d2, 0x12e7, x86_l_12e7);
x86_l_12d4:
	/* 0x12d4: mov    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_12d9:
	/* 0x12d9: jmp    12e7 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x12d9, 0x12e7, x86_l_12e7);
x86_l_12db:
	/* 0x12db: mov    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_12e0:
	/* 0x12e0: jmp    12e7 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x12e0, 0x12e7, x86_l_12e7);
x86_l_12e2:
	/* 0x12e2: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_12e7:
	/* 0x12e7: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_12e9:
	/* 0x12e9: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_12ec:
	/* 0x12ec: mov    r12d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_12f1:
	/* 0x12f1: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_12f5:
	/* 0x12f5: je     15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12f5, 0x15ce, x86_l_15ce);
x86_l_12fb:
	/* 0x12fb: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_12fe:
	/* 0x12fe: mov    r13d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1301:
	/* 0x1301: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_heap));
x86_l_1308:
	/* 0x1308: mov    r14,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_130b:
	/* 0x130b: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_130e:
	/* 0x130e: call   3403 <filter_file_type+0xe29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1313:
	/* 0x1313: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_131a:
	/* 0x131a: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_131d:
	/* 0x131d: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1320:
	/* 0x1320: call   3415 <filter_file_type+0xe3b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1325:
	/* 0x1325: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1327:
	/* 0x1327: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_132a:
	/* 0x132a: je     15d0 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x132a, 0x15d0, x86_l_15d0);
x86_l_1330:
	/* 0x1330: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1333:
	/* 0x1333: je     15d0 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1333, 0x15d0, x86_l_15d0);
x86_l_1339:
	/* 0x1339: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_133c:
	/* 0x133c: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_133f:
	/* 0x133f: jg     139e <filter_char_buf_equal+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x133f, 0x139e, x86_l_139e);
x86_l_1341:
	/* 0x1341: mov    BYTE PTR [r14],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1344:
	/* 0x1344: lea    rdi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1348:
	/* 0x1348: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_134b:
	/* 0x134b: jns    13f4 <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x134b, 0x13f4, x86_l_13f4);
x86_l_1351:
	/* 0x1351: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1354:
	/* 0x1354: jns    1401 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1354, 0x1401, x86_l_1401);
x86_l_135a:
	/* 0x135a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_135c:
	/* 0x135c: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_135f:
	/* 0x135f: jb     137f <filter_char_buf_equal+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x135f, 0x137f, x86_l_137f);
x86_l_1361:
	/* 0x1361: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1364:
	/* 0x1364: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1367:
	/* 0x1367: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_136b:
	/* 0x136b: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_136f:
	/* 0x136f: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1373:
	/* 0x1373: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1377:
	/* 0x1377: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_137a:
	/* 0x137a: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_137d:
	/* 0x137d: jbe    1364 <filter_char_buf_equal+0x177> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x137d, 0x1364, x86_l_1364);
x86_l_137f:
	/* 0x137f: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1383:
	/* 0x1383: jne    15e2 <filter_char_buf_equal+0x3f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1383, 0x15e2, x86_l_15e2);
x86_l_1389:
	/* 0x1389: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_138d:
	/* 0x138d: jne    15fa <filter_char_buf_equal+0x40d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x138d, 0x15fa, x86_l_15fa);
x86_l_1393:
	/* 0x1393: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1397:
	/* 0x1397: je     1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1397, 0x1413, x86_l_1413);
x86_l_1399:
	/* 0x1399: jmp    1614 <filter_char_buf_equal+0x427> */
	X86_SIM_X86_SUB_JMP(0x1399, 0x1614, x86_l_1614);
x86_l_139e:
	/* 0x139e: mov    WORD PTR [r14],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13a2:
	/* 0x13a2: lea    rdi,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_13a6:
	/* 0x13a6: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13a9:
	/* 0x13a9: jns    13f4 <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13a9, 0x13f4, x86_l_13f4);
x86_l_13ab:
	/* 0x13ab: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13ae:
	/* 0x13ae: jns    1401 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13ae, 0x1401, x86_l_1401);
x86_l_13b0:
	/* 0x13b0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13b2:
	/* 0x13b2: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_13b5:
	/* 0x13b5: jb     13d5 <filter_char_buf_equal+0x1e8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x13b5, 0x13d5, x86_l_13d5);
x86_l_13b7:
	/* 0x13b7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13ba:
	/* 0x13ba: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_13bd:
	/* 0x13bd: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_13c1:
	/* 0x13c1: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_13c5:
	/* 0x13c5: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13c9:
	/* 0x13c9: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_13cd:
	/* 0x13cd: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13d0:
	/* 0x13d0: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_13d3:
	/* 0x13d3: jbe    13ba <filter_char_buf_equal+0x1cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x13d3, 0x13ba, x86_l_13ba);
x86_l_13d5:
	/* 0x13d5: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_13d9:
	/* 0x13d9: jne    1622 <filter_char_buf_equal+0x435> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x13d9, 0x1622, x86_l_1622);
x86_l_13df:
	/* 0x13df: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_13e3:
	/* 0x13e3: jne    163a <filter_char_buf_equal+0x44d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x13e3, 0x163a, x86_l_163a);
x86_l_13e9:
	/* 0x13e9: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_13ed:
	/* 0x13ed: je     1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13ed, 0x1413, x86_l_1413);
x86_l_13ef:
	/* 0x13ef: jmp    1654 <filter_char_buf_equal+0x467> */
	X86_SIM_X86_SUB_JMP(0x13ef, 0x1654, x86_l_1654);
x86_l_13f4:
	/* 0x13f4: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13f7:
	/* 0x13f7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13fa:
	/* 0x13fa: call   3502 <filter_file_type+0xf28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_13ff:
	/* 0x13ff: jmp    140d <filter_char_buf_equal+0x220> */
	X86_SIM_X86_SUB_JMP(0x13ff, 0x140d, x86_l_140d);
x86_l_1401:
	/* 0x1401: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1403:
	/* 0x1403: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1405:
	/* 0x1405: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1408:
	/* 0x1408: call   3510 <filter_file_type+0xf36> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_140d:
	/* 0x140d: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1410:
	/* 0x1410: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1413:
	/* 0x1413: sub    r15d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1416:
	/* 0x1416: jle    14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1416, 0x14ec, x86_l_14ec);
x86_l_141c:
	/* 0x141c: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_141e:
	/* 0x141e: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1421:
	/* 0x1421: add    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1424:
	/* 0x1424: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1427:
	/* 0x1427: and    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_142d:
	/* 0x142d: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_1430:
	/* 0x1430: jg     1489 <filter_char_buf_equal+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1430, 0x1489, x86_l_1489);
x86_l_1432:
	/* 0x1432: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1435:
	/* 0x1435: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1438:
	/* 0x1438: jns    14d9 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1438, 0x14d9, x86_l_14d9);
x86_l_143e:
	/* 0x143e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1441:
	/* 0x1441: jns    14e3 <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1441, 0x14e3, x86_l_14e3);
x86_l_1447:
	/* 0x1447: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1449:
	/* 0x1449: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_144c:
	/* 0x144c: jb     146a <filter_char_buf_equal+0x27d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x144c, 0x146a, x86_l_146a);
x86_l_144e:
	/* 0x144e: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1450:
	/* 0x1450: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1452:
	/* 0x1452: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1455:
	/* 0x1455: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1459:
	/* 0x1459: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_145d:
	/* 0x145d: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1461:
	/* 0x1461: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1465:
	/* 0x1465: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1468:
	/* 0x1468: jbe    1452 <filter_char_buf_equal+0x265> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1468, 0x1452, x86_l_1452);
x86_l_146a:
	/* 0x146a: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_146e:
	/* 0x146e: jne    1662 <filter_char_buf_equal+0x475> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x146e, 0x1662, x86_l_1662);
x86_l_1474:
	/* 0x1474: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1478:
	/* 0x1478: jne    1677 <filter_char_buf_equal+0x48a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1478, 0x1677, x86_l_1677);
x86_l_147e:
	/* 0x147e: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1482:
	/* 0x1482: je     14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1482, 0x14ec, x86_l_14ec);
x86_l_1484:
	/* 0x1484: jmp    168e <filter_char_buf_equal+0x4a1> */
	X86_SIM_X86_SUB_JMP(0x1484, 0x168e, x86_l_168e);
x86_l_1489:
	/* 0x1489: add    rdi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_148d:
	/* 0x148d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1490:
	/* 0x1490: jns    14d9 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1490, 0x14d9, x86_l_14d9);
x86_l_1492:
	/* 0x1492: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1495:
	/* 0x1495: jns    14e3 <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1495, 0x14e3, x86_l_14e3);
x86_l_1497:
	/* 0x1497: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1499:
	/* 0x1499: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_149c:
	/* 0x149c: jb     14ba <filter_char_buf_equal+0x2cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x149c, 0x14ba, x86_l_14ba);
x86_l_149e:
	/* 0x149e: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14a0:
	/* 0x14a0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14a2:
	/* 0x14a2: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14a5:
	/* 0x14a5: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_14a9:
	/* 0x14a9: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_14ad:
	/* 0x14ad: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14b1:
	/* 0x14b1: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14b5:
	/* 0x14b5: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14b8:
	/* 0x14b8: jbe    14a2 <filter_char_buf_equal+0x2b5> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x14b8, 0x14a2, x86_l_14a2);
x86_l_14ba:
	/* 0x14ba: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_14be:
	/* 0x14be: jne    169c <filter_char_buf_equal+0x4af> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14be, 0x169c, x86_l_169c);
x86_l_14c4:
	/* 0x14c4: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_14c8:
	/* 0x14c8: jne    16b1 <filter_char_buf_equal+0x4c4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14c8, 0x16b1, x86_l_16b1);
x86_l_14ce:
	/* 0x14ce: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_14d2:
	/* 0x14d2: je     14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14d2, 0x14ec, x86_l_14ec);
x86_l_14d4:
	/* 0x14d4: jmp    16c8 <filter_char_buf_equal+0x4db> */
	X86_SIM_X86_SUB_JMP(0x14d4, 0x16c8, x86_l_16c8);
x86_l_14d9:
	/* 0x14d9: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14dc:
	/* 0x14dc: call   35e4 <filter_file_type+0x100a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14e1:
	/* 0x14e1: jmp    14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x14e1, 0x14ec, x86_l_14ec);
x86_l_14e3:
	/* 0x14e3: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14e5:
	/* 0x14e5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e7:
	/* 0x14e7: call   35ef <filter_file_type+0x1015> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_14ec:
	/* 0x14ec: mov    DWORD PTR [rsp+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14f1:
	/* 0x14f1: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14f4:
	/* 0x14f4: jle    151e <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x14f4, 0x151e, x86_l_151e);
x86_l_14f6:
	/* 0x14f6: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_14f9:
	/* 0x14f9: jg     153f <filter_char_buf_equal+0x352> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x14f9, 0x153f, x86_l_153f);
x86_l_14fb:
	/* 0x14fb: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_14fe:
	/* 0x14fe: je     159a <filter_char_buf_equal+0x3ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14fe, 0x159a, x86_l_159a);
x86_l_1504:
	/* 0x1504: cmp    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1507:
	/* 0x1507: je     157f <filter_char_buf_equal+0x392> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1507, 0x157f, x86_l_157f);
x86_l_1509:
	/* 0x1509: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_150c:
	/* 0x150c: jne    15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x150c, 0x15ce, x86_l_15ce);
x86_l_1512:
	/* 0x1512: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_7));
x86_l_1519:
	/* 0x1519: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1519, 0x15aa, x86_l_15aa);
x86_l_151e:
	/* 0x151e: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1521:
	/* 0x1521: jle    155b <filter_char_buf_equal+0x36e> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1521, 0x155b, x86_l_155b);
x86_l_1523:
	/* 0x1523: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1526:
	/* 0x1526: je     1591 <filter_char_buf_equal+0x3a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1526, 0x1591, x86_l_1591);
x86_l_1528:
	/* 0x1528: cmp    ebp,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_152b:
	/* 0x152b: je     1576 <filter_char_buf_equal+0x389> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x152b, 0x1576, x86_l_1576);
x86_l_152d:
	/* 0x152d: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1530:
	/* 0x1530: jne    15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1530, 0x15ce, x86_l_15ce);
x86_l_1536:
	/* 0x1536: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_4));
x86_l_153d:
	/* 0x153d: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x153d, 0x15aa, x86_l_15aa);
x86_l_153f:
	/* 0x153f: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1542:
	/* 0x1542: je     15a3 <filter_char_buf_equal+0x3b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1542, 0x15a3, x86_l_15a3);
x86_l_1544:
	/* 0x1544: cmp    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1547:
	/* 0x1547: je     1588 <filter_char_buf_equal+0x39b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1547, 0x1588, x86_l_1588);
x86_l_1549:
	/* 0x1549: cmp    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_154c:
	/* 0x154c: jne    15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x154c, 0x15ce, x86_l_15ce);
x86_l_1552:
	/* 0x1552: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_10));
x86_l_1559:
	/* 0x1559: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1559, 0x15aa, x86_l_15aa);
x86_l_155b:
	/* 0x155b: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_155d:
	/* 0x155d: je     156d <filter_char_buf_equal+0x380> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x155d, 0x156d, x86_l_156d);
x86_l_155f:
	/* 0x155f: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1562:
	/* 0x1562: jne    15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1562, 0x15ce, x86_l_15ce);
x86_l_1564:
	/* 0x1564: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_1));
x86_l_156b:
	/* 0x156b: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x156b, 0x15aa, x86_l_15aa);
x86_l_156d:
	/* 0x156d: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_0));
x86_l_1574:
	/* 0x1574: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1574, 0x15aa, x86_l_15aa);
x86_l_1576:
	/* 0x1576: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_3));
x86_l_157d:
	/* 0x157d: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x157d, 0x15aa, x86_l_15aa);
x86_l_157f:
	/* 0x157f: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_6));
x86_l_1586:
	/* 0x1586: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1586, 0x15aa, x86_l_15aa);
x86_l_1588:
	/* 0x1588: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_9));
x86_l_158f:
	/* 0x158f: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x158f, 0x15aa, x86_l_15aa);
x86_l_1591:
	/* 0x1591: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_2));
x86_l_1598:
	/* 0x1598: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1598, 0x15aa, x86_l_15aa);
x86_l_159a:
	/* 0x159a: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_5));
x86_l_15a1:
	/* 0x15a1: jmp    15aa <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x15a1, 0x15aa, x86_l_15aa);
x86_l_15a3:
	/* 0x15a3: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_8));
x86_l_15aa:
	/* 0x15aa: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_15af:
	/* 0x15af: call   36b3 <filter_file_type+0x10d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15b4:
	/* 0x15b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15b7:
	/* 0x15b7: je     15ce <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15b7, 0x15ce, x86_l_15ce);
x86_l_15b9:
	/* 0x15b9: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15bc:
	/* 0x15bc: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_15bf:
	/* 0x15bf: call   36c3 <filter_file_type+0x10e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15c4:
	/* 0x15c4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c6:
	/* 0x15c6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15c9:
	/* 0x15c9: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_15cc:
	/* 0x15cc: jmp    15d0 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JMP(0x15cc, 0x15d0, x86_l_15d0);
x86_l_15ce:
	/* 0x15ce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15d0:
	/* 0x15d0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15d3:
	/* 0x15d3: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_15d7:
	/* 0x15d7: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15d8:
	/* 0x15d8: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15da:
	/* 0x15da: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15dc:
	/* 0x15dc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15de:
	/* 0x15de: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15e0:
	/* 0x15e0: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_15e1:
	/* 0x15e1: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_15e1);
x86_l_15e2:
	/* 0x15e2: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15e5:
	/* 0x15e5: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15e9:
	/* 0x15e9: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15ed:
	/* 0x15ed: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_15f0:
	/* 0x15f0: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_15f4:
	/* 0x15f4: je     1393 <filter_char_buf_equal+0x1a6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15f4, 0x1393, x86_l_1393);
x86_l_15fa:
	/* 0x15fa: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15fd:
	/* 0x15fd: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_1602:
	/* 0x1602: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1607:
	/* 0x1607: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_160a:
	/* 0x160a: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_160e:
	/* 0x160e: je     1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x160e, 0x1413, x86_l_1413);
x86_l_1614:
	/* 0x1614: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1616:
	/* 0x1616: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_161a:
	/* 0x161a: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_161d:
	/* 0x161d: jmp    1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x161d, 0x1413, x86_l_1413);
x86_l_1622:
	/* 0x1622: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1625:
	/* 0x1625: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1629:
	/* 0x1629: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_162d:
	/* 0x162d: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1630:
	/* 0x1630: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1634:
	/* 0x1634: je     13e9 <filter_char_buf_equal+0x1fc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1634, 0x13e9, x86_l_13e9);
x86_l_163a:
	/* 0x163a: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_163d:
	/* 0x163d: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_1642:
	/* 0x1642: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1647:
	/* 0x1647: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_164a:
	/* 0x164a: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_164e:
	/* 0x164e: je     1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x164e, 0x1413, x86_l_1413);
x86_l_1654:
	/* 0x1654: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1656:
	/* 0x1656: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_165a:
	/* 0x165a: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_165d:
	/* 0x165d: jmp    1413 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x165d, 0x1413, x86_l_1413);
x86_l_1662:
	/* 0x1662: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1664:
	/* 0x1664: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1667:
	/* 0x1667: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_166a:
	/* 0x166a: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_166d:
	/* 0x166d: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1671:
	/* 0x1671: je     147e <filter_char_buf_equal+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1671, 0x147e, x86_l_147e);
x86_l_1677:
	/* 0x1677: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1679:
	/* 0x1679: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_167d:
	/* 0x167d: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1681:
	/* 0x1681: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1684:
	/* 0x1684: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1688:
	/* 0x1688: je     14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1688, 0x14ec, x86_l_14ec);
x86_l_168e:
	/* 0x168e: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1690:
	/* 0x1690: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1694:
	/* 0x1694: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1697:
	/* 0x1697: jmp    14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x1697, 0x14ec, x86_l_14ec);
x86_l_169c:
	/* 0x169c: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_169e:
	/* 0x169e: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_16a1:
	/* 0x16a1: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_16a4:
	/* 0x16a4: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_16a7:
	/* 0x16a7: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_16ab:
	/* 0x16ab: je     14ce <filter_char_buf_equal+0x2e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16ab, 0x14ce, x86_l_14ce);
x86_l_16b1:
	/* 0x16b1: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16b3:
	/* 0x16b3: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_16b7:
	/* 0x16b7: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_16bb:
	/* 0x16bb: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_16be:
	/* 0x16be: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_16c2:
	/* 0x16c2: je     14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16c2, 0x14ec, x86_l_14ec);
x86_l_16c8:
	/* 0x16c8: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16ca:
	/* 0x16ca: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_16ce:
	/* 0x16ce: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_16d1:
	/* 0x16d1: jmp    14ec <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x16d1, 0x14ec, x86_l_14ec);

	/* native subroutine native_link_sub_16d6 */
x86_l_16d6:
	/* 0x16d6: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_16d7:
	/* 0x16d7: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_16d9:
	/* 0x16d9: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_16db:
	/* 0x16db: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_16dd:
	/* 0x16dd: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_16df:
	/* 0x16df: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16e0:
	/* 0x16e0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e1:
	/* 0x16e1: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16e4:
	/* 0x16e4: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16e7:
	/* 0x16e7: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_16e9:
	/* 0x16e9: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16eb:
	/* 0x16eb: je     17b8 <filter_char_substring+0xe2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16eb, 0x17b8, x86_l_17b8);
x86_l_16f1:
	/* 0x16f1: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_16f3:
	/* 0x16f3: je     184f <filter_char_substring+0x179> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16f3, 0x184f, x86_l_184f);
x86_l_16f9:
	/* 0x16f9: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16fe:
	/* 0x16fe: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1700:
	/* 0x1700: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1703:
	/* 0x1703: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1708:
	/* 0x1708: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_170c:
	/* 0x170c: mov    rdi,QWORD PTR [rip+0x2933] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_1713:
	/* 0x1713: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1716:
	/* 0x1716: call   404e <filter_file_type+0x1a74> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_171b:
	/* 0x171b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_171e:
	/* 0x171e: je     18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x171e, 0x18cf, x86_l_18cf);
x86_l_1724:
	/* 0x1724: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1727:
	/* 0x1727: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1729:
	/* 0x1729: jmp    1736 <filter_char_substring+0x60> */
	X86_SIM_X86_SUB_JMP(0x1729, 0x1736, x86_l_1736);
x86_l_172b:
	/* 0x172b: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_172e:
	/* 0x172e: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1731:
	/* 0x1731: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1734:
	/* 0x1734: je     1793 <filter_char_substring+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1734, 0x1793, x86_l_1793);
x86_l_1736:
	/* 0x1736: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1738:
	/* 0x1738: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_173c:
	/* 0x173c: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_173f:
	/* 0x173f: jae    172b <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x173f, 0x172b, x86_l_172b);
x86_l_1741:
	/* 0x1741: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1745:
	/* 0x1745: test   edi,edi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1747:
	/* 0x1747: je     178b <filter_char_substring+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1747, 0x178b, x86_l_178b);
x86_l_1749:
	/* 0x1749: movsx  r8d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_174e:
	/* 0x174e: lea    r9d,[r8-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_1752:
	/* 0x1752: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_1756:
	/* 0x1756: jb     176a <filter_char_substring+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1756, 0x176a, x86_l_176a);
x86_l_1758:
	/* 0x1758: lea    r9d,[rdi-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_175c:
	/* 0x175c: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_1760:
	/* 0x1760: jb     1778 <filter_char_substring+0xa2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1760, 0x1778, x86_l_1778);
x86_l_1762:
	/* 0x1762: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_1766:
	/* 0x1766: jbe    1781 <filter_char_substring+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1766, 0x1781, x86_l_1781);
x86_l_1768:
	/* 0x1768: jmp    172b <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JMP(0x1768, 0x172b, x86_l_172b);
x86_l_176a:
	/* 0x176a: or     r8d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_176e:
	/* 0x176e: lea    r9d,[rdi-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_1772:
	/* 0x1772: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_1776:
	/* 0x1776: jae    1762 <filter_char_substring+0x8c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1776, 0x1762, x86_l_1762);
x86_l_1778:
	/* 0x1778: or     edi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_177b:
	/* 0x177b: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_177f:
	/* 0x177f: ja     172b <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x177f, 0x172b, x86_l_172b);
x86_l_1781:
	/* 0x1781: inc    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1784:
	/* 0x1784: cmp    r8d,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1787:
	/* 0x1787: je     1738 <filter_char_substring+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1787, 0x1738, x86_l_1738);
x86_l_1789:
	/* 0x1789: jmp    172b <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JMP(0x1789, 0x172b, x86_l_172b);
x86_l_178b:
	/* 0x178b: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_178d:
	/* 0x178d: jns    18e0 <filter_char_substring+0x20a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x178d, 0x18e0, x86_l_18e0);
x86_l_1793:
	/* 0x1793: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1798:
	/* 0x1798: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_179c:
	/* 0x179c: jae    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x179c, 0x18cf, x86_l_18cf);
x86_l_17a2:
	/* 0x17a2: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_17a6:
	/* 0x17a6: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17a9:
	/* 0x17a9: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_17ad:
	/* 0x17ad: jne    1703 <filter_char_substring+0x2d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x17ad, 0x1703, x86_l_1703);
x86_l_17b3:
	/* 0x17b3: jmp    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x17b3, 0x18cf, x86_l_18cf);
x86_l_17b8:
	/* 0x17b8: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17ba:
	/* 0x17ba: je     1890 <filter_char_substring+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17ba, 0x1890, x86_l_1890);
x86_l_17c0:
	/* 0x17c0: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17c5:
	/* 0x17c5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17c7:
	/* 0x17c7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17ca:
	/* 0x17ca: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_17cf:
	/* 0x17cf: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17d3:
	/* 0x17d3: mov    rdi,QWORD PTR [rip+0x295c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_17da:
	/* 0x17da: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17dd:
	/* 0x17dd: call   413e <filter_file_type+0x1b64> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17e2:
	/* 0x17e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17e5:
	/* 0x17e5: je     18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17e5, 0x18cf, x86_l_18cf);
x86_l_17eb:
	/* 0x17eb: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_17ee:
	/* 0x17ee: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f0:
	/* 0x17f0: jmp    17fd <filter_char_substring+0x127> */
	X86_SIM_X86_SUB_JMP(0x17f0, 0x17fd, x86_l_17fd);
x86_l_17f2:
	/* 0x17f2: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17f5:
	/* 0x17f5: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17f8:
	/* 0x17f8: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_17fb:
	/* 0x17fb: je     182e <filter_char_substring+0x158> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17fb, 0x182e, x86_l_182e);
x86_l_17fd:
	/* 0x17fd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17ff:
	/* 0x17ff: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1803:
	/* 0x1803: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1806:
	/* 0x1806: jae    17f2 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1806, 0x17f2, x86_l_17f2);
x86_l_1808:
	/* 0x1808: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_180c:
	/* 0x180c: test   dil,dil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8, 0, 0);
x86_l_180f:
	/* 0x180f: je     1826 <filter_char_substring+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x180f, 0x1826, x86_l_1826);
x86_l_1811:
	/* 0x1811: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_1815:
	/* 0x1815: ja     17f2 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1815, 0x17f2, x86_l_17f2);
x86_l_1817:
	/* 0x1817: lea    r8,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_181b:
	/* 0x181b: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_181f:
	/* 0x181f: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1822:
	/* 0x1822: je     17ff <filter_char_substring+0x129> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1822, 0x17ff, x86_l_17ff);
x86_l_1824:
	/* 0x1824: jmp    17f2 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JMP(0x1824, 0x17f2, x86_l_17f2);
x86_l_1826:
	/* 0x1826: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1828:
	/* 0x1828: jns    18e0 <filter_char_substring+0x20a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1828, 0x18e0, x86_l_18e0);
x86_l_182e:
	/* 0x182e: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1833:
	/* 0x1833: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1837:
	/* 0x1837: jae    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1837, 0x18cf, x86_l_18cf);
x86_l_183d:
	/* 0x183d: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_1841:
	/* 0x1841: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1844:
	/* 0x1844: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_1848:
	/* 0x1848: jne    17ca <filter_char_substring+0xf4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1848, 0x17ca, x86_l_17ca);
x86_l_184a:
	/* 0x184a: jmp    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x184a, 0x18cf, x86_l_18cf);
x86_l_184f:
	/* 0x184f: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1854:
	/* 0x1854: mov    r15,QWORD PTR [rip+0x2974] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_185b:
	/* 0x185b: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1860:
	/* 0x1860: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1864:
	/* 0x1864: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1868:
	/* 0x1868: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_186b:
	/* 0x186b: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_186e:
	/* 0x186e: call   41e9 <filter_file_type+0x1c0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1873:
	/* 0x1873: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1876:
	/* 0x1876: je     18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1876, 0x18cf, x86_l_18cf);
x86_l_1878:
	/* 0x1878: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_187c:
	/* 0x187c: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_187f:
	/* 0x187f: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1883:
	/* 0x1883: jae    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1883, 0x18cf, x86_l_18cf);
x86_l_1885:
	/* 0x1885: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_188c:
	/* 0x188c: jne    1860 <filter_char_substring+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x188c, 0x1860, x86_l_1860);
x86_l_188e:
	/* 0x188e: jmp    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x188e, 0x18cf, x86_l_18cf);
x86_l_1890:
	/* 0x1890: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1895:
	/* 0x1895: mov    r15,QWORD PTR [rip+0x2976] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_189c:
	/* 0x189c: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18a1:
	/* 0x18a1: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_18a5:
	/* 0x18a5: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18a9:
	/* 0x18a9: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_18ac:
	/* 0x18ac: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18af:
	/* 0x18af: call   4239 <filter_file_type+0x1c5f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_18b4:
	/* 0x18b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18b7:
	/* 0x18b7: je     18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18b7, 0x18cf, x86_l_18cf);
x86_l_18b9:
	/* 0x18b9: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_18bd:
	/* 0x18bd: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_18c0:
	/* 0x18c0: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_18c4:
	/* 0x18c4: jae    18cf <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18c4, 0x18cf, x86_l_18cf);
x86_l_18c6:
	/* 0x18c6: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_18cd:
	/* 0x18cd: jne    18a1 <filter_char_substring+0x1cb> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18cd, 0x18a1, x86_l_18a1);
x86_l_18cf:
	/* 0x18cf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18d1:
	/* 0x18d1: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_18d5:
	/* 0x18d5: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18d6:
	/* 0x18d6: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18d8:
	/* 0x18d8: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18da:
	/* 0x18da: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18dc:
	/* 0x18dc: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18de:
	/* 0x18de: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_18df:
	/* 0x18df: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_18df);
x86_l_18e0:
	/* 0x18e0: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_18e5:
	/* 0x18e5: jmp    18d1 <filter_char_substring+0x1fb> */
	X86_SIM_X86_SUB_JMP(0x18e5, 0x18d1, x86_l_18d1);

	/* native subroutine native_link_sub_18e7 */
x86_l_18e7:
	/* 0x18e7: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18ea:
	/* 0x18ea: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_18ef:
	/* 0x18ef: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_18f3:
	/* 0x18f3: ja     1966 <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x18f3, 0x1966, x86_l_1966);
x86_l_18f5:
	/* 0x18f5: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_18ff:
	/* 0x18ff: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1903:
	/* 0x1903: jae    1906 <filter_16ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1903, 0x1906, x86_l_1906);
x86_l_1905:
	/* 0x1905: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1905);
x86_l_1906:
	/* 0x1906: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_190b:
	/* 0x190b: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_190f:
	/* 0x190f: jae    1926 <filter_16ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x190f, 0x1926, x86_l_1926);
x86_l_1911:
	/* 0x1911: movzx  edx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1914:
	/* 0x1914: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1917:
	/* 0x1917: jne    1a3c <filter_16ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1917, 0x1a3c, x86_l_1a3c);
x86_l_191d:
	/* 0x191d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_191f:
	/* 0x191f: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1922:
	/* 0x1922: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1925:
	/* 0x1925: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1905);
x86_l_1926:
	/* 0x1926: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_192a:
	/* 0x192a: jne    1966 <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x192a, 0x1966, x86_l_1966);
x86_l_192c:
	/* 0x192c: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_192f:
	/* 0x192f: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1932:
	/* 0x1932: jne    1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1932, 0x1905, x86_l_1905);
x86_l_1934:
	/* 0x1934: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1937:
	/* 0x1937: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_193a:
	/* 0x193a: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x193a, 0x1afe, x86_l_1afe);
x86_l_1940:
	/* 0x1940: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1943:
	/* 0x1943: jne    1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1943, 0x1905, x86_l_1905);
x86_l_1945:
	/* 0x1945: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1948:
	/* 0x1948: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1948, 0x1afe, x86_l_1afe);
x86_l_194e:
	/* 0x194e: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1951:
	/* 0x1951: jne    1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1951, 0x1905, x86_l_1905);
x86_l_1953:
	/* 0x1953: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1956:
	/* 0x1956: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1956, 0x1afe, x86_l_1afe);
x86_l_195c:
	/* 0x195c: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_195f:
	/* 0x195f: jne    1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x195f, 0x1905, x86_l_1905);
x86_l_1961:
	/* 0x1961: jmp    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1961, 0x1afe, x86_l_1afe);
x86_l_1966:
	/* 0x1966: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1969:
	/* 0x1969: je     19d8 <filter_16ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1969, 0x19d8, x86_l_19d8);
x86_l_196b:
	/* 0x196b: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_196e:
	/* 0x196e: jne    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x196e, 0x1afe, x86_l_1afe);
x86_l_1974:
	/* 0x1974: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1977:
	/* 0x1977: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_197a:
	/* 0x197a: ja     1ac5 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x197a, 0x1ac5, x86_l_1ac5);
x86_l_1980:
	/* 0x1980: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1985:
	/* 0x1985: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1988:
	/* 0x1988: jae    1ac5 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1988, 0x1ac5, x86_l_1ac5);
x86_l_198e:
	/* 0x198e: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1991:
	/* 0x1991: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1994:
	/* 0x1994: jg     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1994, 0x1905, x86_l_1905);
x86_l_199a:
	/* 0x199a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_199d:
	/* 0x199d: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_19a0:
	/* 0x19a0: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19a0, 0x1afe, x86_l_1afe);
x86_l_19a6:
	/* 0x19a6: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19a9:
	/* 0x19a9: jg     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x19a9, 0x1905, x86_l_1905);
x86_l_19af:
	/* 0x19af: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_19b2:
	/* 0x19b2: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19b2, 0x1afe, x86_l_1afe);
x86_l_19b8:
	/* 0x19b8: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19bb:
	/* 0x19bb: jg     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x19bb, 0x1905, x86_l_1905);
x86_l_19c1:
	/* 0x19c1: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_19c4:
	/* 0x19c4: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19c4, 0x1afe, x86_l_1afe);
x86_l_19ca:
	/* 0x19ca: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_19cd:
	/* 0x19cd: jg     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x19cd, 0x1905, x86_l_1905);
x86_l_19d3:
	/* 0x19d3: jmp    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x19d3, 0x1afe, x86_l_1afe);
x86_l_19d8:
	/* 0x19d8: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_19db:
	/* 0x19db: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_19de:
	/* 0x19de: ja     1a8a <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x19de, 0x1a8a, x86_l_1a8a);
x86_l_19e4:
	/* 0x19e4: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_19e9:
	/* 0x19e9: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_19ec:
	/* 0x19ec: jae    1a8a <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x19ec, 0x1a8a, x86_l_1a8a);
x86_l_19f2:
	/* 0x19f2: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_19f5:
	/* 0x19f5: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19f8:
	/* 0x19f8: jl     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19f8, 0x1905, x86_l_1905);
x86_l_19fe:
	/* 0x19fe: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a01:
	/* 0x1a01: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a04:
	/* 0x1a04: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a04, 0x1afe, x86_l_1afe);
x86_l_1a0a:
	/* 0x1a0a: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a0d:
	/* 0x1a0d: jl     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1a0d, 0x1905, x86_l_1905);
x86_l_1a13:
	/* 0x1a13: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a16:
	/* 0x1a16: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a16, 0x1afe, x86_l_1afe);
x86_l_1a1c:
	/* 0x1a1c: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a1f:
	/* 0x1a1f: jl     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1a1f, 0x1905, x86_l_1905);
x86_l_1a25:
	/* 0x1a25: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a28:
	/* 0x1a28: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a28, 0x1afe, x86_l_1afe);
x86_l_1a2e:
	/* 0x1a2e: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a31:
	/* 0x1a31: jl     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1a31, 0x1905, x86_l_1905);
x86_l_1a37:
	/* 0x1a37: jmp    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1a37, 0x1afe, x86_l_1afe);
x86_l_1a3c:
	/* 0x1a3c: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3f:
	/* 0x1a3f: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a42:
	/* 0x1a42: jb     1a69 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a42, 0x1a69, x86_l_1a69);
x86_l_1a44:
	/* 0x1a44: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a47:
	/* 0x1a47: je     191d <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a47, 0x191d, x86_l_191d);
x86_l_1a4d:
	/* 0x1a4d: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a50:
	/* 0x1a50: jb     1a69 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a50, 0x1a69, x86_l_1a69);
x86_l_1a52:
	/* 0x1a52: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a55:
	/* 0x1a55: je     191d <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a55, 0x191d, x86_l_191d);
x86_l_1a5b:
	/* 0x1a5b: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a5e:
	/* 0x1a5e: jb     1a69 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a5e, 0x1a69, x86_l_1a69);
x86_l_1a60:
	/* 0x1a60: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a63:
	/* 0x1a63: je     191d <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a63, 0x191d, x86_l_191d);
x86_l_1a69:
	/* 0x1a69: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1a6c:
	/* 0x1a6c: ja     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a6c, 0x1afe, x86_l_1afe);
x86_l_1a72:
	/* 0x1a72: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1a74:
	/* 0x1a74: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1a7e:
	/* 0x1a7e: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a82:
	/* 0x1a82: jb     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a82, 0x1905, x86_l_1905);
x86_l_1a88:
	/* 0x1a88: jmp    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1a88, 0x1afe, x86_l_1afe);
x86_l_1a8a:
	/* 0x1a8a: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a8d:
	/* 0x1a8d: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a90:
	/* 0x1a90: jb     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a90, 0x1905, x86_l_1905);
x86_l_1a96:
	/* 0x1a96: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a99:
	/* 0x1a99: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a9c:
	/* 0x1a9c: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a9c, 0x1afe, x86_l_1afe);
x86_l_1a9e:
	/* 0x1a9e: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1aa1:
	/* 0x1aa1: jb     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1aa1, 0x1905, x86_l_1905);
x86_l_1aa7:
	/* 0x1aa7: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1aaa:
	/* 0x1aaa: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1aaa, 0x1afe, x86_l_1afe);
x86_l_1aac:
	/* 0x1aac: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1aaf:
	/* 0x1aaf: jb     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1aaf, 0x1905, x86_l_1905);
x86_l_1ab5:
	/* 0x1ab5: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1ab8:
	/* 0x1ab8: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ab8, 0x1afe, x86_l_1afe);
x86_l_1aba:
	/* 0x1aba: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1abd:
	/* 0x1abd: jb     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1abd, 0x1905, x86_l_1905);
x86_l_1ac3:
	/* 0x1ac3: jmp    1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1ac3, 0x1afe, x86_l_1afe);
x86_l_1ac5:
	/* 0x1ac5: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ac8:
	/* 0x1ac8: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1acb:
	/* 0x1acb: ja     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1acb, 0x1905, x86_l_1905);
x86_l_1ad1:
	/* 0x1ad1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ad4:
	/* 0x1ad4: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ad7:
	/* 0x1ad7: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ad7, 0x1afe, x86_l_1afe);
x86_l_1ad9:
	/* 0x1ad9: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1adc:
	/* 0x1adc: ja     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1adc, 0x1905, x86_l_1905);
x86_l_1ae2:
	/* 0x1ae2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ae5:
	/* 0x1ae5: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ae5, 0x1afe, x86_l_1afe);
x86_l_1ae7:
	/* 0x1ae7: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1aea:
	/* 0x1aea: ja     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1aea, 0x1905, x86_l_1905);
x86_l_1af0:
	/* 0x1af0: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1af3:
	/* 0x1af3: jb     1afe <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1af3, 0x1afe, x86_l_1afe);
x86_l_1af5:
	/* 0x1af5: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1af8:
	/* 0x1af8: ja     1905 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1af8, 0x1905, x86_l_1905);
x86_l_1afe:
	/* 0x1afe: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b00:
	/* 0x1b00: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1905);

	/* native subroutine native_link_sub_1b01 */
x86_l_1b01:
	/* 0x1b01: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b04:
	/* 0x1b04: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1b07:
	/* 0x1b07: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1b0a:
	/* 0x1b0a: ja     1bf1 <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1b0a, 0x1bf1, x86_l_1bf1);
x86_l_1b10:
	/* 0x1b10: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1b15:
	/* 0x1b15: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b18:
	/* 0x1b18: jae    1bf1 <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1b18, 0x1bf1, x86_l_1bf1);
x86_l_1b1e:
	/* 0x1b1e: movsx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b21:
	/* 0x1b21: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1b24:
	/* 0x1b24: jne    1b8c <filter_16ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1b24, 0x1b8c, x86_l_1b8c);
x86_l_1b26:
	/* 0x1b26: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1b2b:
	/* 0x1b2b: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b2e:
	/* 0x1b2e: jg     1b39 <filter_16ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b2e, 0x1b39, x86_l_1b39);
x86_l_1b30:
	/* 0x1b30: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b33:
	/* 0x1b33: jge    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b33, 0x1c08, x86_l_1c08);
x86_l_1b39:
	/* 0x1b39: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b3c:
	/* 0x1b3c: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1b3f:
	/* 0x1b3f: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b3f, 0x1ca8, x86_l_1ca8);
x86_l_1b45:
	/* 0x1b45: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b48:
	/* 0x1b48: jg     1b53 <filter_16ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b48, 0x1b53, x86_l_1b53);
x86_l_1b4a:
	/* 0x1b4a: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b4d:
	/* 0x1b4d: jge    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b4d, 0x1c08, x86_l_1c08);
x86_l_1b53:
	/* 0x1b53: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1b56:
	/* 0x1b56: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b56, 0x1ca8, x86_l_1ca8);
x86_l_1b5c:
	/* 0x1b5c: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b5f:
	/* 0x1b5f: jg     1b6a <filter_16ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b5f, 0x1b6a, x86_l_1b6a);
x86_l_1b61:
	/* 0x1b61: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b64:
	/* 0x1b64: jge    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b64, 0x1c08, x86_l_1c08);
x86_l_1b6a:
	/* 0x1b6a: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1b6d:
	/* 0x1b6d: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b6d, 0x1ca8, x86_l_1ca8);
x86_l_1b73:
	/* 0x1b73: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b75:
	/* 0x1b75: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b78:
	/* 0x1b78: jg     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b78, 0x1caa, x86_l_1caa);
x86_l_1b7e:
	/* 0x1b7e: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b81:
	/* 0x1b81: jge    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b81, 0x1c08, x86_l_1c08);
x86_l_1b87:
	/* 0x1b87: jmp    1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1b87, 0x1caa, x86_l_1caa);
x86_l_1b8c:
	/* 0x1b8c: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b8f:
	/* 0x1b8f: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b92:
	/* 0x1b92: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1b96:
	/* 0x1b96: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b99:
	/* 0x1b99: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1b9c:
	/* 0x1b9c: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1b9f:
	/* 0x1b9f: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ba2:
	/* 0x1ba2: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ba2, 0x1caa, x86_l_1caa);
x86_l_1ba8:
	/* 0x1ba8: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bab:
	/* 0x1bab: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1baf:
	/* 0x1baf: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1bb2:
	/* 0x1bb2: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1bb6:
	/* 0x1bb6: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1bb9:
	/* 0x1bb9: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1bbc:
	/* 0x1bbc: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1bbf:
	/* 0x1bbf: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bbf, 0x1caa, x86_l_1caa);
x86_l_1bc5:
	/* 0x1bc5: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bc8:
	/* 0x1bc8: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1bcc:
	/* 0x1bcc: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1bcf:
	/* 0x1bcf: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1bd3:
	/* 0x1bd3: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1bd6:
	/* 0x1bd6: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1bd9:
	/* 0x1bd9: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1bdc:
	/* 0x1bdc: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bdc, 0x1caa, x86_l_1caa);
x86_l_1be2:
	/* 0x1be2: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1be5:
	/* 0x1be5: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1be8:
	/* 0x1be8: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1beb:
	/* 0x1beb: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1bef:
	/* 0x1bef: jmp    1c64 <filter_16ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x1bef, 0x1c64, x86_l_1c64);
x86_l_1bf1:
	/* 0x1bf1: movzx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1bf4:
	/* 0x1bf4: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1bf7:
	/* 0x1bf7: jne    1c09 <filter_16ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1bf7, 0x1c09, x86_l_1c09);
x86_l_1bf9:
	/* 0x1bf9: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1bfe:
	/* 0x1bfe: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c01:
	/* 0x1c01: ja     1c6c <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c01, 0x1c6c, x86_l_1c6c);
x86_l_1c03:
	/* 0x1c03: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1c06:
	/* 0x1c06: jb     1c6c <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c06, 0x1c6c, x86_l_1c6c);
x86_l_1c08:
	/* 0x1c08: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1c08);
x86_l_1c09:
	/* 0x1c09: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0c:
	/* 0x1c0c: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c0f:
	/* 0x1c0f: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1c13:
	/* 0x1c13: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1c16:
	/* 0x1c16: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1c19:
	/* 0x1c19: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c1c:
	/* 0x1c1c: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1c1f:
	/* 0x1c1f: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c1f, 0x1caa, x86_l_1caa);
x86_l_1c25:
	/* 0x1c25: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c28:
	/* 0x1c28: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1c2c:
	/* 0x1c2c: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c2f:
	/* 0x1c2f: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1c33:
	/* 0x1c33: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c36:
	/* 0x1c36: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1c39:
	/* 0x1c39: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1c3c:
	/* 0x1c3c: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c3c, 0x1caa, x86_l_1caa);
x86_l_1c3e:
	/* 0x1c3e: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c41:
	/* 0x1c41: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1c45:
	/* 0x1c45: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c48:
	/* 0x1c48: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1c4c:
	/* 0x1c4c: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c4f:
	/* 0x1c4f: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1c52:
	/* 0x1c52: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1c55:
	/* 0x1c55: jb     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c55, 0x1caa, x86_l_1caa);
x86_l_1c57:
	/* 0x1c57: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c5a:
	/* 0x1c5a: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1c5d:
	/* 0x1c5d: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c60:
	/* 0x1c60: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1c64:
	/* 0x1c64: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c67:
	/* 0x1c67: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1c6a:
	/* 0x1c6a: jmp    1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1c6a, 0x1caa, x86_l_1caa);
x86_l_1c6c:
	/* 0x1c6c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c6f:
	/* 0x1c6f: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1c72:
	/* 0x1c72: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c72, 0x1ca8, x86_l_1ca8);
x86_l_1c74:
	/* 0x1c74: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c77:
	/* 0x1c77: ja     1c7e <filter_16ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c77, 0x1c7e, x86_l_1c7e);
x86_l_1c79:
	/* 0x1c79: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c7c:
	/* 0x1c7c: jae    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c7c, 0x1c08, x86_l_1c08);
x86_l_1c7e:
	/* 0x1c7e: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1c81:
	/* 0x1c81: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c81, 0x1ca8, x86_l_1ca8);
x86_l_1c83:
	/* 0x1c83: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c86:
	/* 0x1c86: ja     1c91 <filter_16ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c86, 0x1c91, x86_l_1c91);
x86_l_1c88:
	/* 0x1c88: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c8b:
	/* 0x1c8b: jae    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c8b, 0x1c08, x86_l_1c08);
x86_l_1c91:
	/* 0x1c91: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1c94:
	/* 0x1c94: jb     1ca8 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c94, 0x1ca8, x86_l_1ca8);
x86_l_1c96:
	/* 0x1c96: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c98:
	/* 0x1c98: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c9b:
	/* 0x1c9b: ja     1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c9b, 0x1caa, x86_l_1caa);
x86_l_1c9d:
	/* 0x1c9d: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1ca0:
	/* 0x1ca0: jae    1c08 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1ca0, 0x1c08, x86_l_1c08);
x86_l_1ca6:
	/* 0x1ca6: jmp    1caa <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1ca6, 0x1caa, x86_l_1caa);
x86_l_1ca8:
	/* 0x1ca8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1caa:
	/* 0x1caa: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_1cad:
	/* 0x1cad: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1cb0:
	/* 0x1cb0: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1cb3:
	/* 0x1cb3: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1cb5:
	/* 0x1cb5: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1cb8:
	/* 0x1cb8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1c08);

	/* native subroutine native_link_sub_1cb9 */
x86_l_1cb9:
	/* 0x1cb9: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1cbb:
	/* 0x1cbb: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1cbc:
	/* 0x1cbc: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1cc0:
	/* 0x1cc0: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cc3:
	/* 0x1cc3: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1cc6:
	/* 0x1cc6: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1cca:
	/* 0x1cca: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1cce:
	/* 0x1cce: mov    rdi,QWORD PTR [rip+0x14c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_1cd5:
	/* 0x1cd5: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1cda:
	/* 0x1cda: call   319f <filter_file_type+0xbc5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cdf:
	/* 0x1cdf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ce2:
	/* 0x1ce2: je     1d16 <filter_16ty_map+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1ce2, 0x1d16, x86_l_1d16);
x86_l_1ce4:
	/* 0x1ce4: movzx  ecx,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ce8:
	/* 0x1ce8: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ced:
	/* 0x1ced: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cf2:
	/* 0x1cf2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cf5:
	/* 0x1cf5: call   31ba <filter_file_type+0xbe0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cfa:
	/* 0x1cfa: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cfd:
	/* 0x1cfd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cff:
	/* 0x1cff: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_1d02:
	/* 0x1d02: ja     1d30 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d02, 0x1d30, x86_l_1d30);
x86_l_1d04:
	/* 0x1d04: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_1d09:
	/* 0x1d09: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1d0c:
	/* 0x1d0c: jae    1d20 <filter_16ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d0c, 0x1d20, x86_l_1d20);
x86_l_1d0e:
	/* 0x1d0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d11:
	/* 0x1d11: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1d14:
	/* 0x1d14: jmp    1d30 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JMP(0x1d14, 0x1d30, x86_l_1d30);
x86_l_1d16:
	/* 0x1d16: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d18:
	/* 0x1d18: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1d1c:
	/* 0x1d1c: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1d1d:
	/* 0x1d1d: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1d1f:
	/* 0x1d1f: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1d1f);
x86_l_1d20:
	/* 0x1d20: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_1d25:
	/* 0x1d25: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1d28:
	/* 0x1d28: jae    1d30 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d28, 0x1d30, x86_l_1d30);
x86_l_1d2a:
	/* 0x1d2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d2d:
	/* 0x1d2d: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d30:
	/* 0x1d30: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1d33:
	/* 0x1d33: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1d37:
	/* 0x1d37: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1d38:
	/* 0x1d38: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1d3a:
	/* 0x1d3a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1d1f);

	/* native subroutine native_link_sub_1d3b */
x86_l_1d3b:
	/* 0x1d3b: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d3e:
	/* 0x1d3e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1d43:
	/* 0x1d43: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_1d47:
	/* 0x1d47: ja     1db8 <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d47, 0x1db8, x86_l_1db8);
x86_l_1d49:
	/* 0x1d49: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_1d53:
	/* 0x1d53: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d57:
	/* 0x1d57: jae    1d5a <filter_32ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d57, 0x1d5a, x86_l_1d5a);
x86_l_1d59:
	/* 0x1d59: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1d59);
x86_l_1d5a:
	/* 0x1d5a: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_1d5f:
	/* 0x1d5f: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d63:
	/* 0x1d63: jae    1d79 <filter_32ty_selector_val+0x3e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d63, 0x1d79, x86_l_1d79);
x86_l_1d65:
	/* 0x1d65: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d67:
	/* 0x1d67: cmp    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d6a:
	/* 0x1d6a: jne    1e8c <filter_32ty_selector_val+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d6a, 0x1e8c, x86_l_1e8c);
x86_l_1d70:
	/* 0x1d70: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d72:
	/* 0x1d72: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1d75:
	/* 0x1d75: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d78:
	/* 0x1d78: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1d59);
x86_l_1d79:
	/* 0x1d79: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_1d7d:
	/* 0x1d7d: jne    1db8 <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d7d, 0x1db8, x86_l_1db8);
x86_l_1d7f:
	/* 0x1d7f: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d81:
	/* 0x1d81: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1d84:
	/* 0x1d84: jne    1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d84, 0x1d59, x86_l_1d59);
x86_l_1d86:
	/* 0x1d86: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d89:
	/* 0x1d89: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1d8c:
	/* 0x1d8c: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d8c, 0x1f4c, x86_l_1f4c);
x86_l_1d92:
	/* 0x1d92: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1d95:
	/* 0x1d95: jne    1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d95, 0x1d59, x86_l_1d59);
x86_l_1d97:
	/* 0x1d97: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1d9a:
	/* 0x1d9a: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d9a, 0x1f4c, x86_l_1f4c);
x86_l_1da0:
	/* 0x1da0: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1da3:
	/* 0x1da3: jne    1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1da3, 0x1d59, x86_l_1d59);
x86_l_1da5:
	/* 0x1da5: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1da8:
	/* 0x1da8: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1da8, 0x1f4c, x86_l_1f4c);
x86_l_1dae:
	/* 0x1dae: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1db1:
	/* 0x1db1: jne    1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1db1, 0x1d59, x86_l_1d59);
x86_l_1db3:
	/* 0x1db3: jmp    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1db3, 0x1f4c, x86_l_1f4c);
x86_l_1db8:
	/* 0x1db8: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1dbb:
	/* 0x1dbb: je     1e29 <filter_32ty_selector_val+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1dbb, 0x1e29, x86_l_1e29);
x86_l_1dbd:
	/* 0x1dbd: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1dc0:
	/* 0x1dc0: jne    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1dc0, 0x1f4c, x86_l_1f4c);
x86_l_1dc6:
	/* 0x1dc6: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1dc9:
	/* 0x1dc9: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1dcc:
	/* 0x1dcc: ja     1f14 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1dcc, 0x1f14, x86_l_1f14);
x86_l_1dd2:
	/* 0x1dd2: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1dd7:
	/* 0x1dd7: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1dda:
	/* 0x1dda: jae    1f14 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1dda, 0x1f14, x86_l_1f14);
x86_l_1de0:
	/* 0x1de0: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1de2:
	/* 0x1de2: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1de5:
	/* 0x1de5: jl     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1de5, 0x1d59, x86_l_1d59);
x86_l_1deb:
	/* 0x1deb: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dee:
	/* 0x1dee: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1df1:
	/* 0x1df1: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1df1, 0x1f4c, x86_l_1f4c);
x86_l_1df7:
	/* 0x1df7: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1dfa:
	/* 0x1dfa: jl     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1dfa, 0x1d59, x86_l_1d59);
x86_l_1e00:
	/* 0x1e00: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e03:
	/* 0x1e03: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e03, 0x1f4c, x86_l_1f4c);
x86_l_1e09:
	/* 0x1e09: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e0c:
	/* 0x1e0c: jl     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1e0c, 0x1d59, x86_l_1d59);
x86_l_1e12:
	/* 0x1e12: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1e15:
	/* 0x1e15: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e15, 0x1f4c, x86_l_1f4c);
x86_l_1e1b:
	/* 0x1e1b: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e1e:
	/* 0x1e1e: jl     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1e1e, 0x1d59, x86_l_1d59);
x86_l_1e24:
	/* 0x1e24: jmp    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1e24, 0x1f4c, x86_l_1f4c);
x86_l_1e29:
	/* 0x1e29: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1e2c:
	/* 0x1e2c: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1e2f:
	/* 0x1e2f: ja     1eda <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e2f, 0x1eda, x86_l_1eda);
x86_l_1e35:
	/* 0x1e35: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1e3a:
	/* 0x1e3a: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1e3d:
	/* 0x1e3d: jae    1eda <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1e3d, 0x1eda, x86_l_1eda);
x86_l_1e43:
	/* 0x1e43: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e45:
	/* 0x1e45: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e48:
	/* 0x1e48: jg     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e48, 0x1d59, x86_l_1d59);
x86_l_1e4e:
	/* 0x1e4e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e51:
	/* 0x1e51: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e54:
	/* 0x1e54: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e54, 0x1f4c, x86_l_1f4c);
x86_l_1e5a:
	/* 0x1e5a: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e5d:
	/* 0x1e5d: jg     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e5d, 0x1d59, x86_l_1d59);
x86_l_1e63:
	/* 0x1e63: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e66:
	/* 0x1e66: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e66, 0x1f4c, x86_l_1f4c);
x86_l_1e6c:
	/* 0x1e6c: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e6f:
	/* 0x1e6f: jg     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e6f, 0x1d59, x86_l_1d59);
x86_l_1e75:
	/* 0x1e75: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1e78:
	/* 0x1e78: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e78, 0x1f4c, x86_l_1f4c);
x86_l_1e7e:
	/* 0x1e7e: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e81:
	/* 0x1e81: jg     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e81, 0x1d59, x86_l_1d59);
x86_l_1e87:
	/* 0x1e87: jmp    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1e87, 0x1f4c, x86_l_1f4c);
x86_l_1e8c:
	/* 0x1e8c: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e8f:
	/* 0x1e8f: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e92:
	/* 0x1e92: jb     1eb9 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e92, 0x1eb9, x86_l_1eb9);
x86_l_1e94:
	/* 0x1e94: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e97:
	/* 0x1e97: je     1d70 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e97, 0x1d70, x86_l_1d70);
x86_l_1e9d:
	/* 0x1e9d: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ea0:
	/* 0x1ea0: jb     1eb9 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ea0, 0x1eb9, x86_l_1eb9);
x86_l_1ea2:
	/* 0x1ea2: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1ea5:
	/* 0x1ea5: je     1d70 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1ea5, 0x1d70, x86_l_1d70);
x86_l_1eab:
	/* 0x1eab: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1eae:
	/* 0x1eae: jb     1eb9 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eae, 0x1eb9, x86_l_1eb9);
x86_l_1eb0:
	/* 0x1eb0: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1eb3:
	/* 0x1eb3: je     1d70 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1eb3, 0x1d70, x86_l_1d70);
x86_l_1eb9:
	/* 0x1eb9: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1ebc:
	/* 0x1ebc: ja     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ebc, 0x1f4c, x86_l_1f4c);
x86_l_1ec2:
	/* 0x1ec2: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1ec4:
	/* 0x1ec4: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1ece:
	/* 0x1ece: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ed2:
	/* 0x1ed2: jb     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ed2, 0x1d59, x86_l_1d59);
x86_l_1ed8:
	/* 0x1ed8: jmp    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1ed8, 0x1f4c, x86_l_1f4c);
x86_l_1eda:
	/* 0x1eda: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1edc:
	/* 0x1edc: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1edf:
	/* 0x1edf: ja     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1edf, 0x1d59, x86_l_1d59);
x86_l_1ee5:
	/* 0x1ee5: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ee8:
	/* 0x1ee8: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1eeb:
	/* 0x1eeb: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eeb, 0x1f4c, x86_l_1f4c);
x86_l_1eed:
	/* 0x1eed: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ef0:
	/* 0x1ef0: ja     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ef0, 0x1d59, x86_l_1d59);
x86_l_1ef6:
	/* 0x1ef6: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ef9:
	/* 0x1ef9: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ef9, 0x1f4c, x86_l_1f4c);
x86_l_1efb:
	/* 0x1efb: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1efe:
	/* 0x1efe: ja     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1efe, 0x1d59, x86_l_1d59);
x86_l_1f04:
	/* 0x1f04: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1f07:
	/* 0x1f07: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f07, 0x1f4c, x86_l_1f4c);
x86_l_1f09:
	/* 0x1f09: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f0c:
	/* 0x1f0c: ja     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f0c, 0x1d59, x86_l_1d59);
x86_l_1f12:
	/* 0x1f12: jmp    1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1f12, 0x1f4c, x86_l_1f4c);
x86_l_1f14:
	/* 0x1f14: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f16:
	/* 0x1f16: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1f19:
	/* 0x1f19: jb     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f19, 0x1d59, x86_l_1d59);
x86_l_1f1f:
	/* 0x1f1f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f22:
	/* 0x1f22: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1f25:
	/* 0x1f25: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f25, 0x1f4c, x86_l_1f4c);
x86_l_1f27:
	/* 0x1f27: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f2a:
	/* 0x1f2a: jb     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f2a, 0x1d59, x86_l_1d59);
x86_l_1f30:
	/* 0x1f30: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f33:
	/* 0x1f33: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f33, 0x1f4c, x86_l_1f4c);
x86_l_1f35:
	/* 0x1f35: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1f38:
	/* 0x1f38: jb     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f38, 0x1d59, x86_l_1d59);
x86_l_1f3e:
	/* 0x1f3e: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1f41:
	/* 0x1f41: jb     1f4c <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f41, 0x1f4c, x86_l_1f4c);
x86_l_1f43:
	/* 0x1f43: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f46:
	/* 0x1f46: jb     1d59 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f46, 0x1d59, x86_l_1d59);
x86_l_1f4c:
	/* 0x1f4c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4e:
	/* 0x1f4e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1d59);

	/* native subroutine native_link_sub_1f4f */
x86_l_1f4f:
	/* 0x1f4f: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1f52:
	/* 0x1f52: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1f55:
	/* 0x1f55: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1f58:
	/* 0x1f58: ja     203e <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f58, 0x203e, x86_l_203e);
x86_l_1f5e:
	/* 0x1f5e: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1f63:
	/* 0x1f63: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f66:
	/* 0x1f66: jae    203e <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1f66, 0x203e, x86_l_203e);
x86_l_1f6c:
	/* 0x1f6c: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f6e:
	/* 0x1f6e: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1f71:
	/* 0x1f71: jne    1fd9 <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1f71, 0x1fd9, x86_l_1fd9);
x86_l_1f73:
	/* 0x1f73: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f78:
	/* 0x1f78: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f7b:
	/* 0x1f7b: jg     1f86 <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f7b, 0x1f86, x86_l_1f86);
x86_l_1f7d:
	/* 0x1f7d: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f80:
	/* 0x1f80: jle    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f80, 0x2054, x86_l_2054);
x86_l_1f86:
	/* 0x1f86: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f89:
	/* 0x1f89: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f8c:
	/* 0x1f8c: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f8c, 0x20f4, x86_l_20f4);
x86_l_1f92:
	/* 0x1f92: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f95:
	/* 0x1f95: jg     1fa0 <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f95, 0x1fa0, x86_l_1fa0);
x86_l_1f97:
	/* 0x1f97: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f9a:
	/* 0x1f9a: jle    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f9a, 0x2054, x86_l_2054);
x86_l_1fa0:
	/* 0x1fa0: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1fa3:
	/* 0x1fa3: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fa3, 0x20f4, x86_l_20f4);
x86_l_1fa9:
	/* 0x1fa9: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1fac:
	/* 0x1fac: jg     1fb7 <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1fac, 0x1fb7, x86_l_1fb7);
x86_l_1fae:
	/* 0x1fae: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1fb1:
	/* 0x1fb1: jle    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1fb1, 0x2054, x86_l_2054);
x86_l_1fb7:
	/* 0x1fb7: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1fba:
	/* 0x1fba: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fba, 0x20f4, x86_l_20f4);
x86_l_1fc0:
	/* 0x1fc0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fc2:
	/* 0x1fc2: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fc5:
	/* 0x1fc5: jg     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1fc5, 0x20f6, x86_l_20f6);
x86_l_1fcb:
	/* 0x1fcb: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1fce:
	/* 0x1fce: jle    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1fce, 0x2054, x86_l_2054);
x86_l_1fd4:
	/* 0x1fd4: jmp    20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x1fd4, 0x20f6, x86_l_20f6);
x86_l_1fd9:
	/* 0x1fd9: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fdc:
	/* 0x1fdc: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fdf:
	/* 0x1fdf: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fe3:
	/* 0x1fe3: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1fe6:
	/* 0x1fe6: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fe9:
	/* 0x1fe9: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1fec:
	/* 0x1fec: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1fef:
	/* 0x1fef: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fef, 0x20f6, x86_l_20f6);
x86_l_1ff5:
	/* 0x1ff5: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ff8:
	/* 0x1ff8: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1ffc:
	/* 0x1ffc: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1fff:
	/* 0x1fff: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2003:
	/* 0x2003: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2006:
	/* 0x2006: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2009:
	/* 0x2009: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_200c:
	/* 0x200c: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x200c, 0x20f6, x86_l_20f6);
x86_l_2012:
	/* 0x2012: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2015:
	/* 0x2015: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2019:
	/* 0x2019: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_201c:
	/* 0x201c: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2020:
	/* 0x2020: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2023:
	/* 0x2023: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2026:
	/* 0x2026: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2029:
	/* 0x2029: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2029, 0x20f6, x86_l_20f6);
x86_l_202f:
	/* 0x202f: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2032:
	/* 0x2032: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2035:
	/* 0x2035: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_2038:
	/* 0x2038: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_203c:
	/* 0x203c: jmp    20b0 <filter_32ty_range+0x161> */
	X86_SIM_X86_SUB_JMP(0x203c, 0x20b0, x86_l_20b0);
x86_l_203e:
	/* 0x203e: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2040:
	/* 0x2040: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2043:
	/* 0x2043: jne    2055 <filter_32ty_range+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2043, 0x2055, x86_l_2055);
x86_l_2045:
	/* 0x2045: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_204a:
	/* 0x204a: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_204d:
	/* 0x204d: ja     20b8 <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x204d, 0x20b8, x86_l_20b8);
x86_l_204f:
	/* 0x204f: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2052:
	/* 0x2052: ja     20b8 <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2052, 0x20b8, x86_l_20b8);
x86_l_2054:
	/* 0x2054: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2054);
x86_l_2055:
	/* 0x2055: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2058:
	/* 0x2058: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_205b:
	/* 0x205b: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_205f:
	/* 0x205f: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2062:
	/* 0x2062: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2065:
	/* 0x2065: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2068:
	/* 0x2068: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_206b:
	/* 0x206b: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x206b, 0x20f6, x86_l_20f6);
x86_l_2071:
	/* 0x2071: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2074:
	/* 0x2074: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2078:
	/* 0x2078: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_207b:
	/* 0x207b: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_207f:
	/* 0x207f: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2082:
	/* 0x2082: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2085:
	/* 0x2085: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2088:
	/* 0x2088: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2088, 0x20f6, x86_l_20f6);
x86_l_208a:
	/* 0x208a: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_208d:
	/* 0x208d: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2091:
	/* 0x2091: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2094:
	/* 0x2094: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2098:
	/* 0x2098: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_209b:
	/* 0x209b: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_209e:
	/* 0x209e: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_20a1:
	/* 0x20a1: jb     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20a1, 0x20f6, x86_l_20f6);
x86_l_20a3:
	/* 0x20a3: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20a6:
	/* 0x20a6: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_20a9:
	/* 0x20a9: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_20ac:
	/* 0x20ac: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_20b0:
	/* 0x20b0: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_20b3:
	/* 0x20b3: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_20b6:
	/* 0x20b6: jmp    20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x20b6, 0x20f6, x86_l_20f6);
x86_l_20b8:
	/* 0x20b8: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20bb:
	/* 0x20bb: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_20be:
	/* 0x20be: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20be, 0x20f4, x86_l_20f4);
x86_l_20c0:
	/* 0x20c0: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20c3:
	/* 0x20c3: ja     20ca <filter_32ty_range+0x17b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20c3, 0x20ca, x86_l_20ca);
x86_l_20c5:
	/* 0x20c5: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_20c8:
	/* 0x20c8: jbe    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20c8, 0x2054, x86_l_2054);
x86_l_20ca:
	/* 0x20ca: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_20cd:
	/* 0x20cd: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20cd, 0x20f4, x86_l_20f4);
x86_l_20cf:
	/* 0x20cf: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20d2:
	/* 0x20d2: ja     20dd <filter_32ty_range+0x18e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20d2, 0x20dd, x86_l_20dd);
x86_l_20d4:
	/* 0x20d4: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_20d7:
	/* 0x20d7: jbe    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20d7, 0x2054, x86_l_2054);
x86_l_20dd:
	/* 0x20dd: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_20e0:
	/* 0x20e0: jb     20f4 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20e0, 0x20f4, x86_l_20f4);
x86_l_20e2:
	/* 0x20e2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20e4:
	/* 0x20e4: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20e7:
	/* 0x20e7: ja     20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20e7, 0x20f6, x86_l_20f6);
x86_l_20e9:
	/* 0x20e9: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_20ec:
	/* 0x20ec: jbe    2054 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x20ec, 0x2054, x86_l_2054);
x86_l_20f2:
	/* 0x20f2: jmp    20f6 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x20f2, 0x20f6, x86_l_20f6);
x86_l_20f4:
	/* 0x20f4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20f6:
	/* 0x20f6: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_20f9:
	/* 0x20f9: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_20fc:
	/* 0x20fc: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_20ff:
	/* 0x20ff: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2101:
	/* 0x2101: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2104:
	/* 0x2104: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2054);

	/* native subroutine native_link_sub_2105 */
x86_l_2105:
	/* 0x2105: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2107:
	/* 0x2107: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2108:
	/* 0x2108: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_210c:
	/* 0x210c: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_210f:
	/* 0x210f: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2112:
	/* 0x2112: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_2116:
	/* 0x2116: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_211a:
	/* 0x211a: mov    rdi,QWORD PTR [rip+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_2121:
	/* 0x2121: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2126:
	/* 0x2126: call   317b <filter_file_type+0xba1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_212b:
	/* 0x212b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_212e:
	/* 0x212e: je     2161 <filter_32ty_map+0x5c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x212e, 0x2161, x86_l_2161);
x86_l_2130:
	/* 0x2130: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2133:
	/* 0x2133: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2138:
	/* 0x2138: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_213d:
	/* 0x213d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2140:
	/* 0x2140: call   3195 <filter_file_type+0xbbb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2145:
	/* 0x2145: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2148:
	/* 0x2148: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214a:
	/* 0x214a: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_214d:
	/* 0x214d: ja     217b <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x214d, 0x217b, x86_l_217b);
x86_l_214f:
	/* 0x214f: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_2154:
	/* 0x2154: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2157:
	/* 0x2157: jae    216b <filter_32ty_map+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2157, 0x216b, x86_l_216b);
x86_l_2159:
	/* 0x2159: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_215c:
	/* 0x215c: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_215f:
	/* 0x215f: jmp    217b <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JMP(0x215f, 0x217b, x86_l_217b);
x86_l_2161:
	/* 0x2161: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2163:
	/* 0x2163: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2167:
	/* 0x2167: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2168:
	/* 0x2168: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_216a:
	/* 0x216a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_216a);
x86_l_216b:
	/* 0x216b: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_2170:
	/* 0x2170: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2173:
	/* 0x2173: jae    217b <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2173, 0x217b, x86_l_217b);
x86_l_2175:
	/* 0x2175: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2178:
	/* 0x2178: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_217b:
	/* 0x217b: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_217e:
	/* 0x217e: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2182:
	/* 0x2182: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2183:
	/* 0x2183: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2185:
	/* 0x2185: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_216a);

	/* native subroutine native_link_sub_2186 */
x86_l_2186:
	/* 0x2186: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2189:
	/* 0x2189: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_218e:
	/* 0x218e: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_2192:
	/* 0x2192: ja     2205 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2192, 0x2205, x86_l_2205);
x86_l_2194:
	/* 0x2194: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_219e:
	/* 0x219e: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21a2:
	/* 0x21a2: jae    21a5 <filter_8ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x21a2, 0x21a5, x86_l_21a5);
x86_l_21a4:
	/* 0x21a4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_21a4);
x86_l_21a5:
	/* 0x21a5: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_21aa:
	/* 0x21aa: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21ae:
	/* 0x21ae: jae    21c5 <filter_8ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x21ae, 0x21c5, x86_l_21c5);
x86_l_21b0:
	/* 0x21b0: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21b3:
	/* 0x21b3: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21b6:
	/* 0x21b6: jne    22db <filter_8ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21b6, 0x22db, x86_l_22db);
x86_l_21bc:
	/* 0x21bc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21be:
	/* 0x21be: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_21c1:
	/* 0x21c1: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_21c4:
	/* 0x21c4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_21a4);
x86_l_21c5:
	/* 0x21c5: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_21c9:
	/* 0x21c9: jne    2205 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21c9, 0x2205, x86_l_2205);
x86_l_21cb:
	/* 0x21cb: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21ce:
	/* 0x21ce: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_21d1:
	/* 0x21d1: jne    21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21d1, 0x21a4, x86_l_21a4);
x86_l_21d3:
	/* 0x21d3: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21d6:
	/* 0x21d6: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_21d9:
	/* 0x21d9: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21d9, 0x239d, x86_l_239d);
x86_l_21df:
	/* 0x21df: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_21e2:
	/* 0x21e2: jne    21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21e2, 0x21a4, x86_l_21a4);
x86_l_21e4:
	/* 0x21e4: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_21e7:
	/* 0x21e7: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21e7, 0x239d, x86_l_239d);
x86_l_21ed:
	/* 0x21ed: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_21f0:
	/* 0x21f0: jne    21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21f0, 0x21a4, x86_l_21a4);
x86_l_21f2:
	/* 0x21f2: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_21f5:
	/* 0x21f5: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f5, 0x239d, x86_l_239d);
x86_l_21fb:
	/* 0x21fb: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_21fe:
	/* 0x21fe: jne    21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21fe, 0x21a4, x86_l_21a4);
x86_l_2200:
	/* 0x2200: jmp    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2200, 0x239d, x86_l_239d);
x86_l_2205:
	/* 0x2205: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2208:
	/* 0x2208: je     2277 <filter_8ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2208, 0x2277, x86_l_2277);
x86_l_220a:
	/* 0x220a: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_220d:
	/* 0x220d: jne    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x220d, 0x239d, x86_l_239d);
x86_l_2213:
	/* 0x2213: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2216:
	/* 0x2216: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2219:
	/* 0x2219: ja     2364 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2219, 0x2364, x86_l_2364);
x86_l_221f:
	/* 0x221f: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_2224:
	/* 0x2224: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2227:
	/* 0x2227: jae    2364 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2227, 0x2364, x86_l_2364);
x86_l_222d:
	/* 0x222d: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2230:
	/* 0x2230: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2233:
	/* 0x2233: jg     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2233, 0x21a4, x86_l_21a4);
x86_l_2239:
	/* 0x2239: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_223c:
	/* 0x223c: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_223f:
	/* 0x223f: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x223f, 0x239d, x86_l_239d);
x86_l_2245:
	/* 0x2245: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2248:
	/* 0x2248: jg     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2248, 0x21a4, x86_l_21a4);
x86_l_224e:
	/* 0x224e: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2251:
	/* 0x2251: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2251, 0x239d, x86_l_239d);
x86_l_2257:
	/* 0x2257: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_225a:
	/* 0x225a: jg     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x225a, 0x21a4, x86_l_21a4);
x86_l_2260:
	/* 0x2260: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2263:
	/* 0x2263: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2263, 0x239d, x86_l_239d);
x86_l_2269:
	/* 0x2269: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_226c:
	/* 0x226c: jg     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x226c, 0x21a4, x86_l_21a4);
x86_l_2272:
	/* 0x2272: jmp    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2272, 0x239d, x86_l_239d);
x86_l_2277:
	/* 0x2277: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_227a:
	/* 0x227a: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_227d:
	/* 0x227d: ja     2329 <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x227d, 0x2329, x86_l_2329);
x86_l_2283:
	/* 0x2283: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_2288:
	/* 0x2288: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_228b:
	/* 0x228b: jae    2329 <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x228b, 0x2329, x86_l_2329);
x86_l_2291:
	/* 0x2291: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2294:
	/* 0x2294: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2297:
	/* 0x2297: jl     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2297, 0x21a4, x86_l_21a4);
x86_l_229d:
	/* 0x229d: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22a0:
	/* 0x22a0: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_22a3:
	/* 0x22a3: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22a3, 0x239d, x86_l_239d);
x86_l_22a9:
	/* 0x22a9: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22ac:
	/* 0x22ac: jl     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22ac, 0x21a4, x86_l_21a4);
x86_l_22b2:
	/* 0x22b2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_22b5:
	/* 0x22b5: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22b5, 0x239d, x86_l_239d);
x86_l_22bb:
	/* 0x22bb: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22be:
	/* 0x22be: jl     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22be, 0x21a4, x86_l_21a4);
x86_l_22c4:
	/* 0x22c4: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_22c7:
	/* 0x22c7: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22c7, 0x239d, x86_l_239d);
x86_l_22cd:
	/* 0x22cd: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22d0:
	/* 0x22d0: jl     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x22d0, 0x21a4, x86_l_21a4);
x86_l_22d6:
	/* 0x22d6: jmp    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x22d6, 0x239d, x86_l_239d);
x86_l_22db:
	/* 0x22db: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22de:
	/* 0x22de: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_22e1:
	/* 0x22e1: jb     2308 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22e1, 0x2308, x86_l_2308);
x86_l_22e3:
	/* 0x22e3: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22e6:
	/* 0x22e6: je     21bc <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22e6, 0x21bc, x86_l_21bc);
x86_l_22ec:
	/* 0x22ec: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_22ef:
	/* 0x22ef: jb     2308 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22ef, 0x2308, x86_l_2308);
x86_l_22f1:
	/* 0x22f1: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22f4:
	/* 0x22f4: je     21bc <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22f4, 0x21bc, x86_l_21bc);
x86_l_22fa:
	/* 0x22fa: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_22fd:
	/* 0x22fd: jb     2308 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22fd, 0x2308, x86_l_2308);
x86_l_22ff:
	/* 0x22ff: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2302:
	/* 0x2302: je     21bc <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2302, 0x21bc, x86_l_21bc);
x86_l_2308:
	/* 0x2308: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_230b:
	/* 0x230b: ja     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x230b, 0x239d, x86_l_239d);
x86_l_2311:
	/* 0x2311: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2313:
	/* 0x2313: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_231d:
	/* 0x231d: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2321:
	/* 0x2321: jb     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2321, 0x21a4, x86_l_21a4);
x86_l_2327:
	/* 0x2327: jmp    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2327, 0x239d, x86_l_239d);
x86_l_2329:
	/* 0x2329: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_232c:
	/* 0x232c: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_232f:
	/* 0x232f: jb     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x232f, 0x21a4, x86_l_21a4);
x86_l_2335:
	/* 0x2335: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2338:
	/* 0x2338: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_233b:
	/* 0x233b: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x233b, 0x239d, x86_l_239d);
x86_l_233d:
	/* 0x233d: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2340:
	/* 0x2340: jb     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2340, 0x21a4, x86_l_21a4);
x86_l_2346:
	/* 0x2346: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2349:
	/* 0x2349: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2349, 0x239d, x86_l_239d);
x86_l_234b:
	/* 0x234b: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_234e:
	/* 0x234e: jb     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x234e, 0x21a4, x86_l_21a4);
x86_l_2354:
	/* 0x2354: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2357:
	/* 0x2357: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2357, 0x239d, x86_l_239d);
x86_l_2359:
	/* 0x2359: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_235c:
	/* 0x235c: jb     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x235c, 0x21a4, x86_l_21a4);
x86_l_2362:
	/* 0x2362: jmp    239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2362, 0x239d, x86_l_239d);
x86_l_2364:
	/* 0x2364: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2367:
	/* 0x2367: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_236a:
	/* 0x236a: ja     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x236a, 0x21a4, x86_l_21a4);
x86_l_2370:
	/* 0x2370: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2373:
	/* 0x2373: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2376:
	/* 0x2376: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2376, 0x239d, x86_l_239d);
x86_l_2378:
	/* 0x2378: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_237b:
	/* 0x237b: ja     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x237b, 0x21a4, x86_l_21a4);
x86_l_2381:
	/* 0x2381: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2384:
	/* 0x2384: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2384, 0x239d, x86_l_239d);
x86_l_2386:
	/* 0x2386: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2389:
	/* 0x2389: ja     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2389, 0x21a4, x86_l_21a4);
x86_l_238f:
	/* 0x238f: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2392:
	/* 0x2392: jb     239d <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2392, 0x239d, x86_l_239d);
x86_l_2394:
	/* 0x2394: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2397:
	/* 0x2397: ja     21a4 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2397, 0x21a4, x86_l_21a4);
x86_l_239d:
	/* 0x239d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_239f:
	/* 0x239f: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_21a4);

	/* native subroutine native_link_sub_23a0 */
x86_l_23a0:
	/* 0x23a0: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23a3:
	/* 0x23a3: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_23a6:
	/* 0x23a6: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_23a9:
	/* 0x23a9: ja     2490 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x23a9, 0x2490, x86_l_2490);
x86_l_23af:
	/* 0x23af: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_23b4:
	/* 0x23b4: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_23b7:
	/* 0x23b7: jae    2490 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x23b7, 0x2490, x86_l_2490);
x86_l_23bd:
	/* 0x23bd: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_23c0:
	/* 0x23c0: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_23c3:
	/* 0x23c3: jne    242b <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x23c3, 0x242b, x86_l_242b);
x86_l_23c5:
	/* 0x23c5: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_23ca:
	/* 0x23ca: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23cd:
	/* 0x23cd: jg     23d8 <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23cd, 0x23d8, x86_l_23d8);
x86_l_23cf:
	/* 0x23cf: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23d2:
	/* 0x23d2: jge    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23d2, 0x24a7, x86_l_24a7);
x86_l_23d8:
	/* 0x23d8: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23db:
	/* 0x23db: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_23de:
	/* 0x23de: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23de, 0x2547, x86_l_2547);
x86_l_23e4:
	/* 0x23e4: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23e7:
	/* 0x23e7: jg     23f2 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23e7, 0x23f2, x86_l_23f2);
x86_l_23e9:
	/* 0x23e9: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23ec:
	/* 0x23ec: jge    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23ec, 0x24a7, x86_l_24a7);
x86_l_23f2:
	/* 0x23f2: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_23f5:
	/* 0x23f5: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23f5, 0x2547, x86_l_2547);
x86_l_23fb:
	/* 0x23fb: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23fe:
	/* 0x23fe: jg     2409 <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23fe, 0x2409, x86_l_2409);
x86_l_2400:
	/* 0x2400: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2403:
	/* 0x2403: jge    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2403, 0x24a7, x86_l_24a7);
x86_l_2409:
	/* 0x2409: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_240c:
	/* 0x240c: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x240c, 0x2547, x86_l_2547);
x86_l_2412:
	/* 0x2412: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2414:
	/* 0x2414: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2417:
	/* 0x2417: jg     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2417, 0x2549, x86_l_2549);
x86_l_241d:
	/* 0x241d: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2420:
	/* 0x2420: jge    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2420, 0x24a7, x86_l_24a7);
x86_l_2426:
	/* 0x2426: jmp    2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x2426, 0x2549, x86_l_2549);
x86_l_242b:
	/* 0x242b: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_242e:
	/* 0x242e: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2431:
	/* 0x2431: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2435:
	/* 0x2435: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2438:
	/* 0x2438: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_243b:
	/* 0x243b: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_243e:
	/* 0x243e: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2441:
	/* 0x2441: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2441, 0x2549, x86_l_2549);
x86_l_2447:
	/* 0x2447: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_244a:
	/* 0x244a: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_244e:
	/* 0x244e: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2451:
	/* 0x2451: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2455:
	/* 0x2455: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2458:
	/* 0x2458: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_245b:
	/* 0x245b: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_245e:
	/* 0x245e: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x245e, 0x2549, x86_l_2549);
x86_l_2464:
	/* 0x2464: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2467:
	/* 0x2467: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_246b:
	/* 0x246b: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_246e:
	/* 0x246e: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2472:
	/* 0x2472: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2475:
	/* 0x2475: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2478:
	/* 0x2478: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_247b:
	/* 0x247b: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x247b, 0x2549, x86_l_2549);
x86_l_2481:
	/* 0x2481: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2484:
	/* 0x2484: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2487:
	/* 0x2487: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_248a:
	/* 0x248a: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_248e:
	/* 0x248e: jmp    2503 <filter_8ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x248e, 0x2503, x86_l_2503);
x86_l_2490:
	/* 0x2490: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2493:
	/* 0x2493: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2496:
	/* 0x2496: jne    24a8 <filter_8ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2496, 0x24a8, x86_l_24a8);
x86_l_2498:
	/* 0x2498: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_249d:
	/* 0x249d: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a0:
	/* 0x24a0: ja     250b <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24a0, 0x250b, x86_l_250b);
x86_l_24a2:
	/* 0x24a2: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24a5:
	/* 0x24a5: jb     250b <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24a5, 0x250b, x86_l_250b);
x86_l_24a7:
	/* 0x24a7: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_24a7);
x86_l_24a8:
	/* 0x24a8: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ab:
	/* 0x24ab: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ae:
	/* 0x24ae: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_24b2:
	/* 0x24b2: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24b5:
	/* 0x24b5: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_24b8:
	/* 0x24b8: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_24bb:
	/* 0x24bb: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_24be:
	/* 0x24be: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24be, 0x2549, x86_l_2549);
x86_l_24c4:
	/* 0x24c4: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24c7:
	/* 0x24c7: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_24cb:
	/* 0x24cb: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24ce:
	/* 0x24ce: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_24d2:
	/* 0x24d2: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_24d5:
	/* 0x24d5: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_24d8:
	/* 0x24d8: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_24db:
	/* 0x24db: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24db, 0x2549, x86_l_2549);
x86_l_24dd:
	/* 0x24dd: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24e0:
	/* 0x24e0: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_24e4:
	/* 0x24e4: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_24e7:
	/* 0x24e7: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_24eb:
	/* 0x24eb: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_24ee:
	/* 0x24ee: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_24f1:
	/* 0x24f1: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_24f4:
	/* 0x24f4: jb     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24f4, 0x2549, x86_l_2549);
x86_l_24f6:
	/* 0x24f6: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24f9:
	/* 0x24f9: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_24fc:
	/* 0x24fc: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24ff:
	/* 0x24ff: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_2503:
	/* 0x2503: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2506:
	/* 0x2506: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2509:
	/* 0x2509: jmp    2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x2509, 0x2549, x86_l_2549);
x86_l_250b:
	/* 0x250b: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_250e:
	/* 0x250e: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2511:
	/* 0x2511: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2511, 0x2547, x86_l_2547);
x86_l_2513:
	/* 0x2513: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2516:
	/* 0x2516: ja     251d <filter_8ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2516, 0x251d, x86_l_251d);
x86_l_2518:
	/* 0x2518: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_251b:
	/* 0x251b: jae    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x251b, 0x24a7, x86_l_24a7);
x86_l_251d:
	/* 0x251d: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2520:
	/* 0x2520: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2520, 0x2547, x86_l_2547);
x86_l_2522:
	/* 0x2522: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2525:
	/* 0x2525: ja     2530 <filter_8ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2525, 0x2530, x86_l_2530);
x86_l_2527:
	/* 0x2527: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_252a:
	/* 0x252a: jae    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x252a, 0x24a7, x86_l_24a7);
x86_l_2530:
	/* 0x2530: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2533:
	/* 0x2533: jb     2547 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2533, 0x2547, x86_l_2547);
x86_l_2535:
	/* 0x2535: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2537:
	/* 0x2537: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_253a:
	/* 0x253a: ja     2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x253a, 0x2549, x86_l_2549);
x86_l_253c:
	/* 0x253c: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_253f:
	/* 0x253f: jae    24a7 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x253f, 0x24a7, x86_l_24a7);
x86_l_2545:
	/* 0x2545: jmp    2549 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x2545, 0x2549, x86_l_2549);
x86_l_2547:
	/* 0x2547: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2549:
	/* 0x2549: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_254c:
	/* 0x254c: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_254f:
	/* 0x254f: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_2552:
	/* 0x2552: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2554:
	/* 0x2554: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2557:
	/* 0x2557: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_24a7);

	/* native subroutine native_link_sub_2558 */
x86_l_2558:
	/* 0x2558: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_255a:
	/* 0x255a: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_255b:
	/* 0x255b: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_255f:
	/* 0x255f: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2562:
	/* 0x2562: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2565:
	/* 0x2565: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_2569:
	/* 0x2569: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_256d:
	/* 0x256d: mov    rdi,QWORD PTR [rip+0x1930] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_2574:
	/* 0x2574: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2579:
	/* 0x2579: call   3eae <filter_file_type+0x18d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_257e:
	/* 0x257e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2581:
	/* 0x2581: je     25b5 <filter_8ty_map+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2581, 0x25b5, x86_l_25b5);
x86_l_2583:
	/* 0x2583: movzx  ecx,BYTE PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2587:
	/* 0x2587: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_258c:
	/* 0x258c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2591:
	/* 0x2591: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2594:
	/* 0x2594: call   3ec9 <filter_file_type+0x18ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2599:
	/* 0x2599: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_259c:
	/* 0x259c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_259e:
	/* 0x259e: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_25a1:
	/* 0x25a1: ja     25cf <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25a1, 0x25cf, x86_l_25cf);
x86_l_25a3:
	/* 0x25a3: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_25a8:
	/* 0x25a8: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_25ab:
	/* 0x25ab: jae    25bf <filter_8ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x25ab, 0x25bf, x86_l_25bf);
x86_l_25ad:
	/* 0x25ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b0:
	/* 0x25b0: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_25b3:
	/* 0x25b3: jmp    25cf <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JMP(0x25b3, 0x25cf, x86_l_25cf);
x86_l_25b5:
	/* 0x25b5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b7:
	/* 0x25b7: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_25bb:
	/* 0x25bb: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25bc:
	/* 0x25bc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25be:
	/* 0x25be: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_25be);
x86_l_25bf:
	/* 0x25bf: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_25c4:
	/* 0x25c4: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_25c7:
	/* 0x25c7: jae    25cf <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x25c7, 0x25cf, x86_l_25cf);
x86_l_25c9:
	/* 0x25c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25cc:
	/* 0x25cc: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_25cf:
	/* 0x25cf: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_25d2:
	/* 0x25d2: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_25d6:
	/* 0x25d6: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25d7:
	/* 0x25d7: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25d9:
	/* 0x25d9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_25be);

	/* native subroutine native_link_sub_25da */
x86_l_25da:
	/* 0x25da: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25db:
	/* 0x25db: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_25df:
	/* 0x25df: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_25e6:
	/* 0x25e6: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25e8:
	/* 0x25e8: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_25ee:
	/* 0x25ee: ja     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25ee, 0x268b, x86_l_268b);
x86_l_25f4:
	/* 0x25f4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25f7:
	/* 0x25f7: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25fa:
	/* 0x25fa: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_25fe:
	/* 0x25fe: jns    2611 <filter_file_type+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x25fe, 0x2611, x86_l_2611);
x86_l_2600:
	/* 0x2600: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2603:
	/* 0x2603: jns    2637 <filter_file_type+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2603, 0x2637, x86_l_2637);
x86_l_2605:
	/* 0x2605: movzx  ecx,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2608:
	/* 0x2608: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_260b:
	/* 0x260b: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_260d:
	/* 0x260d: jne    2640 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x260d, 0x2640, x86_l_2640);
x86_l_260f:
	/* 0x260f: jmp    268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x260f, 0x268b, x86_l_268b);
x86_l_2611:
	/* 0x2611: lea    rax,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_2616:
	/* 0x2616: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2619:
	/* 0x2619: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_261c:
	/* 0x261c: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2621:
	/* 0x2621: call   4e96 <filter_file_type+0x28bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2626:
	/* 0x2626: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2629:
	/* 0x2629: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_262e:
	/* 0x262e: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2631:
	/* 0x2631: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2633:
	/* 0x2633: jne    2640 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2633, 0x2640, x86_l_2640);
x86_l_2635:
	/* 0x2635: jmp    268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x2635, 0x268b, x86_l_268b);
x86_l_2637:
	/* 0x2637: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2639:
	/* 0x2639: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_263c:
	/* 0x263c: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_263e:
	/* 0x263e: je     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x263e, 0x268b, x86_l_268b);
x86_l_2640:
	/* 0x2640: and    ecx,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_2646:
	/* 0x2646: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_264b:
	/* 0x264b: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_264d:
	/* 0x264d: je     268d <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x264d, 0x268d, x86_l_268d);
x86_l_264f:
	/* 0x264f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2652:
	/* 0x2652: cmp    edx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2655:
	/* 0x2655: jbe    268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2655, 0x268b, x86_l_268b);
x86_l_2657:
	/* 0x2657: mov    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_265a:
	/* 0x265a: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_265c:
	/* 0x265c: je     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x265c, 0x268b, x86_l_268b);
x86_l_265e:
	/* 0x265e: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2660:
	/* 0x2660: je     268d <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2660, 0x268d, x86_l_268d);
x86_l_2662:
	/* 0x2662: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2665:
	/* 0x2665: jb     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2665, 0x268b, x86_l_268b);
x86_l_2667:
	/* 0x2667: mov    esi,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_266a:
	/* 0x266a: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_266c:
	/* 0x266c: je     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x266c, 0x268b, x86_l_268b);
x86_l_266e:
	/* 0x266e: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2670:
	/* 0x2670: je     268d <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2670, 0x268d, x86_l_268d);
x86_l_2672:
	/* 0x2672: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2675:
	/* 0x2675: jb     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2675, 0x268b, x86_l_268b);
x86_l_2677:
	/* 0x2677: mov    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_267a:
	/* 0x267a: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_267c:
	/* 0x267c: je     268b <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x267c, 0x268b, x86_l_268b);
x86_l_267e:
	/* 0x267e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2680:
	/* 0x2680: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2682:
	/* 0x2682: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2685:
	/* 0x2685: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2689:
	/* 0x2689: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_268a:
	/* 0x268a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_268a);
x86_l_268b:
	/* 0x268b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268d:
	/* 0x268d: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2691:
	/* 0x2691: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2692:
	/* 0x2692: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_268a);

x86_sim_ret_dispatch_4bb:
	switch (__x86_sim_ret_addr) {
	case 0x222ULL: goto x86_l_222;
	case 0x355ULL: goto x86_l_355;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_581:
	switch (__x86_sim_ret_addr) {
	case 0x2b5ULL: goto x86_l_2b5;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_8aa:
	switch (__x86_sim_ret_addr) {
	case 0x2f5ULL: goto x86_l_2f5;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_932:
	switch (__x86_sim_ret_addr) {
	case 0x34eULL: goto x86_l_34e;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_9ab:
	switch (__x86_sim_ret_addr) {
	case 0x364ULL: goto x86_l_364;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_9f2:
	switch (__x86_sim_ret_addr) {
	case 0x36bULL: goto x86_l_36b;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_abe:
	switch (__x86_sim_ret_addr) {
	case 0x377ULL: goto x86_l_377;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_adc:
	switch (__x86_sim_ret_addr) {
	case 0x383ULL: goto x86_l_383;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_b24:
	switch (__x86_sim_ret_addr) {
	case 0xadbULL: goto x86_l_adb;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_e54:
	switch (__x86_sim_ret_addr) {
	case 0xafdULL: goto x86_l_afd;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_f71:
	switch (__x86_sim_ret_addr) {
	case 0xb04ULL: goto x86_l_b04;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_10c9:
	switch (__x86_sim_ret_addr) {
	case 0x525ULL: goto x86_l_525;
	case 0xa64ULL: goto x86_l_a64;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_11ec:
	switch (__x86_sim_ret_addr) {
	case 0x53bULL: goto x86_l_53b;
	case 0x954ULL: goto x86_l_954;
	case 0xa82ULL: goto x86_l_a82;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_15e1:
	switch (__x86_sim_ret_addr) {
	case 0x50fULL: goto x86_l_50f;
	case 0x910ULL: goto x86_l_910;
	case 0xa8cULL: goto x86_l_a8c;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_18df:
	switch (__x86_sim_ret_addr) {
	case 0xa98ULL: goto x86_l_a98;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1905:
	switch (__x86_sim_ret_addr) {
	case 0x9f1ULL: goto x86_l_9f1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1c08:
	switch (__x86_sim_ret_addr) {
	case 0xa13ULL: goto x86_l_a13;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1d1f:
	switch (__x86_sim_ret_addr) {
	case 0xa1aULL: goto x86_l_a1a;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1d59:
	switch (__x86_sim_ret_addr) {
	case 0x9aaULL: goto x86_l_9aa;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2054:
	switch (__x86_sim_ret_addr) {
	case 0x9ccULL: goto x86_l_9cc;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_216a:
	switch (__x86_sim_ret_addr) {
	case 0x89fULL: goto x86_l_89f;
	case 0x988ULL: goto x86_l_988;
	case 0x9d3ULL: goto x86_l_9d3;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_21a4:
	switch (__x86_sim_ret_addr) {
	case 0x580ULL: goto x86_l_580;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_24a7:
	switch (__x86_sim_ret_addr) {
	case 0x5a2ULL: goto x86_l_5a2;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_25be:
	switch (__x86_sim_ret_addr) {
	case 0x5a9ULL: goto x86_l_5a9;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_268a:
	switch (__x86_sim_ret_addr) {
	case 0x4f1ULL: goto x86_l_4f1;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
