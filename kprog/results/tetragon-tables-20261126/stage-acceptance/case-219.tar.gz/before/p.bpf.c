#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 280U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(15) M(17) M(18) M(19) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 kconfig_map[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 stack_pivot_syscalls[] __ksym;
extern __u8 suspicious_syscall_source_syscalls[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 syscall_source_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[12] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x66, 0x69, 0x6c, 0x65, 0x20, 0x62, 0x61, 0x63, 0x6b, 0x65, 0x64, 0x00};
static const __u8 __x86_rodata_1[5] SEC(".rodata.native.1") __attribute__((aligned(16))) = {0x68, 0x65, 0x61, 0x70, 0x00};
static const __u8 __x86_rodata_2[8] SEC(".rodata.native.2") __attribute__((aligned(16))) = {0x75, 0x6e, 0x6b, 0x6e, 0x6f, 0x77, 0x6e, 0x00};
static const __u8 __x86_rodata_3[11] SEC(".rodata.native.3") __attribute__((aligned(16))) = {0x6d, 0x61, 0x69, 0x6e, 0x20, 0x73, 0x74, 0x61, 0x63, 0x6b, 0x00};
static const __u8 __x86_rodata_4[18] SEC(".rodata.native.4") __attribute__((aligned(16))) = {0x67, 0x6f, 0x6c, 0x61, 0x6e, 0x67, 0x20, 0x68, 0x65, 0x61, 0x70, 0x2f, 0x73, 0x74, 0x61, 0x63, 0x6b, 0x00};
static const __u8 __x86_rodata_5[5] SEC(".rodata.native.5") __attribute__((aligned(16))) = {0x76, 0x64, 0x73, 0x6f, 0x00};
static const __u8 __x86_rodata_6[10] SEC(".rodata.native.6") __attribute__((aligned(16))) = {0x61, 0x6e, 0x6f, 0x6e, 0x79, 0x6d, 0x6f, 0x75, 0x73, 0x00};
static const __u8 __x86_rodata_7[13] SEC(".rodata.native.7") __attribute__((aligned(16))) = {0x74, 0x68, 0x72, 0x65, 0x61, 0x64, 0x20, 0x73, 0x74, 0x61, 0x63, 0x6b, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.7\",\"size\":12},{\"proof_section\":\".rodata.native.1\",\"proof_symbol\":\"__x86_rodata_1\",\"native_symbol\":\".L.str.11\",\"size\":5},{\"proof_section\":\".rodata.native.2\",\"proof_symbol\":\"__x86_rodata_2\",\"native_symbol\":\".L.str.14\",\"size\":8},{\"proof_section\":\".rodata.native.3\",\"proof_symbol\":\"__x86_rodata_3\",\"native_symbol\":\".L.str.9\",\"size\":11},{\"proof_section\":\".rodata.native.4\",\"proof_symbol\":\"__x86_rodata_4\",\"native_symbol\":\".L.str.12\",\"size\":18},{\"proof_section\":\".rodata.native.5\",\"proof_symbol\":\"__x86_rodata_5\",\"native_symbol\":\".L.str.13\",\"size\":5},{\"proof_section\":\".rodata.native.6\",\"proof_symbol\":\"__x86_rodata_6\",\"native_symbol\":\".L.str.8\",\"size\":10},{\"proof_section\":\".rodata.native.7\",\"proof_symbol\":\"__x86_rodata_7\",\"native_symbol\":\".L.str.10\",\"size\":13}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

static __always_inline __u64 __x86_rodata_1_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_1 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_1 + offset, width);
}

static __always_inline __u64 __x86_rodata_2_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_2 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_2 + offset, width);
}

static __always_inline __u64 __x86_rodata_3_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_3 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_3 + offset, width);
}

static __always_inline __u64 __x86_rodata_4_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_4 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_4 + offset, width);
}

static __always_inline __u64 __x86_rodata_5_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_5 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_5 + offset, width);
}

static __always_inline __u64 __x86_rodata_6_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_6 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_6 + offset, width);
}

static __always_inline __u64 __x86_rodata_7_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_7 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_7 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_1)) \
       RESULT = __x86_rodata_1_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_1 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_2)) \
       RESULT = __x86_rodata_2_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_2 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_3)) \
       RESULT = __x86_rodata_3_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_3 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_4)) \
       RESULT = __x86_rodata_4_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_4 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_5)) \
       RESULT = __x86_rodata_5_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_5 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_6)) \
       RESULT = __x86_rodata_6_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_6 + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_7)) \
       RESULT = __x86_rodata_7_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_7 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/syscall_checker")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xe8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 232ULL);
x86_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x30],0x3e8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158431208ULL);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)kconfig_map));
x86_l_23:
	/* 0x23: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28:
	/* 0x28: call   2d <syscall_checker+0x2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d:
	/* 0x2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30:
	/* 0x30: je     40 <syscall_checker+0x40> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30, 0x40, x86_l_40);
x86_l_32:
	/* 0x32: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35:
	/* 0x35: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: je     43 <syscall_checker+0x43> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38, 0x43, x86_l_43);
x86_l_3a:
	/* 0x3a: mov    rax,QWORD PTR [r15+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3e:
	/* 0x3e: jmp    43 <syscall_checker+0x43> */
	X86_SIM_X86_JMP(0x3e, 0x43, x86_l_43);
x86_l_40:
	/* 0x40: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_43:
	/* 0x43: mov    QWORD PTR [rsp+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_4b:
	/* 0x4b: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_4f:
	/* 0x4f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52:
	/* 0x52: jns    59 <syscall_checker+0x59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x52, 0x59, x86_l_59);
x86_l_54:
	/* 0x54: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57:
	/* 0x57: jmp    5b <syscall_checker+0x5b> */
	X86_SIM_X86_JMP(0x57, 0x5b, x86_l_5b);
x86_l_59:
	/* 0x59: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5b:
	/* 0x5b: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_62:
	/* 0x62: call   67 <syscall_checker+0x67> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_67:
	/* 0x67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a:
	/* 0x6a: jns    98 <syscall_checker+0x98> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6a, 0x98, x86_l_98);
x86_l_6c:
	/* 0x6c: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e:
	/* 0x6e: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_70:
	/* 0x70: je     98 <syscall_checker+0x98> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70, 0x98, x86_l_98);
x86_l_72:
	/* 0x72: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_79:
	/* 0x79: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_81:
	/* 0x81: call   86 <syscall_checker+0x86> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_86:
	/* 0x86: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89:
	/* 0x89: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x89, 0x332f, x86_l_332f);
x86_l_8f:
	/* 0x8f: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91:
	/* 0x91: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_98:
	/* 0x98: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)suspicious_syscall_source_syscalls));
x86_l_9f:
	/* 0x9f: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_a7:
	/* 0xa7: call   ac <syscall_checker+0xac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ac:
	/* 0xac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af:
	/* 0xaf: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaf, 0xda6, x86_l_da6);
x86_l_b5:
	/* 0xb5: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_bc:
	/* 0xbc: mov    DWORD PTR [rsp+0x80],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c3:
	/* 0xc3: mov    DWORD PTR [rsp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_ce:
	/* 0xce: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_d5:
	/* 0xd5: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_dd:
	/* 0xdd: call   e2 <syscall_checker+0xe2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e2:
	/* 0xe2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e5:
	/* 0xe5: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe5, 0xda6, x86_l_da6);
x86_l_eb:
	/* 0xeb: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ee:
	/* 0xee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_f5:
	/* 0xf5: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_fd:
	/* 0xfd: call   102 <syscall_checker+0x102> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_102:
	/* 0x102: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_105:
	/* 0x105: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x105, 0xda6, x86_l_da6);
x86_l_10b:
	/* 0x10b: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e:
	/* 0x10e: mov    r14,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_111:
	/* 0x111: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_11a:
	/* 0x11a: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_121:
	/* 0x121: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_12c:
	/* 0x12c: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_137:
	/* 0x137: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_142:
	/* 0x142: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_14d:
	/* 0x14d: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_158:
	/* 0x158: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_163:
	/* 0x163: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_16e:
	/* 0x16e: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_179:
	/* 0x179: call   17e <syscall_checker+0x17e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_17e:
	/* 0x17e: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_185:
	/* 0x185: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_18d:
	/* 0x18d: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_195:
	/* 0x195: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_19d:
	/* 0x19d: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1a5:
	/* 0x1a5: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1ad:
	/* 0x1ad: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1b5:
	/* 0x1b5: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1bd:
	/* 0x1bd: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1c5:
	/* 0x1c5: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1cd:
	/* 0x1cd: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1d5:
	/* 0x1d5: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_1dd:
	/* 0x1dd: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1e5:
	/* 0x1e5: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1ed:
	/* 0x1ed: call   1f2 <syscall_checker+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1f2:
	/* 0x1f2: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f5:
	/* 0x1f5: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f9:
	/* 0x1f9: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1fc:
	/* 0x1fc: mov    DWORD PTR [rbp+0x70],0x30e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337934ULL);
x86_l_203:
	/* 0x203: call   208 <syscall_checker+0x208> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_208:
	/* 0x208: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c:
	/* 0x20c: call   211 <syscall_checker+0x211> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_211:
	/* 0x211: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_215:
	/* 0x215: call   21a <syscall_checker+0x21a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_21a:
	/* 0x21a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21d:
	/* 0x21d: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_221:
	/* 0x221: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_224:
	/* 0x224: jns    235 <syscall_checker+0x235> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x224, 0x235, x86_l_235);
x86_l_226:
	/* 0x226: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_228:
	/* 0x228: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_22d:
	/* 0x22d: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_233:
	/* 0x233: jne    272 <syscall_checker+0x272> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x233, 0x272, x86_l_272);
x86_l_235:
	/* 0x235: call   23a <syscall_checker+0x23a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_23a:
	/* 0x23a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23d:
	/* 0x23d: call   242 <syscall_checker+0x242> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_242:
	/* 0x242: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_246:
	/* 0x246: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_249:
	/* 0x249: jns    259 <syscall_checker+0x259> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x249, 0x259, x86_l_259);
x86_l_24b:
	/* 0x24b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e:
	/* 0x24e: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_252:
	/* 0x252: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_255:
	/* 0x255: js     264 <syscall_checker+0x264> */
	X86_SIM_X86_JCC(X86_CC_S, 0x255, 0x264, x86_l_264);
x86_l_257:
	/* 0x257: jmp    26e <syscall_checker+0x26e> */
	X86_SIM_X86_JMP(0x257, 0x26e, x86_l_26e);
x86_l_259:
	/* 0x259: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b:
	/* 0x25b: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25f:
	/* 0x25f: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_262:
	/* 0x262: jns    26e <syscall_checker+0x26e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x262, 0x26e, x86_l_26e);
x86_l_264:
	/* 0x264: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_266:
	/* 0x266: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_268:
	/* 0x268: jne    6fe <syscall_checker+0x6fe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x268, 0x6fe, x86_l_6fe);
x86_l_26e:
	/* 0x26e: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_272:
	/* 0x272: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_276:
	/* 0x276: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_27a:
	/* 0x27a: mov    DWORD PTR [rsp+0x98],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_281:
	/* 0x281: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_288:
	/* 0x288: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_290:
	/* 0x290: call   295 <syscall_checker+0x295> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_295:
	/* 0x295: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_29d:
	/* 0x29d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a0:
	/* 0x2a0: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a5:
	/* 0x2a5: je     20f3 <syscall_checker+0x20f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a5, 0x20f3, x86_l_20f3);
x86_l_2ab:
	/* 0x2ab: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2af:
	/* 0x2af: mov    DWORD PTR [rsp+0xc0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2b6:
	/* 0x2b6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_2bd:
	/* 0x2bd: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2c5:
	/* 0x2c5: call   2ca <syscall_checker+0x2ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ca:
	/* 0x2ca: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cd:
	/* 0x2cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d0:
	/* 0x2d0: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2d5:
	/* 0x2d5: je     2216 <syscall_checker+0x2216> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d5, 0x2216, x86_l_2216);
x86_l_2db:
	/* 0x2db: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_2e1:
	/* 0x2e1: jne    2ea <syscall_checker+0x2ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e1, 0x2ea, x86_l_2ea);
x86_l_2e3:
	/* 0x2e3: call   2e8 <syscall_checker+0x2e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_2e8:
	/* 0x2e8: jmp    342 <syscall_checker+0x342> */
	X86_SIM_X86_JMP(0x2e8, 0x342, x86_l_342);
x86_l_2ea:
	/* 0x2ea: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2ef:
	/* 0x2ef: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_2f6:
	/* 0x2f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: jns    313 <syscall_checker+0x313> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f9, 0x313, x86_l_313);
x86_l_2fb:
	/* 0x2fb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe:
	/* 0x2fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_301:
	/* 0x301: js     31a <syscall_checker+0x31a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x301, 0x31a, x86_l_31a);
x86_l_303:
	/* 0x303: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_305:
	/* 0x305: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_308:
	/* 0x308: js     322 <syscall_checker+0x322> */
	X86_SIM_X86_JCC(X86_CC_S, 0x308, 0x322, x86_l_322);
x86_l_30a:
	/* 0x30a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30c:
	/* 0x30c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30f:
	/* 0x30f: js     32a <syscall_checker+0x32a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30f, 0x32a, x86_l_32a);
x86_l_311:
	/* 0x311: jmp    340 <syscall_checker+0x340> */
	X86_SIM_X86_JMP(0x311, 0x340, x86_l_340);
x86_l_313:
	/* 0x313: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_315:
	/* 0x315: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_318:
	/* 0x318: jns    303 <syscall_checker+0x303> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x318, 0x303, x86_l_303);
x86_l_31a:
	/* 0x31a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d:
	/* 0x31d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_320:
	/* 0x320: jns    30a <syscall_checker+0x30a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x320, 0x30a, x86_l_30a);
x86_l_322:
	/* 0x322: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_325:
	/* 0x325: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_328:
	/* 0x328: jns    340 <syscall_checker+0x340> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x328, 0x340, x86_l_340);
x86_l_32a:
	/* 0x32a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d:
	/* 0x32d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_330:
	/* 0x330: je     340 <syscall_checker+0x340> */
	X86_SIM_X86_JCC(X86_CC_E, 0x330, 0x340, x86_l_340);
x86_l_332:
	/* 0x332: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_336:
	/* 0x336: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_339:
	/* 0x339: jns    340 <syscall_checker+0x340> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x339, 0x340, x86_l_340);
x86_l_33b:
	/* 0x33b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33e:
	/* 0x33e: jmp    342 <syscall_checker+0x342> */
	X86_SIM_X86_JMP(0x33e, 0x342, x86_l_342);
x86_l_340:
	/* 0x340: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_342:
	/* 0x342: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_346:
	/* 0x346: mov    QWORD PTR [r13+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34a:
	/* 0x34a: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_351:
	/* 0x351: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_358:
	/* 0x358: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_360:
	/* 0x360: call   365 <syscall_checker+0x365> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_365:
	/* 0x365: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_368:
	/* 0x368: je     381 <syscall_checker+0x381> */
	X86_SIM_X86_JCC(X86_CC_E, 0x368, 0x381, x86_l_381);
x86_l_36a:
	/* 0x36a: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_36d:
	/* 0x36d: mov    BYTE PTR [r13+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_374:
	/* 0x374: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_377:
	/* 0x377: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_37a:
	/* 0x37a: jne    381 <syscall_checker+0x381> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37a, 0x381, x86_l_381);
x86_l_37c:
	/* 0x37c: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_381:
	/* 0x381: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_386:
	/* 0x386: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_38c:
	/* 0x38c: jne    2358 <syscall_checker+0x2358> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38c, 0x2358, x86_l_2358);
x86_l_392:
	/* 0x392: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_39d:
	/* 0x39d: mov    DWORD PTR [rsp+0x30],0x30e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430990ULL);
x86_l_3a5:
	/* 0x3a5: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3aa:
	/* 0x3aa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_3b1:
	/* 0x3b1: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3b6:
	/* 0x3b6: call   3bb <syscall_checker+0x3bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3bb:
	/* 0x3bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3be:
	/* 0x3be: je     429 <syscall_checker+0x429> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3be, 0x429, x86_l_429);
x86_l_3c0:
	/* 0x3c0: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3c5:
	/* 0x3c5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c8:
	/* 0x3c8: call   3cd <syscall_checker+0x3cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3cd:
	/* 0x3cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d0:
	/* 0x3d0: je     429 <syscall_checker+0x429> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d0, 0x429, x86_l_429);
x86_l_3d2:
	/* 0x3d2: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3d6:
	/* 0x3d6: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_3dd:
	/* 0x3dd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e0:
	/* 0x3e0: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_3e7:
	/* 0x3e7: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3eb:
	/* 0x3eb: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ef:
	/* 0x3ef: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_3f6:
	/* 0x3f6: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_3fd:
	/* 0x3fd: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_401:
	/* 0x401: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_408:
	/* 0x408: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_40c:
	/* 0x40c: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_413:
	/* 0x413: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_417:
	/* 0x417: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_41e:
	/* 0x41e: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_422:
	/* 0x422: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_429:
	/* 0x429: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_430:
	/* 0x430: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_437:
	/* 0x437: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43b:
	/* 0x43b: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_43f:
	/* 0x43f: mov    QWORD PTR [rsp+0x8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_444:
	/* 0x444: jne    45d <syscall_checker+0x45d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x444, 0x45d, x86_l_45d);
x86_l_446:
	/* 0x446: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_448:
	/* 0x448: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_44b:
	/* 0x44b: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_452:
	/* 0x452: jne    cfc <syscall_checker+0xcfc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x452, 0xcfc, x86_l_cfc);
x86_l_458:
	/* 0x458: jmp    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JMP(0x458, 0xda6, x86_l_da6);
x86_l_45d:
	/* 0x45d: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_464:
	/* 0x464: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_467:
	/* 0x467: je     71f <syscall_checker+0x71f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x467, 0x71f, x86_l_71f);
x86_l_46d:
	/* 0x46d: movzx  ecx,BYTE PTR [r13+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_475:
	/* 0x475: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_478:
	/* 0x478: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_47a:
	/* 0x47a: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_47d:
	/* 0x47d: sete   bpl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_481:
	/* 0x481: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_484:
	/* 0x484: neg    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_487:
	/* 0x487: xor    rbp,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_48e:
	/* 0x48e: or     rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_491:
	/* 0x491: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_498:
	/* 0x498: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_49b:
	/* 0x49b: je     4bd <syscall_checker+0x4bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49b, 0x4bd, x86_l_4bd);
x86_l_49d:
	/* 0x49d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49f:
	/* 0x49f: cmp    BYTE PTR [r13+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_4a7:
	/* 0x4a7: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_4aa:
	/* 0x4aa: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4ad:
	/* 0x4ad: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4b0:
	/* 0x4b0: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_4b7:
	/* 0x4b7: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4ba:
	/* 0x4ba: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4bd:
	/* 0x4bd: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_4c4:
	/* 0x4c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c7:
	/* 0x4c7: je     4e3 <syscall_checker+0x4e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c7, 0x4e3, x86_l_4e3);
x86_l_4c9:
	/* 0x4c9: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_4cd:
	/* 0x4cd: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4d0:
	/* 0x4d0: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_4d3:
	/* 0x4d3: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4d6:
	/* 0x4d6: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_4dd:
	/* 0x4dd: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4e0:
	/* 0x4e0: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4e3:
	/* 0x4e3: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_4ea:
	/* 0x4ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ed:
	/* 0x4ed: mov    QWORD PTR [rsp+0xe0],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_4f5:
	/* 0x4f5: je     516 <syscall_checker+0x516> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f5, 0x516, x86_l_516);
x86_l_4f7:
	/* 0x4f7: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4fa:
	/* 0x4fa: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_502:
	/* 0x502: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_506:
	/* 0x506: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_509:
	/* 0x509: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_510:
	/* 0x510: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_513:
	/* 0x513: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_516:
	/* 0x516: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_51b:
	/* 0x51b: mov    r15,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_522:
	/* 0x522: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_525:
	/* 0x525: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_52a:
	/* 0x52a: je     65e <syscall_checker+0x65e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52a, 0x65e, x86_l_65e);
x86_l_530:
	/* 0x530: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_537:
	/* 0x537: mov    QWORD PTR [rsp+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_53f:
	/* 0x53f: mov    r12,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_546:
	/* 0x546: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_54d:
	/* 0x54d: mov    QWORD PTR [rsp+0xd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_555:
	/* 0x555: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_55a:
	/* 0x55a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_561:
	/* 0x561: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_566:
	/* 0x566: call   56b <syscall_checker+0x56b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56b:
	/* 0x56b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56e:
	/* 0x56e: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_572:
	/* 0x572: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_577:
	/* 0x577: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_57e:
	/* 0x57e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_581:
	/* 0x581: mov    QWORD PTR [rsp+0x78],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_586:
	/* 0x586: je     5b3 <syscall_checker+0x5b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x586, 0x5b3, x86_l_5b3);
x86_l_588:
	/* 0x588: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_58d:
	/* 0x58d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_590:
	/* 0x590: call   595 <syscall_checker+0x595> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_595:
	/* 0x595: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_598:
	/* 0x598: je     5b3 <syscall_checker+0x5b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x598, 0x5b3, x86_l_5b3);
x86_l_59a:
	/* 0x59a: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59d:
	/* 0x59d: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5a1:
	/* 0x5a1: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5a4:
	/* 0x5a4: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5a9:
	/* 0x5a9: dec    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_5ac:
	/* 0x5ac: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5af:
	/* 0x5af: jae    5c2 <syscall_checker+0x5c2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5af, 0x5c2, x86_l_5c2);
x86_l_5b1:
	/* 0x5b1: jmp    5e0 <syscall_checker+0x5e0> */
	X86_SIM_X86_JMP(0x5b1, 0x5e0, x86_l_5e0);
x86_l_5b3:
	/* 0x5b3: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5b5:
	/* 0x5b5: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5ba:
	/* 0x5ba: dec    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_5bd:
	/* 0x5bd: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c0:
	/* 0x5c0: jb     5e0 <syscall_checker+0x5e0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5c0, 0x5e0, x86_l_5e0);
x86_l_5c2:
	/* 0x5c2: mov    rcx,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_5ca:
	/* 0x5ca: cmp    rcx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5ce:
	/* 0x5ce: je     5d5 <syscall_checker+0x5d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ce, 0x5d5, x86_l_5d5);
x86_l_5d0:
	/* 0x5d0: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5d3:
	/* 0x5d3: jbe    5e0 <syscall_checker+0x5e0> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5d3, 0x5e0, x86_l_5e0);
x86_l_5d5:
	/* 0x5d5: and    r13,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_5dd:
	/* 0x5dd: or     rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5e0:
	/* 0x5e0: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5e4:
	/* 0x5e4: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5e9:
	/* 0x5e9: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5f0:
	/* 0x5f0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5f3:
	/* 0x5f3: je     620 <syscall_checker+0x620> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f3, 0x620, x86_l_620);
x86_l_5f5:
	/* 0x5f5: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5fa:
	/* 0x5fa: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5fd:
	/* 0x5fd: call   602 <syscall_checker+0x602> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_602:
	/* 0x602: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_605:
	/* 0x605: je     620 <syscall_checker+0x620> */
	X86_SIM_X86_JCC(X86_CC_E, 0x605, 0x620, x86_l_620);
x86_l_607:
	/* 0x607: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60a:
	/* 0x60a: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_60e:
	/* 0x60e: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_611:
	/* 0x611: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_614:
	/* 0x614: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_619:
	/* 0x619: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_61c:
	/* 0x61c: jae    62f <syscall_checker+0x62f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x61c, 0x62f, x86_l_62f);
x86_l_61e:
	/* 0x61e: jmp    64d <syscall_checker+0x64d> */
	X86_SIM_X86_JMP(0x61e, 0x64d, x86_l_64d);
x86_l_620:
	/* 0x620: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_622:
	/* 0x622: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_625:
	/* 0x625: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62a:
	/* 0x62a: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62d:
	/* 0x62d: jb     64d <syscall_checker+0x64d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x62d, 0x64d, x86_l_64d);
x86_l_62f:
	/* 0x62f: mov    rdx,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_637:
	/* 0x637: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_63b:
	/* 0x63b: je     642 <syscall_checker+0x642> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63b, 0x642, x86_l_642);
x86_l_63d:
	/* 0x63d: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_640:
	/* 0x640: jbe    64d <syscall_checker+0x64d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x640, 0x64d, x86_l_64d);
x86_l_642:
	/* 0x642: and    r13,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_64a:
	/* 0x64a: or     rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_64d:
	/* 0x64d: or     rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_650:
	/* 0x650: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_653:
	/* 0x653: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_658:
	/* 0x658: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_65b:
	/* 0x65b: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65e:
	/* 0x65e: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_666:
	/* 0x666: je     757 <syscall_checker+0x757> */
	X86_SIM_X86_JCC(X86_CC_E, 0x666, 0x757, x86_l_757);
x86_l_66c:
	/* 0x66c: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_66f:
	/* 0x66f: call   674 <syscall_checker+0x674> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_674:
	/* 0x674: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_678:
	/* 0x678: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_67f:
	/* 0x67f: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_686:
	/* 0x686: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_68b:
	/* 0x68b: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_692:
	/* 0x692: mov    r12,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_699:
	/* 0x699: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_69e:
	/* 0x69e: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6a3:
	/* 0x6a3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_6aa:
	/* 0x6aa: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6af:
	/* 0x6af: call   6b4 <syscall_checker+0x6b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6b4:
	/* 0x6b4: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6b8:
	/* 0x6b8: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6bd:
	/* 0x6bd: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6c4:
	/* 0x6c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c7:
	/* 0x6c7: je     6e7 <syscall_checker+0x6e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c7, 0x6e7, x86_l_6e7);
x86_l_6c9:
	/* 0x6c9: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6ce:
	/* 0x6ce: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d1:
	/* 0x6d1: call   6d6 <syscall_checker+0x6d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d6:
	/* 0x6d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d9:
	/* 0x6d9: je     6e7 <syscall_checker+0x6e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d9, 0x6e7, x86_l_6e7);
x86_l_6db:
	/* 0x6db: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6de:
	/* 0x6de: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e2:
	/* 0x6e2: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6e5:
	/* 0x6e5: jmp    6e9 <syscall_checker+0x6e9> */
	X86_SIM_X86_JMP(0x6e5, 0x6e9, x86_l_6e9);
x86_l_6e7:
	/* 0x6e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e9:
	/* 0x6e9: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6ec:
	/* 0x6ec: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f1:
	/* 0x6f1: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6f4:
	/* 0x6f4: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f7:
	/* 0x6f7: jae    73b <syscall_checker+0x73b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6f7, 0x73b, x86_l_73b);
x86_l_6f9:
	/* 0x6f9: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6fc:
	/* 0x6fc: jmp    751 <syscall_checker+0x751> */
	X86_SIM_X86_JMP(0x6fc, 0x751, x86_l_751);
x86_l_6fe:
	/* 0x6fe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_705:
	/* 0x705: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_70a:
	/* 0x70a: call   70f <syscall_checker+0x70f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_70f:
	/* 0x70f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_712:
	/* 0x712: je     1ad9 <syscall_checker+0x1ad9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x712, 0x1ad9, x86_l_1ad9);
x86_l_718:
	/* 0x718: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_71a:
	/* 0x71a: jmp    272 <syscall_checker+0x272> */
	X86_SIM_X86_JMP(0x71a, 0x272, x86_l_272);
x86_l_71f:
	/* 0x71f: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_726:
	/* 0x726: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_72d:
	/* 0x72d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_730:
	/* 0x730: jne    49d <syscall_checker+0x49d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x730, 0x49d, x86_l_49d);
x86_l_736:
	/* 0x736: jmp    4bd <syscall_checker+0x4bd> */
	X86_SIM_X86_JMP(0x736, 0x4bd, x86_l_4bd);
x86_l_73b:
	/* 0x73b: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_73f:
	/* 0x73f: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_742:
	/* 0x742: je     749 <syscall_checker+0x749> */
	X86_SIM_X86_JCC(X86_CC_E, 0x742, 0x749, x86_l_749);
x86_l_744:
	/* 0x744: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_747:
	/* 0x747: jbe    751 <syscall_checker+0x751> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x747, 0x751, x86_l_751);
x86_l_749:
	/* 0x749: and    r15,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 120ULL);
x86_l_74e:
	/* 0x74e: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_751:
	/* 0x751: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_754:
	/* 0x754: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_757:
	/* 0x757: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_75f:
	/* 0x75f: je     807 <syscall_checker+0x807> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75f, 0x807, x86_l_807);
x86_l_765:
	/* 0x765: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_76a:
	/* 0x76a: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_771:
	/* 0x771: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_774:
	/* 0x774: jns    77b <syscall_checker+0x77b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x774, 0x77b, x86_l_77b);
x86_l_776:
	/* 0x776: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_779:
	/* 0x779: jmp    77d <syscall_checker+0x77d> */
	X86_SIM_X86_JMP(0x779, 0x77d, x86_l_77d);
x86_l_77b:
	/* 0x77b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77d:
	/* 0x77d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_781:
	/* 0x781: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_783:
	/* 0x783: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_786:
	/* 0x786: jns    792 <syscall_checker+0x792> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x786, 0x792, x86_l_792);
x86_l_788:
	/* 0x788: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_78b:
	/* 0x78b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_78e:
	/* 0x78e: js     799 <syscall_checker+0x799> */
	X86_SIM_X86_JCC(X86_CC_S, 0x78e, 0x799, x86_l_799);
x86_l_790:
	/* 0x790: jmp    79b <syscall_checker+0x79b> */
	X86_SIM_X86_JMP(0x790, 0x79b, x86_l_79b);
x86_l_792:
	/* 0x792: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_794:
	/* 0x794: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_797:
	/* 0x797: jns    79b <syscall_checker+0x79b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x797, 0x79b, x86_l_79b);
x86_l_799:
	/* 0x799: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_79b:
	/* 0x79b: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_79f:
	/* 0x79f: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_7a6:
	/* 0x7a6: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_7ad:
	/* 0x7ad: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7b0:
	/* 0x7b0: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_7b5:
	/* 0x7b5: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7ba:
	/* 0x7ba: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_7c1:
	/* 0x7c1: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7c6:
	/* 0x7c6: call   7cb <syscall_checker+0x7cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7cb:
	/* 0x7cb: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7d2:
	/* 0x7d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d5:
	/* 0x7d5: je     7f9 <syscall_checker+0x7f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d5, 0x7f9, x86_l_7f9);
x86_l_7d7:
	/* 0x7d7: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7dc:
	/* 0x7dc: lea    rsi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7e0:
	/* 0x7e0: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e3:
	/* 0x7e3: call   7e8 <syscall_checker+0x7e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7e8:
	/* 0x7e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7eb:
	/* 0x7eb: je     7f9 <syscall_checker+0x7f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7eb, 0x7f9, x86_l_7f9);
x86_l_7ed:
	/* 0x7ed: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f0:
	/* 0x7f0: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7f4:
	/* 0x7f4: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7f7:
	/* 0x7f7: jmp    7fb <syscall_checker+0x7fb> */
	X86_SIM_X86_JMP(0x7f7, 0x7fb, x86_l_7fb);
x86_l_7f9:
	/* 0x7f9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7fb:
	/* 0x7fb: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7fe:
	/* 0x7fe: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_801:
	/* 0x801: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_804:
	/* 0x804: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_807:
	/* 0x807: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_80f:
	/* 0x80f: je     8db <syscall_checker+0x8db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x80f, 0x8db, x86_l_8db);
x86_l_815:
	/* 0x815: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_81c:
	/* 0x81c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_820:
	/* 0x820: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_822:
	/* 0x822: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_825:
	/* 0x825: jns    834 <syscall_checker+0x834> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x825, 0x834, x86_l_834);
x86_l_827:
	/* 0x827: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_82a:
	/* 0x82a: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_82d:
	/* 0x82d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_830:
	/* 0x830: js     83e <syscall_checker+0x83e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x830, 0x83e, x86_l_83e);
x86_l_832:
	/* 0x832: jmp    840 <syscall_checker+0x840> */
	X86_SIM_X86_JMP(0x832, 0x840, x86_l_840);
x86_l_834:
	/* 0x834: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_836:
	/* 0x836: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_839:
	/* 0x839: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_83c:
	/* 0x83c: jns    840 <syscall_checker+0x840> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83c, 0x840, x86_l_840);
x86_l_83e:
	/* 0x83e: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_840:
	/* 0x840: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_842:
	/* 0x842: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_846:
	/* 0x846: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_849:
	/* 0x849: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_84d:
	/* 0x84d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_84f:
	/* 0x84f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_852:
	/* 0x852: jns    862 <syscall_checker+0x862> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x852, 0x862, x86_l_862);
x86_l_854:
	/* 0x854: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_857:
	/* 0x857: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_85b:
	/* 0x85b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_85e:
	/* 0x85e: js     86d <syscall_checker+0x86d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x85e, 0x86d, x86_l_86d);
x86_l_860:
	/* 0x860: jmp    86f <syscall_checker+0x86f> */
	X86_SIM_X86_JMP(0x860, 0x86f, x86_l_86f);
x86_l_862:
	/* 0x862: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_864:
	/* 0x864: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_868:
	/* 0x868: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_86b:
	/* 0x86b: jns    86f <syscall_checker+0x86f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x86b, 0x86f, x86_l_86f);
x86_l_86d:
	/* 0x86d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86f:
	/* 0x86f: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_873:
	/* 0x873: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_87a:
	/* 0x87a: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_881:
	/* 0x881: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_884:
	/* 0x884: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_889:
	/* 0x889: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_88e:
	/* 0x88e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_895:
	/* 0x895: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_89a:
	/* 0x89a: call   89f <syscall_checker+0x89f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_89f:
	/* 0x89f: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_8a6:
	/* 0x8a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a9:
	/* 0x8a9: je     8cd <syscall_checker+0x8cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a9, 0x8cd, x86_l_8cd);
x86_l_8ab:
	/* 0x8ab: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8b0:
	/* 0x8b0: lea    rsi,[rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8b4:
	/* 0x8b4: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8b7:
	/* 0x8b7: call   8bc <syscall_checker+0x8bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8bc:
	/* 0x8bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8bf:
	/* 0x8bf: je     8cd <syscall_checker+0x8cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8bf, 0x8cd, x86_l_8cd);
x86_l_8c1:
	/* 0x8c1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c4:
	/* 0x8c4: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8c8:
	/* 0x8c8: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8cb:
	/* 0x8cb: jmp    8cf <syscall_checker+0x8cf> */
	X86_SIM_X86_JMP(0x8cb, 0x8cf, x86_l_8cf);
x86_l_8cd:
	/* 0x8cd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8cf:
	/* 0x8cf: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8d2:
	/* 0x8d2: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8d5:
	/* 0x8d5: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8d8:
	/* 0x8d8: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8db:
	/* 0x8db: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_8e3:
	/* 0x8e3: je     abd <syscall_checker+0xabd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e3, 0xabd, x86_l_abd);
x86_l_8e9:
	/* 0x8e9: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8ee:
	/* 0x8ee: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_8f5:
	/* 0x8f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8f8:
	/* 0x8f8: jns    90b <syscall_checker+0x90b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8f8, 0x90b, x86_l_90b);
x86_l_8fa:
	/* 0x8fa: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8fd:
	/* 0x8fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_900:
	/* 0x900: js     912 <syscall_checker+0x912> */
	X86_SIM_X86_JCC(X86_CC_S, 0x900, 0x912, x86_l_912);
x86_l_902:
	/* 0x902: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_904:
	/* 0x904: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_907:
	/* 0x907: js     91a <syscall_checker+0x91a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x907, 0x91a, x86_l_91a);
x86_l_909:
	/* 0x909: jmp    965 <syscall_checker+0x965> */
	X86_SIM_X86_JMP(0x909, 0x965, x86_l_965);
x86_l_90b:
	/* 0x90b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_90d:
	/* 0x90d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_910:
	/* 0x910: jns    902 <syscall_checker+0x902> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x910, 0x902, x86_l_902);
x86_l_912:
	/* 0x912: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_915:
	/* 0x915: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_918:
	/* 0x918: jns    965 <syscall_checker+0x965> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x918, 0x965, x86_l_965);
x86_l_91a:
	/* 0x91a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91d:
	/* 0x91d: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_922:
	/* 0x922: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_926:
	/* 0x926: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_92b:
	/* 0x92b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_92f:
	/* 0x92f: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_934:
	/* 0x934: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_938:
	/* 0x938: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_93d:
	/* 0x93d: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_941:
	/* 0x941: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_946:
	/* 0x946: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_94a:
	/* 0x94a: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_94f:
	/* 0x94f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_953:
	/* 0x953: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_958:
	/* 0x958: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_95c:
	/* 0x95c: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_961:
	/* 0x961: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_965:
	/* 0x965: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_96a:
	/* 0x96a: lea    rbx,[rax+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_96e:
	/* 0x96e: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_973:
	/* 0x973: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_976:
	/* 0x976: jns    a4c <syscall_checker+0xa4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x976, 0xa4c, x86_l_a4c);
x86_l_97c:
	/* 0x97c: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_97f:
	/* 0x97f: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_981:
	/* 0x981: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_983:
	/* 0x983: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x983, 0xa5b, x86_l_a5b);
x86_l_989:
	/* 0x989: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_98d:
	/* 0x98d: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_991:
	/* 0x991: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_993:
	/* 0x993: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x993, 0xa5b, x86_l_a5b);
x86_l_999:
	/* 0x999: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_99d:
	/* 0x99d: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_9a1:
	/* 0x9a1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a3:
	/* 0x9a3: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a3, 0xa5b, x86_l_a5b);
x86_l_9a9:
	/* 0x9a9: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_9ad:
	/* 0x9ad: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_9b1:
	/* 0x9b1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b3:
	/* 0x9b3: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b3, 0xa5b, x86_l_a5b);
x86_l_9b9:
	/* 0x9b9: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_9bd:
	/* 0x9bd: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_9c1:
	/* 0x9c1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9c3:
	/* 0x9c3: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c3, 0xa5b, x86_l_a5b);
x86_l_9c9:
	/* 0x9c9: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_9cd:
	/* 0x9cd: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_9d1:
	/* 0x9d1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d3:
	/* 0x9d3: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d3, 0xa5b, x86_l_a5b);
x86_l_9d9:
	/* 0x9d9: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_9dd:
	/* 0x9dd: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_9e1:
	/* 0x9e1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9e3:
	/* 0x9e3: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e3, 0xa5b, x86_l_a5b);
x86_l_9e5:
	/* 0x9e5: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_9e9:
	/* 0x9e9: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_9ed:
	/* 0x9ed: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9ef:
	/* 0x9ef: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ef, 0xa5b, x86_l_a5b);
x86_l_9f1:
	/* 0x9f1: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_9f5:
	/* 0x9f5: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_9f9:
	/* 0x9f9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9fb:
	/* 0x9fb: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9fb, 0xa5b, x86_l_a5b);
x86_l_9fd:
	/* 0x9fd: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_a01:
	/* 0xa01: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_a05:
	/* 0xa05: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a07:
	/* 0xa07: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa07, 0xa5b, x86_l_a5b);
x86_l_a09:
	/* 0xa09: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_a0d:
	/* 0xa0d: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_a11:
	/* 0xa11: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a13:
	/* 0xa13: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa13, 0xa5b, x86_l_a5b);
x86_l_a15:
	/* 0xa15: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_a19:
	/* 0xa19: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_a1d:
	/* 0xa1d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a1f:
	/* 0xa1f: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa1f, 0xa5b, x86_l_a5b);
x86_l_a21:
	/* 0xa21: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_a25:
	/* 0xa25: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_a29:
	/* 0xa29: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a2b:
	/* 0xa2b: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa2b, 0xa5b, x86_l_a5b);
x86_l_a2d:
	/* 0xa2d: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_a31:
	/* 0xa31: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_a35:
	/* 0xa35: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a37:
	/* 0xa37: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa37, 0xa5b, x86_l_a5b);
x86_l_a39:
	/* 0xa39: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_a3d:
	/* 0xa3d: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_a41:
	/* 0xa41: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_a43:
	/* 0xa43: je     a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa43, 0xa5b, x86_l_a5b);
x86_l_a45:
	/* 0xa45: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_a4a:
	/* 0xa4a: jmp    a5b <syscall_checker+0xa5b> */
	X86_SIM_X86_JMP(0xa4a, 0xa5b, x86_l_a5b);
x86_l_a4c:
	/* 0xa4c: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a54:
	/* 0xa54: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a5b:
	/* 0xa5b: mov    r15,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a62:
	/* 0xa62: mov    r12,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a69:
	/* 0xa69: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a6c:
	/* 0xa6c: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_a71:
	/* 0xa71: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a76:
	/* 0xa76: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a7d:
	/* 0xa7d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a82:
	/* 0xa82: call   a87 <syscall_checker+0xa87> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a87:
	/* 0xa87: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a8e:
	/* 0xa8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a91:
	/* 0xa91: je     aaf <syscall_checker+0xaaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa91, 0xaaf, x86_l_aaf);
x86_l_a93:
	/* 0xa93: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a96:
	/* 0xa96: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a99:
	/* 0xa99: call   a9e <syscall_checker+0xa9e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a9e:
	/* 0xa9e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aa1:
	/* 0xaa1: je     aaf <syscall_checker+0xaaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaa1, 0xaaf, x86_l_aaf);
x86_l_aa3:
	/* 0xaa3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aa6:
	/* 0xaa6: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aaa:
	/* 0xaaa: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_aad:
	/* 0xaad: jmp    ab1 <syscall_checker+0xab1> */
	X86_SIM_X86_JMP(0xaad, 0xab1, x86_l_ab1);
x86_l_aaf:
	/* 0xaaf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ab1:
	/* 0xab1: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ab4:
	/* 0xab4: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ab7:
	/* 0xab7: or     r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_aba:
	/* 0xaba: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_abd:
	/* 0xabd: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_ac5:
	/* 0xac5: movzx  r13d,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_acb:
	/* 0xacb: je     b41 <syscall_checker+0xb41> */
	X86_SIM_X86_JCC(X86_CC_E, 0xacb, 0xb41, x86_l_b41);
x86_l_acd:
	/* 0xacd: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ad2:
	/* 0xad2: lea    rbx,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_ad6:
	/* 0xad6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ad9:
	/* 0xad9: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_ade:
	/* 0xade: call   ae3 <syscall_checker+0xae3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_ae3:
	/* 0xae3: mov    r15,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_aea:
	/* 0xaea: mov    r12,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_af1:
	/* 0xaf1: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_af4:
	/* 0xaf4: mov    WORD PTR [rsp+0x30],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_afa:
	/* 0xafa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_b01:
	/* 0xb01: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b06:
	/* 0xb06: call   b0b <syscall_checker+0xb0b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b0b:
	/* 0xb0b: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b12:
	/* 0xb12: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b15:
	/* 0xb15: je     b33 <syscall_checker+0xb33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb15, 0xb33, x86_l_b33);
x86_l_b17:
	/* 0xb17: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1a:
	/* 0xb1a: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b1d:
	/* 0xb1d: call   b22 <syscall_checker+0xb22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b22:
	/* 0xb22: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b25:
	/* 0xb25: je     b33 <syscall_checker+0xb33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb25, 0xb33, x86_l_b33);
x86_l_b27:
	/* 0xb27: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b2a:
	/* 0xb2a: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b2e:
	/* 0xb2e: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b31:
	/* 0xb31: jmp    b35 <syscall_checker+0xb35> */
	X86_SIM_X86_JMP(0xb31, 0xb35, x86_l_b35);
x86_l_b33:
	/* 0xb33: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b35:
	/* 0xb35: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b38:
	/* 0xb38: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b3b:
	/* 0xb3b: or     r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b3e:
	/* 0xb3e: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b41:
	/* 0xb41: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b48:
	/* 0xb48: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b4b:
	/* 0xb4b: je     bb8 <syscall_checker+0xbb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4b, 0xbb8, x86_l_bb8);
x86_l_b4d:
	/* 0xb4d: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b51:
	/* 0xb51: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b55:
	/* 0xb55: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b5c:
	/* 0xb5c: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b5f:
	/* 0xb5f: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_b64:
	/* 0xb64: mov    WORD PTR [rsp+0xa8],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_b6c:
	/* 0xb6c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b73:
	/* 0xb73: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_b7b:
	/* 0xb7b: call   b80 <syscall_checker+0xb80> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b80:
	/* 0xb80: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b87:
	/* 0xb87: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8a:
	/* 0xb8a: je     baa <syscall_checker+0xbaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8a, 0xbaa, x86_l_baa);
x86_l_b8c:
	/* 0xb8c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b91:
	/* 0xb91: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b94:
	/* 0xb94: call   b99 <syscall_checker+0xb99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b99:
	/* 0xb99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b9c:
	/* 0xb9c: je     baa <syscall_checker+0xbaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9c, 0xbaa, x86_l_baa);
x86_l_b9e:
	/* 0xb9e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ba1:
	/* 0xba1: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ba5:
	/* 0xba5: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ba8:
	/* 0xba8: jmp    bac <syscall_checker+0xbac> */
	X86_SIM_X86_JMP(0xba8, 0xbac, x86_l_bac);
x86_l_baa:
	/* 0xbaa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bac:
	/* 0xbac: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_baf:
	/* 0xbaf: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bb2:
	/* 0xbb2: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bb5:
	/* 0xbb5: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bb8:
	/* 0xbb8: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_bbf:
	/* 0xbbf: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bc2:
	/* 0xbc2: je     c25 <syscall_checker+0xc25> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc2, 0xc25, x86_l_c25);
x86_l_bc4:
	/* 0xbc4: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_bcb:
	/* 0xbcb: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bce:
	/* 0xbce: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_bd3:
	/* 0xbd3: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bd8:
	/* 0xbd8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_bdf:
	/* 0xbdf: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_be4:
	/* 0xbe4: call   be9 <syscall_checker+0xbe9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_be9:
	/* 0xbe9: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bf0:
	/* 0xbf0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bf3:
	/* 0xbf3: je     c17 <syscall_checker+0xc17> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf3, 0xc17, x86_l_c17);
x86_l_bf5:
	/* 0xbf5: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_bfa:
	/* 0xbfa: lea    rsi,[rcx+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_bfe:
	/* 0xbfe: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c01:
	/* 0xc01: call   c06 <syscall_checker+0xc06> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c06:
	/* 0xc06: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c09:
	/* 0xc09: je     c17 <syscall_checker+0xc17> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc09, 0xc17, x86_l_c17);
x86_l_c0b:
	/* 0xc0b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c0e:
	/* 0xc0e: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c12:
	/* 0xc12: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c15:
	/* 0xc15: jmp    c19 <syscall_checker+0xc19> */
	X86_SIM_X86_JMP(0xc15, 0xc19, x86_l_c19);
x86_l_c17:
	/* 0xc17: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c19:
	/* 0xc19: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c1c:
	/* 0xc1c: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c1f:
	/* 0xc1f: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c22:
	/* 0xc22: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c25:
	/* 0xc25: mov    r15,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c2c:
	/* 0xc2c: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c2f:
	/* 0xc2f: je     cbb <syscall_checker+0xcbb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc2f, 0xcbb, x86_l_cbb);
x86_l_c35:
	/* 0xc35: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c38:
	/* 0xc38: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c3f:
	/* 0xc3f: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c42:
	/* 0xc42: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_c47:
	/* 0xc47: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c4c:
	/* 0xc4c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_c53:
	/* 0xc53: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c58:
	/* 0xc58: call   c5d <syscall_checker+0xc5d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c5d:
	/* 0xc5d: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c64:
	/* 0xc64: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c67:
	/* 0xc67: je     caa <syscall_checker+0xcaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc67, 0xcaa, x86_l_caa);
x86_l_c69:
	/* 0xc69: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6c:
	/* 0xc6c: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c74:
	/* 0xc74: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_c78:
	/* 0xc78: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c7b:
	/* 0xc7b: call   c80 <syscall_checker+0xc80> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c80:
	/* 0xc80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c83:
	/* 0xc83: jne    c9e <syscall_checker+0xc9e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc83, 0xc9e, x86_l_c9e);
x86_l_c85:
	/* 0xc85: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c8d:
	/* 0xc8d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c91:
	/* 0xc91: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c94:
	/* 0xc94: call   c99 <syscall_checker+0xc99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c99:
	/* 0xc99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c9c:
	/* 0xc9c: je     caa <syscall_checker+0xcaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc9c, 0xcaa, x86_l_caa);
x86_l_c9e:
	/* 0xc9e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ca1:
	/* 0xca1: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca5:
	/* 0xca5: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ca8:
	/* 0xca8: jmp    cac <syscall_checker+0xcac> */
	X86_SIM_X86_JMP(0xca8, 0xcac, x86_l_cac);
x86_l_caa:
	/* 0xcaa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cac:
	/* 0xcac: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_caf:
	/* 0xcaf: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cb2:
	/* 0xcb2: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cb5:
	/* 0xcb5: and    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cb8:
	/* 0xcb8: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cbb:
	/* 0xcbb: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_cc2:
	/* 0xcc2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc5:
	/* 0xcc5: mov    r15,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_ccd:
	/* 0xccd: je     cde <syscall_checker+0xcde> */
	X86_SIM_X86_JCC(X86_CC_E, 0xccd, 0xcde, x86_l_cde);
x86_l_ccf:
	/* 0xccf: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_cd7:
	/* 0xcd7: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_cdb:
	/* 0xcdb: or     rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cde:
	/* 0xcde: and    rbp,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_ce5:
	/* 0xce5: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cec:
	/* 0xcec: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cef:
	/* 0xcef: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cf6:
	/* 0xcf6: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcf6, 0xda6, x86_l_da6);
x86_l_cfc:
	/* 0xcfc: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_d04:
	/* 0xd04: mov    rax,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d0b:
	/* 0xd0b: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d10:
	/* 0xd10: call   d15 <syscall_checker+0xd15> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_d15:
	/* 0xd15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d18:
	/* 0xd18: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd18, 0xda6, x86_l_da6);
x86_l_d1e:
	/* 0xd1e: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d23:
	/* 0xd23: lea    rdx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d27:
	/* 0xd27: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d2a:
	/* 0xd2a: jns    d36 <syscall_checker+0xd36> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd2a, 0xd36, x86_l_d36);
x86_l_d2c:
	/* 0xd2c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d2f:
	/* 0xd2f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d32:
	/* 0xd32: js     d3d <syscall_checker+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd32, 0xd3d, x86_l_d3d);
x86_l_d34:
	/* 0xd34: jmp    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JMP(0xd34, 0xda6, x86_l_da6);
x86_l_d36:
	/* 0xd36: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d38:
	/* 0xd38: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d3b:
	/* 0xd3b: jns    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd3b, 0xda6, x86_l_da6);
x86_l_d3d:
	/* 0xd3d: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d40:
	/* 0xd40: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d43:
	/* 0xd43: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd43, 0xda6, x86_l_da6);
x86_l_d45:
	/* 0xd45: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d4a:
	/* 0xd4a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d4e:
	/* 0xd4e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d50:
	/* 0xd50: lea    rbp,[r12-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_d55:
	/* 0xd55: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_d58:
	/* 0xd58: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_d5b:
	/* 0xd5b: jns    d62 <syscall_checker+0xd62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd5b, 0xd62, x86_l_d62);
x86_l_d5d:
	/* 0xd5d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d60:
	/* 0xd60: jmp    d64 <syscall_checker+0xd64> */
	X86_SIM_X86_JMP(0xd60, 0xd64, x86_l_d64);
x86_l_d62:
	/* 0xd62: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d64:
	/* 0xd64: lea    r13,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_d69:
	/* 0xd69: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d6c:
	/* 0xd6c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d6f:
	/* 0xd6f: jns    d91 <syscall_checker+0xd91> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd6f, 0xd91, x86_l_d91);
x86_l_d71:
	/* 0xd71: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d74:
	/* 0xd74: cmp    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d77:
	/* 0xd77: jbe    d91 <syscall_checker+0xd91> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xd77, 0xd91, x86_l_d91);
x86_l_d79:
	/* 0xd79: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d7c:
	/* 0xd7c: jbe    1aed <syscall_checker+0x1aed> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xd7c, 0x1aed, x86_l_1aed);
x86_l_d82:
	/* 0xd82: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_d86:
	/* 0xd86: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d89:
	/* 0xd89: jns    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd89, 0xda6, x86_l_da6);
x86_l_d8b:
	/* 0xd8b: mov    r12,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d8f:
	/* 0xd8f: jmp    d9a <syscall_checker+0xd9a> */
	X86_SIM_X86_JMP(0xd8f, 0xd9a, x86_l_d9a);
x86_l_d91:
	/* 0xd91: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d94:
	/* 0xd94: jns    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd94, 0xda6, x86_l_da6);
x86_l_d96:
	/* 0xd96: mov    r12,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d9a:
	/* 0xd9a: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_d9d:
	/* 0xd9d: ja     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd9d, 0xda6, x86_l_da6);
x86_l_d9f:
	/* 0xd9f: inc    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_da1:
	/* 0xda1: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_da4:
	/* 0xda4: jne    d50 <syscall_checker+0xd50> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xda4, 0xd50, x86_l_d50);
x86_l_da6:
	/* 0xda6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_pivot_syscalls));
x86_l_dad:
	/* 0xdad: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_db5:
	/* 0xdb5: call   dba <syscall_checker+0xdba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_dba:
	/* 0xdba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dbd:
	/* 0xdbd: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdbd, 0x332f, x86_l_332f);
x86_l_dc3:
	/* 0xdc3: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_dca:
	/* 0xdca: mov    DWORD PTR [rsp+0x80],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_dd1:
	/* 0xdd1: mov    DWORD PTR [rsp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_ddc:
	/* 0xddc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_de3:
	/* 0xde3: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_deb:
	/* 0xdeb: call   df0 <syscall_checker+0xdf0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_df0:
	/* 0xdf0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_df3:
	/* 0xdf3: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf3, 0x332f, x86_l_332f);
x86_l_df9:
	/* 0xdf9: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dfc:
	/* 0xdfc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_e03:
	/* 0xe03: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_e0b:
	/* 0xe0b: call   e10 <syscall_checker+0xe10> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e10:
	/* 0xe10: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e13:
	/* 0xe13: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe13, 0x332f, x86_l_332f);
x86_l_e19:
	/* 0xe19: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e1c:
	/* 0xe1c: mov    QWORD PTR [rsp+0x20],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e21:
	/* 0xe21: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_e2b:
	/* 0xe2b: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_e33:
	/* 0xe33: mov    QWORD PTR [r14+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_e3e:
	/* 0xe3e: mov    QWORD PTR [r14+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_e49:
	/* 0xe49: mov    QWORD PTR [r14+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_e54:
	/* 0xe54: mov    QWORD PTR [r14+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_e5f:
	/* 0xe5f: mov    QWORD PTR [r14+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_e6a:
	/* 0xe6a: mov    QWORD PTR [r14+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_e75:
	/* 0xe75: mov    QWORD PTR [r14+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_e80:
	/* 0xe80: mov    QWORD PTR [r14+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_e8b:
	/* 0xe8b: call   e90 <syscall_checker+0xe90> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_e90:
	/* 0xe90: mov    QWORD PTR [r14+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_e97:
	/* 0xe97: mov    QWORD PTR [r14+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e9f:
	/* 0xe9f: mov    QWORD PTR [r14+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_ea7:
	/* 0xea7: mov    QWORD PTR [r14+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_eaf:
	/* 0xeaf: mov    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_eb7:
	/* 0xeb7: mov    QWORD PTR [r14+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_ebf:
	/* 0xebf: mov    QWORD PTR [r14+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_ec7:
	/* 0xec7: mov    QWORD PTR [r14+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_ecf:
	/* 0xecf: mov    QWORD PTR [r14+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_ed7:
	/* 0xed7: mov    QWORD PTR [r14+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_edf:
	/* 0xedf: mov    QWORD PTR [r14+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_ee7:
	/* 0xee7: mov    QWORD PTR [r14+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_eef:
	/* 0xeef: mov    QWORD PTR [r14+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_ef7:
	/* 0xef7: mov    QWORD PTR [r14+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_eff:
	/* 0xeff: call   f04 <syscall_checker+0xf04> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_f04:
	/* 0xf04: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_f08:
	/* 0xf08: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_f0c:
	/* 0xf0c: mov    DWORD PTR [r14+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_f10:
	/* 0xf10: mov    DWORD PTR [r14+0x70],0x30f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337935ULL);
x86_l_f18:
	/* 0xf18: call   f1d <syscall_checker+0xf1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_f1d:
	/* 0xf1d: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f20:
	/* 0xf20: call   f25 <syscall_checker+0xf25> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_f25:
	/* 0xf25: mov    WORD PTR [r14+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_f2a:
	/* 0xf2a: call   f2f <syscall_checker+0xf2f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_f2f:
	/* 0xf2f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f32:
	/* 0xf32: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_f36:
	/* 0xf36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f39:
	/* 0xf39: jns    f4a <syscall_checker+0xf4a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf39, 0xf4a, x86_l_f4a);
x86_l_f3b:
	/* 0xf3b: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3d:
	/* 0xf3d: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_f42:
	/* 0xf42: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_f48:
	/* 0xf48: jne    f87 <syscall_checker+0xf87> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf48, 0xf87, x86_l_f87);
x86_l_f4a:
	/* 0xf4a: call   f4f <syscall_checker+0xf4f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_f4f:
	/* 0xf4f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f52:
	/* 0xf52: call   f57 <syscall_checker+0xf57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_f57:
	/* 0xf57: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_f5b:
	/* 0xf5b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f5e:
	/* 0xf5e: jns    f6e <syscall_checker+0xf6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf5e, 0xf6e, x86_l_f6e);
x86_l_f60:
	/* 0xf60: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f63:
	/* 0xf63: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f67:
	/* 0xf67: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f6a:
	/* 0xf6a: js     f79 <syscall_checker+0xf79> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf6a, 0xf79, x86_l_f79);
x86_l_f6c:
	/* 0xf6c: jmp    f83 <syscall_checker+0xf83> */
	X86_SIM_X86_JMP(0xf6c, 0xf83, x86_l_f83);
x86_l_f6e:
	/* 0xf6e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f70:
	/* 0xf70: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f74:
	/* 0xf74: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f77:
	/* 0xf77: jns    f83 <syscall_checker+0xf83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf77, 0xf83, x86_l_f83);
x86_l_f79:
	/* 0xf79: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7b:
	/* 0xf7b: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_f7d:
	/* 0xf7d: jne    1316 <syscall_checker+0x1316> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf7d, 0x1316, x86_l_1316);
x86_l_f83:
	/* 0xf83: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f87:
	/* 0xf87: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_f8b:
	/* 0xf8b: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_f8f:
	/* 0xf8f: mov    DWORD PTR [rsp+0x98],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_f96:
	/* 0xf96: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_f9d:
	/* 0xf9d: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_fa5:
	/* 0xfa5: call   faa <syscall_checker+0xfaa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_faa:
	/* 0xfaa: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_fb2:
	/* 0xfb2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fb5:
	/* 0xfb5: je     2187 <syscall_checker+0x2187> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb5, 0x2187, x86_l_2187);
x86_l_fbb:
	/* 0xfbb: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_fbf:
	/* 0xfbf: mov    DWORD PTR [rsp+0xc0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_fc6:
	/* 0xfc6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_fcd:
	/* 0xfcd: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_fd5:
	/* 0xfd5: call   fda <syscall_checker+0xfda> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fda:
	/* 0xfda: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fdd:
	/* 0xfdd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fe0:
	/* 0xfe0: mov    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fe5:
	/* 0xfe5: je     22b7 <syscall_checker+0x22b7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe5, 0x22b7, x86_l_22b7);
x86_l_feb:
	/* 0xfeb: test   BYTE PTR [rbp+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_fef:
	/* 0xfef: jne    ff8 <syscall_checker+0xff8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfef, 0xff8, x86_l_ff8);
x86_l_ff1:
	/* 0xff1: call   ff6 <syscall_checker+0xff6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_ff6:
	/* 0xff6: jmp    1050 <syscall_checker+0x1050> */
	X86_SIM_X86_JMP(0xff6, 0x1050, x86_l_1050);
x86_l_ff8:
	/* 0xff8: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_ffd:
	/* 0xffd: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_1004:
	/* 0x1004: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1007:
	/* 0x1007: jns    1021 <syscall_checker+0x1021> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1007, 0x1021, x86_l_1021);
x86_l_1009:
	/* 0x1009: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_100c:
	/* 0x100c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_100f:
	/* 0x100f: js     1028 <syscall_checker+0x1028> */
	X86_SIM_X86_JCC(X86_CC_S, 0x100f, 0x1028, x86_l_1028);
x86_l_1011:
	/* 0x1011: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1013:
	/* 0x1013: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1016:
	/* 0x1016: js     1030 <syscall_checker+0x1030> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1016, 0x1030, x86_l_1030);
x86_l_1018:
	/* 0x1018: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_101a:
	/* 0x101a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_101d:
	/* 0x101d: js     1038 <syscall_checker+0x1038> */
	X86_SIM_X86_JCC(X86_CC_S, 0x101d, 0x1038, x86_l_1038);
x86_l_101f:
	/* 0x101f: jmp    104e <syscall_checker+0x104e> */
	X86_SIM_X86_JMP(0x101f, 0x104e, x86_l_104e);
x86_l_1021:
	/* 0x1021: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1023:
	/* 0x1023: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1026:
	/* 0x1026: jns    1011 <syscall_checker+0x1011> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1026, 0x1011, x86_l_1011);
x86_l_1028:
	/* 0x1028: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_102b:
	/* 0x102b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_102e:
	/* 0x102e: jns    1018 <syscall_checker+0x1018> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x102e, 0x1018, x86_l_1018);
x86_l_1030:
	/* 0x1030: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1033:
	/* 0x1033: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1036:
	/* 0x1036: jns    104e <syscall_checker+0x104e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1036, 0x104e, x86_l_104e);
x86_l_1038:
	/* 0x1038: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_103b:
	/* 0x103b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_103e:
	/* 0x103e: je     104e <syscall_checker+0x104e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x103e, 0x104e, x86_l_104e);
x86_l_1040:
	/* 0x1040: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1044:
	/* 0x1044: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1047:
	/* 0x1047: jns    104e <syscall_checker+0x104e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1047, 0x104e, x86_l_104e);
x86_l_1049:
	/* 0x1049: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_104c:
	/* 0x104c: jmp    1050 <syscall_checker+0x1050> */
	X86_SIM_X86_JMP(0x104c, 0x1050, x86_l_1050);
x86_l_104e:
	/* 0x104e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1050:
	/* 0x1050: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1054:
	/* 0x1054: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1059:
	/* 0x1059: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1060:
	/* 0x1060: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_1067:
	/* 0x1067: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_106f:
	/* 0x106f: call   1074 <syscall_checker+0x1074> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1074:
	/* 0x1074: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1077:
	/* 0x1077: je     1091 <syscall_checker+0x1091> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1077, 0x1091, x86_l_1091);
x86_l_1079:
	/* 0x1079: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_107c:
	/* 0x107c: mov    BYTE PTR [r12+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_1084:
	/* 0x1084: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_1087:
	/* 0x1087: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_108a:
	/* 0x108a: jne    1091 <syscall_checker+0x1091> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x108a, 0x1091, x86_l_1091);
x86_l_108c:
	/* 0x108c: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_1091:
	/* 0x1091: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_1096:
	/* 0x1096: cmp    ax,WORD PTR [rbp+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_109a:
	/* 0x109a: jne    2507 <syscall_checker+0x2507> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x109a, 0x2507, x86_l_2507);
x86_l_10a0:
	/* 0x10a0: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_10ab:
	/* 0x10ab: mov    DWORD PTR [rsp+0x30],0x30f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430991ULL);
x86_l_10b3:
	/* 0x10b3: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_10b8:
	/* 0x10b8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_10bf:
	/* 0x10bf: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_10c4:
	/* 0x10c4: call   10c9 <syscall_checker+0x10c9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10c9:
	/* 0x10c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10cc:
	/* 0x10cc: je     1137 <syscall_checker+0x1137> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10cc, 0x1137, x86_l_1137);
x86_l_10ce:
	/* 0x10ce: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10d3:
	/* 0x10d3: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10d6:
	/* 0x10d6: call   10db <syscall_checker+0x10db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10db:
	/* 0x10db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10de:
	/* 0x10de: je     1137 <syscall_checker+0x1137> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10de, 0x1137, x86_l_1137);
x86_l_10e0:
	/* 0x10e0: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10e4:
	/* 0x10e4: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_10eb:
	/* 0x10eb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10ee:
	/* 0x10ee: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_10f5:
	/* 0x10f5: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10f9:
	/* 0x10f9: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_10fd:
	/* 0x10fd: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_1104:
	/* 0x1104: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_110b:
	/* 0x110b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_110f:
	/* 0x110f: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_1116:
	/* 0x1116: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_111a:
	/* 0x111a: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_1121:
	/* 0x1121: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1125:
	/* 0x1125: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_112c:
	/* 0x112c: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1130:
	/* 0x1130: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_1137:
	/* 0x1137: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_113e:
	/* 0x113e: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1145:
	/* 0x1145: mov    ecx,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1148:
	/* 0x1148: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_114c:
	/* 0x114c: mov    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1151:
	/* 0x1151: jne    116a <syscall_checker+0x116a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1151, 0x116a, x86_l_116a);
x86_l_1153:
	/* 0x1153: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1155:
	/* 0x1155: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1158:
	/* 0x1158: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_115f:
	/* 0x115f: jne    1a0d <syscall_checker+0x1a0d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x115f, 0x1a0d, x86_l_1a0d);
x86_l_1165:
	/* 0x1165: jmp    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JMP(0x1165, 0x332f, x86_l_332f);
x86_l_116a:
	/* 0x116a: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_1171:
	/* 0x1171: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1174:
	/* 0x1174: je     1337 <syscall_checker+0x1337> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1174, 0x1337, x86_l_1337);
x86_l_117a:
	/* 0x117a: movzx  ecx,BYTE PTR [r12+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_1183:
	/* 0x1183: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_1186:
	/* 0x1186: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1188:
	/* 0x1188: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_118b:
	/* 0x118b: sete   bpl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_118f:
	/* 0x118f: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1192:
	/* 0x1192: neg    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1195:
	/* 0x1195: xor    rbp,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_119c:
	/* 0x119c: or     rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_119f:
	/* 0x119f: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_11a6:
	/* 0x11a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11a9:
	/* 0x11a9: je     11cc <syscall_checker+0x11cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11a9, 0x11cc, x86_l_11cc);
x86_l_11ab:
	/* 0x11ab: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11ad:
	/* 0x11ad: cmp    BYTE PTR [r12+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_11b6:
	/* 0x11b6: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_11b9:
	/* 0x11b9: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_11bc:
	/* 0x11bc: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_11bf:
	/* 0x11bf: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_11c6:
	/* 0x11c6: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_11c9:
	/* 0x11c9: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_11cc:
	/* 0x11cc: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_11d3:
	/* 0x11d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11d6:
	/* 0x11d6: je     11f2 <syscall_checker+0x11f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d6, 0x11f2, x86_l_11f2);
x86_l_11d8:
	/* 0x11d8: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_11dc:
	/* 0x11dc: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_11df:
	/* 0x11df: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_11e2:
	/* 0x11e2: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_11e5:
	/* 0x11e5: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_11ec:
	/* 0x11ec: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_11ef:
	/* 0x11ef: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_11f2:
	/* 0x11f2: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_11f9:
	/* 0x11f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11fc:
	/* 0x11fc: mov    QWORD PTR [rsp+0xe0],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1204:
	/* 0x1204: je     1225 <syscall_checker+0x1225> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1204, 0x1225, x86_l_1225);
x86_l_1206:
	/* 0x1206: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1209:
	/* 0x1209: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1211:
	/* 0x1211: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1215:
	/* 0x1215: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1218:
	/* 0x1218: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_121f:
	/* 0x121f: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1222:
	/* 0x1222: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1225:
	/* 0x1225: movzx  r13d,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_122a:
	/* 0x122a: mov    r15,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1231:
	/* 0x1231: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1234:
	/* 0x1234: mov    WORD PTR [rsp+0x18],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_123a:
	/* 0x123a: je     13ae <syscall_checker+0x13ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x123a, 0x13ae, x86_l_13ae);
x86_l_1240:
	/* 0x1240: mov    rax,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_1247:
	/* 0x1247: mov    QWORD PTR [rsp+0xd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_124f:
	/* 0x124f: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1252:
	/* 0x1252: mov    r13,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1259:
	/* 0x1259: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_1260:
	/* 0x1260: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1265:
	/* 0x1265: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_126a:
	/* 0x126a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_1271:
	/* 0x1271: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1276:
	/* 0x1276: call   127b <syscall_checker+0x127b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_127b:
	/* 0x127b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_127e:
	/* 0x127e: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1282:
	/* 0x1282: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1287:
	/* 0x1287: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_128e:
	/* 0x128e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1291:
	/* 0x1291: mov    QWORD PTR [rsp+0xd8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1299:
	/* 0x1299: je     12b9 <syscall_checker+0x12b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1299, 0x12b9, x86_l_12b9);
x86_l_129b:
	/* 0x129b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12a0:
	/* 0x12a0: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12a3:
	/* 0x12a3: call   12a8 <syscall_checker+0x12a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12a8:
	/* 0x12a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ab:
	/* 0x12ab: je     12b9 <syscall_checker+0x12b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12ab, 0x12b9, x86_l_12b9);
x86_l_12ad:
	/* 0x12ad: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b0:
	/* 0x12b0: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12b4:
	/* 0x12b4: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_12b7:
	/* 0x12b7: jmp    12bb <syscall_checker+0x12bb> */
	X86_SIM_X86_JMP(0x12b7, 0x12bb, x86_l_12bb);
x86_l_12b9:
	/* 0x12b9: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12bb:
	/* 0x12bb: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_12c0:
	/* 0x12c0: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12c5:
	/* 0x12c5: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_12c8:
	/* 0x12c8: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12cb:
	/* 0x12cb: jb     12e3 <syscall_checker+0x12e3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x12cb, 0x12e3, x86_l_12e3);
x86_l_12cd:
	/* 0x12cd: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_12d1:
	/* 0x12d1: je     12d8 <syscall_checker+0x12d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d1, 0x12d8, x86_l_12d8);
x86_l_12d3:
	/* 0x12d3: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12d6:
	/* 0x12d6: jbe    12e3 <syscall_checker+0x12e3> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x12d6, 0x12e3, x86_l_12e3);
x86_l_12d8:
	/* 0x12d8: and    r12,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_12e0:
	/* 0x12e0: or     rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_12e3:
	/* 0x12e3: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12e7:
	/* 0x12e7: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12ec:
	/* 0x12ec: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_12f3:
	/* 0x12f3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12f6:
	/* 0x12f6: je     1353 <syscall_checker+0x1353> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f6, 0x1353, x86_l_1353);
x86_l_12f8:
	/* 0x12f8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12fd:
	/* 0x12fd: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1300:
	/* 0x1300: call   1305 <syscall_checker+0x1305> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1305:
	/* 0x1305: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1308:
	/* 0x1308: je     1380 <syscall_checker+0x1380> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1308, 0x1380, x86_l_1380);
x86_l_130a:
	/* 0x130a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_130d:
	/* 0x130d: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1311:
	/* 0x1311: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1314:
	/* 0x1314: jmp    1382 <syscall_checker+0x1382> */
	X86_SIM_X86_JMP(0x1314, 0x1382, x86_l_1382);
x86_l_1316:
	/* 0x1316: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_131d:
	/* 0x131d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1322:
	/* 0x1322: call   1327 <syscall_checker+0x1327> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1327:
	/* 0x1327: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_132a:
	/* 0x132a: je     1ae3 <syscall_checker+0x1ae3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x132a, 0x1ae3, x86_l_1ae3);
x86_l_1330:
	/* 0x1330: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1332:
	/* 0x1332: jmp    f87 <syscall_checker+0xf87> */
	X86_SIM_X86_JMP(0x1332, 0xf87, x86_l_f87);
x86_l_1337:
	/* 0x1337: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_133e:
	/* 0x133e: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1345:
	/* 0x1345: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1348:
	/* 0x1348: jne    11ab <syscall_checker+0x11ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1348, 0x11ab, x86_l_11ab);
x86_l_134e:
	/* 0x134e: jmp    11cc <syscall_checker+0x11cc> */
	X86_SIM_X86_JMP(0x134e, 0x11cc, x86_l_11cc);
x86_l_1353:
	/* 0x1353: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1355:
	/* 0x1355: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1358:
	/* 0x1358: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_135d:
	/* 0x135d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1360:
	/* 0x1360: jb     1394 <syscall_checker+0x1394> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1360, 0x1394, x86_l_1394);
x86_l_1362:
	/* 0x1362: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1366:
	/* 0x1366: movzx  r13d,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_136c:
	/* 0x136c: je     1373 <syscall_checker+0x1373> */
	X86_SIM_X86_JCC(X86_CC_E, 0x136c, 0x1373, x86_l_1373);
x86_l_136e:
	/* 0x136e: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1371:
	/* 0x1371: jbe    139a <syscall_checker+0x139a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1371, 0x139a, x86_l_139a);
x86_l_1373:
	/* 0x1373: and    r12,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_137b:
	/* 0x137b: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_137e:
	/* 0x137e: jmp    139a <syscall_checker+0x139a> */
	X86_SIM_X86_JMP(0x137e, 0x139a, x86_l_139a);
x86_l_1380:
	/* 0x1380: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1382:
	/* 0x1382: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1387:
	/* 0x1387: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_138a:
	/* 0x138a: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_138f:
	/* 0x138f: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1392:
	/* 0x1392: jae    1362 <syscall_checker+0x1362> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1392, 0x1362, x86_l_1362);
x86_l_1394:
	/* 0x1394: movzx  r13d,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_139a:
	/* 0x139a: or     rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_139d:
	/* 0x139d: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_13a0:
	/* 0x13a0: mov    rax,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_13a8:
	/* 0x13a8: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_13ab:
	/* 0x13ab: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13ae:
	/* 0x13ae: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_13b6:
	/* 0x13b6: je     146e <syscall_checker+0x146e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13b6, 0x146e, x86_l_146e);
x86_l_13bc:
	/* 0x13bc: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_13bf:
	/* 0x13bf: call   13c4 <syscall_checker+0x13c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_13c4:
	/* 0x13c4: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13c8:
	/* 0x13c8: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_13cf:
	/* 0x13cf: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_13d6:
	/* 0x13d6: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_13db:
	/* 0x13db: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_13e2:
	/* 0x13e2: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_13e5:
	/* 0x13e5: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_13ec:
	/* 0x13ec: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13f1:
	/* 0x13f1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_13f8:
	/* 0x13f8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13fd:
	/* 0x13fd: call   1402 <syscall_checker+0x1402> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1402:
	/* 0x1402: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1406:
	/* 0x1406: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_140b:
	/* 0x140b: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1412:
	/* 0x1412: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1415:
	/* 0x1415: je     1435 <syscall_checker+0x1435> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1415, 0x1435, x86_l_1435);
x86_l_1417:
	/* 0x1417: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_141c:
	/* 0x141c: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_141f:
	/* 0x141f: call   1424 <syscall_checker+0x1424> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1424:
	/* 0x1424: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1427:
	/* 0x1427: je     1435 <syscall_checker+0x1435> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1427, 0x1435, x86_l_1435);
x86_l_1429:
	/* 0x1429: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_142c:
	/* 0x142c: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1430:
	/* 0x1430: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1433:
	/* 0x1433: jmp    1437 <syscall_checker+0x1437> */
	X86_SIM_X86_JMP(0x1433, 0x1437, x86_l_1437);
x86_l_1435:
	/* 0x1435: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1437:
	/* 0x1437: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_143a:
	/* 0x143a: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_143f:
	/* 0x143f: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_1442:
	/* 0x1442: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1445:
	/* 0x1445: jae    144c <syscall_checker+0x144c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1445, 0x144c, x86_l_144c);
x86_l_1447:
	/* 0x1447: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_144a:
	/* 0x144a: jmp    1462 <syscall_checker+0x1462> */
	X86_SIM_X86_JMP(0x144a, 0x1462, x86_l_1462);
x86_l_144c:
	/* 0x144c: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1450:
	/* 0x1450: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1453:
	/* 0x1453: je     145a <syscall_checker+0x145a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1453, 0x145a, x86_l_145a);
x86_l_1455:
	/* 0x1455: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1458:
	/* 0x1458: jbe    1462 <syscall_checker+0x1462> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1458, 0x1462, x86_l_1462);
x86_l_145a:
	/* 0x145a: and    r15,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 120ULL);
x86_l_145f:
	/* 0x145f: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1462:
	/* 0x1462: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1465:
	/* 0x1465: and    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1468:
	/* 0x1468: movzx  r13d,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_146e:
	/* 0x146e: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_1476:
	/* 0x1476: je     151a <syscall_checker+0x151a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1476, 0x151a, x86_l_151a);
x86_l_147c:
	/* 0x147c: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1481:
	/* 0x1481: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_1488:
	/* 0x1488: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_148b:
	/* 0x148b: jns    1492 <syscall_checker+0x1492> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148b, 0x1492, x86_l_1492);
x86_l_148d:
	/* 0x148d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1490:
	/* 0x1490: jmp    1494 <syscall_checker+0x1494> */
	X86_SIM_X86_JMP(0x1490, 0x1494, x86_l_1494);
x86_l_1492:
	/* 0x1492: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1494:
	/* 0x1494: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1498:
	/* 0x1498: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_149a:
	/* 0x149a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_149d:
	/* 0x149d: jns    14a9 <syscall_checker+0x14a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x149d, 0x14a9, x86_l_14a9);
x86_l_149f:
	/* 0x149f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14a2:
	/* 0x14a2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14a5:
	/* 0x14a5: js     14b0 <syscall_checker+0x14b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14a5, 0x14b0, x86_l_14b0);
x86_l_14a7:
	/* 0x14a7: jmp    14b2 <syscall_checker+0x14b2> */
	X86_SIM_X86_JMP(0x14a7, 0x14b2, x86_l_14b2);
x86_l_14a9:
	/* 0x14a9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14ab:
	/* 0x14ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14ae:
	/* 0x14ae: jns    14b2 <syscall_checker+0x14b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14ae, 0x14b2, x86_l_14b2);
x86_l_14b0:
	/* 0x14b0: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14b2:
	/* 0x14b2: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_14b6:
	/* 0x14b6: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_14bd:
	/* 0x14bd: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_14c4:
	/* 0x14c4: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_14c7:
	/* 0x14c7: mov    WORD PTR [rsp+0x30],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14cd:
	/* 0x14cd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_14d4:
	/* 0x14d4: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14d9:
	/* 0x14d9: call   14de <syscall_checker+0x14de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_14de:
	/* 0x14de: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_14e5:
	/* 0x14e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e8:
	/* 0x14e8: je     150c <syscall_checker+0x150c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e8, 0x150c, x86_l_150c);
x86_l_14ea:
	/* 0x14ea: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14ef:
	/* 0x14ef: lea    rsi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_14f3:
	/* 0x14f3: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14f6:
	/* 0x14f6: call   14fb <syscall_checker+0x14fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_14fb:
	/* 0x14fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14fe:
	/* 0x14fe: je     150c <syscall_checker+0x150c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14fe, 0x150c, x86_l_150c);
x86_l_1500:
	/* 0x1500: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1503:
	/* 0x1503: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1507:
	/* 0x1507: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_150a:
	/* 0x150a: jmp    150e <syscall_checker+0x150e> */
	X86_SIM_X86_JMP(0x150a, 0x150e, x86_l_150e);
x86_l_150c:
	/* 0x150c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_150e:
	/* 0x150e: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1511:
	/* 0x1511: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1514:
	/* 0x1514: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1517:
	/* 0x1517: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_151a:
	/* 0x151a: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_1522:
	/* 0x1522: je     15ea <syscall_checker+0x15ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1522, 0x15ea, x86_l_15ea);
x86_l_1528:
	/* 0x1528: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_152f:
	/* 0x152f: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1533:
	/* 0x1533: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1535:
	/* 0x1535: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1538:
	/* 0x1538: jns    1547 <syscall_checker+0x1547> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1538, 0x1547, x86_l_1547);
x86_l_153a:
	/* 0x153a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153d:
	/* 0x153d: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1540:
	/* 0x1540: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1543:
	/* 0x1543: js     1551 <syscall_checker+0x1551> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1543, 0x1551, x86_l_1551);
x86_l_1545:
	/* 0x1545: jmp    1553 <syscall_checker+0x1553> */
	X86_SIM_X86_JMP(0x1545, 0x1553, x86_l_1553);
x86_l_1547:
	/* 0x1547: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1549:
	/* 0x1549: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_154c:
	/* 0x154c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_154f:
	/* 0x154f: jns    1553 <syscall_checker+0x1553> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x154f, 0x1553, x86_l_1553);
x86_l_1551:
	/* 0x1551: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1553:
	/* 0x1553: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1555:
	/* 0x1555: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1559:
	/* 0x1559: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_155c:
	/* 0x155c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1560:
	/* 0x1560: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1562:
	/* 0x1562: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1565:
	/* 0x1565: jns    1575 <syscall_checker+0x1575> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1565, 0x1575, x86_l_1575);
x86_l_1567:
	/* 0x1567: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_156a:
	/* 0x156a: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_156e:
	/* 0x156e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1571:
	/* 0x1571: js     1580 <syscall_checker+0x1580> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1571, 0x1580, x86_l_1580);
x86_l_1573:
	/* 0x1573: jmp    1582 <syscall_checker+0x1582> */
	X86_SIM_X86_JMP(0x1573, 0x1582, x86_l_1582);
x86_l_1575:
	/* 0x1575: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1577:
	/* 0x1577: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_157b:
	/* 0x157b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: jns    1582 <syscall_checker+0x1582> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157e, 0x1582, x86_l_1582);
x86_l_1580:
	/* 0x1580: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1582:
	/* 0x1582: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1586:
	/* 0x1586: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_158d:
	/* 0x158d: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1594:
	/* 0x1594: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1597:
	/* 0x1597: mov    WORD PTR [rsp+0x30],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_159d:
	/* 0x159d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_15a4:
	/* 0x15a4: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15a9:
	/* 0x15a9: call   15ae <syscall_checker+0x15ae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15ae:
	/* 0x15ae: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_15b5:
	/* 0x15b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15b8:
	/* 0x15b8: je     15dc <syscall_checker+0x15dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15b8, 0x15dc, x86_l_15dc);
x86_l_15ba:
	/* 0x15ba: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15bf:
	/* 0x15bf: lea    rsi,[rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_15c3:
	/* 0x15c3: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15c6:
	/* 0x15c6: call   15cb <syscall_checker+0x15cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15cb:
	/* 0x15cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15ce:
	/* 0x15ce: je     15dc <syscall_checker+0x15dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15ce, 0x15dc, x86_l_15dc);
x86_l_15d0:
	/* 0x15d0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d3:
	/* 0x15d3: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15d7:
	/* 0x15d7: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_15da:
	/* 0x15da: jmp    15de <syscall_checker+0x15de> */
	X86_SIM_X86_JMP(0x15da, 0x15de, x86_l_15de);
x86_l_15dc:
	/* 0x15dc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15de:
	/* 0x15de: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_15e1:
	/* 0x15e1: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_15e4:
	/* 0x15e4: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_15e7:
	/* 0x15e7: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_15ea:
	/* 0x15ea: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_15f2:
	/* 0x15f2: je     17d2 <syscall_checker+0x17d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f2, 0x17d2, x86_l_17d2);
x86_l_15f8:
	/* 0x15f8: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_15fd:
	/* 0x15fd: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_1604:
	/* 0x1604: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1607:
	/* 0x1607: jns    161a <syscall_checker+0x161a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1607, 0x161a, x86_l_161a);
x86_l_1609:
	/* 0x1609: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160c:
	/* 0x160c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_160f:
	/* 0x160f: js     1621 <syscall_checker+0x1621> */
	X86_SIM_X86_JCC(X86_CC_S, 0x160f, 0x1621, x86_l_1621);
x86_l_1611:
	/* 0x1611: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1613:
	/* 0x1613: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1616:
	/* 0x1616: js     1629 <syscall_checker+0x1629> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1616, 0x1629, x86_l_1629);
x86_l_1618:
	/* 0x1618: jmp    1674 <syscall_checker+0x1674> */
	X86_SIM_X86_JMP(0x1618, 0x1674, x86_l_1674);
x86_l_161a:
	/* 0x161a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_161c:
	/* 0x161c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_161f:
	/* 0x161f: jns    1611 <syscall_checker+0x1611> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161f, 0x1611, x86_l_1611);
x86_l_1621:
	/* 0x1621: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1624:
	/* 0x1624: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1627:
	/* 0x1627: jns    1674 <syscall_checker+0x1674> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1627, 0x1674, x86_l_1674);
x86_l_1629:
	/* 0x1629: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162c:
	/* 0x162c: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1631:
	/* 0x1631: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1635:
	/* 0x1635: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_163a:
	/* 0x163a: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_163e:
	/* 0x163e: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1643:
	/* 0x1643: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1647:
	/* 0x1647: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_164c:
	/* 0x164c: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1650:
	/* 0x1650: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1655:
	/* 0x1655: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1659:
	/* 0x1659: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_165e:
	/* 0x165e: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1662:
	/* 0x1662: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1667:
	/* 0x1667: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_166b:
	/* 0x166b: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1670:
	/* 0x1670: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1674:
	/* 0x1674: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1679:
	/* 0x1679: lea    rbx,[rax+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_167d:
	/* 0x167d: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1682:
	/* 0x1682: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1685:
	/* 0x1685: jns    175b <syscall_checker+0x175b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1685, 0x175b, x86_l_175b);
x86_l_168b:
	/* 0x168b: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_168e:
	/* 0x168e: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1690:
	/* 0x1690: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1692:
	/* 0x1692: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1692, 0x176a, x86_l_176a);
x86_l_1698:
	/* 0x1698: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_169c:
	/* 0x169c: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_16a0:
	/* 0x16a0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16a2:
	/* 0x16a2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16a2, 0x176a, x86_l_176a);
x86_l_16a8:
	/* 0x16a8: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_16ac:
	/* 0x16ac: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_16b0:
	/* 0x16b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16b2:
	/* 0x16b2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16b2, 0x176a, x86_l_176a);
x86_l_16b8:
	/* 0x16b8: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_16bc:
	/* 0x16bc: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_16c0:
	/* 0x16c0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16c2:
	/* 0x16c2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16c2, 0x176a, x86_l_176a);
x86_l_16c8:
	/* 0x16c8: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_16cc:
	/* 0x16cc: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_16d0:
	/* 0x16d0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16d2:
	/* 0x16d2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d2, 0x176a, x86_l_176a);
x86_l_16d8:
	/* 0x16d8: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_16dc:
	/* 0x16dc: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_16e0:
	/* 0x16e0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16e2:
	/* 0x16e2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e2, 0x176a, x86_l_176a);
x86_l_16e8:
	/* 0x16e8: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_16ec:
	/* 0x16ec: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_16f0:
	/* 0x16f0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16f2:
	/* 0x16f2: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16f2, 0x176a, x86_l_176a);
x86_l_16f4:
	/* 0x16f4: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_16f8:
	/* 0x16f8: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_16fc:
	/* 0x16fc: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_16fe:
	/* 0x16fe: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16fe, 0x176a, x86_l_176a);
x86_l_1700:
	/* 0x1700: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1704:
	/* 0x1704: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_1708:
	/* 0x1708: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_170a:
	/* 0x170a: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170a, 0x176a, x86_l_176a);
x86_l_170c:
	/* 0x170c: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1710:
	/* 0x1710: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_1714:
	/* 0x1714: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1716:
	/* 0x1716: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1716, 0x176a, x86_l_176a);
x86_l_1718:
	/* 0x1718: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_171c:
	/* 0x171c: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_1720:
	/* 0x1720: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1722:
	/* 0x1722: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1722, 0x176a, x86_l_176a);
x86_l_1724:
	/* 0x1724: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1728:
	/* 0x1728: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_172c:
	/* 0x172c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_172e:
	/* 0x172e: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172e, 0x176a, x86_l_176a);
x86_l_1730:
	/* 0x1730: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1734:
	/* 0x1734: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1738:
	/* 0x1738: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_173a:
	/* 0x173a: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x173a, 0x176a, x86_l_176a);
x86_l_173c:
	/* 0x173c: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1740:
	/* 0x1740: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_1744:
	/* 0x1744: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1746:
	/* 0x1746: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1746, 0x176a, x86_l_176a);
x86_l_1748:
	/* 0x1748: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_174c:
	/* 0x174c: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_1750:
	/* 0x1750: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1752:
	/* 0x1752: je     176a <syscall_checker+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1752, 0x176a, x86_l_176a);
x86_l_1754:
	/* 0x1754: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_1759:
	/* 0x1759: jmp    176a <syscall_checker+0x176a> */
	X86_SIM_X86_JMP(0x1759, 0x176a, x86_l_176a);
x86_l_175b:
	/* 0x175b: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1763:
	/* 0x1763: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_176a:
	/* 0x176a: mov    r15,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_1771:
	/* 0x1771: mov    r13,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_1778:
	/* 0x1778: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_177b:
	/* 0x177b: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_1780:
	/* 0x1780: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1785:
	/* 0x1785: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_178c:
	/* 0x178c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1791:
	/* 0x1791: call   1796 <syscall_checker+0x1796> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1796:
	/* 0x1796: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_179d:
	/* 0x179d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17a0:
	/* 0x17a0: je     17be <syscall_checker+0x17be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17a0, 0x17be, x86_l_17be);
x86_l_17a2:
	/* 0x17a2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17a5:
	/* 0x17a5: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17a8:
	/* 0x17a8: call   17ad <syscall_checker+0x17ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17ad:
	/* 0x17ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17b0:
	/* 0x17b0: je     17be <syscall_checker+0x17be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b0, 0x17be, x86_l_17be);
x86_l_17b2:
	/* 0x17b2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b5:
	/* 0x17b5: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17b9:
	/* 0x17b9: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_17bc:
	/* 0x17bc: jmp    17c0 <syscall_checker+0x17c0> */
	X86_SIM_X86_JMP(0x17bc, 0x17c0, x86_l_17c0);
x86_l_17be:
	/* 0x17be: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17c0:
	/* 0x17c0: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_17c3:
	/* 0x17c3: and    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_17c6:
	/* 0x17c6: or     r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_17c9:
	/* 0x17c9: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_17cc:
	/* 0x17cc: movzx  r13d,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_17d2:
	/* 0x17d2: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_17da:
	/* 0x17da: je     185c <syscall_checker+0x185c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17da, 0x185c, x86_l_185c);
x86_l_17e0:
	/* 0x17e0: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17e5:
	/* 0x17e5: lea    rbx,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_17e9:
	/* 0x17e9: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17ec:
	/* 0x17ec: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_17f1:
	/* 0x17f1: call   17f6 <syscall_checker+0x17f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_17f6:
	/* 0x17f6: mov    r15,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_17fd:
	/* 0x17fd: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1800:
	/* 0x1800: mov    r13,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1807:
	/* 0x1807: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_180a:
	/* 0x180a: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_180f:
	/* 0x180f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_1816:
	/* 0x1816: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_181b:
	/* 0x181b: call   1820 <syscall_checker+0x1820> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1820:
	/* 0x1820: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1827:
	/* 0x1827: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_182a:
	/* 0x182a: je     1848 <syscall_checker+0x1848> */
	X86_SIM_X86_JCC(X86_CC_E, 0x182a, 0x1848, x86_l_1848);
x86_l_182c:
	/* 0x182c: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_182f:
	/* 0x182f: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1832:
	/* 0x1832: call   1837 <syscall_checker+0x1837> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1837:
	/* 0x1837: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_183a:
	/* 0x183a: je     1848 <syscall_checker+0x1848> */
	X86_SIM_X86_JCC(X86_CC_E, 0x183a, 0x1848, x86_l_1848);
x86_l_183c:
	/* 0x183c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_183f:
	/* 0x183f: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1843:
	/* 0x1843: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1846:
	/* 0x1846: jmp    184a <syscall_checker+0x184a> */
	X86_SIM_X86_JMP(0x1846, 0x184a, x86_l_184a);
x86_l_1848:
	/* 0x1848: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_184a:
	/* 0x184a: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_184d:
	/* 0x184d: and    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1850:
	/* 0x1850: or     r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1853:
	/* 0x1853: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1856:
	/* 0x1856: movzx  r13d,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_185c:
	/* 0x185c: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1863:
	/* 0x1863: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1866:
	/* 0x1866: je     18cf <syscall_checker+0x18cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1866, 0x18cf, x86_l_18cf);
x86_l_1868:
	/* 0x1868: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_186c:
	/* 0x186c: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1870:
	/* 0x1870: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1877:
	/* 0x1877: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_187a:
	/* 0x187a: mov    WORD PTR [rsp+0xa8],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1883:
	/* 0x1883: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_188a:
	/* 0x188a: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1892:
	/* 0x1892: call   1897 <syscall_checker+0x1897> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1897:
	/* 0x1897: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_189e:
	/* 0x189e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18a1:
	/* 0x18a1: je     18c1 <syscall_checker+0x18c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18a1, 0x18c1, x86_l_18c1);
x86_l_18a3:
	/* 0x18a3: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18a8:
	/* 0x18a8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18ab:
	/* 0x18ab: call   18b0 <syscall_checker+0x18b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_18b0:
	/* 0x18b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18b3:
	/* 0x18b3: je     18c1 <syscall_checker+0x18c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b3, 0x18c1, x86_l_18c1);
x86_l_18b5:
	/* 0x18b5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18b8:
	/* 0x18b8: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18bc:
	/* 0x18bc: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_18bf:
	/* 0x18bf: jmp    18c3 <syscall_checker+0x18c3> */
	X86_SIM_X86_JMP(0x18bf, 0x18c3, x86_l_18c3);
x86_l_18c1:
	/* 0x18c1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c3:
	/* 0x18c3: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_18c6:
	/* 0x18c6: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_18c9:
	/* 0x18c9: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_18cc:
	/* 0x18cc: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_18cf:
	/* 0x18cf: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_18d6:
	/* 0x18d6: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18d9:
	/* 0x18d9: je     1938 <syscall_checker+0x1938> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18d9, 0x1938, x86_l_1938);
x86_l_18db:
	/* 0x18db: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_18e2:
	/* 0x18e2: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_18e5:
	/* 0x18e5: mov    WORD PTR [rsp+0x30],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18eb:
	/* 0x18eb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_18f2:
	/* 0x18f2: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18f7:
	/* 0x18f7: call   18fc <syscall_checker+0x18fc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_18fc:
	/* 0x18fc: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1903:
	/* 0x1903: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1906:
	/* 0x1906: je     192a <syscall_checker+0x192a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1906, 0x192a, x86_l_192a);
x86_l_1908:
	/* 0x1908: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_190d:
	/* 0x190d: lea    rsi,[rcx+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1911:
	/* 0x1911: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1914:
	/* 0x1914: call   1919 <syscall_checker+0x1919> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1919:
	/* 0x1919: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_191c:
	/* 0x191c: je     192a <syscall_checker+0x192a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x191c, 0x192a, x86_l_192a);
x86_l_191e:
	/* 0x191e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1921:
	/* 0x1921: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1925:
	/* 0x1925: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1928:
	/* 0x1928: jmp    192c <syscall_checker+0x192c> */
	X86_SIM_X86_JMP(0x1928, 0x192c, x86_l_192c);
x86_l_192a:
	/* 0x192a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_192c:
	/* 0x192c: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_192f:
	/* 0x192f: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1932:
	/* 0x1932: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1935:
	/* 0x1935: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1938:
	/* 0x1938: mov    r15,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_193f:
	/* 0x193f: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1942:
	/* 0x1942: je     19cc <syscall_checker+0x19cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1942, 0x19cc, x86_l_19cc);
x86_l_1948:
	/* 0x1948: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_194b:
	/* 0x194b: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_194e:
	/* 0x194e: mov    r13,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_1955:
	/* 0x1955: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1958:
	/* 0x1958: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_195d:
	/* 0x195d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_1964:
	/* 0x1964: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1969:
	/* 0x1969: call   196e <syscall_checker+0x196e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_196e:
	/* 0x196e: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1975:
	/* 0x1975: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1978:
	/* 0x1978: je     19bb <syscall_checker+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1978, 0x19bb, x86_l_19bb);
x86_l_197a:
	/* 0x197a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_197d:
	/* 0x197d: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1985:
	/* 0x1985: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1989:
	/* 0x1989: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_198c:
	/* 0x198c: call   1991 <syscall_checker+0x1991> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1991:
	/* 0x1991: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1994:
	/* 0x1994: jne    19af <syscall_checker+0x19af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1994, 0x19af, x86_l_19af);
x86_l_1996:
	/* 0x1996: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_199e:
	/* 0x199e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19a2:
	/* 0x19a2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19a5:
	/* 0x19a5: call   19aa <syscall_checker+0x19aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_19aa:
	/* 0x19aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19ad:
	/* 0x19ad: je     19bb <syscall_checker+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ad, 0x19bb, x86_l_19bb);
x86_l_19af:
	/* 0x19af: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19b2:
	/* 0x19b2: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b6:
	/* 0x19b6: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_19b9:
	/* 0x19b9: jmp    19bd <syscall_checker+0x19bd> */
	X86_SIM_X86_JMP(0x19b9, 0x19bd, x86_l_19bd);
x86_l_19bb:
	/* 0x19bb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19bd:
	/* 0x19bd: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_19c0:
	/* 0x19c0: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_19c3:
	/* 0x19c3: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_19c6:
	/* 0x19c6: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_19c9:
	/* 0x19c9: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_19cc:
	/* 0x19cc: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_19d3:
	/* 0x19d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19d6:
	/* 0x19d6: mov    r15,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_19de:
	/* 0x19de: je     19ef <syscall_checker+0x19ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19de, 0x19ef, x86_l_19ef);
x86_l_19e0:
	/* 0x19e0: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_19e8:
	/* 0x19e8: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_19ec:
	/* 0x19ec: or     rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_19ef:
	/* 0x19ef: and    rbp,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_19f6:
	/* 0x19f6: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_19fd:
	/* 0x19fd: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1a00:
	/* 0x1a00: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1a07:
	/* 0x1a07: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a07, 0x332f, x86_l_332f);
x86_l_1a0d:
	/* 0x1a0d: mov    rax,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1a15:
	/* 0x1a15: mov    rax,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1a1c:
	/* 0x1a1c: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1a24:
	/* 0x1a24: call   1a29 <syscall_checker+0x1a29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_1a29:
	/* 0x1a29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a2c:
	/* 0x1a2c: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a2c, 0x332f, x86_l_332f);
x86_l_1a32:
	/* 0x1a32: mov    rcx,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1a3a:
	/* 0x1a3a: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a3e:
	/* 0x1a3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a41:
	/* 0x1a41: jns    1a50 <syscall_checker+0x1a50> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a41, 0x1a50, x86_l_1a50);
x86_l_1a43:
	/* 0x1a43: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a46:
	/* 0x1a46: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a49:
	/* 0x1a49: js     1a5b <syscall_checker+0x1a5b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a49, 0x1a5b, x86_l_1a5b);
x86_l_1a4b:
	/* 0x1a4b: jmp    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JMP(0x1a4b, 0x332f, x86_l_332f);
x86_l_1a50:
	/* 0x1a50: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a52:
	/* 0x1a52: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a55:
	/* 0x1a55: jns    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a55, 0x332f, x86_l_332f);
x86_l_1a5b:
	/* 0x1a5b: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a5e:
	/* 0x1a5e: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1a61:
	/* 0x1a61: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a61, 0x332f, x86_l_332f);
x86_l_1a67:
	/* 0x1a67: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a6c:
	/* 0x1a6c: lea    rdi,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a70:
	/* 0x1a70: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a72:
	/* 0x1a72: lea    rbp,[r12-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_1a77:
	/* 0x1a77: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a7a:
	/* 0x1a7a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a7d:
	/* 0x1a7d: jns    1a84 <syscall_checker+0x1a84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a7d, 0x1a84, x86_l_1a84);
x86_l_1a7f:
	/* 0x1a7f: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a82:
	/* 0x1a82: jmp    1a86 <syscall_checker+0x1a86> */
	X86_SIM_X86_JMP(0x1a82, 0x1a86, x86_l_1a86);
x86_l_1a84:
	/* 0x1a84: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a86:
	/* 0x1a86: lea    r13,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1a8b:
	/* 0x1a8b: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1a8e:
	/* 0x1a8e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a91:
	/* 0x1a91: jns    1ab7 <syscall_checker+0x1ab7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a91, 0x1ab7, x86_l_1ab7);
x86_l_1a93:
	/* 0x1a93: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a96:
	/* 0x1a96: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a99:
	/* 0x1a99: jbe    1ab7 <syscall_checker+0x1ab7> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1a99, 0x1ab7, x86_l_1ab7);
x86_l_1a9b:
	/* 0x1a9b: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a9e:
	/* 0x1a9e: jbe    1bb4 <syscall_checker+0x1bb4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1a9e, 0x1bb4, x86_l_1bb4);
x86_l_1aa4:
	/* 0x1aa4: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1aa8:
	/* 0x1aa8: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1aab:
	/* 0x1aab: jns    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aab, 0x332f, x86_l_332f);
x86_l_1ab1:
	/* 0x1ab1: mov    r12,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab5:
	/* 0x1ab5: jmp    1ac4 <syscall_checker+0x1ac4> */
	X86_SIM_X86_JMP(0x1ab5, 0x1ac4, x86_l_1ac4);
x86_l_1ab7:
	/* 0x1ab7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1aba:
	/* 0x1aba: jns    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aba, 0x332f, x86_l_332f);
x86_l_1ac0:
	/* 0x1ac0: mov    r12,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ac4:
	/* 0x1ac4: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1ac7:
	/* 0x1ac7: ja     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ac7, 0x332f, x86_l_332f);
x86_l_1acd:
	/* 0x1acd: inc    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1acf:
	/* 0x1acf: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ad2:
	/* 0x1ad2: jne    1a72 <syscall_checker+0x1a72> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ad2, 0x1a72, x86_l_1a72);
x86_l_1ad4:
	/* 0x1ad4: jmp    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JMP(0x1ad4, 0x332f, x86_l_332f);
x86_l_1ad9:
	/* 0x1ad9: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1ade:
	/* 0x1ade: jmp    272 <syscall_checker+0x272> */
	X86_SIM_X86_JMP(0x1ade, 0x272, x86_l_272);
x86_l_1ae3:
	/* 0x1ae3: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1ae8:
	/* 0x1ae8: jmp    f87 <syscall_checker+0xf87> */
	X86_SIM_X86_JMP(0x1ae8, 0xf87, x86_l_f87);
x86_l_1aed:
	/* 0x1aed: lea    rsi,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1af2:
	/* 0x1af2: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1af5:
	/* 0x1af5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1af8:
	/* 0x1af8: jns    1b06 <syscall_checker+0x1b06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af8, 0x1b06, x86_l_1b06);
x86_l_1afa:
	/* 0x1afa: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1afd:
	/* 0x1afd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b00:
	/* 0x1b00: jne    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b00, 0xda6, x86_l_da6);
x86_l_1b06:
	/* 0x1b06: lea    rcx,[r12+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b0b:
	/* 0x1b0b: mov    QWORD PTR [rsp+0x90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1b13:
	/* 0x1b13: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b16:
	/* 0x1b16: mov    QWORD PTR [rsp+0x20],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b1b:
	/* 0x1b1b: jns    1c8c <syscall_checker+0x1c8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1b, 0x1c8c, x86_l_1c8c);
x86_l_1b21:
	/* 0x1b21: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b24:
	/* 0x1b24: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b27:
	/* 0x1b27: je     1c8c <syscall_checker+0x1c8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b27, 0x1c8c, x86_l_1c8c);
x86_l_1b2d:
	/* 0x1b2d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b30:
	/* 0x1b30: jns    1c0e <syscall_checker+0x1c0e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b30, 0x1c0e, x86_l_1c0e);
x86_l_1b36:
	/* 0x1b36: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b39:
	/* 0x1b39: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b3c:
	/* 0x1b3c: jns    1c10 <syscall_checker+0x1c10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3c, 0x1c10, x86_l_1c10);
x86_l_1b42:
	/* 0x1b42: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b45:
	/* 0x1b45: jns    1c8c <syscall_checker+0x1c8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b45, 0x1c8c, x86_l_1c8c);
x86_l_1b4b:
	/* 0x1b4b: movzx  ecx,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1b4e:
	/* 0x1b4e: mov    BYTE PTR [rsp+0x30],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b52:
	/* 0x1b52: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1b54:
	/* 0x1b54: je     1c8c <syscall_checker+0x1c8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b54, 0x1c8c, x86_l_1c8c);
x86_l_1b5a:
	/* 0x1b5a: movzx  ecx,BYTE PTR [rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1b5e:
	/* 0x1b5e: mov    BYTE PTR [rsp+0x31],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 49ULL);
x86_l_1b62:
	/* 0x1b62: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1b64:
	/* 0x1b64: je     1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b64, 0x1c35, x86_l_1c35);
x86_l_1b6a:
	/* 0x1b6a: movzx  ecx,BYTE PTR [rdx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1b6e:
	/* 0x1b6e: mov    BYTE PTR [rsp+0x32],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_1b72:
	/* 0x1b72: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1b74:
	/* 0x1b74: je     1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b74, 0x1c35, x86_l_1c35);
x86_l_1b7a:
	/* 0x1b7a: movzx  ecx,BYTE PTR [rdx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1b7e:
	/* 0x1b7e: mov    BYTE PTR [rsp+0x33],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 51ULL);
x86_l_1b82:
	/* 0x1b82: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1b84:
	/* 0x1b84: je     1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b84, 0x1c35, x86_l_1c35);
x86_l_1b8a:
	/* 0x1b8a: movzx  ecx,BYTE PTR [rdx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1b8e:
	/* 0x1b8e: mov    BYTE PTR [rsp+0x34],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1b92:
	/* 0x1b92: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1b94:
	/* 0x1b94: je     1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b94, 0x1c35, x86_l_1c35);
x86_l_1b9a:
	/* 0x1b9a: movzx  ecx,BYTE PTR [rdx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1b9e:
	/* 0x1b9e: mov    BYTE PTR [rsp+0x35],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_1ba2:
	/* 0x1ba2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ba4:
	/* 0x1ba4: je     1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ba4, 0x1c35, x86_l_1c35);
x86_l_1baa:
	/* 0x1baa: mov    BYTE PTR [rsp+0x36],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 231928233984ULL);
x86_l_1baf:
	/* 0x1baf: jmp    1c35 <syscall_checker+0x1c35> */
	X86_SIM_X86_JMP(0x1baf, 0x1c35, x86_l_1c35);
x86_l_1bb4:
	/* 0x1bb4: lea    rax,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1bb9:
	/* 0x1bb9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bbc:
	/* 0x1bbc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bbf:
	/* 0x1bbf: mov    QWORD PTR [rsp+0xc8],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1bc7:
	/* 0x1bc7: jns    1bdd <syscall_checker+0x1bdd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bc7, 0x1bdd, x86_l_1bdd);
x86_l_1bc9:
	/* 0x1bc9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bcc:
	/* 0x1bcc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bcf:
	/* 0x1bcf: je     1bdd <syscall_checker+0x1bdd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bcf, 0x1bdd, x86_l_1bdd);
x86_l_1bd1:
	/* 0x1bd1: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1bd8:
	/* 0x1bd8: jmp    2a3e <syscall_checker+0x2a3e> */
	X86_SIM_X86_JMP(0x1bd8, 0x2a3e, x86_l_2a3e);
x86_l_1bdd:
	/* 0x1bdd: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1be2:
	/* 0x1be2: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1be5:
	/* 0x1be5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1be8:
	/* 0x1be8: jns    1da9 <syscall_checker+0x1da9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1be8, 0x1da9, x86_l_1da9);
x86_l_1bee:
	/* 0x1bee: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf1:
	/* 0x1bf1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bf4:
	/* 0x1bf4: je     1da9 <syscall_checker+0x1da9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bf4, 0x1da9, x86_l_1da9);
x86_l_1bfa:
	/* 0x1bfa: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1bfd:
	/* 0x1bfd: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c00:
	/* 0x1c00: jns    1d7a <syscall_checker+0x1d7a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c00, 0x1d7a, x86_l_1d7a);
x86_l_1c06:
	/* 0x1c06: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c09:
	/* 0x1c09: jmp    1d7c <syscall_checker+0x1d7c> */
	X86_SIM_X86_JMP(0x1c09, 0x1d7c, x86_l_1d7c);
x86_l_1c0e:
	/* 0x1c0e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c10:
	/* 0x1c10: mov    QWORD PTR [rsp+0x78],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1c15:
	/* 0x1c15: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c1a:
	/* 0x1c1a: mov    esi,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1c1f:
	/* 0x1c1f: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c22:
	/* 0x1c22: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c25:
	/* 0x1c25: call   1c2a <syscall_checker+0x1c2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1c2a:
	/* 0x1c2a: mov    rsi,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1c2f:
	/* 0x1c2f: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c32:
	/* 0x1c32: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c35:
	/* 0x1c35: movzx  ecx,BYTE PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 48ULL);
x86_l_1c3a:
	/* 0x1c3a: mov    dl,0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_1c3c:
	/* 0x1c3c: cmp    cl,0x5b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_1c3f:
	/* 0x1c3f: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c3f, 0x1c84, x86_l_1c84);
x86_l_1c41:
	/* 0x1c41: movzx  ecx,BYTE PTR [rsp+0x31] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 49ULL);
x86_l_1c46:
	/* 0x1c46: mov    dl,0x76 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_1c48:
	/* 0x1c48: cmp    cl,0x76 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_1c4b:
	/* 0x1c4b: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c4b, 0x1c84, x86_l_1c84);
x86_l_1c4d:
	/* 0x1c4d: movzx  ecx,BYTE PTR [rsp+0x32] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 50ULL);
x86_l_1c52:
	/* 0x1c52: mov    dl,0x64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_1c54:
	/* 0x1c54: cmp    cl,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_1c57:
	/* 0x1c57: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c57, 0x1c84, x86_l_1c84);
x86_l_1c59:
	/* 0x1c59: movzx  ecx,BYTE PTR [rsp+0x33] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 51ULL);
x86_l_1c5e:
	/* 0x1c5e: mov    dl,0x73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_1c60:
	/* 0x1c60: cmp    cl,0x73 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_1c63:
	/* 0x1c63: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c63, 0x1c84, x86_l_1c84);
x86_l_1c65:
	/* 0x1c65: movzx  ecx,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_1c6a:
	/* 0x1c6a: mov    dl,0x6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_1c6c:
	/* 0x1c6c: cmp    cl,0x6f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_1c6f:
	/* 0x1c6f: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c6f, 0x1c84, x86_l_1c84);
x86_l_1c71:
	/* 0x1c71: movzx  ecx,BYTE PTR [rsp+0x35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 53ULL);
x86_l_1c76:
	/* 0x1c76: mov    dl,0x5d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_1c78:
	/* 0x1c78: cmp    cl,0x5d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_1c7b:
	/* 0x1c7b: jne    1c84 <syscall_checker+0x1c84> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c7b, 0x1c84, x86_l_1c84);
x86_l_1c7d:
	/* 0x1c7d: movzx  ecx,BYTE PTR [rsp+0x36] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 54ULL);
x86_l_1c82:
	/* 0x1c82: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c84:
	/* 0x1c84: cmp    dl,cl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1c86:
	/* 0x1c86: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c86, 0xda6, x86_l_da6);
x86_l_1c8c:
	/* 0x1c8c: mov    ecx,DWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1c93:
	/* 0x1c93: mov    DWORD PTR [rsp+0xa8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1c9a:
	/* 0x1c9a: lea    rdx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c9e:
	/* 0x1c9e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ca0:
	/* 0x1ca0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ca3:
	/* 0x1ca3: jns    1ca7 <syscall_checker+0x1ca7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca3, 0x1ca7, x86_l_1ca7);
x86_l_1ca5:
	/* 0x1ca5: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca7:
	/* 0x1ca7: mov    DWORD PTR [rsp+0xac],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_1cae:
	/* 0x1cae: add    rax,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1cb2:
	/* 0x1cb2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb5:
	/* 0x1cb5: jns    1cbc <syscall_checker+0x1cbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb5, 0x1cbc, x86_l_1cbc);
x86_l_1cb7:
	/* 0x1cb7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cba:
	/* 0x1cba: jmp    1cbe <syscall_checker+0x1cbe> */
	X86_SIM_X86_JMP(0x1cba, 0x1cbe, x86_l_1cbe);
x86_l_1cbc:
	/* 0x1cbc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cbe:
	/* 0x1cbe: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1cc2:
	/* 0x1cc2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc5:
	/* 0x1cc5: jns    1ccc <syscall_checker+0x1ccc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc5, 0x1ccc, x86_l_1ccc);
x86_l_1cc7:
	/* 0x1cc7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cca:
	/* 0x1cca: jmp    1cce <syscall_checker+0x1cce> */
	X86_SIM_X86_JMP(0x1cca, 0x1cce, x86_l_1cce);
x86_l_1ccc:
	/* 0x1ccc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cce:
	/* 0x1cce: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1cd6:
	/* 0x1cd6: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1cd9:
	/* 0x1cd9: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cdc:
	/* 0x1cdc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cdf:
	/* 0x1cdf: jns    1ce6 <syscall_checker+0x1ce6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cdf, 0x1ce6, x86_l_1ce6);
x86_l_1ce1:
	/* 0x1ce1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ce4:
	/* 0x1ce4: jmp    1ce8 <syscall_checker+0x1ce8> */
	X86_SIM_X86_JMP(0x1ce4, 0x1ce8, x86_l_1ce8);
x86_l_1ce6:
	/* 0x1ce6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ce8:
	/* 0x1ce8: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1cf0:
	/* 0x1cf0: mov    BYTE PTR [rsp+0x87],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 579820584961ULL);
x86_l_1cf8:
	/* 0x1cf8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)syscall_source_map));
x86_l_1cff:
	/* 0x1cff: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d07:
	/* 0x1d07: lea    rdx,[rsp+0x87] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 135ULL);
x86_l_1d0f:
	/* 0x1d0f: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1d14:
	/* 0x1d14: call   1d19 <syscall_checker+0x1d19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1d19:
	/* 0x1d19: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d1b:
	/* 0x1d1b: mov    ecx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1d20:
	/* 0x1d20: add    rcx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551600ULL);
x86_l_1d24:
	/* 0x1d24: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d27:
	/* 0x1d27: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d27, 0xda6, x86_l_da6);
x86_l_1d2d:
	/* 0x1d2d: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d30:
	/* 0x1d30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d33:
	/* 0x1d33: jns    1d49 <syscall_checker+0x1d49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d33, 0x1d49, x86_l_1d49);
x86_l_1d35:
	/* 0x1d35: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d38:
	/* 0x1d38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d3b:
	/* 0x1d3b: je     1d49 <syscall_checker+0x1d49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d3b, 0x1d49, x86_l_1d49);
x86_l_1d3d:
	/* 0x1d3d: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1d44:
	/* 0x1d44: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x1d44, 0x3951, x86_l_3951);
x86_l_1d49:
	/* 0x1d49: lea    rax,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d4e:
	/* 0x1d4e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d51:
	/* 0x1d51: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d54:
	/* 0x1d54: jns    1f93 <syscall_checker+0x1f93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d54, 0x1f93, x86_l_1f93);
x86_l_1d5a:
	/* 0x1d5a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d5d:
	/* 0x1d5d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d60:
	/* 0x1d60: je     1f93 <syscall_checker+0x1f93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d60, 0x1f93, x86_l_1f93);
x86_l_1d66:
	/* 0x1d66: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1d69:
	/* 0x1d69: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d6c:
	/* 0x1d6c: jns    1f5c <syscall_checker+0x1f5c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d6c, 0x1f5c, x86_l_1f5c);
x86_l_1d72:
	/* 0x1d72: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d75:
	/* 0x1d75: jmp    1f5e <syscall_checker+0x1f5e> */
	X86_SIM_X86_JMP(0x1d75, 0x1f5e, x86_l_1f5e);
x86_l_1d7a:
	/* 0x1d7a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d7c:
	/* 0x1d7c: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1d7f:
	/* 0x1d7f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d82:
	/* 0x1d82: jns    1d89 <syscall_checker+0x1d89> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d82, 0x1d89, x86_l_1d89);
x86_l_1d84:
	/* 0x1d84: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d87:
	/* 0x1d87: jmp    1d8b <syscall_checker+0x1d8b> */
	X86_SIM_X86_JMP(0x1d87, 0x1d8b, x86_l_1d8b);
x86_l_1d89:
	/* 0x1d89: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d8b:
	/* 0x1d8b: add    rdx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_1d8f:
	/* 0x1d8f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d92:
	/* 0x1d92: jns    1d99 <syscall_checker+0x1d99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d92, 0x1d99, x86_l_1d99);
x86_l_1d94:
	/* 0x1d94: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d97:
	/* 0x1d97: jmp    1d9b <syscall_checker+0x1d9b> */
	X86_SIM_X86_JMP(0x1d97, 0x1d9b, x86_l_1d9b);
x86_l_1d99:
	/* 0x1d99: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d9b:
	/* 0x1d9b: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d9e:
	/* 0x1d9e: ja     1da9 <syscall_checker+0x1da9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d9e, 0x1da9, x86_l_1da9);
x86_l_1da0:
	/* 0x1da0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1da3:
	/* 0x1da3: jbe    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1da3, 0x332f, x86_l_332f);
x86_l_1da9:
	/* 0x1da9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dac:
	/* 0x1dac: jns    1e0a <syscall_checker+0x1e0a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dac, 0x1e0a, x86_l_1e0a);
x86_l_1dae:
	/* 0x1dae: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1db1:
	/* 0x1db1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1db4:
	/* 0x1db4: je     1e0a <syscall_checker+0x1e0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1db4, 0x1e0a, x86_l_1e0a);
x86_l_1db6:
	/* 0x1db6: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1db9:
	/* 0x1db9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1dbc:
	/* 0x1dbc: jns    1dc3 <syscall_checker+0x1dc3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dbc, 0x1dc3, x86_l_1dc3);
x86_l_1dbe:
	/* 0x1dbe: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dc1:
	/* 0x1dc1: jmp    1dc5 <syscall_checker+0x1dc5> */
	X86_SIM_X86_JMP(0x1dc1, 0x1dc5, x86_l_1dc5);
x86_l_1dc3:
	/* 0x1dc3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc5:
	/* 0x1dc5: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1dc8:
	/* 0x1dc8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dcb:
	/* 0x1dcb: jns    1dd2 <syscall_checker+0x1dd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dcb, 0x1dd2, x86_l_1dd2);
x86_l_1dcd:
	/* 0x1dcd: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd0:
	/* 0x1dd0: jmp    1dd4 <syscall_checker+0x1dd4> */
	X86_SIM_X86_JMP(0x1dd0, 0x1dd4, x86_l_1dd4);
x86_l_1dd2:
	/* 0x1dd2: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dd4:
	/* 0x1dd4: lea    rdi,[rcx+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1dd8:
	/* 0x1dd8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ddb:
	/* 0x1ddb: jns    1de2 <syscall_checker+0x1de2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ddb, 0x1de2, x86_l_1de2);
x86_l_1ddd:
	/* 0x1ddd: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1de0:
	/* 0x1de0: jmp    1de4 <syscall_checker+0x1de4> */
	X86_SIM_X86_JMP(0x1de0, 0x1de4, x86_l_1de4);
x86_l_1de2:
	/* 0x1de2: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de4:
	/* 0x1de4: add    rcx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_1de8:
	/* 0x1de8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1deb:
	/* 0x1deb: jns    1df2 <syscall_checker+0x1df2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1deb, 0x1df2, x86_l_1df2);
x86_l_1ded:
	/* 0x1ded: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1df0:
	/* 0x1df0: jmp    1df4 <syscall_checker+0x1df4> */
	X86_SIM_X86_JMP(0x1df0, 0x1df4, x86_l_1df4);
x86_l_1df2:
	/* 0x1df2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1df4:
	/* 0x1df4: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1df7:
	/* 0x1df7: jae    1e0a <syscall_checker+0x1e0a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1df7, 0x1e0a, x86_l_1e0a);
x86_l_1df9:
	/* 0x1df9: cmp    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dfc:
	/* 0x1dfc: jae    1e0a <syscall_checker+0x1e0a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1dfc, 0x1e0a, x86_l_1e0a);
x86_l_1dfe:
	/* 0x1dfe: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_1e05:
	/* 0x1e05: jmp    2a3e <syscall_checker+0x2a3e> */
	X86_SIM_X86_JMP(0x1e05, 0x2a3e, x86_l_2a3e);
x86_l_1e0a:
	/* 0x1e0a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e0d:
	/* 0x1e0d: jns    1e23 <syscall_checker+0x1e23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e0d, 0x1e23, x86_l_1e23);
x86_l_1e0f:
	/* 0x1e0f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e12:
	/* 0x1e12: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e15:
	/* 0x1e15: je     1e23 <syscall_checker+0x1e23> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e15, 0x1e23, x86_l_1e23);
x86_l_1e17:
	/* 0x1e17: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_2) + (0))));
x86_l_1e1e:
	/* 0x1e1e: jmp    2a3e <syscall_checker+0x2a3e> */
	X86_SIM_X86_JMP(0x1e1e, 0x2a3e, x86_l_2a3e);
x86_l_1e23:
	/* 0x1e23: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1e26:
	/* 0x1e26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e29:
	/* 0x1e29: jns    1e5b <syscall_checker+0x1e5b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e29, 0x1e5b, x86_l_1e5b);
x86_l_1e2b:
	/* 0x1e2b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e2e:
	/* 0x1e2e: movabs rcx,0xffffffff00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744069414584320ULL);
x86_l_1e38:
	/* 0x1e38: and    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1e3b:
	/* 0x1e3b: movabs rax,0xffffff4000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446743249075830784ULL);
x86_l_1e45:
	/* 0x1e45: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e48:
	/* 0x1e48: movabs rcx,0x3f00000001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 270582939649ULL);
x86_l_1e52:
	/* 0x1e52: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e55:
	/* 0x1e55: jb     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e55, 0x332f, x86_l_332f);
x86_l_1e5b:
	/* 0x1e5b: lea    rax,[r12+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e60:
	/* 0x1e60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e63:
	/* 0x1e63: jns    2ae4 <syscall_checker+0x2ae4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e63, 0x2ae4, x86_l_2ae4);
x86_l_1e69:
	/* 0x1e69: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e6c:
	/* 0x1e6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e6f:
	/* 0x1e6f: je     2ae4 <syscall_checker+0x2ae4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e6f, 0x2ae4, x86_l_2ae4);
x86_l_1e75:
	/* 0x1e75: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e78:
	/* 0x1e78: jns    1edf <syscall_checker+0x1edf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e78, 0x1edf, x86_l_1edf);
x86_l_1e7a:
	/* 0x1e7a: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e7d:
	/* 0x1e7d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e80:
	/* 0x1e80: jns    1ee1 <syscall_checker+0x1ee1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e80, 0x1ee1, x86_l_1ee1);
x86_l_1e82:
	/* 0x1e82: mov    al,0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_1e84:
	/* 0x1e84: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e87:
	/* 0x1e87: jns    2a2d <syscall_checker+0x2a2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e87, 0x2a2d, x86_l_2a2d);
x86_l_1e8d:
	/* 0x1e8d: movzx  ecx,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1e90:
	/* 0x1e90: mov    BYTE PTR [rsp+0x30],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e94:
	/* 0x1e94: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1e96:
	/* 0x1e96: je     2a2d <syscall_checker+0x2a2d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e96, 0x2a2d, x86_l_2a2d);
x86_l_1e9c:
	/* 0x1e9c: movzx  eax,BYTE PTR [rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1ea0:
	/* 0x1ea0: mov    BYTE PTR [rsp+0x31],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 49ULL);
x86_l_1ea4:
	/* 0x1ea4: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1ea6:
	/* 0x1ea6: je     1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea6, 0x1ef0, x86_l_1ef0);
x86_l_1ea8:
	/* 0x1ea8: movzx  eax,BYTE PTR [rdx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1eac:
	/* 0x1eac: mov    BYTE PTR [rsp+0x32],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_1eb0:
	/* 0x1eb0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1eb2:
	/* 0x1eb2: je     1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb2, 0x1ef0, x86_l_1ef0);
x86_l_1eb4:
	/* 0x1eb4: movzx  eax,BYTE PTR [rdx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1eb8:
	/* 0x1eb8: mov    BYTE PTR [rsp+0x33],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 51ULL);
x86_l_1ebc:
	/* 0x1ebc: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1ebe:
	/* 0x1ebe: je     1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ebe, 0x1ef0, x86_l_1ef0);
x86_l_1ec0:
	/* 0x1ec0: movzx  eax,BYTE PTR [rdx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1ec4:
	/* 0x1ec4: mov    BYTE PTR [rsp+0x34],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1ec8:
	/* 0x1ec8: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1eca:
	/* 0x1eca: je     1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eca, 0x1ef0, x86_l_1ef0);
x86_l_1ecc:
	/* 0x1ecc: movzx  eax,BYTE PTR [rdx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1ed0:
	/* 0x1ed0: mov    BYTE PTR [rsp+0x35],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_1ed4:
	/* 0x1ed4: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1ed6:
	/* 0x1ed6: je     1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed6, 0x1ef0, x86_l_1ef0);
x86_l_1ed8:
	/* 0x1ed8: mov    BYTE PTR [rsp+0x36],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 231928233984ULL);
x86_l_1edd:
	/* 0x1edd: jmp    1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_X86_JMP(0x1edd, 0x1ef0, x86_l_1ef0);
x86_l_1edf:
	/* 0x1edf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ee1:
	/* 0x1ee1: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ee6:
	/* 0x1ee6: mov    esi,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1eeb:
	/* 0x1eeb: call   1ef0 <syscall_checker+0x1ef0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1ef0:
	/* 0x1ef0: movzx  ecx,BYTE PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 48ULL);
x86_l_1ef5:
	/* 0x1ef5: mov    al,0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_1ef7:
	/* 0x1ef7: cmp    cl,0x5b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_1efa:
	/* 0x1efa: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1efa, 0x2a2f, x86_l_2a2f);
x86_l_1f00:
	/* 0x1f00: movzx  ecx,BYTE PTR [rsp+0x31] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 49ULL);
x86_l_1f05:
	/* 0x1f05: mov    al,0x76 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_1f07:
	/* 0x1f07: cmp    cl,0x76 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_1f0a:
	/* 0x1f0a: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f0a, 0x2a2f, x86_l_2a2f);
x86_l_1f10:
	/* 0x1f10: movzx  ecx,BYTE PTR [rsp+0x32] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 50ULL);
x86_l_1f15:
	/* 0x1f15: mov    al,0x64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_1f17:
	/* 0x1f17: cmp    cl,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_1f1a:
	/* 0x1f1a: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f1a, 0x2a2f, x86_l_2a2f);
x86_l_1f20:
	/* 0x1f20: movzx  ecx,BYTE PTR [rsp+0x33] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 51ULL);
x86_l_1f25:
	/* 0x1f25: mov    al,0x73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_1f27:
	/* 0x1f27: cmp    cl,0x73 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_1f2a:
	/* 0x1f2a: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f2a, 0x2a2f, x86_l_2a2f);
x86_l_1f30:
	/* 0x1f30: movzx  ecx,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_1f35:
	/* 0x1f35: mov    al,0x6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_1f37:
	/* 0x1f37: cmp    cl,0x6f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_1f3a:
	/* 0x1f3a: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f3a, 0x2a2f, x86_l_2a2f);
x86_l_1f40:
	/* 0x1f40: movzx  ecx,BYTE PTR [rsp+0x35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 53ULL);
x86_l_1f45:
	/* 0x1f45: mov    al,0x5d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_1f47:
	/* 0x1f47: cmp    cl,0x5d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_1f4a:
	/* 0x1f4a: jne    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f4a, 0x2a2f, x86_l_2a2f);
x86_l_1f50:
	/* 0x1f50: movzx  ecx,BYTE PTR [rsp+0x36] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 54ULL);
x86_l_1f55:
	/* 0x1f55: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f57:
	/* 0x1f57: jmp    2a2f <syscall_checker+0x2a2f> */
	X86_SIM_X86_JMP(0x1f57, 0x2a2f, x86_l_2a2f);
x86_l_1f5c:
	/* 0x1f5c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f5e:
	/* 0x1f5e: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1f61:
	/* 0x1f61: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f64:
	/* 0x1f64: jns    1f6b <syscall_checker+0x1f6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f64, 0x1f6b, x86_l_1f6b);
x86_l_1f66:
	/* 0x1f66: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f69:
	/* 0x1f69: jmp    1f6d <syscall_checker+0x1f6d> */
	X86_SIM_X86_JMP(0x1f69, 0x1f6d, x86_l_1f6d);
x86_l_1f6b:
	/* 0x1f6b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f6d:
	/* 0x1f6d: add    rcx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_1f71:
	/* 0x1f71: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f74:
	/* 0x1f74: jns    1f7b <syscall_checker+0x1f7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f74, 0x1f7b, x86_l_1f7b);
x86_l_1f76:
	/* 0x1f76: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f79:
	/* 0x1f79: jmp    1f7d <syscall_checker+0x1f7d> */
	X86_SIM_X86_JMP(0x1f79, 0x1f7d, x86_l_1f7d);
x86_l_1f7b:
	/* 0x1f7b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f7d:
	/* 0x1f7d: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f80:
	/* 0x1f80: ja     1f93 <syscall_checker+0x1f93> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f80, 0x1f93, x86_l_1f93);
x86_l_1f82:
	/* 0x1f82: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f85:
	/* 0x1f85: ja     1f93 <syscall_checker+0x1f93> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f85, 0x1f93, x86_l_1f93);
x86_l_1f87:
	/* 0x1f87: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_3) + (0))));
x86_l_1f8e:
	/* 0x1f8e: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x1f8e, 0x3951, x86_l_3951);
x86_l_1f93:
	/* 0x1f93: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f96:
	/* 0x1f96: jns    1ff4 <syscall_checker+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f96, 0x1ff4, x86_l_1ff4);
x86_l_1f98:
	/* 0x1f98: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f9b:
	/* 0x1f9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f9e:
	/* 0x1f9e: je     1ff4 <syscall_checker+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9e, 0x1ff4, x86_l_1ff4);
x86_l_1fa0:
	/* 0x1fa0: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1fa3:
	/* 0x1fa3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fa6:
	/* 0x1fa6: jns    1fad <syscall_checker+0x1fad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fa6, 0x1fad, x86_l_1fad);
x86_l_1fa8:
	/* 0x1fa8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fab:
	/* 0x1fab: jmp    1faf <syscall_checker+0x1faf> */
	X86_SIM_X86_JMP(0x1fab, 0x1faf, x86_l_1faf);
x86_l_1fad:
	/* 0x1fad: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1faf:
	/* 0x1faf: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1fb2:
	/* 0x1fb2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1fb5:
	/* 0x1fb5: jns    1fbc <syscall_checker+0x1fbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb5, 0x1fbc, x86_l_1fbc);
x86_l_1fb7:
	/* 0x1fb7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fba:
	/* 0x1fba: jmp    1fbe <syscall_checker+0x1fbe> */
	X86_SIM_X86_JMP(0x1fba, 0x1fbe, x86_l_1fbe);
x86_l_1fbc:
	/* 0x1fbc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fbe:
	/* 0x1fbe: lea    rsi,[rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1fc2:
	/* 0x1fc2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fc5:
	/* 0x1fc5: jns    1fcc <syscall_checker+0x1fcc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc5, 0x1fcc, x86_l_1fcc);
x86_l_1fc7:
	/* 0x1fc7: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fca:
	/* 0x1fca: jmp    1fce <syscall_checker+0x1fce> */
	X86_SIM_X86_JMP(0x1fca, 0x1fce, x86_l_1fce);
x86_l_1fcc:
	/* 0x1fcc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fce:
	/* 0x1fce: add    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_1fd2:
	/* 0x1fd2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fd5:
	/* 0x1fd5: jns    1fdc <syscall_checker+0x1fdc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd5, 0x1fdc, x86_l_1fdc);
x86_l_1fd7:
	/* 0x1fd7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fda:
	/* 0x1fda: jmp    1fde <syscall_checker+0x1fde> */
	X86_SIM_X86_JMP(0x1fda, 0x1fde, x86_l_1fde);
x86_l_1fdc:
	/* 0x1fdc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fde:
	/* 0x1fde: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fe1:
	/* 0x1fe1: jae    1ff4 <syscall_checker+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fe1, 0x1ff4, x86_l_1ff4);
x86_l_1fe3:
	/* 0x1fe3: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1fe6:
	/* 0x1fe6: jae    1ff4 <syscall_checker+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fe6, 0x1ff4, x86_l_1ff4);
x86_l_1fe8:
	/* 0x1fe8: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_1) + (0))));
x86_l_1fef:
	/* 0x1fef: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x1fef, 0x3951, x86_l_3951);
x86_l_1ff4:
	/* 0x1ff4: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ff7:
	/* 0x1ff7: jns    200d <syscall_checker+0x200d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff7, 0x200d, x86_l_200d);
x86_l_1ff9:
	/* 0x1ff9: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ffc:
	/* 0x1ffc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fff:
	/* 0x1fff: je     200d <syscall_checker+0x200d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fff, 0x200d, x86_l_200d);
x86_l_2001:
	/* 0x2001: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_2) + (0))));
x86_l_2008:
	/* 0x2008: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x2008, 0x3951, x86_l_3951);
x86_l_200d:
	/* 0x200d: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2010:
	/* 0x2010: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2013:
	/* 0x2013: jns    204d <syscall_checker+0x204d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2013, 0x204d, x86_l_204d);
x86_l_2015:
	/* 0x2015: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2018:
	/* 0x2018: movabs rcx,0xffffffff00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744069414584320ULL);
x86_l_2022:
	/* 0x2022: and    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2025:
	/* 0x2025: movabs rax,0xffffff4000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446743249075830784ULL);
x86_l_202f:
	/* 0x202f: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2032:
	/* 0x2032: movabs rcx,0x3f00000001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 270582939649ULL);
x86_l_203c:
	/* 0x203c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_203f:
	/* 0x203f: jae    204d <syscall_checker+0x204d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x203f, 0x204d, x86_l_204d);
x86_l_2041:
	/* 0x2041: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_4) + (0))));
x86_l_2048:
	/* 0x2048: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x2048, 0x3951, x86_l_3951);
x86_l_204d:
	/* 0x204d: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2055:
	/* 0x2055: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2058:
	/* 0x2058: jns    38f6 <syscall_checker+0x38f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2058, 0x38f6, x86_l_38f6);
x86_l_205e:
	/* 0x205e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2061:
	/* 0x2061: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2064:
	/* 0x2064: je     38f6 <syscall_checker+0x38f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2064, 0x38f6, x86_l_38f6);
x86_l_206a:
	/* 0x206a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_206d:
	/* 0x206d: jns    26b4 <syscall_checker+0x26b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x206d, 0x26b4, x86_l_26b4);
x86_l_2073:
	/* 0x2073: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2076:
	/* 0x2076: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2079:
	/* 0x2079: jns    26b6 <syscall_checker+0x26b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2079, 0x26b6, x86_l_26b6);
x86_l_207f:
	/* 0x207f: mov    al,0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_2081:
	/* 0x2081: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2084:
	/* 0x2084: jns    38e7 <syscall_checker+0x38e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2084, 0x38e7, x86_l_38e7);
x86_l_208a:
	/* 0x208a: movzx  ecx,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_208d:
	/* 0x208d: mov    BYTE PTR [rsp+0x30],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2091:
	/* 0x2091: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2093:
	/* 0x2093: je     38e7 <syscall_checker+0x38e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2093, 0x38e7, x86_l_38e7);
x86_l_2099:
	/* 0x2099: movzx  eax,BYTE PTR [rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_209d:
	/* 0x209d: mov    BYTE PTR [rsp+0x31],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 49ULL);
x86_l_20a1:
	/* 0x20a1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20a3:
	/* 0x20a3: je     26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a3, 0x26c5, x86_l_26c5);
x86_l_20a9:
	/* 0x20a9: movzx  eax,BYTE PTR [rdx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_20ad:
	/* 0x20ad: mov    BYTE PTR [rsp+0x32],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_20b1:
	/* 0x20b1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20b3:
	/* 0x20b3: je     26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b3, 0x26c5, x86_l_26c5);
x86_l_20b9:
	/* 0x20b9: movzx  eax,BYTE PTR [rdx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_20bd:
	/* 0x20bd: mov    BYTE PTR [rsp+0x33],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 51ULL);
x86_l_20c1:
	/* 0x20c1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20c3:
	/* 0x20c3: je     26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20c3, 0x26c5, x86_l_26c5);
x86_l_20c9:
	/* 0x20c9: movzx  eax,BYTE PTR [rdx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_20cd:
	/* 0x20cd: mov    BYTE PTR [rsp+0x34],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_20d1:
	/* 0x20d1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20d3:
	/* 0x20d3: je     26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20d3, 0x26c5, x86_l_26c5);
x86_l_20d9:
	/* 0x20d9: movzx  eax,BYTE PTR [rdx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_20dd:
	/* 0x20dd: mov    BYTE PTR [rsp+0x35],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 53ULL);
x86_l_20e1:
	/* 0x20e1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_20e3:
	/* 0x20e3: je     26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e3, 0x26c5, x86_l_26c5);
x86_l_20e9:
	/* 0x20e9: mov    BYTE PTR [rsp+0x36],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 231928233984ULL);
x86_l_20ee:
	/* 0x20ee: jmp    26c5 <syscall_checker+0x26c5> */
	X86_SIM_X86_JMP(0x20ee, 0x26c5, x86_l_26c5);
x86_l_20f3:
	/* 0x20f3: mov    eax,DWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_20fa:
	/* 0x20fa: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2101:
	/* 0x2101: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2109:
	/* 0x2109: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_2110:
	/* 0x2110: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2115:
	/* 0x2115: call   211a <syscall_checker+0x211a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_211a:
	/* 0x211a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_211d:
	/* 0x211d: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x211d, 0xda6, x86_l_da6);
x86_l_2123:
	/* 0x2123: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2126:
	/* 0x2126: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_212d:
	/* 0x212d: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2131:
	/* 0x2131: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_2136:
	/* 0x2136: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2139:
	/* 0x2139: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_213b:
	/* 0x213b: call   2140 <syscall_checker+0x2140> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_2140:
	/* 0x2140: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_2147:
	/* 0x2147: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_214c:
	/* 0x214c: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2151:
	/* 0x2151: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2154:
	/* 0x2154: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2157:
	/* 0x2157: call   215c <syscall_checker+0x215c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_215c:
	/* 0x215c: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2164:
	/* 0x2164: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2167:
	/* 0x2167: call   216c <syscall_checker+0x216c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_216c:
	/* 0x216c: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2174:
	/* 0x2174: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2177:
	/* 0x2177: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_217c:
	/* 0x217c: jne    2ab <syscall_checker+0x2ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x217c, 0x2ab, x86_l_2ab);
x86_l_2182:
	/* 0x2182: jmp    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JMP(0x2182, 0xda6, x86_l_da6);
x86_l_2187:
	/* 0x2187: mov    eax,DWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_218e:
	/* 0x218e: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2195:
	/* 0x2195: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_219d:
	/* 0x219d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_21a4:
	/* 0x21a4: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21a9:
	/* 0x21a9: call   21ae <syscall_checker+0x21ae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_21ae:
	/* 0x21ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b1:
	/* 0x21b1: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b1, 0x332f, x86_l_332f);
x86_l_21b7:
	/* 0x21b7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21ba:
	/* 0x21ba: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_21c1:
	/* 0x21c1: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21c5:
	/* 0x21c5: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_21ca:
	/* 0x21ca: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21cd:
	/* 0x21cd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21cf:
	/* 0x21cf: call   21d4 <syscall_checker+0x21d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_21d4:
	/* 0x21d4: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_21db:
	/* 0x21db: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21e0:
	/* 0x21e0: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_21e5:
	/* 0x21e5: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21e8:
	/* 0x21e8: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21eb:
	/* 0x21eb: call   21f0 <syscall_checker+0x21f0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_21f0:
	/* 0x21f0: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_21f8:
	/* 0x21f8: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21fb:
	/* 0x21fb: call   2200 <syscall_checker+0x2200> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2200:
	/* 0x2200: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2208:
	/* 0x2208: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_220b:
	/* 0x220b: jne    fbb <syscall_checker+0xfbb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x220b, 0xfbb, x86_l_fbb);
x86_l_2211:
	/* 0x2211: jmp    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JMP(0x2211, 0x332f, x86_l_332f);
x86_l_2216:
	/* 0x2216: mov    eax,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_221d:
	/* 0x221d: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2224:
	/* 0x2224: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_222c:
	/* 0x222c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_2233:
	/* 0x2233: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2238:
	/* 0x2238: call   223d <syscall_checker+0x223d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_223d:
	/* 0x223d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2240:
	/* 0x2240: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2240, 0xda6, x86_l_da6);
x86_l_2246:
	/* 0x2246: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2249:
	/* 0x2249: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2250:
	/* 0x2250: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2254:
	/* 0x2254: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_2259:
	/* 0x2259: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_225c:
	/* 0x225c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_225e:
	/* 0x225e: call   2263 <syscall_checker+0x2263> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_2263:
	/* 0x2263: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_226a:
	/* 0x226a: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_226f:
	/* 0x226f: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2274:
	/* 0x2274: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2277:
	/* 0x2277: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_227a:
	/* 0x227a: call   227f <syscall_checker+0x227f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_227f:
	/* 0x227f: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2287:
	/* 0x2287: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_228a:
	/* 0x228a: call   228f <syscall_checker+0x228f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_228f:
	/* 0x228f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2292:
	/* 0x2292: je     da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2292, 0xda6, x86_l_da6);
x86_l_2298:
	/* 0x2298: mov    r13,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_229f:
	/* 0x229f: lea    r8,[r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_22a3:
	/* 0x22a3: mov    rcx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_22a6:
	/* 0x22a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22a9:
	/* 0x22a9: jns    2769 <syscall_checker+0x2769> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a9, 0x2769, x86_l_2769);
x86_l_22af:
	/* 0x22af: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22b2:
	/* 0x22b2: jmp    276b <syscall_checker+0x276b> */
	X86_SIM_X86_JMP(0x22b2, 0x276b, x86_l_276b);
x86_l_22b7:
	/* 0x22b7: mov    eax,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_22be:
	/* 0x22be: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_22c5:
	/* 0x22c5: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_22cd:
	/* 0x22cd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_22d4:
	/* 0x22d4: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_22d9:
	/* 0x22d9: call   22de <syscall_checker+0x22de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22de:
	/* 0x22de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22e1:
	/* 0x22e1: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22e1, 0x332f, x86_l_332f);
x86_l_22e7:
	/* 0x22e7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22ea:
	/* 0x22ea: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_22f1:
	/* 0x22f1: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_22f5:
	/* 0x22f5: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_22fa:
	/* 0x22fa: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_22fd:
	/* 0x22fd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ff:
	/* 0x22ff: call   2304 <syscall_checker+0x2304> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_2304:
	/* 0x2304: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_230b:
	/* 0x230b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2310:
	/* 0x2310: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2315:
	/* 0x2315: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2318:
	/* 0x2318: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_231b:
	/* 0x231b: call   2320 <syscall_checker+0x2320> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2320:
	/* 0x2320: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2328:
	/* 0x2328: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_232b:
	/* 0x232b: call   2330 <syscall_checker+0x2330> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2330:
	/* 0x2330: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2333:
	/* 0x2333: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2333, 0x332f, x86_l_332f);
x86_l_2339:
	/* 0x2339: mov    r13,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2340:
	/* 0x2340: lea    r8,[r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2344:
	/* 0x2344: mov    rcx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2347:
	/* 0x2347: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_234a:
	/* 0x234a: jns    277e <syscall_checker+0x277e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x234a, 0x277e, x86_l_277e);
x86_l_2350:
	/* 0x2350: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2353:
	/* 0x2353: jmp    2780 <syscall_checker+0x2780> */
	X86_SIM_X86_JMP(0x2353, 0x2780, x86_l_2780);
x86_l_2358:
	/* 0x2358: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_235b:
	/* 0x235b: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_235f:
	/* 0x235f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2362:
	/* 0x2362: jns    2731 <syscall_checker+0x2731> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2362, 0x2731, x86_l_2731);
x86_l_2368:
	/* 0x2368: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_236b:
	/* 0x236b: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_2372:
	/* 0x2372: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2376:
	/* 0x2376: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_237d:
	/* 0x237d: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2381:
	/* 0x2381: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_2388:
	/* 0x2388: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_238c:
	/* 0x238c: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_2393:
	/* 0x2393: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2397:
	/* 0x2397: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_239e:
	/* 0x239e: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23a2:
	/* 0x23a2: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_23a9:
	/* 0x23a9: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_23ad:
	/* 0x23ad: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_23b4:
	/* 0x23b4: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_23b8:
	/* 0x23b8: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_23bf:
	/* 0x23bf: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_23c3:
	/* 0x23c3: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_23ca:
	/* 0x23ca: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_23ce:
	/* 0x23ce: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_23d5:
	/* 0x23d5: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_23d9:
	/* 0x23d9: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_23e0:
	/* 0x23e0: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_23e4:
	/* 0x23e4: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_23eb:
	/* 0x23eb: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_23ef:
	/* 0x23ef: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_23f6:
	/* 0x23f6: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_23fa:
	/* 0x23fa: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_2401:
	/* 0x2401: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2405:
	/* 0x2405: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_240c:
	/* 0x240c: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2410:
	/* 0x2410: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_2417:
	/* 0x2417: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_241e:
	/* 0x241e: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_2425:
	/* 0x2425: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_242c:
	/* 0x242c: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_2433:
	/* 0x2433: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_243a:
	/* 0x243a: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_2441:
	/* 0x2441: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2448:
	/* 0x2448: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_244f:
	/* 0x244f: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2456:
	/* 0x2456: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_245d:
	/* 0x245d: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2464:
	/* 0x2464: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_246b:
	/* 0x246b: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2472:
	/* 0x2472: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_2479:
	/* 0x2479: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2480:
	/* 0x2480: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_2487:
	/* 0x2487: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_248e:
	/* 0x248e: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_2495:
	/* 0x2495: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_249c:
	/* 0x249c: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_24a3:
	/* 0x24a3: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_24aa:
	/* 0x24aa: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_24b1:
	/* 0x24b1: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_24b8:
	/* 0x24b8: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_24bf:
	/* 0x24bf: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_24c6:
	/* 0x24c6: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_24cd:
	/* 0x24cd: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_24d4:
	/* 0x24d4: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_24db:
	/* 0x24db: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_24e2:
	/* 0x24e2: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_24e9:
	/* 0x24e9: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_24f0:
	/* 0x24f0: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_24f7:
	/* 0x24f7: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_24fd:
	/* 0x24fd: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_2502:
	/* 0x2502: jmp    392 <syscall_checker+0x392> */
	X86_SIM_X86_JMP(0x2502, 0x392, x86_l_392);
x86_l_2507:
	/* 0x2507: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_250a:
	/* 0x250a: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_250e:
	/* 0x250e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2511:
	/* 0x2511: jns    274c <syscall_checker+0x274c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2511, 0x274c, x86_l_274c);
x86_l_2517:
	/* 0x2517: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_251a:
	/* 0x251a: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_2521:
	/* 0x2521: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2525:
	/* 0x2525: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_252c:
	/* 0x252c: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2530:
	/* 0x2530: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_2537:
	/* 0x2537: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_253b:
	/* 0x253b: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_2542:
	/* 0x2542: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2546:
	/* 0x2546: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_254d:
	/* 0x254d: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2551:
	/* 0x2551: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_2558:
	/* 0x2558: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_255c:
	/* 0x255c: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_2563:
	/* 0x2563: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2567:
	/* 0x2567: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_256e:
	/* 0x256e: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2572:
	/* 0x2572: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_2579:
	/* 0x2579: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_257d:
	/* 0x257d: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_2584:
	/* 0x2584: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2588:
	/* 0x2588: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_258f:
	/* 0x258f: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2593:
	/* 0x2593: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_259a:
	/* 0x259a: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_259e:
	/* 0x259e: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_25a5:
	/* 0x25a5: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_25a9:
	/* 0x25a9: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_25b0:
	/* 0x25b0: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_25b4:
	/* 0x25b4: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_25bb:
	/* 0x25bb: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_25bf:
	/* 0x25bf: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_25c6:
	/* 0x25c6: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_25cd:
	/* 0x25cd: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_25d4:
	/* 0x25d4: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_25db:
	/* 0x25db: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_25e2:
	/* 0x25e2: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_25e9:
	/* 0x25e9: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_25f0:
	/* 0x25f0: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_25f7:
	/* 0x25f7: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_25fe:
	/* 0x25fe: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2605:
	/* 0x2605: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_260c:
	/* 0x260c: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2613:
	/* 0x2613: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_261a:
	/* 0x261a: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2621:
	/* 0x2621: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_2628:
	/* 0x2628: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_262f:
	/* 0x262f: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_2636:
	/* 0x2636: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_263d:
	/* 0x263d: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_2644:
	/* 0x2644: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_264b:
	/* 0x264b: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_2652:
	/* 0x2652: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2659:
	/* 0x2659: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_2660:
	/* 0x2660: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2667:
	/* 0x2667: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_266e:
	/* 0x266e: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2675:
	/* 0x2675: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_267c:
	/* 0x267c: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2683:
	/* 0x2683: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_268a:
	/* 0x268a: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_2691:
	/* 0x2691: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_2698:
	/* 0x2698: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_269f:
	/* 0x269f: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_26a6:
	/* 0x26a6: movzx  eax,WORD PTR [rbp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_26aa:
	/* 0x26aa: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_26af:
	/* 0x26af: jmp    10a0 <syscall_checker+0x10a0> */
	X86_SIM_X86_JMP(0x26af, 0x10a0, x86_l_10a0);
x86_l_26b4:
	/* 0x26b4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b6:
	/* 0x26b6: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_26bb:
	/* 0x26bb: mov    esi,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_26c0:
	/* 0x26c0: call   26c5 <syscall_checker+0x26c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_26c5:
	/* 0x26c5: movzx  ecx,BYTE PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 48ULL);
x86_l_26ca:
	/* 0x26ca: mov    al,0x5b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_26cc:
	/* 0x26cc: cmp    cl,0x5b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 91ULL);
x86_l_26cf:
	/* 0x26cf: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26cf, 0x38e9, x86_l_38e9);
x86_l_26d5:
	/* 0x26d5: movzx  ecx,BYTE PTR [rsp+0x31] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 49ULL);
x86_l_26da:
	/* 0x26da: mov    al,0x76 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_26dc:
	/* 0x26dc: cmp    cl,0x76 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 118ULL);
x86_l_26df:
	/* 0x26df: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26df, 0x38e9, x86_l_38e9);
x86_l_26e5:
	/* 0x26e5: movzx  ecx,BYTE PTR [rsp+0x32] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 50ULL);
x86_l_26ea:
	/* 0x26ea: mov    al,0x64 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_26ec:
	/* 0x26ec: cmp    cl,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 100ULL);
x86_l_26ef:
	/* 0x26ef: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26ef, 0x38e9, x86_l_38e9);
x86_l_26f5:
	/* 0x26f5: movzx  ecx,BYTE PTR [rsp+0x33] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 51ULL);
x86_l_26fa:
	/* 0x26fa: mov    al,0x73 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_26fc:
	/* 0x26fc: cmp    cl,0x73 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 115ULL);
x86_l_26ff:
	/* 0x26ff: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26ff, 0x38e9, x86_l_38e9);
x86_l_2705:
	/* 0x2705: movzx  ecx,BYTE PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 52ULL);
x86_l_270a:
	/* 0x270a: mov    al,0x6f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_270c:
	/* 0x270c: cmp    cl,0x6f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 111ULL);
x86_l_270f:
	/* 0x270f: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x270f, 0x38e9, x86_l_38e9);
x86_l_2715:
	/* 0x2715: movzx  ecx,BYTE PTR [rsp+0x35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 53ULL);
x86_l_271a:
	/* 0x271a: mov    al,0x5d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_271c:
	/* 0x271c: cmp    cl,0x5d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_271f:
	/* 0x271f: jne    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x271f, 0x38e9, x86_l_38e9);
x86_l_2725:
	/* 0x2725: movzx  ecx,BYTE PTR [rsp+0x36] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 54ULL);
x86_l_272a:
	/* 0x272a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_272c:
	/* 0x272c: jmp    38e9 <syscall_checker+0x38e9> */
	X86_SIM_X86_JMP(0x272c, 0x38e9, x86_l_38e9);
x86_l_2731:
	/* 0x2731: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_2738:
	/* 0x2738: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_273d:
	/* 0x273d: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2740:
	/* 0x2740: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2742:
	/* 0x2742: call   2747 <syscall_checker+0x2747> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_2747:
	/* 0x2747: jmp    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JMP(0x2747, 0xda6, x86_l_da6);
x86_l_274c:
	/* 0x274c: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2751:
	/* 0x2751: add    rdi,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_2758:
	/* 0x2758: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_275d:
	/* 0x275d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_275f:
	/* 0x275f: call   2764 <syscall_checker+0x2764> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_2764:
	/* 0x2764: jmp    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JMP(0x2764, 0x332f, x86_l_332f);
x86_l_2769:
	/* 0x2769: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_276b:
	/* 0x276b: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2770:
	/* 0x2770: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2774:
	/* 0x2774: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2777:
	/* 0x2777: jns    2793 <syscall_checker+0x2793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2777, 0x2793, x86_l_2793);
x86_l_2779:
	/* 0x2779: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277c:
	/* 0x277c: jmp    2795 <syscall_checker+0x2795> */
	X86_SIM_X86_JMP(0x277c, 0x2795, x86_l_2795);
x86_l_277e:
	/* 0x277e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2780:
	/* 0x2780: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2785:
	/* 0x2785: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2789:
	/* 0x2789: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_278c:
	/* 0x278c: jns    27aa <syscall_checker+0x27aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x278c, 0x27aa, x86_l_27aa);
x86_l_278e:
	/* 0x278e: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2791:
	/* 0x2791: jmp    27ac <syscall_checker+0x27ac> */
	X86_SIM_X86_JMP(0x2791, 0x27ac, x86_l_27ac);
x86_l_2793:
	/* 0x2793: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2795:
	/* 0x2795: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_279a:
	/* 0x279a: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_279e:
	/* 0x279e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a0:
	/* 0x27a0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27a3:
	/* 0x27a3: jns    27c1 <syscall_checker+0x27c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a3, 0x27c1, x86_l_27c1);
x86_l_27a5:
	/* 0x27a5: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27a8:
	/* 0x27a8: jmp    27c3 <syscall_checker+0x27c3> */
	X86_SIM_X86_JMP(0x27a8, 0x27c3, x86_l_27c3);
x86_l_27aa:
	/* 0x27aa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27ac:
	/* 0x27ac: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27b1:
	/* 0x27b1: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_27b5:
	/* 0x27b5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b7:
	/* 0x27b7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27ba:
	/* 0x27ba: jns    27e9 <syscall_checker+0x27e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ba, 0x27e9, x86_l_27e9);
x86_l_27bc:
	/* 0x27bc: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27bf:
	/* 0x27bf: jmp    27eb <syscall_checker+0x27eb> */
	X86_SIM_X86_JMP(0x27bf, 0x27eb, x86_l_27eb);
x86_l_27c1:
	/* 0x27c1: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27c3:
	/* 0x27c3: lea    rdx,[rbx+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_27c7:
	/* 0x27c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27ca:
	/* 0x27ca: jns    27ce <syscall_checker+0x27ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ca, 0x27ce, x86_l_27ce);
x86_l_27cc:
	/* 0x27cc: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ce:
	/* 0x27ce: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d3:
	/* 0x27d3: mov    DWORD PTR [rax+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_27d6:
	/* 0x27d6: lea    rcx,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27da:
	/* 0x27da: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27dd:
	/* 0x27dd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27df:
	/* 0x27df: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27e2:
	/* 0x27e2: jns    2811 <syscall_checker+0x2811> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27e2, 0x2811, x86_l_2811);
x86_l_27e4:
	/* 0x27e4: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27e7:
	/* 0x27e7: jmp    2813 <syscall_checker+0x2813> */
	X86_SIM_X86_JMP(0x27e7, 0x2813, x86_l_2813);
x86_l_27e9:
	/* 0x27e9: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27eb:
	/* 0x27eb: lea    rdx,[rbx+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_27ef:
	/* 0x27ef: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27f2:
	/* 0x27f2: jns    27f6 <syscall_checker+0x27f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27f2, 0x27f6, x86_l_27f6);
x86_l_27f4:
	/* 0x27f4: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27f6:
	/* 0x27f6: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27fb:
	/* 0x27fb: mov    DWORD PTR [rax+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_27fe:
	/* 0x27fe: lea    rcx,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2802:
	/* 0x2802: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2805:
	/* 0x2805: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2807:
	/* 0x2807: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_280a:
	/* 0x280a: jns    2845 <syscall_checker+0x2845> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x280a, 0x2845, x86_l_2845);
x86_l_280c:
	/* 0x280c: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280f:
	/* 0x280f: jmp    2847 <syscall_checker+0x2847> */
	X86_SIM_X86_JMP(0x280f, 0x2847, x86_l_2847);
x86_l_2811:
	/* 0x2811: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2813:
	/* 0x2813: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2816:
	/* 0x2816: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2819:
	/* 0x2819: jns    281d <syscall_checker+0x281d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2819, 0x281d, x86_l_281d);
x86_l_281b:
	/* 0x281b: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_281d:
	/* 0x281d: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_281f:
	/* 0x281f: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2823:
	/* 0x2823: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2826:
	/* 0x2826: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_282a:
	/* 0x282a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_282c:
	/* 0x282c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_282f:
	/* 0x282f: jns    2833 <syscall_checker+0x2833> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x282f, 0x2833, x86_l_2833);
x86_l_2831:
	/* 0x2831: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2833:
	/* 0x2833: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2838:
	/* 0x2838: mov    DWORD PTR [rax+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_283b:
	/* 0x283b: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_283e:
	/* 0x283e: jns    2879 <syscall_checker+0x2879> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x283e, 0x2879, x86_l_2879);
x86_l_2840:
	/* 0x2840: mov    rdx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2843:
	/* 0x2843: jmp    287b <syscall_checker+0x287b> */
	X86_SIM_X86_JMP(0x2843, 0x287b, x86_l_287b);
x86_l_2845:
	/* 0x2845: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2847:
	/* 0x2847: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_284a:
	/* 0x284a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_284d:
	/* 0x284d: jns    2851 <syscall_checker+0x2851> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x284d, 0x2851, x86_l_2851);
x86_l_284f:
	/* 0x284f: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2851:
	/* 0x2851: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2853:
	/* 0x2853: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2857:
	/* 0x2857: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_285a:
	/* 0x285a: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_285e:
	/* 0x285e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2860:
	/* 0x2860: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2863:
	/* 0x2863: jns    2867 <syscall_checker+0x2867> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2863, 0x2867, x86_l_2867);
x86_l_2865:
	/* 0x2865: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2867:
	/* 0x2867: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_286c:
	/* 0x286c: mov    DWORD PTR [rax+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_286f:
	/* 0x286f: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2872:
	/* 0x2872: jns    288b <syscall_checker+0x288b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2872, 0x288b, x86_l_288b);
x86_l_2874:
	/* 0x2874: mov    rdx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2877:
	/* 0x2877: jmp    288d <syscall_checker+0x288d> */
	X86_SIM_X86_JMP(0x2877, 0x288d, x86_l_288d);
x86_l_2879:
	/* 0x2879: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_287b:
	/* 0x287b: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_287f:
	/* 0x287f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2881:
	/* 0x2881: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2884:
	/* 0x2884: jns    289d <syscall_checker+0x289d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2884, 0x289d, x86_l_289d);
x86_l_2886:
	/* 0x2886: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2889:
	/* 0x2889: jmp    289f <syscall_checker+0x289f> */
	X86_SIM_X86_JMP(0x2889, 0x289f, x86_l_289f);
x86_l_288b:
	/* 0x288b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_288d:
	/* 0x288d: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2891:
	/* 0x2891: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2893:
	/* 0x2893: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2896:
	/* 0x2896: jns    28d3 <syscall_checker+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2896, 0x28d3, x86_l_28d3);
x86_l_2898:
	/* 0x2898: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_289b:
	/* 0x289b: jmp    28d5 <syscall_checker+0x28d5> */
	X86_SIM_X86_JMP(0x289b, 0x28d5, x86_l_28d5);
x86_l_289d:
	/* 0x289d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_289f:
	/* 0x289f: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28a2:
	/* 0x28a2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28a5:
	/* 0x28a5: jns    28a9 <syscall_checker+0x28a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28a5, 0x28a9, x86_l_28a9);
x86_l_28a7:
	/* 0x28a7: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a9:
	/* 0x28a9: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28ab:
	/* 0x28ab: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_28af:
	/* 0x28af: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28b2:
	/* 0x28b2: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_28b6:
	/* 0x28b6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b8:
	/* 0x28b8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28bb:
	/* 0x28bb: jns    28bf <syscall_checker+0x28bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28bb, 0x28bf, x86_l_28bf);
x86_l_28bd:
	/* 0x28bd: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28bf:
	/* 0x28bf: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28c4:
	/* 0x28c4: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c7:
	/* 0x28c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c9:
	/* 0x28c9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28cc:
	/* 0x28cc: jns    2909 <syscall_checker+0x2909> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28cc, 0x2909, x86_l_2909);
x86_l_28ce:
	/* 0x28ce: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d1:
	/* 0x28d1: jmp    290b <syscall_checker+0x290b> */
	X86_SIM_X86_JMP(0x28d1, 0x290b, x86_l_290b);
x86_l_28d3:
	/* 0x28d3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d5:
	/* 0x28d5: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28d8:
	/* 0x28d8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28db:
	/* 0x28db: jns    28df <syscall_checker+0x28df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28db, 0x28df, x86_l_28df);
x86_l_28dd:
	/* 0x28dd: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28df:
	/* 0x28df: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28e1:
	/* 0x28e1: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_28e5:
	/* 0x28e5: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28e8:
	/* 0x28e8: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_28ec:
	/* 0x28ec: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ee:
	/* 0x28ee: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28f1:
	/* 0x28f1: jns    28f5 <syscall_checker+0x28f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28f1, 0x28f5, x86_l_28f5);
x86_l_28f3:
	/* 0x28f3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28f5:
	/* 0x28f5: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28fa:
	/* 0x28fa: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28fd:
	/* 0x28fd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ff:
	/* 0x28ff: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2902:
	/* 0x2902: jns    292e <syscall_checker+0x292e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2902, 0x292e, x86_l_292e);
x86_l_2904:
	/* 0x2904: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2907:
	/* 0x2907: jmp    2930 <syscall_checker+0x2930> */
	X86_SIM_X86_JMP(0x2907, 0x2930, x86_l_2930);
x86_l_2909:
	/* 0x2909: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_290b:
	/* 0x290b: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_290e:
	/* 0x290e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2911:
	/* 0x2911: jns    2915 <syscall_checker+0x2915> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2911, 0x2915, x86_l_2915);
x86_l_2913:
	/* 0x2913: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2915:
	/* 0x2915: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2917:
	/* 0x2917: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_291b:
	/* 0x291b: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_291e:
	/* 0x291e: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2922:
	/* 0x2922: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2924:
	/* 0x2924: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2927:
	/* 0x2927: jns    2953 <syscall_checker+0x2953> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2927, 0x2953, x86_l_2953);
x86_l_2929:
	/* 0x2929: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_292c:
	/* 0x292c: jmp    2955 <syscall_checker+0x2955> */
	X86_SIM_X86_JMP(0x292c, 0x2955, x86_l_2955);
x86_l_292e:
	/* 0x292e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2930:
	/* 0x2930: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2933:
	/* 0x2933: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2936:
	/* 0x2936: jns    293a <syscall_checker+0x293a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2936, 0x293a, x86_l_293a);
x86_l_2938:
	/* 0x2938: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_293a:
	/* 0x293a: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_293c:
	/* 0x293c: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2940:
	/* 0x2940: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2943:
	/* 0x2943: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2947:
	/* 0x2947: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2949:
	/* 0x2949: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_294c:
	/* 0x294c: jns    2973 <syscall_checker+0x2973> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x294c, 0x2973, x86_l_2973);
x86_l_294e:
	/* 0x294e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2951:
	/* 0x2951: jmp    2975 <syscall_checker+0x2975> */
	X86_SIM_X86_JMP(0x2951, 0x2975, x86_l_2975);
x86_l_2953:
	/* 0x2953: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2955:
	/* 0x2955: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2959:
	/* 0x2959: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_295c:
	/* 0x295c: jns    2960 <syscall_checker+0x2960> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x295c, 0x2960, x86_l_2960);
x86_l_295e:
	/* 0x295e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2960:
	/* 0x2960: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2964:
	/* 0x2964: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2967:
	/* 0x2967: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2969:
	/* 0x2969: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_296c:
	/* 0x296c: jns    2993 <syscall_checker+0x2993> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296c, 0x2993, x86_l_2993);
x86_l_296e:
	/* 0x296e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2971:
	/* 0x2971: jmp    2995 <syscall_checker+0x2995> */
	X86_SIM_X86_JMP(0x2971, 0x2995, x86_l_2995);
x86_l_2973:
	/* 0x2973: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2975:
	/* 0x2975: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2979:
	/* 0x2979: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_297c:
	/* 0x297c: jns    2980 <syscall_checker+0x2980> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x297c, 0x2980, x86_l_2980);
x86_l_297e:
	/* 0x297e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2980:
	/* 0x2980: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2984:
	/* 0x2984: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2987:
	/* 0x2987: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2989:
	/* 0x2989: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_298c:
	/* 0x298c: jns    29b8 <syscall_checker+0x29b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x298c, 0x29b8, x86_l_29b8);
x86_l_298e:
	/* 0x298e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2991:
	/* 0x2991: jmp    29ba <syscall_checker+0x29ba> */
	X86_SIM_X86_JMP(0x2991, 0x29ba, x86_l_29ba);
x86_l_2993:
	/* 0x2993: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2995:
	/* 0x2995: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2998:
	/* 0x2998: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_299b:
	/* 0x299b: jns    299f <syscall_checker+0x299f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x299b, 0x299f, x86_l_299f);
x86_l_299d:
	/* 0x299d: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_299f:
	/* 0x299f: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_29a1:
	/* 0x29a1: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_29a5:
	/* 0x29a5: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_29a8:
	/* 0x29a8: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29ac:
	/* 0x29ac: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29ae:
	/* 0x29ae: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29b1:
	/* 0x29b1: jns    29dd <syscall_checker+0x29dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29b1, 0x29dd, x86_l_29dd);
x86_l_29b3:
	/* 0x29b3: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b6:
	/* 0x29b6: jmp    29df <syscall_checker+0x29df> */
	X86_SIM_X86_JMP(0x29b6, 0x29df, x86_l_29df);
x86_l_29b8:
	/* 0x29b8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29ba:
	/* 0x29ba: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29bd:
	/* 0x29bd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29c0:
	/* 0x29c0: jns    29c4 <syscall_checker+0x29c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29c0, 0x29c4, x86_l_29c4);
x86_l_29c2:
	/* 0x29c2: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c4:
	/* 0x29c4: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_29c6:
	/* 0x29c6: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_29ca:
	/* 0x29ca: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_29cd:
	/* 0x29cd: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29d1:
	/* 0x29d1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d3:
	/* 0x29d3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29d6:
	/* 0x29d6: jns    2a05 <syscall_checker+0x2a05> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d6, 0x2a05, x86_l_2a05);
x86_l_29d8:
	/* 0x29d8: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29db:
	/* 0x29db: jmp    2a07 <syscall_checker+0x2a07> */
	X86_SIM_X86_JMP(0x29db, 0x2a07, x86_l_2a07);
x86_l_29dd:
	/* 0x29dd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29df:
	/* 0x29df: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_29e3:
	/* 0x29e3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29e6:
	/* 0x29e6: jns    29ea <syscall_checker+0x29ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29e6, 0x29ea, x86_l_29ea);
x86_l_29e8:
	/* 0x29e8: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ea:
	/* 0x29ea: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_29ec:
	/* 0x29ec: jne    3371 <syscall_checker+0x3371> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29ec, 0x3371, x86_l_3371);
x86_l_29f2:
	/* 0x29f2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f4:
	/* 0x29f4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29f7:
	/* 0x29f7: jns    3347 <syscall_checker+0x3347> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f7, 0x3347, x86_l_3347);
x86_l_29fd:
	/* 0x29fd: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a00:
	/* 0x2a00: jmp    3349 <syscall_checker+0x3349> */
	X86_SIM_X86_JMP(0x2a00, 0x3349, x86_l_3349);
x86_l_2a05:
	/* 0x2a05: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a07:
	/* 0x2a07: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2a0b:
	/* 0x2a0b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a0e:
	/* 0x2a0e: jns    2a12 <syscall_checker+0x2a12> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a0e, 0x2a12, x86_l_2a12);
x86_l_2a10:
	/* 0x2a10: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a12:
	/* 0x2a12: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2a14:
	/* 0x2a14: jne    3639 <syscall_checker+0x3639> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a14, 0x3639, x86_l_3639);
x86_l_2a1a:
	/* 0x2a1a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a1c:
	/* 0x2a1c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a1f:
	/* 0x2a1f: jns    360f <syscall_checker+0x360f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a1f, 0x360f, x86_l_360f);
x86_l_2a25:
	/* 0x2a25: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a28:
	/* 0x2a28: jmp    3611 <syscall_checker+0x3611> */
	X86_SIM_X86_JMP(0x2a28, 0x3611, x86_l_3611);
x86_l_2a2d:
	/* 0x2a2d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a2f:
	/* 0x2a2f: cmp    al,cl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a31:
	/* 0x2a31: jne    2ae4 <syscall_checker+0x2ae4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a31, 0x2ae4, x86_l_2ae4);
x86_l_2a37:
	/* 0x2a37: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_5) + (0))));
x86_l_2a3e:
	/* 0x2a3e: mov    rbx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2a41:
	/* 0x2a41: shr    rbx,0x3f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 63ULL);
x86_l_2a45:
	/* 0x2a45: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a48:
	/* 0x2a48: jns    2a50 <syscall_checker+0x2a50> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a48, 0x2a50, x86_l_2a50);
x86_l_2a4a:
	/* 0x2a4a: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a4e:
	/* 0x2a4e: jmp    2a52 <syscall_checker+0x2a52> */
	X86_SIM_X86_JMP(0x2a4e, 0x2a52, x86_l_2a52);
x86_l_2a50:
	/* 0x2a50: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a52:
	/* 0x2a52: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2a57:
	/* 0x2a57: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2a5a:
	/* 0x2a5a: jns    2a62 <syscall_checker+0x2a62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a5a, 0x2a62, x86_l_2a62);
x86_l_2a5c:
	/* 0x2a5c: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a60:
	/* 0x2a60: jmp    2a64 <syscall_checker+0x2a64> */
	X86_SIM_X86_JMP(0x2a60, 0x2a64, x86_l_2a64);
x86_l_2a62:
	/* 0x2a62: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a64:
	/* 0x2a64: sub    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 40ULL);
x86_l_2a69:
	/* 0x2a69: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2a71:
	/* 0x2a71: add    r12,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2a75:
	/* 0x2a75: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2a78:
	/* 0x2a78: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a7b:
	/* 0x2a7b: jns    2a83 <syscall_checker+0x2a83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a7b, 0x2a83, x86_l_2a83);
x86_l_2a7d:
	/* 0x2a7d: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a81:
	/* 0x2a81: jmp    2a85 <syscall_checker+0x2a85> */
	X86_SIM_X86_JMP(0x2a81, 0x2a85, x86_l_2a85);
x86_l_2a83:
	/* 0x2a83: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a85:
	/* 0x2a85: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2a8d:
	/* 0x2a8d: movzx  r15d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a95:
	/* 0x2a95: cmp    r15,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2a9c:
	/* 0x2a9c: ja     2b73 <syscall_checker+0x2b73> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a9c, 0x2b73, x86_l_2b73);
x86_l_2aa2:
	/* 0x2aa2: mov    BYTE PTR [r14+r15*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 588410519552ULL);
x86_l_2aab:
	/* 0x2aab: cmp    r15d,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2ab2:
	/* 0x2ab2: ja     2b73 <syscall_checker+0x2b73> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ab2, 0x2b73, x86_l_2b73);
x86_l_2ab8:
	/* 0x2ab8: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2abd:
	/* 0x2abd: lea    rdi,[r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2ac1:
	/* 0x2ac1: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2ac8:
	/* 0x2ac8: lea    rax,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2ad0:
	/* 0x2ad0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ad3:
	/* 0x2ad3: jns    2b3b <syscall_checker+0x2b3b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad3, 0x2b3b, x86_l_2b3b);
x86_l_2ad5:
	/* 0x2ad5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ad8:
	/* 0x2ad8: jns    2b6d <syscall_checker+0x2b6d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad8, 0x2b6d, x86_l_2b6d);
x86_l_2ade:
	/* 0x2ade: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae0:
	/* 0x2ae0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae2:
	/* 0x2ae2: jmp    2b58 <syscall_checker+0x2b58> */
	X86_SIM_X86_JMP(0x2ae2, 0x2b58, x86_l_2b58);
x86_l_2ae4:
	/* 0x2ae4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ae9:
	/* 0x2ae9: mov    rax,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2af0:
	/* 0x2af0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af3:
	/* 0x2af3: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2af3, 0x332f, x86_l_332f);
x86_l_2af9:
	/* 0x2af9: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2afe:
	/* 0x2afe: mov    rcx,QWORD PTR [rcx+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2b05:
	/* 0x2b05: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b08:
	/* 0x2b08: je     332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b08, 0x332f, x86_l_332f);
x86_l_2b0e:
	/* 0x2b0e: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2b16:
	/* 0x2b16: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_6) + (0))));
x86_l_2b1d:
	/* 0x2b1d: mov    rbx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2b20:
	/* 0x2b20: shr    rbx,0x3f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 63ULL);
x86_l_2b24:
	/* 0x2b24: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b27:
	/* 0x2b27: ja     2a45 <syscall_checker+0x2a45> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b27, 0x2a45, x86_l_2a45);
x86_l_2b2d:
	/* 0x2b2d: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b30:
	/* 0x2b30: jae    332f <syscall_checker+0x332f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b30, 0x332f, x86_l_332f);
x86_l_2b36:
	/* 0x2b36: jmp    2a45 <syscall_checker+0x2a45> */
	X86_SIM_X86_JMP(0x2b36, 0x2a45, x86_l_2a45);
x86_l_2b3b:
	/* 0x2b3b: lea    rdx,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2b43:
	/* 0x2b43: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2b48:
	/* 0x2b48: mov    r12,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2b4b:
	/* 0x2b4b: call   2b50 <syscall_checker+0x2b50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b50:
	/* 0x2b50: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2b53:
	/* 0x2b53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b56:
	/* 0x2b56: js     2b73 <syscall_checker+0x2b73> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b56, 0x2b73, x86_l_2b73);
x86_l_2b58:
	/* 0x2b58: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2b5c:
	/* 0x2b5c: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2b64:
	/* 0x2b64: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2b6b:
	/* 0x2b6b: jmp    2b73 <syscall_checker+0x2b73> */
	X86_SIM_X86_JMP(0x2b6b, 0x2b73, x86_l_2b73);
x86_l_2b6d:
	/* 0x2b6d: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b73:
	/* 0x2b73: movzx  r15d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2b7b:
	/* 0x2b7b: cmp    r15,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2b82:
	/* 0x2b82: ja     2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b82, 0x2ce4, x86_l_2ce4);
x86_l_2b88:
	/* 0x2b88: mov    BYTE PTR [r14+r15*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 588410519553ULL);
x86_l_2b91:
	/* 0x2b91: cmp    r15d,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2b98:
	/* 0x2b98: jbe    2ba4 <syscall_checker+0x2ba4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2b98, 0x2ba4, x86_l_2ba4);
x86_l_2b9a:
	/* 0x2b9a: movzx  r15d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2ba2:
	/* 0x2ba2: jmp    2c02 <syscall_checker+0x2c02> */
	X86_SIM_X86_JMP(0x2ba2, 0x2c02, x86_l_2c02);
x86_l_2ba4:
	/* 0x2ba4: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ba9:
	/* 0x2ba9: lea    rdi,[r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2bad:
	/* 0x2bad: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2bb4:
	/* 0x2bb4: lea    rax,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2bbc:
	/* 0x2bbc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bbf:
	/* 0x2bbf: jns    2bd2 <syscall_checker+0x2bd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bbf, 0x2bd2, x86_l_2bd2);
x86_l_2bc1:
	/* 0x2bc1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bc4:
	/* 0x2bc4: jns    2c70 <syscall_checker+0x2c70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bc4, 0x2c70, x86_l_2c70);
x86_l_2bca:
	/* 0x2bca: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bcd:
	/* 0x2bcd: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bd0:
	/* 0x2bd0: jmp    2bef <syscall_checker+0x2bef> */
	X86_SIM_X86_JMP(0x2bd0, 0x2bef, x86_l_2bef);
x86_l_2bd2:
	/* 0x2bd2: lea    rdx,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2bda:
	/* 0x2bda: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2bdf:
	/* 0x2bdf: mov    r12,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2be2:
	/* 0x2be2: call   2be7 <syscall_checker+0x2be7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2be7:
	/* 0x2be7: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2bea:
	/* 0x2bea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bed:
	/* 0x2bed: js     2b9a <syscall_checker+0x2b9a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bed, 0x2b9a, x86_l_2b9a);
x86_l_2bef:
	/* 0x2bef: add    r15d,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2bf3:
	/* 0x2bf3: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2bfb:
	/* 0x2bfb: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2c02:
	/* 0x2c02: movzx  eax,r15w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2c06:
	/* 0x2c06: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_2c0b:
	/* 0x2c0b: ja     2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c0b, 0x2ce4, x86_l_2ce4);
x86_l_2c11:
	/* 0x2c11: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_2c1a:
	/* 0x2c1a: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2c22:
	/* 0x2c22: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_2c2a:
	/* 0x2c2a: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2c30:
	/* 0x2c30: ja     2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c30, 0x2ce4, x86_l_2ce4);
x86_l_2c36:
	/* 0x2c36: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c3b:
	/* 0x2c3b: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2c3f:
	/* 0x2c3f: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2c46:
	/* 0x2c46: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2c49:
	/* 0x2c49: je     2c7c <syscall_checker+0x2c7c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c49, 0x2c7c, x86_l_2c7c);
x86_l_2c4b:
	/* 0x2c4b: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2c4e:
	/* 0x2c4e: jns    2c92 <syscall_checker+0x2c92> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c4e, 0x2c92, x86_l_2c92);
x86_l_2c50:
	/* 0x2c50: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c52:
	/* 0x2c52: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2c59:
	/* 0x2c59: je     2ca0 <syscall_checker+0x2ca0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c59, 0x2ca0, x86_l_2ca0);
x86_l_2c5b:
	/* 0x2c5b: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2c5f:
	/* 0x2c5f: movzx  edx,BYTE PTR [r8+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2c64:
	/* 0x2c64: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2c67:
	/* 0x2c67: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c6a:
	/* 0x2c6a: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2c6c:
	/* 0x2c6c: jne    2c52 <syscall_checker+0x2c52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c6c, 0x2c52, x86_l_2c52);
x86_l_2c6e:
	/* 0x2c6e: jmp    2c89 <syscall_checker+0x2c89> */
	X86_SIM_X86_JMP(0x2c6e, 0x2c89, x86_l_2c89);
x86_l_2c70:
	/* 0x2c70: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c77:
	/* 0x2c77: jmp    2b9a <syscall_checker+0x2b9a> */
	X86_SIM_X86_JMP(0x2c77, 0x2b9a, x86_l_2b9a);
x86_l_2c7c:
	/* 0x2c7c: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c81:
	/* 0x2c81: mov    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2c84:
	/* 0x2c84: call   2c89 <syscall_checker+0x2c89> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2c89:
	/* 0x2c89: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c8c:
	/* 0x2c8c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2c8e:
	/* 0x2c8e: jg     2cb1 <syscall_checker+0x2cb1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2c8e, 0x2cb1, x86_l_2cb1);
x86_l_2c90:
	/* 0x2c90: jmp    2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JMP(0x2c90, 0x2ce4, x86_l_2ce4);
x86_l_2c92:
	/* 0x2c92: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c97:
	/* 0x2c97: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c99:
	/* 0x2c99: call   2c9e <syscall_checker+0x2c9e> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2c9e:
	/* 0x2c9e: jmp    2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JMP(0x2c9e, 0x2ce4, x86_l_2ce4);
x86_l_2ca0:
	/* 0x2ca0: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2ca7:
	/* 0x2ca7: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2cac:
	/* 0x2cac: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2cb1:
	/* 0x2cb1: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2cb9:
	/* 0x2cb9: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2cc0:
	/* 0x2cc0: ja     2ce4 <syscall_checker+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cc0, 0x2ce4, x86_l_2ce4);
x86_l_2cc2:
	/* 0x2cc2: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2cca:
	/* 0x2cca: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2cd2:
	/* 0x2cd2: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2cd5:
	/* 0x2cd5: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2cdd:
	/* 0x2cdd: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2ce4:
	/* 0x2ce4: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2cec:
	/* 0x2cec: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2cf3:
	/* 0x2cf3: mov    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2cf6:
	/* 0x2cf6: ja     2d5f <syscall_checker+0x2d5f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cf6, 0x2d5f, x86_l_2d5f);
x86_l_2cf8:
	/* 0x2cf8: mov    BYTE PTR [r14+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_2d01:
	/* 0x2d01: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2d07:
	/* 0x2d07: ja     2d5f <syscall_checker+0x2d5f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d07, 0x2d5f, x86_l_2d5f);
x86_l_2d09:
	/* 0x2d09: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d0e:
	/* 0x2d0e: lea    rdi,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2d12:
	/* 0x2d12: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2d19:
	/* 0x2d19: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d1e:
	/* 0x2d1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d21:
	/* 0x2d21: jns    2d30 <syscall_checker+0x2d30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d21, 0x2d30, x86_l_2d30);
x86_l_2d23:
	/* 0x2d23: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d26:
	/* 0x2d26: jns    2d58 <syscall_checker+0x2d58> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d26, 0x2d58, x86_l_2d58);
x86_l_2d28:
	/* 0x2d28: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d2b:
	/* 0x2d2b: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d2e:
	/* 0x2d2e: jmp    2d44 <syscall_checker+0x2d44> */
	X86_SIM_X86_JMP(0x2d2e, 0x2d44, x86_l_2d44);
x86_l_2d30:
	/* 0x2d30: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d35:
	/* 0x2d35: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2d3a:
	/* 0x2d3a: call   2d3f <syscall_checker+0x2d3f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2d3f:
	/* 0x2d3f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d42:
	/* 0x2d42: js     2d5f <syscall_checker+0x2d5f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d42, 0x2d5f, x86_l_2d5f);
x86_l_2d44:
	/* 0x2d44: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2d47:
	/* 0x2d47: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2d4f:
	/* 0x2d4f: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2d56:
	/* 0x2d56: jmp    2d5f <syscall_checker+0x2d5f> */
	X86_SIM_X86_JMP(0x2d56, 0x2d5f, x86_l_2d5f);
x86_l_2d58:
	/* 0x2d58: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d5f:
	/* 0x2d5f: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d67:
	/* 0x2d67: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2d6e:
	/* 0x2d6e: ja     2ddd <syscall_checker+0x2ddd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d6e, 0x2ddd, x86_l_2ddd);
x86_l_2d70:
	/* 0x2d70: mov    BYTE PTR [r14+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_2d79:
	/* 0x2d79: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2d7f:
	/* 0x2d7f: ja     2ddd <syscall_checker+0x2ddd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d7f, 0x2ddd, x86_l_2ddd);
x86_l_2d81:
	/* 0x2d81: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d86:
	/* 0x2d86: lea    rdi,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2d8a:
	/* 0x2d8a: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2d91:
	/* 0x2d91: lea    rax,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2d99:
	/* 0x2d99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d9c:
	/* 0x2d9c: jns    2dab <syscall_checker+0x2dab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d9c, 0x2dab, x86_l_2dab);
x86_l_2d9e:
	/* 0x2d9e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2da1:
	/* 0x2da1: jns    2dd6 <syscall_checker+0x2dd6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2da1, 0x2dd6, x86_l_2dd6);
x86_l_2da3:
	/* 0x2da3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da6:
	/* 0x2da6: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da9:
	/* 0x2da9: jmp    2dc2 <syscall_checker+0x2dc2> */
	X86_SIM_X86_JMP(0x2da9, 0x2dc2, x86_l_2dc2);
x86_l_2dab:
	/* 0x2dab: lea    rdx,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2db3:
	/* 0x2db3: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2db8:
	/* 0x2db8: call   2dbd <syscall_checker+0x2dbd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2dbd:
	/* 0x2dbd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dc0:
	/* 0x2dc0: js     2ddd <syscall_checker+0x2ddd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dc0, 0x2ddd, x86_l_2ddd);
x86_l_2dc2:
	/* 0x2dc2: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2dc5:
	/* 0x2dc5: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2dcd:
	/* 0x2dcd: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2dd4:
	/* 0x2dd4: jmp    2ddd <syscall_checker+0x2ddd> */
	X86_SIM_X86_JMP(0x2dd4, 0x2ddd, x86_l_2ddd);
x86_l_2dd6:
	/* 0x2dd6: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ddd:
	/* 0x2ddd: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2de5:
	/* 0x2de5: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2dec:
	/* 0x2dec: ja     2e5b <syscall_checker+0x2e5b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dec, 0x2e5b, x86_l_2e5b);
x86_l_2dee:
	/* 0x2dee: mov    BYTE PTR [r14+rbx*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519557ULL);
x86_l_2df7:
	/* 0x2df7: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2dfd:
	/* 0x2dfd: ja     2e5b <syscall_checker+0x2e5b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dfd, 0x2e5b, x86_l_2e5b);
x86_l_2dff:
	/* 0x2dff: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e04:
	/* 0x2e04: lea    rdi,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2e08:
	/* 0x2e08: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2e0f:
	/* 0x2e0f: lea    rax,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2e17:
	/* 0x2e17: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e1a:
	/* 0x2e1a: jns    2e29 <syscall_checker+0x2e29> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1a, 0x2e29, x86_l_2e29);
x86_l_2e1c:
	/* 0x2e1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e1f:
	/* 0x2e1f: jns    2e54 <syscall_checker+0x2e54> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1f, 0x2e54, x86_l_2e54);
x86_l_2e21:
	/* 0x2e21: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e24:
	/* 0x2e24: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e27:
	/* 0x2e27: jmp    2e40 <syscall_checker+0x2e40> */
	X86_SIM_X86_JMP(0x2e27, 0x2e40, x86_l_2e40);
x86_l_2e29:
	/* 0x2e29: lea    rdx,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2e31:
	/* 0x2e31: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2e36:
	/* 0x2e36: call   2e3b <syscall_checker+0x2e3b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e3b:
	/* 0x2e3b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e3e:
	/* 0x2e3e: js     2e5b <syscall_checker+0x2e5b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e3e, 0x2e5b, x86_l_2e5b);
x86_l_2e40:
	/* 0x2e40: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2e43:
	/* 0x2e43: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e4b:
	/* 0x2e4b: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e52:
	/* 0x2e52: jmp    2e5b <syscall_checker+0x2e5b> */
	X86_SIM_X86_JMP(0x2e52, 0x2e5b, x86_l_2e5b);
x86_l_2e54:
	/* 0x2e54: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e5b:
	/* 0x2e5b: mov    r12,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2e62:
	/* 0x2e62: lea    rcx,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e67:
	/* 0x2e67: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e6a:
	/* 0x2e6a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e6d:
	/* 0x2e6d: jns    2e74 <syscall_checker+0x2e74> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e6d, 0x2e74, x86_l_2e74);
x86_l_2e6f:
	/* 0x2e6f: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e72:
	/* 0x2e72: jmp    2e77 <syscall_checker+0x2e77> */
	X86_SIM_X86_JMP(0x2e72, 0x2e77, x86_l_2e77);
x86_l_2e74:
	/* 0x2e74: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e77:
	/* 0x2e77: lea    rax,[r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e7b:
	/* 0x2e7b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e7e:
	/* 0x2e7e: jns    2e85 <syscall_checker+0x2e85> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e7e, 0x2e85, x86_l_2e85);
x86_l_2e80:
	/* 0x2e80: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e83:
	/* 0x2e83: jmp    2e87 <syscall_checker+0x2e87> */
	X86_SIM_X86_JMP(0x2e83, 0x2e87, x86_l_2e87);
x86_l_2e85:
	/* 0x2e85: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e87:
	/* 0x2e87: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2e8b:
	/* 0x2e8b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e8d:
	/* 0x2e8d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e90:
	/* 0x2e90: jns    2e97 <syscall_checker+0x2e97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e90, 0x2e97, x86_l_2e97);
x86_l_2e92:
	/* 0x2e92: mov    rbp,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e95:
	/* 0x2e95: jmp    2e99 <syscall_checker+0x2e99> */
	X86_SIM_X86_JMP(0x2e95, 0x2e99, x86_l_2e99);
x86_l_2e97:
	/* 0x2e97: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e99:
	/* 0x2e99: lea    rdx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2e9d:
	/* 0x2e9d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ea0:
	/* 0x2ea0: jns    2ea4 <syscall_checker+0x2ea4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ea0, 0x2ea4, x86_l_2ea4);
x86_l_2ea2:
	/* 0x2ea2: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea4:
	/* 0x2ea4: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2ea8:
	/* 0x2ea8: lea    rax,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ead:
	/* 0x2ead: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eb0:
	/* 0x2eb0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eb2:
	/* 0x2eb2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2eb5:
	/* 0x2eb5: jns    2ebc <syscall_checker+0x2ebc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb5, 0x2ebc, x86_l_2ebc);
x86_l_2eb7:
	/* 0x2eb7: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eba:
	/* 0x2eba: jmp    2ebe <syscall_checker+0x2ebe> */
	X86_SIM_X86_JMP(0x2eba, 0x2ebe, x86_l_2ebe);
x86_l_2ebc:
	/* 0x2ebc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ebe:
	/* 0x2ebe: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ec1:
	/* 0x2ec1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2ec4:
	/* 0x2ec4: jns    2ec8 <syscall_checker+0x2ec8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ec4, 0x2ec8, x86_l_2ec8);
x86_l_2ec6:
	/* 0x2ec6: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ec8:
	/* 0x2ec8: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2eca:
	/* 0x2eca: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2ece:
	/* 0x2ece: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2ed1:
	/* 0x2ed1: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ed5:
	/* 0x2ed5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ed7:
	/* 0x2ed7: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2eda:
	/* 0x2eda: jns    2ede <syscall_checker+0x2ede> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eda, 0x2ede, x86_l_2ede);
x86_l_2edc:
	/* 0x2edc: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ede:
	/* 0x2ede: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2ee2:
	/* 0x2ee2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ee5:
	/* 0x2ee5: jns    2eec <syscall_checker+0x2eec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee5, 0x2eec, x86_l_2eec);
x86_l_2ee7:
	/* 0x2ee7: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eea:
	/* 0x2eea: jmp    2eee <syscall_checker+0x2eee> */
	X86_SIM_X86_JMP(0x2eea, 0x2eee, x86_l_2eee);
x86_l_2eec:
	/* 0x2eec: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eee:
	/* 0x2eee: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2ef2:
	/* 0x2ef2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ef4:
	/* 0x2ef4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ef7:
	/* 0x2ef7: jns    2efe <syscall_checker+0x2efe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ef7, 0x2efe, x86_l_2efe);
x86_l_2ef9:
	/* 0x2ef9: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2efc:
	/* 0x2efc: jmp    2f00 <syscall_checker+0x2f00> */
	X86_SIM_X86_JMP(0x2efc, 0x2f00, x86_l_2f00);
x86_l_2efe:
	/* 0x2efe: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f00:
	/* 0x2f00: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f03:
	/* 0x2f03: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f06:
	/* 0x2f06: jns    2f0a <syscall_checker+0x2f0a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f06, 0x2f0a, x86_l_2f0a);
x86_l_2f08:
	/* 0x2f08: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f0a:
	/* 0x2f0a: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2f0c:
	/* 0x2f0c: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f10:
	/* 0x2f10: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f13:
	/* 0x2f13: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f17:
	/* 0x2f17: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f19:
	/* 0x2f19: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f1c:
	/* 0x2f1c: jns    2f20 <syscall_checker+0x2f20> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f1c, 0x2f20, x86_l_2f20);
x86_l_2f1e:
	/* 0x2f1e: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f20:
	/* 0x2f20: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2f24:
	/* 0x2f24: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f26:
	/* 0x2f26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f29:
	/* 0x2f29: jns    2f30 <syscall_checker+0x2f30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f29, 0x2f30, x86_l_2f30);
x86_l_2f2b:
	/* 0x2f2b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2e:
	/* 0x2f2e: jmp    2f32 <syscall_checker+0x2f32> */
	X86_SIM_X86_JMP(0x2f2e, 0x2f32, x86_l_2f32);
x86_l_2f30:
	/* 0x2f30: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f32:
	/* 0x2f32: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f35:
	/* 0x2f35: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f38:
	/* 0x2f38: jns    2f3c <syscall_checker+0x2f3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f38, 0x2f3c, x86_l_2f3c);
x86_l_2f3a:
	/* 0x2f3a: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f3c:
	/* 0x2f3c: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2f3e:
	/* 0x2f3e: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f42:
	/* 0x2f42: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f45:
	/* 0x2f45: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f49:
	/* 0x2f49: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f4b:
	/* 0x2f4b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f4e:
	/* 0x2f4e: jns    2f55 <syscall_checker+0x2f55> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f4e, 0x2f55, x86_l_2f55);
x86_l_2f50:
	/* 0x2f50: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f53:
	/* 0x2f53: jmp    2f57 <syscall_checker+0x2f57> */
	X86_SIM_X86_JMP(0x2f53, 0x2f57, x86_l_2f57);
x86_l_2f55:
	/* 0x2f55: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f57:
	/* 0x2f57: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2f5b:
	/* 0x2f5b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f5e:
	/* 0x2f5e: jns    2f62 <syscall_checker+0x2f62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f5e, 0x2f62, x86_l_2f62);
x86_l_2f60:
	/* 0x2f60: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f62:
	/* 0x2f62: lea    rcx,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f66:
	/* 0x2f66: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f69:
	/* 0x2f69: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f6b:
	/* 0x2f6b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f6e:
	/* 0x2f6e: jns    2f75 <syscall_checker+0x2f75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f6e, 0x2f75, x86_l_2f75);
x86_l_2f70:
	/* 0x2f70: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f73:
	/* 0x2f73: jmp    2f77 <syscall_checker+0x2f77> */
	X86_SIM_X86_JMP(0x2f73, 0x2f77, x86_l_2f77);
x86_l_2f75:
	/* 0x2f75: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f77:
	/* 0x2f77: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f7a:
	/* 0x2f7a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f7d:
	/* 0x2f7d: jns    2f81 <syscall_checker+0x2f81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f7d, 0x2f81, x86_l_2f81);
x86_l_2f7f:
	/* 0x2f7f: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f81:
	/* 0x2f81: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f83:
	/* 0x2f83: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f87:
	/* 0x2f87: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f8a:
	/* 0x2f8a: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f8e:
	/* 0x2f8e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f90:
	/* 0x2f90: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f93:
	/* 0x2f93: jns    2f9a <syscall_checker+0x2f9a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f93, 0x2f9a, x86_l_2f9a);
x86_l_2f95:
	/* 0x2f95: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f98:
	/* 0x2f98: jmp    2f9c <syscall_checker+0x2f9c> */
	X86_SIM_X86_JMP(0x2f98, 0x2f9c, x86_l_2f9c);
x86_l_2f9a:
	/* 0x2f9a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f9c:
	/* 0x2f9c: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2fa0:
	/* 0x2fa0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fa3:
	/* 0x2fa3: jns    2fa7 <syscall_checker+0x2fa7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fa3, 0x2fa7, x86_l_2fa7);
x86_l_2fa5:
	/* 0x2fa5: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fa7:
	/* 0x2fa7: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2fa9:
	/* 0x2fa9: jne    2fdd <syscall_checker+0x2fdd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fa9, 0x2fdd, x86_l_2fdd);
x86_l_2fab:
	/* 0x2fab: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fad:
	/* 0x2fad: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fb0:
	/* 0x2fb0: jns    2fb7 <syscall_checker+0x2fb7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fb0, 0x2fb7, x86_l_2fb7);
x86_l_2fb2:
	/* 0x2fb2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fb5:
	/* 0x2fb5: jmp    2fb9 <syscall_checker+0x2fb9> */
	X86_SIM_X86_JMP(0x2fb5, 0x2fb9, x86_l_2fb9);
x86_l_2fb7:
	/* 0x2fb7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fb9:
	/* 0x2fb9: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fbc:
	/* 0x2fbc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fbf:
	/* 0x2fbf: jns    2fc3 <syscall_checker+0x2fc3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fbf, 0x2fc3, x86_l_2fc3);
x86_l_2fc1:
	/* 0x2fc1: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc3:
	/* 0x2fc3: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2fc5:
	/* 0x2fc5: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2fc9:
	/* 0x2fc9: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2fcc:
	/* 0x2fcc: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2fd0:
	/* 0x2fd0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fd2:
	/* 0x2fd2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fd5:
	/* 0x2fd5: jns    2fd9 <syscall_checker+0x2fd9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd5, 0x2fd9, x86_l_2fd9);
x86_l_2fd7:
	/* 0x2fd7: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd9:
	/* 0x2fd9: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2fdd:
	/* 0x2fdd: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2fe1:
	/* 0x2fe1: lea    rbx,[r12+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2fe9:
	/* 0x2fe9: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2fec:
	/* 0x2fec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fef:
	/* 0x2fef: jns    2ff6 <syscall_checker+0x2ff6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fef, 0x2ff6, x86_l_2ff6);
x86_l_2ff1:
	/* 0x2ff1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff4:
	/* 0x2ff4: jmp    2ff8 <syscall_checker+0x2ff8> */
	X86_SIM_X86_JMP(0x2ff4, 0x2ff8, x86_l_2ff8);
x86_l_2ff6:
	/* 0x2ff6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ff8:
	/* 0x2ff8: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2ffc:
	/* 0x2ffc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ffe:
	/* 0x2ffe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3001:
	/* 0x3001: jns    3008 <syscall_checker+0x3008> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3001, 0x3008, x86_l_3008);
x86_l_3003:
	/* 0x3003: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3006:
	/* 0x3006: jmp    300a <syscall_checker+0x300a> */
	X86_SIM_X86_JMP(0x3006, 0x300a, x86_l_300a);
x86_l_3008:
	/* 0x3008: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_300a:
	/* 0x300a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_300d:
	/* 0x300d: jns    3011 <syscall_checker+0x3011> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x300d, 0x3011, x86_l_3011);
x86_l_300f:
	/* 0x300f: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3011:
	/* 0x3011: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_3015:
	/* 0x3015: call   301a <syscall_checker+0x301a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_301a:
	/* 0x301a: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_301e:
	/* 0x301e: lea    rax,[r12+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3023:
	/* 0x3023: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3026:
	/* 0x3026: jns    302d <syscall_checker+0x302d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3026, 0x302d, x86_l_302d);
x86_l_3028:
	/* 0x3028: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_302b:
	/* 0x302b: jmp    302f <syscall_checker+0x302f> */
	X86_SIM_X86_JMP(0x302b, 0x302f, x86_l_302f);
x86_l_302d:
	/* 0x302d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_302f:
	/* 0x302f: mov    rcx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_3037:
	/* 0x3037: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_303a:
	/* 0x303a: add    r13,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_303e:
	/* 0x303e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3041:
	/* 0x3041: jns    3049 <syscall_checker+0x3049> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3041, 0x3049, x86_l_3049);
x86_l_3043:
	/* 0x3043: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3047:
	/* 0x3047: jmp    304b <syscall_checker+0x304b> */
	X86_SIM_X86_JMP(0x3047, 0x304b, x86_l_304b);
x86_l_3049:
	/* 0x3049: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_304b:
	/* 0x304b: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_304f:
	/* 0x304f: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3053:
	/* 0x3053: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3056:
	/* 0x3056: jns    305e <syscall_checker+0x305e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3056, 0x305e, x86_l_305e);
x86_l_3058:
	/* 0x3058: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_305c:
	/* 0x305c: jmp    3060 <syscall_checker+0x3060> */
	X86_SIM_X86_JMP(0x305c, 0x3060, x86_l_3060);
x86_l_305e:
	/* 0x305e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3060:
	/* 0x3060: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3065:
	/* 0x3065: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3069:
	/* 0x3069: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_306c:
	/* 0x306c: jns    307b <syscall_checker+0x307b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x306c, 0x307b, x86_l_307b);
x86_l_306e:
	/* 0x306e: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3072:
	/* 0x3072: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3074:
	/* 0x3074: je     307b <syscall_checker+0x307b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3074, 0x307b, x86_l_307b);
x86_l_3076:
	/* 0x3076: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_307b:
	/* 0x307b: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3080:
	/* 0x3080: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3084:
	/* 0x3084: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_308c:
	/* 0x308c: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_3094:
	/* 0x3094: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3099:
	/* 0x3099: call   309e <syscall_checker+0x309e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_309e:
	/* 0x309e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_30a1:
	/* 0x30a1: jns    30a8 <syscall_checker+0x30a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30a1, 0x30a8, x86_l_30a8);
x86_l_30a3:
	/* 0x30a3: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30a6:
	/* 0x30a6: jmp    30aa <syscall_checker+0x30aa> */
	X86_SIM_X86_JMP(0x30a6, 0x30aa, x86_l_30aa);
x86_l_30a8:
	/* 0x30a8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30aa:
	/* 0x30aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30ad:
	/* 0x30ad: mov    rsi,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_30b5:
	/* 0x30b5: jns    30bc <syscall_checker+0x30bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30b5, 0x30bc, x86_l_30bc);
x86_l_30b7:
	/* 0x30b7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ba:
	/* 0x30ba: jmp    30be <syscall_checker+0x30be> */
	X86_SIM_X86_JMP(0x30ba, 0x30be, x86_l_30be);
x86_l_30bc:
	/* 0x30bc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30be:
	/* 0x30be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30c1:
	/* 0x30c1: jns    3104 <syscall_checker+0x3104> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30c1, 0x3104, x86_l_3104);
x86_l_30c3:
	/* 0x30c3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30c6:
	/* 0x30c6: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30cb:
	/* 0x30cb: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_30cf:
	/* 0x30cf: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30d4:
	/* 0x30d4: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30d8:
	/* 0x30d8: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_30dd:
	/* 0x30dd: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_30e1:
	/* 0x30e1: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_30e6:
	/* 0x30e6: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30ea:
	/* 0x30ea: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_30ef:
	/* 0x30ef: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_30f3:
	/* 0x30f3: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_30f8:
	/* 0x30f8: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30fc:
	/* 0x30fc: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3100:
	/* 0x3100: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_3104:
	/* 0x3104: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3109:
	/* 0x3109: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_310d:
	/* 0x310d: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3112:
	/* 0x3112: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3115:
	/* 0x3115: jns    31eb <syscall_checker+0x31eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3115, 0x31eb, x86_l_31eb);
x86_l_311b:
	/* 0x311b: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_311e:
	/* 0x311e: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3120:
	/* 0x3120: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3122:
	/* 0x3122: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3122, 0x31fa, x86_l_31fa);
x86_l_3128:
	/* 0x3128: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_312c:
	/* 0x312c: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_3130:
	/* 0x3130: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3132:
	/* 0x3132: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3132, 0x31fa, x86_l_31fa);
x86_l_3138:
	/* 0x3138: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_313c:
	/* 0x313c: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_3140:
	/* 0x3140: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3142:
	/* 0x3142: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3142, 0x31fa, x86_l_31fa);
x86_l_3148:
	/* 0x3148: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_314c:
	/* 0x314c: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_3150:
	/* 0x3150: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3152:
	/* 0x3152: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3152, 0x31fa, x86_l_31fa);
x86_l_3158:
	/* 0x3158: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_315c:
	/* 0x315c: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3160:
	/* 0x3160: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3162:
	/* 0x3162: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3162, 0x31fa, x86_l_31fa);
x86_l_3168:
	/* 0x3168: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_316c:
	/* 0x316c: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_3170:
	/* 0x3170: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3172:
	/* 0x3172: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3172, 0x31fa, x86_l_31fa);
x86_l_3178:
	/* 0x3178: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_317c:
	/* 0x317c: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_3180:
	/* 0x3180: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3182:
	/* 0x3182: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3182, 0x31fa, x86_l_31fa);
x86_l_3184:
	/* 0x3184: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3188:
	/* 0x3188: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_318c:
	/* 0x318c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_318e:
	/* 0x318e: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x318e, 0x31fa, x86_l_31fa);
x86_l_3190:
	/* 0x3190: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_3194:
	/* 0x3194: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_3198:
	/* 0x3198: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_319a:
	/* 0x319a: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x319a, 0x31fa, x86_l_31fa);
x86_l_319c:
	/* 0x319c: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_31a0:
	/* 0x31a0: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_31a4:
	/* 0x31a4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31a6:
	/* 0x31a6: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31a6, 0x31fa, x86_l_31fa);
x86_l_31a8:
	/* 0x31a8: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_31ac:
	/* 0x31ac: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_31b0:
	/* 0x31b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31b2:
	/* 0x31b2: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31b2, 0x31fa, x86_l_31fa);
x86_l_31b4:
	/* 0x31b4: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_31b8:
	/* 0x31b8: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_31bc:
	/* 0x31bc: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31be:
	/* 0x31be: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31be, 0x31fa, x86_l_31fa);
x86_l_31c0:
	/* 0x31c0: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_31c4:
	/* 0x31c4: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_31c8:
	/* 0x31c8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31ca:
	/* 0x31ca: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31ca, 0x31fa, x86_l_31fa);
x86_l_31cc:
	/* 0x31cc: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_31d0:
	/* 0x31d0: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_31d4:
	/* 0x31d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31d6:
	/* 0x31d6: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31d6, 0x31fa, x86_l_31fa);
x86_l_31d8:
	/* 0x31d8: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_31dc:
	/* 0x31dc: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_31e0:
	/* 0x31e0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_31e2:
	/* 0x31e2: je     31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31e2, 0x31fa, x86_l_31fa);
x86_l_31e4:
	/* 0x31e4: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_31e9:
	/* 0x31e9: jmp    31fa <syscall_checker+0x31fa> */
	X86_SIM_X86_JMP(0x31e9, 0x31fa, x86_l_31fa);
x86_l_31eb:
	/* 0x31eb: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_31f3:
	/* 0x31f3: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31fa:
	/* 0x31fa: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_31fd:
	/* 0x31fd: jns    326c <syscall_checker+0x326c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31fd, 0x326c, x86_l_326c);
x86_l_31ff:
	/* 0x31ff: mov    rax,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3202:
	/* 0x3202: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3207:
	/* 0x3207: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_320a:
	/* 0x320a: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_320e:
	/* 0x320e: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3212:
	/* 0x3212: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3216:
	/* 0x3216: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_321a:
	/* 0x321a: mov    rax,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_321e:
	/* 0x321e: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3222:
	/* 0x3222: mov    rax,QWORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3226:
	/* 0x3226: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_322a:
	/* 0x322a: mov    rax,QWORD PTR [rsi+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_322e:
	/* 0x322e: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3232:
	/* 0x3232: mov    rax,QWORD PTR [rsi+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3236:
	/* 0x3236: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_323a:
	/* 0x323a: mov    rax,QWORD PTR [rsi+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_323e:
	/* 0x323e: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3242:
	/* 0x3242: mov    rax,QWORD PTR [rsi+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3246:
	/* 0x3246: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_324a:
	/* 0x324a: mov    rax,QWORD PTR [rsi+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_324e:
	/* 0x324e: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3252:
	/* 0x3252: mov    rax,QWORD PTR [rsi+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3256:
	/* 0x3256: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_325a:
	/* 0x325a: mov    rax,QWORD PTR [rsi+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_325e:
	/* 0x325e: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3262:
	/* 0x3262: mov    rax,QWORD PTR [rsi+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3266:
	/* 0x3266: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_326a:
	/* 0x326a: jmp    32d8 <syscall_checker+0x32d8> */
	X86_SIM_X86_JMP(0x326a, 0x32d8, x86_l_32d8);
x86_l_326c:
	/* 0x326c: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3271:
	/* 0x3271: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3279:
	/* 0x3279: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3281:
	/* 0x3281: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3289:
	/* 0x3289: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_3291:
	/* 0x3291: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3299:
	/* 0x3299: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_32a1:
	/* 0x32a1: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_32a9:
	/* 0x32a9: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_32b1:
	/* 0x32b1: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_32b9:
	/* 0x32b9: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_32c1:
	/* 0x32c1: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_32c9:
	/* 0x32c9: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_32d1:
	/* 0x32d1: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d8:
	/* 0x32d8: test   BYTE PTR [r13+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_32dd:
	/* 0x32dd: je     32fb <syscall_checker+0x32fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32dd, 0x32fb, x86_l_32fb);
x86_l_32df:
	/* 0x32df: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_32e6:
	/* 0x32e6: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_32eb:
	/* 0x32eb: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_32ee:
	/* 0x32ee: call   32f3 <syscall_checker+0x32f3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_32f3:
	/* 0x32f3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_32f5:
	/* 0x32f5: js     32fb <syscall_checker+0x32fb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32f5, 0x32fb, x86_l_32fb);
x86_l_32f7:
	/* 0x32f7: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_32fb:
	/* 0x32fb: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3303:
	/* 0x3303: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_3308:
	/* 0x3308: jb     330f <syscall_checker+0x330f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3308, 0x330f, x86_l_330f);
x86_l_330a:
	/* 0x330a: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_330f:
	/* 0x330f: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_3314:
	/* 0x3314: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_3318:
	/* 0x3318: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_331f:
	/* 0x331f: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_3324:
	/* 0x3324: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3327:
	/* 0x3327: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_332a:
	/* 0x332a: call   332f <syscall_checker+0x332f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_332f:
	/* 0x332f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3331:
	/* 0x3331: add    rsp,0xe8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 232ULL);
x86_l_3338:
	/* 0x3338: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3339:
	/* 0x3339: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_333b:
	/* 0x333b: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_333d:
	/* 0x333d: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_333f:
	/* 0x333f: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3341:
	/* 0x3341: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3342:
	/* 0x3342: jmp    41c0 <.L.str.10+0x4140> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3347:
	/* 0x3347: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3349:
	/* 0x3349: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_334c:
	/* 0x334c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_334f:
	/* 0x334f: jns    3353 <syscall_checker+0x3353> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x334f, 0x3353, x86_l_3353);
x86_l_3351:
	/* 0x3351: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3353:
	/* 0x3353: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3355:
	/* 0x3355: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3359:
	/* 0x3359: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_335c:
	/* 0x335c: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3360:
	/* 0x3360: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3362:
	/* 0x3362: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3365:
	/* 0x3365: jns    3369 <syscall_checker+0x3369> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3365, 0x3369, x86_l_3369);
x86_l_3367:
	/* 0x3367: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3369:
	/* 0x3369: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_336e:
	/* 0x336e: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3371:
	/* 0x3371: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3376:
	/* 0x3376: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3379:
	/* 0x3379: lea    rax,[r13+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3380:
	/* 0x3380: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_3385:
	/* 0x3385: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3388:
	/* 0x3388: jns    338f <syscall_checker+0x338f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3388, 0x338f, x86_l_338f);
x86_l_338a:
	/* 0x338a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_338d:
	/* 0x338d: jmp    3391 <syscall_checker+0x3391> */
	X86_SIM_X86_JMP(0x338d, 0x3391, x86_l_3391);
x86_l_338f:
	/* 0x338f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3391:
	/* 0x3391: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3395:
	/* 0x3395: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3397:
	/* 0x3397: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_339a:
	/* 0x339a: jns    33a1 <syscall_checker+0x33a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x339a, 0x33a1, x86_l_33a1);
x86_l_339c:
	/* 0x339c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_339f:
	/* 0x339f: jmp    33a3 <syscall_checker+0x33a3> */
	X86_SIM_X86_JMP(0x339f, 0x33a3, x86_l_33a3);
x86_l_33a1:
	/* 0x33a1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33a3:
	/* 0x33a3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33a6:
	/* 0x33a6: jns    33aa <syscall_checker+0x33aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33a6, 0x33aa, x86_l_33aa);
x86_l_33a8:
	/* 0x33a8: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33aa:
	/* 0x33aa: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33af:
	/* 0x33af: mov    DWORD PTR [r12+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_33b4:
	/* 0x33b4: call   33b9 <syscall_checker+0x33b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_33b9:
	/* 0x33b9: mov    DWORD PTR [r12+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_33be:
	/* 0x33be: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_33c1:
	/* 0x33c1: lea    rax,[r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_33c5:
	/* 0x33c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33c8:
	/* 0x33c8: jns    33cf <syscall_checker+0x33cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33c8, 0x33cf, x86_l_33cf);
x86_l_33ca:
	/* 0x33ca: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33cd:
	/* 0x33cd: jmp    33d1 <syscall_checker+0x33d1> */
	X86_SIM_X86_JMP(0x33cd, 0x33d1, x86_l_33d1);
x86_l_33cf:
	/* 0x33cf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33d1:
	/* 0x33d1: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33d6:
	/* 0x33d6: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33d9:
	/* 0x33d9: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33de:
	/* 0x33de: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_33e2:
	/* 0x33e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33e5:
	/* 0x33e5: jns    33ec <syscall_checker+0x33ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33e5, 0x33ec, x86_l_33ec);
x86_l_33e7:
	/* 0x33e7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33ea:
	/* 0x33ea: jmp    33ee <syscall_checker+0x33ee> */
	X86_SIM_X86_JMP(0x33ea, 0x33ee, x86_l_33ee);
x86_l_33ec:
	/* 0x33ec: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33ee:
	/* 0x33ee: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33f3:
	/* 0x33f3: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_33f7:
	/* 0x33f7: add    rbx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_33fb:
	/* 0x33fb: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33fe:
	/* 0x33fe: jns    3405 <syscall_checker+0x3405> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33fe, 0x3405, x86_l_3405);
x86_l_3400:
	/* 0x3400: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3403:
	/* 0x3403: jmp    3407 <syscall_checker+0x3407> */
	X86_SIM_X86_JMP(0x3403, 0x3407, x86_l_3407);
x86_l_3405:
	/* 0x3405: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3407:
	/* 0x3407: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_340c:
	/* 0x340c: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3411:
	/* 0x3411: mov    QWORD PTR [r13+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3415:
	/* 0x3415: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3418:
	/* 0x3418: jns    3425 <syscall_checker+0x3425> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3418, 0x3425, x86_l_3425);
x86_l_341a:
	/* 0x341a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_341c:
	/* 0x341c: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_341e:
	/* 0x341e: je     3425 <syscall_checker+0x3425> */
	X86_SIM_X86_JCC(X86_CC_E, 0x341e, 0x3425, x86_l_3425);
x86_l_3420:
	/* 0x3420: or     BYTE PTR [r13+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_3425:
	/* 0x3425: lea    rdi,[r13+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_3429:
	/* 0x3429: mov    QWORD PTR [r13+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_3431:
	/* 0x3431: mov    QWORD PTR [r13+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_3439:
	/* 0x3439: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_343e:
	/* 0x343e: call   3443 <syscall_checker+0x3443> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_3443:
	/* 0x3443: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_3448:
	/* 0x3448: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_344b:
	/* 0x344b: jns    3452 <syscall_checker+0x3452> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x344b, 0x3452, x86_l_3452);
x86_l_344d:
	/* 0x344d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3450:
	/* 0x3450: jmp    3454 <syscall_checker+0x3454> */
	X86_SIM_X86_JMP(0x3450, 0x3454, x86_l_3454);
x86_l_3452:
	/* 0x3452: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3454:
	/* 0x3454: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3457:
	/* 0x3457: jns    345e <syscall_checker+0x345e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3457, 0x345e, x86_l_345e);
x86_l_3459:
	/* 0x3459: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_345c:
	/* 0x345c: jmp    3460 <syscall_checker+0x3460> */
	X86_SIM_X86_JMP(0x345c, 0x3460, x86_l_3460);
x86_l_345e:
	/* 0x345e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3460:
	/* 0x3460: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3463:
	/* 0x3463: jns    34b0 <syscall_checker+0x34b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3463, 0x34b0, x86_l_34b0);
x86_l_3465:
	/* 0x3465: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3468:
	/* 0x3468: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_346d:
	/* 0x346d: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3471:
	/* 0x3471: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3476:
	/* 0x3476: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_347a:
	/* 0x347a: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_347f:
	/* 0x347f: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3483:
	/* 0x3483: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3488:
	/* 0x3488: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_348c:
	/* 0x348c: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3491:
	/* 0x3491: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3495:
	/* 0x3495: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_349a:
	/* 0x349a: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_349e:
	/* 0x349e: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_34a3:
	/* 0x34a3: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34a7:
	/* 0x34a7: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_34ac:
	/* 0x34ac: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_34b0:
	/* 0x34b0: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_34b3:
	/* 0x34b3: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_34b7:
	/* 0x34b7: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_34bc:
	/* 0x34bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_34bf:
	/* 0x34bf: jns    35fb <syscall_checker+0x35fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34bf, 0x35fb, x86_l_35fb);
x86_l_34c5:
	/* 0x34c5: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_34c8:
	/* 0x34c8: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34ca:
	/* 0x34ca: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_34cc:
	/* 0x34cc: je     2db <syscall_checker+0x2db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34cc, 0x2db, x86_l_2db);
x86_l_34d2:
	/* 0x34d2: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_34d6:
	/* 0x34d6: mov    BYTE PTR [r13+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_34da:
	/* 0x34da: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_34dc:
	/* 0x34dc: je     35ec <syscall_checker+0x35ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34dc, 0x35ec, x86_l_35ec);
x86_l_34e2:
	/* 0x34e2: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_34e6:
	/* 0x34e6: mov    BYTE PTR [r13+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_34ea:
	/* 0x34ea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_34ec:
	/* 0x34ec: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34ec, 0x38c4, x86_l_38c4);
x86_l_34f2:
	/* 0x34f2: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_34f6:
	/* 0x34f6: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34fb:
	/* 0x34fb: mov    BYTE PTR [rdx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_34fe:
	/* 0x34fe: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3500:
	/* 0x3500: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3500, 0x38c4, x86_l_38c4);
x86_l_3506:
	/* 0x3506: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_350a:
	/* 0x350a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_350f:
	/* 0x350f: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3512:
	/* 0x3512: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3514:
	/* 0x3514: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3514, 0x38c4, x86_l_38c4);
x86_l_351a:
	/* 0x351a: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_351e:
	/* 0x351e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3523:
	/* 0x3523: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_3526:
	/* 0x3526: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3528:
	/* 0x3528: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3528, 0x38c4, x86_l_38c4);
x86_l_352e:
	/* 0x352e: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3532:
	/* 0x3532: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3537:
	/* 0x3537: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_353a:
	/* 0x353a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_353c:
	/* 0x353c: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x353c, 0x38c4, x86_l_38c4);
x86_l_3542:
	/* 0x3542: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3546:
	/* 0x3546: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_354b:
	/* 0x354b: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_354e:
	/* 0x354e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3550:
	/* 0x3550: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3550, 0x38c4, x86_l_38c4);
x86_l_3556:
	/* 0x3556: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_355a:
	/* 0x355a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_355f:
	/* 0x355f: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_3562:
	/* 0x3562: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3564:
	/* 0x3564: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3564, 0x38c4, x86_l_38c4);
x86_l_356a:
	/* 0x356a: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_356e:
	/* 0x356e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3573:
	/* 0x3573: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_3576:
	/* 0x3576: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3578:
	/* 0x3578: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3578, 0x38c4, x86_l_38c4);
x86_l_357e:
	/* 0x357e: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_3582:
	/* 0x3582: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3587:
	/* 0x3587: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_358a:
	/* 0x358a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_358c:
	/* 0x358c: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x358c, 0x38c4, x86_l_38c4);
x86_l_3592:
	/* 0x3592: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_3596:
	/* 0x3596: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_359b:
	/* 0x359b: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_359e:
	/* 0x359e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_35a0:
	/* 0x35a0: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35a0, 0x38c4, x86_l_38c4);
x86_l_35a6:
	/* 0x35a6: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_35aa:
	/* 0x35aa: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35af:
	/* 0x35af: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_35b2:
	/* 0x35b2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_35b4:
	/* 0x35b4: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35b4, 0x38c4, x86_l_38c4);
x86_l_35ba:
	/* 0x35ba: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_35be:
	/* 0x35be: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35c3:
	/* 0x35c3: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_35c6:
	/* 0x35c6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_35c8:
	/* 0x35c8: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35c8, 0x38c4, x86_l_38c4);
x86_l_35ce:
	/* 0x35ce: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_35d2:
	/* 0x35d2: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35d7:
	/* 0x35d7: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_35da:
	/* 0x35da: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_35dc:
	/* 0x35dc: je     38c4 <syscall_checker+0x38c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35dc, 0x38c4, x86_l_38c4);
x86_l_35e2:
	/* 0x35e2: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35e7:
	/* 0x35e7: mov    BYTE PTR [r13+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_35ec:
	/* 0x35ec: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35f1:
	/* 0x35f1: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_35f6:
	/* 0x35f6: jmp    2db <syscall_checker+0x2db> */
	X86_SIM_X86_JMP(0x35f6, 0x2db, x86_l_2db);
x86_l_35fb:
	/* 0x35fb: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3603:
	/* 0x3603: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_360a:
	/* 0x360a: jmp    2db <syscall_checker+0x2db> */
	X86_SIM_X86_JMP(0x360a, 0x2db, x86_l_2db);
x86_l_360f:
	/* 0x360f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3611:
	/* 0x3611: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3614:
	/* 0x3614: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3617:
	/* 0x3617: jns    361b <syscall_checker+0x361b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3617, 0x361b, x86_l_361b);
x86_l_3619:
	/* 0x3619: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_361b:
	/* 0x361b: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_361d:
	/* 0x361d: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3621:
	/* 0x3621: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3624:
	/* 0x3624: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3628:
	/* 0x3628: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_362a:
	/* 0x362a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_362d:
	/* 0x362d: jns    3631 <syscall_checker+0x3631> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x362d, 0x3631, x86_l_3631);
x86_l_362f:
	/* 0x362f: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3631:
	/* 0x3631: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3636:
	/* 0x3636: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3639:
	/* 0x3639: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_363e:
	/* 0x363e: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3641:
	/* 0x3641: lea    rax,[r13+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3648:
	/* 0x3648: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_364d:
	/* 0x364d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3650:
	/* 0x3650: jns    3657 <syscall_checker+0x3657> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3650, 0x3657, x86_l_3657);
x86_l_3652:
	/* 0x3652: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3655:
	/* 0x3655: jmp    3659 <syscall_checker+0x3659> */
	X86_SIM_X86_JMP(0x3655, 0x3659, x86_l_3659);
x86_l_3657:
	/* 0x3657: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3659:
	/* 0x3659: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_365d:
	/* 0x365d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_365f:
	/* 0x365f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3662:
	/* 0x3662: jns    3669 <syscall_checker+0x3669> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3662, 0x3669, x86_l_3669);
x86_l_3664:
	/* 0x3664: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3667:
	/* 0x3667: jmp    366b <syscall_checker+0x366b> */
	X86_SIM_X86_JMP(0x3667, 0x366b, x86_l_366b);
x86_l_3669:
	/* 0x3669: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_366b:
	/* 0x366b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_366e:
	/* 0x366e: jns    3672 <syscall_checker+0x3672> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x366e, 0x3672, x86_l_3672);
x86_l_3670:
	/* 0x3670: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3672:
	/* 0x3672: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3677:
	/* 0x3677: mov    DWORD PTR [r12+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_367c:
	/* 0x367c: call   3681 <syscall_checker+0x3681> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_3681:
	/* 0x3681: mov    DWORD PTR [r12+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3686:
	/* 0x3686: lea    rax,[r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_368a:
	/* 0x368a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_368d:
	/* 0x368d: jns    3694 <syscall_checker+0x3694> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x368d, 0x3694, x86_l_3694);
x86_l_368f:
	/* 0x368f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3692:
	/* 0x3692: jmp    3696 <syscall_checker+0x3696> */
	X86_SIM_X86_JMP(0x3692, 0x3696, x86_l_3696);
x86_l_3694:
	/* 0x3694: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3696:
	/* 0x3696: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_369b:
	/* 0x369b: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_369e:
	/* 0x369e: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_36a3:
	/* 0x36a3: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_36a7:
	/* 0x36a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36aa:
	/* 0x36aa: jns    36b1 <syscall_checker+0x36b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36aa, 0x36b1, x86_l_36b1);
x86_l_36ac:
	/* 0x36ac: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36af:
	/* 0x36af: jmp    36b3 <syscall_checker+0x36b3> */
	X86_SIM_X86_JMP(0x36af, 0x36b3, x86_l_36b3);
x86_l_36b1:
	/* 0x36b1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36b3:
	/* 0x36b3: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36b8:
	/* 0x36b8: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_36bc:
	/* 0x36bc: add    rbx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_36c0:
	/* 0x36c0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_36c3:
	/* 0x36c3: jns    36ca <syscall_checker+0x36ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36c3, 0x36ca, x86_l_36ca);
x86_l_36c5:
	/* 0x36c5: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36c8:
	/* 0x36c8: jmp    36cc <syscall_checker+0x36cc> */
	X86_SIM_X86_JMP(0x36c8, 0x36cc, x86_l_36cc);
x86_l_36ca:
	/* 0x36ca: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36cc:
	/* 0x36cc: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36d1:
	/* 0x36d1: mov    QWORD PTR [r12+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_36d6:
	/* 0x36d6: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_36d9:
	/* 0x36d9: jns    36e9 <syscall_checker+0x36e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36d9, 0x36e9, x86_l_36e9);
x86_l_36db:
	/* 0x36db: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36df:
	/* 0x36df: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_36e1:
	/* 0x36e1: je     36e9 <syscall_checker+0x36e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36e1, 0x36e9, x86_l_36e9);
x86_l_36e3:
	/* 0x36e3: or     BYTE PTR [r12+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_36e9:
	/* 0x36e9: lea    rdi,[r12+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_36ee:
	/* 0x36ee: mov    QWORD PTR [r12+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_36f7:
	/* 0x36f7: mov    QWORD PTR [r12+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_3700:
	/* 0x3700: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3705:
	/* 0x3705: call   370a <syscall_checker+0x370a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_370a:
	/* 0x370a: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_370f:
	/* 0x370f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3712:
	/* 0x3712: jns    3719 <syscall_checker+0x3719> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3712, 0x3719, x86_l_3719);
x86_l_3714:
	/* 0x3714: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3717:
	/* 0x3717: jmp    371b <syscall_checker+0x371b> */
	X86_SIM_X86_JMP(0x3717, 0x371b, x86_l_371b);
x86_l_3719:
	/* 0x3719: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_371b:
	/* 0x371b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_371e:
	/* 0x371e: jns    3725 <syscall_checker+0x3725> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x371e, 0x3725, x86_l_3725);
x86_l_3720:
	/* 0x3720: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3723:
	/* 0x3723: jmp    3727 <syscall_checker+0x3727> */
	X86_SIM_X86_JMP(0x3723, 0x3727, x86_l_3727);
x86_l_3725:
	/* 0x3725: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3727:
	/* 0x3727: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_372a:
	/* 0x372a: jns    3777 <syscall_checker+0x3777> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x372a, 0x3777, x86_l_3777);
x86_l_372c:
	/* 0x372c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_372f:
	/* 0x372f: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3734:
	/* 0x3734: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3738:
	/* 0x3738: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_373d:
	/* 0x373d: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3741:
	/* 0x3741: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3746:
	/* 0x3746: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_374a:
	/* 0x374a: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_374f:
	/* 0x374f: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3753:
	/* 0x3753: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3758:
	/* 0x3758: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_375c:
	/* 0x375c: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3761:
	/* 0x3761: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3765:
	/* 0x3765: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_376a:
	/* 0x376a: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_376e:
	/* 0x376e: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3773:
	/* 0x3773: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_3777:
	/* 0x3777: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_377a:
	/* 0x377a: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_377e:
	/* 0x377e: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3783:
	/* 0x3783: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3786:
	/* 0x3786: jns    38b0 <syscall_checker+0x38b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3786, 0x38b0, x86_l_38b0);
x86_l_378c:
	/* 0x378c: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_378f:
	/* 0x378f: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3791:
	/* 0x3791: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_3793:
	/* 0x3793: je     feb <syscall_checker+0xfeb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3793, 0xfeb, x86_l_feb);
x86_l_3799:
	/* 0x3799: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_379d:
	/* 0x379d: mov    BYTE PTR [r12+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_37a2:
	/* 0x37a2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_37a4:
	/* 0x37a4: je     38a6 <syscall_checker+0x38a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37a4, 0x38a6, x86_l_38a6);
x86_l_37aa:
	/* 0x37aa: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_37ae:
	/* 0x37ae: mov    BYTE PTR [r12+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_37b3:
	/* 0x37b3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_37b5:
	/* 0x37b5: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37b5, 0x38d8, x86_l_38d8);
x86_l_37bb:
	/* 0x37bb: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_37bf:
	/* 0x37bf: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37c4:
	/* 0x37c4: mov    BYTE PTR [rdx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_37c7:
	/* 0x37c7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_37c9:
	/* 0x37c9: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37c9, 0x38d8, x86_l_38d8);
x86_l_37cf:
	/* 0x37cf: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_37d3:
	/* 0x37d3: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37d8:
	/* 0x37d8: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_37db:
	/* 0x37db: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_37dd:
	/* 0x37dd: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37dd, 0x38d8, x86_l_38d8);
x86_l_37e3:
	/* 0x37e3: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_37e7:
	/* 0x37e7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37ec:
	/* 0x37ec: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_37ef:
	/* 0x37ef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_37f1:
	/* 0x37f1: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37f1, 0x38d8, x86_l_38d8);
x86_l_37f7:
	/* 0x37f7: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_37fb:
	/* 0x37fb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3800:
	/* 0x3800: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_3803:
	/* 0x3803: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3805:
	/* 0x3805: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3805, 0x38d8, x86_l_38d8);
x86_l_380b:
	/* 0x380b: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_380f:
	/* 0x380f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3814:
	/* 0x3814: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_3817:
	/* 0x3817: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3819:
	/* 0x3819: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3819, 0x38d8, x86_l_38d8);
x86_l_381f:
	/* 0x381f: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_3823:
	/* 0x3823: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3828:
	/* 0x3828: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_382b:
	/* 0x382b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_382d:
	/* 0x382d: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x382d, 0x38d8, x86_l_38d8);
x86_l_3833:
	/* 0x3833: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_3837:
	/* 0x3837: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_383c:
	/* 0x383c: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_383f:
	/* 0x383f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3841:
	/* 0x3841: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3841, 0x38d8, x86_l_38d8);
x86_l_3847:
	/* 0x3847: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_384b:
	/* 0x384b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3850:
	/* 0x3850: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_3853:
	/* 0x3853: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3855:
	/* 0x3855: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3855, 0x38d8, x86_l_38d8);
x86_l_385b:
	/* 0x385b: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_385f:
	/* 0x385f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3864:
	/* 0x3864: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_3867:
	/* 0x3867: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3869:
	/* 0x3869: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3869, 0x38d8, x86_l_38d8);
x86_l_386b:
	/* 0x386b: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_386f:
	/* 0x386f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3874:
	/* 0x3874: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3877:
	/* 0x3877: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3879:
	/* 0x3879: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3879, 0x38d8, x86_l_38d8);
x86_l_387b:
	/* 0x387b: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_387f:
	/* 0x387f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3884:
	/* 0x3884: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_3887:
	/* 0x3887: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3889:
	/* 0x3889: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3889, 0x38d8, x86_l_38d8);
x86_l_388b:
	/* 0x388b: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_388f:
	/* 0x388f: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3894:
	/* 0x3894: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_3897:
	/* 0x3897: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_3899:
	/* 0x3899: je     38d8 <syscall_checker+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3899, 0x38d8, x86_l_38d8);
x86_l_389b:
	/* 0x389b: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38a0:
	/* 0x38a0: mov    BYTE PTR [r12+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_38a6:
	/* 0x38a6: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_38ab:
	/* 0x38ab: jmp    feb <syscall_checker+0xfeb> */
	X86_SIM_X86_JMP(0x38ab, 0xfeb, x86_l_feb);
x86_l_38b0:
	/* 0x38b0: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_38b8:
	/* 0x38b8: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38bf:
	/* 0x38bf: jmp    feb <syscall_checker+0xfeb> */
	X86_SIM_X86_JMP(0x38bf, 0xfeb, x86_l_feb);
x86_l_38c4:
	/* 0x38c4: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_38c9:
	/* 0x38c9: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_38ce:
	/* 0x38ce: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38d3:
	/* 0x38d3: jmp    2db <syscall_checker+0x2db> */
	X86_SIM_X86_JMP(0x38d3, 0x2db, x86_l_2db);
x86_l_38d8:
	/* 0x38d8: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_38dd:
	/* 0x38dd: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38e2:
	/* 0x38e2: jmp    feb <syscall_checker+0xfeb> */
	X86_SIM_X86_JMP(0x38e2, 0xfeb, x86_l_feb);
x86_l_38e7:
	/* 0x38e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38e9:
	/* 0x38e9: cmp    al,cl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_38eb:
	/* 0x38eb: jne    38f6 <syscall_checker+0x38f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38eb, 0x38f6, x86_l_38f6);
x86_l_38ed:
	/* 0x38ed: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_5) + (0))));
x86_l_38f4:
	/* 0x38f4: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x38f4, 0x3951, x86_l_3951);
x86_l_38f6:
	/* 0x38f6: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_38fb:
	/* 0x38fb: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3900:
	/* 0x3900: mov    rcx,QWORD PTR [rcx+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_3907:
	/* 0x3907: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_6) + (0))));
x86_l_390e:
	/* 0x390e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3911:
	/* 0x3911: je     3926 <syscall_checker+0x3926> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3911, 0x3926, x86_l_3926);
x86_l_3913:
	/* 0x3913: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3916:
	/* 0x3916: ja     3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3916, 0x3951, x86_l_3951);
x86_l_3918:
	/* 0x3918: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_391d:
	/* 0x391d: mov    rcx,QWORD PTR [rcx+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3924:
	/* 0x3924: jmp    3937 <syscall_checker+0x3937> */
	X86_SIM_X86_JMP(0x3924, 0x3937, x86_l_3937);
x86_l_3926:
	/* 0x3926: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_392b:
	/* 0x392b: mov    rcx,QWORD PTR [rcx+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3932:
	/* 0x3932: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3935:
	/* 0x3935: je     3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3935, 0x3951, x86_l_3951);
x86_l_3937:
	/* 0x3937: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_393a:
	/* 0x393a: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_393d:
	/* 0x393d: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_393f:
	/* 0x393f: jne    394a <syscall_checker+0x394a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x393f, 0x394a, x86_l_394a);
x86_l_3941:
	/* 0x3941: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_6) + (0))));
x86_l_3948:
	/* 0x3948: jmp    3951 <syscall_checker+0x3951> */
	X86_SIM_X86_JMP(0x3948, 0x3951, x86_l_3951);
x86_l_394a:
	/* 0x394a: lea    r8,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_7) + (0))));
x86_l_3951:
	/* 0x3951: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3954:
	/* 0x3954: jns    395c <syscall_checker+0x395c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3954, 0x395c, x86_l_395c);
x86_l_3956:
	/* 0x3956: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_395a:
	/* 0x395a: jmp    395e <syscall_checker+0x395e> */
	X86_SIM_X86_JMP(0x395a, 0x395e, x86_l_395e);
x86_l_395c:
	/* 0x395c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_395e:
	/* 0x395e: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3963:
	/* 0x3963: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_396b:
	/* 0x396b: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_396e:
	/* 0x396e: jns    3976 <syscall_checker+0x3976> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x396e, 0x3976, x86_l_3976);
x86_l_3970:
	/* 0x3970: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3974:
	/* 0x3974: jmp    3978 <syscall_checker+0x3978> */
	X86_SIM_X86_JMP(0x3974, 0x3978, x86_l_3978);
x86_l_3976:
	/* 0x3976: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3978:
	/* 0x3978: sub    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 136ULL);
x86_l_3980:
	/* 0x3980: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3988:
	/* 0x3988: add    r12,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_398c:
	/* 0x398c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_398f:
	/* 0x398f: jns    3997 <syscall_checker+0x3997> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x398f, 0x3997, x86_l_3997);
x86_l_3991:
	/* 0x3991: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3995:
	/* 0x3995: jmp    3999 <syscall_checker+0x3999> */
	X86_SIM_X86_JMP(0x3995, 0x3999, x86_l_3999);
x86_l_3997:
	/* 0x3997: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3999:
	/* 0x3999: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_39a1:
	/* 0x39a1: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_39a9:
	/* 0x39a9: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_39b0:
	/* 0x39b0: ja     3a1d <syscall_checker+0x3a1d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x39b0, 0x3a1d, x86_l_3a1d);
x86_l_39b2:
	/* 0x39b2: mov    BYTE PTR [r14+rbx*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519552ULL);
x86_l_39bb:
	/* 0x39bb: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_39c1:
	/* 0x39c1: ja     3a1d <syscall_checker+0x3a1d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x39c1, 0x3a1d, x86_l_3a1d);
x86_l_39c3:
	/* 0x39c3: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_39c7:
	/* 0x39c7: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_39ce:
	/* 0x39ce: lea    rax,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_39d6:
	/* 0x39d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39d9:
	/* 0x39d9: jns    39e6 <syscall_checker+0x39e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x39d9, 0x39e6, x86_l_39e6);
x86_l_39db:
	/* 0x39db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39de:
	/* 0x39de: jns    3a17 <syscall_checker+0x3a17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x39de, 0x3a17, x86_l_3a17);
x86_l_39e0:
	/* 0x39e0: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39e2:
	/* 0x39e2: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39e4:
	/* 0x39e4: jmp    3a03 <syscall_checker+0x3a03> */
	X86_SIM_X86_JMP(0x39e4, 0x3a03, x86_l_3a03);
x86_l_39e6:
	/* 0x39e6: lea    rdx,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_39ee:
	/* 0x39ee: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_39f3:
	/* 0x39f3: mov    r12,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_39f6:
	/* 0x39f6: call   39fb <syscall_checker+0x39fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_39fb:
	/* 0x39fb: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_39fe:
	/* 0x39fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a01:
	/* 0x3a01: js     3a1d <syscall_checker+0x3a1d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3a01, 0x3a1d, x86_l_3a1d);
x86_l_3a03:
	/* 0x3a03: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_3a06:
	/* 0x3a06: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3a0e:
	/* 0x3a0e: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3a15:
	/* 0x3a15: jmp    3a1d <syscall_checker+0x3a1d> */
	X86_SIM_X86_JMP(0x3a15, 0x3a1d, x86_l_3a1d);
x86_l_3a17:
	/* 0x3a17: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a1d:
	/* 0x3a1d: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3a25:
	/* 0x3a25: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_3a2c:
	/* 0x3a2c: ja     3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3a2c, 0x3b7b, x86_l_3b7b);
x86_l_3a32:
	/* 0x3a32: mov    BYTE PTR [r14+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_3a3b:
	/* 0x3a3b: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_3a41:
	/* 0x3a41: jbe    3a4d <syscall_checker+0x3a4d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3a41, 0x3a4d, x86_l_3a4d);
x86_l_3a43:
	/* 0x3a43: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3a4b:
	/* 0x3a4b: jmp    3a9f <syscall_checker+0x3a9f> */
	X86_SIM_X86_JMP(0x3a4b, 0x3a9f, x86_l_3a9f);
x86_l_3a4d:
	/* 0x3a4d: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3a51:
	/* 0x3a51: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3a58:
	/* 0x3a58: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a5d:
	/* 0x3a5d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a60:
	/* 0x3a60: jns    3a73 <syscall_checker+0x3a73> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a60, 0x3a73, x86_l_3a73);
x86_l_3a62:
	/* 0x3a62: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a65:
	/* 0x3a65: jns    3b07 <syscall_checker+0x3b07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a65, 0x3b07, x86_l_3b07);
x86_l_3a6b:
	/* 0x3a6b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a6e:
	/* 0x3a6e: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a71:
	/* 0x3a71: jmp    3a8d <syscall_checker+0x3a8d> */
	X86_SIM_X86_JMP(0x3a71, 0x3a8d, x86_l_3a8d);
x86_l_3a73:
	/* 0x3a73: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a78:
	/* 0x3a78: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3a7d:
	/* 0x3a7d: mov    r12,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3a80:
	/* 0x3a80: call   3a85 <syscall_checker+0x3a85> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3a85:
	/* 0x3a85: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3a88:
	/* 0x3a88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a8b:
	/* 0x3a8b: js     3a43 <syscall_checker+0x3a43> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3a8b, 0x3a43, x86_l_3a43);
x86_l_3a8d:
	/* 0x3a8d: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3a90:
	/* 0x3a90: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3a98:
	/* 0x3a98: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3a9f:
	/* 0x3a9f: movzx  eax,bx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RBX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_3aa2:
	/* 0x3aa2: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_3aa7:
	/* 0x3aa7: ja     3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3aa7, 0x3b7b, x86_l_3b7b);
x86_l_3aad:
	/* 0x3aad: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_3ab6:
	/* 0x3ab6: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3abe:
	/* 0x3abe: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_3ac6:
	/* 0x3ac6: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_3acc:
	/* 0x3acc: ja     3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3acc, 0x3b7b, x86_l_3b7b);
x86_l_3ad2:
	/* 0x3ad2: lea    rdi,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3ad6:
	/* 0x3ad6: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_3add:
	/* 0x3add: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3ae0:
	/* 0x3ae0: jns    3b13 <syscall_checker+0x3b13> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ae0, 0x3b13, x86_l_3b13);
x86_l_3ae2:
	/* 0x3ae2: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3ae5:
	/* 0x3ae5: jns    3b29 <syscall_checker+0x3b29> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ae5, 0x3b29, x86_l_3b29);
x86_l_3ae7:
	/* 0x3ae7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ae9:
	/* 0x3ae9: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_3af0:
	/* 0x3af0: je     3b37 <syscall_checker+0x3b37> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3af0, 0x3b37, x86_l_3b37);
x86_l_3af2:
	/* 0x3af2: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3af6:
	/* 0x3af6: movzx  edx,BYTE PTR [r8+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_3afb:
	/* 0x3afb: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3afe:
	/* 0x3afe: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b01:
	/* 0x3b01: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_3b03:
	/* 0x3b03: jne    3ae9 <syscall_checker+0x3ae9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b03, 0x3ae9, x86_l_3ae9);
x86_l_3b05:
	/* 0x3b05: jmp    3b20 <syscall_checker+0x3b20> */
	X86_SIM_X86_JMP(0x3b05, 0x3b20, x86_l_3b20);
x86_l_3b07:
	/* 0x3b07: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b0e:
	/* 0x3b0e: jmp    3a43 <syscall_checker+0x3a43> */
	X86_SIM_X86_JMP(0x3b0e, 0x3a43, x86_l_3a43);
x86_l_3b13:
	/* 0x3b13: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3b18:
	/* 0x3b18: mov    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3b1b:
	/* 0x3b1b: call   3b20 <syscall_checker+0x3b20> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_3b20:
	/* 0x3b20: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b23:
	/* 0x3b23: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3b25:
	/* 0x3b25: jg     3b48 <syscall_checker+0x3b48> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3b25, 0x3b48, x86_l_3b48);
x86_l_3b27:
	/* 0x3b27: jmp    3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JMP(0x3b27, 0x3b7b, x86_l_3b7b);
x86_l_3b29:
	/* 0x3b29: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3b2e:
	/* 0x3b2e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b30:
	/* 0x3b30: call   3b35 <syscall_checker+0x3b35> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_3b35:
	/* 0x3b35: jmp    3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JMP(0x3b35, 0x3b7b, x86_l_3b7b);
x86_l_3b37:
	/* 0x3b37: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_3b3e:
	/* 0x3b3e: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3b43:
	/* 0x3b43: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_3b48:
	/* 0x3b48: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3b50:
	/* 0x3b50: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_3b57:
	/* 0x3b57: ja     3b7b <syscall_checker+0x3b7b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3b57, 0x3b7b, x86_l_3b7b);
x86_l_3b59:
	/* 0x3b59: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_3b61:
	/* 0x3b61: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_3b69:
	/* 0x3b69: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_3b6c:
	/* 0x3b6c: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3b74:
	/* 0x3b74: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3b7b:
	/* 0x3b7b: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3b83:
	/* 0x3b83: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_3b8a:
	/* 0x3b8a: ja     3bf4 <syscall_checker+0x3bf4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3b8a, 0x3bf4, x86_l_3bf4);
x86_l_3b8c:
	/* 0x3b8c: mov    BYTE PTR [r14+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_3b95:
	/* 0x3b95: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_3b9b:
	/* 0x3b9b: ja     3bf4 <syscall_checker+0x3bf4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3b9b, 0x3bf4, x86_l_3bf4);
x86_l_3b9d:
	/* 0x3b9d: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3ba1:
	/* 0x3ba1: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3ba8:
	/* 0x3ba8: lea    rax,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_3bb0:
	/* 0x3bb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bb3:
	/* 0x3bb3: jns    3bc2 <syscall_checker+0x3bc2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3bb3, 0x3bc2, x86_l_3bc2);
x86_l_3bb5:
	/* 0x3bb5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bb8:
	/* 0x3bb8: jns    3bed <syscall_checker+0x3bed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3bb8, 0x3bed, x86_l_3bed);
x86_l_3bba:
	/* 0x3bba: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bbd:
	/* 0x3bbd: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bc0:
	/* 0x3bc0: jmp    3bd9 <syscall_checker+0x3bd9> */
	X86_SIM_X86_JMP(0x3bc0, 0x3bd9, x86_l_3bd9);
x86_l_3bc2:
	/* 0x3bc2: lea    rdx,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_3bca:
	/* 0x3bca: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3bcf:
	/* 0x3bcf: call   3bd4 <syscall_checker+0x3bd4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3bd4:
	/* 0x3bd4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bd7:
	/* 0x3bd7: js     3bf4 <syscall_checker+0x3bf4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3bd7, 0x3bf4, x86_l_3bf4);
x86_l_3bd9:
	/* 0x3bd9: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3bdc:
	/* 0x3bdc: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3be4:
	/* 0x3be4: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3beb:
	/* 0x3beb: jmp    3bf4 <syscall_checker+0x3bf4> */
	X86_SIM_X86_JMP(0x3beb, 0x3bf4, x86_l_3bf4);
x86_l_3bed:
	/* 0x3bed: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3bf4:
	/* 0x3bf4: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3bfc:
	/* 0x3bfc: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_3c03:
	/* 0x3c03: ja     3c6d <syscall_checker+0x3c6d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c03, 0x3c6d, x86_l_3c6d);
x86_l_3c05:
	/* 0x3c05: mov    BYTE PTR [r14+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_3c0e:
	/* 0x3c0e: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_3c14:
	/* 0x3c14: ja     3c6d <syscall_checker+0x3c6d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c14, 0x3c6d, x86_l_3c6d);
x86_l_3c16:
	/* 0x3c16: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3c1a:
	/* 0x3c1a: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3c21:
	/* 0x3c21: lea    rax,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3c29:
	/* 0x3c29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c2c:
	/* 0x3c2c: jns    3c3b <syscall_checker+0x3c3b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c2c, 0x3c3b, x86_l_3c3b);
x86_l_3c2e:
	/* 0x3c2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c31:
	/* 0x3c31: jns    3c66 <syscall_checker+0x3c66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c31, 0x3c66, x86_l_3c66);
x86_l_3c33:
	/* 0x3c33: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c36:
	/* 0x3c36: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c39:
	/* 0x3c39: jmp    3c52 <syscall_checker+0x3c52> */
	X86_SIM_X86_JMP(0x3c39, 0x3c52, x86_l_3c52);
x86_l_3c3b:
	/* 0x3c3b: lea    rdx,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_3c43:
	/* 0x3c43: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3c48:
	/* 0x3c48: call   3c4d <syscall_checker+0x3c4d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3c4d:
	/* 0x3c4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c50:
	/* 0x3c50: js     3c6d <syscall_checker+0x3c6d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3c50, 0x3c6d, x86_l_3c6d);
x86_l_3c52:
	/* 0x3c52: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3c55:
	/* 0x3c55: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3c5d:
	/* 0x3c5d: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3c64:
	/* 0x3c64: jmp    3c6d <syscall_checker+0x3c6d> */
	X86_SIM_X86_JMP(0x3c64, 0x3c6d, x86_l_3c6d);
x86_l_3c66:
	/* 0x3c66: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c6d:
	/* 0x3c6d: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3c75:
	/* 0x3c75: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_3c7c:
	/* 0x3c7c: ja     3ce6 <syscall_checker+0x3ce6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c7c, 0x3ce6, x86_l_3ce6);
x86_l_3c7e:
	/* 0x3c7e: mov    BYTE PTR [r14+rbx*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519557ULL);
x86_l_3c87:
	/* 0x3c87: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_3c8d:
	/* 0x3c8d: ja     3ce6 <syscall_checker+0x3ce6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3c8d, 0x3ce6, x86_l_3ce6);
x86_l_3c8f:
	/* 0x3c8f: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_3c93:
	/* 0x3c93: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_3c9a:
	/* 0x3c9a: lea    rax,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3ca2:
	/* 0x3ca2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ca5:
	/* 0x3ca5: jns    3cb4 <syscall_checker+0x3cb4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ca5, 0x3cb4, x86_l_3cb4);
x86_l_3ca7:
	/* 0x3ca7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3caa:
	/* 0x3caa: jns    3cdf <syscall_checker+0x3cdf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3caa, 0x3cdf, x86_l_3cdf);
x86_l_3cac:
	/* 0x3cac: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3caf:
	/* 0x3caf: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3cb2:
	/* 0x3cb2: jmp    3ccb <syscall_checker+0x3ccb> */
	X86_SIM_X86_JMP(0x3cb2, 0x3ccb, x86_l_3ccb);
x86_l_3cb4:
	/* 0x3cb4: lea    rdx,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3cbc:
	/* 0x3cbc: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3cc1:
	/* 0x3cc1: call   3cc6 <syscall_checker+0x3cc6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3cc6:
	/* 0x3cc6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cc9:
	/* 0x3cc9: js     3ce6 <syscall_checker+0x3ce6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3cc9, 0x3ce6, x86_l_3ce6);
x86_l_3ccb:
	/* 0x3ccb: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_3cce:
	/* 0x3cce: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_3cd6:
	/* 0x3cd6: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_3cdd:
	/* 0x3cdd: jmp    3ce6 <syscall_checker+0x3ce6> */
	X86_SIM_X86_JMP(0x3cdd, 0x3ce6, x86_l_3ce6);
x86_l_3cdf:
	/* 0x3cdf: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ce6:
	/* 0x3ce6: mov    r12,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_3ced:
	/* 0x3ced: lea    rcx,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3cf2:
	/* 0x3cf2: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3cf5:
	/* 0x3cf5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cf8:
	/* 0x3cf8: jns    3cff <syscall_checker+0x3cff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3cf8, 0x3cff, x86_l_3cff);
x86_l_3cfa:
	/* 0x3cfa: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3cfd:
	/* 0x3cfd: jmp    3d02 <syscall_checker+0x3d02> */
	X86_SIM_X86_JMP(0x3cfd, 0x3d02, x86_l_3d02);
x86_l_3cff:
	/* 0x3cff: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d02:
	/* 0x3d02: lea    rax,[r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3d06:
	/* 0x3d06: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d09:
	/* 0x3d09: jns    3d10 <syscall_checker+0x3d10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d09, 0x3d10, x86_l_3d10);
x86_l_3d0b:
	/* 0x3d0b: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d0e:
	/* 0x3d0e: jmp    3d12 <syscall_checker+0x3d12> */
	X86_SIM_X86_JMP(0x3d0e, 0x3d12, x86_l_3d12);
x86_l_3d10:
	/* 0x3d10: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d12:
	/* 0x3d12: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3d16:
	/* 0x3d16: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d18:
	/* 0x3d18: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3d1b:
	/* 0x3d1b: jns    3d22 <syscall_checker+0x3d22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d1b, 0x3d22, x86_l_3d22);
x86_l_3d1d:
	/* 0x3d1d: mov    rbp,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d20:
	/* 0x3d20: jmp    3d24 <syscall_checker+0x3d24> */
	X86_SIM_X86_JMP(0x3d20, 0x3d24, x86_l_3d24);
x86_l_3d22:
	/* 0x3d22: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d24:
	/* 0x3d24: lea    rdx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3d28:
	/* 0x3d28: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3d2b:
	/* 0x3d2b: jns    3d2f <syscall_checker+0x3d2f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d2b, 0x3d2f, x86_l_3d2f);
x86_l_3d2d:
	/* 0x3d2d: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d2f:
	/* 0x3d2f: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_3d33:
	/* 0x3d33: lea    rax,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d38:
	/* 0x3d38: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d3b:
	/* 0x3d3b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d3d:
	/* 0x3d3d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d40:
	/* 0x3d40: jns    3d47 <syscall_checker+0x3d47> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d40, 0x3d47, x86_l_3d47);
x86_l_3d42:
	/* 0x3d42: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d45:
	/* 0x3d45: jmp    3d49 <syscall_checker+0x3d49> */
	X86_SIM_X86_JMP(0x3d45, 0x3d49, x86_l_3d49);
x86_l_3d47:
	/* 0x3d47: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d49:
	/* 0x3d49: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d4c:
	/* 0x3d4c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3d4f:
	/* 0x3d4f: jns    3d53 <syscall_checker+0x3d53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d4f, 0x3d53, x86_l_3d53);
x86_l_3d51:
	/* 0x3d51: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d53:
	/* 0x3d53: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3d55:
	/* 0x3d55: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3d59:
	/* 0x3d59: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3d5c:
	/* 0x3d5c: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3d60:
	/* 0x3d60: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d62:
	/* 0x3d62: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d65:
	/* 0x3d65: jns    3d69 <syscall_checker+0x3d69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d65, 0x3d69, x86_l_3d69);
x86_l_3d67:
	/* 0x3d67: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d69:
	/* 0x3d69: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_3d6d:
	/* 0x3d6d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3d70:
	/* 0x3d70: jns    3d77 <syscall_checker+0x3d77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d70, 0x3d77, x86_l_3d77);
x86_l_3d72:
	/* 0x3d72: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d75:
	/* 0x3d75: jmp    3d79 <syscall_checker+0x3d79> */
	X86_SIM_X86_JMP(0x3d75, 0x3d79, x86_l_3d79);
x86_l_3d77:
	/* 0x3d77: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d79:
	/* 0x3d79: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3d7d:
	/* 0x3d7d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d7f:
	/* 0x3d7f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3d82:
	/* 0x3d82: jns    3d89 <syscall_checker+0x3d89> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d82, 0x3d89, x86_l_3d89);
x86_l_3d84:
	/* 0x3d84: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d87:
	/* 0x3d87: jmp    3d8b <syscall_checker+0x3d8b> */
	X86_SIM_X86_JMP(0x3d87, 0x3d8b, x86_l_3d8b);
x86_l_3d89:
	/* 0x3d89: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d8b:
	/* 0x3d8b: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3d8e:
	/* 0x3d8e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d91:
	/* 0x3d91: jns    3d95 <syscall_checker+0x3d95> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d91, 0x3d95, x86_l_3d95);
x86_l_3d93:
	/* 0x3d93: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d95:
	/* 0x3d95: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3d97:
	/* 0x3d97: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3d9b:
	/* 0x3d9b: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3d9e:
	/* 0x3d9e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3da2:
	/* 0x3da2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3da4:
	/* 0x3da4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3da7:
	/* 0x3da7: jns    3dab <syscall_checker+0x3dab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3da7, 0x3dab, x86_l_3dab);
x86_l_3da9:
	/* 0x3da9: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dab:
	/* 0x3dab: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3daf:
	/* 0x3daf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3db1:
	/* 0x3db1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3db4:
	/* 0x3db4: jns    3dbb <syscall_checker+0x3dbb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3db4, 0x3dbb, x86_l_3dbb);
x86_l_3db6:
	/* 0x3db6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3db9:
	/* 0x3db9: jmp    3dbd <syscall_checker+0x3dbd> */
	X86_SIM_X86_JMP(0x3db9, 0x3dbd, x86_l_3dbd);
x86_l_3dbb:
	/* 0x3dbb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3dbd:
	/* 0x3dbd: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dc0:
	/* 0x3dc0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3dc3:
	/* 0x3dc3: jns    3dc7 <syscall_checker+0x3dc7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3dc3, 0x3dc7, x86_l_3dc7);
x86_l_3dc5:
	/* 0x3dc5: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dc7:
	/* 0x3dc7: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3dc9:
	/* 0x3dc9: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3dcd:
	/* 0x3dcd: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3dd0:
	/* 0x3dd0: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3dd4:
	/* 0x3dd4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3dd6:
	/* 0x3dd6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3dd9:
	/* 0x3dd9: jns    3de0 <syscall_checker+0x3de0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3dd9, 0x3de0, x86_l_3de0);
x86_l_3ddb:
	/* 0x3ddb: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dde:
	/* 0x3dde: jmp    3de2 <syscall_checker+0x3de2> */
	X86_SIM_X86_JMP(0x3dde, 0x3de2, x86_l_3de2);
x86_l_3de0:
	/* 0x3de0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3de2:
	/* 0x3de2: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3de6:
	/* 0x3de6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3de9:
	/* 0x3de9: jns    3ded <syscall_checker+0x3ded> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3de9, 0x3ded, x86_l_3ded);
x86_l_3deb:
	/* 0x3deb: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ded:
	/* 0x3ded: lea    rcx,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3df1:
	/* 0x3df1: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3df4:
	/* 0x3df4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3df6:
	/* 0x3df6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3df9:
	/* 0x3df9: jns    3e00 <syscall_checker+0x3e00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3df9, 0x3e00, x86_l_3e00);
x86_l_3dfb:
	/* 0x3dfb: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dfe:
	/* 0x3dfe: jmp    3e02 <syscall_checker+0x3e02> */
	X86_SIM_X86_JMP(0x3dfe, 0x3e02, x86_l_3e02);
x86_l_3e00:
	/* 0x3e00: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e02:
	/* 0x3e02: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3e05:
	/* 0x3e05: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3e08:
	/* 0x3e08: jns    3e0c <syscall_checker+0x3e0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e08, 0x3e0c, x86_l_3e0c);
x86_l_3e0a:
	/* 0x3e0a: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e0c:
	/* 0x3e0c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3e0e:
	/* 0x3e0e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3e12:
	/* 0x3e12: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3e15:
	/* 0x3e15: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3e19:
	/* 0x3e19: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e1b:
	/* 0x3e1b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3e1e:
	/* 0x3e1e: jns    3e25 <syscall_checker+0x3e25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e1e, 0x3e25, x86_l_3e25);
x86_l_3e20:
	/* 0x3e20: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e23:
	/* 0x3e23: jmp    3e27 <syscall_checker+0x3e27> */
	X86_SIM_X86_JMP(0x3e23, 0x3e27, x86_l_3e27);
x86_l_3e25:
	/* 0x3e25: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e27:
	/* 0x3e27: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3e2b:
	/* 0x3e2b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3e2e:
	/* 0x3e2e: jns    3e32 <syscall_checker+0x3e32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e2e, 0x3e32, x86_l_3e32);
x86_l_3e30:
	/* 0x3e30: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e32:
	/* 0x3e32: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3e34:
	/* 0x3e34: jne    3e68 <syscall_checker+0x3e68> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e34, 0x3e68, x86_l_3e68);
x86_l_3e36:
	/* 0x3e36: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e38:
	/* 0x3e38: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3e3b:
	/* 0x3e3b: jns    3e42 <syscall_checker+0x3e42> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e3b, 0x3e42, x86_l_3e42);
x86_l_3e3d:
	/* 0x3e3d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e40:
	/* 0x3e40: jmp    3e44 <syscall_checker+0x3e44> */
	X86_SIM_X86_JMP(0x3e40, 0x3e44, x86_l_3e44);
x86_l_3e42:
	/* 0x3e42: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e44:
	/* 0x3e44: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3e47:
	/* 0x3e47: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3e4a:
	/* 0x3e4a: jns    3e4e <syscall_checker+0x3e4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e4a, 0x3e4e, x86_l_3e4e);
x86_l_3e4c:
	/* 0x3e4c: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e4e:
	/* 0x3e4e: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3e50:
	/* 0x3e50: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3e54:
	/* 0x3e54: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3e57:
	/* 0x3e57: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3e5b:
	/* 0x3e5b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e5d:
	/* 0x3e5d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3e60:
	/* 0x3e60: jns    3e64 <syscall_checker+0x3e64> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e60, 0x3e64, x86_l_3e64);
x86_l_3e62:
	/* 0x3e62: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e64:
	/* 0x3e64: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e68:
	/* 0x3e68: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3e6c:
	/* 0x3e6c: lea    rbx,[r12+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3e74:
	/* 0x3e74: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3e77:
	/* 0x3e77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e7a:
	/* 0x3e7a: jns    3e81 <syscall_checker+0x3e81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e7a, 0x3e81, x86_l_3e81);
x86_l_3e7c:
	/* 0x3e7c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e7f:
	/* 0x3e7f: jmp    3e83 <syscall_checker+0x3e83> */
	X86_SIM_X86_JMP(0x3e7f, 0x3e83, x86_l_3e83);
x86_l_3e81:
	/* 0x3e81: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e83:
	/* 0x3e83: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3e87:
	/* 0x3e87: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e89:
	/* 0x3e89: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3e8c:
	/* 0x3e8c: jns    3e93 <syscall_checker+0x3e93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e8c, 0x3e93, x86_l_3e93);
x86_l_3e8e:
	/* 0x3e8e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e91:
	/* 0x3e91: jmp    3e95 <syscall_checker+0x3e95> */
	X86_SIM_X86_JMP(0x3e91, 0x3e95, x86_l_3e95);
x86_l_3e93:
	/* 0x3e93: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e95:
	/* 0x3e95: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3e98:
	/* 0x3e98: jns    3e9c <syscall_checker+0x3e9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e98, 0x3e9c, x86_l_3e9c);
x86_l_3e9a:
	/* 0x3e9a: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e9c:
	/* 0x3e9c: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_3ea0:
	/* 0x3ea0: call   3ea5 <syscall_checker+0x3ea5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_3ea5:
	/* 0x3ea5: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3ea9:
	/* 0x3ea9: lea    rax,[r12+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3eae:
	/* 0x3eae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3eb1:
	/* 0x3eb1: jns    3eb8 <syscall_checker+0x3eb8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3eb1, 0x3eb8, x86_l_3eb8);
x86_l_3eb3:
	/* 0x3eb3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3eb6:
	/* 0x3eb6: jmp    3eba <syscall_checker+0x3eba> */
	X86_SIM_X86_JMP(0x3eb6, 0x3eba, x86_l_3eba);
x86_l_3eb8:
	/* 0x3eb8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3eba:
	/* 0x3eba: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3ebf:
	/* 0x3ebf: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ec2:
	/* 0x3ec2: add    r13,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3ec6:
	/* 0x3ec6: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3ec9:
	/* 0x3ec9: jns    3ed1 <syscall_checker+0x3ed1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ec9, 0x3ed1, x86_l_3ed1);
x86_l_3ecb:
	/* 0x3ecb: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ecf:
	/* 0x3ecf: jmp    3ed3 <syscall_checker+0x3ed3> */
	X86_SIM_X86_JMP(0x3ecf, 0x3ed3, x86_l_3ed3);
x86_l_3ed1:
	/* 0x3ed1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ed3:
	/* 0x3ed3: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ed8:
	/* 0x3ed8: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3edc:
	/* 0x3edc: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3ee0:
	/* 0x3ee0: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3ee3:
	/* 0x3ee3: jns    3eeb <syscall_checker+0x3eeb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ee3, 0x3eeb, x86_l_3eeb);
x86_l_3ee5:
	/* 0x3ee5: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ee9:
	/* 0x3ee9: jmp    3eed <syscall_checker+0x3eed> */
	X86_SIM_X86_JMP(0x3ee9, 0x3eed, x86_l_3eed);
x86_l_3eeb:
	/* 0x3eeb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3eed:
	/* 0x3eed: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ef2:
	/* 0x3ef2: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3ef6:
	/* 0x3ef6: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3ef9:
	/* 0x3ef9: jns    3f08 <syscall_checker+0x3f08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ef9, 0x3f08, x86_l_3f08);
x86_l_3efb:
	/* 0x3efb: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3eff:
	/* 0x3eff: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3f01:
	/* 0x3f01: je     3f08 <syscall_checker+0x3f08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f01, 0x3f08, x86_l_3f08);
x86_l_3f03:
	/* 0x3f03: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_3f08:
	/* 0x3f08: lea    rdi,[rbp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3f0c:
	/* 0x3f0c: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_3f14:
	/* 0x3f14: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_3f1c:
	/* 0x3f1c: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3f21:
	/* 0x3f21: call   3f26 <syscall_checker+0x3f26> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_3f26:
	/* 0x3f26: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3f29:
	/* 0x3f29: jns    3f30 <syscall_checker+0x3f30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f29, 0x3f30, x86_l_3f30);
x86_l_3f2b:
	/* 0x3f2b: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f2e:
	/* 0x3f2e: jmp    3f32 <syscall_checker+0x3f32> */
	X86_SIM_X86_JMP(0x3f2e, 0x3f32, x86_l_3f32);
x86_l_3f30:
	/* 0x3f30: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f32:
	/* 0x3f32: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f35:
	/* 0x3f35: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f3a:
	/* 0x3f3a: jns    3f41 <syscall_checker+0x3f41> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f3a, 0x3f41, x86_l_3f41);
x86_l_3f3c:
	/* 0x3f3c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f3f:
	/* 0x3f3f: jmp    3f43 <syscall_checker+0x3f43> */
	X86_SIM_X86_JMP(0x3f3f, 0x3f43, x86_l_3f43);
x86_l_3f41:
	/* 0x3f41: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f43:
	/* 0x3f43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f46:
	/* 0x3f46: jns    3f93 <syscall_checker+0x3f93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f46, 0x3f93, x86_l_3f93);
x86_l_3f48:
	/* 0x3f48: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f4b:
	/* 0x3f4b: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3f50:
	/* 0x3f50: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f54:
	/* 0x3f54: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3f59:
	/* 0x3f59: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f5d:
	/* 0x3f5d: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3f62:
	/* 0x3f62: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3f66:
	/* 0x3f66: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3f6b:
	/* 0x3f6b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f6f:
	/* 0x3f6f: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3f74:
	/* 0x3f74: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3f78:
	/* 0x3f78: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3f7d:
	/* 0x3f7d: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3f81:
	/* 0x3f81: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3f86:
	/* 0x3f86: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3f8a:
	/* 0x3f8a: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3f8f:
	/* 0x3f8f: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_3f93:
	/* 0x3f93: add    rbp,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_3f97:
	/* 0x3f97: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3f9c:
	/* 0x3f9c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f9f:
	/* 0x3f9f: jns    4076 <syscall_checker+0x4076> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f9f, 0x4076, x86_l_4076);
x86_l_3fa5:
	/* 0x3fa5: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3fa8:
	/* 0x3fa8: mov    BYTE PTR [rbp+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fab:
	/* 0x3fab: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3fad:
	/* 0x3fad: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fad, 0x4086, x86_l_4086);
x86_l_3fb3:
	/* 0x3fb3: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_3fb7:
	/* 0x3fb7: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_3fbb:
	/* 0x3fbb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3fbd:
	/* 0x3fbd: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fbd, 0x4086, x86_l_4086);
x86_l_3fc3:
	/* 0x3fc3: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_3fc7:
	/* 0x3fc7: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_3fcb:
	/* 0x3fcb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3fcd:
	/* 0x3fcd: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fcd, 0x4086, x86_l_4086);
x86_l_3fd3:
	/* 0x3fd3: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_3fd7:
	/* 0x3fd7: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_3fdb:
	/* 0x3fdb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3fdd:
	/* 0x3fdd: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fdd, 0x4086, x86_l_4086);
x86_l_3fe3:
	/* 0x3fe3: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_3fe7:
	/* 0x3fe7: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3feb:
	/* 0x3feb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3fed:
	/* 0x3fed: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fed, 0x4086, x86_l_4086);
x86_l_3ff3:
	/* 0x3ff3: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_3ff7:
	/* 0x3ff7: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_3ffb:
	/* 0x3ffb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3ffd:
	/* 0x3ffd: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ffd, 0x4086, x86_l_4086);
x86_l_4003:
	/* 0x4003: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_4007:
	/* 0x4007: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_400b:
	/* 0x400b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_400d:
	/* 0x400d: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x400d, 0x4086, x86_l_4086);
x86_l_400f:
	/* 0x400f: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_4013:
	/* 0x4013: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_4017:
	/* 0x4017: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4019:
	/* 0x4019: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4019, 0x4086, x86_l_4086);
x86_l_401b:
	/* 0x401b: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_401f:
	/* 0x401f: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_4023:
	/* 0x4023: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4025:
	/* 0x4025: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4025, 0x4086, x86_l_4086);
x86_l_4027:
	/* 0x4027: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_402b:
	/* 0x402b: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_402f:
	/* 0x402f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4031:
	/* 0x4031: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4031, 0x4086, x86_l_4086);
x86_l_4033:
	/* 0x4033: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_4037:
	/* 0x4037: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_403b:
	/* 0x403b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_403d:
	/* 0x403d: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x403d, 0x4086, x86_l_4086);
x86_l_403f:
	/* 0x403f: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_4043:
	/* 0x4043: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_4047:
	/* 0x4047: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4049:
	/* 0x4049: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4049, 0x4086, x86_l_4086);
x86_l_404b:
	/* 0x404b: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_404f:
	/* 0x404f: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_4053:
	/* 0x4053: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4055:
	/* 0x4055: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4055, 0x4086, x86_l_4086);
x86_l_4057:
	/* 0x4057: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_405b:
	/* 0x405b: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_405f:
	/* 0x405f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_4061:
	/* 0x4061: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4061, 0x4086, x86_l_4086);
x86_l_4063:
	/* 0x4063: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_4067:
	/* 0x4067: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_406b:
	/* 0x406b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_406d:
	/* 0x406d: je     4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JCC(X86_CC_E, 0x406d, 0x4086, x86_l_4086);
x86_l_406f:
	/* 0x406f: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_4074:
	/* 0x4074: jmp    4086 <syscall_checker+0x4086> */
	X86_SIM_X86_JMP(0x4074, 0x4086, x86_l_4086);
x86_l_4076:
	/* 0x4076: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_407e:
	/* 0x407e: mov    QWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4086:
	/* 0x4086: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4089:
	/* 0x4089: jns    40f8 <syscall_checker+0x40f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4089, 0x40f8, x86_l_40f8);
x86_l_408b:
	/* 0x408b: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_408e:
	/* 0x408e: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4093:
	/* 0x4093: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4096:
	/* 0x4096: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_409a:
	/* 0x409a: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_409e:
	/* 0x409e: mov    rax,QWORD PTR [rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_40a2:
	/* 0x40a2: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_40a6:
	/* 0x40a6: mov    rax,QWORD PTR [rdx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_40aa:
	/* 0x40aa: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_40ae:
	/* 0x40ae: mov    rax,QWORD PTR [rdx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_40b2:
	/* 0x40b2: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_40b6:
	/* 0x40b6: mov    rax,QWORD PTR [rdx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_40ba:
	/* 0x40ba: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_40be:
	/* 0x40be: mov    rax,QWORD PTR [rdx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_40c2:
	/* 0x40c2: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_40c6:
	/* 0x40c6: mov    rax,QWORD PTR [rdx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_40ca:
	/* 0x40ca: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_40ce:
	/* 0x40ce: mov    rax,QWORD PTR [rdx+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_40d2:
	/* 0x40d2: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_40d6:
	/* 0x40d6: mov    rax,QWORD PTR [rdx+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_40da:
	/* 0x40da: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_40de:
	/* 0x40de: mov    rax,QWORD PTR [rdx+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_40e2:
	/* 0x40e2: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_40e6:
	/* 0x40e6: mov    rax,QWORD PTR [rdx+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_40ea:
	/* 0x40ea: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_40ee:
	/* 0x40ee: mov    rax,QWORD PTR [rdx+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_40f2:
	/* 0x40f2: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_40f6:
	/* 0x40f6: jmp    4164 <syscall_checker+0x4164> */
	X86_SIM_X86_JMP(0x40f6, 0x4164, x86_l_4164);
x86_l_40f8:
	/* 0x40f8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_40fd:
	/* 0x40fd: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_4105:
	/* 0x4105: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_410d:
	/* 0x410d: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_4115:
	/* 0x4115: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_411d:
	/* 0x411d: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_4125:
	/* 0x4125: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_412d:
	/* 0x412d: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_4135:
	/* 0x4135: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_413d:
	/* 0x413d: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_4145:
	/* 0x4145: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_414d:
	/* 0x414d: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_4155:
	/* 0x4155: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_415d:
	/* 0x415d: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4164:
	/* 0x4164: test   BYTE PTR [r13+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_4169:
	/* 0x4169: je     4187 <syscall_checker+0x4187> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4169, 0x4187, x86_l_4187);
x86_l_416b:
	/* 0x416b: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_4172:
	/* 0x4172: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_4177:
	/* 0x4177: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_417a:
	/* 0x417a: call   417f <syscall_checker+0x417f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_417f:
	/* 0x417f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4181:
	/* 0x4181: js     4187 <syscall_checker+0x4187> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4181, 0x4187, x86_l_4187);
x86_l_4183:
	/* 0x4183: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_4187:
	/* 0x4187: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_418f:
	/* 0x418f: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_4194:
	/* 0x4194: jb     419b <syscall_checker+0x419b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4194, 0x419b, x86_l_419b);
x86_l_4196:
	/* 0x4196: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_419b:
	/* 0x419b: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_41a0:
	/* 0x41a0: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_41a4:
	/* 0x41a4: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_41ab:
	/* 0x41ab: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_41b0:
	/* 0x41b0: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_41b3:
	/* 0x41b3: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_41b6:
	/* 0x41b6: call   41bb <syscall_checker+0x41bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_41bb:
	/* 0x41bb: jmp    da6 <syscall_checker+0xda6> */
	X86_SIM_X86_JMP(0x41bb, 0xda6, x86_l_da6);
x86_l_41c0:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
