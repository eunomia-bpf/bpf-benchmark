#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 200U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(4) M(5) M(6) M(8) M(9) M(11) M(12)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 config_map[] __ksym;
extern __u8 enforcer_data[] __ksym;
extern __u8 enforcer_missed_notifications[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 fexit_calls[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 policy_conf[] __ksym;
extern __u8 policy_stats[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 ratelimit_heap[] __ksym;
extern __u8 ratelimit_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 stack_trace_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_MEM_IMM, X86_OP_IMUL_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("fexit/generic_fexit_tail")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_8:
	/* 0x8: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_13:
	/* 0x13: mov    rdi,QWORD PTR [rip+0x460] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_1a:
	/* 0x1a: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f:
	/* 0x1f: call   484 <do_action+0x354> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24:
	/* 0x24: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27:
	/* 0x27: je     121 <generic_fexit_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27, 0x121, x86_l_121);
x86_l_2d:
	/* 0x2d: mov    r14d,DWORD PTR [rax+0x5f04] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_34:
	/* 0x34: cmp    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_38:
	/* 0x38: jl     121 <generic_fexit_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_L, 0x38, 0x121, x86_l_121);
x86_l_3e:
	/* 0x3e: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x460] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_4b:
	/* 0x4b: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e:
	/* 0x4e: call   4b3 <do_action+0x383> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     121 <generic_fexit_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x121, x86_l_121);
x86_l_5c:
	/* 0x5c: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_5f:
	/* 0x5f: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_65:
	/* 0x65: add    r14d,DWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_69:
	/* 0x69: and    r14d,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_70:
	/* 0x70: add    r14,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_73:
	/* 0x73: mov    BYTE PTR [rsp+0x7],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771073ULL);
x86_l_78:
	/* 0x78: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_80:
	/* 0x80: mov    rdi,QWORD PTR [rip+0x460] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_conf));
x86_l_87:
	/* 0x87: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8c:
	/* 0x8c: call   4f1 <do_action+0x3c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_91:
	/* 0x91: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_94:
	/* 0x94: je     a4 <generic_fexit_actions+0xa4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94, 0xa4, x86_l_a4);
x86_l_96:
	/* 0x96: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_99:
	/* 0x99: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_9c:
	/* 0x9c: cmp    DWORD PTR [r14],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_a0:
	/* 0xa0: jae    ac <generic_fexit_actions+0xac> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa0, 0xac, x86_l_ac);
x86_l_a2:
	/* 0xa2: jmp    106 <generic_fexit_actions+0x106> */
	X86_SIM_X86_JMP(0xa2, 0x106, x86_l_106);
x86_l_a4:
	/* 0xa4: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a6:
	/* 0xa6: cmp    DWORD PTR [r14],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_aa:
	/* 0xaa: jb     106 <generic_fexit_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_B, 0xaa, 0x106, x86_l_106);
x86_l_ac:
	/* 0xac: movzx  ebp,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_af:
	/* 0xaf: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_b4:
	/* 0xb4: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b7:
	/* 0xb7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b9:
	/* 0xb9: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bc:
	/* 0xbc: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_bf:
	/* 0xbf: call   0 <generic_fexit_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0xc4ULL);
x86_l_c4:
	/* 0xc4: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_cb:
	/* 0xcb: cmp    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_ce:
	/* 0xce: jae    106 <generic_fexit_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xce, 0x106, x86_l_106);
x86_l_d0:
	/* 0xd0: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_d5:
	/* 0xd5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d8:
	/* 0xd8: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_da:
	/* 0xda: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_dd:
	/* 0xdd: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_e0:
	/* 0xe0: call   0 <generic_fexit_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0xe5ULL);
x86_l_e5:
	/* 0xe5: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_ec:
	/* 0xec: cmp    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_ef:
	/* 0xef: jae    106 <generic_fexit_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xef, 0x106, x86_l_106);
x86_l_f1:
	/* 0xf1: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_f6:
	/* 0xf6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f9:
	/* 0xf9: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_fb:
	/* 0xfb: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fe:
	/* 0xfe: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_101:
	/* 0x101: call   0 <generic_fexit_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0x106ULL);
x86_l_106:
	/* 0x106: cmp    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_10b:
	/* 0x10b: je     121 <generic_fexit_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10b, 0x121, x86_l_121);
x86_l_10d:
	/* 0x10d: mov    rsi,QWORD PTR [rip+0x460] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fexit_calls));
x86_l_114:
	/* 0x114: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_117:
	/* 0x117: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_11c:
	/* 0x11c: call   581 <do_action+0x451> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_121:
	/* 0x121: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_123:
	/* 0x123: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_127:
	/* 0x127: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_128:
	/* 0x128: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12b:
	/* 0x12b: jmp    bd3 <do_action+0xaa3> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_bd3:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_130 */
x86_l_130:
	/* 0x130: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_131:
	/* 0x131: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_133:
	/* 0x133: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_135:
	/* 0x135: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_139:
	/* 0x139: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13a:
	/* 0x13a: sub    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 104ULL);
x86_l_13e:
	/* 0x13e: mov    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_141:
	/* 0x141: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_149:
	/* 0x149: mov    ebx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14b:
	/* 0x14b: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14e:
	/* 0x14e: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_150:
	/* 0x150: movsxd r12,DWORD PTR [rdx+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_RAX, 2, X86_WIDTH_32), 4ULL);
x86_l_155:
	/* 0x155: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_15d:
	/* 0x15d: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_164:
	/* 0x164: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_169:
	/* 0x169: call   27fe <do_action+0x26ce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16e:
	/* 0x16e: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_171:
	/* 0x171: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_173:
	/* 0x173: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_176:
	/* 0x176: je     b91 <do_action+0xa61> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x176, 0xb91, x86_l_b91);
x86_l_17c:
	/* 0x17c: cmp    r12d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_180:
	/* 0x180: jg     1aa <do_action+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x180, 0x1aa, x86_l_1aa);
x86_l_182:
	/* 0x182: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_186:
	/* 0x186: jg     1e2 <do_action+0xb2> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x186, 0x1e2, x86_l_1e2);
x86_l_188:
	/* 0x188: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_18c:
	/* 0x18c: jg     30b <do_action+0x1db> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x18c, 0x30b, x86_l_30b);
x86_l_192:
	/* 0x192: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_195:
	/* 0x195: je     5c2 <do_action+0x492> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x195, 0x5c2, x86_l_5c2);
x86_l_19b:
	/* 0x19b: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_19f:
	/* 0x19f: je     324 <do_action+0x1f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19f, 0x324, x86_l_324);
x86_l_1a5:
	/* 0x1a5: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x1a5, 0xb89, x86_l_b89);
x86_l_1aa:
	/* 0x1aa: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1ae:
	/* 0x1ae: jg     2dd <do_action+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ae, 0x2dd, x86_l_2dd);
x86_l_1b4:
	/* 0x1b4: lea    ecx,[r12-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_1b9:
	/* 0x1b9: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bc:
	/* 0x1bc: jb     45b <do_action+0x32b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bc, 0x45b, x86_l_45b);
x86_l_1c2:
	/* 0x1c2: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1c6:
	/* 0x1c6: je     536 <do_action+0x406> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c6, 0x536, x86_l_536);
x86_l_1cc:
	/* 0x1cc: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1d0:
	/* 0x1d0: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d0, 0xb89, x86_l_b89);
x86_l_1d6:
	/* 0x1d6: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d8:
	/* 0x1d8: mov    edi,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_1dd:
	/* 0x1dd: jmp    507 <do_action+0x3d7> */
	X86_SIM_X86_SUB_JMP(0x1dd, 0x507, x86_l_507);
x86_l_1e2:
	/* 0x1e2: lea    eax,[r12-0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_1e7:
	/* 0x1e7: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ea:
	/* 0x1ea: jb     526 <do_action+0x3f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ea, 0x526, x86_l_526);
x86_l_1f0:
	/* 0x1f0: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f4:
	/* 0x1f4: je     543 <do_action+0x413> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f4, 0x543, x86_l_543);
x86_l_1fa:
	/* 0x1fa: cmp    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_1fe:
	/* 0x1fe: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1fe, 0xb89, x86_l_b89);
x86_l_204:
	/* 0x204: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_207:
	/* 0x207: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_20c:
	/* 0x20c: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_20f:
	/* 0x20f: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_212:
	/* 0x212: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_215:
	/* 0x215: ja     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x215, 0xb89, x86_l_b89);
x86_l_21b:
	/* 0x21b: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_224:
	/* 0x224: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x224, 0xb89, x86_l_b89);
x86_l_22a:
	/* 0x22a: mov    r15d,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_22f:
	/* 0x22f: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_237:
	/* 0x237: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_23c:
	/* 0x23c: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_244:
	/* 0x244: mov    eax,DWORD PTR [r14+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_24c:
	/* 0x24c: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_250:
	/* 0x250: call   28e5 <do_action+0x27b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_255:
	/* 0x255: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_259:
	/* 0x259: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25d:
	/* 0x25d: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_264:
	/* 0x264: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_267:
	/* 0x267: call   28fc <do_action+0x27cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26c:
	/* 0x26c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26f:
	/* 0x26f: je     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x26f, 0xb89, x86_l_b89);
x86_l_275:
	/* 0x275: and    r15d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_279:
	/* 0x279: cmp    r15d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_27d:
	/* 0x27d: ja     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x27d, 0xb89, x86_l_b89);
x86_l_283:
	/* 0x283: cmp    DWORD PTR [r14+r15*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 104041287778304ULL);
x86_l_28c:
	/* 0x28c: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x28c, 0xb89, x86_l_b89);
x86_l_292:
	/* 0x292: mov    rcx,QWORD PTR [r14+r15*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 3), 24184ULL);
x86_l_29a:
	/* 0x29a: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_2a0:
	/* 0x2a0: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2a8:
	/* 0x2a8: mov    ecx,DWORD PTR [r14+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_2b0:
	/* 0x2b0: mov    DWORD PTR [rsp+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b4:
	/* 0x2b4: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b7:
	/* 0x2b7: call   294c <do_action+0x281c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_2bc:
	/* 0x2bc: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2c0:
	/* 0x2c0: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c4:
	/* 0x2c4: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_2cb:
	/* 0x2cb: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_2ce:
	/* 0x2ce: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d1:
	/* 0x2d1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d3:
	/* 0x2d3: call   2968 <do_action+0x2838> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2d8:
	/* 0x2d8: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x2d8, 0xb89, x86_l_b89);
x86_l_2dd:
	/* 0x2dd: cmp    r12d,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2e1:
	/* 0x2e1: je     664 <do_action+0x534> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2e1, 0x664, x86_l_664);
x86_l_2e7:
	/* 0x2e7: cmp    r12d,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2eb:
	/* 0x2eb: je     552 <do_action+0x422> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2eb, 0x552, x86_l_552);
x86_l_2f1:
	/* 0x2f1: cmp    r12d,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_2f5:
	/* 0x2f5: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2f5, 0xb89, x86_l_b89);
x86_l_2fb:
	/* 0x2fb: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_2fe:
	/* 0x2fe: movzx  r15d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_302:
	/* 0x302: xor    r15,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 9ULL);
x86_l_306:
	/* 0x306: jmp    66f <do_action+0x53f> */
	X86_SIM_X86_SUB_JMP(0x306, 0x66f, x86_l_66f);
x86_l_30b:
	/* 0x30b: mov    edi,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_310:
	/* 0x310: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_314:
	/* 0x314: je     507 <do_action+0x3d7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x314, 0x507, x86_l_507);
x86_l_31a:
	/* 0x31a: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_31e:
	/* 0x31e: jne    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x31e, 0xb89, x86_l_b89);
x86_l_324:
	/* 0x324: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_327:
	/* 0x327: mov    r13d,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_32c:
	/* 0x32c: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_32f:
	/* 0x32f: mov    ebp,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_334:
	/* 0x334: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_33c:
	/* 0x33c: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap));
x86_l_343:
	/* 0x343: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_348:
	/* 0x348: call   29dd <do_action+0x28ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_34d:
	/* 0x34d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_350:
	/* 0x350: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_353:
	/* 0x353: je     b82 <do_action+0xa52> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x353, 0xb82, x86_l_b82);
x86_l_359:
	/* 0x359: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35c:
	/* 0x35c: and    r13d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_360:
	/* 0x360: cmp    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_364:
	/* 0x364: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_369:
	/* 0x369: ja     b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x369, 0xb84, x86_l_b84);
x86_l_36f:
	/* 0x36f: cmp    DWORD PTR [r14+r13*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 104041287778304ULL);
x86_l_378:
	/* 0x378: jne    b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x378, 0xb84, x86_l_b84);
x86_l_37e:
	/* 0x37e: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_383:
	/* 0x383: mov    rax,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_38b:
	/* 0x38b: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_390:
	/* 0x390: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_398:
	/* 0x398: mov    eax,DWORD PTR [r14+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_3a0:
	/* 0x3a0: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a4:
	/* 0x3a4: call   2a39 <do_action+0x2909> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_3a9:
	/* 0x3a9: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3ad:
	/* 0x3ad: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b1:
	/* 0x3b1: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3b5:
	/* 0x3b5: jne    6fa <do_action+0x5ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3b5, 0x6fa, x86_l_6fa);
x86_l_3bb:
	/* 0x3bb: and    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_3be:
	/* 0x3be: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3c1:
	/* 0x3c1: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3c6:
	/* 0x3c6: ja     b82 <do_action+0xa52> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x3c6, 0xb82, x86_l_b82);
x86_l_3cc:
	/* 0x3cc: cmp    DWORD PTR [r14+rbp*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 104041287778304ULL);
x86_l_3d5:
	/* 0x3d5: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3da:
	/* 0x3da: jne    b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3da, 0xb84, x86_l_b84);
x86_l_3e0:
	/* 0x3e0: mov    rcx,QWORD PTR [r14+rbp*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 3), 24184ULL);
x86_l_3e8:
	/* 0x3e8: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_3ee:
	/* 0x3ee: lea    rax,[r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3f2:
	/* 0x3f2: add    rax,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_3f8:
	/* 0x3f8: mov    esi,DWORD PTR [r14+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_400:
	/* 0x400: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_402:
	/* 0x402: and    ecx,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_408:
	/* 0x408: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_40c:
	/* 0x40c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40f:
	/* 0x40f: jns    b4d <do_action+0xa1d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x40f, 0xb4d, x86_l_b4d);
x86_l_415:
	/* 0x415: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_418:
	/* 0x418: jns    b5c <do_action+0xa2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x418, 0xb5c, x86_l_b5c);
x86_l_41e:
	/* 0x41e: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_420:
	/* 0x420: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_423:
	/* 0x423: mov    rdi,QWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_427:
	/* 0x427: mov    QWORD PTR [rdx+r8*1],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_42b:
	/* 0x42b: lea    rdi,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42f:
	/* 0x42f: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_433:
	/* 0x433: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_436:
	/* 0x436: jbe    420 <do_action+0x2f0> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x436, 0x420, x86_l_420);
x86_l_438:
	/* 0x438: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_43c:
	/* 0x43c: jne    ba0 <do_action+0xa70> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x43c, 0xba0, x86_l_ba0);
x86_l_442:
	/* 0x442: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_446:
	/* 0x446: jne    bb3 <do_action+0xa83> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x446, 0xbb3, x86_l_bb3);
x86_l_44c:
	/* 0x44c: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_450:
	/* 0x450: je     b6e <do_action+0xa3e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x450, 0xb6e, x86_l_b6e);
x86_l_456:
	/* 0x456: jmp    bc8 <do_action+0xa98> */
	X86_SIM_X86_SUB_JMP(0x456, 0xbc8, x86_l_bc8);
x86_l_45b:
	/* 0x45b: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_45d:
	/* 0x45d: mov    ecx,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_462:
	/* 0x462: and    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_465:
	/* 0x465: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_468:
	/* 0x468: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_46b:
	/* 0x46b: ja     b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x46b, 0xb84, x86_l_b84);
x86_l_471:
	/* 0x471: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_47a:
	/* 0x47a: jne    b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x47a, 0xb84, x86_l_b84);
x86_l_480:
	/* 0x480: mov    rcx,QWORD PTR [r14+rcx*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24184ULL);
x86_l_488:
	/* 0x488: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_48e:
	/* 0x48e: mov    rcx,QWORD PTR [r14+rcx*1+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 184ULL);
x86_l_496:
	/* 0x496: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49b:
	/* 0x49b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_49e:
	/* 0x49e: je     b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x49e, 0xb84, x86_l_b84);
x86_l_4a4:
	/* 0x4a4: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_4a8:
	/* 0x4a8: jne    706 <do_action+0x5d6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a8, 0x706, x86_l_706);
x86_l_4ae:
	/* 0x4ae: call   2b43 <do_action+0x2a13> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_4b3:
	/* 0x4b3: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b6:
	/* 0x4b6: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_4ba:
	/* 0x4ba: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4bd:
	/* 0x4bd: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_4c4:
	/* 0x4c4: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_4c7:
	/* 0x4c7: call   2b5c <do_action+0x2a2c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4cc:
	/* 0x4cc: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cf:
	/* 0x4cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4d2:
	/* 0x4d2: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_4d7:
	/* 0x4d7: je     b84 <do_action+0xa54> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d7, 0xb84, x86_l_b84);
x86_l_4dd:
	/* 0x4dd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4df:
	/* 0x4df: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e2:
	/* 0x4e2: mov    DWORD PTR [rsp+0x4],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4e7:
	/* 0x4e7: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4eb:
	/* 0x4eb: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4f0:
	/* 0x4f0: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_4f7:
	/* 0x4f7: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4fa:
	/* 0x4fa: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4ff:
	/* 0x4ff: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_502:
	/* 0x502: jmp    b7b <do_action+0xa4b> */
	X86_SIM_X86_SUB_JMP(0x502, 0xb7b, x86_l_b7b);
x86_l_507:
	/* 0x507: mov    r15d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_50d:
	/* 0x50d: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_510:
	/* 0x510: je     66f <do_action+0x53f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x510, 0x66f, x86_l_66f);
x86_l_516:
	/* 0x516: call   2bab <do_action+0x2a7b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_send_signal);
x86_l_51b:
	/* 0x51b: mov    r15d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_521:
	/* 0x521: jmp    66f <do_action+0x53f> */
	X86_SIM_X86_SUB_JMP(0x521, 0x66f, x86_l_66f);
x86_l_526:
	/* 0x526: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_528:
	/* 0x528: mov    eax,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_52d:
	/* 0x52d: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_531:
	/* 0x531: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x531, 0xb89, x86_l_b89);
x86_l_536:
	/* 0x536: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_53b:
	/* 0x53b: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53e:
	/* 0x53e: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x53e, 0xb89, x86_l_b89);
x86_l_543:
	/* 0x543: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_545:
	/* 0x545: movzx  r15d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_549:
	/* 0x549: xor    r15,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 5ULL);
x86_l_54d:
	/* 0x54d: jmp    66f <do_action+0x53f> */
	X86_SIM_X86_SUB_JMP(0x54d, 0x66f, x86_l_66f);
x86_l_552:
	/* 0x552: call   2be7 <do_action+0x2ab7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_557:
	/* 0x557: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_55c:
	/* 0x55c: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_563:
	/* 0x563: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_568:
	/* 0x568: call   2bfd <do_action+0x2acd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56d:
	/* 0x56d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_570:
	/* 0x570: je     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x570, 0xb89, x86_l_b89);
x86_l_576:
	/* 0x576: mov    rax,QWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_57a:
	/* 0x57a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_57f:
	/* 0x57f: mov    DWORD PTR [rsp+0x18],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215106ULL);
x86_l_587:
	/* 0x587: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_58e:
	/* 0x58e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_593:
	/* 0x593: call   2c28 <do_action+0x2af8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_598:
	/* 0x598: mov    DWORD PTR [rsp+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_5a0:
	/* 0x5a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a3:
	/* 0x5a3: je     698 <do_action+0x568> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5a3, 0x698, x86_l_698);
x86_l_5a9:
	/* 0x5a9: lock inc DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_5ac:
	/* 0x5ac: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_5b3:
	/* 0x5b3: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5b8:
	/* 0x5b8: call   2c4d <do_action+0x2b1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_5bd:
	/* 0x5bd: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x5bd, 0xb89, x86_l_b89);
x86_l_5c2:
	/* 0x5c2: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_5c5:
	/* 0x5c5: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_5ca:
	/* 0x5ca: lea    eax,[rbx+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_5cd:
	/* 0x5cd: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_5d2:
	/* 0x5d2: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5d6:
	/* 0x5d6: call   2c6b <do_action+0x2b3b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_5db:
	/* 0x5db: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5df:
	/* 0x5df: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_5e7:
	/* 0x5e7: mov    QWORD PTR [rsp+0x60],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_5ec:
	/* 0x5ec: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5ef:
	/* 0x5ef: je     a94 <do_action+0x964> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5ef, 0xa94, x86_l_a94);
x86_l_5f5:
	/* 0x5f5: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_heap));
x86_l_5fc:
	/* 0x5fc: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_601:
	/* 0x601: call   2c96 <do_action+0x2b66> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_606:
	/* 0x606: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_609:
	/* 0x609: je     a94 <do_action+0x964> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x609, 0xa94, x86_l_a94);
x86_l_60f:
	/* 0x60f: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_614:
	/* 0x614: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_617:
	/* 0x617: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_61e:
	/* 0x61e: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_623:
	/* 0x623: call   2cb8 <do_action+0x2b88> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_628:
	/* 0x628: mov    rcx,QWORD PTR [r14+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_62c:
	/* 0x62c: mov    QWORD PTR [rbp+0x0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_630:
	/* 0x630: mov    rcx,QWORD PTR [r14+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_634:
	/* 0x634: mov    QWORD PTR [rsp+0x40],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_639:
	/* 0x639: mov    QWORD PTR [rbp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_63d:
	/* 0x63d: mov    ecx,DWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_641:
	/* 0x641: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_644:
	/* 0x644: je     725 <do_action+0x5f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x644, 0x725, x86_l_725);
x86_l_64a:
	/* 0x64a: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_64d:
	/* 0x64d: je     71f <do_action+0x5ef> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x64d, 0x71f, x86_l_71f);
x86_l_653:
	/* 0x653: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_655:
	/* 0x655: jne    a94 <do_action+0x964> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x655, 0xa94, x86_l_a94);
x86_l_65b:
	/* 0x65b: mov    ecx,DWORD PTR [r14+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_65f:
	/* 0x65f: jmp    727 <do_action+0x5f7> */
	X86_SIM_X86_SUB_JMP(0x65f, 0x727, x86_l_727);
x86_l_664:
	/* 0x664: add    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_667:
	/* 0x667: movzx  r15d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_66b:
	/* 0x66b: xor    r15,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 7ULL);
x86_l_66f:
	/* 0x66f: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_676:
	/* 0x676: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_stats));
x86_l_67d:
	/* 0x67d: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_680:
	/* 0x680: call   2d15 <do_action+0x2be5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_685:
	/* 0x685: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_688:
	/* 0x688: je     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x688, 0xb89, x86_l_b89);
x86_l_68e:
	/* 0x68e: lock inc QWORD PTR [rax+r15*8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_R15, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_693:
	/* 0x693: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0x693, 0xb89, x86_l_b89);
x86_l_698:
	/* 0x698: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_69f:
	/* 0x69f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6a4:
	/* 0x6a4: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_6a9:
	/* 0x6a9: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_6ae:
	/* 0x6ae: call   2d43 <do_action+0x2c13> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_6b3:
	/* 0x6b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b6:
	/* 0x6b6: je     5ac <do_action+0x47c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6b6, 0x5ac, x86_l_5ac);
x86_l_6bc:
	/* 0x6bc: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6bf:
	/* 0x6bf: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_6c1:
	/* 0x6c1: mov    WORD PTR [rsp],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c5:
	/* 0x6c5: mov    WORD PTR [rsp+0x2],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934595ULL);
x86_l_6cc:
	/* 0x6cc: movabs rax,0x20000003b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8589934651ULL);
x86_l_6d6:
	/* 0x6d6: mov    QWORD PTR [rsp+0x4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_6db:
	/* 0x6db: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_6e2:
	/* 0x6e2: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_6e5:
	/* 0x6e5: call   2d7a <do_action+0x2c4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6ea:
	/* 0x6ea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ed:
	/* 0x6ed: je     b00 <do_action+0x9d0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6ed, 0xb00, x86_l_b00);
x86_l_6f3:
	/* 0x6f3: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6f5:
	/* 0x6f5: jmp    b1e <do_action+0x9ee> */
	X86_SIM_X86_SUB_JMP(0x6f5, 0xb1e, x86_l_b1e);
x86_l_6fa:
	/* 0x6fa: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_701:
	/* 0x701: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_704:
	/* 0x704: jmp    712 <do_action+0x5e2> */
	X86_SIM_X86_SUB_JMP(0x704, 0x712, x86_l_712);
x86_l_706:
	/* 0x706: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_70d:
	/* 0x70d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_712:
	/* 0x712: call   2da7 <do_action+0x2c77> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_717:
	/* 0x717: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_71a:
	/* 0x71a: jmp    b82 <do_action+0xa52> */
	X86_SIM_X86_SUB_JMP(0x71a, 0xb82, x86_l_b82);
x86_l_71f:
	/* 0x71f: mov    ecx,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_723:
	/* 0x723: jmp    727 <do_action+0x5f7> */
	X86_SIM_X86_SUB_JMP(0x723, 0x727, x86_l_727);
x86_l_725:
	/* 0x725: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_727:
	/* 0x727: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_729:
	/* 0x729: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_72e:
	/* 0x72e: mov    QWORD PTR [rdx+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_732:
	/* 0x732: mov    rdi,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_737:
	/* 0x737: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_73b:
	/* 0x73b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73e:
	/* 0x73e: mov    QWORD PTR [rsp+0x58],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_743:
	/* 0x743: mov    QWORD PTR [rsp+0x48],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_748:
	/* 0x748: jns    864 <do_action+0x734> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x748, 0x864, x86_l_864);
x86_l_74e:
	/* 0x74e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_751:
	/* 0x751: jns    873 <do_action+0x743> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x751, 0x873, x86_l_873);
x86_l_757:
	/* 0x757: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_75a:
	/* 0x75a: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_75f:
	/* 0x75f: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_763:
	/* 0x763: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_767:
	/* 0x767: mov    QWORD PTR [rdx+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_76b:
	/* 0x76b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76f:
	/* 0x76f: mov    QWORD PTR [rdx+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_773:
	/* 0x773: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_777:
	/* 0x777: mov    QWORD PTR [rdx+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_77b:
	/* 0x77b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_77f:
	/* 0x77f: mov    QWORD PTR [rdx+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_783:
	/* 0x783: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_787:
	/* 0x787: mov    QWORD PTR [rdx+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_78b:
	/* 0x78b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_78f:
	/* 0x78f: mov    QWORD PTR [rdx+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_793:
	/* 0x793: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_797:
	/* 0x797: mov    QWORD PTR [rdx+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_79b:
	/* 0x79b: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_79f:
	/* 0x79f: mov    QWORD PTR [rdx+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7a3:
	/* 0x7a3: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_7a7:
	/* 0x7a7: mov    QWORD PTR [rdx+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_7ab:
	/* 0x7ab: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7af:
	/* 0x7af: mov    QWORD PTR [rdx+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7b3:
	/* 0x7b3: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7b7:
	/* 0x7b7: mov    QWORD PTR [rdx+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7bb:
	/* 0x7bb: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_7bf:
	/* 0x7bf: mov    QWORD PTR [rdx+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_7c3:
	/* 0x7c3: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_7c7:
	/* 0x7c7: mov    QWORD PTR [rdx+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_7ce:
	/* 0x7ce: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7d2:
	/* 0x7d2: mov    QWORD PTR [rdx+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_7d9:
	/* 0x7d9: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_7dd:
	/* 0x7dd: mov    QWORD PTR [rdx+0x90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_7e4:
	/* 0x7e4: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_7eb:
	/* 0x7eb: mov    QWORD PTR [rdx+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_7f2:
	/* 0x7f2: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_7f9:
	/* 0x7f9: mov    QWORD PTR [rdx+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_800:
	/* 0x800: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_807:
	/* 0x807: mov    QWORD PTR [rdx+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_80e:
	/* 0x80e: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_815:
	/* 0x815: mov    QWORD PTR [rdx+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_81c:
	/* 0x81c: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_823:
	/* 0x823: mov    QWORD PTR [rdx+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_82a:
	/* 0x82a: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_831:
	/* 0x831: mov    QWORD PTR [rdx+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_838:
	/* 0x838: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_83f:
	/* 0x83f: mov    QWORD PTR [rdx+0xc8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_846:
	/* 0x846: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_84d:
	/* 0x84d: mov    QWORD PTR [rdx+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_854:
	/* 0x854: mov    rax,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_85b:
	/* 0x85b: mov    QWORD PTR [rdx+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_862:
	/* 0x862: jmp    87f <do_action+0x74f> */
	X86_SIM_X86_SUB_JMP(0x862, 0x87f, x86_l_87f);
x86_l_864:
	/* 0x864: mov    esi,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_869:
	/* 0x869: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86c:
	/* 0x86c: call   2f01 <do_action+0x2dd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_871:
	/* 0x871: jmp    87f <do_action+0x74f> */
	X86_SIM_X86_SUB_JMP(0x871, 0x87f, x86_l_87f);
x86_l_873:
	/* 0x873: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_878:
	/* 0x878: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_87a:
	/* 0x87a: call   2f0f <do_action+0x2ddf> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_87f:
	/* 0x87f: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_882:
	/* 0x882: mov    rbp,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_889:
	/* 0x889: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_891:
	/* 0x891: jmp    8bf <do_action+0x78f> */
	X86_SIM_X86_SUB_JMP(0x891, 0x8bf, x86_l_8bf);
x86_l_893:
	/* 0x893: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_895:
	/* 0x895: mov    QWORD PTR [rsp+0x20],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_89a:
	/* 0x89a: call   2f2f <do_action+0x2dff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_89f:
	/* 0x89f: mov    r8,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8a4:
	/* 0x8a4: add    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_8a7:
	/* 0x8a7: mov    DWORD PTR [rsp+0x20],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8ab:
	/* 0x8ab: mov    rbp,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_8b2:
	/* 0x8b2: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_8b5:
	/* 0x8b5: cmp    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 5ULL);
x86_l_8b9:
	/* 0x8b9: je     a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8b9, 0xa47, x86_l_a47);
x86_l_8bf:
	/* 0x8bf: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_8c7:
	/* 0x8c7: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_8ca:
	/* 0x8ca: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8cf:
	/* 0x8cf: call   2f64 <do_action+0x2e34> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8d4:
	/* 0x8d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8d7:
	/* 0x8d7: je     a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8d7, 0xa47, x86_l_a47);
x86_l_8dd:
	/* 0x8dd: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_8e3:
	/* 0x8e3: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_8ea:
	/* 0x8ea: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ed:
	/* 0x8ed: call   2f82 <do_action+0x2e52> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8f2:
	/* 0x8f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8f5:
	/* 0x8f5: je     a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8f5, 0xa47, x86_l_a47);
x86_l_8fb:
	/* 0x8fb: cmp    DWORD PTR [rax+r13*4+0x40],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 279172874239ULL);
x86_l_901:
	/* 0x901: je     a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x901, 0xa47, x86_l_a47);
x86_l_907:
	/* 0x907: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_90f:
	/* 0x90f: mov    eax,DWORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_913:
	/* 0x913: cmp    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_916:
	/* 0x916: jge    a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x916, 0xa47, x86_l_a47);
x86_l_91c:
	/* 0x91c: cmp    r13,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_920:
	/* 0x920: je     97a <do_action+0x84a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x920, 0x97a, x86_l_97a);
x86_l_922:
	/* 0x922: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_92a:
	/* 0x92a: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_92d:
	/* 0x92d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_932:
	/* 0x932: call   2fc7 <do_action+0x2e97> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_937:
	/* 0x937: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_93a:
	/* 0x93a: je     972 <do_action+0x842> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x93a, 0x972, x86_l_972);
x86_l_93c:
	/* 0x93c: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_942:
	/* 0x942: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_949:
	/* 0x949: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_94c:
	/* 0x94c: call   2fe1 <do_action+0x2eb1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_951:
	/* 0x951: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_954:
	/* 0x954: je     972 <do_action+0x842> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x954, 0x972, x86_l_972);
x86_l_956:
	/* 0x956: cmp    DWORD PTR [rax+r13*4+0x44],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 296352743423ULL);
x86_l_95c:
	/* 0x95c: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_964:
	/* 0x964: je     97a <do_action+0x84a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x964, 0x97a, x86_l_97a);
x86_l_966:
	/* 0x966: mov    ecx,DWORD PTR [r14+r13*8+0x5e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 24192ULL);
x86_l_96e:
	/* 0x96e: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_970:
	/* 0x970: jmp    983 <do_action+0x853> */
	X86_SIM_X86_SUB_JMP(0x970, 0x983, x86_l_983);
x86_l_972:
	/* 0x972: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_97a:
	/* 0x97a: mov    ecx,DWORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_97e:
	/* 0x97e: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_980:
	/* 0x980: add    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_983:
	/* 0x983: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_985:
	/* 0x985: jle    8b2 <do_action+0x782> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x985, 0x8b2, x86_l_8b2);
x86_l_98b:
	/* 0x98b: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_98d:
	/* 0x98d: cmp    ecx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_990:
	/* 0x990: jl     997 <do_action+0x867> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x990, 0x997, x86_l_997);
x86_l_992:
	/* 0x992: mov    ebp,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_997:
	/* 0x997: add    edx,0x3ffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16380ULL);
x86_l_99d:
	/* 0x99d: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_9a3:
	/* 0x9a3: movzx  r8d,BYTE PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_9a9:
	/* 0x9a9: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_9ae:
	/* 0x9ae: lea    rdi,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_9b2:
	/* 0x9b2: add    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_9b5:
	/* 0x9b5: add    rdx,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_9bc:
	/* 0x9bc: jns    893 <do_action+0x763> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x9bc, 0x893, x86_l_893);
x86_l_9c2:
	/* 0x9c2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9c5:
	/* 0x9c5: jns    9fe <do_action+0x8ce> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x9c5, 0x9fe, x86_l_9fe);
x86_l_9c7:
	/* 0x9c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9c9:
	/* 0x9c9: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_9cc:
	/* 0x9cc: jb     9e6 <do_action+0x8b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9cc, 0x9e6, x86_l_9e6);
x86_l_9ce:
	/* 0x9ce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9d0:
	/* 0x9d0: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9d2:
	/* 0x9d2: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_9d6:
	/* 0x9d6: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_9da:
	/* 0x9da: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9dd:
	/* 0x9dd: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_9e0:
	/* 0x9e0: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_9e2:
	/* 0x9e2: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_9e4:
	/* 0x9e4: jbe    9d0 <do_action+0x8a0> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x9e4, 0x9d0, x86_l_9d0);
x86_l_9e6:
	/* 0x9e6: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_9ea:
	/* 0x9ea: jne    a11 <do_action+0x8e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x9ea, 0xa11, x86_l_a11);
x86_l_9ec:
	/* 0x9ec: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_9f0:
	/* 0x9f0: jne    a22 <do_action+0x8f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x9f0, 0xa22, x86_l_a22);
x86_l_9f2:
	/* 0x9f2: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_9f6:
	/* 0x9f6: je     8a4 <do_action+0x774> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9f6, 0x8a4, x86_l_8a4);
x86_l_9fc:
	/* 0x9fc: jmp    a39 <do_action+0x909> */
	X86_SIM_X86_SUB_JMP(0x9fc, 0xa39, x86_l_a39);
x86_l_9fe:
	/* 0x9fe: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a00:
	/* 0xa00: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a02:
	/* 0xa02: mov    QWORD PTR [rsp+0x20],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a07:
	/* 0xa07: call   309c <do_action+0x2f6c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_a0c:
	/* 0xa0c: jmp    89f <do_action+0x76f> */
	X86_SIM_X86_SUB_JMP(0xa0c, 0x89f, x86_l_89f);
x86_l_a11:
	/* 0xa11: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a13:
	/* 0xa13: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a16:
	/* 0xa16: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a19:
	/* 0xa19: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_a1c:
	/* 0xa1c: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_a20:
	/* 0xa20: je     9f2 <do_action+0x8c2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa20, 0x9f2, x86_l_9f2);
x86_l_a22:
	/* 0xa22: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a24:
	/* 0xa24: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_a28:
	/* 0xa28: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a2c:
	/* 0xa2c: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_a2f:
	/* 0xa2f: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a33:
	/* 0xa33: je     8a4 <do_action+0x774> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa33, 0x8a4, x86_l_8a4);
x86_l_a39:
	/* 0xa39: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a3b:
	/* 0xa3b: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_a3f:
	/* 0xa3f: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_a42:
	/* 0xa42: jmp    8a4 <do_action+0x774> */
	X86_SIM_X86_SUB_JMP(0xa42, 0x8a4, x86_l_8a4);
x86_l_a47:
	/* 0xa47: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_a4e:
	/* 0xa4e: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a53:
	/* 0xa53: call   30e8 <do_action+0x2fb8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a58:
	/* 0xa58: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a5b:
	/* 0xa5b: je     a79 <do_action+0x949> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa5b, 0xa79, x86_l_a79);
x86_l_a5d:
	/* 0xa5d: imul   rcx,QWORD PTR [rsp+0x60],0xfffffffffff0bdc0 */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 416610827712ULL);
x86_l_a66:
	/* 0xa66: add    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_a6a:
	/* 0xa6a: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a6d:
	/* 0xa6d: jbe    a79 <do_action+0x949> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xa6d, 0xa79, x86_l_a79);
x86_l_a6f:
	/* 0xa6f: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a74:
	/* 0xa74: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a77:
	/* 0xa77: jmp    a8f <do_action+0x95f> */
	X86_SIM_X86_SUB_JMP(0xa77, 0xa8f, x86_l_a8f);
x86_l_a79:
	/* 0xa79: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_a80:
	/* 0xa80: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_a83:
	/* 0xa83: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a88:
	/* 0xa88: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a8a:
	/* 0xa8a: call   311f <do_action+0x2fef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_a8f:
	/* 0xa8f: mov    r13,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_a94:
	/* 0xa94: lea    eax,[rbx+0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_a97:
	/* 0xa97: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_a9d:
	/* 0xa9d: je     abc <do_action+0x98c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa9d, 0xabc, x86_l_abc);
x86_l_a9f:
	/* 0xa9f: or     BYTE PTR [r14+0x1],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967298ULL);
x86_l_aa4:
	/* 0xaa4: mov    rsi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_aab:
	/* 0xaab: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_aae:
	/* 0xaae: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ab0:
	/* 0xab0: call   3145 <do_action+0x3015> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_ab5:
	/* 0xab5: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_abc:
	/* 0xabc: lea    eax,[rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_abf:
	/* 0xabf: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_ac5:
	/* 0xac5: je     ae7 <do_action+0x9b7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xac5, 0xae7, x86_l_ae7);
x86_l_ac7:
	/* 0xac7: or     BYTE PTR [r14+0x1],0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967300ULL);
x86_l_acc:
	/* 0xacc: mov    rsi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_ad3:
	/* 0xad3: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_ad8:
	/* 0xad8: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_adb:
	/* 0xadb: call   3170 <do_action+0x3040> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_ae0:
	/* 0xae0: mov    QWORD PTR [r14+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_ae7:
	/* 0xae7: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_aea:
	/* 0xaea: cmp    DWORD PTR [r15+rbx*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 17179869184ULL);
x86_l_af0:
	/* 0xaf0: je     b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaf0, 0xb89, x86_l_b89);
x86_l_af6:
	/* 0xaf6: or     BYTE PTR [r14+0x1],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967304ULL);
x86_l_afb:
	/* 0xafb: jmp    b89 <do_action+0xa59> */
	X86_SIM_X86_SUB_JMP(0xafb, 0xb89, x86_l_b89);
x86_l_b00:
	/* 0xb00: mov    DWORD PTR [rsp+0x54],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 360777252865ULL);
x86_l_b08:
	/* 0xb08: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_b0f:
	/* 0xb0f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b12:
	/* 0xb12: lea    rdx,[rsp+0x54] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_b17:
	/* 0xb17: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b19:
	/* 0xb19: call   31ae <do_action+0x307e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b1e:
	/* 0xb1e: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_b21:
	/* 0xb21: je     5ac <do_action+0x47c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb21, 0x5ac, x86_l_5ac);
x86_l_b27:
	/* 0xb27: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_b2e:
	/* 0xb2e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b33:
	/* 0xb33: call   31c8 <do_action+0x3098> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b38:
	/* 0xb38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b3b:
	/* 0xb3b: je     5ac <do_action+0x47c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb3b, 0x5ac, x86_l_5ac);
x86_l_b41:
	/* 0xb41: mov    ecx,DWORD PTR [rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_b45:
	/* 0xb45: lock add DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RCX, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b48:
	/* 0xb48: jmp    5ac <do_action+0x47c> */
	X86_SIM_X86_SUB_JMP(0xb48, 0x5ac, x86_l_5ac);
x86_l_b4d:
	/* 0xb4d: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b50:
	/* 0xb50: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b52:
	/* 0xb52: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b55:
	/* 0xb55: call   31ea <do_action+0x30ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b5a:
	/* 0xb5a: jmp    b69 <do_action+0xa39> */
	X86_SIM_X86_SUB_JMP(0xb5a, 0xb69, x86_l_b69);
x86_l_b5c:
	/* 0xb5c: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b5f:
	/* 0xb5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b61:
	/* 0xb61: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b64:
	/* 0xb64: call   31f9 <do_action+0x30c9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_b69:
	/* 0xb69: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_b6e:
	/* 0xb6e: mov    rdi,QWORD PTR [rip+0x2690] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_b75:
	/* 0xb75: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b78:
	/* 0xb78: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b7b:
	/* 0xb7b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b7d:
	/* 0xb7d: call   3212 <do_action+0x30e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b82:
	/* 0xb82: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b84:
	/* 0xb84: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_b87:
	/* 0xb87: jne    b91 <do_action+0xa61> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb87, 0xb91, x86_l_b91);
x86_l_b89:
	/* 0xb89: mov    QWORD PTR [r14+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_b8d:
	/* 0xb8d: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_b8f:
	/* 0xb8f: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_b91:
	/* 0xb91: add    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 104ULL);
x86_l_b95:
	/* 0xb95: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b96:
	/* 0xb96: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b98:
	/* 0xb98: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b9a:
	/* 0xb9a: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b9c:
	/* 0xb9c: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b9e:
	/* 0xb9e: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b9f:
	/* 0xb9f: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b9f);
x86_l_ba0:
	/* 0xba0: mov    ecx,DWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_ba3:
	/* 0xba3: mov    DWORD PTR [rdx+rdi*1],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_ba6:
	/* 0xba6: add    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_ba9:
	/* 0xba9: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_bad:
	/* 0xbad: je     44c <do_action+0x31c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbad, 0x44c, x86_l_44c);
x86_l_bb3:
	/* 0xbb3: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_bb5:
	/* 0xbb5: movzx  r8d,WORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_bba:
	/* 0xbba: mov    WORD PTR [rdx+rcx*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_bbf:
	/* 0xbbf: add    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_bc2:
	/* 0xbc2: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_bc6:
	/* 0xbc6: je     b6e <do_action+0xa3e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbc6, 0xb6e, x86_l_b6e);
x86_l_bc8:
	/* 0xbc8: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_bca:
	/* 0xbca: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_bce:
	/* 0xbce: mov    BYTE PTR [rdx+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_bd1:
	/* 0xbd1: jmp    b6e <do_action+0xa3e> */
	X86_SIM_X86_SUB_JMP(0xbd1, 0xb6e, x86_l_b6e);

x86_sim_ret_dispatch_b9f:
	switch (__x86_sim_ret_addr) {
	case 0xc4ULL: goto x86_l_c4;
	case 0xe5ULL: goto x86_l_e5;
	case 0x106ULL: goto x86_l_106;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
