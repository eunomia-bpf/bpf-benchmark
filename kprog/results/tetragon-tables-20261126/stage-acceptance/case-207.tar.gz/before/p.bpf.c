#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 168U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11)
#include "../x86_sim_local_bpf.h"

extern __u8 bufs[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 task_info_map[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/process_execute_failed_tail")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 120ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25:
	/* 0x25: call   2a <process_execute_failed_tail+0x2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     5fd <process_execute_failed_tail+0x5fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x5fd, x86_l_5fd);
x86_l_33:
	/* 0x33: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_3d:
	/* 0x3d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_42:
	/* 0x42: call   47 <process_execute_failed_tail+0x47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_47:
	/* 0x47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a:
	/* 0x4a: je     5fd <process_execute_failed_tail+0x5fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a, 0x5fd, x86_l_5fd);
x86_l_50:
	/* 0x50: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: lea    rsi,[r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_57:
	/* 0x57: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_5e:
	/* 0x5e: call   63 <process_execute_failed_tail+0x63> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_63:
	/* 0x63: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_66:
	/* 0x66: je     5fd <process_execute_failed_tail+0x5fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x66, 0x5fd, x86_l_5fd);
x86_l_6c:
	/* 0x6c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f:
	/* 0x6f: lea    rsi,[r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_73:
	/* 0x73: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_7a:
	/* 0x7a: call   7f <process_execute_failed_tail+0x7f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f:
	/* 0x7f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_82:
	/* 0x82: je     5fd <process_execute_failed_tail+0x5fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82, 0x5fd, x86_l_5fd);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8d:
	/* 0x8d: call   92 <process_execute_failed_tail+0x92> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_92:
	/* 0x92: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_95:
	/* 0x95: call   9a <process_execute_failed_tail+0x9a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_9a:
	/* 0x9a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d:
	/* 0x9d: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a2:
	/* 0xa2: mov    QWORD PTR [rsp+0x28],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a7:
	/* 0xa7: je     e5 <process_execute_failed_tail+0xe5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7, 0xe5, x86_l_e5);
x86_l_a9:
	/* 0xa9: sub    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_ad:
	/* 0xad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b0:
	/* 0xb0: jns    155 <process_execute_failed_tail+0x155> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb0, 0x155, x86_l_155);
x86_l_b6:
	/* 0xb6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b9:
	/* 0xb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc:
	/* 0xbc: js     160 <process_execute_failed_tail+0x160> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbc, 0x160, x86_l_160);
x86_l_c2:
	/* 0xc2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c4:
	/* 0xc4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7:
	/* 0xc7: js     16c <process_execute_failed_tail+0x16c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc7, 0x16c, x86_l_16c);
x86_l_cd:
	/* 0xcd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d0:
	/* 0xd0: lea    rax,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d4:
	/* 0xd4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d7:
	/* 0xd7: js     f1 <process_execute_failed_tail+0xf1> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd7, 0xf1, x86_l_f1);
x86_l_d9:
	/* 0xd9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_db:
	/* 0xdb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_de:
	/* 0xde: jns    f9 <process_execute_failed_tail+0xf9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde, 0xf9, x86_l_f9);
x86_l_e0:
	/* 0xe0: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_e3:
	/* 0xe3: jmp    fb <process_execute_failed_tail+0xfb> */
	X86_SIM_X86_JMP(0xe3, 0xfb, x86_l_fb);
x86_l_e5:
	/* 0xe5: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e8:
	/* 0xe8: lea    rax,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ec:
	/* 0xec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ef:
	/* 0xef: jns    d9 <process_execute_failed_tail+0xd9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xef, 0xd9, x86_l_d9);
x86_l_f1:
	/* 0xf1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f4:
	/* 0xf4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f7:
	/* 0xf7: js     e0 <process_execute_failed_tail+0xe0> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf7, 0xe0, x86_l_e0);
x86_l_f9:
	/* 0xf9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb:
	/* 0xfb: and    eax,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_100:
	/* 0x100: mov    WORD PTR [rsp+0x12],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_105:
	/* 0x105: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_10d:
	/* 0x10d: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_114:
	/* 0x114: ja     1e5 <process_execute_failed_tail+0x1e5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x114, 0x1e5, x86_l_1e5);
x86_l_11a:
	/* 0x11a: mov    BYTE PTR [r14+rbx*1+0x89],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519561ULL);
x86_l_123:
	/* 0x123: cmp    ebx,0x7cfd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31997ULL);
x86_l_129:
	/* 0x129: ja     1e5 <process_execute_failed_tail+0x1e5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x129, 0x1e5, x86_l_1e5);
x86_l_12f:
	/* 0x12f: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_133:
	/* 0x133: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_13a:
	/* 0x13a: lea    rax,[rsp+0x12] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_13f:
	/* 0x13f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_142:
	/* 0x142: jns    18e <process_execute_failed_tail+0x18e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x142, 0x18e, x86_l_18e);
x86_l_144:
	/* 0x144: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_147:
	/* 0x147: jns    1e0 <process_execute_failed_tail+0x1e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x147, 0x1e0, x86_l_1e0);
x86_l_14d:
	/* 0x14d: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_150:
	/* 0x150: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153:
	/* 0x153: jmp    1a2 <process_execute_failed_tail+0x1a2> */
	X86_SIM_X86_JMP(0x153, 0x1a2, x86_l_1a2);
x86_l_155:
	/* 0x155: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157:
	/* 0x157: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15a:
	/* 0x15a: jns    c2 <process_execute_failed_tail+0xc2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15a, 0xc2, x86_l_c2);
x86_l_160:
	/* 0x160: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_163:
	/* 0x163: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_166:
	/* 0x166: jns    cd <process_execute_failed_tail+0xcd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x166, 0xcd, x86_l_cd);
x86_l_16c:
	/* 0x16c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16f:
	/* 0x16f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_172:
	/* 0x172: je     1b6 <process_execute_failed_tail+0x1b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172, 0x1b6, x86_l_1b6);
x86_l_174:
	/* 0x174: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177:
	/* 0x177: jns    1cb <process_execute_failed_tail+0x1cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x177, 0x1cb, x86_l_1cb);
x86_l_179:
	/* 0x179: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c:
	/* 0x17c: lea    rax,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_180:
	/* 0x180: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_183:
	/* 0x183: js     f1 <process_execute_failed_tail+0xf1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x183, 0xf1, x86_l_f1);
x86_l_189:
	/* 0x189: jmp    d9 <process_execute_failed_tail+0xd9> */
	X86_SIM_X86_JMP(0x189, 0xd9, x86_l_d9);
x86_l_18e:
	/* 0x18e: lea    rdx,[rsp+0x12] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18ULL);
x86_l_193:
	/* 0x193: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_198:
	/* 0x198: call   19d <process_execute_failed_tail+0x19d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_19d:
	/* 0x19d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a0:
	/* 0x1a0: js     1e5 <process_execute_failed_tail+0x1e5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a0, 0x1e5, x86_l_1e5);
x86_l_1a2:
	/* 0x1a2: add    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1a5:
	/* 0x1a5: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1ad:
	/* 0x1ad: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1b4:
	/* 0x1b4: jmp    1e5 <process_execute_failed_tail+0x1e5> */
	X86_SIM_X86_JMP(0x1b4, 0x1e5, x86_l_1e5);
x86_l_1b6:
	/* 0x1b6: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b9:
	/* 0x1b9: lea    rax,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bd:
	/* 0x1bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c0:
	/* 0x1c0: jns    d9 <process_execute_failed_tail+0xd9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c0, 0xd9, x86_l_d9);
x86_l_1c6:
	/* 0x1c6: jmp    f1 <process_execute_failed_tail+0xf1> */
	X86_SIM_X86_JMP(0x1c6, 0xf1, x86_l_f1);
x86_l_1cb:
	/* 0x1cb: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ce:
	/* 0x1ce: lea    rax,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d2:
	/* 0x1d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d5:
	/* 0x1d5: js     f1 <process_execute_failed_tail+0xf1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d5, 0xf1, x86_l_f1);
x86_l_1db:
	/* 0x1db: jmp    d9 <process_execute_failed_tail+0xd9> */
	X86_SIM_X86_JMP(0x1db, 0xd9, x86_l_d9);
x86_l_1e0:
	/* 0x1e0: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e5:
	/* 0x1e5: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1ed:
	/* 0x1ed: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_1f4:
	/* 0x1f4: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f9:
	/* 0x1f9: call   1fe <process_execute_failed_tail+0x1fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1fe:
	/* 0x1fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201:
	/* 0x201: je     219 <process_execute_failed_tail+0x219> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201, 0x219, x86_l_219);
x86_l_203:
	/* 0x203: lea    rcx,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_207:
	/* 0x207: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20a:
	/* 0x20a: jns    235 <process_execute_failed_tail+0x235> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20a, 0x235, x86_l_235);
x86_l_20c:
	/* 0x20c: mov    rbx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20f:
	/* 0x20f: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_212:
	/* 0x212: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_215:
	/* 0x215: js     23f <process_execute_failed_tail+0x23f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x215, 0x23f, x86_l_23f);
x86_l_217:
	/* 0x217: jmp    24a <process_execute_failed_tail+0x24a> */
	X86_SIM_X86_JMP(0x217, 0x24a, x86_l_24a);
x86_l_219:
	/* 0x219: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b:
	/* 0x21b: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_223:
	/* 0x223: cmp    rcx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_22a:
	/* 0x22a: jbe    1820 <process_execute_failed_tail+0x1820> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x22a, 0x1820, x86_l_1820);
x86_l_230:
	/* 0x230: jmp    18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JMP(0x230, 0x18f8, x86_l_18f8);
x86_l_235:
	/* 0x235: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_237:
	/* 0x237: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_23a:
	/* 0x23a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23d:
	/* 0x23d: jns    24a <process_execute_failed_tail+0x24a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23d, 0x24a, x86_l_24a);
x86_l_23f:
	/* 0x23f: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241:
	/* 0x241: test   cl,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_244:
	/* 0x244: jne    368 <process_execute_failed_tail+0x368> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x244, 0x368, x86_l_368);
x86_l_24a:
	/* 0x24a: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_24e:
	/* 0x24e: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_251:
	/* 0x251: jns    258 <process_execute_failed_tail+0x258> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x251, 0x258, x86_l_258);
x86_l_253:
	/* 0x253: mov    r8,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_256:
	/* 0x256: jmp    25b <process_execute_failed_tail+0x25b> */
	X86_SIM_X86_JMP(0x256, 0x25b, x86_l_25b);
x86_l_258:
	/* 0x258: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b:
	/* 0x25b: lea    rcx,[r8-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_25f:
	/* 0x25f: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_262:
	/* 0x262: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_265:
	/* 0x265: jns    289 <process_execute_failed_tail+0x289> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x265, 0x289, x86_l_289);
x86_l_267:
	/* 0x267: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a:
	/* 0x26a: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26d:
	/* 0x26d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_270:
	/* 0x270: js     293 <process_execute_failed_tail+0x293> */
	X86_SIM_X86_JCC(X86_CC_S, 0x270, 0x293, x86_l_293);
x86_l_272:
	/* 0x272: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_274:
	/* 0x274: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_278:
	/* 0x278: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27b:
	/* 0x27b: js     29f <process_execute_failed_tail+0x29f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27b, 0x29f, x86_l_29f);
x86_l_27d:
	/* 0x27d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27f:
	/* 0x27f: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_282:
	/* 0x282: jne    2ab <process_execute_failed_tail+0x2ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x282, 0x2ab, x86_l_2ab);
x86_l_284:
	/* 0x284: jmp    337 <process_execute_failed_tail+0x337> */
	X86_SIM_X86_JMP(0x284, 0x337, x86_l_337);
x86_l_289:
	/* 0x289: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b:
	/* 0x28b: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_28e:
	/* 0x28e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_291:
	/* 0x291: jns    272 <process_execute_failed_tail+0x272> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x291, 0x272, x86_l_272);
x86_l_293:
	/* 0x293: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_296:
	/* 0x296: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29a:
	/* 0x29a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29d:
	/* 0x29d: jns    27d <process_execute_failed_tail+0x27d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d, 0x27d, x86_l_27d);
x86_l_29f:
	/* 0x29f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a2:
	/* 0x2a2: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a5:
	/* 0x2a5: je     337 <process_execute_failed_tail+0x337> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a5, 0x337, x86_l_337);
x86_l_2ab:
	/* 0x2ab: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ae:
	/* 0x2ae: je     337 <process_execute_failed_tail+0x337> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ae, 0x337, x86_l_337);
x86_l_2b4:
	/* 0x2b4: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b8:
	/* 0x2b8: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bb:
	/* 0x2bb: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2c1:
	/* 0x2c1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c4:
	/* 0x2c4: jns    2cd <process_execute_failed_tail+0x2cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c4, 0x2cd, x86_l_2cd);
x86_l_2c6:
	/* 0x2c6: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c9:
	/* 0x2c9: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cd:
	/* 0x2cd: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2d1:
	/* 0x2d1: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2d4:
	/* 0x2d4: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2db:
	/* 0x2db: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2de:
	/* 0x2de: je     809 <process_execute_failed_tail+0x809> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2de, 0x809, x86_l_809);
x86_l_2e4:
	/* 0x2e4: mov    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2e7:
	/* 0x2e7: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_2e9:
	/* 0x2e9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2ef:
	/* 0x2ef: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f2:
	/* 0x2f2: mov    ebp,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_2f7:
	/* 0x2f7: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_2fa:
	/* 0x2fa: jns    7e3 <process_execute_failed_tail+0x7e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fa, 0x7e3, x86_l_7e3);
x86_l_300:
	/* 0x300: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_304:
	/* 0x304: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_307:
	/* 0x307: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: je     3dc <process_execute_failed_tail+0x3dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30a, 0x3dc, x86_l_3dc);
x86_l_310:
	/* 0x310: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_314:
	/* 0x314: movzx  ebp,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_319:
	/* 0x319: mov    BYTE PTR [rdi+r15*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_31d:
	/* 0x31d: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_320:
	/* 0x320: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_323:
	/* 0x323: jne    307 <process_execute_failed_tail+0x307> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x323, 0x307, x86_l_307);
x86_l_325:
	/* 0x325: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_328:
	/* 0x328: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_32c:
	/* 0x32c: jge    3eb <process_execute_failed_tail+0x3eb> */
	X86_SIM_X86_JCC(X86_CC_GE, 0x32c, 0x3eb, x86_l_3eb);
x86_l_332:
	/* 0x332: jmp    809 <process_execute_failed_tail+0x809> */
	X86_SIM_X86_JMP(0x332, 0x809, x86_l_809);
x86_l_337:
	/* 0x337: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_33a:
	/* 0x33a: jne    809 <process_execute_failed_tail+0x809> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33a, 0x809, x86_l_809);
x86_l_340:
	/* 0x340: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_343:
	/* 0x343: je     809 <process_execute_failed_tail+0x809> */
	X86_SIM_X86_JCC(X86_CC_E, 0x343, 0x809, x86_l_809);
x86_l_349:
	/* 0x349: add    r8,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_34d:
	/* 0x34d: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_350:
	/* 0x350: jns    39e <process_execute_failed_tail+0x39e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x350, 0x39e, x86_l_39e);
x86_l_352:
	/* 0x352: mov    rsi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_355:
	/* 0x355: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_358:
	/* 0x358: js     3a5 <process_execute_failed_tail+0x3a5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x358, 0x3a5, x86_l_3a5);
x86_l_35a:
	/* 0x35a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35c:
	/* 0x35c: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_35f:
	/* 0x35f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_362:
	/* 0x362: js     3b0 <process_execute_failed_tail+0x3b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x362, 0x3b0, x86_l_3b0);
x86_l_364:
	/* 0x364: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_366:
	/* 0x366: jmp    3b3 <process_execute_failed_tail+0x3b3> */
	X86_SIM_X86_JMP(0x366, 0x3b3, x86_l_3b3);
x86_l_368:
	/* 0x368: lea    rcx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_36f:
	/* 0x36f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_372:
	/* 0x372: jns    81e <process_execute_failed_tail+0x81e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x372, 0x81e, x86_l_81e);
x86_l_378:
	/* 0x378: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37a:
	/* 0x37a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37c:
	/* 0x37c: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_383:
	/* 0x383: je     863 <process_execute_failed_tail+0x863> */
	X86_SIM_X86_JCC(X86_CC_E, 0x383, 0x863, x86_l_863);
x86_l_389:
	/* 0x389: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_38d:
	/* 0x38d: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_391:
	/* 0x391: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_394:
	/* 0x394: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_397:
	/* 0x397: jne    37c <process_execute_failed_tail+0x37c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x397, 0x37c, x86_l_37c);
x86_l_399:
	/* 0x399: jmp    1802 <process_execute_failed_tail+0x1802> */
	X86_SIM_X86_JMP(0x399, 0x1802, x86_l_1802);
x86_l_39e:
	/* 0x39e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a0:
	/* 0x3a0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3a3:
	/* 0x3a3: jns    35a <process_execute_failed_tail+0x35a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a3, 0x35a, x86_l_35a);
x86_l_3a5:
	/* 0x3a5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a8:
	/* 0x3a8: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3ab:
	/* 0x3ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ae:
	/* 0x3ae: jns    364 <process_execute_failed_tail+0x364> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ae, 0x364, x86_l_364);
x86_l_3b0:
	/* 0x3b0: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b3:
	/* 0x3b3: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b7:
	/* 0x3b7: mov    ebp,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_3bc:
	/* 0x3bc: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3bf:
	/* 0x3bf: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3c2:
	/* 0x3c2: jns    402 <process_execute_failed_tail+0x402> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c2, 0x402, x86_l_402);
x86_l_3c4:
	/* 0x3c4: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c7:
	/* 0x3c7: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3cb:
	/* 0x3cb: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3ce:
	/* 0x3ce: js     40d <process_execute_failed_tail+0x40d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3ce, 0x40d, x86_l_40d);
x86_l_3d0:
	/* 0x3d0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d2:
	/* 0x3d2: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3d5:
	/* 0x3d5: jne    419 <process_execute_failed_tail+0x419> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d5, 0x419, x86_l_419);
x86_l_3d7:
	/* 0x3d7: jmp    495 <process_execute_failed_tail+0x495> */
	X86_SIM_X86_JMP(0x3d7, 0x495, x86_l_495);
x86_l_3dc:
	/* 0x3dc: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_3e1:
	/* 0x3e1: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3e5:
	/* 0x3e5: jl     809 <process_execute_failed_tail+0x809> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3e5, 0x809, x86_l_809);
x86_l_3eb:
	/* 0x3eb: mov    BYTE PTR [rax+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_3f2:
	/* 0x3f2: mov    ebp,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_3f7:
	/* 0x3f7: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3fa:
	/* 0x3fa: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3fd:
	/* 0x3fd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_400:
	/* 0x400: js     3c4 <process_execute_failed_tail+0x3c4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x400, 0x3c4, x86_l_3c4);
x86_l_402:
	/* 0x402: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_404:
	/* 0x404: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_408:
	/* 0x408: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_40b:
	/* 0x40b: jns    3d0 <process_execute_failed_tail+0x3d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x40b, 0x3d0, x86_l_3d0);
x86_l_40d:
	/* 0x40d: mov    rbx,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_410:
	/* 0x410: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_413:
	/* 0x413: je     495 <process_execute_failed_tail+0x495> */
	X86_SIM_X86_JCC(X86_CC_E, 0x413, 0x495, x86_l_495);
x86_l_419:
	/* 0x419: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_41c:
	/* 0x41c: je     495 <process_execute_failed_tail+0x495> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41c, 0x495, x86_l_495);
x86_l_41e:
	/* 0x41e: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_422:
	/* 0x422: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_425:
	/* 0x425: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_42b:
	/* 0x42b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_42e:
	/* 0x42e: jns    437 <process_execute_failed_tail+0x437> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x42e, 0x437, x86_l_437);
x86_l_430:
	/* 0x430: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_433:
	/* 0x433: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_437:
	/* 0x437: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_43b:
	/* 0x43b: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_43e:
	/* 0x43e: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_445:
	/* 0x445: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_447:
	/* 0x447: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_44a:
	/* 0x44a: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x44a, 0x17ed, x86_l_17ed);
x86_l_450:
	/* 0x450: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_453:
	/* 0x453: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x453, 0x7fa, x86_l_7fa);
x86_l_459:
	/* 0x459: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_45f:
	/* 0x45f: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_462:
	/* 0x462: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_465:
	/* 0x465: jns    983 <process_execute_failed_tail+0x983> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x465, 0x983, x86_l_983);
x86_l_46b:
	/* 0x46b: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_470:
	/* 0x470: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_474:
	/* 0x474: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_477:
	/* 0x477: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_47a:
	/* 0x47a: je     4ef <process_execute_failed_tail+0x4ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47a, 0x4ef, x86_l_4ef);
x86_l_47c:
	/* 0x47c: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_480:
	/* 0x480: movzx  edx,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_485:
	/* 0x485: mov    BYTE PTR [rdi+r15*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_489:
	/* 0x489: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_48c:
	/* 0x48c: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_48e:
	/* 0x48e: jne    477 <process_execute_failed_tail+0x477> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x48e, 0x477, x86_l_477);
x86_l_490:
	/* 0x490: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_493:
	/* 0x493: jmp    4f4 <process_execute_failed_tail+0x4f4> */
	X86_SIM_X86_JMP(0x493, 0x4f4, x86_l_4f4);
x86_l_495:
	/* 0x495: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_498:
	/* 0x498: jne    7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x498, 0x7fa, x86_l_7fa);
x86_l_49e:
	/* 0x49e: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4a1:
	/* 0x4a1: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a1, 0x7fa, x86_l_7fa);
x86_l_4a7:
	/* 0x4a7: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ab:
	/* 0x4ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: jns    4b5 <process_execute_failed_tail+0x4b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ae, 0x4b5, x86_l_4b5);
x86_l_4b0:
	/* 0x4b0: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b3:
	/* 0x4b3: jmp    4b7 <process_execute_failed_tail+0x4b7> */
	X86_SIM_X86_JMP(0x4b3, 0x4b7, x86_l_4b7);
x86_l_4b5:
	/* 0x4b5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b7:
	/* 0x4b7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4ba:
	/* 0x4ba: jns    4c1 <process_execute_failed_tail+0x4c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ba, 0x4c1, x86_l_4c1);
x86_l_4bc:
	/* 0x4bc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4bf:
	/* 0x4bf: jmp    4c3 <process_execute_failed_tail+0x4c3> */
	X86_SIM_X86_JMP(0x4bf, 0x4c3, x86_l_4c3);
x86_l_4c1:
	/* 0x4c1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c3:
	/* 0x4c3: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4c6:
	/* 0x4c6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4c9:
	/* 0x4c9: jns    4d0 <process_execute_failed_tail+0x4d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4c9, 0x4d0, x86_l_4d0);
x86_l_4cb:
	/* 0x4cb: mov    r11,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ce:
	/* 0x4ce: jmp    4d3 <process_execute_failed_tail+0x4d3> */
	X86_SIM_X86_JMP(0x4ce, 0x4d3, x86_l_4d3);
x86_l_4d0:
	/* 0x4d0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d3:
	/* 0x4d3: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4d7:
	/* 0x4d7: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_4da:
	/* 0x4da: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4dd:
	/* 0x4dd: jns    51b <process_execute_failed_tail+0x51b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4dd, 0x51b, x86_l_51b);
x86_l_4df:
	/* 0x4df: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e2:
	/* 0x4e2: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4e6:
	/* 0x4e6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4e9:
	/* 0x4e9: js     526 <process_execute_failed_tail+0x526> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4e9, 0x526, x86_l_526);
x86_l_4eb:
	/* 0x4eb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ed:
	/* 0x4ed: jmp    529 <process_execute_failed_tail+0x529> */
	X86_SIM_X86_JMP(0x4ed, 0x529, x86_l_529);
x86_l_4ef:
	/* 0x4ef: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_4f4:
	/* 0x4f4: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4f8:
	/* 0x4f8: mov    r11,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4fd:
	/* 0x4fd: jl     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_L, 0x4fd, 0x7fa, x86_l_7fa);
x86_l_503:
	/* 0x503: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_506:
	/* 0x506: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_50c:
	/* 0x50c: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_510:
	/* 0x510: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_513:
	/* 0x513: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_516:
	/* 0x516: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_519:
	/* 0x519: js     4df <process_execute_failed_tail+0x4df> */
	X86_SIM_X86_JCC(X86_CC_S, 0x519, 0x4df, x86_l_4df);
x86_l_51b:
	/* 0x51b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_51d:
	/* 0x51d: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_521:
	/* 0x521: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_524:
	/* 0x524: jns    4eb <process_execute_failed_tail+0x4eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x524, 0x4eb, x86_l_4eb);
x86_l_526:
	/* 0x526: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_529:
	/* 0x529: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_52c:
	/* 0x52c: je     5ae <process_execute_failed_tail+0x5ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52c, 0x5ae, x86_l_5ae);
x86_l_532:
	/* 0x532: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_535:
	/* 0x535: je     5ae <process_execute_failed_tail+0x5ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x535, 0x5ae, x86_l_5ae);
x86_l_537:
	/* 0x537: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53b:
	/* 0x53b: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53e:
	/* 0x53e: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_544:
	/* 0x544: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_547:
	/* 0x547: jns    550 <process_execute_failed_tail+0x550> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x547, 0x550, x86_l_550);
x86_l_549:
	/* 0x549: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54c:
	/* 0x54c: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_550:
	/* 0x550: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_554:
	/* 0x554: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_557:
	/* 0x557: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_55e:
	/* 0x55e: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_560:
	/* 0x560: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_563:
	/* 0x563: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x563, 0x17ed, x86_l_17ed);
x86_l_569:
	/* 0x569: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_56c:
	/* 0x56c: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56c, 0xab7, x86_l_ab7);
x86_l_572:
	/* 0x572: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_578:
	/* 0x578: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_57b:
	/* 0x57b: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_57e:
	/* 0x57e: jns    7e3 <process_execute_failed_tail+0x7e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x57e, 0x7e3, x86_l_7e3);
x86_l_584:
	/* 0x584: mov    QWORD PTR [rsp+0x8],r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_589:
	/* 0x589: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_58d:
	/* 0x58d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_590:
	/* 0x590: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_593:
	/* 0x593: je     607 <process_execute_failed_tail+0x607> */
	X86_SIM_X86_JCC(X86_CC_E, 0x593, 0x607, x86_l_607);
x86_l_595:
	/* 0x595: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_599:
	/* 0x599: movzx  edx,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_59e:
	/* 0x59e: mov    BYTE PTR [rdi+r15*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_5a2:
	/* 0x5a2: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5a5:
	/* 0x5a5: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_5a7:
	/* 0x5a7: jne    590 <process_execute_failed_tail+0x590> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5a7, 0x590, x86_l_590);
x86_l_5a9:
	/* 0x5a9: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_5ac:
	/* 0x5ac: jmp    60c <process_execute_failed_tail+0x60c> */
	X86_SIM_X86_JMP(0x5ac, 0x60c, x86_l_60c);
x86_l_5ae:
	/* 0x5ae: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_5b1:
	/* 0x5b1: jne    ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5b1, 0xab7, x86_l_ab7);
x86_l_5b7:
	/* 0x5b7: cmp    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_5ba:
	/* 0x5ba: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ba, 0xab7, x86_l_ab7);
x86_l_5c0:
	/* 0x5c0: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c4:
	/* 0x5c4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5c7:
	/* 0x5c7: jns    5ce <process_execute_failed_tail+0x5ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5c7, 0x5ce, x86_l_5ce);
x86_l_5c9:
	/* 0x5c9: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5cc:
	/* 0x5cc: jmp    5d0 <process_execute_failed_tail+0x5d0> */
	X86_SIM_X86_JMP(0x5cc, 0x5d0, x86_l_5d0);
x86_l_5ce:
	/* 0x5ce: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5d0:
	/* 0x5d0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5d3:
	/* 0x5d3: jns    5da <process_execute_failed_tail+0x5da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5d3, 0x5da, x86_l_5da);
x86_l_5d5:
	/* 0x5d5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d8:
	/* 0x5d8: jmp    5dc <process_execute_failed_tail+0x5dc> */
	X86_SIM_X86_JMP(0x5d8, 0x5dc, x86_l_5dc);
x86_l_5da:
	/* 0x5da: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5dc:
	/* 0x5dc: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5df:
	/* 0x5df: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5e2:
	/* 0x5e2: jns    5e9 <process_execute_failed_tail+0x5e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5e2, 0x5e9, x86_l_5e9);
x86_l_5e4:
	/* 0x5e4: mov    r11,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e7:
	/* 0x5e7: jmp    5ec <process_execute_failed_tail+0x5ec> */
	X86_SIM_X86_JMP(0x5e7, 0x5ec, x86_l_5ec);
x86_l_5e9:
	/* 0x5e9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ec:
	/* 0x5ec: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f0:
	/* 0x5f0: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_5f3:
	/* 0x5f3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_5f6:
	/* 0x5f6: jns    633 <process_execute_failed_tail+0x633> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5f6, 0x633, x86_l_633);
x86_l_5f8:
	/* 0x5f8: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5fb:
	/* 0x5fb: jmp    635 <process_execute_failed_tail+0x635> */
	X86_SIM_X86_JMP(0x5fb, 0x635, x86_l_635);
x86_l_5fd:
	/* 0x5fd: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_602:
	/* 0x602: jmp    1ed1 <process_execute_failed_tail+0x1ed1> */
	X86_SIM_X86_JMP(0x602, 0x1ed1, x86_l_1ed1);
x86_l_607:
	/* 0x607: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_60c:
	/* 0x60c: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_610:
	/* 0x610: mov    r11,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_615:
	/* 0x615: jl     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x615, 0xab7, x86_l_ab7);
x86_l_61b:
	/* 0x61b: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_61e:
	/* 0x61e: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_624:
	/* 0x624: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_628:
	/* 0x628: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_62b:
	/* 0x62b: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_62e:
	/* 0x62e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_631:
	/* 0x631: js     5f8 <process_execute_failed_tail+0x5f8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x631, 0x5f8, x86_l_5f8);
x86_l_633:
	/* 0x633: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_635:
	/* 0x635: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_639:
	/* 0x639: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_63c:
	/* 0x63c: jns    643 <process_execute_failed_tail+0x643> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x63c, 0x643, x86_l_643);
x86_l_63e:
	/* 0x63e: mov    rbx,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_641:
	/* 0x641: jmp    645 <process_execute_failed_tail+0x645> */
	X86_SIM_X86_JMP(0x641, 0x645, x86_l_645);
x86_l_643:
	/* 0x643: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_645:
	/* 0x645: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_648:
	/* 0x648: je     6ca <process_execute_failed_tail+0x6ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x648, 0x6ca, x86_l_6ca);
x86_l_64e:
	/* 0x64e: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_651:
	/* 0x651: je     6ca <process_execute_failed_tail+0x6ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x651, 0x6ca, x86_l_6ca);
x86_l_653:
	/* 0x653: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_657:
	/* 0x657: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_65a:
	/* 0x65a: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_660:
	/* 0x660: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_663:
	/* 0x663: jns    66c <process_execute_failed_tail+0x66c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x663, 0x66c, x86_l_66c);
x86_l_665:
	/* 0x665: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_668:
	/* 0x668: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_66c:
	/* 0x66c: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_670:
	/* 0x670: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_673:
	/* 0x673: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_67a:
	/* 0x67a: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_67c:
	/* 0x67c: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_67f:
	/* 0x67f: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x67f, 0x17ed, x86_l_17ed);
x86_l_685:
	/* 0x685: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_688:
	/* 0x688: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x688, 0x7fa, x86_l_7fa);
x86_l_68e:
	/* 0x68e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_694:
	/* 0x694: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_697:
	/* 0x697: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_69a:
	/* 0x69a: jns    983 <process_execute_failed_tail+0x983> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x69a, 0x983, x86_l_983);
x86_l_6a0:
	/* 0x6a0: mov    QWORD PTR [rsp+0x8],r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6a5:
	/* 0x6a5: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_6a9:
	/* 0x6a9: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ac:
	/* 0x6ac: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6af:
	/* 0x6af: je     719 <process_execute_failed_tail+0x719> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6af, 0x719, x86_l_719);
x86_l_6b1:
	/* 0x6b1: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_6b5:
	/* 0x6b5: movzx  edx,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_6ba:
	/* 0x6ba: mov    BYTE PTR [rdi+r15*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_6be:
	/* 0x6be: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6c1:
	/* 0x6c1: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_6c3:
	/* 0x6c3: jne    6ac <process_execute_failed_tail+0x6ac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6c3, 0x6ac, x86_l_6ac);
x86_l_6c5:
	/* 0x6c5: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_6c8:
	/* 0x6c8: jmp    71e <process_execute_failed_tail+0x71e> */
	X86_SIM_X86_JMP(0x6c8, 0x71e, x86_l_71e);
x86_l_6ca:
	/* 0x6ca: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_6cd:
	/* 0x6cd: jne    7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6cd, 0x7fa, x86_l_7fa);
x86_l_6d3:
	/* 0x6d3: cmp    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_6d6:
	/* 0x6d6: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d6, 0x7fa, x86_l_7fa);
x86_l_6dc:
	/* 0x6dc: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e0:
	/* 0x6e0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_6e3:
	/* 0x6e3: jns    6ea <process_execute_failed_tail+0x6ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6e3, 0x6ea, x86_l_6ea);
x86_l_6e5:
	/* 0x6e5: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e8:
	/* 0x6e8: jmp    6ec <process_execute_failed_tail+0x6ec> */
	X86_SIM_X86_JMP(0x6e8, 0x6ec, x86_l_6ec);
x86_l_6ea:
	/* 0x6ea: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ec:
	/* 0x6ec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ef:
	/* 0x6ef: jns    6f6 <process_execute_failed_tail+0x6f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6ef, 0x6f6, x86_l_6f6);
x86_l_6f1:
	/* 0x6f1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f4:
	/* 0x6f4: jmp    6f8 <process_execute_failed_tail+0x6f8> */
	X86_SIM_X86_JMP(0x6f4, 0x6f8, x86_l_6f8);
x86_l_6f6:
	/* 0x6f6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f8:
	/* 0x6f8: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6fb:
	/* 0x6fb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_6fe:
	/* 0x6fe: jns    705 <process_execute_failed_tail+0x705> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6fe, 0x705, x86_l_705);
x86_l_700:
	/* 0x700: mov    r11,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_703:
	/* 0x703: jmp    708 <process_execute_failed_tail+0x708> */
	X86_SIM_X86_JMP(0x703, 0x708, x86_l_708);
x86_l_705:
	/* 0x705: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_708:
	/* 0x708: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_70c:
	/* 0x70c: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_70f:
	/* 0x70f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_712:
	/* 0x712: jns    745 <process_execute_failed_tail+0x745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x712, 0x745, x86_l_745);
x86_l_714:
	/* 0x714: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_717:
	/* 0x717: jmp    747 <process_execute_failed_tail+0x747> */
	X86_SIM_X86_JMP(0x717, 0x747, x86_l_747);
x86_l_719:
	/* 0x719: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_71e:
	/* 0x71e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_722:
	/* 0x722: mov    r11,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_727:
	/* 0x727: jl     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_L, 0x727, 0x7fa, x86_l_7fa);
x86_l_72d:
	/* 0x72d: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_730:
	/* 0x730: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_736:
	/* 0x736: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_73a:
	/* 0x73a: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_73d:
	/* 0x73d: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_740:
	/* 0x740: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_743:
	/* 0x743: js     714 <process_execute_failed_tail+0x714> */
	X86_SIM_X86_JCC(X86_CC_S, 0x743, 0x714, x86_l_714);
x86_l_745:
	/* 0x745: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_747:
	/* 0x747: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_74b:
	/* 0x74b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_74e:
	/* 0x74e: jns    755 <process_execute_failed_tail+0x755> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x74e, 0x755, x86_l_755);
x86_l_750:
	/* 0x750: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_753:
	/* 0x753: jmp    757 <process_execute_failed_tail+0x757> */
	X86_SIM_X86_JMP(0x753, 0x757, x86_l_757);
x86_l_755:
	/* 0x755: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_757:
	/* 0x757: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_75a:
	/* 0x75a: je     871 <process_execute_failed_tail+0x871> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75a, 0x871, x86_l_871);
x86_l_760:
	/* 0x760: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_763:
	/* 0x763: je     871 <process_execute_failed_tail+0x871> */
	X86_SIM_X86_JCC(X86_CC_E, 0x763, 0x871, x86_l_871);
x86_l_769:
	/* 0x769: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76d:
	/* 0x76d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_770:
	/* 0x770: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_776:
	/* 0x776: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_779:
	/* 0x779: jns    782 <process_execute_failed_tail+0x782> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x779, 0x782, x86_l_782);
x86_l_77b:
	/* 0x77b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_77e:
	/* 0x77e: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_782:
	/* 0x782: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_786:
	/* 0x786: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_789:
	/* 0x789: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_790:
	/* 0x790: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_792:
	/* 0x792: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_795:
	/* 0x795: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x795, 0x17ed, x86_l_17ed);
x86_l_79b:
	/* 0x79b: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_79e:
	/* 0x79e: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x79e, 0xab7, x86_l_ab7);
x86_l_7a4:
	/* 0x7a4: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_7aa:
	/* 0x7aa: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7ad:
	/* 0x7ad: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_7b0:
	/* 0x7b0: jns    7e3 <process_execute_failed_tail+0x7e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7b0, 0x7e3, x86_l_7e3);
x86_l_7b2:
	/* 0x7b2: mov    QWORD PTR [rsp+0x8],r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7b7:
	/* 0x7b7: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_7bb:
	/* 0x7bb: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7be:
	/* 0x7be: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7c1:
	/* 0x7c1: je     8c0 <process_execute_failed_tail+0x8c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c1, 0x8c0, x86_l_8c0);
x86_l_7c7:
	/* 0x7c7: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_7cb:
	/* 0x7cb: movzx  edx,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_7d0:
	/* 0x7d0: mov    BYTE PTR [rdi+r15*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_7d4:
	/* 0x7d4: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_7d7:
	/* 0x7d7: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_7d9:
	/* 0x7d9: jne    7be <process_execute_failed_tail+0x7be> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7d9, 0x7be, x86_l_7be);
x86_l_7db:
	/* 0x7db: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_7de:
	/* 0x7de: jmp    8c5 <process_execute_failed_tail+0x8c5> */
	X86_SIM_X86_JMP(0x7de, 0x8c5, x86_l_8c5);
x86_l_7e3:
	/* 0x7e3: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7e8:
	/* 0x7e8: mov    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_7eb:
	/* 0x7eb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ed:
	/* 0x7ed: call   7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_7f2:
	/* 0x7f2: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7f5:
	/* 0x7f5: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7fa:
	/* 0x7fa: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_7fd:
	/* 0x7fd: cmp    ebp,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_803:
	/* 0x803: jne    17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x803, 0x17ed, x86_l_17ed);
x86_l_809:
	/* 0x809: add    rbx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_80d:
	/* 0x80d: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_810:
	/* 0x810: jns    83a <process_execute_failed_tail+0x83a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x810, 0x83a, x86_l_83a);
x86_l_812:
	/* 0x812: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_815:
	/* 0x815: mov    rcx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_819:
	/* 0x819: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_81c:
	/* 0x81c: js     841 <process_execute_failed_tail+0x841> */
	X86_SIM_X86_JCC(X86_CC_S, 0x81c, 0x841, x86_l_841);
x86_l_81e:
	/* 0x81e: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_820:
	/* 0x820: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_825:
	/* 0x825: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_828:
	/* 0x828: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82a:
	/* 0x82a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_82d:
	/* 0x82d: call   832 <process_execute_failed_tail+0x832> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_832:
	/* 0x832: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_835:
	/* 0x835: jmp    1802 <process_execute_failed_tail+0x1802> */
	X86_SIM_X86_JMP(0x835, 0x1802, x86_l_1802);
x86_l_83a:
	/* 0x83a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_83c:
	/* 0x83c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_83f:
	/* 0x83f: jns    81e <process_execute_failed_tail+0x81e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83f, 0x81e, x86_l_81e);
x86_l_841:
	/* 0x841: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_843:
	/* 0x843: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_845:
	/* 0x845: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_84c:
	/* 0x84c: je     863 <process_execute_failed_tail+0x863> */
	X86_SIM_X86_JCC(X86_CC_E, 0x84c, 0x863, x86_l_863);
x86_l_84e:
	/* 0x84e: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_852:
	/* 0x852: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_856:
	/* 0x856: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_859:
	/* 0x859: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_85c:
	/* 0x85c: jne    845 <process_execute_failed_tail+0x845> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x85c, 0x845, x86_l_845);
x86_l_85e:
	/* 0x85e: jmp    1802 <process_execute_failed_tail+0x1802> */
	X86_SIM_X86_JMP(0x85e, 0x1802, x86_l_1802);
x86_l_863:
	/* 0x863: mov    BYTE PTR [rax+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_86a:
	/* 0x86a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_86c:
	/* 0x86c: jmp    1802 <process_execute_failed_tail+0x1802> */
	X86_SIM_X86_JMP(0x86c, 0x1802, x86_l_1802);
x86_l_871:
	/* 0x871: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_874:
	/* 0x874: jne    ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x874, 0xab7, x86_l_ab7);
x86_l_87a:
	/* 0x87a: cmp    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_87d:
	/* 0x87d: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x87d, 0xab7, x86_l_ab7);
x86_l_883:
	/* 0x883: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_887:
	/* 0x887: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_88a:
	/* 0x88a: jns    891 <process_execute_failed_tail+0x891> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x88a, 0x891, x86_l_891);
x86_l_88c:
	/* 0x88c: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_88f:
	/* 0x88f: jmp    893 <process_execute_failed_tail+0x893> */
	X86_SIM_X86_JMP(0x88f, 0x893, x86_l_893);
x86_l_891:
	/* 0x891: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_893:
	/* 0x893: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_896:
	/* 0x896: jns    89d <process_execute_failed_tail+0x89d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x896, 0x89d, x86_l_89d);
x86_l_898:
	/* 0x898: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_89b:
	/* 0x89b: jmp    89f <process_execute_failed_tail+0x89f> */
	X86_SIM_X86_JMP(0x89b, 0x89f, x86_l_89f);
x86_l_89d:
	/* 0x89d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_89f:
	/* 0x89f: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8a2:
	/* 0x8a2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_8a5:
	/* 0x8a5: jns    8ac <process_execute_failed_tail+0x8ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8a5, 0x8ac, x86_l_8ac);
x86_l_8a7:
	/* 0x8a7: mov    r11,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8aa:
	/* 0x8aa: jmp    8af <process_execute_failed_tail+0x8af> */
	X86_SIM_X86_JMP(0x8aa, 0x8af, x86_l_8af);
x86_l_8ac:
	/* 0x8ac: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8af:
	/* 0x8af: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8b3:
	/* 0x8b3: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_8b6:
	/* 0x8b6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8b9:
	/* 0x8b9: jns    8ec <process_execute_failed_tail+0x8ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8b9, 0x8ec, x86_l_8ec);
x86_l_8bb:
	/* 0x8bb: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8be:
	/* 0x8be: jmp    8ee <process_execute_failed_tail+0x8ee> */
	X86_SIM_X86_JMP(0x8be, 0x8ee, x86_l_8ee);
x86_l_8c0:
	/* 0x8c0: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_8c5:
	/* 0x8c5: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_8c9:
	/* 0x8c9: mov    r11,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8ce:
	/* 0x8ce: jl     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x8ce, 0xab7, x86_l_ab7);
x86_l_8d4:
	/* 0x8d4: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_8d7:
	/* 0x8d7: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_8dd:
	/* 0x8dd: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_8e1:
	/* 0x8e1: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_8e4:
	/* 0x8e4: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_8e7:
	/* 0x8e7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8ea:
	/* 0x8ea: js     8bb <process_execute_failed_tail+0x8bb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8ea, 0x8bb, x86_l_8bb);
x86_l_8ec:
	/* 0x8ec: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8ee:
	/* 0x8ee: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f2:
	/* 0x8f2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_8f5:
	/* 0x8f5: jns    8fc <process_execute_failed_tail+0x8fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8f5, 0x8fc, x86_l_8fc);
x86_l_8f7:
	/* 0x8f7: mov    rbx,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8fa:
	/* 0x8fa: jmp    8fe <process_execute_failed_tail+0x8fe> */
	X86_SIM_X86_JMP(0x8fa, 0x8fe, x86_l_8fe);
x86_l_8fc:
	/* 0x8fc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8fe:
	/* 0x8fe: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_901:
	/* 0x901: je     990 <process_execute_failed_tail+0x990> */
	X86_SIM_X86_JCC(X86_CC_E, 0x901, 0x990, x86_l_990);
x86_l_907:
	/* 0x907: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_90a:
	/* 0x90a: je     990 <process_execute_failed_tail+0x990> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90a, 0x990, x86_l_990);
x86_l_910:
	/* 0x910: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_914:
	/* 0x914: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_917:
	/* 0x917: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_91d:
	/* 0x91d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_920:
	/* 0x920: jns    929 <process_execute_failed_tail+0x929> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x920, 0x929, x86_l_929);
x86_l_922:
	/* 0x922: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_925:
	/* 0x925: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_929:
	/* 0x929: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_92d:
	/* 0x92d: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_930:
	/* 0x930: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_937:
	/* 0x937: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_939:
	/* 0x939: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_93c:
	/* 0x93c: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0x93c, 0x17ed, x86_l_17ed);
x86_l_942:
	/* 0x942: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_945:
	/* 0x945: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x945, 0x7fa, x86_l_7fa);
x86_l_94b:
	/* 0x94b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_951:
	/* 0x951: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_954:
	/* 0x954: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_957:
	/* 0x957: jns    983 <process_execute_failed_tail+0x983> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x957, 0x983, x86_l_983);
x86_l_959:
	/* 0x959: mov    QWORD PTR [rsp+0x8],r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_95e:
	/* 0x95e: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_962:
	/* 0x962: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_965:
	/* 0x965: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_968:
	/* 0x968: je     9df <process_execute_failed_tail+0x9df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x968, 0x9df, x86_l_9df);
x86_l_96a:
	/* 0x96a: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_96e:
	/* 0x96e: movzx  edx,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_973:
	/* 0x973: mov    BYTE PTR [rdi+r15*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_977:
	/* 0x977: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_97a:
	/* 0x97a: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_97c:
	/* 0x97c: jne    965 <process_execute_failed_tail+0x965> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x97c, 0x965, x86_l_965);
x86_l_97e:
	/* 0x97e: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_981:
	/* 0x981: jmp    9e4 <process_execute_failed_tail+0x9e4> */
	X86_SIM_X86_JMP(0x981, 0x9e4, x86_l_9e4);
x86_l_983:
	/* 0x983: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_988:
	/* 0x988: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_98b:
	/* 0x98b: jmp    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JMP(0x98b, 0x7e8, x86_l_7e8);
x86_l_990:
	/* 0x990: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_993:
	/* 0x993: jne    7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x993, 0x7fa, x86_l_7fa);
x86_l_999:
	/* 0x999: cmp    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_99c:
	/* 0x99c: je     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99c, 0x7fa, x86_l_7fa);
x86_l_9a2:
	/* 0x9a2: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9a6:
	/* 0x9a6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9a9:
	/* 0x9a9: jns    9b0 <process_execute_failed_tail+0x9b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9a9, 0x9b0, x86_l_9b0);
x86_l_9ab:
	/* 0x9ab: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9ae:
	/* 0x9ae: jmp    9b2 <process_execute_failed_tail+0x9b2> */
	X86_SIM_X86_JMP(0x9ae, 0x9b2, x86_l_9b2);
x86_l_9b0:
	/* 0x9b0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9b2:
	/* 0x9b2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9b5:
	/* 0x9b5: jns    9bc <process_execute_failed_tail+0x9bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9b5, 0x9bc, x86_l_9bc);
x86_l_9b7:
	/* 0x9b7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9ba:
	/* 0x9ba: jmp    9be <process_execute_failed_tail+0x9be> */
	X86_SIM_X86_JMP(0x9ba, 0x9be, x86_l_9be);
x86_l_9bc:
	/* 0x9bc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9be:
	/* 0x9be: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9c1:
	/* 0x9c1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9c4:
	/* 0x9c4: jns    9cb <process_execute_failed_tail+0x9cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9c4, 0x9cb, x86_l_9cb);
x86_l_9c6:
	/* 0x9c6: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9c9:
	/* 0x9c9: jmp    9ce <process_execute_failed_tail+0x9ce> */
	X86_SIM_X86_JMP(0x9c9, 0x9ce, x86_l_9ce);
x86_l_9cb:
	/* 0x9cb: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9ce:
	/* 0x9ce: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d2:
	/* 0x9d2: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_9d5:
	/* 0x9d5: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_9d8:
	/* 0x9d8: jns    a0b <process_execute_failed_tail+0xa0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9d8, 0xa0b, x86_l_a0b);
x86_l_9da:
	/* 0x9da: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9dd:
	/* 0x9dd: jmp    a0d <process_execute_failed_tail+0xa0d> */
	X86_SIM_X86_JMP(0x9dd, 0xa0d, x86_l_a0d);
x86_l_9df:
	/* 0x9df: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_9e4:
	/* 0x9e4: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_9e8:
	/* 0x9e8: jl     7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_L, 0x9e8, 0x7fa, x86_l_7fa);
x86_l_9ee:
	/* 0x9ee: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_9f1:
	/* 0x9f1: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_9f7:
	/* 0x9f7: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_9fb:
	/* 0x9fb: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_9fe:
	/* 0x9fe: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a03:
	/* 0xa03: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_a06:
	/* 0xa06: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_a09:
	/* 0xa09: js     9da <process_execute_failed_tail+0x9da> */
	X86_SIM_X86_JCC(X86_CC_S, 0xa09, 0x9da, x86_l_9da);
x86_l_a0b:
	/* 0xa0b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a0d:
	/* 0xa0d: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a11:
	/* 0xa11: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_a14:
	/* 0xa14: jns    a1b <process_execute_failed_tail+0xa1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa14, 0xa1b, x86_l_a1b);
x86_l_a16:
	/* 0xa16: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a19:
	/* 0xa19: jmp    a1d <process_execute_failed_tail+0xa1d> */
	X86_SIM_X86_JMP(0xa19, 0xa1d, x86_l_a1d);
x86_l_a1b:
	/* 0xa1b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a1d:
	/* 0xa1d: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a20:
	/* 0xa20: je     a9a <process_execute_failed_tail+0xa9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa20, 0xa9a, x86_l_a9a);
x86_l_a22:
	/* 0xa22: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_a25:
	/* 0xa25: je     a9a <process_execute_failed_tail+0xa9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa25, 0xa9a, x86_l_a9a);
x86_l_a27:
	/* 0xa27: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a2b:
	/* 0xa2b: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a2e:
	/* 0xa2e: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_a34:
	/* 0xa34: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a37:
	/* 0xa37: jns    a40 <process_execute_failed_tail+0xa40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa37, 0xa40, x86_l_a40);
x86_l_a39:
	/* 0xa39: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a3c:
	/* 0xa3c: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a40:
	/* 0xa40: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_a44:
	/* 0xa44: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_a47:
	/* 0xa47: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a4e:
	/* 0xa4e: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a50:
	/* 0xa50: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_a53:
	/* 0xa53: jb     17ed <process_execute_failed_tail+0x17ed> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa53, 0x17ed, x86_l_17ed);
x86_l_a59:
	/* 0xa59: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_a5c:
	/* 0xa5c: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5c, 0xab7, x86_l_ab7);
x86_l_a5e:
	/* 0xa5e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_a64:
	/* 0xa64: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a69:
	/* 0xa69: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a6c:
	/* 0xa6c: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_a6f:
	/* 0xa6f: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa6f, 0x7e8, x86_l_7e8);
x86_l_a75:
	/* 0xa75: lea    eax,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_a79:
	/* 0xa79: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a7c:
	/* 0xa7c: cmp    rax,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_a7f:
	/* 0xa7f: je     aee <process_execute_failed_tail+0xaee> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7f, 0xaee, x86_l_aee);
x86_l_a81:
	/* 0xa81: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_a85:
	/* 0xa85: movzx  edx,BYTE PTR [r10+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_a8a:
	/* 0xa8a: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_a8e:
	/* 0xa8e: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a91:
	/* 0xa91: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_a93:
	/* 0xa93: jne    a7c <process_execute_failed_tail+0xa7c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa93, 0xa7c, x86_l_a7c);
x86_l_a95:
	/* 0xa95: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_a98:
	/* 0xa98: jmp    af2 <process_execute_failed_tail+0xaf2> */
	X86_SIM_X86_JMP(0xa98, 0xaf2, x86_l_af2);
x86_l_a9a:
	/* 0xa9a: cmp    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a9d:
	/* 0xa9d: jne    ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa9d, 0xab7, x86_l_ab7);
x86_l_a9f:
	/* 0xa9f: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_aa2:
	/* 0xaa2: je     ab7 <process_execute_failed_tail+0xab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaa2, 0xab7, x86_l_ab7);
x86_l_aa4:
	/* 0xaa4: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aa9:
	/* 0xaa9: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aad:
	/* 0xaad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ab0:
	/* 0xab0: jns    abf <process_execute_failed_tail+0xabf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xab0, 0xabf, x86_l_abf);
x86_l_ab2:
	/* 0xab2: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ab5:
	/* 0xab5: jmp    ac1 <process_execute_failed_tail+0xac1> */
	X86_SIM_X86_JMP(0xab5, 0xac1, x86_l_ac1);
x86_l_ab7:
	/* 0xab7: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_aba:
	/* 0xaba: jmp    7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JMP(0xaba, 0x7fa, x86_l_7fa);
x86_l_abf:
	/* 0xabf: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac1:
	/* 0xac1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ac4:
	/* 0xac4: jns    acb <process_execute_failed_tail+0xacb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xac4, 0xacb, x86_l_acb);
x86_l_ac6:
	/* 0xac6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ac9:
	/* 0xac9: jmp    acd <process_execute_failed_tail+0xacd> */
	X86_SIM_X86_JMP(0xac9, 0xacd, x86_l_acd);
x86_l_acb:
	/* 0xacb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_acd:
	/* 0xacd: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ad0:
	/* 0xad0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad3:
	/* 0xad3: jns    ada <process_execute_failed_tail+0xada> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xad3, 0xada, x86_l_ada);
x86_l_ad5:
	/* 0xad5: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ad8:
	/* 0xad8: jmp    add <process_execute_failed_tail+0xadd> */
	X86_SIM_X86_JMP(0xad8, 0xadd, x86_l_add);
x86_l_ada:
	/* 0xada: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_add:
	/* 0xadd: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ae1:
	/* 0xae1: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_ae4:
	/* 0xae4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae7:
	/* 0xae7: jns    b19 <process_execute_failed_tail+0xb19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xae7, 0xb19, x86_l_b19);
x86_l_ae9:
	/* 0xae9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aec:
	/* 0xaec: jmp    b1b <process_execute_failed_tail+0xb1b> */
	X86_SIM_X86_JMP(0xaec, 0xb1b, x86_l_b1b);
x86_l_aee:
	/* 0xaee: mov    BYTE PTR [rdi+rax*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_af2:
	/* 0xaf2: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_af6:
	/* 0xaf6: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0xaf6, 0x7f2, x86_l_7f2);
x86_l_afc:
	/* 0xafc: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_aff:
	/* 0xaff: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_b05:
	/* 0xb05: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b0a:
	/* 0xb0a: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_b0e:
	/* 0xb0e: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_b11:
	/* 0xb11: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_b14:
	/* 0xb14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b17:
	/* 0xb17: js     ae9 <process_execute_failed_tail+0xae9> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb17, 0xae9, x86_l_ae9);
x86_l_b19:
	/* 0xb19: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b1b:
	/* 0xb1b: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b1f:
	/* 0xb1f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_b22:
	/* 0xb22: jns    b29 <process_execute_failed_tail+0xb29> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb22, 0xb29, x86_l_b29);
x86_l_b24:
	/* 0xb24: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b27:
	/* 0xb27: jmp    b2b <process_execute_failed_tail+0xb2b> */
	X86_SIM_X86_JMP(0xb27, 0xb2b, x86_l_b2b);
x86_l_b29:
	/* 0xb29: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b2b:
	/* 0xb2b: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b2e:
	/* 0xb2e: je     ba8 <process_execute_failed_tail+0xba8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2e, 0xba8, x86_l_ba8);
x86_l_b30:
	/* 0xb30: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b33:
	/* 0xb33: je     ba8 <process_execute_failed_tail+0xba8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb33, 0xba8, x86_l_ba8);
x86_l_b35:
	/* 0xb35: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b39:
	/* 0xb39: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b3c:
	/* 0xb3c: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_b41:
	/* 0xb41: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_b44:
	/* 0xb44: jns    b4d <process_execute_failed_tail+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb44, 0xb4d, x86_l_b4d);
x86_l_b46:
	/* 0xb46: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b49:
	/* 0xb49: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b4d:
	/* 0xb4d: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_b51:
	/* 0xb51: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_b54:
	/* 0xb54: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_b5b:
	/* 0xb5b: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b5d:
	/* 0xb5d: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_b60:
	/* 0xb60: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb60, 0x17e8, x86_l_17e8);
x86_l_b66:
	/* 0xb66: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_b69:
	/* 0xb69: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb69, 0x7f5, x86_l_7f5);
x86_l_b6f:
	/* 0xb6f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_b75:
	/* 0xb75: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_b7a:
	/* 0xb7a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b7d:
	/* 0xb7d: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb7d, 0x160c, x86_l_160c);
x86_l_b83:
	/* 0xb83: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_b87:
	/* 0xb87: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b8a:
	/* 0xb8a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_b8d:
	/* 0xb8d: je     bf7 <process_execute_failed_tail+0xbf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8d, 0xbf7, x86_l_bf7);
x86_l_b8f:
	/* 0xb8f: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_b93:
	/* 0xb93: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_b98:
	/* 0xb98: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_b9c:
	/* 0xb9c: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b9f:
	/* 0xb9f: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_ba1:
	/* 0xba1: jne    b8a <process_execute_failed_tail+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xba1, 0xb8a, x86_l_b8a);
x86_l_ba3:
	/* 0xba3: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_ba6:
	/* 0xba6: jmp    bfc <process_execute_failed_tail+0xbfc> */
	X86_SIM_X86_JMP(0xba6, 0xbfc, x86_l_bfc);
x86_l_ba8:
	/* 0xba8: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bab:
	/* 0xbab: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbab, 0x7f5, x86_l_7f5);
x86_l_bb1:
	/* 0xbb1: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_bb4:
	/* 0xbb4: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb4, 0x7f5, x86_l_7f5);
x86_l_bba:
	/* 0xbba: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bbe:
	/* 0xbbe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc1:
	/* 0xbc1: jns    bc8 <process_execute_failed_tail+0xbc8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbc1, 0xbc8, x86_l_bc8);
x86_l_bc3:
	/* 0xbc3: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bc6:
	/* 0xbc6: jmp    bca <process_execute_failed_tail+0xbca> */
	X86_SIM_X86_JMP(0xbc6, 0xbca, x86_l_bca);
x86_l_bc8:
	/* 0xbc8: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bca:
	/* 0xbca: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bcd:
	/* 0xbcd: jns    bd4 <process_execute_failed_tail+0xbd4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbcd, 0xbd4, x86_l_bd4);
x86_l_bcf:
	/* 0xbcf: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd2:
	/* 0xbd2: jmp    bd6 <process_execute_failed_tail+0xbd6> */
	X86_SIM_X86_JMP(0xbd2, 0xbd6, x86_l_bd6);
x86_l_bd4:
	/* 0xbd4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bd6:
	/* 0xbd6: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bd9:
	/* 0xbd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bdc:
	/* 0xbdc: jns    be3 <process_execute_failed_tail+0xbe3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbdc, 0xbe3, x86_l_be3);
x86_l_bde:
	/* 0xbde: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_be1:
	/* 0xbe1: jmp    be6 <process_execute_failed_tail+0xbe6> */
	X86_SIM_X86_JMP(0xbe1, 0xbe6, x86_l_be6);
x86_l_be3:
	/* 0xbe3: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_be6:
	/* 0xbe6: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bea:
	/* 0xbea: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_bed:
	/* 0xbed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bf0:
	/* 0xbf0: jns    c23 <process_execute_failed_tail+0xc23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbf0, 0xc23, x86_l_c23);
x86_l_bf2:
	/* 0xbf2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf5:
	/* 0xbf5: jmp    c25 <process_execute_failed_tail+0xc25> */
	X86_SIM_X86_JMP(0xbf5, 0xc25, x86_l_c25);
x86_l_bf7:
	/* 0xbf7: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_bfc:
	/* 0xbfc: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_c00:
	/* 0xc00: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0xc00, 0x7f5, x86_l_7f5);
x86_l_c06:
	/* 0xc06: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_c09:
	/* 0xc09: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_c0f:
	/* 0xc0f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c14:
	/* 0xc14: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_c18:
	/* 0xc18: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_c1b:
	/* 0xc1b: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_c1e:
	/* 0xc1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c21:
	/* 0xc21: js     bf2 <process_execute_failed_tail+0xbf2> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc21, 0xbf2, x86_l_bf2);
x86_l_c23:
	/* 0xc23: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c25:
	/* 0xc25: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c29:
	/* 0xc29: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c2c:
	/* 0xc2c: jns    c33 <process_execute_failed_tail+0xc33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc2c, 0xc33, x86_l_c33);
x86_l_c2e:
	/* 0xc2e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c31:
	/* 0xc31: jmp    c35 <process_execute_failed_tail+0xc35> */
	X86_SIM_X86_JMP(0xc31, 0xc35, x86_l_c35);
x86_l_c33:
	/* 0xc33: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c35:
	/* 0xc35: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c38:
	/* 0xc38: je     cb2 <process_execute_failed_tail+0xcb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc38, 0xcb2, x86_l_cb2);
x86_l_c3a:
	/* 0xc3a: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c3d:
	/* 0xc3d: je     cb2 <process_execute_failed_tail+0xcb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3d, 0xcb2, x86_l_cb2);
x86_l_c3f:
	/* 0xc3f: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c43:
	/* 0xc43: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c46:
	/* 0xc46: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_c4b:
	/* 0xc4b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_c4e:
	/* 0xc4e: jns    c57 <process_execute_failed_tail+0xc57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc4e, 0xc57, x86_l_c57);
x86_l_c50:
	/* 0xc50: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c53:
	/* 0xc53: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c57:
	/* 0xc57: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_c5b:
	/* 0xc5b: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_c5e:
	/* 0xc5e: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_c65:
	/* 0xc65: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_c67:
	/* 0xc67: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_c6a:
	/* 0xc6a: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0xc6a, 0x17e8, x86_l_17e8);
x86_l_c70:
	/* 0xc70: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_c73:
	/* 0xc73: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc73, 0x7f2, x86_l_7f2);
x86_l_c79:
	/* 0xc79: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_c7f:
	/* 0xc7f: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_c84:
	/* 0xc84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c87:
	/* 0xc87: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc87, 0x7e8, x86_l_7e8);
x86_l_c8d:
	/* 0xc8d: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_c91:
	/* 0xc91: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c94:
	/* 0xc94: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_c97:
	/* 0xc97: je     d01 <process_execute_failed_tail+0xd01> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc97, 0xd01, x86_l_d01);
x86_l_c99:
	/* 0xc99: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_c9d:
	/* 0xc9d: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_ca2:
	/* 0xca2: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_ca6:
	/* 0xca6: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ca9:
	/* 0xca9: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_cab:
	/* 0xcab: jne    c94 <process_execute_failed_tail+0xc94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcab, 0xc94, x86_l_c94);
x86_l_cad:
	/* 0xcad: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_cb0:
	/* 0xcb0: jmp    d06 <process_execute_failed_tail+0xd06> */
	X86_SIM_X86_JMP(0xcb0, 0xd06, x86_l_d06);
x86_l_cb2:
	/* 0xcb2: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cb5:
	/* 0xcb5: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcb5, 0x7f2, x86_l_7f2);
x86_l_cbb:
	/* 0xcbb: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cbe:
	/* 0xcbe: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcbe, 0x7f2, x86_l_7f2);
x86_l_cc4:
	/* 0xcc4: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cc8:
	/* 0xcc8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ccb:
	/* 0xccb: jns    cd2 <process_execute_failed_tail+0xcd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xccb, 0xcd2, x86_l_cd2);
x86_l_ccd:
	/* 0xccd: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd0:
	/* 0xcd0: jmp    cd4 <process_execute_failed_tail+0xcd4> */
	X86_SIM_X86_JMP(0xcd0, 0xcd4, x86_l_cd4);
x86_l_cd2:
	/* 0xcd2: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cd4:
	/* 0xcd4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cd7:
	/* 0xcd7: jns    cde <process_execute_failed_tail+0xcde> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd7, 0xcde, x86_l_cde);
x86_l_cd9:
	/* 0xcd9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cdc:
	/* 0xcdc: jmp    ce0 <process_execute_failed_tail+0xce0> */
	X86_SIM_X86_JMP(0xcdc, 0xce0, x86_l_ce0);
x86_l_cde:
	/* 0xcde: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ce0:
	/* 0xce0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ce3:
	/* 0xce3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce6:
	/* 0xce6: jns    ced <process_execute_failed_tail+0xced> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xce6, 0xced, x86_l_ced);
x86_l_ce8:
	/* 0xce8: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ceb:
	/* 0xceb: jmp    cf0 <process_execute_failed_tail+0xcf0> */
	X86_SIM_X86_JMP(0xceb, 0xcf0, x86_l_cf0);
x86_l_ced:
	/* 0xced: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf0:
	/* 0xcf0: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cf4:
	/* 0xcf4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_cf7:
	/* 0xcf7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cfa:
	/* 0xcfa: jns    d2d <process_execute_failed_tail+0xd2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcfa, 0xd2d, x86_l_d2d);
x86_l_cfc:
	/* 0xcfc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cff:
	/* 0xcff: jmp    d2f <process_execute_failed_tail+0xd2f> */
	X86_SIM_X86_JMP(0xcff, 0xd2f, x86_l_d2f);
x86_l_d01:
	/* 0xd01: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_d06:
	/* 0xd06: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_d0a:
	/* 0xd0a: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0xd0a, 0x7f2, x86_l_7f2);
x86_l_d10:
	/* 0xd10: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_d13:
	/* 0xd13: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_d19:
	/* 0xd19: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d1e:
	/* 0xd1e: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_d22:
	/* 0xd22: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_d25:
	/* 0xd25: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_d28:
	/* 0xd28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d2b:
	/* 0xd2b: js     cfc <process_execute_failed_tail+0xcfc> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd2b, 0xcfc, x86_l_cfc);
x86_l_d2d:
	/* 0xd2d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d2f:
	/* 0xd2f: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d33:
	/* 0xd33: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d36:
	/* 0xd36: jns    d3d <process_execute_failed_tail+0xd3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd36, 0xd3d, x86_l_d3d);
x86_l_d38:
	/* 0xd38: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3b:
	/* 0xd3b: jmp    d3f <process_execute_failed_tail+0xd3f> */
	X86_SIM_X86_JMP(0xd3b, 0xd3f, x86_l_d3f);
x86_l_d3d:
	/* 0xd3d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d3f:
	/* 0xd3f: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d42:
	/* 0xd42: je     dbc <process_execute_failed_tail+0xdbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd42, 0xdbc, x86_l_dbc);
x86_l_d44:
	/* 0xd44: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d47:
	/* 0xd47: je     dbc <process_execute_failed_tail+0xdbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd47, 0xdbc, x86_l_dbc);
x86_l_d49:
	/* 0xd49: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d4d:
	/* 0xd4d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d50:
	/* 0xd50: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_d55:
	/* 0xd55: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d58:
	/* 0xd58: jns    d61 <process_execute_failed_tail+0xd61> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd58, 0xd61, x86_l_d61);
x86_l_d5a:
	/* 0xd5a: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d5d:
	/* 0xd5d: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d61:
	/* 0xd61: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_d65:
	/* 0xd65: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d68:
	/* 0xd68: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_d6f:
	/* 0xd6f: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_d71:
	/* 0xd71: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_d74:
	/* 0xd74: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0xd74, 0x17e8, x86_l_17e8);
x86_l_d7a:
	/* 0xd7a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_d7d:
	/* 0xd7d: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7d, 0x7f5, x86_l_7f5);
x86_l_d83:
	/* 0xd83: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_d89:
	/* 0xd89: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_d8e:
	/* 0xd8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d91:
	/* 0xd91: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd91, 0x160c, x86_l_160c);
x86_l_d97:
	/* 0xd97: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_d9b:
	/* 0xd9b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d9e:
	/* 0xd9e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_da1:
	/* 0xda1: je     e0b <process_execute_failed_tail+0xe0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda1, 0xe0b, x86_l_e0b);
x86_l_da3:
	/* 0xda3: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_da7:
	/* 0xda7: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_dac:
	/* 0xdac: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_db0:
	/* 0xdb0: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_db3:
	/* 0xdb3: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_db5:
	/* 0xdb5: jne    d9e <process_execute_failed_tail+0xd9e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdb5, 0xd9e, x86_l_d9e);
x86_l_db7:
	/* 0xdb7: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_dba:
	/* 0xdba: jmp    e10 <process_execute_failed_tail+0xe10> */
	X86_SIM_X86_JMP(0xdba, 0xe10, x86_l_e10);
x86_l_dbc:
	/* 0xdbc: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dbf:
	/* 0xdbf: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdbf, 0x7f5, x86_l_7f5);
x86_l_dc5:
	/* 0xdc5: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_dc8:
	/* 0xdc8: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc8, 0x7f5, x86_l_7f5);
x86_l_dce:
	/* 0xdce: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dd2:
	/* 0xdd2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd5:
	/* 0xdd5: jns    ddc <process_execute_failed_tail+0xddc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdd5, 0xddc, x86_l_ddc);
x86_l_dd7:
	/* 0xdd7: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dda:
	/* 0xdda: jmp    dde <process_execute_failed_tail+0xdde> */
	X86_SIM_X86_JMP(0xdda, 0xdde, x86_l_dde);
x86_l_ddc:
	/* 0xddc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dde:
	/* 0xdde: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_de1:
	/* 0xde1: jns    de8 <process_execute_failed_tail+0xde8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde1, 0xde8, x86_l_de8);
x86_l_de3:
	/* 0xde3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de6:
	/* 0xde6: jmp    dea <process_execute_failed_tail+0xdea> */
	X86_SIM_X86_JMP(0xde6, 0xdea, x86_l_dea);
x86_l_de8:
	/* 0xde8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dea:
	/* 0xdea: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ded:
	/* 0xded: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_df0:
	/* 0xdf0: jns    df7 <process_execute_failed_tail+0xdf7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdf0, 0xdf7, x86_l_df7);
x86_l_df2:
	/* 0xdf2: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_df5:
	/* 0xdf5: jmp    dfa <process_execute_failed_tail+0xdfa> */
	X86_SIM_X86_JMP(0xdf5, 0xdfa, x86_l_dfa);
x86_l_df7:
	/* 0xdf7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dfa:
	/* 0xdfa: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dfe:
	/* 0xdfe: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e01:
	/* 0xe01: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e04:
	/* 0xe04: jns    e37 <process_execute_failed_tail+0xe37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe04, 0xe37, x86_l_e37);
x86_l_e06:
	/* 0xe06: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e09:
	/* 0xe09: jmp    e39 <process_execute_failed_tail+0xe39> */
	X86_SIM_X86_JMP(0xe09, 0xe39, x86_l_e39);
x86_l_e0b:
	/* 0xe0b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_e10:
	/* 0xe10: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e14:
	/* 0xe14: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0xe14, 0x7f5, x86_l_7f5);
x86_l_e1a:
	/* 0xe1a: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_e1d:
	/* 0xe1d: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_e23:
	/* 0xe23: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e28:
	/* 0xe28: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_e2c:
	/* 0xe2c: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e2f:
	/* 0xe2f: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e32:
	/* 0xe32: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e35:
	/* 0xe35: js     e06 <process_execute_failed_tail+0xe06> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe35, 0xe06, x86_l_e06);
x86_l_e37:
	/* 0xe37: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e39:
	/* 0xe39: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e3d:
	/* 0xe3d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e40:
	/* 0xe40: jns    e47 <process_execute_failed_tail+0xe47> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe40, 0xe47, x86_l_e47);
x86_l_e42:
	/* 0xe42: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e45:
	/* 0xe45: jmp    e49 <process_execute_failed_tail+0xe49> */
	X86_SIM_X86_JMP(0xe45, 0xe49, x86_l_e49);
x86_l_e47:
	/* 0xe47: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e49:
	/* 0xe49: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4c:
	/* 0xe4c: je     ec6 <process_execute_failed_tail+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4c, 0xec6, x86_l_ec6);
x86_l_e4e:
	/* 0xe4e: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e51:
	/* 0xe51: je     ec6 <process_execute_failed_tail+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe51, 0xec6, x86_l_ec6);
x86_l_e53:
	/* 0xe53: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e57:
	/* 0xe57: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e5a:
	/* 0xe5a: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e5f:
	/* 0xe5f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e62:
	/* 0xe62: jns    e6b <process_execute_failed_tail+0xe6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe62, 0xe6b, x86_l_e6b);
x86_l_e64:
	/* 0xe64: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e67:
	/* 0xe67: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e6b:
	/* 0xe6b: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_e6f:
	/* 0xe6f: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_e72:
	/* 0xe72: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_e79:
	/* 0xe79: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_e7b:
	/* 0xe7b: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e7e:
	/* 0xe7e: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0xe7e, 0x17e8, x86_l_17e8);
x86_l_e84:
	/* 0xe84: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_e87:
	/* 0xe87: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe87, 0x7f2, x86_l_7f2);
x86_l_e8d:
	/* 0xe8d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_e93:
	/* 0xe93: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_e98:
	/* 0xe98: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e9b:
	/* 0xe9b: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe9b, 0x7e8, x86_l_7e8);
x86_l_ea1:
	/* 0xea1: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ea5:
	/* 0xea5: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ea8:
	/* 0xea8: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_eab:
	/* 0xeab: je     f15 <process_execute_failed_tail+0xf15> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeab, 0xf15, x86_l_f15);
x86_l_ead:
	/* 0xead: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_eb1:
	/* 0xeb1: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_eb6:
	/* 0xeb6: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_eba:
	/* 0xeba: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ebd:
	/* 0xebd: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_ebf:
	/* 0xebf: jne    ea8 <process_execute_failed_tail+0xea8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xebf, 0xea8, x86_l_ea8);
x86_l_ec1:
	/* 0xec1: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_ec4:
	/* 0xec4: jmp    f1a <process_execute_failed_tail+0xf1a> */
	X86_SIM_X86_JMP(0xec4, 0xf1a, x86_l_f1a);
x86_l_ec6:
	/* 0xec6: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ec9:
	/* 0xec9: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xec9, 0x7f2, x86_l_7f2);
x86_l_ecf:
	/* 0xecf: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ed2:
	/* 0xed2: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed2, 0x7f2, x86_l_7f2);
x86_l_ed8:
	/* 0xed8: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_edc:
	/* 0xedc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_edf:
	/* 0xedf: jns    ee6 <process_execute_failed_tail+0xee6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xedf, 0xee6, x86_l_ee6);
x86_l_ee1:
	/* 0xee1: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee4:
	/* 0xee4: jmp    ee8 <process_execute_failed_tail+0xee8> */
	X86_SIM_X86_JMP(0xee4, 0xee8, x86_l_ee8);
x86_l_ee6:
	/* 0xee6: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ee8:
	/* 0xee8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_eeb:
	/* 0xeeb: jns    ef2 <process_execute_failed_tail+0xef2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeeb, 0xef2, x86_l_ef2);
x86_l_eed:
	/* 0xeed: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef0:
	/* 0xef0: jmp    ef4 <process_execute_failed_tail+0xef4> */
	X86_SIM_X86_JMP(0xef0, 0xef4, x86_l_ef4);
x86_l_ef2:
	/* 0xef2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef4:
	/* 0xef4: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ef7:
	/* 0xef7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_efa:
	/* 0xefa: jns    f01 <process_execute_failed_tail+0xf01> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xefa, 0xf01, x86_l_f01);
x86_l_efc:
	/* 0xefc: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eff:
	/* 0xeff: jmp    f04 <process_execute_failed_tail+0xf04> */
	X86_SIM_X86_JMP(0xeff, 0xf04, x86_l_f04);
x86_l_f01:
	/* 0xf01: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f04:
	/* 0xf04: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f08:
	/* 0xf08: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f0b:
	/* 0xf0b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f0e:
	/* 0xf0e: jns    f41 <process_execute_failed_tail+0xf41> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf0e, 0xf41, x86_l_f41);
x86_l_f10:
	/* 0xf10: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f13:
	/* 0xf13: jmp    f43 <process_execute_failed_tail+0xf43> */
	X86_SIM_X86_JMP(0xf13, 0xf43, x86_l_f43);
x86_l_f15:
	/* 0xf15: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f1a:
	/* 0xf1a: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f1e:
	/* 0xf1e: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf1e, 0x7f2, x86_l_7f2);
x86_l_f24:
	/* 0xf24: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f27:
	/* 0xf27: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_f2d:
	/* 0xf2d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f32:
	/* 0xf32: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_f36:
	/* 0xf36: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f39:
	/* 0xf39: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f3c:
	/* 0xf3c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f3f:
	/* 0xf3f: js     f10 <process_execute_failed_tail+0xf10> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf3f, 0xf10, x86_l_f10);
x86_l_f41:
	/* 0xf41: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f43:
	/* 0xf43: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f47:
	/* 0xf47: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f4a:
	/* 0xf4a: jns    f51 <process_execute_failed_tail+0xf51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf4a, 0xf51, x86_l_f51);
x86_l_f4c:
	/* 0xf4c: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f4f:
	/* 0xf4f: jmp    f53 <process_execute_failed_tail+0xf53> */
	X86_SIM_X86_JMP(0xf4f, 0xf53, x86_l_f53);
x86_l_f51:
	/* 0xf51: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f53:
	/* 0xf53: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f56:
	/* 0xf56: je     fd0 <process_execute_failed_tail+0xfd0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf56, 0xfd0, x86_l_fd0);
x86_l_f58:
	/* 0xf58: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f5b:
	/* 0xf5b: je     fd0 <process_execute_failed_tail+0xfd0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf5b, 0xfd0, x86_l_fd0);
x86_l_f5d:
	/* 0xf5d: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f61:
	/* 0xf61: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f64:
	/* 0xf64: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_f69:
	/* 0xf69: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f6c:
	/* 0xf6c: jns    f75 <process_execute_failed_tail+0xf75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf6c, 0xf75, x86_l_f75);
x86_l_f6e:
	/* 0xf6e: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f71:
	/* 0xf71: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f75:
	/* 0xf75: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_f79:
	/* 0xf79: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_f7c:
	/* 0xf7c: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_f83:
	/* 0xf83: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_f85:
	/* 0xf85: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f88:
	/* 0xf88: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf88, 0x17e8, x86_l_17e8);
x86_l_f8e:
	/* 0xf8e: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_f91:
	/* 0xf91: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf91, 0x7f5, x86_l_7f5);
x86_l_f97:
	/* 0xf97: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_f9d:
	/* 0xf9d: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_fa2:
	/* 0xfa2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fa5:
	/* 0xfa5: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfa5, 0x160c, x86_l_160c);
x86_l_fab:
	/* 0xfab: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_faf:
	/* 0xfaf: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb2:
	/* 0xfb2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_fb5:
	/* 0xfb5: je     101f <process_execute_failed_tail+0x101f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb5, 0x101f, x86_l_101f);
x86_l_fb7:
	/* 0xfb7: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_fbb:
	/* 0xfbb: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_fc0:
	/* 0xfc0: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_fc4:
	/* 0xfc4: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fc7:
	/* 0xfc7: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_fc9:
	/* 0xfc9: jne    fb2 <process_execute_failed_tail+0xfb2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfc9, 0xfb2, x86_l_fb2);
x86_l_fcb:
	/* 0xfcb: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_fce:
	/* 0xfce: jmp    1024 <process_execute_failed_tail+0x1024> */
	X86_SIM_X86_JMP(0xfce, 0x1024, x86_l_1024);
x86_l_fd0:
	/* 0xfd0: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fd3:
	/* 0xfd3: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfd3, 0x7f5, x86_l_7f5);
x86_l_fd9:
	/* 0xfd9: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_fdc:
	/* 0xfdc: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfdc, 0x7f5, x86_l_7f5);
x86_l_fe2:
	/* 0xfe2: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fe6:
	/* 0xfe6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fe9:
	/* 0xfe9: jns    ff0 <process_execute_failed_tail+0xff0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfe9, 0xff0, x86_l_ff0);
x86_l_feb:
	/* 0xfeb: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fee:
	/* 0xfee: jmp    ff2 <process_execute_failed_tail+0xff2> */
	X86_SIM_X86_JMP(0xfee, 0xff2, x86_l_ff2);
x86_l_ff0:
	/* 0xff0: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ff2:
	/* 0xff2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ff5:
	/* 0xff5: jns    ffc <process_execute_failed_tail+0xffc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xff5, 0xffc, x86_l_ffc);
x86_l_ff7:
	/* 0xff7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ffa:
	/* 0xffa: jmp    ffe <process_execute_failed_tail+0xffe> */
	X86_SIM_X86_JMP(0xffa, 0xffe, x86_l_ffe);
x86_l_ffc:
	/* 0xffc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ffe:
	/* 0xffe: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1001:
	/* 0x1001: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1004:
	/* 0x1004: jns    100b <process_execute_failed_tail+0x100b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1004, 0x100b, x86_l_100b);
x86_l_1006:
	/* 0x1006: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1009:
	/* 0x1009: jmp    100e <process_execute_failed_tail+0x100e> */
	X86_SIM_X86_JMP(0x1009, 0x100e, x86_l_100e);
x86_l_100b:
	/* 0x100b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_100e:
	/* 0x100e: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1012:
	/* 0x1012: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1015:
	/* 0x1015: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1018:
	/* 0x1018: jns    104b <process_execute_failed_tail+0x104b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1018, 0x104b, x86_l_104b);
x86_l_101a:
	/* 0x101a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_101d:
	/* 0x101d: jmp    104d <process_execute_failed_tail+0x104d> */
	X86_SIM_X86_JMP(0x101d, 0x104d, x86_l_104d);
x86_l_101f:
	/* 0x101f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1024:
	/* 0x1024: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1028:
	/* 0x1028: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1028, 0x7f5, x86_l_7f5);
x86_l_102e:
	/* 0x102e: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1031:
	/* 0x1031: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1037:
	/* 0x1037: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_103c:
	/* 0x103c: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1040:
	/* 0x1040: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1043:
	/* 0x1043: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1046:
	/* 0x1046: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1049:
	/* 0x1049: js     101a <process_execute_failed_tail+0x101a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1049, 0x101a, x86_l_101a);
x86_l_104b:
	/* 0x104b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_104d:
	/* 0x104d: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1051:
	/* 0x1051: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1054:
	/* 0x1054: jns    105b <process_execute_failed_tail+0x105b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1054, 0x105b, x86_l_105b);
x86_l_1056:
	/* 0x1056: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1059:
	/* 0x1059: jmp    105d <process_execute_failed_tail+0x105d> */
	X86_SIM_X86_JMP(0x1059, 0x105d, x86_l_105d);
x86_l_105b:
	/* 0x105b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_105d:
	/* 0x105d: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1060:
	/* 0x1060: je     10da <process_execute_failed_tail+0x10da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1060, 0x10da, x86_l_10da);
x86_l_1062:
	/* 0x1062: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1065:
	/* 0x1065: je     10da <process_execute_failed_tail+0x10da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1065, 0x10da, x86_l_10da);
x86_l_1067:
	/* 0x1067: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_106b:
	/* 0x106b: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_106e:
	/* 0x106e: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1073:
	/* 0x1073: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1076:
	/* 0x1076: jns    107f <process_execute_failed_tail+0x107f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1076, 0x107f, x86_l_107f);
x86_l_1078:
	/* 0x1078: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_107b:
	/* 0x107b: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_107f:
	/* 0x107f: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1083:
	/* 0x1083: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1086:
	/* 0x1086: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_108d:
	/* 0x108d: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_108f:
	/* 0x108f: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1092:
	/* 0x1092: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1092, 0x17e8, x86_l_17e8);
x86_l_1098:
	/* 0x1098: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_109b:
	/* 0x109b: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x109b, 0x7f2, x86_l_7f2);
x86_l_10a1:
	/* 0x10a1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_10a7:
	/* 0x10a7: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_10ac:
	/* 0x10ac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10af:
	/* 0x10af: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10af, 0x7e8, x86_l_7e8);
x86_l_10b5:
	/* 0x10b5: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10b9:
	/* 0x10b9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10bc:
	/* 0x10bc: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_10bf:
	/* 0x10bf: je     1129 <process_execute_failed_tail+0x1129> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10bf, 0x1129, x86_l_1129);
x86_l_10c1:
	/* 0x10c1: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_10c5:
	/* 0x10c5: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_10ca:
	/* 0x10ca: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_10ce:
	/* 0x10ce: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10d1:
	/* 0x10d1: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_10d3:
	/* 0x10d3: jne    10bc <process_execute_failed_tail+0x10bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10d3, 0x10bc, x86_l_10bc);
x86_l_10d5:
	/* 0x10d5: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_10d8:
	/* 0x10d8: jmp    112e <process_execute_failed_tail+0x112e> */
	X86_SIM_X86_JMP(0x10d8, 0x112e, x86_l_112e);
x86_l_10da:
	/* 0x10da: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10dd:
	/* 0x10dd: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10dd, 0x7f2, x86_l_7f2);
x86_l_10e3:
	/* 0x10e3: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_10e6:
	/* 0x10e6: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e6, 0x7f2, x86_l_7f2);
x86_l_10ec:
	/* 0x10ec: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10f0:
	/* 0x10f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10f3:
	/* 0x10f3: jns    10fa <process_execute_failed_tail+0x10fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10f3, 0x10fa, x86_l_10fa);
x86_l_10f5:
	/* 0x10f5: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10f8:
	/* 0x10f8: jmp    10fc <process_execute_failed_tail+0x10fc> */
	X86_SIM_X86_JMP(0x10f8, 0x10fc, x86_l_10fc);
x86_l_10fa:
	/* 0x10fa: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10fc:
	/* 0x10fc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10ff:
	/* 0x10ff: jns    1106 <process_execute_failed_tail+0x1106> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10ff, 0x1106, x86_l_1106);
x86_l_1101:
	/* 0x1101: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1104:
	/* 0x1104: jmp    1108 <process_execute_failed_tail+0x1108> */
	X86_SIM_X86_JMP(0x1104, 0x1108, x86_l_1108);
x86_l_1106:
	/* 0x1106: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1108:
	/* 0x1108: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_110b:
	/* 0x110b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_110e:
	/* 0x110e: jns    1115 <process_execute_failed_tail+0x1115> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x110e, 0x1115, x86_l_1115);
x86_l_1110:
	/* 0x1110: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1113:
	/* 0x1113: jmp    1118 <process_execute_failed_tail+0x1118> */
	X86_SIM_X86_JMP(0x1113, 0x1118, x86_l_1118);
x86_l_1115:
	/* 0x1115: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1118:
	/* 0x1118: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_111c:
	/* 0x111c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_111f:
	/* 0x111f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1122:
	/* 0x1122: jns    1155 <process_execute_failed_tail+0x1155> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1122, 0x1155, x86_l_1155);
x86_l_1124:
	/* 0x1124: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1127:
	/* 0x1127: jmp    1157 <process_execute_failed_tail+0x1157> */
	X86_SIM_X86_JMP(0x1127, 0x1157, x86_l_1157);
x86_l_1129:
	/* 0x1129: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_112e:
	/* 0x112e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1132:
	/* 0x1132: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1132, 0x7f2, x86_l_7f2);
x86_l_1138:
	/* 0x1138: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_113b:
	/* 0x113b: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1141:
	/* 0x1141: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1146:
	/* 0x1146: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_114a:
	/* 0x114a: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_114d:
	/* 0x114d: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1150:
	/* 0x1150: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1153:
	/* 0x1153: js     1124 <process_execute_failed_tail+0x1124> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1153, 0x1124, x86_l_1124);
x86_l_1155:
	/* 0x1155: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1157:
	/* 0x1157: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_115b:
	/* 0x115b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_115e:
	/* 0x115e: jns    1165 <process_execute_failed_tail+0x1165> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x115e, 0x1165, x86_l_1165);
x86_l_1160:
	/* 0x1160: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1163:
	/* 0x1163: jmp    1167 <process_execute_failed_tail+0x1167> */
	X86_SIM_X86_JMP(0x1163, 0x1167, x86_l_1167);
x86_l_1165:
	/* 0x1165: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1167:
	/* 0x1167: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_116a:
	/* 0x116a: je     11e4 <process_execute_failed_tail+0x11e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116a, 0x11e4, x86_l_11e4);
x86_l_116c:
	/* 0x116c: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_116f:
	/* 0x116f: je     11e4 <process_execute_failed_tail+0x11e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116f, 0x11e4, x86_l_11e4);
x86_l_1171:
	/* 0x1171: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1175:
	/* 0x1175: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1178:
	/* 0x1178: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_117d:
	/* 0x117d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1180:
	/* 0x1180: jns    1189 <process_execute_failed_tail+0x1189> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1180, 0x1189, x86_l_1189);
x86_l_1182:
	/* 0x1182: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1185:
	/* 0x1185: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1189:
	/* 0x1189: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_118d:
	/* 0x118d: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1190:
	/* 0x1190: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1197:
	/* 0x1197: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1199:
	/* 0x1199: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_119c:
	/* 0x119c: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x119c, 0x17e8, x86_l_17e8);
x86_l_11a2:
	/* 0x11a2: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_11a5:
	/* 0x11a5: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11a5, 0x7f5, x86_l_7f5);
x86_l_11ab:
	/* 0x11ab: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_11b1:
	/* 0x11b1: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_11b6:
	/* 0x11b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11b9:
	/* 0x11b9: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11b9, 0x160c, x86_l_160c);
x86_l_11bf:
	/* 0x11bf: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_11c3:
	/* 0x11c3: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c6:
	/* 0x11c6: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_11c9:
	/* 0x11c9: je     1233 <process_execute_failed_tail+0x1233> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11c9, 0x1233, x86_l_1233);
x86_l_11cb:
	/* 0x11cb: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_11cf:
	/* 0x11cf: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_11d4:
	/* 0x11d4: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_11d8:
	/* 0x11d8: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11db:
	/* 0x11db: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_11dd:
	/* 0x11dd: jne    11c6 <process_execute_failed_tail+0x11c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11dd, 0x11c6, x86_l_11c6);
x86_l_11df:
	/* 0x11df: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_11e2:
	/* 0x11e2: jmp    1238 <process_execute_failed_tail+0x1238> */
	X86_SIM_X86_JMP(0x11e2, 0x1238, x86_l_1238);
x86_l_11e4:
	/* 0x11e4: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e7:
	/* 0x11e7: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11e7, 0x7f5, x86_l_7f5);
x86_l_11ed:
	/* 0x11ed: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11f0:
	/* 0x11f0: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11f0, 0x7f5, x86_l_7f5);
x86_l_11f6:
	/* 0x11f6: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11fa:
	/* 0x11fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11fd:
	/* 0x11fd: jns    1204 <process_execute_failed_tail+0x1204> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11fd, 0x1204, x86_l_1204);
x86_l_11ff:
	/* 0x11ff: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1202:
	/* 0x1202: jmp    1206 <process_execute_failed_tail+0x1206> */
	X86_SIM_X86_JMP(0x1202, 0x1206, x86_l_1206);
x86_l_1204:
	/* 0x1204: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1206:
	/* 0x1206: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1209:
	/* 0x1209: jns    1210 <process_execute_failed_tail+0x1210> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1209, 0x1210, x86_l_1210);
x86_l_120b:
	/* 0x120b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_120e:
	/* 0x120e: jmp    1212 <process_execute_failed_tail+0x1212> */
	X86_SIM_X86_JMP(0x120e, 0x1212, x86_l_1212);
x86_l_1210:
	/* 0x1210: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1212:
	/* 0x1212: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1215:
	/* 0x1215: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1218:
	/* 0x1218: jns    121f <process_execute_failed_tail+0x121f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1218, 0x121f, x86_l_121f);
x86_l_121a:
	/* 0x121a: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_121d:
	/* 0x121d: jmp    1222 <process_execute_failed_tail+0x1222> */
	X86_SIM_X86_JMP(0x121d, 0x1222, x86_l_1222);
x86_l_121f:
	/* 0x121f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1222:
	/* 0x1222: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1226:
	/* 0x1226: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1229:
	/* 0x1229: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_122c:
	/* 0x122c: jns    125f <process_execute_failed_tail+0x125f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x122c, 0x125f, x86_l_125f);
x86_l_122e:
	/* 0x122e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1231:
	/* 0x1231: jmp    1261 <process_execute_failed_tail+0x1261> */
	X86_SIM_X86_JMP(0x1231, 0x1261, x86_l_1261);
x86_l_1233:
	/* 0x1233: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1238:
	/* 0x1238: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_123c:
	/* 0x123c: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0x123c, 0x7f5, x86_l_7f5);
x86_l_1242:
	/* 0x1242: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1245:
	/* 0x1245: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_124b:
	/* 0x124b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1250:
	/* 0x1250: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1254:
	/* 0x1254: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1257:
	/* 0x1257: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_125a:
	/* 0x125a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_125d:
	/* 0x125d: js     122e <process_execute_failed_tail+0x122e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x125d, 0x122e, x86_l_122e);
x86_l_125f:
	/* 0x125f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1261:
	/* 0x1261: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1265:
	/* 0x1265: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1268:
	/* 0x1268: jns    126f <process_execute_failed_tail+0x126f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1268, 0x126f, x86_l_126f);
x86_l_126a:
	/* 0x126a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_126d:
	/* 0x126d: jmp    1271 <process_execute_failed_tail+0x1271> */
	X86_SIM_X86_JMP(0x126d, 0x1271, x86_l_1271);
x86_l_126f:
	/* 0x126f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1271:
	/* 0x1271: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1274:
	/* 0x1274: je     12ee <process_execute_failed_tail+0x12ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1274, 0x12ee, x86_l_12ee);
x86_l_1276:
	/* 0x1276: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1279:
	/* 0x1279: je     12ee <process_execute_failed_tail+0x12ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1279, 0x12ee, x86_l_12ee);
x86_l_127b:
	/* 0x127b: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_127f:
	/* 0x127f: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1282:
	/* 0x1282: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1287:
	/* 0x1287: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_128a:
	/* 0x128a: jns    1293 <process_execute_failed_tail+0x1293> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x128a, 0x1293, x86_l_1293);
x86_l_128c:
	/* 0x128c: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_128f:
	/* 0x128f: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1293:
	/* 0x1293: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1297:
	/* 0x1297: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_129a:
	/* 0x129a: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_12a1:
	/* 0x12a1: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_12a3:
	/* 0x12a3: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_12a6:
	/* 0x12a6: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x12a6, 0x17e8, x86_l_17e8);
x86_l_12ac:
	/* 0x12ac: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_12af:
	/* 0x12af: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12af, 0x7f2, x86_l_7f2);
x86_l_12b5:
	/* 0x12b5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_12bb:
	/* 0x12bb: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_12c0:
	/* 0x12c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12c3:
	/* 0x12c3: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12c3, 0x7e8, x86_l_7e8);
x86_l_12c9:
	/* 0x12c9: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_12cd:
	/* 0x12cd: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12d0:
	/* 0x12d0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_12d3:
	/* 0x12d3: je     133d <process_execute_failed_tail+0x133d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d3, 0x133d, x86_l_133d);
x86_l_12d5:
	/* 0x12d5: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12d9:
	/* 0x12d9: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_12de:
	/* 0x12de: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_12e2:
	/* 0x12e2: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12e5:
	/* 0x12e5: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_12e7:
	/* 0x12e7: jne    12d0 <process_execute_failed_tail+0x12d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12e7, 0x12d0, x86_l_12d0);
x86_l_12e9:
	/* 0x12e9: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_12ec:
	/* 0x12ec: jmp    1342 <process_execute_failed_tail+0x1342> */
	X86_SIM_X86_JMP(0x12ec, 0x1342, x86_l_1342);
x86_l_12ee:
	/* 0x12ee: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12f1:
	/* 0x12f1: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12f1, 0x7f2, x86_l_7f2);
x86_l_12f7:
	/* 0x12f7: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_12fa:
	/* 0x12fa: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12fa, 0x7f2, x86_l_7f2);
x86_l_1300:
	/* 0x1300: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1304:
	/* 0x1304: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1307:
	/* 0x1307: jns    130e <process_execute_failed_tail+0x130e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1307, 0x130e, x86_l_130e);
x86_l_1309:
	/* 0x1309: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_130c:
	/* 0x130c: jmp    1310 <process_execute_failed_tail+0x1310> */
	X86_SIM_X86_JMP(0x130c, 0x1310, x86_l_1310);
x86_l_130e:
	/* 0x130e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1310:
	/* 0x1310: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1313:
	/* 0x1313: jns    131a <process_execute_failed_tail+0x131a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1313, 0x131a, x86_l_131a);
x86_l_1315:
	/* 0x1315: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1318:
	/* 0x1318: jmp    131c <process_execute_failed_tail+0x131c> */
	X86_SIM_X86_JMP(0x1318, 0x131c, x86_l_131c);
x86_l_131a:
	/* 0x131a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_131c:
	/* 0x131c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_131f:
	/* 0x131f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1322:
	/* 0x1322: jns    1329 <process_execute_failed_tail+0x1329> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1322, 0x1329, x86_l_1329);
x86_l_1324:
	/* 0x1324: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1327:
	/* 0x1327: jmp    132c <process_execute_failed_tail+0x132c> */
	X86_SIM_X86_JMP(0x1327, 0x132c, x86_l_132c);
x86_l_1329:
	/* 0x1329: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_132c:
	/* 0x132c: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1330:
	/* 0x1330: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1333:
	/* 0x1333: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1336:
	/* 0x1336: jns    1369 <process_execute_failed_tail+0x1369> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1336, 0x1369, x86_l_1369);
x86_l_1338:
	/* 0x1338: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_133b:
	/* 0x133b: jmp    136b <process_execute_failed_tail+0x136b> */
	X86_SIM_X86_JMP(0x133b, 0x136b, x86_l_136b);
x86_l_133d:
	/* 0x133d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1342:
	/* 0x1342: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1346:
	/* 0x1346: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1346, 0x7f2, x86_l_7f2);
x86_l_134c:
	/* 0x134c: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_134f:
	/* 0x134f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1355:
	/* 0x1355: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_135a:
	/* 0x135a: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_135e:
	/* 0x135e: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1361:
	/* 0x1361: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1364:
	/* 0x1364: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1367:
	/* 0x1367: js     1338 <process_execute_failed_tail+0x1338> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1367, 0x1338, x86_l_1338);
x86_l_1369:
	/* 0x1369: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_136b:
	/* 0x136b: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_136f:
	/* 0x136f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1372:
	/* 0x1372: jns    1379 <process_execute_failed_tail+0x1379> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1372, 0x1379, x86_l_1379);
x86_l_1374:
	/* 0x1374: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1377:
	/* 0x1377: jmp    137b <process_execute_failed_tail+0x137b> */
	X86_SIM_X86_JMP(0x1377, 0x137b, x86_l_137b);
x86_l_1379:
	/* 0x1379: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_137b:
	/* 0x137b: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_137e:
	/* 0x137e: je     13f8 <process_execute_failed_tail+0x13f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x137e, 0x13f8, x86_l_13f8);
x86_l_1380:
	/* 0x1380: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1383:
	/* 0x1383: je     13f8 <process_execute_failed_tail+0x13f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1383, 0x13f8, x86_l_13f8);
x86_l_1385:
	/* 0x1385: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1389:
	/* 0x1389: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_138c:
	/* 0x138c: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1391:
	/* 0x1391: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1394:
	/* 0x1394: jns    139d <process_execute_failed_tail+0x139d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1394, 0x139d, x86_l_139d);
x86_l_1396:
	/* 0x1396: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1399:
	/* 0x1399: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_139d:
	/* 0x139d: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_13a1:
	/* 0x13a1: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_13a4:
	/* 0x13a4: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_13ab:
	/* 0x13ab: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_13ad:
	/* 0x13ad: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_13b0:
	/* 0x13b0: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13b0, 0x17e8, x86_l_17e8);
x86_l_13b6:
	/* 0x13b6: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_13b9:
	/* 0x13b9: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13b9, 0x7f5, x86_l_7f5);
x86_l_13bf:
	/* 0x13bf: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_13c5:
	/* 0x13c5: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_13ca:
	/* 0x13ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13cd:
	/* 0x13cd: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13cd, 0x160c, x86_l_160c);
x86_l_13d3:
	/* 0x13d3: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_13d7:
	/* 0x13d7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13da:
	/* 0x13da: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_13dd:
	/* 0x13dd: je     1447 <process_execute_failed_tail+0x1447> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13dd, 0x1447, x86_l_1447);
x86_l_13df:
	/* 0x13df: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_13e3:
	/* 0x13e3: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_13e8:
	/* 0x13e8: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_13ec:
	/* 0x13ec: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_13ef:
	/* 0x13ef: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_13f1:
	/* 0x13f1: jne    13da <process_execute_failed_tail+0x13da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13f1, 0x13da, x86_l_13da);
x86_l_13f3:
	/* 0x13f3: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_13f6:
	/* 0x13f6: jmp    144c <process_execute_failed_tail+0x144c> */
	X86_SIM_X86_JMP(0x13f6, 0x144c, x86_l_144c);
x86_l_13f8:
	/* 0x13f8: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13fb:
	/* 0x13fb: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13fb, 0x7f5, x86_l_7f5);
x86_l_1401:
	/* 0x1401: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1404:
	/* 0x1404: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1404, 0x7f5, x86_l_7f5);
x86_l_140a:
	/* 0x140a: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_140e:
	/* 0x140e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1411:
	/* 0x1411: jns    1418 <process_execute_failed_tail+0x1418> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1411, 0x1418, x86_l_1418);
x86_l_1413:
	/* 0x1413: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1416:
	/* 0x1416: jmp    141a <process_execute_failed_tail+0x141a> */
	X86_SIM_X86_JMP(0x1416, 0x141a, x86_l_141a);
x86_l_1418:
	/* 0x1418: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_141a:
	/* 0x141a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_141d:
	/* 0x141d: jns    1424 <process_execute_failed_tail+0x1424> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x141d, 0x1424, x86_l_1424);
x86_l_141f:
	/* 0x141f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1422:
	/* 0x1422: jmp    1426 <process_execute_failed_tail+0x1426> */
	X86_SIM_X86_JMP(0x1422, 0x1426, x86_l_1426);
x86_l_1424:
	/* 0x1424: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1426:
	/* 0x1426: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1429:
	/* 0x1429: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_142c:
	/* 0x142c: jns    1433 <process_execute_failed_tail+0x1433> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x142c, 0x1433, x86_l_1433);
x86_l_142e:
	/* 0x142e: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1431:
	/* 0x1431: jmp    1436 <process_execute_failed_tail+0x1436> */
	X86_SIM_X86_JMP(0x1431, 0x1436, x86_l_1436);
x86_l_1433:
	/* 0x1433: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1436:
	/* 0x1436: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_143a:
	/* 0x143a: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_143d:
	/* 0x143d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1440:
	/* 0x1440: jns    1473 <process_execute_failed_tail+0x1473> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1440, 0x1473, x86_l_1473);
x86_l_1442:
	/* 0x1442: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1445:
	/* 0x1445: jmp    1475 <process_execute_failed_tail+0x1475> */
	X86_SIM_X86_JMP(0x1445, 0x1475, x86_l_1475);
x86_l_1447:
	/* 0x1447: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_144c:
	/* 0x144c: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1450:
	/* 0x1450: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1450, 0x7f5, x86_l_7f5);
x86_l_1456:
	/* 0x1456: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1459:
	/* 0x1459: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_145f:
	/* 0x145f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1464:
	/* 0x1464: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1468:
	/* 0x1468: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_146b:
	/* 0x146b: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_146e:
	/* 0x146e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1471:
	/* 0x1471: js     1442 <process_execute_failed_tail+0x1442> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1471, 0x1442, x86_l_1442);
x86_l_1473:
	/* 0x1473: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1475:
	/* 0x1475: lea    rsi,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1479:
	/* 0x1479: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_147c:
	/* 0x147c: jns    1483 <process_execute_failed_tail+0x1483> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x147c, 0x1483, x86_l_1483);
x86_l_147e:
	/* 0x147e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1481:
	/* 0x1481: jmp    1485 <process_execute_failed_tail+0x1485> */
	X86_SIM_X86_JMP(0x1481, 0x1485, x86_l_1485);
x86_l_1483:
	/* 0x1483: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1485:
	/* 0x1485: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1488:
	/* 0x1488: je     1502 <process_execute_failed_tail+0x1502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1488, 0x1502, x86_l_1502);
x86_l_148a:
	/* 0x148a: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_148d:
	/* 0x148d: je     1502 <process_execute_failed_tail+0x1502> */
	X86_SIM_X86_JCC(X86_CC_E, 0x148d, 0x1502, x86_l_1502);
x86_l_148f:
	/* 0x148f: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1493:
	/* 0x1493: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1496:
	/* 0x1496: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_149b:
	/* 0x149b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_149e:
	/* 0x149e: jns    14a7 <process_execute_failed_tail+0x14a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x149e, 0x14a7, x86_l_14a7);
x86_l_14a0:
	/* 0x14a0: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14a3:
	/* 0x14a3: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14a7:
	/* 0x14a7: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14ab:
	/* 0x14ab: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_14ae:
	/* 0x14ae: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_14b5:
	/* 0x14b5: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_14b7:
	/* 0x14b7: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_14ba:
	/* 0x14ba: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x14ba, 0x17e8, x86_l_17e8);
x86_l_14c0:
	/* 0x14c0: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_14c3:
	/* 0x14c3: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14c3, 0x7f2, x86_l_7f2);
x86_l_14c9:
	/* 0x14c9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_14cf:
	/* 0x14cf: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_14d4:
	/* 0x14d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14d7:
	/* 0x14d7: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14d7, 0x7e8, x86_l_7e8);
x86_l_14dd:
	/* 0x14dd: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_14e1:
	/* 0x14e1: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e4:
	/* 0x14e4: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_14e7:
	/* 0x14e7: je     1551 <process_execute_failed_tail+0x1551> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e7, 0x1551, x86_l_1551);
x86_l_14e9:
	/* 0x14e9: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_14ed:
	/* 0x14ed: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_14f2:
	/* 0x14f2: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_14f6:
	/* 0x14f6: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_14f9:
	/* 0x14f9: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_14fb:
	/* 0x14fb: jne    14e4 <process_execute_failed_tail+0x14e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14fb, 0x14e4, x86_l_14e4);
x86_l_14fd:
	/* 0x14fd: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1500:
	/* 0x1500: jmp    1556 <process_execute_failed_tail+0x1556> */
	X86_SIM_X86_JMP(0x1500, 0x1556, x86_l_1556);
x86_l_1502:
	/* 0x1502: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1505:
	/* 0x1505: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1505, 0x7f2, x86_l_7f2);
x86_l_150b:
	/* 0x150b: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_150e:
	/* 0x150e: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x150e, 0x7f2, x86_l_7f2);
x86_l_1514:
	/* 0x1514: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1518:
	/* 0x1518: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_151b:
	/* 0x151b: jns    1522 <process_execute_failed_tail+0x1522> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x151b, 0x1522, x86_l_1522);
x86_l_151d:
	/* 0x151d: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1520:
	/* 0x1520: jmp    1524 <process_execute_failed_tail+0x1524> */
	X86_SIM_X86_JMP(0x1520, 0x1524, x86_l_1524);
x86_l_1522:
	/* 0x1522: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1524:
	/* 0x1524: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1527:
	/* 0x1527: jns    152e <process_execute_failed_tail+0x152e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1527, 0x152e, x86_l_152e);
x86_l_1529:
	/* 0x1529: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_152c:
	/* 0x152c: jmp    1530 <process_execute_failed_tail+0x1530> */
	X86_SIM_X86_JMP(0x152c, 0x1530, x86_l_1530);
x86_l_152e:
	/* 0x152e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1530:
	/* 0x1530: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1533:
	/* 0x1533: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1536:
	/* 0x1536: jns    153d <process_execute_failed_tail+0x153d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1536, 0x153d, x86_l_153d);
x86_l_1538:
	/* 0x1538: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153b:
	/* 0x153b: jmp    1540 <process_execute_failed_tail+0x1540> */
	X86_SIM_X86_JMP(0x153b, 0x1540, x86_l_1540);
x86_l_153d:
	/* 0x153d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1540:
	/* 0x1540: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1544:
	/* 0x1544: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1547:
	/* 0x1547: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_154a:
	/* 0x154a: jns    157d <process_execute_failed_tail+0x157d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x154a, 0x157d, x86_l_157d);
x86_l_154c:
	/* 0x154c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154f:
	/* 0x154f: jmp    157f <process_execute_failed_tail+0x157f> */
	X86_SIM_X86_JMP(0x154f, 0x157f, x86_l_157f);
x86_l_1551:
	/* 0x1551: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1556:
	/* 0x1556: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_155a:
	/* 0x155a: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0x155a, 0x7f2, x86_l_7f2);
x86_l_1560:
	/* 0x1560: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1563:
	/* 0x1563: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1569:
	/* 0x1569: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_156e:
	/* 0x156e: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1572:
	/* 0x1572: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1575:
	/* 0x1575: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1578:
	/* 0x1578: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_157b:
	/* 0x157b: js     154c <process_execute_failed_tail+0x154c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x157b, 0x154c, x86_l_154c);
x86_l_157d:
	/* 0x157d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157f:
	/* 0x157f: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1583:
	/* 0x1583: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1586:
	/* 0x1586: jns    158d <process_execute_failed_tail+0x158d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1586, 0x158d, x86_l_158d);
x86_l_1588:
	/* 0x1588: mov    rbx,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158b:
	/* 0x158b: jmp    158f <process_execute_failed_tail+0x158f> */
	X86_SIM_X86_JMP(0x158b, 0x158f, x86_l_158f);
x86_l_158d:
	/* 0x158d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_158f:
	/* 0x158f: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1592:
	/* 0x1592: je     1614 <process_execute_failed_tail+0x1614> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1592, 0x1614, x86_l_1614);
x86_l_1598:
	/* 0x1598: cmp    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_159b:
	/* 0x159b: je     1614 <process_execute_failed_tail+0x1614> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159b, 0x1614, x86_l_1614);
x86_l_159d:
	/* 0x159d: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15a1:
	/* 0x15a1: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a4:
	/* 0x15a4: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_15a9:
	/* 0x15a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15ac:
	/* 0x15ac: jns    15b5 <process_execute_failed_tail+0x15b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ac, 0x15b5, x86_l_15b5);
x86_l_15ae:
	/* 0x15ae: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b1:
	/* 0x15b1: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15b5:
	/* 0x15b5: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_15b9:
	/* 0x15b9: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_15bc:
	/* 0x15bc: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_15c3:
	/* 0x15c3: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_15c5:
	/* 0x15c5: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_15c8:
	/* 0x15c8: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15c8, 0x17e8, x86_l_17e8);
x86_l_15ce:
	/* 0x15ce: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_15d1:
	/* 0x15d1: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15d1, 0x7f5, x86_l_7f5);
x86_l_15d7:
	/* 0x15d7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_15dd:
	/* 0x15dd: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_15e2:
	/* 0x15e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15e5:
	/* 0x15e5: jns    160c <process_execute_failed_tail+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15e5, 0x160c, x86_l_160c);
x86_l_15e7:
	/* 0x15e7: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_15eb:
	/* 0x15eb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15ee:
	/* 0x15ee: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_15f1:
	/* 0x15f1: je     1663 <process_execute_failed_tail+0x1663> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f1, 0x1663, x86_l_1663);
x86_l_15f3:
	/* 0x15f3: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_15f7:
	/* 0x15f7: movzx  edx,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_15fc:
	/* 0x15fc: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1600:
	/* 0x1600: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1603:
	/* 0x1603: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1605:
	/* 0x1605: jne    15ee <process_execute_failed_tail+0x15ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1605, 0x15ee, x86_l_15ee);
x86_l_1607:
	/* 0x1607: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_160a:
	/* 0x160a: jmp    1668 <process_execute_failed_tail+0x1668> */
	X86_SIM_X86_JMP(0x160a, 0x1668, x86_l_1668);
x86_l_160c:
	/* 0x160c: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_160f:
	/* 0x160f: jmp    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JMP(0x160f, 0x7e8, x86_l_7e8);
x86_l_1614:
	/* 0x1614: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1617:
	/* 0x1617: jne    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1617, 0x7f5, x86_l_7f5);
x86_l_161d:
	/* 0x161d: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1620:
	/* 0x1620: je     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1620, 0x7f5, x86_l_7f5);
x86_l_1626:
	/* 0x1626: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_162a:
	/* 0x162a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_162d:
	/* 0x162d: jns    1634 <process_execute_failed_tail+0x1634> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162d, 0x1634, x86_l_1634);
x86_l_162f:
	/* 0x162f: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1632:
	/* 0x1632: jmp    1636 <process_execute_failed_tail+0x1636> */
	X86_SIM_X86_JMP(0x1632, 0x1636, x86_l_1636);
x86_l_1634:
	/* 0x1634: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1636:
	/* 0x1636: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1639:
	/* 0x1639: jns    1640 <process_execute_failed_tail+0x1640> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1639, 0x1640, x86_l_1640);
x86_l_163b:
	/* 0x163b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_163e:
	/* 0x163e: jmp    1642 <process_execute_failed_tail+0x1642> */
	X86_SIM_X86_JMP(0x163e, 0x1642, x86_l_1642);
x86_l_1640:
	/* 0x1640: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1642:
	/* 0x1642: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1645:
	/* 0x1645: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1648:
	/* 0x1648: jns    164f <process_execute_failed_tail+0x164f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1648, 0x164f, x86_l_164f);
x86_l_164a:
	/* 0x164a: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_164d:
	/* 0x164d: jmp    1652 <process_execute_failed_tail+0x1652> */
	X86_SIM_X86_JMP(0x164d, 0x1652, x86_l_1652);
x86_l_164f:
	/* 0x164f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1652:
	/* 0x1652: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1656:
	/* 0x1656: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1659:
	/* 0x1659: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165c:
	/* 0x165c: jns    168f <process_execute_failed_tail+0x168f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x165c, 0x168f, x86_l_168f);
x86_l_165e:
	/* 0x165e: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1661:
	/* 0x1661: jmp    1691 <process_execute_failed_tail+0x1691> */
	X86_SIM_X86_JMP(0x1661, 0x1691, x86_l_1691);
x86_l_1663:
	/* 0x1663: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1668:
	/* 0x1668: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_166c:
	/* 0x166c: jl     7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_L, 0x166c, 0x7f5, x86_l_7f5);
x86_l_1672:
	/* 0x1672: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1675:
	/* 0x1675: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_167b:
	/* 0x167b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1680:
	/* 0x1680: mov    BYTE PTR [rax+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1684:
	/* 0x1684: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1687:
	/* 0x1687: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_168a:
	/* 0x168a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_168d:
	/* 0x168d: js     165e <process_execute_failed_tail+0x165e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x168d, 0x165e, x86_l_165e);
x86_l_168f:
	/* 0x168f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1691:
	/* 0x1691: lea    rax,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1695:
	/* 0x1695: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1698:
	/* 0x1698: jns    169f <process_execute_failed_tail+0x169f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1698, 0x169f, x86_l_169f);
x86_l_169a:
	/* 0x169a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_169d:
	/* 0x169d: jmp    16a1 <process_execute_failed_tail+0x16a1> */
	X86_SIM_X86_JMP(0x169d, 0x16a1, x86_l_16a1);
x86_l_169f:
	/* 0x169f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a1:
	/* 0x16a1: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16a4:
	/* 0x16a4: je     171e <process_execute_failed_tail+0x171e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16a4, 0x171e, x86_l_171e);
x86_l_16a6:
	/* 0x16a6: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16a9:
	/* 0x16a9: je     171e <process_execute_failed_tail+0x171e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16a9, 0x171e, x86_l_171e);
x86_l_16ab:
	/* 0x16ab: lea    rdi,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16af:
	/* 0x16af: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16b2:
	/* 0x16b2: mov    esi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_16b7:
	/* 0x16b7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16ba:
	/* 0x16ba: jns    16c3 <process_execute_failed_tail+0x16c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ba, 0x16c3, x86_l_16c3);
x86_l_16bc:
	/* 0x16bc: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16bf:
	/* 0x16bf: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16c3:
	/* 0x16c3: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_16c7:
	/* 0x16c7: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_16ca:
	/* 0x16ca: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_16d1:
	/* 0x16d1: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_16d3:
	/* 0x16d3: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16d6:
	/* 0x16d6: jb     17e8 <process_execute_failed_tail+0x17e8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16d6, 0x17e8, x86_l_17e8);
x86_l_16dc:
	/* 0x16dc: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_16df:
	/* 0x16df: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16df, 0x7f2, x86_l_7f2);
x86_l_16e5:
	/* 0x16e5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_16eb:
	/* 0x16eb: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_16f0:
	/* 0x16f0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16f3:
	/* 0x16f3: jns    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f3, 0x7e8, x86_l_7e8);
x86_l_16f9:
	/* 0x16f9: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_16fd:
	/* 0x16fd: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1700:
	/* 0x1700: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1703:
	/* 0x1703: je     176a <process_execute_failed_tail+0x176a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1703, 0x176a, x86_l_176a);
x86_l_1705:
	/* 0x1705: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1709:
	/* 0x1709: movzx  edx,BYTE PTR [rsi+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_170e:
	/* 0x170e: mov    BYTE PTR [rdi+r11*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1712:
	/* 0x1712: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1715:
	/* 0x1715: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1717:
	/* 0x1717: jne    1700 <process_execute_failed_tail+0x1700> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1717, 0x1700, x86_l_1700);
x86_l_1719:
	/* 0x1719: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_171c:
	/* 0x171c: jmp    176f <process_execute_failed_tail+0x176f> */
	X86_SIM_X86_JMP(0x171c, 0x176f, x86_l_176f);
x86_l_171e:
	/* 0x171e: cmp    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1721:
	/* 0x1721: jne    7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1721, 0x7f2, x86_l_7f2);
x86_l_1727:
	/* 0x1727: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_172a:
	/* 0x172a: je     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172a, 0x7f2, x86_l_7f2);
x86_l_1730:
	/* 0x1730: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1734:
	/* 0x1734: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1737:
	/* 0x1737: jns    173e <process_execute_failed_tail+0x173e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1737, 0x173e, x86_l_173e);
x86_l_1739:
	/* 0x1739: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_173c:
	/* 0x173c: jmp    1740 <process_execute_failed_tail+0x1740> */
	X86_SIM_X86_JMP(0x173c, 0x1740, x86_l_1740);
x86_l_173e:
	/* 0x173e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1740:
	/* 0x1740: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1743:
	/* 0x1743: jns    174a <process_execute_failed_tail+0x174a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1743, 0x174a, x86_l_174a);
x86_l_1745:
	/* 0x1745: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1748:
	/* 0x1748: jmp    174c <process_execute_failed_tail+0x174c> */
	X86_SIM_X86_JMP(0x1748, 0x174c, x86_l_174c);
x86_l_174a:
	/* 0x174a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174c:
	/* 0x174c: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_174f:
	/* 0x174f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1752:
	/* 0x1752: jns    1759 <process_execute_failed_tail+0x1759> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1752, 0x1759, x86_l_1759);
x86_l_1754:
	/* 0x1754: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1757:
	/* 0x1757: jmp    175c <process_execute_failed_tail+0x175c> */
	X86_SIM_X86_JMP(0x1757, 0x175c, x86_l_175c);
x86_l_1759:
	/* 0x1759: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_175c:
	/* 0x175c: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1760:
	/* 0x1760: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1763:
	/* 0x1763: jns    1793 <process_execute_failed_tail+0x1793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1763, 0x1793, x86_l_1793);
x86_l_1765:
	/* 0x1765: mov    rdi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1768:
	/* 0x1768: jmp    1795 <process_execute_failed_tail+0x1795> */
	X86_SIM_X86_JMP(0x1768, 0x1795, x86_l_1795);
x86_l_176a:
	/* 0x176a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_176f:
	/* 0x176f: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1773:
	/* 0x1773: jl     7f2 <process_execute_failed_tail+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1773, 0x7f2, x86_l_7f2);
x86_l_1779:
	/* 0x1779: lea    edx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_177c:
	/* 0x177c: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1782:
	/* 0x1782: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1787:
	/* 0x1787: mov    BYTE PTR [rsi+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_178b:
	/* 0x178b: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_178e:
	/* 0x178e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1791:
	/* 0x1791: js     1765 <process_execute_failed_tail+0x1765> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1791, 0x1765, x86_l_1765);
x86_l_1793:
	/* 0x1793: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1795:
	/* 0x1795: lea    rsi,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1799:
	/* 0x1799: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_179c:
	/* 0x179c: jns    17a3 <process_execute_failed_tail+0x17a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x179c, 0x17a3, x86_l_17a3);
x86_l_179e:
	/* 0x179e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a1:
	/* 0x17a1: jmp    17a5 <process_execute_failed_tail+0x17a5> */
	X86_SIM_X86_JMP(0x17a1, 0x17a5, x86_l_17a5);
x86_l_17a3:
	/* 0x17a3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a5:
	/* 0x17a5: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17a8:
	/* 0x17a8: je     1ee4 <process_execute_failed_tail+0x1ee4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17a8, 0x1ee4, x86_l_1ee4);
x86_l_17ae:
	/* 0x17ae: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17b1:
	/* 0x17b1: je     1ee4 <process_execute_failed_tail+0x1ee4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b1, 0x1ee4, x86_l_1ee4);
x86_l_17b7:
	/* 0x17b7: lea    rdx,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17bb:
	/* 0x17bb: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17be:
	/* 0x17be: mov    ecx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_17c3:
	/* 0x17c3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17c6:
	/* 0x17c6: jns    17cf <process_execute_failed_tail+0x17cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c6, 0x17cf, x86_l_17cf);
x86_l_17c8:
	/* 0x17c8: mov    r9,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17cb:
	/* 0x17cb: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17cf:
	/* 0x17cf: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_17d3:
	/* 0x17d3: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_17d6:
	/* 0x17d6: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_17dd:
	/* 0x17dd: mov    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_17df:
	/* 0x17df: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_17e2:
	/* 0x17e2: jae    1f04 <process_execute_failed_tail+0x1f04> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x17e2, 0x1f04, x86_l_1f04);
x86_l_17e8:
	/* 0x17e8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17ed:
	/* 0x17ed: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_17ef:
	/* 0x17ef: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_17f1:
	/* 0x17f1: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_17f7:
	/* 0x17f7: mov    BYTE PTR [rax+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_17fb:
	/* 0x17fb: mov    BYTE PTR [rax+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_1802:
	/* 0x1802: and    ebp,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1808:
	/* 0x1808: add    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_180b:
	/* 0x180b: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1813:
	/* 0x1813: cmp    rcx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_181a:
	/* 0x181a: ja     18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x181a, 0x18f8, x86_l_18f8);
x86_l_1820:
	/* 0x1820: mov    BYTE PTR [r14+rcx*1+0x89],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519562ULL);
x86_l_1829:
	/* 0x1829: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1831:
	/* 0x1831: mov    WORD PTR [r14+0x7da0],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32160ULL);
x86_l_1839:
	/* 0x1839: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1840:
	/* 0x1840: ja     18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1840, 0x18f8, x86_l_18f8);
x86_l_1846:
	/* 0x1846: lea    rdi,[rcx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_184a:
	/* 0x184a: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1851:
	/* 0x1851: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1854:
	/* 0x1854: jns    187c <process_execute_failed_tail+0x187c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1854, 0x187c, x86_l_187c);
x86_l_1856:
	/* 0x1856: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1859:
	/* 0x1859: jns    18c8 <process_execute_failed_tail+0x18c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1859, 0x18c8, x86_l_18c8);
x86_l_185b:
	/* 0x185b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_185d:
	/* 0x185d: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1864:
	/* 0x1864: je     18d6 <process_execute_failed_tail+0x18d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1864, 0x18d6, x86_l_18d6);
x86_l_1866:
	/* 0x1866: lea    rcx,[rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_186a:
	/* 0x186a: movzx  esi,BYTE PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_186e:
	/* 0x186e: mov    BYTE PTR [rdi+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1872:
	/* 0x1872: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1875:
	/* 0x1875: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_1878:
	/* 0x1878: jne    185d <process_execute_failed_tail+0x185d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1878, 0x185d, x86_l_185d);
x86_l_187a:
	/* 0x187a: jmp    188c <process_execute_failed_tail+0x188c> */
	X86_SIM_X86_JMP(0x187a, 0x188c, x86_l_188c);
x86_l_187c:
	/* 0x187c: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1881:
	/* 0x1881: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1884:
	/* 0x1884: call   1889 <process_execute_failed_tail+0x1889> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1889:
	/* 0x1889: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_188c:
	/* 0x188c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_188f:
	/* 0x188f: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1891:
	/* 0x1891: jle    18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1891, 0x18f8, x86_l_18f8);
x86_l_1893:
	/* 0x1893: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_189b:
	/* 0x189b: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_18a2:
	/* 0x18a2: ja     18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x18a2, 0x18f8, x86_l_18f8);
x86_l_18a4:
	/* 0x18a4: mov    DWORD PTR [rdx+r14*1+0x8a],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_18ac:
	/* 0x18ac: add    ax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_18b4:
	/* 0x18b4: add    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_18b7:
	/* 0x18b7: mov    WORD PTR [r14+0x7d8a],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_18bf:
	/* 0x18bf: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_18c6:
	/* 0x18c6: jmp    18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JMP(0x18c6, 0x18f8, x86_l_18f8);
x86_l_18c8:
	/* 0x18c8: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_18cd:
	/* 0x18cd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18cf:
	/* 0x18cf: call   18d4 <process_execute_failed_tail+0x18d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_18d4:
	/* 0x18d4: jmp    18f8 <process_execute_failed_tail+0x18f8> */
	X86_SIM_X86_JMP(0x18d4, 0x18f8, x86_l_18f8);
x86_l_18d6:
	/* 0x18d6: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_18dd:
	/* 0x18dd: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_18e2:
	/* 0x18e2: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_18e7:
	/* 0x18e7: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_18ef:
	/* 0x18ef: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_18f6:
	/* 0x18f6: jbe    18a4 <process_execute_failed_tail+0x18a4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x18f6, 0x18a4, x86_l_18a4);
x86_l_18f8:
	/* 0x18f8: add    r13,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_18fc:
	/* 0x18fc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18fe:
	/* 0x18fe: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1901:
	/* 0x1901: jns    1912 <process_execute_failed_tail+0x1912> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1901, 0x1912, x86_l_1912);
x86_l_1903:
	/* 0x1903: mov    rcx,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1907:
	/* 0x1907: add    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_190b:
	/* 0x190b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_190e:
	/* 0x190e: js     191d <process_execute_failed_tail+0x191d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x190e, 0x191d, x86_l_191d);
x86_l_1910:
	/* 0x1910: jmp    191f <process_execute_failed_tail+0x191f> */
	X86_SIM_X86_JMP(0x1910, 0x191f, x86_l_191f);
x86_l_1912:
	/* 0x1912: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1914:
	/* 0x1914: add    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1918:
	/* 0x1918: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_191b:
	/* 0x191b: jns    191f <process_execute_failed_tail+0x191f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x191b, 0x191f, x86_l_191f);
x86_l_191d:
	/* 0x191d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_191f:
	/* 0x191f: shr    eax,0x15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 21ULL);
x86_l_1922:
	/* 0x1922: and    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_1925:
	/* 0x1925: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1929:
	/* 0x1929: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1931:
	/* 0x1931: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1938:
	/* 0x1938: ja     1999 <process_execute_failed_tail+0x1999> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1938, 0x1999, x86_l_1999);
x86_l_193a:
	/* 0x193a: mov    BYTE PTR [r14+rbx*1+0x89],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519563ULL);
x86_l_1943:
	/* 0x1943: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_1949:
	/* 0x1949: ja     1999 <process_execute_failed_tail+0x1999> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1949, 0x1999, x86_l_1999);
x86_l_194b:
	/* 0x194b: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_194f:
	/* 0x194f: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1956:
	/* 0x1956: lea    rax,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_195b:
	/* 0x195b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_195e:
	/* 0x195e: jns    196b <process_execute_failed_tail+0x196b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x195e, 0x196b, x86_l_196b);
x86_l_1960:
	/* 0x1960: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1963:
	/* 0x1963: jns    1993 <process_execute_failed_tail+0x1993> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1963, 0x1993, x86_l_1993);
x86_l_1965:
	/* 0x1965: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1967:
	/* 0x1967: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1969:
	/* 0x1969: jmp    197f <process_execute_failed_tail+0x197f> */
	X86_SIM_X86_JMP(0x1969, 0x197f, x86_l_197f);
x86_l_196b:
	/* 0x196b: lea    rdx,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1970:
	/* 0x1970: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1975:
	/* 0x1975: call   197a <process_execute_failed_tail+0x197a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_197a:
	/* 0x197a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_197d:
	/* 0x197d: js     1999 <process_execute_failed_tail+0x1999> */
	X86_SIM_X86_JCC(X86_CC_S, 0x197d, 0x1999, x86_l_1999);
x86_l_197f:
	/* 0x197f: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1982:
	/* 0x1982: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_198a:
	/* 0x198a: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1991:
	/* 0x1991: jmp    1999 <process_execute_failed_tail+0x1999> */
	X86_SIM_X86_JMP(0x1991, 0x1999, x86_l_1999);
x86_l_1993:
	/* 0x1993: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1999:
	/* 0x1999: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_19a0:
	/* 0x19a0: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19a4:
	/* 0x19a4: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_19a7:
	/* 0x19a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19aa:
	/* 0x19aa: jns    19bc <process_execute_failed_tail+0x19bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19aa, 0x19bc, x86_l_19bc);
x86_l_19ac:
	/* 0x19ac: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19af:
	/* 0x19af: lea    rax,[r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19b3:
	/* 0x19b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19b6:
	/* 0x19b6: js     19c8 <process_execute_failed_tail+0x19c8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19b6, 0x19c8, x86_l_19c8);
x86_l_19b8:
	/* 0x19b8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19ba:
	/* 0x19ba: jmp    19cb <process_execute_failed_tail+0x19cb> */
	X86_SIM_X86_JMP(0x19ba, 0x19cb, x86_l_19cb);
x86_l_19bc:
	/* 0x19bc: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19bf:
	/* 0x19bf: lea    rax,[r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19c3:
	/* 0x19c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19c6:
	/* 0x19c6: jns    19b8 <process_execute_failed_tail+0x19b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19c6, 0x19b8, x86_l_19b8);
x86_l_19c8:
	/* 0x19c8: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19cb:
	/* 0x19cb: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_19cf:
	/* 0x19cf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19d1:
	/* 0x19d1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19d4:
	/* 0x19d4: jns    19e4 <process_execute_failed_tail+0x19e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19d4, 0x19e4, x86_l_19e4);
x86_l_19d6:
	/* 0x19d6: mov    rbp,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19d9:
	/* 0x19d9: lea    rdx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19dd:
	/* 0x19dd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19e0:
	/* 0x19e0: js     19ef <process_execute_failed_tail+0x19ef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19e0, 0x19ef, x86_l_19ef);
x86_l_19e2:
	/* 0x19e2: jmp    19f1 <process_execute_failed_tail+0x19f1> */
	X86_SIM_X86_JMP(0x19e2, 0x19f1, x86_l_19f1);
x86_l_19e4:
	/* 0x19e4: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19e6:
	/* 0x19e6: lea    rdx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19ea:
	/* 0x19ea: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19ed:
	/* 0x19ed: jns    19f1 <process_execute_failed_tail+0x19f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19ed, 0x19f1, x86_l_19f1);
x86_l_19ef:
	/* 0x19ef: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f1:
	/* 0x19f1: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_19f5:
	/* 0x19f5: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19f9:
	/* 0x19f9: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19fc:
	/* 0x19fc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19fe:
	/* 0x19fe: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a01:
	/* 0x1a01: jns    1a10 <process_execute_failed_tail+0x1a10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a01, 0x1a10, x86_l_1a10);
x86_l_1a03:
	/* 0x1a03: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a06:
	/* 0x1a06: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a09:
	/* 0x1a09: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a0c:
	/* 0x1a0c: js     1a1a <process_execute_failed_tail+0x1a1a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a0c, 0x1a1a, x86_l_1a1a);
x86_l_1a0e:
	/* 0x1a0e: jmp    1a1c <process_execute_failed_tail+0x1a1c> */
	X86_SIM_X86_JMP(0x1a0e, 0x1a1c, x86_l_1a1c);
x86_l_1a10:
	/* 0x1a10: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a12:
	/* 0x1a12: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a15:
	/* 0x1a15: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a18:
	/* 0x1a18: jns    1a1c <process_execute_failed_tail+0x1a1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a18, 0x1a1c, x86_l_1a1c);
x86_l_1a1a:
	/* 0x1a1a: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a1c:
	/* 0x1a1c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1a1e:
	/* 0x1a1e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1a22:
	/* 0x1a22: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a25:
	/* 0x1a25: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a29:
	/* 0x1a29: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a2b:
	/* 0x1a2b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a2e:
	/* 0x1a2e: jns    1a32 <process_execute_failed_tail+0x1a32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a2e, 0x1a32, x86_l_1a32);
x86_l_1a30:
	/* 0x1a30: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a32:
	/* 0x1a32: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a36:
	/* 0x1a36: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a39:
	/* 0x1a39: jns    1a40 <process_execute_failed_tail+0x1a40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a39, 0x1a40, x86_l_1a40);
x86_l_1a3b:
	/* 0x1a3b: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a3e:
	/* 0x1a3e: jmp    1a42 <process_execute_failed_tail+0x1a42> */
	X86_SIM_X86_JMP(0x1a3e, 0x1a42, x86_l_1a42);
x86_l_1a40:
	/* 0x1a40: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a42:
	/* 0x1a42: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1a46:
	/* 0x1a46: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a48:
	/* 0x1a48: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a4b:
	/* 0x1a4b: jns    1a5a <process_execute_failed_tail+0x1a5a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a4b, 0x1a5a, x86_l_1a5a);
x86_l_1a4d:
	/* 0x1a4d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a50:
	/* 0x1a50: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a53:
	/* 0x1a53: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a56:
	/* 0x1a56: js     1a64 <process_execute_failed_tail+0x1a64> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a56, 0x1a64, x86_l_1a64);
x86_l_1a58:
	/* 0x1a58: jmp    1a66 <process_execute_failed_tail+0x1a66> */
	X86_SIM_X86_JMP(0x1a58, 0x1a66, x86_l_1a66);
x86_l_1a5a:
	/* 0x1a5a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a5c:
	/* 0x1a5c: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a5f:
	/* 0x1a5f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a62:
	/* 0x1a62: jns    1a66 <process_execute_failed_tail+0x1a66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a62, 0x1a66, x86_l_1a66);
x86_l_1a64:
	/* 0x1a64: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a66:
	/* 0x1a66: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1a68:
	/* 0x1a68: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1a6c:
	/* 0x1a6c: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a6f:
	/* 0x1a6f: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a73:
	/* 0x1a73: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a75:
	/* 0x1a75: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a78:
	/* 0x1a78: jns    1a7c <process_execute_failed_tail+0x1a7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a78, 0x1a7c, x86_l_1a7c);
x86_l_1a7a:
	/* 0x1a7a: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a7c:
	/* 0x1a7c: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a80:
	/* 0x1a80: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a82:
	/* 0x1a82: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a85:
	/* 0x1a85: jns    1a94 <process_execute_failed_tail+0x1a94> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a85, 0x1a94, x86_l_1a94);
x86_l_1a87:
	/* 0x1a87: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a8a:
	/* 0x1a8a: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a8d:
	/* 0x1a8d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a90:
	/* 0x1a90: js     1a9e <process_execute_failed_tail+0x1a9e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a90, 0x1a9e, x86_l_1a9e);
x86_l_1a92:
	/* 0x1a92: jmp    1aa0 <process_execute_failed_tail+0x1aa0> */
	X86_SIM_X86_JMP(0x1a92, 0x1aa0, x86_l_1aa0);
x86_l_1a94:
	/* 0x1a94: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a96:
	/* 0x1a96: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a99:
	/* 0x1a99: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a9c:
	/* 0x1a9c: jns    1aa0 <process_execute_failed_tail+0x1aa0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a9c, 0x1aa0, x86_l_1aa0);
x86_l_1a9e:
	/* 0x1a9e: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aa0:
	/* 0x1aa0: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1aa2:
	/* 0x1aa2: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1aa6:
	/* 0x1aa6: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1aa9:
	/* 0x1aa9: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1aad:
	/* 0x1aad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aaf:
	/* 0x1aaf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ab2:
	/* 0x1ab2: jns    1ac2 <process_execute_failed_tail+0x1ac2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ab2, 0x1ac2, x86_l_1ac2);
x86_l_1ab4:
	/* 0x1ab4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab7:
	/* 0x1ab7: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1abb:
	/* 0x1abb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1abe:
	/* 0x1abe: js     1acd <process_execute_failed_tail+0x1acd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1abe, 0x1acd, x86_l_1acd);
x86_l_1ac0:
	/* 0x1ac0: jmp    1acf <process_execute_failed_tail+0x1acf> */
	X86_SIM_X86_JMP(0x1ac0, 0x1acf, x86_l_1acf);
x86_l_1ac2:
	/* 0x1ac2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac4:
	/* 0x1ac4: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1ac8:
	/* 0x1ac8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1acb:
	/* 0x1acb: jns    1acf <process_execute_failed_tail+0x1acf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1acb, 0x1acf, x86_l_1acf);
x86_l_1acd:
	/* 0x1acd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1acf:
	/* 0x1acf: lea    rcx,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ad3:
	/* 0x1ad3: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ad6:
	/* 0x1ad6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ad8:
	/* 0x1ad8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1adb:
	/* 0x1adb: jns    1aea <process_execute_failed_tail+0x1aea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1adb, 0x1aea, x86_l_1aea);
x86_l_1add:
	/* 0x1add: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ae0:
	/* 0x1ae0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ae3:
	/* 0x1ae3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ae6:
	/* 0x1ae6: js     1af4 <process_execute_failed_tail+0x1af4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ae6, 0x1af4, x86_l_1af4);
x86_l_1ae8:
	/* 0x1ae8: jmp    1af6 <process_execute_failed_tail+0x1af6> */
	X86_SIM_X86_JMP(0x1ae8, 0x1af6, x86_l_1af6);
x86_l_1aea:
	/* 0x1aea: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aec:
	/* 0x1aec: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1aef:
	/* 0x1aef: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1af2:
	/* 0x1af2: jns    1af6 <process_execute_failed_tail+0x1af6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af2, 0x1af6, x86_l_1af6);
x86_l_1af4:
	/* 0x1af4: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af6:
	/* 0x1af6: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1af8:
	/* 0x1af8: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1afc:
	/* 0x1afc: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1aff:
	/* 0x1aff: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1b03:
	/* 0x1b03: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b05:
	/* 0x1b05: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b08:
	/* 0x1b08: jns    1b18 <process_execute_failed_tail+0x1b18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b08, 0x1b18, x86_l_1b18);
x86_l_1b0a:
	/* 0x1b0a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b0d:
	/* 0x1b0d: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1b11:
	/* 0x1b11: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b14:
	/* 0x1b14: js     1b23 <process_execute_failed_tail+0x1b23> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b14, 0x1b23, x86_l_1b23);
x86_l_1b16:
	/* 0x1b16: jmp    1b25 <process_execute_failed_tail+0x1b25> */
	X86_SIM_X86_JMP(0x1b16, 0x1b25, x86_l_1b25);
x86_l_1b18:
	/* 0x1b18: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b1a:
	/* 0x1b1a: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1b1e:
	/* 0x1b1e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b21:
	/* 0x1b21: jns    1b25 <process_execute_failed_tail+0x1b25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b21, 0x1b25, x86_l_1b25);
x86_l_1b23:
	/* 0x1b23: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b25:
	/* 0x1b25: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1b27:
	/* 0x1b27: jne    1b63 <process_execute_failed_tail+0x1b63> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b27, 0x1b63, x86_l_1b63);
x86_l_1b29:
	/* 0x1b29: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b2b:
	/* 0x1b2b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b2e:
	/* 0x1b2e: jns    1b3d <process_execute_failed_tail+0x1b3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b2e, 0x1b3d, x86_l_1b3d);
x86_l_1b30:
	/* 0x1b30: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b33:
	/* 0x1b33: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b36:
	/* 0x1b36: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b39:
	/* 0x1b39: js     1b47 <process_execute_failed_tail+0x1b47> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b39, 0x1b47, x86_l_1b47);
x86_l_1b3b:
	/* 0x1b3b: jmp    1b49 <process_execute_failed_tail+0x1b49> */
	X86_SIM_X86_JMP(0x1b3b, 0x1b49, x86_l_1b49);
x86_l_1b3d:
	/* 0x1b3d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b3f:
	/* 0x1b3f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b42:
	/* 0x1b42: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b45:
	/* 0x1b45: jns    1b49 <process_execute_failed_tail+0x1b49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b45, 0x1b49, x86_l_1b49);
x86_l_1b47:
	/* 0x1b47: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b49:
	/* 0x1b49: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1b4b:
	/* 0x1b4b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1b4f:
	/* 0x1b4f: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b52:
	/* 0x1b52: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1b56:
	/* 0x1b56: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b58:
	/* 0x1b58: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b5b:
	/* 0x1b5b: jns    1b5f <process_execute_failed_tail+0x1b5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b5b, 0x1b5f, x86_l_1b5f);
x86_l_1b5d:
	/* 0x1b5d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b5f:
	/* 0x1b5f: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b63:
	/* 0x1b63: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1b67:
	/* 0x1b67: lea    r12,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1b6e:
	/* 0x1b6e: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1b71:
	/* 0x1b71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b74:
	/* 0x1b74: jns    1b7b <process_execute_failed_tail+0x1b7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b74, 0x1b7b, x86_l_1b7b);
x86_l_1b76:
	/* 0x1b76: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b79:
	/* 0x1b79: jmp    1b7d <process_execute_failed_tail+0x1b7d> */
	X86_SIM_X86_JMP(0x1b79, 0x1b7d, x86_l_1b7d);
x86_l_1b7b:
	/* 0x1b7b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b7d:
	/* 0x1b7d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1b81:
	/* 0x1b81: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b83:
	/* 0x1b83: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b86:
	/* 0x1b86: jns    1b92 <process_execute_failed_tail+0x1b92> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b86, 0x1b92, x86_l_1b92);
x86_l_1b88:
	/* 0x1b88: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b8b:
	/* 0x1b8b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b8e:
	/* 0x1b8e: js     1b99 <process_execute_failed_tail+0x1b99> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b8e, 0x1b99, x86_l_1b99);
x86_l_1b90:
	/* 0x1b90: jmp    1b9b <process_execute_failed_tail+0x1b9b> */
	X86_SIM_X86_JMP(0x1b90, 0x1b9b, x86_l_1b9b);
x86_l_1b92:
	/* 0x1b92: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b94:
	/* 0x1b94: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b97:
	/* 0x1b97: jns    1b9b <process_execute_failed_tail+0x1b9b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b97, 0x1b9b, x86_l_1b9b);
x86_l_1b99:
	/* 0x1b99: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9b:
	/* 0x1b9b: lea    r15,[r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b9f:
	/* 0x1b9f: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1ba3:
	/* 0x1ba3: call   1ba8 <process_execute_failed_tail+0x1ba8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1ba8:
	/* 0x1ba8: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bac:
	/* 0x1bac: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1bb0:
	/* 0x1bb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bb3:
	/* 0x1bb3: jns    1bba <process_execute_failed_tail+0x1bba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bb3, 0x1bba, x86_l_1bba);
x86_l_1bb5:
	/* 0x1bb5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bb8:
	/* 0x1bb8: jmp    1bbc <process_execute_failed_tail+0x1bbc> */
	X86_SIM_X86_JMP(0x1bb8, 0x1bbc, x86_l_1bbc);
x86_l_1bba:
	/* 0x1bba: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bbc:
	/* 0x1bbc: mov    QWORD PTR [r15],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bbf:
	/* 0x1bbf: add    r13,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1bc3:
	/* 0x1bc3: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1bc6:
	/* 0x1bc6: jns    1bce <process_execute_failed_tail+0x1bce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bc6, 0x1bce, x86_l_1bce);
x86_l_1bc8:
	/* 0x1bc8: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bcc:
	/* 0x1bcc: jmp    1bd0 <process_execute_failed_tail+0x1bd0> */
	X86_SIM_X86_JMP(0x1bcc, 0x1bd0, x86_l_1bd0);
x86_l_1bce:
	/* 0x1bce: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bd0:
	/* 0x1bd0: mov    r13,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bd5:
	/* 0x1bd5: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1bd9:
	/* 0x1bd9: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1bdd:
	/* 0x1bdd: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1be0:
	/* 0x1be0: jns    1bf1 <process_execute_failed_tail+0x1bf1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1be0, 0x1bf1, x86_l_1bf1);
x86_l_1be2:
	/* 0x1be2: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1be6:
	/* 0x1be6: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1bea:
	/* 0x1bea: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bed:
	/* 0x1bed: js     1bfc <process_execute_failed_tail+0x1bfc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bed, 0x1bfc, x86_l_1bfc);
x86_l_1bef:
	/* 0x1bef: jmp    1c07 <process_execute_failed_tail+0x1c07> */
	X86_SIM_X86_JMP(0x1bef, 0x1c07, x86_l_1c07);
x86_l_1bf1:
	/* 0x1bf1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bf3:
	/* 0x1bf3: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1bf7:
	/* 0x1bf7: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bfa:
	/* 0x1bfa: jns    1c07 <process_execute_failed_tail+0x1c07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bfa, 0x1c07, x86_l_1c07);
x86_l_1bfc:
	/* 0x1bfc: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bfe:
	/* 0x1bfe: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c00:
	/* 0x1c00: je     1c07 <process_execute_failed_tail+0x1c07> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c00, 0x1c07, x86_l_1c07);
x86_l_1c02:
	/* 0x1c02: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_1c07:
	/* 0x1c07: lea    rdi,[r14+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1c0b:
	/* 0x1c0b: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_1c13:
	/* 0x1c13: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_1c1b:
	/* 0x1c1b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1c20:
	/* 0x1c20: call   1c25 <process_execute_failed_tail+0x1c25> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_1c25:
	/* 0x1c25: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1c28:
	/* 0x1c28: jns    1c3c <process_execute_failed_tail+0x1c3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c28, 0x1c3c, x86_l_1c3c);
x86_l_1c2a:
	/* 0x1c2a: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c2e:
	/* 0x1c2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c31:
	/* 0x1c31: js     1c43 <process_execute_failed_tail+0x1c43> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c31, 0x1c43, x86_l_1c43);
x86_l_1c33:
	/* 0x1c33: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c35:
	/* 0x1c35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c38:
	/* 0x1c38: js     1c4b <process_execute_failed_tail+0x1c4b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c38, 0x1c4b, x86_l_1c4b);
x86_l_1c3a:
	/* 0x1c3a: jmp    1c8c <process_execute_failed_tail+0x1c8c> */
	X86_SIM_X86_JMP(0x1c3a, 0x1c8c, x86_l_1c8c);
x86_l_1c3c:
	/* 0x1c3c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c3e:
	/* 0x1c3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c41:
	/* 0x1c41: jns    1c33 <process_execute_failed_tail+0x1c33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c41, 0x1c33, x86_l_1c33);
x86_l_1c43:
	/* 0x1c43: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c46:
	/* 0x1c46: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c49:
	/* 0x1c49: jns    1c8c <process_execute_failed_tail+0x1c8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c49, 0x1c8c, x86_l_1c8c);
x86_l_1c4b:
	/* 0x1c4b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c4e:
	/* 0x1c4e: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c53:
	/* 0x1c53: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c57:
	/* 0x1c57: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1c5c:
	/* 0x1c5c: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c60:
	/* 0x1c60: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c65:
	/* 0x1c65: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c69:
	/* 0x1c69: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1c6e:
	/* 0x1c6e: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c72:
	/* 0x1c72: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c77:
	/* 0x1c77: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c7b:
	/* 0x1c7b: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1c80:
	/* 0x1c80: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c84:
	/* 0x1c84: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1c88:
	/* 0x1c88: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1c8c:
	/* 0x1c8c: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c8f:
	/* 0x1c8f: add    rcx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_1c93:
	/* 0x1c93: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c98:
	/* 0x1c98: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c9b:
	/* 0x1c9b: jns    1d71 <process_execute_failed_tail+0x1d71> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c9b, 0x1d71, x86_l_1d71);
x86_l_1ca1:
	/* 0x1ca1: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1ca4:
	/* 0x1ca4: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca6:
	/* 0x1ca6: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1ca8:
	/* 0x1ca8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ca8, 0x1d80, x86_l_1d80);
x86_l_1cae:
	/* 0x1cae: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1cb2:
	/* 0x1cb2: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_1cb6:
	/* 0x1cb6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1cb8:
	/* 0x1cb8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cb8, 0x1d80, x86_l_1d80);
x86_l_1cbe:
	/* 0x1cbe: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1cc2:
	/* 0x1cc2: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1cc6:
	/* 0x1cc6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1cc8:
	/* 0x1cc8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc8, 0x1d80, x86_l_1d80);
x86_l_1cce:
	/* 0x1cce: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1cd2:
	/* 0x1cd2: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1cd6:
	/* 0x1cd6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1cd8:
	/* 0x1cd8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd8, 0x1d80, x86_l_1d80);
x86_l_1cde:
	/* 0x1cde: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1ce2:
	/* 0x1ce2: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ce6:
	/* 0x1ce6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ce8:
	/* 0x1ce8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce8, 0x1d80, x86_l_1d80);
x86_l_1cee:
	/* 0x1cee: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1cf2:
	/* 0x1cf2: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1cf6:
	/* 0x1cf6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1cf8:
	/* 0x1cf8: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cf8, 0x1d80, x86_l_1d80);
x86_l_1cfe:
	/* 0x1cfe: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1d02:
	/* 0x1d02: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1d06:
	/* 0x1d06: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d08:
	/* 0x1d08: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d08, 0x1d80, x86_l_1d80);
x86_l_1d0a:
	/* 0x1d0a: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_1d0e:
	/* 0x1d0e: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_1d12:
	/* 0x1d12: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d14:
	/* 0x1d14: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d14, 0x1d80, x86_l_1d80);
x86_l_1d16:
	/* 0x1d16: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1d1a:
	/* 0x1d1a: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_1d1e:
	/* 0x1d1e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d20:
	/* 0x1d20: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d20, 0x1d80, x86_l_1d80);
x86_l_1d22:
	/* 0x1d22: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1d26:
	/* 0x1d26: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_1d2a:
	/* 0x1d2a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d2c:
	/* 0x1d2c: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d2c, 0x1d80, x86_l_1d80);
x86_l_1d2e:
	/* 0x1d2e: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_1d32:
	/* 0x1d32: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_1d36:
	/* 0x1d36: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d38:
	/* 0x1d38: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d38, 0x1d80, x86_l_1d80);
x86_l_1d3a:
	/* 0x1d3a: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1d3e:
	/* 0x1d3e: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_1d42:
	/* 0x1d42: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d44:
	/* 0x1d44: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d44, 0x1d80, x86_l_1d80);
x86_l_1d46:
	/* 0x1d46: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1d4a:
	/* 0x1d4a: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1d4e:
	/* 0x1d4e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d50:
	/* 0x1d50: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d50, 0x1d80, x86_l_1d80);
x86_l_1d52:
	/* 0x1d52: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1d56:
	/* 0x1d56: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_1d5a:
	/* 0x1d5a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d5c:
	/* 0x1d5c: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5c, 0x1d80, x86_l_1d80);
x86_l_1d5e:
	/* 0x1d5e: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1d62:
	/* 0x1d62: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_1d66:
	/* 0x1d66: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1d68:
	/* 0x1d68: je     1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d68, 0x1d80, x86_l_1d80);
x86_l_1d6a:
	/* 0x1d6a: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_1d6f:
	/* 0x1d6f: jmp    1d80 <process_execute_failed_tail+0x1d80> */
	X86_SIM_X86_JMP(0x1d6f, 0x1d80, x86_l_1d80);
x86_l_1d71:
	/* 0x1d71: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1d79:
	/* 0x1d79: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d80:
	/* 0x1d80: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1d83:
	/* 0x1d83: jns    1e09 <process_execute_failed_tail+0x1e09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d83, 0x1e09, x86_l_1e09);
x86_l_1d89:
	/* 0x1d89: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d8c:
	/* 0x1d8c: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d90:
	/* 0x1d90: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d94:
	/* 0x1d94: mov    QWORD PTR [r13+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d98:
	/* 0x1d98: mov    rax,QWORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d9c:
	/* 0x1d9c: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1da0:
	/* 0x1da0: mov    rax,QWORD PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1da4:
	/* 0x1da4: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1da8:
	/* 0x1da8: mov    rax,QWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1dac:
	/* 0x1dac: mov    QWORD PTR [r13+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1db0:
	/* 0x1db0: mov    rax,QWORD PTR [r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1db4:
	/* 0x1db4: mov    QWORD PTR [r13+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1db8:
	/* 0x1db8: mov    rax,QWORD PTR [r15+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1dbc:
	/* 0x1dbc: mov    QWORD PTR [r13+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1dc0:
	/* 0x1dc0: mov    rax,QWORD PTR [r15+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1dc4:
	/* 0x1dc4: mov    QWORD PTR [r13+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1dc8:
	/* 0x1dc8: mov    rax,QWORD PTR [r15+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dcc:
	/* 0x1dcc: mov    QWORD PTR [r13+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dd0:
	/* 0x1dd0: mov    rax,QWORD PTR [r15+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1dd4:
	/* 0x1dd4: mov    QWORD PTR [r13+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1dd8:
	/* 0x1dd8: mov    rax,QWORD PTR [r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ddc:
	/* 0x1ddc: mov    QWORD PTR [r13+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1de0:
	/* 0x1de0: mov    rax,QWORD PTR [r15+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1de4:
	/* 0x1de4: mov    QWORD PTR [r13+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1de8:
	/* 0x1de8: mov    rax,QWORD PTR [r15+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1dec:
	/* 0x1dec: mov    QWORD PTR [r13+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1df0:
	/* 0x1df0: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1df5:
	/* 0x1df5: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1dfa:
	/* 0x1dfa: test   BYTE PTR [rax+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_1dfe:
	/* 0x1dfe: jne    1e81 <process_execute_failed_tail+0x1e81> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dfe, 0x1e81, x86_l_1e81);
x86_l_1e04:
	/* 0x1e04: jmp    1e9d <process_execute_failed_tail+0x1e9d> */
	X86_SIM_X86_JMP(0x1e04, 0x1e9d, x86_l_1e9d);
x86_l_1e09:
	/* 0x1e09: mov    QWORD PTR [r13+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1e11:
	/* 0x1e11: mov    QWORD PTR [r13+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_1e19:
	/* 0x1e19: mov    QWORD PTR [r13+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1e21:
	/* 0x1e21: mov    QWORD PTR [r13+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1e29:
	/* 0x1e29: mov    QWORD PTR [r13+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1e31:
	/* 0x1e31: mov    QWORD PTR [r13+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1e39:
	/* 0x1e39: mov    QWORD PTR [r13+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1e41:
	/* 0x1e41: mov    QWORD PTR [r13+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1e49:
	/* 0x1e49: mov    QWORD PTR [r13+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1e51:
	/* 0x1e51: mov    QWORD PTR [r13+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1e59:
	/* 0x1e59: mov    QWORD PTR [r13+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1e61:
	/* 0x1e61: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1e69:
	/* 0x1e69: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e71:
	/* 0x1e71: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e76:
	/* 0x1e76: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e7b:
	/* 0x1e7b: test   BYTE PTR [rax+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_1e7f:
	/* 0x1e7f: je     1e9d <process_execute_failed_tail+0x1e9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e7f, 0x1e9d, x86_l_1e9d);
x86_l_1e81:
	/* 0x1e81: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_1e88:
	/* 0x1e88: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1e8d:
	/* 0x1e8d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e90:
	/* 0x1e90: call   1e95 <process_execute_failed_tail+0x1e95> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_1e95:
	/* 0x1e95: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1e97:
	/* 0x1e97: js     1e9d <process_execute_failed_tail+0x1e9d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e97, 0x1e9d, x86_l_1e9d);
x86_l_1e99:
	/* 0x1e99: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1e9d:
	/* 0x1e9d: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1ea5:
	/* 0x1ea5: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1eaa:
	/* 0x1eaa: jb     1eb1 <process_execute_failed_tail+0x1eb1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1eaa, 0x1eb1, x86_l_1eb1);
x86_l_1eac:
	/* 0x1eac: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1eb1:
	/* 0x1eb1: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_1eb6:
	/* 0x1eb6: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1eba:
	/* 0x1eba: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_1ec1:
	/* 0x1ec1: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1ec6:
	/* 0x1ec6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ec9:
	/* 0x1ec9: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ecc:
	/* 0x1ecc: call   1ed1 <process_execute_failed_tail+0x1ed1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_1ed1:
	/* 0x1ed1: add    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_1ed5:
	/* 0x1ed5: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ed6:
	/* 0x1ed6: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ed8:
	/* 0x1ed8: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1eda:
	/* 0x1eda: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1edc:
	/* 0x1edc: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ede:
	/* 0x1ede: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1edf:
	/* 0x1edf: jmp    1f96 <process_execute_failed_tail+0x1f96> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1ee4:
	/* 0x1ee4: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ee7:
	/* 0x1ee7: jne    1f8e <process_execute_failed_tail+0x1f8e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee7, 0x1f8e, x86_l_1f8e);
x86_l_1eed:
	/* 0x1eed: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ef0:
	/* 0x1ef0: je     1f8e <process_execute_failed_tail+0x1f8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef0, 0x1f8e, x86_l_1f8e);
x86_l_1ef6:
	/* 0x1ef6: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1efa:
	/* 0x1efa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1efd:
	/* 0x1efd: jns    1f43 <process_execute_failed_tail+0x1f43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1efd, 0x1f43, x86_l_1f43);
x86_l_1eff:
	/* 0x1eff: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f02:
	/* 0x1f02: jmp    1f45 <process_execute_failed_tail+0x1f45> */
	X86_SIM_X86_JMP(0x1f02, 0x1f45, x86_l_1f45);
x86_l_1f04:
	/* 0x1f04: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1f07:
	/* 0x1f07: je     1f8e <process_execute_failed_tail+0x1f8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f07, 0x1f8e, x86_l_1f8e);
x86_l_1f0d:
	/* 0x1f0d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f13:
	/* 0x1f13: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1f18:
	/* 0x1f18: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f1b:
	/* 0x1f1b: jns    1f62 <process_execute_failed_tail+0x1f62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f1b, 0x1f62, x86_l_1f62);
x86_l_1f1d:
	/* 0x1f1d: lea    edx,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f21:
	/* 0x1f21: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f24:
	/* 0x1f24: cmp    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f27:
	/* 0x1f27: je     1f6a <process_execute_failed_tail+0x1f6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f27, 0x1f6a, x86_l_1f6a);
x86_l_1f29:
	/* 0x1f29: lea    r10,[r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f2d:
	/* 0x1f2d: movzx  r11d,BYTE PTR [rcx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_1f32:
	/* 0x1f32: mov    BYTE PTR [rdi+r8*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1f36:
	/* 0x1f36: mov    r8,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1f39:
	/* 0x1f39: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_1f3c:
	/* 0x1f3c: jne    1f24 <process_execute_failed_tail+0x1f24> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f3c, 0x1f24, x86_l_1f24);
x86_l_1f3e:
	/* 0x1f3e: mov    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_1f41:
	/* 0x1f41: jmp    1f6e <process_execute_failed_tail+0x1f6e> */
	X86_SIM_X86_JMP(0x1f41, 0x1f6e, x86_l_1f6e);
x86_l_1f43:
	/* 0x1f43: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f45:
	/* 0x1f45: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f48:
	/* 0x1f48: jns    1f4f <process_execute_failed_tail+0x1f4f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f48, 0x1f4f, x86_l_1f4f);
x86_l_1f4a:
	/* 0x1f4a: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f4d:
	/* 0x1f4d: jmp    1f51 <process_execute_failed_tail+0x1f51> */
	X86_SIM_X86_JMP(0x1f4d, 0x1f51, x86_l_1f51);
x86_l_1f4f:
	/* 0x1f4f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f51:
	/* 0x1f51: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f54:
	/* 0x1f54: jns    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f54, 0x7f5, x86_l_7f5);
x86_l_1f5a:
	/* 0x1f5a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5d:
	/* 0x1f5d: jmp    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JMP(0x1f5d, 0x7f5, x86_l_7f5);
x86_l_1f62:
	/* 0x1f62: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f65:
	/* 0x1f65: jmp    7e8 <process_execute_failed_tail+0x7e8> */
	X86_SIM_X86_JMP(0x1f65, 0x7e8, x86_l_7e8);
x86_l_1f6a:
	/* 0x1f6a: mov    BYTE PTR [rdi+rdx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1f6e:
	/* 0x1f6e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f72:
	/* 0x1f72: jl     1f8e <process_execute_failed_tail+0x1f8e> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f72, 0x1f8e, x86_l_1f8e);
x86_l_1f74:
	/* 0x1f74: lea    ecx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f77:
	/* 0x1f77: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f7d:
	/* 0x1f7d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f82:
	/* 0x1f82: mov    BYTE PTR [rax+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_1f86:
	/* 0x1f86: sub    ebp,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f89:
	/* 0x1f89: jmp    7fa <process_execute_failed_tail+0x7fa> */
	X86_SIM_X86_JMP(0x1f89, 0x7fa, x86_l_7fa);
x86_l_1f8e:
	/* 0x1f8e: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f91:
	/* 0x1f91: jmp    7f5 <process_execute_failed_tail+0x7f5> */
	X86_SIM_X86_JMP(0x1f91, 0x7f5, x86_l_7f5);
x86_l_1f96:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
