#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 232U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(15) M(17) M(18) M(19) M(22)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 sys_exit_tails[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[64] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x58, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(314):.rodata:table_10\",\"size\":64}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/sys_exit_submit")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xac],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2e:
	/* 0x2e: call   33 <sys_exit_submit+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x2896, x86_l_2896);
x86_l_3c:
	/* 0x3c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_4e:
	/* 0x4e: call   53 <sys_exit_submit+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x2896, x86_l_2896);
x86_l_5c:
	/* 0x5c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r14,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9e:
	/* 0x9e: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a9:
	/* 0xa9: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b4:
	/* 0xb4: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bf:
	/* 0xbf: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ca:
	/* 0xca: call   cf <sys_exit_submit+0xcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f6:
	/* 0xf6: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_116:
	/* 0x116: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11e:
	/* 0x11e: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12e:
	/* 0x12e: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13e:
	/* 0x13e: call   143 <sys_exit_submit+0x143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_143:
	/* 0x143: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [rbp+0x70],0x31b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337947ULL);
x86_l_154:
	/* 0x154: call   159 <sys_exit_submit+0x159> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d:
	/* 0x15d: call   162 <sys_exit_submit+0x162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_162:
	/* 0x162: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_166:
	/* 0x166: call   16b <sys_exit_submit+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16b:
	/* 0x16b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: jns    186 <sys_exit_submit+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175, 0x186, x86_l_186);
x86_l_177:
	/* 0x177: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17e:
	/* 0x17e: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_184:
	/* 0x184: jne    1c3 <sys_exit_submit+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184, 0x1c3, x86_l_1c3);
x86_l_186:
	/* 0x186: call   18b <sys_exit_submit+0x18b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18b:
	/* 0x18b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: call   193 <sys_exit_submit+0x193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_193:
	/* 0x193: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: jns    1aa <sys_exit_submit+0x1aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19a, 0x1aa, x86_l_1aa);
x86_l_19c:
	/* 0x19c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a3:
	/* 0x1a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     1b5 <sys_exit_submit+0x1b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a6, 0x1b5, x86_l_1b5);
x86_l_1a8:
	/* 0x1a8: jmp    1bf <sys_exit_submit+0x1bf> */
	X86_SIM_X86_JMP(0x1a8, 0x1bf, x86_l_1bf);
x86_l_1aa:
	/* 0x1aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac:
	/* 0x1ac: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b0:
	/* 0x1b0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: jns    1bf <sys_exit_submit+0x1bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3, 0x1bf, x86_l_1bf);
x86_l_1b5:
	/* 0x1b5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7:
	/* 0x1b7: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b9:
	/* 0x1b9: jne    55f <sys_exit_submit+0x55f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b9, 0x55f, x86_l_55f);
x86_l_1bf:
	/* 0x1bf: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1cb:
	/* 0x1cb: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1e1:
	/* 0x1e1: call   1e6 <sys_exit_submit+0x1e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e6:
	/* 0x1e6: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1ee:
	/* 0x1ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f1:
	/* 0x1f1: je     fcc <sys_exit_submit+0xfcc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1, 0xfcc, x86_l_fcc);
x86_l_1f7:
	/* 0x1f7: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fb:
	/* 0x1fb: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_202:
	/* 0x202: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_209:
	/* 0x209: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_211:
	/* 0x211: call   216 <sys_exit_submit+0x216> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_216:
	/* 0x216: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21c:
	/* 0x21c: je     105e <sys_exit_submit+0x105e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21c, 0x105e, x86_l_105e);
x86_l_222:
	/* 0x222: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_227:
	/* 0x227: jne    230 <sys_exit_submit+0x230> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x227, 0x230, x86_l_230);
x86_l_229:
	/* 0x229: call   22e <sys_exit_submit+0x22e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_22e:
	/* 0x22e: jmp    288 <sys_exit_submit+0x288> */
	X86_SIM_X86_JMP(0x22e, 0x288, x86_l_288);
x86_l_230:
	/* 0x230: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_235:
	/* 0x235: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_23c:
	/* 0x23c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23f:
	/* 0x23f: jns    259 <sys_exit_submit+0x259> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f, 0x259, x86_l_259);
x86_l_241:
	/* 0x241: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244:
	/* 0x244: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_247:
	/* 0x247: js     260 <sys_exit_submit+0x260> */
	X86_SIM_X86_JCC(X86_CC_S, 0x247, 0x260, x86_l_260);
x86_l_249:
	/* 0x249: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24b:
	/* 0x24b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24e:
	/* 0x24e: js     268 <sys_exit_submit+0x268> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24e, 0x268, x86_l_268);
x86_l_250:
	/* 0x250: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_252:
	/* 0x252: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_255:
	/* 0x255: js     270 <sys_exit_submit+0x270> */
	X86_SIM_X86_JCC(X86_CC_S, 0x255, 0x270, x86_l_270);
x86_l_257:
	/* 0x257: jmp    286 <sys_exit_submit+0x286> */
	X86_SIM_X86_JMP(0x257, 0x286, x86_l_286);
x86_l_259:
	/* 0x259: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b:
	/* 0x25b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e:
	/* 0x25e: jns    249 <sys_exit_submit+0x249> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e, 0x249, x86_l_249);
x86_l_260:
	/* 0x260: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_263:
	/* 0x263: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_266:
	/* 0x266: jns    250 <sys_exit_submit+0x250> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x266, 0x250, x86_l_250);
x86_l_268:
	/* 0x268: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b:
	/* 0x26b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26e:
	/* 0x26e: jns    286 <sys_exit_submit+0x286> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26e, 0x286, x86_l_286);
x86_l_270:
	/* 0x270: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_273:
	/* 0x273: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_276:
	/* 0x276: je     286 <sys_exit_submit+0x286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x276, 0x286, x86_l_286);
x86_l_278:
	/* 0x278: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_27c:
	/* 0x27c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27f:
	/* 0x27f: jns    286 <sys_exit_submit+0x286> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27f, 0x286, x86_l_286);
x86_l_281:
	/* 0x281: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284:
	/* 0x284: jmp    288 <sys_exit_submit+0x288> */
	X86_SIM_X86_JMP(0x284, 0x288, x86_l_288);
x86_l_286:
	/* 0x286: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_288:
	/* 0x288: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c:
	/* 0x28c: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_290:
	/* 0x290: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_294:
	/* 0x294: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_29b:
	/* 0x29b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a0:
	/* 0x2a0: call   2a5 <sys_exit_submit+0x2a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a5:
	/* 0x2a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a8:
	/* 0x2a8: je     2c0 <sys_exit_submit+0x2c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8, 0x2c0, x86_l_2c0);
x86_l_2aa:
	/* 0x2aa: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2ad:
	/* 0x2ad: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2b3:
	/* 0x2b3: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2b6:
	/* 0x2b6: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2b9:
	/* 0x2b9: jne    2c0 <sys_exit_submit+0x2c0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b9, 0x2c0, x86_l_2c0);
x86_l_2bb:
	/* 0x2bb: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2c0:
	/* 0x2c0: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2c5:
	/* 0x2c5: cmp    ax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R13, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2ca:
	/* 0x2ca: jne    1106 <sys_exit_submit+0x1106> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ca, 0x1106, x86_l_1106);
x86_l_2d0:
	/* 0x2d0: mov    QWORD PTR [r14+0x80],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 554050781183ULL);
x86_l_2db:
	/* 0x2db: lea    rcx,[rbp+0x7d8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2e2:
	/* 0x2e2: mov    edx,DWORD PTR [rbx+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2e5:
	/* 0x2e5: mov    DWORD PTR [r14+0x70],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2e9:
	/* 0x2e9: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_2f3:
	/* 0x2f3: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_2fb:
	/* 0x2fb: mov    QWORD PTR [rcx+0x38],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244813135871ULL);
x86_l_303:
	/* 0x303: mov    QWORD PTR [rcx+0x30],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 210453397503ULL);
x86_l_30b:
	/* 0x30b: mov    QWORD PTR [rcx+0x28],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176093659135ULL);
x86_l_313:
	/* 0x313: mov    QWORD PTR [rcx+0x20],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 141733920767ULL);
x86_l_31b:
	/* 0x31b: mov    QWORD PTR [rcx+0x18],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 107374182399ULL);
x86_l_323:
	/* 0x323: mov    QWORD PTR [rcx+0x10],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 73014444031ULL);
x86_l_32b:
	/* 0x32b: mov    QWORD PTR [rcx+0x8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_333:
	/* 0x333: mov    QWORD PTR [rcx],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4294967295ULL);
x86_l_33a:
	/* 0x33a: mov    QWORD PTR [r14+0x7dd8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138370961375231ULL);
x86_l_345:
	/* 0x345: mov    DWORD PTR [rsp+0x30],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_349:
	/* 0x349: mov    WORD PTR [rsp+0x78],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_34e:
	/* 0x34e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_355:
	/* 0x355: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_35a:
	/* 0x35a: call   35f <sys_exit_submit+0x35f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_35f:
	/* 0x35f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_362:
	/* 0x362: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x362, 0x2896, x86_l_2896);
x86_l_368:
	/* 0x368: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_36d:
	/* 0x36d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_370:
	/* 0x370: call   375 <sys_exit_submit+0x375> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_375:
	/* 0x375: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_378:
	/* 0x378: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x378, 0x2896, x86_l_2896);
x86_l_37e:
	/* 0x37e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_382:
	/* 0x382: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_389:
	/* 0x389: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38c:
	/* 0x38c: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_393:
	/* 0x393: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_39a:
	/* 0x39a: mov    rdx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39e:
	/* 0x39e: mov    rsi,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3a2:
	/* 0x3a2: mov    QWORD PTR [r14+0x7de8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_3a9:
	/* 0x3a9: mov    QWORD PTR [r14+0x7df0],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_3b0:
	/* 0x3b0: mov    rdx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b4:
	/* 0x3b4: mov    QWORD PTR [r14+0x7df8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_3bb:
	/* 0x3bb: mov    rdx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3bf:
	/* 0x3bf: mov    QWORD PTR [r14+0x7e00],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_3c6:
	/* 0x3c6: mov    rdx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3ca:
	/* 0x3ca: mov    QWORD PTR [r14+0x7e08],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_3d1:
	/* 0x3d1: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3d5:
	/* 0x3d5: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_3dc:
	/* 0x3dc: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3e0:
	/* 0x3e0: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_3e5:
	/* 0x3e5: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e9:
	/* 0x3e9: cmp    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_3ed:
	/* 0x3ed: jne    409 <sys_exit_submit+0x409> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ed, 0x409, x86_l_409);
x86_l_3ef:
	/* 0x3ef: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f1:
	/* 0x3f1: and    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3f4:
	/* 0x3f4: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3fb:
	/* 0x3fb: mov    edx,DWORD PTR [rbx+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3fe:
	/* 0x3fe: jne    d1e <sys_exit_submit+0xd1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3fe, 0xd1e, x86_l_d1e);
x86_l_404:
	/* 0x404: jmp    2887 <sys_exit_submit+0x2887> */
	X86_SIM_X86_JMP(0x404, 0x2887, x86_l_2887);
x86_l_409:
	/* 0x409: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_410:
	/* 0x410: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_413:
	/* 0x413: je     5e1 <sys_exit_submit+0x5e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x413, 0x5e1, x86_l_5e1);
x86_l_419:
	/* 0x419: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_420:
	/* 0x420: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_423:
	/* 0x423: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_425:
	/* 0x425: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_428:
	/* 0x428: sete   sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_42c:
	/* 0x42c: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_42f:
	/* 0x42f: neg    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_432:
	/* 0x432: xor    rsi,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_439:
	/* 0x439: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_43c:
	/* 0x43c: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_443:
	/* 0x443: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_446:
	/* 0x446: je     467 <sys_exit_submit+0x467> */
	X86_SIM_X86_JCC(X86_CC_E, 0x446, 0x467, x86_l_467);
x86_l_448:
	/* 0x448: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_44a:
	/* 0x44a: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_451:
	/* 0x451: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_454:
	/* 0x454: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_457:
	/* 0x457: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_45a:
	/* 0x45a: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_461:
	/* 0x461: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_464:
	/* 0x464: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_467:
	/* 0x467: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_46e:
	/* 0x46e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_471:
	/* 0x471: je     48d <sys_exit_submit+0x48d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x471, 0x48d, x86_l_48d);
x86_l_473:
	/* 0x473: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_477:
	/* 0x477: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_47a:
	/* 0x47a: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_47d:
	/* 0x47d: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_480:
	/* 0x480: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_487:
	/* 0x487: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_48a:
	/* 0x48a: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_48d:
	/* 0x48d: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_494:
	/* 0x494: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_497:
	/* 0x497: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_49c:
	/* 0x49c: je     4bd <sys_exit_submit+0x4bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49c, 0x4bd, x86_l_4bd);
x86_l_49e:
	/* 0x49e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4a1:
	/* 0x4a1: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4a9:
	/* 0x4a9: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4ad:
	/* 0x4ad: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4b0:
	/* 0x4b0: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_4b7:
	/* 0x4b7: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4ba:
	/* 0x4ba: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4bd:
	/* 0x4bd: mov    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c2:
	/* 0x4c2: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_4c7:
	/* 0x4c7: mov    rbx,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_4ce:
	/* 0x4ce: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4d1:
	/* 0x4d1: mov    QWORD PTR [rsp+0x28],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d6:
	/* 0x4d6: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4db:
	/* 0x4db: mov    WORD PTR [rsp+0x1e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_4e0:
	/* 0x4e0: je     656 <sys_exit_submit+0x656> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e0, 0x656, x86_l_656);
x86_l_4e6:
	/* 0x4e6: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4ee:
	/* 0x4ee: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_4f5:
	/* 0x4f5: mov    QWORD PTR [rsp+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4fd:
	/* 0x4fd: mov    rbp,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_504:
	/* 0x504: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_50b:
	/* 0x50b: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_513:
	/* 0x513: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_518:
	/* 0x518: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_51f:
	/* 0x51f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_524:
	/* 0x524: call   529 <sys_exit_submit+0x529> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_529:
	/* 0x529: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52c:
	/* 0x52c: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_530:
	/* 0x530: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_535:
	/* 0x535: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_53c:
	/* 0x53c: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_53f:
	/* 0x53f: je     580 <sys_exit_submit+0x580> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53f, 0x580, x86_l_580);
x86_l_541:
	/* 0x541: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_546:
	/* 0x546: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_549:
	/* 0x549: call   54e <sys_exit_submit+0x54e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54e:
	/* 0x54e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_551:
	/* 0x551: je     580 <sys_exit_submit+0x580> */
	X86_SIM_X86_JCC(X86_CC_E, 0x551, 0x580, x86_l_580);
x86_l_553:
	/* 0x553: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_556:
	/* 0x556: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_55a:
	/* 0x55a: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_55d:
	/* 0x55d: jmp    583 <sys_exit_submit+0x583> */
	X86_SIM_X86_JMP(0x55d, 0x583, x86_l_583);
x86_l_55f:
	/* 0x55f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_566:
	/* 0x566: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_56b:
	/* 0x56b: call   570 <sys_exit_submit+0x570> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_570:
	/* 0x570: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_573:
	/* 0x573: je     5fd <sys_exit_submit+0x5fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x573, 0x5fd, x86_l_5fd);
x86_l_579:
	/* 0x579: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57b:
	/* 0x57b: jmp    1c3 <sys_exit_submit+0x1c3> */
	X86_SIM_X86_JMP(0x57b, 0x1c3, x86_l_1c3);
x86_l_580:
	/* 0x580: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_583:
	/* 0x583: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_58b:
	/* 0x58b: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_590:
	/* 0x590: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_593:
	/* 0x593: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_596:
	/* 0x596: jb     5ae <sys_exit_submit+0x5ae> */
	X86_SIM_X86_JCC(X86_CC_B, 0x596, 0x5ae, x86_l_5ae);
x86_l_598:
	/* 0x598: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_59c:
	/* 0x59c: je     5a3 <sys_exit_submit+0x5a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59c, 0x5a3, x86_l_5a3);
x86_l_59e:
	/* 0x59e: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5a1:
	/* 0x5a1: jbe    5ae <sys_exit_submit+0x5ae> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5a1, 0x5ae, x86_l_5ae);
x86_l_5a3:
	/* 0x5a3: and    r12,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 176ULL);
x86_l_5ab:
	/* 0x5ab: or     r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5ae:
	/* 0x5ae: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5b2:
	/* 0x5b2: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5b7:
	/* 0x5b7: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5be:
	/* 0x5be: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5c1:
	/* 0x5c1: je     607 <sys_exit_submit+0x607> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c1, 0x607, x86_l_607);
x86_l_5c3:
	/* 0x5c3: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5c8:
	/* 0x5c8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5cb:
	/* 0x5cb: call   5d0 <sys_exit_submit+0x5d0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5d0:
	/* 0x5d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d3:
	/* 0x5d3: je     618 <sys_exit_submit+0x618> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d3, 0x618, x86_l_618);
x86_l_5d5:
	/* 0x5d5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d8:
	/* 0x5d8: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5dc:
	/* 0x5dc: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5df:
	/* 0x5df: jmp    61a <sys_exit_submit+0x61a> */
	X86_SIM_X86_JMP(0x5df, 0x61a, x86_l_61a);
x86_l_5e1:
	/* 0x5e1: mov    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5e8:
	/* 0x5e8: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_5ef:
	/* 0x5ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f2:
	/* 0x5f2: jne    448 <sys_exit_submit+0x448> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5f2, 0x448, x86_l_448);
x86_l_5f8:
	/* 0x5f8: jmp    467 <sys_exit_submit+0x467> */
	X86_SIM_X86_JMP(0x5f8, 0x467, x86_l_467);
x86_l_5fd:
	/* 0x5fd: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_602:
	/* 0x602: jmp    1c3 <sys_exit_submit+0x1c3> */
	X86_SIM_X86_JMP(0x602, 0x1c3, x86_l_1c3);
x86_l_607:
	/* 0x607: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_609:
	/* 0x609: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_60c:
	/* 0x60c: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_611:
	/* 0x611: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_614:
	/* 0x614: jae    62f <sys_exit_submit+0x62f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x614, 0x62f, x86_l_62f);
x86_l_616:
	/* 0x616: jmp    645 <sys_exit_submit+0x645> */
	X86_SIM_X86_JMP(0x616, 0x645, x86_l_645);
x86_l_618:
	/* 0x618: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_61a:
	/* 0x61a: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_622:
	/* 0x622: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_625:
	/* 0x625: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62a:
	/* 0x62a: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62d:
	/* 0x62d: jb     645 <sys_exit_submit+0x645> */
	X86_SIM_X86_JCC(X86_CC_B, 0x62d, 0x645, x86_l_645);
x86_l_62f:
	/* 0x62f: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_633:
	/* 0x633: je     63a <sys_exit_submit+0x63a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x633, 0x63a, x86_l_63a);
x86_l_635:
	/* 0x635: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_638:
	/* 0x638: jbe    645 <sys_exit_submit+0x645> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x638, 0x645, x86_l_645);
x86_l_63a:
	/* 0x63a: and    r12,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 176ULL);
x86_l_642:
	/* 0x642: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_645:
	/* 0x645: or     r13,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_648:
	/* 0x648: or     r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_64b:
	/* 0x64b: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_653:
	/* 0x653: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_656:
	/* 0x656: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_65e:
	/* 0x65e: je     71d <sys_exit_submit+0x71d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65e, 0x71d, x86_l_71d);
x86_l_664:
	/* 0x664: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_66c:
	/* 0x66c: call   671 <sys_exit_submit+0x671> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_671:
	/* 0x671: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_675:
	/* 0x675: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_67c:
	/* 0x67c: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_683:
	/* 0x683: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_68b:
	/* 0x68b: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_692:
	/* 0x692: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_699:
	/* 0x699: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_69e:
	/* 0x69e: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6a3:
	/* 0x6a3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_6aa:
	/* 0x6aa: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6af:
	/* 0x6af: call   6b4 <sys_exit_submit+0x6b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6b4:
	/* 0x6b4: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6b8:
	/* 0x6b8: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6bd:
	/* 0x6bd: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6c4:
	/* 0x6c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c7:
	/* 0x6c7: je     6e7 <sys_exit_submit+0x6e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c7, 0x6e7, x86_l_6e7);
x86_l_6c9:
	/* 0x6c9: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6ce:
	/* 0x6ce: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d1:
	/* 0x6d1: call   6d6 <sys_exit_submit+0x6d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d6:
	/* 0x6d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d9:
	/* 0x6d9: je     6e7 <sys_exit_submit+0x6e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d9, 0x6e7, x86_l_6e7);
x86_l_6db:
	/* 0x6db: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6de:
	/* 0x6de: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e2:
	/* 0x6e2: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6e5:
	/* 0x6e5: jmp    6e9 <sys_exit_submit+0x6e9> */
	X86_SIM_X86_JMP(0x6e5, 0x6e9, x86_l_6e9);
x86_l_6e7:
	/* 0x6e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e9:
	/* 0x6e9: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6ec:
	/* 0x6ec: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f1:
	/* 0x6f1: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6f4:
	/* 0x6f4: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f7:
	/* 0x6f7: jb     70f <sys_exit_submit+0x70f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6f7, 0x70f, x86_l_70f);
x86_l_6f9:
	/* 0x6f9: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6fd:
	/* 0x6fd: je     704 <sys_exit_submit+0x704> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6fd, 0x704, x86_l_704);
x86_l_6ff:
	/* 0x6ff: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_702:
	/* 0x702: jbe    70f <sys_exit_submit+0x70f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x702, 0x70f, x86_l_70f);
x86_l_704:
	/* 0x704: and    r15,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 136ULL);
x86_l_70c:
	/* 0x70c: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_70f:
	/* 0x70f: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_712:
	/* 0x712: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_71a:
	/* 0x71a: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_71d:
	/* 0x71d: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_725:
	/* 0x725: je     7d6 <sys_exit_submit+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x725, 0x7d6, x86_l_7d6);
x86_l_72b:
	/* 0x72b: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_730:
	/* 0x730: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_737:
	/* 0x737: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73a:
	/* 0x73a: jns    741 <sys_exit_submit+0x741> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x73a, 0x741, x86_l_741);
x86_l_73c:
	/* 0x73c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_73f:
	/* 0x73f: jmp    743 <sys_exit_submit+0x743> */
	X86_SIM_X86_JMP(0x73f, 0x743, x86_l_743);
x86_l_741:
	/* 0x741: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_743:
	/* 0x743: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_747:
	/* 0x747: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_749:
	/* 0x749: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_74c:
	/* 0x74c: jns    75b <sys_exit_submit+0x75b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x74c, 0x75b, x86_l_75b);
x86_l_74e:
	/* 0x74e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_751:
	/* 0x751: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_754:
	/* 0x754: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_757:
	/* 0x757: js     765 <sys_exit_submit+0x765> */
	X86_SIM_X86_JCC(X86_CC_S, 0x757, 0x765, x86_l_765);
x86_l_759:
	/* 0x759: jmp    767 <sys_exit_submit+0x767> */
	X86_SIM_X86_JMP(0x759, 0x767, x86_l_767);
x86_l_75b:
	/* 0x75b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_75d:
	/* 0x75d: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_760:
	/* 0x760: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_763:
	/* 0x763: jns    767 <sys_exit_submit+0x767> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x763, 0x767, x86_l_767);
x86_l_765:
	/* 0x765: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_767:
	/* 0x767: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_76b:
	/* 0x76b: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_772:
	/* 0x772: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_779:
	/* 0x779: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_77c:
	/* 0x77c: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_781:
	/* 0x781: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_786:
	/* 0x786: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_78d:
	/* 0x78d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_792:
	/* 0x792: call   797 <sys_exit_submit+0x797> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_797:
	/* 0x797: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_79e:
	/* 0x79e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a1:
	/* 0x7a1: je     7c5 <sys_exit_submit+0x7c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a1, 0x7c5, x86_l_7c5);
x86_l_7a3:
	/* 0x7a3: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a8:
	/* 0x7a8: lea    rsi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7ac:
	/* 0x7ac: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7af:
	/* 0x7af: call   7b4 <sys_exit_submit+0x7b4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7b4:
	/* 0x7b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b7:
	/* 0x7b7: je     7c5 <sys_exit_submit+0x7c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b7, 0x7c5, x86_l_7c5);
x86_l_7b9:
	/* 0x7b9: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7bc:
	/* 0x7bc: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7c0:
	/* 0x7c0: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7c3:
	/* 0x7c3: jmp    7c7 <sys_exit_submit+0x7c7> */
	X86_SIM_X86_JMP(0x7c3, 0x7c7, x86_l_7c7);
x86_l_7c5:
	/* 0x7c5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c7:
	/* 0x7c7: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7ca:
	/* 0x7ca: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7cd:
	/* 0x7cd: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7d0:
	/* 0x7d0: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_7d3:
	/* 0x7d3: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7d6:
	/* 0x7d6: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_7de:
	/* 0x7de: je     8a7 <sys_exit_submit+0x8a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7de, 0x8a7, x86_l_8a7);
x86_l_7e4:
	/* 0x7e4: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_7eb:
	/* 0x7eb: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7ef:
	/* 0x7ef: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f1:
	/* 0x7f1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7f4:
	/* 0x7f4: jns    803 <sys_exit_submit+0x803> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7f4, 0x803, x86_l_803);
x86_l_7f6:
	/* 0x7f6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f9:
	/* 0x7f9: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7fc:
	/* 0x7fc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7ff:
	/* 0x7ff: js     80d <sys_exit_submit+0x80d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7ff, 0x80d, x86_l_80d);
x86_l_801:
	/* 0x801: jmp    80f <sys_exit_submit+0x80f> */
	X86_SIM_X86_JMP(0x801, 0x80f, x86_l_80f);
x86_l_803:
	/* 0x803: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_805:
	/* 0x805: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_808:
	/* 0x808: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_80b:
	/* 0x80b: jns    80f <sys_exit_submit+0x80f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x80b, 0x80f, x86_l_80f);
x86_l_80d:
	/* 0x80d: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_80f:
	/* 0x80f: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_811:
	/* 0x811: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_815:
	/* 0x815: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_818:
	/* 0x818: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_81c:
	/* 0x81c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_81e:
	/* 0x81e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_821:
	/* 0x821: jns    828 <sys_exit_submit+0x828> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x821, 0x828, x86_l_828);
x86_l_823:
	/* 0x823: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_826:
	/* 0x826: jmp    82a <sys_exit_submit+0x82a> */
	X86_SIM_X86_JMP(0x826, 0x82a, x86_l_82a);
x86_l_828:
	/* 0x828: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82a:
	/* 0x82a: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_82d:
	/* 0x82d: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_831:
	/* 0x831: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_834:
	/* 0x834: jns    838 <sys_exit_submit+0x838> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x834, 0x838, x86_l_838);
x86_l_836:
	/* 0x836: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_838:
	/* 0x838: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_83c:
	/* 0x83c: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_843:
	/* 0x843: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_84a:
	/* 0x84a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_84d:
	/* 0x84d: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_852:
	/* 0x852: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_857:
	/* 0x857: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_85e:
	/* 0x85e: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_863:
	/* 0x863: call   868 <sys_exit_submit+0x868> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_868:
	/* 0x868: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_86f:
	/* 0x86f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_872:
	/* 0x872: je     896 <sys_exit_submit+0x896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x872, 0x896, x86_l_896);
x86_l_874:
	/* 0x874: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_879:
	/* 0x879: lea    rsi,[rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_87d:
	/* 0x87d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_880:
	/* 0x880: call   885 <sys_exit_submit+0x885> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_885:
	/* 0x885: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_888:
	/* 0x888: je     896 <sys_exit_submit+0x896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x888, 0x896, x86_l_896);
x86_l_88a:
	/* 0x88a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_88d:
	/* 0x88d: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_891:
	/* 0x891: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_894:
	/* 0x894: jmp    898 <sys_exit_submit+0x898> */
	X86_SIM_X86_JMP(0x894, 0x898, x86_l_898);
x86_l_896:
	/* 0x896: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_898:
	/* 0x898: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_89b:
	/* 0x89b: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_89e:
	/* 0x89e: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8a1:
	/* 0x8a1: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_8a4:
	/* 0x8a4: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8a7:
	/* 0x8a7: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_8af:
	/* 0x8af: je     a90 <sys_exit_submit+0xa90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8af, 0xa90, x86_l_a90);
x86_l_8b5:
	/* 0x8b5: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8ba:
	/* 0x8ba: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_8c1:
	/* 0x8c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c4:
	/* 0x8c4: jns    8d7 <sys_exit_submit+0x8d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c4, 0x8d7, x86_l_8d7);
x86_l_8c6:
	/* 0x8c6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c9:
	/* 0x8c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8cc:
	/* 0x8cc: js     8de <sys_exit_submit+0x8de> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8cc, 0x8de, x86_l_8de);
x86_l_8ce:
	/* 0x8ce: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d0:
	/* 0x8d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8d3:
	/* 0x8d3: js     8e6 <sys_exit_submit+0x8e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8d3, 0x8e6, x86_l_8e6);
x86_l_8d5:
	/* 0x8d5: jmp    931 <sys_exit_submit+0x931> */
	X86_SIM_X86_JMP(0x8d5, 0x931, x86_l_931);
x86_l_8d7:
	/* 0x8d7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d9:
	/* 0x8d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8dc:
	/* 0x8dc: jns    8ce <sys_exit_submit+0x8ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8dc, 0x8ce, x86_l_8ce);
x86_l_8de:
	/* 0x8de: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e1:
	/* 0x8e1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e4:
	/* 0x8e4: jns    931 <sys_exit_submit+0x931> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e4, 0x931, x86_l_931);
x86_l_8e6:
	/* 0x8e6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e9:
	/* 0x8e9: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8ee:
	/* 0x8ee: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f2:
	/* 0x8f2: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8f7:
	/* 0x8f7: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8fb:
	/* 0x8fb: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_900:
	/* 0x900: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_904:
	/* 0x904: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_909:
	/* 0x909: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_90d:
	/* 0x90d: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_912:
	/* 0x912: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_916:
	/* 0x916: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_91b:
	/* 0x91b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_91f:
	/* 0x91f: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_924:
	/* 0x924: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_928:
	/* 0x928: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_92d:
	/* 0x92d: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_931:
	/* 0x931: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_936:
	/* 0x936: lea    r15,[rax+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_93a:
	/* 0x93a: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_93f:
	/* 0x93f: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_942:
	/* 0x942: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_945:
	/* 0x945: jns    a1c <sys_exit_submit+0xa1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x945, 0xa1c, x86_l_a1c);
x86_l_94b:
	/* 0x94b: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_94e:
	/* 0x94e: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_951:
	/* 0x951: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_953:
	/* 0x953: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x953, 0xa2b, x86_l_a2b);
x86_l_959:
	/* 0x959: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_95d:
	/* 0x95d: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_961:
	/* 0x961: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_963:
	/* 0x963: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x963, 0xa2b, x86_l_a2b);
x86_l_969:
	/* 0x969: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_96d:
	/* 0x96d: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_971:
	/* 0x971: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_973:
	/* 0x973: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x973, 0xa2b, x86_l_a2b);
x86_l_979:
	/* 0x979: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_97d:
	/* 0x97d: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_981:
	/* 0x981: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_983:
	/* 0x983: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x983, 0xa2b, x86_l_a2b);
x86_l_989:
	/* 0x989: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_98d:
	/* 0x98d: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_991:
	/* 0x991: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_993:
	/* 0x993: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x993, 0xa2b, x86_l_a2b);
x86_l_999:
	/* 0x999: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_99d:
	/* 0x99d: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_9a1:
	/* 0x9a1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a3:
	/* 0x9a3: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a3, 0xa2b, x86_l_a2b);
x86_l_9a9:
	/* 0x9a9: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_9ad:
	/* 0x9ad: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_9b1:
	/* 0x9b1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b3:
	/* 0x9b3: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b3, 0xa2b, x86_l_a2b);
x86_l_9b5:
	/* 0x9b5: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_9b9:
	/* 0x9b9: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_9bd:
	/* 0x9bd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9bf:
	/* 0x9bf: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9bf, 0xa2b, x86_l_a2b);
x86_l_9c1:
	/* 0x9c1: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_9c5:
	/* 0x9c5: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_9c9:
	/* 0x9c9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9cb:
	/* 0x9cb: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cb, 0xa2b, x86_l_a2b);
x86_l_9cd:
	/* 0x9cd: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_9d1:
	/* 0x9d1: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_9d5:
	/* 0x9d5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d7:
	/* 0x9d7: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d7, 0xa2b, x86_l_a2b);
x86_l_9d9:
	/* 0x9d9: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_9dd:
	/* 0x9dd: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_9e1:
	/* 0x9e1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9e3:
	/* 0x9e3: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e3, 0xa2b, x86_l_a2b);
x86_l_9e5:
	/* 0x9e5: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_9e9:
	/* 0x9e9: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_9ed:
	/* 0x9ed: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9ef:
	/* 0x9ef: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ef, 0xa2b, x86_l_a2b);
x86_l_9f1:
	/* 0x9f1: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_9f5:
	/* 0x9f5: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_9f9:
	/* 0x9f9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9fb:
	/* 0x9fb: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9fb, 0xa2b, x86_l_a2b);
x86_l_9fd:
	/* 0x9fd: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_a01:
	/* 0xa01: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_a05:
	/* 0xa05: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a07:
	/* 0xa07: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa07, 0xa2b, x86_l_a2b);
x86_l_a09:
	/* 0xa09: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_a0d:
	/* 0xa0d: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_a11:
	/* 0xa11: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_a13:
	/* 0xa13: je     a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa13, 0xa2b, x86_l_a2b);
x86_l_a15:
	/* 0xa15: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_a1a:
	/* 0xa1a: jmp    a2b <sys_exit_submit+0xa2b> */
	X86_SIM_X86_JMP(0xa1a, 0xa2b, x86_l_a2b);
x86_l_a1c:
	/* 0xa1c: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a24:
	/* 0xa24: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a2b:
	/* 0xa2b: mov    rbx,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a32:
	/* 0xa32: mov    r13,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a39:
	/* 0xa39: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a3c:
	/* 0xa3c: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_a41:
	/* 0xa41: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a46:
	/* 0xa46: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a4d:
	/* 0xa4d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a52:
	/* 0xa52: call   a57 <sys_exit_submit+0xa57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a57:
	/* 0xa57: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a5e:
	/* 0xa5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a61:
	/* 0xa61: je     a7f <sys_exit_submit+0xa7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa61, 0xa7f, x86_l_a7f);
x86_l_a63:
	/* 0xa63: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a66:
	/* 0xa66: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a69:
	/* 0xa69: call   a6e <sys_exit_submit+0xa6e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a6e:
	/* 0xa6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a71:
	/* 0xa71: je     a7f <sys_exit_submit+0xa7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa71, 0xa7f, x86_l_a7f);
x86_l_a73:
	/* 0xa73: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a76:
	/* 0xa76: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a7a:
	/* 0xa7a: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a7d:
	/* 0xa7d: jmp    a81 <sys_exit_submit+0xa81> */
	X86_SIM_X86_JMP(0xa7d, 0xa81, x86_l_a81);
x86_l_a7f:
	/* 0xa7f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a81:
	/* 0xa81: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a84:
	/* 0xa84: and    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a87:
	/* 0xa87: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a8a:
	/* 0xa8a: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a8d:
	/* 0xa8d: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_a90:
	/* 0xa90: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a98:
	/* 0xa98: je     b1c <sys_exit_submit+0xb1c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa98, 0xb1c, x86_l_b1c);
x86_l_a9e:
	/* 0xa9e: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_aa1:
	/* 0xaa1: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_aa6:
	/* 0xaa6: lea    r15,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_aaa:
	/* 0xaaa: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_aad:
	/* 0xaad: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_ab2:
	/* 0xab2: call   ab7 <sys_exit_submit+0xab7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_ab7:
	/* 0xab7: mov    rbx,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_abe:
	/* 0xabe: mov    r13,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_ac5:
	/* 0xac5: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ac8:
	/* 0xac8: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_acd:
	/* 0xacd: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ad2:
	/* 0xad2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_ad9:
	/* 0xad9: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ade:
	/* 0xade: call   ae3 <sys_exit_submit+0xae3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae3:
	/* 0xae3: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_aea:
	/* 0xaea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aed:
	/* 0xaed: je     b0b <sys_exit_submit+0xb0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaed, 0xb0b, x86_l_b0b);
x86_l_aef:
	/* 0xaef: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af2:
	/* 0xaf2: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_af5:
	/* 0xaf5: call   afa <sys_exit_submit+0xafa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_afa:
	/* 0xafa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_afd:
	/* 0xafd: je     b0b <sys_exit_submit+0xb0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xafd, 0xb0b, x86_l_b0b);
x86_l_aff:
	/* 0xaff: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b02:
	/* 0xb02: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b06:
	/* 0xb06: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b09:
	/* 0xb09: jmp    b0d <sys_exit_submit+0xb0d> */
	X86_SIM_X86_JMP(0xb09, 0xb0d, x86_l_b0d);
x86_l_b0b:
	/* 0xb0b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b0d:
	/* 0xb0d: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b10:
	/* 0xb10: and    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b13:
	/* 0xb13: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b16:
	/* 0xb16: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b19:
	/* 0xb19: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b1c:
	/* 0xb1c: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b23:
	/* 0xb23: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b26:
	/* 0xb26: je     b99 <sys_exit_submit+0xb99> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb26, 0xb99, x86_l_b99);
x86_l_b28:
	/* 0xb28: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_b2b:
	/* 0xb2b: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b2f:
	/* 0xb2f: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b33:
	/* 0xb33: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b3a:
	/* 0xb3a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b3d:
	/* 0xb3d: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_b42:
	/* 0xb42: mov    WORD PTR [rsp+0x84],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_b4a:
	/* 0xb4a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b51:
	/* 0xb51: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_b59:
	/* 0xb59: call   b5e <sys_exit_submit+0xb5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b5e:
	/* 0xb5e: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b65:
	/* 0xb65: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b68:
	/* 0xb68: je     b88 <sys_exit_submit+0xb88> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb68, 0xb88, x86_l_b88);
x86_l_b6a:
	/* 0xb6a: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b6f:
	/* 0xb6f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b72:
	/* 0xb72: call   b77 <sys_exit_submit+0xb77> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b77:
	/* 0xb77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b7a:
	/* 0xb7a: je     b88 <sys_exit_submit+0xb88> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb7a, 0xb88, x86_l_b88);
x86_l_b7c:
	/* 0xb7c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b7f:
	/* 0xb7f: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b83:
	/* 0xb83: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b86:
	/* 0xb86: jmp    b8a <sys_exit_submit+0xb8a> */
	X86_SIM_X86_JMP(0xb86, 0xb8a, x86_l_b8a);
x86_l_b88:
	/* 0xb88: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b8a:
	/* 0xb8a: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b8d:
	/* 0xb8d: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b90:
	/* 0xb90: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b93:
	/* 0xb93: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b96:
	/* 0xb96: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b99:
	/* 0xb99: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_ba0:
	/* 0xba0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ba3:
	/* 0xba3: je     c2b <sys_exit_submit+0xc2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xba3, 0xc2b, x86_l_c2b);
x86_l_ba9:
	/* 0xba9: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_bac:
	/* 0xbac: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_bb3:
	/* 0xbb3: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bb6:
	/* 0xbb6: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_bbb:
	/* 0xbbb: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bc0:
	/* 0xbc0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_bc7:
	/* 0xbc7: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bcc:
	/* 0xbcc: call   bd1 <sys_exit_submit+0xbd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bd1:
	/* 0xbd1: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bd8:
	/* 0xbd8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bdb:
	/* 0xbdb: je     bff <sys_exit_submit+0xbff> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbdb, 0xbff, x86_l_bff);
x86_l_bdd:
	/* 0xbdd: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_be2:
	/* 0xbe2: lea    rsi,[rcx+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_be6:
	/* 0xbe6: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be9:
	/* 0xbe9: call   bee <sys_exit_submit+0xbee> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bee:
	/* 0xbee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bf1:
	/* 0xbf1: je     bff <sys_exit_submit+0xbff> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf1, 0xbff, x86_l_bff);
x86_l_bf3:
	/* 0xbf3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf6:
	/* 0xbf6: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfa:
	/* 0xbfa: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bfd:
	/* 0xbfd: jmp    c01 <sys_exit_submit+0xc01> */
	X86_SIM_X86_JMP(0xbfd, 0xc01, x86_l_c01);
x86_l_bff:
	/* 0xbff: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c01:
	/* 0xc01: mov    r13,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c06:
	/* 0xc06: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c09:
	/* 0xc09: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c0c:
	/* 0xc0c: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c0f:
	/* 0xc0f: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c12:
	/* 0xc12: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c15:
	/* 0xc15: mov    rbx,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c1c:
	/* 0xc1c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c1f:
	/* 0xc1f: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_c24:
	/* 0xc24: jne    c45 <sys_exit_submit+0xc45> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc24, 0xc45, x86_l_c45);
x86_l_c26:
	/* 0xc26: jmp    cd0 <sys_exit_submit+0xcd0> */
	X86_SIM_X86_JMP(0xc26, 0xcd0, x86_l_cd0);
x86_l_c2b:
	/* 0xc2b: mov    r13,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c30:
	/* 0xc30: mov    rbx,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c37:
	/* 0xc37: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c3a:
	/* 0xc3a: movzx  eax,WORD PTR [rsp+0x1e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 30ULL);
x86_l_c3f:
	/* 0xc3f: je     cd0 <sys_exit_submit+0xcd0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3f, 0xcd0, x86_l_cd0);
x86_l_c45:
	/* 0xc45: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c4d:
	/* 0xc4d: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c54:
	/* 0xc54: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c57:
	/* 0xc57: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c5c:
	/* 0xc5c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_c63:
	/* 0xc63: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c68:
	/* 0xc68: call   c6d <sys_exit_submit+0xc6d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c6d:
	/* 0xc6d: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c74:
	/* 0xc74: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c77:
	/* 0xc77: je     cba <sys_exit_submit+0xcba> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc77, 0xcba, x86_l_cba);
x86_l_c79:
	/* 0xc79: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7c:
	/* 0xc7c: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_c84:
	/* 0xc84: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_c88:
	/* 0xc88: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c8b:
	/* 0xc8b: call   c90 <sys_exit_submit+0xc90> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c90:
	/* 0xc90: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c93:
	/* 0xc93: jne    cae <sys_exit_submit+0xcae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc93, 0xcae, x86_l_cae);
x86_l_c95:
	/* 0xc95: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_c9d:
	/* 0xc9d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ca1:
	/* 0xca1: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ca4:
	/* 0xca4: call   ca9 <sys_exit_submit+0xca9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ca9:
	/* 0xca9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cac:
	/* 0xcac: je     cba <sys_exit_submit+0xcba> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcac, 0xcba, x86_l_cba);
x86_l_cae:
	/* 0xcae: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cb1:
	/* 0xcb1: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cb5:
	/* 0xcb5: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_cb8:
	/* 0xcb8: jmp    cbc <sys_exit_submit+0xcbc> */
	X86_SIM_X86_JMP(0xcb8, 0xcbc, x86_l_cbc);
x86_l_cba:
	/* 0xcba: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cbc:
	/* 0xcbc: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cbf:
	/* 0xcbf: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cc2:
	/* 0xcc2: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cc5:
	/* 0xcc5: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_ccd:
	/* 0xccd: and    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cd0:
	/* 0xcd0: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_cd7:
	/* 0xcd7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cda:
	/* 0xcda: mov    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cdd:
	/* 0xcdd: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ce2:
	/* 0xce2: je     cf3 <sys_exit_submit+0xcf3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xce2, 0xcf3, x86_l_cf3);
x86_l_ce4:
	/* 0xce4: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cec:
	/* 0xcec: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_cf0:
	/* 0xcf0: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cf3:
	/* 0xcf3: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_cf8:
	/* 0xcf8: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cfd:
	/* 0xcfd: and    rsi,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_d04:
	/* 0xd04: mov    rcx,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d0b:
	/* 0xd0b: and    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d0e:
	/* 0xd0e: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d15:
	/* 0xd15: mov    edx,DWORD PTR [rbx+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d18:
	/* 0xd18: je     2887 <sys_exit_submit+0x2887> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd18, 0x2887, x86_l_2887);
x86_l_d1e:
	/* 0xd1e: cmp    edx,0x3b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 59ULL);
x86_l_d21:
	/* 0xd21: je     2887 <sys_exit_submit+0x2887> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd21, 0x2887, x86_l_2887);
x86_l_d27:
	/* 0xd27: cmp    edx,0x142 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 322ULL);
x86_l_d2d:
	/* 0xd2d: je     2887 <sys_exit_submit+0x2887> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd2d, 0x2887, x86_l_2887);
x86_l_d33:
	/* 0xd33: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d38:
	/* 0xd38: mov    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d3d:
	/* 0xd3d: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d42:
	/* 0xd42: mov    QWORD PTR [rsp+0x28],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d47:
	/* 0xd47: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_d4e:
	/* 0xd4e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d51:
	/* 0xd51: je     2b80 <sys_exit_submit+0x2b80> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd51, 0x2b80, x86_l_2b80);
x86_l_d57:
	/* 0xd57: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_d5a:
	/* 0xd5a: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_d5d:
	/* 0xd5d: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd5d, 0x1479, x86_l_1479);
x86_l_d63:
	/* 0xd63: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d65:
	/* 0xd65: je     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd65, 0x1479, x86_l_1479);
x86_l_d6b:
	/* 0xd6b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d70:
	/* 0xd70: lea    rbp,[rdx+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d74:
	/* 0xd74: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_d77:
	/* 0xd77: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_d79:
	/* 0xd79: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_d80:
	/* 0xd80: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d85:
	/* 0xd85: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_d8a:
	/* 0xd8a: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_d90:
	/* 0xd90: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d94:
	/* 0xd94: jae    d9a <sys_exit_submit+0xd9a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xd94, 0xd9a, x86_l_d9a);
x86_l_d96:
	/* 0xd96: mov    rbp,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d9a:
	/* 0xd9a: mov    r15d,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_d9e:
	/* 0xd9e: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_da4:
	/* 0xda4: je     db8 <sys_exit_submit+0xdb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda4, 0xdb8, x86_l_db8);
x86_l_da6:
	/* 0xda6: lea    eax,[r15-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_daa:
	/* 0xdaa: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_dad:
	/* 0xdad: jae    ee5 <sys_exit_submit+0xee5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xdad, 0xee5, x86_l_ee5);
x86_l_db3:
	/* 0xdb3: jmp    1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JMP(0xdb3, 0x1479, x86_l_1479);
x86_l_db8:
	/* 0xdb8: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_dbd:
	/* 0xdbd: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_dc0:
	/* 0xdc0: je     ee2 <sys_exit_submit+0xee2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc0, 0xee2, x86_l_ee2);
x86_l_dc6:
	/* 0xdc6: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_dc9:
	/* 0xdc9: je     e53 <sys_exit_submit+0xe53> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc9, 0xe53, x86_l_e53);
x86_l_dcf:
	/* 0xdcf: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_dd2:
	/* 0xdd2: jne    da6 <sys_exit_submit+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdd2, 0xda6, x86_l_da6);
x86_l_dd4:
	/* 0xdd4: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_ddc:
	/* 0xddc: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_de2:
	/* 0xde2: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0xde2, 0x1479, x86_l_1479);
x86_l_de8:
	/* 0xde8: mov    BYTE PTR [r14+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_df1:
	/* 0xdf1: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_df9:
	/* 0xdf9: mov    WORD PTR [r14+0x7d8c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_e01:
	/* 0xe01: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_e07:
	/* 0xe07: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe07, 0x1479, x86_l_1479);
x86_l_e0d:
	/* 0xe0d: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e12:
	/* 0xe12: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_e16:
	/* 0xe16: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_e1d:
	/* 0xe1d: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e20:
	/* 0xe20: jns    eb9 <sys_exit_submit+0xeb9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe20, 0xeb9, x86_l_eb9);
x86_l_e26:
	/* 0xe26: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e29:
	/* 0xe29: jns    12b4 <sys_exit_submit+0x12b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe29, 0x12b4, x86_l_12b4);
x86_l_e2f:
	/* 0xe2f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e31:
	/* 0xe31: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_e38:
	/* 0xe38: je     1435 <sys_exit_submit+0x1435> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe38, 0x1435, x86_l_1435);
x86_l_e3e:
	/* 0xe3e: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_e42:
	/* 0xe42: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_e47:
	/* 0xe47: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_e4a:
	/* 0xe4a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4d:
	/* 0xe4d: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_e4f:
	/* 0xe4f: jne    e31 <sys_exit_submit+0xe31> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe4f, 0xe31, x86_l_e31);
x86_l_e51:
	/* 0xe51: jmp    ec6 <sys_exit_submit+0xec6> */
	X86_SIM_X86_JMP(0xe51, 0xec6, x86_l_ec6);
x86_l_e53:
	/* 0xe53: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e56:
	/* 0xe56: je     e6c <sys_exit_submit+0xe6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe56, 0xe6c, x86_l_e6c);
x86_l_e58:
	/* 0xe58: jns    e7d <sys_exit_submit+0xe7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe58, 0xe7d, x86_l_e7d);
x86_l_e5a:
	/* 0xe5a: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e5d:
	/* 0xe5d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e60:
	/* 0xe60: jns    ead <sys_exit_submit+0xead> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe60, 0xead, x86_l_ead);
x86_l_e62:
	/* 0xe62: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_e65:
	/* 0xe65: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e6a:
	/* 0xe6a: jmp    e94 <sys_exit_submit+0xe94> */
	X86_SIM_X86_JMP(0xe6a, 0xe94, x86_l_e94);
x86_l_e6c:
	/* 0xe6c: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_e73:
	/* 0xe73: lea    rbp,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e78:
	/* 0xe78: jmp    da6 <sys_exit_submit+0xda6> */
	X86_SIM_X86_JMP(0xe78, 0xda6, x86_l_da6);
x86_l_e7d:
	/* 0xe7d: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e82:
	/* 0xe82: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e87:
	/* 0xe87: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e8a:
	/* 0xe8a: call   e8f <sys_exit_submit+0xe8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e8f:
	/* 0xe8f: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_e94:
	/* 0xe94: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_e98:
	/* 0xe98: je     edd <sys_exit_submit+0xedd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe98, 0xedd, x86_l_edd);
x86_l_e9a:
	/* 0xe9a: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_e9d:
	/* 0xe9d: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_ea0:
	/* 0xea0: je     ed6 <sys_exit_submit+0xed6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xea0, 0xed6, x86_l_ed6);
x86_l_ea2:
	/* 0xea2: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_ea5:
	/* 0xea5: jne    da6 <sys_exit_submit+0xda6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xea5, 0xda6, x86_l_da6);
x86_l_eab:
	/* 0xeab: jmp    ee2 <sys_exit_submit+0xee2> */
	X86_SIM_X86_JMP(0xeab, 0xee2, x86_l_ee2);
x86_l_ead:
	/* 0xead: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_eb4:
	/* 0xeb4: jmp    da6 <sys_exit_submit+0xda6> */
	X86_SIM_X86_JMP(0xeb4, 0xda6, x86_l_da6);
x86_l_eb9:
	/* 0xeb9: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_ebe:
	/* 0xebe: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_ec1:
	/* 0xec1: call   ec6 <sys_exit_submit+0xec6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_ec6:
	/* 0xec6: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ec9:
	/* 0xec9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_ecb:
	/* 0xecb: jg     1446 <sys_exit_submit+0x1446> */
	X86_SIM_X86_JCC(X86_CC_G, 0xecb, 0x1446, x86_l_1446);
x86_l_ed1:
	/* 0xed1: jmp    1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JMP(0xed1, 0x1479, x86_l_1479);
x86_l_ed6:
	/* 0xed6: mov    ebx,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_edb:
	/* 0xedb: jmp    ee2 <sys_exit_submit+0xee2> */
	X86_SIM_X86_JMP(0xedb, 0xee2, x86_l_ee2);
x86_l_edd:
	/* 0xedd: mov    ebx,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_ee2:
	/* 0xee2: mov    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_ee5:
	/* 0xee5: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_eed:
	/* 0xeed: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_ef3:
	/* 0xef3: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0xef3, 0x1479, x86_l_1479);
x86_l_ef9:
	/* 0xef9: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_efd:
	/* 0xefd: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_eff:
	/* 0xeff: mov    BYTE PTR [r14+rcx*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519552ULL);
x86_l_f08:
	/* 0xf08: lea    ebx,[r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_f0c:
	/* 0xf0c: cmp    ebx,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_f12:
	/* 0xf12: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf12, 0x1479, x86_l_1479);
x86_l_f18:
	/* 0xf18: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f1d:
	/* 0xf1d: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_f21:
	/* 0xf21: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_f28:
	/* 0xf28: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f2b:
	/* 0xf2b: jns    f6b <sys_exit_submit+0xf6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf2b, 0xf6b, x86_l_f6b);
x86_l_f2d:
	/* 0xf2d: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f30:
	/* 0xf30: jns    f84 <sys_exit_submit+0xf84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf30, 0xf84, x86_l_f84);
x86_l_f32:
	/* 0xf32: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f34:
	/* 0xf34: cmp    r15d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_f38:
	/* 0xf38: jb     f54 <sys_exit_submit+0xf54> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf38, 0xf54, x86_l_f54);
x86_l_f3a:
	/* 0xf3a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f3c:
	/* 0xf3c: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_f3e:
	/* 0xf3e: mov    rdx,QWORD PTR [rbp+rax*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_f43:
	/* 0xf43: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_f47:
	/* 0xf47: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f4a:
	/* 0xf4a: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_f4d:
	/* 0xf4d: cmp    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_f50:
	/* 0xf50: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_f52:
	/* 0xf52: jbe    f3c <sys_exit_submit+0xf3c> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xf52, 0xf3c, x86_l_f3c);
x86_l_f54:
	/* 0xf54: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_f58:
	/* 0xf58: jne    f93 <sys_exit_submit+0xf93> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf58, 0xf93, x86_l_f93);
x86_l_f5a:
	/* 0xf5a: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_f5e:
	/* 0xf5e: jne    fa5 <sys_exit_submit+0xfa5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf5e, 0xfa5, x86_l_fa5);
x86_l_f60:
	/* 0xf60: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_f64:
	/* 0xf64: jne    fbd <sys_exit_submit+0xfbd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf64, 0xfbd, x86_l_fbd);
x86_l_f66:
	/* 0xf66: jmp    146a <sys_exit_submit+0x146a> */
	X86_SIM_X86_JMP(0xf66, 0x146a, x86_l_146a);
x86_l_f6b:
	/* 0xf6b: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_f6e:
	/* 0xf6e: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f71:
	/* 0xf71: call   f76 <sys_exit_submit+0xf76> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f76:
	/* 0xf76: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f79:
	/* 0xf79: jns    146a <sys_exit_submit+0x146a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf79, 0x146a, x86_l_146a);
x86_l_f7f:
	/* 0xf7f: jmp    1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JMP(0xf7f, 0x1479, x86_l_1479);
x86_l_f84:
	/* 0xf84: mov    edx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_f87:
	/* 0xf87: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f89:
	/* 0xf89: call   f8e <sys_exit_submit+0xf8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_f8e:
	/* 0xf8e: jmp    1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JMP(0xf8e, 0x1479, x86_l_1479);
x86_l_f93:
	/* 0xf93: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_f95:
	/* 0xf95: mov    edx,DWORD PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_f99:
	/* 0xf99: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_f9c:
	/* 0xf9c: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_f9f:
	/* 0xf9f: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_fa3:
	/* 0xfa3: je     f60 <sys_exit_submit+0xf60> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfa3, 0xf60, x86_l_f60);
x86_l_fa5:
	/* 0xfa5: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_fa7:
	/* 0xfa7: movzx  edx,WORD PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_fac:
	/* 0xfac: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_fb0:
	/* 0xfb0: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_fb3:
	/* 0xfb3: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_fb7:
	/* 0xfb7: je     146a <sys_exit_submit+0x146a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb7, 0x146a, x86_l_146a);
x86_l_fbd:
	/* 0xfbd: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_fbf:
	/* 0xfbf: movzx  ecx,BYTE PTR [rbp+rax*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_fc4:
	/* 0xfc4: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_fc7:
	/* 0xfc7: jmp    146a <sys_exit_submit+0x146a> */
	X86_SIM_X86_JMP(0xfc7, 0x146a, x86_l_146a);
x86_l_fcc:
	/* 0xfcc: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fcf:
	/* 0xfcf: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_fd6:
	/* 0xfd6: mov    DWORD PTR [rsp+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_fda:
	/* 0xfda: mov    DWORD PTR [rsp+0x84],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_fe5:
	/* 0xfe5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_fec:
	/* 0xfec: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_ff4:
	/* 0xff4: call   ff9 <sys_exit_submit+0xff9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ff9:
	/* 0xff9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ffc:
	/* 0xffc: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0xffc, 0x2896, x86_l_2896);
x86_l_1002:
	/* 0x1002: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1005:
	/* 0x1005: mov    eax,DWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1009:
	/* 0x1009: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_100d:
	/* 0x100d: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1012:
	/* 0x1012: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1015:
	/* 0x1015: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1017:
	/* 0x1017: call   101c <sys_exit_submit+0x101c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_101c:
	/* 0x101c: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1023:
	/* 0x1023: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1028:
	/* 0x1028: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_102d:
	/* 0x102d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1030:
	/* 0x1030: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1033:
	/* 0x1033: call   1038 <sys_exit_submit+0x1038> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1038:
	/* 0x1038: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_103d:
	/* 0x103d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1040:
	/* 0x1040: call   1045 <sys_exit_submit+0x1045> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1045:
	/* 0x1045: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_104d:
	/* 0x104d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1050:
	/* 0x1050: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1053:
	/* 0x1053: jne    1f7 <sys_exit_submit+0x1f7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1053, 0x1f7, x86_l_1f7);
x86_l_1059:
	/* 0x1059: jmp    2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JMP(0x1059, 0x2896, x86_l_2896);
x86_l_105e:
	/* 0x105e: mov    QWORD PTR [rsp+0x28],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1063:
	/* 0x1063: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_106a:
	/* 0x106a: mov    DWORD PTR [rsp+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_106e:
	/* 0x106e: mov    DWORD PTR [rsp+0x84],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 566935683072ULL);
x86_l_1079:
	/* 0x1079: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1080:
	/* 0x1080: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_1088:
	/* 0x1088: call   108d <sys_exit_submit+0x108d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_108d:
	/* 0x108d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1090:
	/* 0x1090: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1090, 0x2896, x86_l_2896);
x86_l_1096:
	/* 0x1096: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1099:
	/* 0x1099: mov    eax,DWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_109d:
	/* 0x109d: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10a1:
	/* 0x10a1: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_10a6:
	/* 0x10a6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10a9:
	/* 0x10a9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ab:
	/* 0x10ab: call   10b0 <sys_exit_submit+0x10b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_10b0:
	/* 0x10b0: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_10b7:
	/* 0x10b7: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10bc:
	/* 0x10bc: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_10c1:
	/* 0x10c1: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10c4:
	/* 0x10c4: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10c7:
	/* 0x10c7: call   10cc <sys_exit_submit+0x10cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_10cc:
	/* 0x10cc: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_10d1:
	/* 0x10d1: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10d4:
	/* 0x10d4: call   10d9 <sys_exit_submit+0x10d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10d9:
	/* 0x10d9: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10de:
	/* 0x10de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e1:
	/* 0x10e1: je     2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e1, 0x2896, x86_l_2896);
x86_l_10e7:
	/* 0x10e7: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_10ee:
	/* 0x10ee: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_10f2:
	/* 0x10f2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10f5:
	/* 0x10f5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10f8:
	/* 0x10f8: jns    12d9 <sys_exit_submit+0x12d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10f8, 0x12d9, x86_l_12d9);
x86_l_10fe:
	/* 0x10fe: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1101:
	/* 0x1101: jmp    12dc <sys_exit_submit+0x12dc> */
	X86_SIM_X86_JMP(0x1101, 0x12dc, x86_l_12dc);
x86_l_1106:
	/* 0x1106: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1109:
	/* 0x1109: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_110d:
	/* 0x110d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1110:
	/* 0x1110: jns    12be <sys_exit_submit+0x12be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1110, 0x12be, x86_l_12be);
x86_l_1116:
	/* 0x1116: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1119:
	/* 0x1119: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1120:
	/* 0x1120: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1124:
	/* 0x1124: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_112b:
	/* 0x112b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_112f:
	/* 0x112f: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1136:
	/* 0x1136: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_113a:
	/* 0x113a: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1141:
	/* 0x1141: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1145:
	/* 0x1145: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_114c:
	/* 0x114c: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1150:
	/* 0x1150: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1157:
	/* 0x1157: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_115b:
	/* 0x115b: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1162:
	/* 0x1162: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1166:
	/* 0x1166: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_116d:
	/* 0x116d: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1171:
	/* 0x1171: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1178:
	/* 0x1178: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_117c:
	/* 0x117c: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1183:
	/* 0x1183: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1187:
	/* 0x1187: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_118e:
	/* 0x118e: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1192:
	/* 0x1192: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1199:
	/* 0x1199: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_119d:
	/* 0x119d: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_11a4:
	/* 0x11a4: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_11a8:
	/* 0x11a8: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_11af:
	/* 0x11af: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_11b3:
	/* 0x11b3: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_11ba:
	/* 0x11ba: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_11be:
	/* 0x11be: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_11c5:
	/* 0x11c5: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_11cc:
	/* 0x11cc: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_11d3:
	/* 0x11d3: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_11da:
	/* 0x11da: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_11e1:
	/* 0x11e1: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_11e8:
	/* 0x11e8: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_11ef:
	/* 0x11ef: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_11f6:
	/* 0x11f6: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_11fd:
	/* 0x11fd: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1204:
	/* 0x1204: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_120b:
	/* 0x120b: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1212:
	/* 0x1212: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1219:
	/* 0x1219: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1220:
	/* 0x1220: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1227:
	/* 0x1227: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_122e:
	/* 0x122e: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1235:
	/* 0x1235: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_123c:
	/* 0x123c: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1243:
	/* 0x1243: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_124a:
	/* 0x124a: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1251:
	/* 0x1251: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1258:
	/* 0x1258: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_125f:
	/* 0x125f: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1266:
	/* 0x1266: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_126d:
	/* 0x126d: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1274:
	/* 0x1274: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_127b:
	/* 0x127b: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1282:
	/* 0x1282: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1289:
	/* 0x1289: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1290:
	/* 0x1290: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1297:
	/* 0x1297: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_129e:
	/* 0x129e: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_12a5:
	/* 0x12a5: movzx  eax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_12aa:
	/* 0x12aa: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_12af:
	/* 0x12af: jmp    2d0 <sys_exit_submit+0x2d0> */
	X86_SIM_X86_JMP(0x12af, 0x2d0, x86_l_2d0);
x86_l_12b4:
	/* 0x12b4: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_12b9:
	/* 0x12b9: jmp    f87 <sys_exit_submit+0xf87> */
	X86_SIM_X86_JMP(0x12b9, 0xf87, x86_l_f87);
x86_l_12be:
	/* 0x12be: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_12c5:
	/* 0x12c5: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_12ca:
	/* 0x12ca: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_12cd:
	/* 0x12cd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12cf:
	/* 0x12cf: call   12d4 <sys_exit_submit+0x12d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_12d4:
	/* 0x12d4: jmp    2896 <sys_exit_submit+0x2896> */
	X86_SIM_X86_JMP(0x12d4, 0x2896, x86_l_2896);
x86_l_12d9:
	/* 0x12d9: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12dc:
	/* 0x12dc: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12e0:
	/* 0x12e0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12e3:
	/* 0x12e3: jns    12ea <sys_exit_submit+0x12ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12e3, 0x12ea, x86_l_12ea);
x86_l_12e5:
	/* 0x12e5: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12e8:
	/* 0x12e8: jmp    12ec <sys_exit_submit+0x12ec> */
	X86_SIM_X86_JMP(0x12e8, 0x12ec, x86_l_12ec);
x86_l_12ea:
	/* 0x12ea: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ec:
	/* 0x12ec: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_12f0:
	/* 0x12f0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12f2:
	/* 0x12f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12f5:
	/* 0x12f5: jns    12fc <sys_exit_submit+0x12fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f5, 0x12fc, x86_l_12fc);
x86_l_12f7:
	/* 0x12f7: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12fa:
	/* 0x12fa: jmp    12ff <sys_exit_submit+0x12ff> */
	X86_SIM_X86_JMP(0x12fa, 0x12ff, x86_l_12ff);
x86_l_12fc:
	/* 0x12fc: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ff:
	/* 0x12ff: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1304:
	/* 0x1304: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1307:
	/* 0x1307: jns    130b <sys_exit_submit+0x130b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1307, 0x130b, x86_l_130b);
x86_l_1309:
	/* 0x1309: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_130b:
	/* 0x130b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1310:
	/* 0x1310: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1313:
	/* 0x1313: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1317:
	/* 0x1317: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_131a:
	/* 0x131a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_131c:
	/* 0x131c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_131f:
	/* 0x131f: jns    1326 <sys_exit_submit+0x1326> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x131f, 0x1326, x86_l_1326);
x86_l_1321:
	/* 0x1321: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1324:
	/* 0x1324: jmp    1328 <sys_exit_submit+0x1328> */
	X86_SIM_X86_JMP(0x1324, 0x1328, x86_l_1328);
x86_l_1326:
	/* 0x1326: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1328:
	/* 0x1328: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_132b:
	/* 0x132b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_132e:
	/* 0x132e: jns    1332 <sys_exit_submit+0x1332> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x132e, 0x1332, x86_l_1332);
x86_l_1330:
	/* 0x1330: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1332:
	/* 0x1332: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1334:
	/* 0x1334: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1338:
	/* 0x1338: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_133b:
	/* 0x133b: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_133f:
	/* 0x133f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1341:
	/* 0x1341: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1344:
	/* 0x1344: jns    1348 <sys_exit_submit+0x1348> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1344, 0x1348, x86_l_1348);
x86_l_1346:
	/* 0x1346: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1348:
	/* 0x1348: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_134d:
	/* 0x134d: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1350:
	/* 0x1350: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1353:
	/* 0x1353: jns    135a <sys_exit_submit+0x135a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1353, 0x135a, x86_l_135a);
x86_l_1355:
	/* 0x1355: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1358:
	/* 0x1358: jmp    135c <sys_exit_submit+0x135c> */
	X86_SIM_X86_JMP(0x1358, 0x135c, x86_l_135c);
x86_l_135a:
	/* 0x135a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_135c:
	/* 0x135c: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1360:
	/* 0x1360: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1362:
	/* 0x1362: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1365:
	/* 0x1365: jns    136c <sys_exit_submit+0x136c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1365, 0x136c, x86_l_136c);
x86_l_1367:
	/* 0x1367: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_136a:
	/* 0x136a: jmp    136e <sys_exit_submit+0x136e> */
	X86_SIM_X86_JMP(0x136a, 0x136e, x86_l_136e);
x86_l_136c:
	/* 0x136c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_136e:
	/* 0x136e: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1371:
	/* 0x1371: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1374:
	/* 0x1374: jns    1378 <sys_exit_submit+0x1378> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1374, 0x1378, x86_l_1378);
x86_l_1376:
	/* 0x1376: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1378:
	/* 0x1378: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_137a:
	/* 0x137a: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_137e:
	/* 0x137e: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1381:
	/* 0x1381: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1385:
	/* 0x1385: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1387:
	/* 0x1387: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_138a:
	/* 0x138a: jns    138e <sys_exit_submit+0x138e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138a, 0x138e, x86_l_138e);
x86_l_138c:
	/* 0x138c: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_138e:
	/* 0x138e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1393:
	/* 0x1393: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1396:
	/* 0x1396: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1398:
	/* 0x1398: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_139b:
	/* 0x139b: jns    13a2 <sys_exit_submit+0x13a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x139b, 0x13a2, x86_l_13a2);
x86_l_139d:
	/* 0x139d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13a0:
	/* 0x13a0: jmp    13a4 <sys_exit_submit+0x13a4> */
	X86_SIM_X86_JMP(0x13a0, 0x13a4, x86_l_13a4);
x86_l_13a2:
	/* 0x13a2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13a4:
	/* 0x13a4: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13a7:
	/* 0x13a7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13aa:
	/* 0x13aa: jns    13ae <sys_exit_submit+0x13ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13aa, 0x13ae, x86_l_13ae);
x86_l_13ac:
	/* 0x13ac: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ae:
	/* 0x13ae: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_13b0:
	/* 0x13b0: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_13b4:
	/* 0x13b4: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_13b7:
	/* 0x13b7: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_13bb:
	/* 0x13bb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13bd:
	/* 0x13bd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13c0:
	/* 0x13c0: jns    13c7 <sys_exit_submit+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13c0, 0x13c7, x86_l_13c7);
x86_l_13c2:
	/* 0x13c2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13c5:
	/* 0x13c5: jmp    13c9 <sys_exit_submit+0x13c9> */
	X86_SIM_X86_JMP(0x13c5, 0x13c9, x86_l_13c9);
x86_l_13c7:
	/* 0x13c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13c9:
	/* 0x13c9: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_13cd:
	/* 0x13cd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13d0:
	/* 0x13d0: jns    13d4 <sys_exit_submit+0x13d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13d0, 0x13d4, x86_l_13d4);
x86_l_13d2:
	/* 0x13d2: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13d4:
	/* 0x13d4: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13d9:
	/* 0x13d9: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13dc:
	/* 0x13dc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13de:
	/* 0x13de: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_13e1:
	/* 0x13e1: jns    13e8 <sys_exit_submit+0x13e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e1, 0x13e8, x86_l_13e8);
x86_l_13e3:
	/* 0x13e3: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e6:
	/* 0x13e6: jmp    13ea <sys_exit_submit+0x13ea> */
	X86_SIM_X86_JMP(0x13e6, 0x13ea, x86_l_13ea);
x86_l_13e8:
	/* 0x13e8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13ea:
	/* 0x13ea: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_13ed:
	/* 0x13ed: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_13f0:
	/* 0x13f0: jns    13f4 <sys_exit_submit+0x13f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13f0, 0x13f4, x86_l_13f4);
x86_l_13f2:
	/* 0x13f2: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13f4:
	/* 0x13f4: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_13f6:
	/* 0x13f6: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_13fa:
	/* 0x13fa: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_13fd:
	/* 0x13fd: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1401:
	/* 0x1401: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1403:
	/* 0x1403: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1406:
	/* 0x1406: jns    140d <sys_exit_submit+0x140d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1406, 0x140d, x86_l_140d);
x86_l_1408:
	/* 0x1408: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_140b:
	/* 0x140b: jmp    140f <sys_exit_submit+0x140f> */
	X86_SIM_X86_JMP(0x140b, 0x140f, x86_l_140f);
x86_l_140d:
	/* 0x140d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_140f:
	/* 0x140f: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1413:
	/* 0x1413: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1416:
	/* 0x1416: jns    141a <sys_exit_submit+0x141a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1416, 0x141a, x86_l_141a);
x86_l_1418:
	/* 0x1418: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_141a:
	/* 0x141a: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_141c:
	/* 0x141c: jne    28d8 <sys_exit_submit+0x28d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x141c, 0x28d8, x86_l_28d8);
x86_l_1422:
	/* 0x1422: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1424:
	/* 0x1424: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1427:
	/* 0x1427: jns    28ae <sys_exit_submit+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1427, 0x28ae, x86_l_28ae);
x86_l_142d:
	/* 0x142d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1430:
	/* 0x1430: jmp    28b0 <sys_exit_submit+0x28b0> */
	X86_SIM_X86_JMP(0x1430, 0x28b0, x86_l_28b0);
x86_l_1435:
	/* 0x1435: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_143c:
	/* 0x143c: mov    ebx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1441:
	/* 0x1441: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1446:
	/* 0x1446: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_144e:
	/* 0x144e: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1455:
	/* 0x1455: ja     1479 <sys_exit_submit+0x1479> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1455, 0x1479, x86_l_1479);
x86_l_1457:
	/* 0x1457: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_145f:
	/* 0x145f: add    bx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_1467:
	/* 0x1467: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_146a:
	/* 0x146a: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1472:
	/* 0x1472: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1479:
	/* 0x1479: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1480:
	/* 0x1480: shr    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 8ULL);
x86_l_1484:
	/* 0x1484: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1487:
	/* 0x1487: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_148a:
	/* 0x148a: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x148a, 0x173d, x86_l_173d);
x86_l_1490:
	/* 0x1490: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1492:
	/* 0x1492: je     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1492, 0x173d, x86_l_173d);
x86_l_1498:
	/* 0x1498: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_149b:
	/* 0x149b: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_149d:
	/* 0x149d: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_14a4:
	/* 0x14a4: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_14a9:
	/* 0x14a9: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_14ae:
	/* 0x14ae: mov    r8,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14b3:
	/* 0x14b3: lea    rbx,[r8+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_14b7:
	/* 0x14b7: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_14bd:
	/* 0x14bd: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14c1:
	/* 0x14c1: jae    14c6 <sys_exit_submit+0x14c6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x14c1, 0x14c6, x86_l_14c6);
x86_l_14c3:
	/* 0x14c3: mov    rbx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c6:
	/* 0x14c6: mov    ebp,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_14c9:
	/* 0x14c9: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_14cf:
	/* 0x14cf: je     14e2 <sys_exit_submit+0x14e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14cf, 0x14e2, x86_l_14e2);
x86_l_14d1:
	/* 0x14d1: lea    eax,[rbp-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_14d4:
	/* 0x14d4: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_14d7:
	/* 0x14d7: jae    161a <sys_exit_submit+0x161a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x14d7, 0x161a, x86_l_161a);
x86_l_14dd:
	/* 0x14dd: jmp    173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JMP(0x14dd, 0x173d, x86_l_173d);
x86_l_14e2:
	/* 0x14e2: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_14e5:
	/* 0x14e5: je     1523 <sys_exit_submit+0x1523> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e5, 0x1523, x86_l_1523);
x86_l_14e7:
	/* 0x14e7: mov    r15d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_14ed:
	/* 0x14ed: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_14f0:
	/* 0x14f0: je     1617 <sys_exit_submit+0x1617> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f0, 0x1617, x86_l_1617);
x86_l_14f6:
	/* 0x14f6: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_14f9:
	/* 0x14f9: jne    14d1 <sys_exit_submit+0x14d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14f9, 0x14d1, x86_l_14d1);
x86_l_14fb:
	/* 0x14fb: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_14fe:
	/* 0x14fe: je     15a1 <sys_exit_submit+0x15a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14fe, 0x15a1, x86_l_15a1);
x86_l_1504:
	/* 0x1504: jns    15b2 <sys_exit_submit+0x15b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1504, 0x15b2, x86_l_15b2);
x86_l_150a:
	/* 0x150a: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_150d:
	/* 0x150d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1510:
	/* 0x1510: jns    15e8 <sys_exit_submit+0x15e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1510, 0x15e8, x86_l_15e8);
x86_l_1516:
	/* 0x1516: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1519:
	/* 0x1519: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_151e:
	/* 0x151e: jmp    15c9 <sys_exit_submit+0x15c9> */
	X86_SIM_X86_JMP(0x151e, 0x15c9, x86_l_15c9);
x86_l_1523:
	/* 0x1523: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_152b:
	/* 0x152b: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1531:
	/* 0x1531: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1531, 0x173d, x86_l_173d);
x86_l_1537:
	/* 0x1537: mov    BYTE PTR [r14+rax*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519553ULL);
x86_l_1540:
	/* 0x1540: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1548:
	/* 0x1548: mov    WORD PTR [r14+0x7d8e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32142ULL);
x86_l_1550:
	/* 0x1550: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1556:
	/* 0x1556: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1556, 0x173d, x86_l_173d);
x86_l_155c:
	/* 0x155c: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1561:
	/* 0x1561: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1565:
	/* 0x1565: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_156c:
	/* 0x156c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_156f:
	/* 0x156f: jns    15f4 <sys_exit_submit+0x15f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156f, 0x15f4, x86_l_15f4);
x86_l_1575:
	/* 0x1575: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1578:
	/* 0x1578: jns    16f0 <sys_exit_submit+0x16f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1578, 0x16f0, x86_l_16f0);
x86_l_157e:
	/* 0x157e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1580:
	/* 0x1580: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1587:
	/* 0x1587: je     16f7 <sys_exit_submit+0x16f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1587, 0x16f7, x86_l_16f7);
x86_l_158d:
	/* 0x158d: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1591:
	/* 0x1591: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1595:
	/* 0x1595: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1598:
	/* 0x1598: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_159b:
	/* 0x159b: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_159d:
	/* 0x159d: jne    1580 <sys_exit_submit+0x1580> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x159d, 0x1580, x86_l_1580);
x86_l_159f:
	/* 0x159f: jmp    1601 <sys_exit_submit+0x1601> */
	X86_SIM_X86_JMP(0x159f, 0x1601, x86_l_1601);
x86_l_15a1:
	/* 0x15a1: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_15a8:
	/* 0x15a8: lea    rbx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15ad:
	/* 0x15ad: jmp    14d1 <sys_exit_submit+0x14d1> */
	X86_SIM_X86_JMP(0x15ad, 0x14d1, x86_l_14d1);
x86_l_15b2:
	/* 0x15b2: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15b7:
	/* 0x15b7: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_15bc:
	/* 0x15bc: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15bf:
	/* 0x15bf: call   15c4 <sys_exit_submit+0x15c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15c4:
	/* 0x15c4: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_15c9:
	/* 0x15c9: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_15cd:
	/* 0x15cd: je     1611 <sys_exit_submit+0x1611> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15cd, 0x1611, x86_l_1611);
x86_l_15cf:
	/* 0x15cf: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_15d2:
	/* 0x15d2: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_15d5:
	/* 0x15d5: je     1617 <sys_exit_submit+0x1617> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15d5, 0x1617, x86_l_1617);
x86_l_15d7:
	/* 0x15d7: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_15da:
	/* 0x15da: jne    14d1 <sys_exit_submit+0x14d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15da, 0x14d1, x86_l_14d1);
x86_l_15e0:
	/* 0x15e0: mov    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_15e6:
	/* 0x15e6: jmp    1617 <sys_exit_submit+0x1617> */
	X86_SIM_X86_JMP(0x15e6, 0x1617, x86_l_1617);
x86_l_15e8:
	/* 0x15e8: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_15ef:
	/* 0x15ef: jmp    14d1 <sys_exit_submit+0x14d1> */
	X86_SIM_X86_JMP(0x15ef, 0x14d1, x86_l_14d1);
x86_l_15f4:
	/* 0x15f4: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_15f9:
	/* 0x15f9: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15fc:
	/* 0x15fc: call   1601 <sys_exit_submit+0x1601> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1601:
	/* 0x1601: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1604:
	/* 0x1604: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1606:
	/* 0x1606: jg     1709 <sys_exit_submit+0x1709> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1606, 0x1709, x86_l_1709);
x86_l_160c:
	/* 0x160c: jmp    173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JMP(0x160c, 0x173d, x86_l_173d);
x86_l_1611:
	/* 0x1611: mov    r15d,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_1617:
	/* 0x1617: mov    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_161a:
	/* 0x161a: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1622:
	/* 0x1622: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_1628:
	/* 0x1628: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1628, 0x173d, x86_l_173d);
x86_l_162e:
	/* 0x162e: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1632:
	/* 0x1632: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1634:
	/* 0x1634: mov    BYTE PTR [r14+rcx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519553ULL);
x86_l_163d:
	/* 0x163d: lea    r15d,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1641:
	/* 0x1641: cmp    r15d,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1648:
	/* 0x1648: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1648, 0x173d, x86_l_173d);
x86_l_164e:
	/* 0x164e: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1653:
	/* 0x1653: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1657:
	/* 0x1657: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_165e:
	/* 0x165e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1661:
	/* 0x1661: jns    169e <sys_exit_submit+0x169e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1661, 0x169e, x86_l_169e);
x86_l_1663:
	/* 0x1663: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1666:
	/* 0x1666: jns    16b6 <sys_exit_submit+0x16b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1666, 0x16b6, x86_l_16b6);
x86_l_1668:
	/* 0x1668: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_166a:
	/* 0x166a: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_166d:
	/* 0x166d: jb     1687 <sys_exit_submit+0x1687> */
	X86_SIM_X86_JCC(X86_CC_B, 0x166d, 0x1687, x86_l_1687);
x86_l_166f:
	/* 0x166f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1671:
	/* 0x1671: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1673:
	/* 0x1673: mov    rdx,QWORD PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1677:
	/* 0x1677: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_167b:
	/* 0x167b: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_167e:
	/* 0x167e: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1681:
	/* 0x1681: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1683:
	/* 0x1683: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1685:
	/* 0x1685: jbe    1671 <sys_exit_submit+0x1671> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1685, 0x1671, x86_l_1671);
x86_l_1687:
	/* 0x1687: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_168b:
	/* 0x168b: jne    16c1 <sys_exit_submit+0x16c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x168b, 0x16c1, x86_l_16c1);
x86_l_168d:
	/* 0x168d: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1691:
	/* 0x1691: jne    16d2 <sys_exit_submit+0x16d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1691, 0x16d2, x86_l_16d2);
x86_l_1693:
	/* 0x1693: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1697:
	/* 0x1697: jne    16e5 <sys_exit_submit+0x16e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1697, 0x16e5, x86_l_16e5);
x86_l_1699:
	/* 0x1699: jmp    172e <sys_exit_submit+0x172e> */
	X86_SIM_X86_JMP(0x1699, 0x172e, x86_l_172e);
x86_l_169e:
	/* 0x169e: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_16a0:
	/* 0x16a0: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16a3:
	/* 0x16a3: call   16a8 <sys_exit_submit+0x16a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_16a8:
	/* 0x16a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16ab:
	/* 0x16ab: jns    172e <sys_exit_submit+0x172e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ab, 0x172e, x86_l_172e);
x86_l_16b1:
	/* 0x16b1: jmp    173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JMP(0x16b1, 0x173d, x86_l_173d);
x86_l_16b6:
	/* 0x16b6: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_16b8:
	/* 0x16b8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ba:
	/* 0x16ba: call   16bf <sys_exit_submit+0x16bf> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_16bf:
	/* 0x16bf: jmp    173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JMP(0x16bf, 0x173d, x86_l_173d);
x86_l_16c1:
	/* 0x16c1: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16c3:
	/* 0x16c3: mov    edx,DWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_16c6:
	/* 0x16c6: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_16c9:
	/* 0x16c9: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_16cc:
	/* 0x16cc: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_16d0:
	/* 0x16d0: je     1693 <sys_exit_submit+0x1693> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d0, 0x1693, x86_l_1693);
x86_l_16d2:
	/* 0x16d2: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16d4:
	/* 0x16d4: movzx  edx,WORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_16d8:
	/* 0x16d8: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_16dc:
	/* 0x16dc: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_16df:
	/* 0x16df: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_16e3:
	/* 0x16e3: je     172e <sys_exit_submit+0x172e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e3, 0x172e, x86_l_172e);
x86_l_16e5:
	/* 0x16e5: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16e7:
	/* 0x16e7: movzx  ecx,BYTE PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_16eb:
	/* 0x16eb: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_16ee:
	/* 0x16ee: jmp    172e <sys_exit_submit+0x172e> */
	X86_SIM_X86_JMP(0x16ee, 0x172e, x86_l_172e);
x86_l_16f0:
	/* 0x16f0: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_16f5:
	/* 0x16f5: jmp    16b8 <sys_exit_submit+0x16b8> */
	X86_SIM_X86_JMP(0x16f5, 0x16b8, x86_l_16b8);
x86_l_16f7:
	/* 0x16f7: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_16fe:
	/* 0x16fe: mov    r15d,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1704:
	/* 0x1704: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1709:
	/* 0x1709: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1711:
	/* 0x1711: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1718:
	/* 0x1718: ja     173d <sys_exit_submit+0x173d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1718, 0x173d, x86_l_173d);
x86_l_171a:
	/* 0x171a: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_1722:
	/* 0x1722: add    r15w,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_172a:
	/* 0x172a: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_172e:
	/* 0x172e: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1736:
	/* 0x1736: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_173d:
	/* 0x173d: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1744:
	/* 0x1744: shr    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 16ULL);
x86_l_1748:
	/* 0x1748: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_174b:
	/* 0x174b: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_174e:
	/* 0x174e: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x174e, 0x1a04, x86_l_1a04);
x86_l_1754:
	/* 0x1754: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1756:
	/* 0x1756: je     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1756, 0x1a04, x86_l_1a04);
x86_l_175c:
	/* 0x175c: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_175f:
	/* 0x175f: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1761:
	/* 0x1761: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1768:
	/* 0x1768: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_176d:
	/* 0x176d: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_1772:
	/* 0x1772: mov    r8,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1777:
	/* 0x1777: lea    rbx,[r8+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_177e:
	/* 0x177e: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_1784:
	/* 0x1784: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1788:
	/* 0x1788: jae    178d <sys_exit_submit+0x178d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1788, 0x178d, x86_l_178d);
x86_l_178a:
	/* 0x178a: mov    rbx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_178d:
	/* 0x178d: mov    ebp,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1790:
	/* 0x1790: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_1796:
	/* 0x1796: je     17a9 <sys_exit_submit+0x17a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1796, 0x17a9, x86_l_17a9);
x86_l_1798:
	/* 0x1798: lea    eax,[rbp-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_179b:
	/* 0x179b: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_179e:
	/* 0x179e: jae    18e1 <sys_exit_submit+0x18e1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x179e, 0x18e1, x86_l_18e1);
x86_l_17a4:
	/* 0x17a4: jmp    1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JMP(0x17a4, 0x1a04, x86_l_1a04);
x86_l_17a9:
	/* 0x17a9: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_17ac:
	/* 0x17ac: je     17ea <sys_exit_submit+0x17ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ac, 0x17ea, x86_l_17ea);
x86_l_17ae:
	/* 0x17ae: mov    r15d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_17b4:
	/* 0x17b4: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_17b7:
	/* 0x17b7: je     18de <sys_exit_submit+0x18de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b7, 0x18de, x86_l_18de);
x86_l_17bd:
	/* 0x17bd: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_17c0:
	/* 0x17c0: jne    1798 <sys_exit_submit+0x1798> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17c0, 0x1798, x86_l_1798);
x86_l_17c2:
	/* 0x17c2: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17c5:
	/* 0x17c5: je     1868 <sys_exit_submit+0x1868> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17c5, 0x1868, x86_l_1868);
x86_l_17cb:
	/* 0x17cb: jns    1879 <sys_exit_submit+0x1879> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17cb, 0x1879, x86_l_1879);
x86_l_17d1:
	/* 0x17d1: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17d4:
	/* 0x17d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17d7:
	/* 0x17d7: jns    18af <sys_exit_submit+0x18af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17d7, 0x18af, x86_l_18af);
x86_l_17dd:
	/* 0x17dd: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_17e0:
	/* 0x17e0: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_17e5:
	/* 0x17e5: jmp    1890 <sys_exit_submit+0x1890> */
	X86_SIM_X86_JMP(0x17e5, 0x1890, x86_l_1890);
x86_l_17ea:
	/* 0x17ea: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_17f2:
	/* 0x17f2: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_17f8:
	/* 0x17f8: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17f8, 0x1a04, x86_l_1a04);
x86_l_17fe:
	/* 0x17fe: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_1807:
	/* 0x1807: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_180f:
	/* 0x180f: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_1817:
	/* 0x1817: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_181d:
	/* 0x181d: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x181d, 0x1a04, x86_l_1a04);
x86_l_1823:
	/* 0x1823: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1828:
	/* 0x1828: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_182c:
	/* 0x182c: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1833:
	/* 0x1833: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1836:
	/* 0x1836: jns    18bb <sys_exit_submit+0x18bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1836, 0x18bb, x86_l_18bb);
x86_l_183c:
	/* 0x183c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_183f:
	/* 0x183f: jns    19b7 <sys_exit_submit+0x19b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x183f, 0x19b7, x86_l_19b7);
x86_l_1845:
	/* 0x1845: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1847:
	/* 0x1847: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_184e:
	/* 0x184e: je     19be <sys_exit_submit+0x19be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184e, 0x19be, x86_l_19be);
x86_l_1854:
	/* 0x1854: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1858:
	/* 0x1858: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_185c:
	/* 0x185c: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_185f:
	/* 0x185f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1862:
	/* 0x1862: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1864:
	/* 0x1864: jne    1847 <sys_exit_submit+0x1847> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1864, 0x1847, x86_l_1847);
x86_l_1866:
	/* 0x1866: jmp    18c8 <sys_exit_submit+0x18c8> */
	X86_SIM_X86_JMP(0x1866, 0x18c8, x86_l_18c8);
x86_l_1868:
	/* 0x1868: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_186f:
	/* 0x186f: lea    rbx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1874:
	/* 0x1874: jmp    1798 <sys_exit_submit+0x1798> */
	X86_SIM_X86_JMP(0x1874, 0x1798, x86_l_1798);
x86_l_1879:
	/* 0x1879: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_187e:
	/* 0x187e: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1883:
	/* 0x1883: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1886:
	/* 0x1886: call   188b <sys_exit_submit+0x188b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_188b:
	/* 0x188b: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_1890:
	/* 0x1890: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_1894:
	/* 0x1894: je     18d8 <sys_exit_submit+0x18d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1894, 0x18d8, x86_l_18d8);
x86_l_1896:
	/* 0x1896: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1899:
	/* 0x1899: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_189c:
	/* 0x189c: je     18de <sys_exit_submit+0x18de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x189c, 0x18de, x86_l_18de);
x86_l_189e:
	/* 0x189e: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_18a1:
	/* 0x18a1: jne    1798 <sys_exit_submit+0x1798> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18a1, 0x1798, x86_l_1798);
x86_l_18a7:
	/* 0x18a7: mov    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_18ad:
	/* 0x18ad: jmp    18de <sys_exit_submit+0x18de> */
	X86_SIM_X86_JMP(0x18ad, 0x18de, x86_l_18de);
x86_l_18af:
	/* 0x18af: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_18b6:
	/* 0x18b6: jmp    1798 <sys_exit_submit+0x1798> */
	X86_SIM_X86_JMP(0x18b6, 0x1798, x86_l_1798);
x86_l_18bb:
	/* 0x18bb: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_18c0:
	/* 0x18c0: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18c3:
	/* 0x18c3: call   18c8 <sys_exit_submit+0x18c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_18c8:
	/* 0x18c8: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18cb:
	/* 0x18cb: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_18cd:
	/* 0x18cd: jg     19d0 <sys_exit_submit+0x19d0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x18cd, 0x19d0, x86_l_19d0);
x86_l_18d3:
	/* 0x18d3: jmp    1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JMP(0x18d3, 0x1a04, x86_l_1a04);
x86_l_18d8:
	/* 0x18d8: mov    r15d,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_18de:
	/* 0x18de: mov    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_18e1:
	/* 0x18e1: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_18e9:
	/* 0x18e9: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_18ef:
	/* 0x18ef: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x18ef, 0x1a04, x86_l_1a04);
x86_l_18f5:
	/* 0x18f5: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_18f9:
	/* 0x18f9: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_18fb:
	/* 0x18fb: mov    BYTE PTR [r14+rcx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519554ULL);
x86_l_1904:
	/* 0x1904: lea    r15d,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1908:
	/* 0x1908: cmp    r15d,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_190f:
	/* 0x190f: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x190f, 0x1a04, x86_l_1a04);
x86_l_1915:
	/* 0x1915: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_191a:
	/* 0x191a: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_191e:
	/* 0x191e: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_1925:
	/* 0x1925: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1928:
	/* 0x1928: jns    1965 <sys_exit_submit+0x1965> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1928, 0x1965, x86_l_1965);
x86_l_192a:
	/* 0x192a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_192d:
	/* 0x192d: jns    197d <sys_exit_submit+0x197d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x192d, 0x197d, x86_l_197d);
x86_l_192f:
	/* 0x192f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1931:
	/* 0x1931: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1934:
	/* 0x1934: jb     194e <sys_exit_submit+0x194e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1934, 0x194e, x86_l_194e);
x86_l_1936:
	/* 0x1936: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1938:
	/* 0x1938: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_193a:
	/* 0x193a: mov    rdx,QWORD PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_193e:
	/* 0x193e: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1942:
	/* 0x1942: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1945:
	/* 0x1945: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1948:
	/* 0x1948: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_194a:
	/* 0x194a: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_194c:
	/* 0x194c: jbe    1938 <sys_exit_submit+0x1938> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x194c, 0x1938, x86_l_1938);
x86_l_194e:
	/* 0x194e: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1952:
	/* 0x1952: jne    1988 <sys_exit_submit+0x1988> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1952, 0x1988, x86_l_1988);
x86_l_1954:
	/* 0x1954: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1958:
	/* 0x1958: jne    1999 <sys_exit_submit+0x1999> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1958, 0x1999, x86_l_1999);
x86_l_195a:
	/* 0x195a: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_195e:
	/* 0x195e: jne    19ac <sys_exit_submit+0x19ac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x195e, 0x19ac, x86_l_19ac);
x86_l_1960:
	/* 0x1960: jmp    19f5 <sys_exit_submit+0x19f5> */
	X86_SIM_X86_JMP(0x1960, 0x19f5, x86_l_19f5);
x86_l_1965:
	/* 0x1965: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1967:
	/* 0x1967: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_196a:
	/* 0x196a: call   196f <sys_exit_submit+0x196f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_196f:
	/* 0x196f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1972:
	/* 0x1972: jns    19f5 <sys_exit_submit+0x19f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1972, 0x19f5, x86_l_19f5);
x86_l_1978:
	/* 0x1978: jmp    1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JMP(0x1978, 0x1a04, x86_l_1a04);
x86_l_197d:
	/* 0x197d: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_197f:
	/* 0x197f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1981:
	/* 0x1981: call   1986 <sys_exit_submit+0x1986> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1986:
	/* 0x1986: jmp    1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JMP(0x1986, 0x1a04, x86_l_1a04);
x86_l_1988:
	/* 0x1988: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_198a:
	/* 0x198a: mov    edx,DWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_198d:
	/* 0x198d: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1990:
	/* 0x1990: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1993:
	/* 0x1993: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1997:
	/* 0x1997: je     195a <sys_exit_submit+0x195a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1997, 0x195a, x86_l_195a);
x86_l_1999:
	/* 0x1999: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_199b:
	/* 0x199b: movzx  edx,WORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_199f:
	/* 0x199f: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_19a3:
	/* 0x19a3: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_19a6:
	/* 0x19a6: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_19aa:
	/* 0x19aa: je     19f5 <sys_exit_submit+0x19f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19aa, 0x19f5, x86_l_19f5);
x86_l_19ac:
	/* 0x19ac: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_19ae:
	/* 0x19ae: movzx  ecx,BYTE PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_19b2:
	/* 0x19b2: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_19b5:
	/* 0x19b5: jmp    19f5 <sys_exit_submit+0x19f5> */
	X86_SIM_X86_JMP(0x19b5, 0x19f5, x86_l_19f5);
x86_l_19b7:
	/* 0x19b7: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_19bc:
	/* 0x19bc: jmp    197f <sys_exit_submit+0x197f> */
	X86_SIM_X86_JMP(0x19bc, 0x197f, x86_l_197f);
x86_l_19be:
	/* 0x19be: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_19c5:
	/* 0x19c5: mov    r15d,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_19cb:
	/* 0x19cb: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_19d0:
	/* 0x19d0: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_19d8:
	/* 0x19d8: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_19df:
	/* 0x19df: ja     1a04 <sys_exit_submit+0x1a04> */
	X86_SIM_X86_JCC(X86_CC_A, 0x19df, 0x1a04, x86_l_1a04);
x86_l_19e1:
	/* 0x19e1: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_19e9:
	/* 0x19e9: add    r15w,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_19f1:
	/* 0x19f1: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_19f5:
	/* 0x19f5: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_19fd:
	/* 0x19fd: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1a04:
	/* 0x1a04: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1a0b:
	/* 0x1a0b: shr    rcx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 24ULL);
x86_l_1a0f:
	/* 0x1a0f: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1a12:
	/* 0x1a12: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1a15:
	/* 0x1a15: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a15, 0x1ccb, x86_l_1ccb);
x86_l_1a1b:
	/* 0x1a1b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1a1d:
	/* 0x1a1d: je     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1d, 0x1ccb, x86_l_1ccb);
x86_l_1a23:
	/* 0x1a23: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1a26:
	/* 0x1a26: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1a28:
	/* 0x1a28: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1a2f:
	/* 0x1a2f: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1a34:
	/* 0x1a34: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_1a39:
	/* 0x1a39: mov    r8,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3e:
	/* 0x1a3e: lea    rbx,[r8+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1a45:
	/* 0x1a45: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_1a4b:
	/* 0x1a4b: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a4f:
	/* 0x1a4f: jae    1a54 <sys_exit_submit+0x1a54> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a4f, 0x1a54, x86_l_1a54);
x86_l_1a51:
	/* 0x1a51: mov    rbx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a54:
	/* 0x1a54: mov    ebp,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1a57:
	/* 0x1a57: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_1a5d:
	/* 0x1a5d: je     1a70 <sys_exit_submit+0x1a70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5d, 0x1a70, x86_l_1a70);
x86_l_1a5f:
	/* 0x1a5f: lea    eax,[rbp-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_1a62:
	/* 0x1a62: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_1a65:
	/* 0x1a65: jae    1ba8 <sys_exit_submit+0x1ba8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a65, 0x1ba8, x86_l_1ba8);
x86_l_1a6b:
	/* 0x1a6b: jmp    1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JMP(0x1a6b, 0x1ccb, x86_l_1ccb);
x86_l_1a70:
	/* 0x1a70: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1a73:
	/* 0x1a73: je     1ab1 <sys_exit_submit+0x1ab1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a73, 0x1ab1, x86_l_1ab1);
x86_l_1a75:
	/* 0x1a75: mov    r15d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1a7b:
	/* 0x1a7b: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1a7e:
	/* 0x1a7e: je     1ba5 <sys_exit_submit+0x1ba5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a7e, 0x1ba5, x86_l_1ba5);
x86_l_1a84:
	/* 0x1a84: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a87:
	/* 0x1a87: jne    1a5f <sys_exit_submit+0x1a5f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a87, 0x1a5f, x86_l_1a5f);
x86_l_1a89:
	/* 0x1a89: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a8c:
	/* 0x1a8c: je     1b2f <sys_exit_submit+0x1b2f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8c, 0x1b2f, x86_l_1b2f);
x86_l_1a92:
	/* 0x1a92: jns    1b40 <sys_exit_submit+0x1b40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a92, 0x1b40, x86_l_1b40);
x86_l_1a98:
	/* 0x1a98: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a9b:
	/* 0x1a9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a9e:
	/* 0x1a9e: jns    1b76 <sys_exit_submit+0x1b76> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a9e, 0x1b76, x86_l_1b76);
x86_l_1aa4:
	/* 0x1aa4: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1aa7:
	/* 0x1aa7: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1aac:
	/* 0x1aac: jmp    1b57 <sys_exit_submit+0x1b57> */
	X86_SIM_X86_JMP(0x1aac, 0x1b57, x86_l_1b57);
x86_l_1ab1:
	/* 0x1ab1: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1ab9:
	/* 0x1ab9: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1abf:
	/* 0x1abf: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1abf, 0x1ccb, x86_l_1ccb);
x86_l_1ac5:
	/* 0x1ac5: mov    BYTE PTR [r14+rax*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519555ULL);
x86_l_1ace:
	/* 0x1ace: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1ad6:
	/* 0x1ad6: mov    WORD PTR [r14+0x7d92],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32146ULL);
x86_l_1ade:
	/* 0x1ade: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1ae4:
	/* 0x1ae4: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ae4, 0x1ccb, x86_l_1ccb);
x86_l_1aea:
	/* 0x1aea: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1aef:
	/* 0x1aef: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1af3:
	/* 0x1af3: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1afa:
	/* 0x1afa: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1afd:
	/* 0x1afd: jns    1b82 <sys_exit_submit+0x1b82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1afd, 0x1b82, x86_l_1b82);
x86_l_1b03:
	/* 0x1b03: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b06:
	/* 0x1b06: jns    1c7e <sys_exit_submit+0x1c7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b06, 0x1c7e, x86_l_1c7e);
x86_l_1b0c:
	/* 0x1b0c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b0e:
	/* 0x1b0e: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1b15:
	/* 0x1b15: je     1c85 <sys_exit_submit+0x1c85> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b15, 0x1c85, x86_l_1c85);
x86_l_1b1b:
	/* 0x1b1b: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b1f:
	/* 0x1b1f: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1b23:
	/* 0x1b23: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1b26:
	/* 0x1b26: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b29:
	/* 0x1b29: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1b2b:
	/* 0x1b2b: jne    1b0e <sys_exit_submit+0x1b0e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b2b, 0x1b0e, x86_l_1b0e);
x86_l_1b2d:
	/* 0x1b2d: jmp    1b8f <sys_exit_submit+0x1b8f> */
	X86_SIM_X86_JMP(0x1b2d, 0x1b8f, x86_l_1b8f);
x86_l_1b2f:
	/* 0x1b2f: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1b36:
	/* 0x1b36: lea    rbx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b3b:
	/* 0x1b3b: jmp    1a5f <sys_exit_submit+0x1a5f> */
	X86_SIM_X86_JMP(0x1b3b, 0x1a5f, x86_l_1a5f);
x86_l_1b40:
	/* 0x1b40: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b45:
	/* 0x1b45: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b4a:
	/* 0x1b4a: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b4d:
	/* 0x1b4d: call   1b52 <sys_exit_submit+0x1b52> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1b52:
	/* 0x1b52: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_1b57:
	/* 0x1b57: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_1b5b:
	/* 0x1b5b: je     1b9f <sys_exit_submit+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5b, 0x1b9f, x86_l_1b9f);
x86_l_1b5d:
	/* 0x1b5d: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1b60:
	/* 0x1b60: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b63:
	/* 0x1b63: je     1ba5 <sys_exit_submit+0x1ba5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b63, 0x1ba5, x86_l_1ba5);
x86_l_1b65:
	/* 0x1b65: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1b68:
	/* 0x1b68: jne    1a5f <sys_exit_submit+0x1a5f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b68, 0x1a5f, x86_l_1a5f);
x86_l_1b6e:
	/* 0x1b6e: mov    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_1b74:
	/* 0x1b74: jmp    1ba5 <sys_exit_submit+0x1ba5> */
	X86_SIM_X86_JMP(0x1b74, 0x1ba5, x86_l_1ba5);
x86_l_1b76:
	/* 0x1b76: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1b7d:
	/* 0x1b7d: jmp    1a5f <sys_exit_submit+0x1a5f> */
	X86_SIM_X86_JMP(0x1b7d, 0x1a5f, x86_l_1a5f);
x86_l_1b82:
	/* 0x1b82: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1b87:
	/* 0x1b87: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b8a:
	/* 0x1b8a: call   1b8f <sys_exit_submit+0x1b8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1b8f:
	/* 0x1b8f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b92:
	/* 0x1b92: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b94:
	/* 0x1b94: jg     1c97 <sys_exit_submit+0x1c97> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1b94, 0x1c97, x86_l_1c97);
x86_l_1b9a:
	/* 0x1b9a: jmp    1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JMP(0x1b9a, 0x1ccb, x86_l_1ccb);
x86_l_1b9f:
	/* 0x1b9f: mov    r15d,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_1ba5:
	/* 0x1ba5: mov    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1ba8:
	/* 0x1ba8: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1bb0:
	/* 0x1bb0: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_1bb6:
	/* 0x1bb6: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1bb6, 0x1ccb, x86_l_1ccb);
x86_l_1bbc:
	/* 0x1bbc: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1bc0:
	/* 0x1bc0: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1bc2:
	/* 0x1bc2: mov    BYTE PTR [r14+rcx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519555ULL);
x86_l_1bcb:
	/* 0x1bcb: lea    r15d,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1bcf:
	/* 0x1bcf: cmp    r15d,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1bd6:
	/* 0x1bd6: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1bd6, 0x1ccb, x86_l_1ccb);
x86_l_1bdc:
	/* 0x1bdc: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1be1:
	/* 0x1be1: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1be5:
	/* 0x1be5: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_1bec:
	/* 0x1bec: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bef:
	/* 0x1bef: jns    1c2c <sys_exit_submit+0x1c2c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bef, 0x1c2c, x86_l_1c2c);
x86_l_1bf1:
	/* 0x1bf1: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bf4:
	/* 0x1bf4: jns    1c44 <sys_exit_submit+0x1c44> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bf4, 0x1c44, x86_l_1c44);
x86_l_1bf6:
	/* 0x1bf6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bf8:
	/* 0x1bf8: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1bfb:
	/* 0x1bfb: jb     1c15 <sys_exit_submit+0x1c15> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1bfb, 0x1c15, x86_l_1c15);
x86_l_1bfd:
	/* 0x1bfd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bff:
	/* 0x1bff: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1c01:
	/* 0x1c01: mov    rdx,QWORD PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c05:
	/* 0x1c05: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c09:
	/* 0x1c09: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0c:
	/* 0x1c0c: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1c0f:
	/* 0x1c0f: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1c11:
	/* 0x1c11: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c13:
	/* 0x1c13: jbe    1bff <sys_exit_submit+0x1bff> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1c13, 0x1bff, x86_l_1bff);
x86_l_1c15:
	/* 0x1c15: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1c19:
	/* 0x1c19: jne    1c4f <sys_exit_submit+0x1c4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c19, 0x1c4f, x86_l_1c4f);
x86_l_1c1b:
	/* 0x1c1b: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c1f:
	/* 0x1c1f: jne    1c60 <sys_exit_submit+0x1c60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c1f, 0x1c60, x86_l_1c60);
x86_l_1c21:
	/* 0x1c21: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1c25:
	/* 0x1c25: jne    1c73 <sys_exit_submit+0x1c73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c25, 0x1c73, x86_l_1c73);
x86_l_1c27:
	/* 0x1c27: jmp    1cbc <sys_exit_submit+0x1cbc> */
	X86_SIM_X86_JMP(0x1c27, 0x1cbc, x86_l_1cbc);
x86_l_1c2c:
	/* 0x1c2c: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1c2e:
	/* 0x1c2e: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c31:
	/* 0x1c31: call   1c36 <sys_exit_submit+0x1c36> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1c36:
	/* 0x1c36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c39:
	/* 0x1c39: jns    1cbc <sys_exit_submit+0x1cbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c39, 0x1cbc, x86_l_1cbc);
x86_l_1c3f:
	/* 0x1c3f: jmp    1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JMP(0x1c3f, 0x1ccb, x86_l_1ccb);
x86_l_1c44:
	/* 0x1c44: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1c46:
	/* 0x1c46: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c48:
	/* 0x1c48: call   1c4d <sys_exit_submit+0x1c4d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1c4d:
	/* 0x1c4d: jmp    1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JMP(0x1c4d, 0x1ccb, x86_l_1ccb);
x86_l_1c4f:
	/* 0x1c4f: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c51:
	/* 0x1c51: mov    edx,DWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1c54:
	/* 0x1c54: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1c57:
	/* 0x1c57: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1c5a:
	/* 0x1c5a: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c5e:
	/* 0x1c5e: je     1c21 <sys_exit_submit+0x1c21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c5e, 0x1c21, x86_l_1c21);
x86_l_1c60:
	/* 0x1c60: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c62:
	/* 0x1c62: movzx  edx,WORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_1c66:
	/* 0x1c66: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1c6a:
	/* 0x1c6a: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1c6d:
	/* 0x1c6d: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1c71:
	/* 0x1c71: je     1cbc <sys_exit_submit+0x1cbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c71, 0x1cbc, x86_l_1cbc);
x86_l_1c73:
	/* 0x1c73: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c75:
	/* 0x1c75: movzx  ecx,BYTE PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1c79:
	/* 0x1c79: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c7c:
	/* 0x1c7c: jmp    1cbc <sys_exit_submit+0x1cbc> */
	X86_SIM_X86_JMP(0x1c7c, 0x1cbc, x86_l_1cbc);
x86_l_1c7e:
	/* 0x1c7e: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1c83:
	/* 0x1c83: jmp    1c46 <sys_exit_submit+0x1c46> */
	X86_SIM_X86_JMP(0x1c83, 0x1c46, x86_l_1c46);
x86_l_1c85:
	/* 0x1c85: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_1c8c:
	/* 0x1c8c: mov    r15d,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1c92:
	/* 0x1c92: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1c97:
	/* 0x1c97: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1c9f:
	/* 0x1c9f: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1ca6:
	/* 0x1ca6: ja     1ccb <sys_exit_submit+0x1ccb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ca6, 0x1ccb, x86_l_1ccb);
x86_l_1ca8:
	/* 0x1ca8: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_1cb0:
	/* 0x1cb0: add    r15w,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_1cb8:
	/* 0x1cb8: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1cbc:
	/* 0x1cbc: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1cc4:
	/* 0x1cc4: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1ccb:
	/* 0x1ccb: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1cd2:
	/* 0x1cd2: shr    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1cd6:
	/* 0x1cd6: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1cd9:
	/* 0x1cd9: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1cdc:
	/* 0x1cdc: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1cdc, 0x1f92, x86_l_1f92);
x86_l_1ce2:
	/* 0x1ce2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1ce4:
	/* 0x1ce4: je     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce4, 0x1f92, x86_l_1f92);
x86_l_1cea:
	/* 0x1cea: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1ced:
	/* 0x1ced: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1cef:
	/* 0x1cef: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1cf6:
	/* 0x1cf6: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1cfb:
	/* 0x1cfb: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_1d00:
	/* 0x1d00: mov    r8,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d05:
	/* 0x1d05: lea    rbx,[r8+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1d0c:
	/* 0x1d0c: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_1d12:
	/* 0x1d12: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d16:
	/* 0x1d16: jae    1d1b <sys_exit_submit+0x1d1b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1d16, 0x1d1b, x86_l_1d1b);
x86_l_1d18:
	/* 0x1d18: mov    rbx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d1b:
	/* 0x1d1b: mov    ebp,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1d1e:
	/* 0x1d1e: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_1d24:
	/* 0x1d24: je     1d37 <sys_exit_submit+0x1d37> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d24, 0x1d37, x86_l_1d37);
x86_l_1d26:
	/* 0x1d26: lea    eax,[rbp-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_1d29:
	/* 0x1d29: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_1d2c:
	/* 0x1d2c: jae    1e6f <sys_exit_submit+0x1e6f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1d2c, 0x1e6f, x86_l_1e6f);
x86_l_1d32:
	/* 0x1d32: jmp    1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JMP(0x1d32, 0x1f92, x86_l_1f92);
x86_l_1d37:
	/* 0x1d37: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1d3a:
	/* 0x1d3a: je     1d78 <sys_exit_submit+0x1d78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d3a, 0x1d78, x86_l_1d78);
x86_l_1d3c:
	/* 0x1d3c: mov    r15d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1d42:
	/* 0x1d42: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1d45:
	/* 0x1d45: je     1e6c <sys_exit_submit+0x1e6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d45, 0x1e6c, x86_l_1e6c);
x86_l_1d4b:
	/* 0x1d4b: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1d4e:
	/* 0x1d4e: jne    1d26 <sys_exit_submit+0x1d26> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d4e, 0x1d26, x86_l_1d26);
x86_l_1d50:
	/* 0x1d50: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d53:
	/* 0x1d53: je     1df6 <sys_exit_submit+0x1df6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d53, 0x1df6, x86_l_1df6);
x86_l_1d59:
	/* 0x1d59: jns    1e07 <sys_exit_submit+0x1e07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d59, 0x1e07, x86_l_1e07);
x86_l_1d5f:
	/* 0x1d5f: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d62:
	/* 0x1d62: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d65:
	/* 0x1d65: jns    1e3d <sys_exit_submit+0x1e3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d65, 0x1e3d, x86_l_1e3d);
x86_l_1d6b:
	/* 0x1d6b: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1d6e:
	/* 0x1d6e: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d73:
	/* 0x1d73: jmp    1e1e <sys_exit_submit+0x1e1e> */
	X86_SIM_X86_JMP(0x1d73, 0x1e1e, x86_l_1e1e);
x86_l_1d78:
	/* 0x1d78: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1d80:
	/* 0x1d80: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1d86:
	/* 0x1d86: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d86, 0x1f92, x86_l_1f92);
x86_l_1d8c:
	/* 0x1d8c: mov    BYTE PTR [r14+rax*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519556ULL);
x86_l_1d95:
	/* 0x1d95: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1d9d:
	/* 0x1d9d: mov    WORD PTR [r14+0x7d94],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32148ULL);
x86_l_1da5:
	/* 0x1da5: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1dab:
	/* 0x1dab: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1dab, 0x1f92, x86_l_1f92);
x86_l_1db1:
	/* 0x1db1: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1db6:
	/* 0x1db6: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1dba:
	/* 0x1dba: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1dc1:
	/* 0x1dc1: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1dc4:
	/* 0x1dc4: jns    1e49 <sys_exit_submit+0x1e49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dc4, 0x1e49, x86_l_1e49);
x86_l_1dca:
	/* 0x1dca: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1dcd:
	/* 0x1dcd: jns    1f45 <sys_exit_submit+0x1f45> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dcd, 0x1f45, x86_l_1f45);
x86_l_1dd3:
	/* 0x1dd3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dd5:
	/* 0x1dd5: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1ddc:
	/* 0x1ddc: je     1f4c <sys_exit_submit+0x1f4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ddc, 0x1f4c, x86_l_1f4c);
x86_l_1de2:
	/* 0x1de2: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1de6:
	/* 0x1de6: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1dea:
	/* 0x1dea: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1ded:
	/* 0x1ded: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1df0:
	/* 0x1df0: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1df2:
	/* 0x1df2: jne    1dd5 <sys_exit_submit+0x1dd5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1df2, 0x1dd5, x86_l_1dd5);
x86_l_1df4:
	/* 0x1df4: jmp    1e56 <sys_exit_submit+0x1e56> */
	X86_SIM_X86_JMP(0x1df4, 0x1e56, x86_l_1e56);
x86_l_1df6:
	/* 0x1df6: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1dfd:
	/* 0x1dfd: lea    rbx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e02:
	/* 0x1e02: jmp    1d26 <sys_exit_submit+0x1d26> */
	X86_SIM_X86_JMP(0x1e02, 0x1d26, x86_l_1d26);
x86_l_1e07:
	/* 0x1e07: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e0c:
	/* 0x1e0c: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e11:
	/* 0x1e11: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e14:
	/* 0x1e14: call   1e19 <sys_exit_submit+0x1e19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1e19:
	/* 0x1e19: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_1e1e:
	/* 0x1e1e: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_1e22:
	/* 0x1e22: je     1e66 <sys_exit_submit+0x1e66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e22, 0x1e66, x86_l_1e66);
x86_l_1e24:
	/* 0x1e24: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1e27:
	/* 0x1e27: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e2a:
	/* 0x1e2a: je     1e6c <sys_exit_submit+0x1e6c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e2a, 0x1e6c, x86_l_1e6c);
x86_l_1e2c:
	/* 0x1e2c: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1e2f:
	/* 0x1e2f: jne    1d26 <sys_exit_submit+0x1d26> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e2f, 0x1d26, x86_l_1d26);
x86_l_1e35:
	/* 0x1e35: mov    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_1e3b:
	/* 0x1e3b: jmp    1e6c <sys_exit_submit+0x1e6c> */
	X86_SIM_X86_JMP(0x1e3b, 0x1e6c, x86_l_1e6c);
x86_l_1e3d:
	/* 0x1e3d: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1e44:
	/* 0x1e44: jmp    1d26 <sys_exit_submit+0x1d26> */
	X86_SIM_X86_JMP(0x1e44, 0x1d26, x86_l_1d26);
x86_l_1e49:
	/* 0x1e49: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1e4e:
	/* 0x1e4e: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e51:
	/* 0x1e51: call   1e56 <sys_exit_submit+0x1e56> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1e56:
	/* 0x1e56: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e59:
	/* 0x1e59: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1e5b:
	/* 0x1e5b: jg     1f5e <sys_exit_submit+0x1f5e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1e5b, 0x1f5e, x86_l_1f5e);
x86_l_1e61:
	/* 0x1e61: jmp    1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JMP(0x1e61, 0x1f92, x86_l_1f92);
x86_l_1e66:
	/* 0x1e66: mov    r15d,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_1e6c:
	/* 0x1e6c: mov    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e6f:
	/* 0x1e6f: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1e77:
	/* 0x1e77: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_1e7d:
	/* 0x1e7d: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1e7d, 0x1f92, x86_l_1f92);
x86_l_1e83:
	/* 0x1e83: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e87:
	/* 0x1e87: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1e89:
	/* 0x1e89: mov    BYTE PTR [r14+rcx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519556ULL);
x86_l_1e92:
	/* 0x1e92: lea    r15d,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1e96:
	/* 0x1e96: cmp    r15d,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1e9d:
	/* 0x1e9d: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1e9d, 0x1f92, x86_l_1f92);
x86_l_1ea3:
	/* 0x1ea3: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ea8:
	/* 0x1ea8: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1eac:
	/* 0x1eac: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_1eb3:
	/* 0x1eb3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1eb6:
	/* 0x1eb6: jns    1ef3 <sys_exit_submit+0x1ef3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eb6, 0x1ef3, x86_l_1ef3);
x86_l_1eb8:
	/* 0x1eb8: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ebb:
	/* 0x1ebb: jns    1f0b <sys_exit_submit+0x1f0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ebb, 0x1f0b, x86_l_1f0b);
x86_l_1ebd:
	/* 0x1ebd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ebf:
	/* 0x1ebf: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1ec2:
	/* 0x1ec2: jb     1edc <sys_exit_submit+0x1edc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ec2, 0x1edc, x86_l_1edc);
x86_l_1ec4:
	/* 0x1ec4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec6:
	/* 0x1ec6: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1ec8:
	/* 0x1ec8: mov    rdx,QWORD PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1ecc:
	/* 0x1ecc: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1ed0:
	/* 0x1ed0: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ed3:
	/* 0x1ed3: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1ed6:
	/* 0x1ed6: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1ed8:
	/* 0x1ed8: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1eda:
	/* 0x1eda: jbe    1ec6 <sys_exit_submit+0x1ec6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1eda, 0x1ec6, x86_l_1ec6);
x86_l_1edc:
	/* 0x1edc: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1ee0:
	/* 0x1ee0: jne    1f16 <sys_exit_submit+0x1f16> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee0, 0x1f16, x86_l_1f16);
x86_l_1ee2:
	/* 0x1ee2: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1ee6:
	/* 0x1ee6: jne    1f27 <sys_exit_submit+0x1f27> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee6, 0x1f27, x86_l_1f27);
x86_l_1ee8:
	/* 0x1ee8: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1eec:
	/* 0x1eec: jne    1f3a <sys_exit_submit+0x1f3a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eec, 0x1f3a, x86_l_1f3a);
x86_l_1eee:
	/* 0x1eee: jmp    1f83 <sys_exit_submit+0x1f83> */
	X86_SIM_X86_JMP(0x1eee, 0x1f83, x86_l_1f83);
x86_l_1ef3:
	/* 0x1ef3: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1ef5:
	/* 0x1ef5: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ef8:
	/* 0x1ef8: call   1efd <sys_exit_submit+0x1efd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1efd:
	/* 0x1efd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f00:
	/* 0x1f00: jns    1f83 <sys_exit_submit+0x1f83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f00, 0x1f83, x86_l_1f83);
x86_l_1f06:
	/* 0x1f06: jmp    1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JMP(0x1f06, 0x1f92, x86_l_1f92);
x86_l_1f0b:
	/* 0x1f0b: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1f0d:
	/* 0x1f0d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f0f:
	/* 0x1f0f: call   1f14 <sys_exit_submit+0x1f14> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1f14:
	/* 0x1f14: jmp    1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JMP(0x1f14, 0x1f92, x86_l_1f92);
x86_l_1f16:
	/* 0x1f16: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f18:
	/* 0x1f18: mov    edx,DWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1f1b:
	/* 0x1f1b: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1f1e:
	/* 0x1f1e: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1f21:
	/* 0x1f21: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1f25:
	/* 0x1f25: je     1ee8 <sys_exit_submit+0x1ee8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f25, 0x1ee8, x86_l_1ee8);
x86_l_1f27:
	/* 0x1f27: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f29:
	/* 0x1f29: movzx  edx,WORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_1f2d:
	/* 0x1f2d: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1f31:
	/* 0x1f31: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1f34:
	/* 0x1f34: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1f38:
	/* 0x1f38: je     1f83 <sys_exit_submit+0x1f83> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f38, 0x1f83, x86_l_1f83);
x86_l_1f3a:
	/* 0x1f3a: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f3c:
	/* 0x1f3c: movzx  ecx,BYTE PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1f40:
	/* 0x1f40: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1f43:
	/* 0x1f43: jmp    1f83 <sys_exit_submit+0x1f83> */
	X86_SIM_X86_JMP(0x1f43, 0x1f83, x86_l_1f83);
x86_l_1f45:
	/* 0x1f45: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1f4a:
	/* 0x1f4a: jmp    1f0d <sys_exit_submit+0x1f0d> */
	X86_SIM_X86_JMP(0x1f4a, 0x1f0d, x86_l_1f0d);
x86_l_1f4c:
	/* 0x1f4c: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_1f53:
	/* 0x1f53: mov    r15d,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1f59:
	/* 0x1f59: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1f5e:
	/* 0x1f5e: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1f66:
	/* 0x1f66: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1f6d:
	/* 0x1f6d: ja     1f92 <sys_exit_submit+0x1f92> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1f6d, 0x1f92, x86_l_1f92);
x86_l_1f6f:
	/* 0x1f6f: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_1f77:
	/* 0x1f77: add    r15w,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_1f7f:
	/* 0x1f7f: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1f83:
	/* 0x1f83: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1f8b:
	/* 0x1f8b: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1f92:
	/* 0x1f92: mov    rcx,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1f99:
	/* 0x1f99: shr    rcx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 40ULL);
x86_l_1f9d:
	/* 0x1f9d: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1fa0:
	/* 0x1fa0: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1fa3:
	/* 0x1fa3: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1fa3, 0x2259, x86_l_2259);
x86_l_1fa9:
	/* 0x1fa9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1fab:
	/* 0x1fab: je     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fab, 0x2259, x86_l_2259);
x86_l_1fb1:
	/* 0x1fb1: movzx  edi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1fb4:
	/* 0x1fb4: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1fb6:
	/* 0x1fb6: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1fbd:
	/* 0x1fbd: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1fc2:
	/* 0x1fc2: shlx   rsi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_1fc7:
	/* 0x1fc7: mov    r8,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fcc:
	/* 0x1fcc: lea    rbx,[r8+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1fd3:
	/* 0x1fd3: mov    r8d,0xa880 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 43136ULL);
x86_l_1fd9:
	/* 0x1fd9: bt     r8,rdi */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fdd:
	/* 0x1fdd: jae    1fe2 <sys_exit_submit+0x1fe2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fdd, 0x1fe2, x86_l_1fe2);
x86_l_1fdf:
	/* 0x1fdf: mov    rbx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe2:
	/* 0x1fe2: mov    ebp,DWORD PTR [rdx+rcx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 0ULL);
x86_l_1fe5:
	/* 0x1fe5: test   esi,0x177e */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 6014ULL);
x86_l_1feb:
	/* 0x1feb: je     1ffe <sys_exit_submit+0x1ffe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1feb, 0x1ffe, x86_l_1ffe);
x86_l_1fed:
	/* 0x1fed: lea    eax,[rbp-0x6f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551505ULL);
x86_l_1ff0:
	/* 0x1ff0: cmp    eax,0xffffff92 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967186ULL);
x86_l_1ff3:
	/* 0x1ff3: jae    2136 <sys_exit_submit+0x2136> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ff3, 0x2136, x86_l_2136);
x86_l_1ff9:
	/* 0x1ff9: jmp    2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JMP(0x1ff9, 0x2259, x86_l_2259);
x86_l_1ffe:
	/* 0x1ffe: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2001:
	/* 0x2001: je     203f <sys_exit_submit+0x203f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2001, 0x203f, x86_l_203f);
x86_l_2003:
	/* 0x2003: mov    r15d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2009:
	/* 0x2009: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_200c:
	/* 0x200c: je     2133 <sys_exit_submit+0x2133> */
	X86_SIM_X86_JCC(X86_CC_E, 0x200c, 0x2133, x86_l_2133);
x86_l_2012:
	/* 0x2012: cmp    eax,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2015:
	/* 0x2015: jne    1fed <sys_exit_submit+0x1fed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2015, 0x1fed, x86_l_1fed);
x86_l_2017:
	/* 0x2017: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_201a:
	/* 0x201a: je     20bd <sys_exit_submit+0x20bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201a, 0x20bd, x86_l_20bd);
x86_l_2020:
	/* 0x2020: jns    20ce <sys_exit_submit+0x20ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2020, 0x20ce, x86_l_20ce);
x86_l_2026:
	/* 0x2026: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2029:
	/* 0x2029: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_202c:
	/* 0x202c: jns    2104 <sys_exit_submit+0x2104> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x202c, 0x2104, x86_l_2104);
x86_l_2032:
	/* 0x2032: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2035:
	/* 0x2035: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_203a:
	/* 0x203a: jmp    20e5 <sys_exit_submit+0x20e5> */
	X86_SIM_X86_JMP(0x203a, 0x20e5, x86_l_20e5);
x86_l_203f:
	/* 0x203f: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2047:
	/* 0x2047: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_204d:
	/* 0x204d: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x204d, 0x2259, x86_l_2259);
x86_l_2053:
	/* 0x2053: mov    BYTE PTR [r14+rax*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519557ULL);
x86_l_205c:
	/* 0x205c: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2064:
	/* 0x2064: mov    WORD PTR [r14+0x7d96],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32150ULL);
x86_l_206c:
	/* 0x206c: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2072:
	/* 0x2072: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2072, 0x2259, x86_l_2259);
x86_l_2078:
	/* 0x2078: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_207d:
	/* 0x207d: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2081:
	/* 0x2081: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2088:
	/* 0x2088: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_208b:
	/* 0x208b: jns    2110 <sys_exit_submit+0x2110> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x208b, 0x2110, x86_l_2110);
x86_l_2091:
	/* 0x2091: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2094:
	/* 0x2094: jns    220c <sys_exit_submit+0x220c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2094, 0x220c, x86_l_220c);
x86_l_209a:
	/* 0x209a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_209c:
	/* 0x209c: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_20a3:
	/* 0x20a3: je     2213 <sys_exit_submit+0x2213> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a3, 0x2213, x86_l_2213);
x86_l_20a9:
	/* 0x20a9: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20ad:
	/* 0x20ad: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_20b1:
	/* 0x20b1: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_20b4:
	/* 0x20b4: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20b7:
	/* 0x20b7: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_20b9:
	/* 0x20b9: jne    209c <sys_exit_submit+0x209c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20b9, 0x209c, x86_l_209c);
x86_l_20bb:
	/* 0x20bb: jmp    211d <sys_exit_submit+0x211d> */
	X86_SIM_X86_JMP(0x20bb, 0x211d, x86_l_211d);
x86_l_20bd:
	/* 0x20bd: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_20c4:
	/* 0x20c4: lea    rbx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20c9:
	/* 0x20c9: jmp    1fed <sys_exit_submit+0x1fed> */
	X86_SIM_X86_JMP(0x20c9, 0x1fed, x86_l_1fed);
x86_l_20ce:
	/* 0x20ce: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20d3:
	/* 0x20d3: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20d8:
	/* 0x20d8: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20db:
	/* 0x20db: call   20e0 <sys_exit_submit+0x20e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_20e0:
	/* 0x20e0: movzx  eax,WORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 48ULL);
x86_l_20e5:
	/* 0x20e5: cmp    ax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 1ULL);
x86_l_20e9:
	/* 0x20e9: je     212d <sys_exit_submit+0x212d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e9, 0x212d, x86_l_212d);
x86_l_20eb:
	/* 0x20eb: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_20ee:
	/* 0x20ee: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20f1:
	/* 0x20f1: je     2133 <sys_exit_submit+0x2133> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20f1, 0x2133, x86_l_2133);
x86_l_20f3:
	/* 0x20f3: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_20f6:
	/* 0x20f6: jne    1fed <sys_exit_submit+0x1fed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20f6, 0x1fed, x86_l_1fed);
x86_l_20fc:
	/* 0x20fc: mov    r15d,0x1c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_2102:
	/* 0x2102: jmp    2133 <sys_exit_submit+0x2133> */
	X86_SIM_X86_JMP(0x2102, 0x2133, x86_l_2133);
x86_l_2104:
	/* 0x2104: mov    WORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_210b:
	/* 0x210b: jmp    1fed <sys_exit_submit+0x1fed> */
	X86_SIM_X86_JMP(0x210b, 0x1fed, x86_l_1fed);
x86_l_2110:
	/* 0x2110: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2115:
	/* 0x2115: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2118:
	/* 0x2118: call   211d <sys_exit_submit+0x211d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_211d:
	/* 0x211d: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2120:
	/* 0x2120: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2122:
	/* 0x2122: jg     2225 <sys_exit_submit+0x2225> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2122, 0x2225, x86_l_2225);
x86_l_2128:
	/* 0x2128: jmp    2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JMP(0x2128, 0x2259, x86_l_2259);
x86_l_212d:
	/* 0x212d: mov    r15d,0x6e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 110ULL);
x86_l_2133:
	/* 0x2133: mov    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2136:
	/* 0x2136: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_213e:
	/* 0x213e: cmp    ecx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_2144:
	/* 0x2144: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2144, 0x2259, x86_l_2259);
x86_l_214a:
	/* 0x214a: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_214e:
	/* 0x214e: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2150:
	/* 0x2150: mov    BYTE PTR [r14+rcx*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 588410519557ULL);
x86_l_2159:
	/* 0x2159: lea    r15d,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_215d:
	/* 0x215d: cmp    r15d,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2164:
	/* 0x2164: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2164, 0x2259, x86_l_2259);
x86_l_216a:
	/* 0x216a: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_216f:
	/* 0x216f: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2173:
	/* 0x2173: add    rdi,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 137ULL);
x86_l_217a:
	/* 0x217a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_217d:
	/* 0x217d: jns    21ba <sys_exit_submit+0x21ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x217d, 0x21ba, x86_l_21ba);
x86_l_217f:
	/* 0x217f: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2182:
	/* 0x2182: jns    21d2 <sys_exit_submit+0x21d2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2182, 0x21d2, x86_l_21d2);
x86_l_2184:
	/* 0x2184: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2186:
	/* 0x2186: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2189:
	/* 0x2189: jb     21a3 <sys_exit_submit+0x21a3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2189, 0x21a3, x86_l_21a3);
x86_l_218b:
	/* 0x218b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_218d:
	/* 0x218d: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_218f:
	/* 0x218f: mov    rdx,QWORD PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2193:
	/* 0x2193: mov    QWORD PTR [rdi+rax*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2197:
	/* 0x2197: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_219a:
	/* 0x219a: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_219d:
	/* 0x219d: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_219f:
	/* 0x219f: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_21a1:
	/* 0x21a1: jbe    218d <sys_exit_submit+0x218d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x21a1, 0x218d, x86_l_218d);
x86_l_21a3:
	/* 0x21a3: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_21a7:
	/* 0x21a7: jne    21dd <sys_exit_submit+0x21dd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21a7, 0x21dd, x86_l_21dd);
x86_l_21a9:
	/* 0x21a9: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_21ad:
	/* 0x21ad: jne    21ee <sys_exit_submit+0x21ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21ad, 0x21ee, x86_l_21ee);
x86_l_21af:
	/* 0x21af: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_21b3:
	/* 0x21b3: jne    2201 <sys_exit_submit+0x2201> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21b3, 0x2201, x86_l_2201);
x86_l_21b5:
	/* 0x21b5: jmp    224a <sys_exit_submit+0x224a> */
	X86_SIM_X86_JMP(0x21b5, 0x224a, x86_l_224a);
x86_l_21ba:
	/* 0x21ba: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_21bc:
	/* 0x21bc: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21bf:
	/* 0x21bf: call   21c4 <sys_exit_submit+0x21c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_21c4:
	/* 0x21c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21c7:
	/* 0x21c7: jns    224a <sys_exit_submit+0x224a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21c7, 0x224a, x86_l_224a);
x86_l_21cd:
	/* 0x21cd: jmp    2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JMP(0x21cd, 0x2259, x86_l_2259);
x86_l_21d2:
	/* 0x21d2: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_21d4:
	/* 0x21d4: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d6:
	/* 0x21d6: call   21db <sys_exit_submit+0x21db> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_21db:
	/* 0x21db: jmp    2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JMP(0x21db, 0x2259, x86_l_2259);
x86_l_21dd:
	/* 0x21dd: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_21df:
	/* 0x21df: mov    edx,DWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_21e2:
	/* 0x21e2: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_21e5:
	/* 0x21e5: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_21e8:
	/* 0x21e8: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_21ec:
	/* 0x21ec: je     21af <sys_exit_submit+0x21af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ec, 0x21af, x86_l_21af);
x86_l_21ee:
	/* 0x21ee: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_21f0:
	/* 0x21f0: movzx  edx,WORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_21f4:
	/* 0x21f4: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_21f8:
	/* 0x21f8: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_21fb:
	/* 0x21fb: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_21ff:
	/* 0x21ff: je     224a <sys_exit_submit+0x224a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ff, 0x224a, x86_l_224a);
x86_l_2201:
	/* 0x2201: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2203:
	/* 0x2203: movzx  ecx,BYTE PTR [rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_2207:
	/* 0x2207: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_220a:
	/* 0x220a: jmp    224a <sys_exit_submit+0x224a> */
	X86_SIM_X86_JMP(0x220a, 0x224a, x86_l_224a);
x86_l_220c:
	/* 0x220c: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2211:
	/* 0x2211: jmp    21d4 <sys_exit_submit+0x21d4> */
	X86_SIM_X86_JMP(0x2211, 0x21d4, x86_l_21d4);
x86_l_2213:
	/* 0x2213: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_221a:
	/* 0x221a: mov    r15d,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2220:
	/* 0x2220: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2225:
	/* 0x2225: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_222d:
	/* 0x222d: cmp    rcx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2234:
	/* 0x2234: ja     2259 <sys_exit_submit+0x2259> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2234, 0x2259, x86_l_2259);
x86_l_2236:
	/* 0x2236: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_223e:
	/* 0x223e: add    r15w,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2246:
	/* 0x2246: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_224a:
	/* 0x224a: mov    WORD PTR [r14+0x7d8a],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2252:
	/* 0x2252: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2259:
	/* 0x2259: mov    rax,QWORD PTR [r14+0x7de0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_2260:
	/* 0x2260: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2265:
	/* 0x2265: mov    rcx,QWORD PTR [rcx+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_226c:
	/* 0x226c: mov    QWORD PTR [r14],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_226f:
	/* 0x226f: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2277:
	/* 0x2277: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_227e:
	/* 0x227e: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2283:
	/* 0x2283: ja     2344 <sys_exit_submit+0x2344> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2283, 0x2344, x86_l_2344);
x86_l_2289:
	/* 0x2289: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_228b:
	/* 0x228b: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_228e:
	/* 0x228e: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2290:
	/* 0x2290: and    edx,0xff00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 65280ULL);
x86_l_2296:
	/* 0x2296: cmp    rdx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_229a:
	/* 0x229a: sbb    cl,0xff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SBB, 255ULL);
x86_l_229d:
	/* 0x229d: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_229f:
	/* 0x229f: and    edx,0xff0000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16711680ULL);
x86_l_22a5:
	/* 0x22a5: cmp    rdx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_22a9:
	/* 0x22a9: sbb    cl,0xff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SBB, 255ULL);
x86_l_22ac:
	/* 0x22ac: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_22ae:
	/* 0x22ae: and    edx,0xff000000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4278190080ULL);
x86_l_22b4:
	/* 0x22b4: cmp    rdx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_22b8:
	/* 0x22b8: sbb    cl,0xff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SBB, 255ULL);
x86_l_22bb:
	/* 0x22bb: movabs rdx,0xff00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1095216660480ULL);
x86_l_22c5:
	/* 0x22c5: and    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_22c8:
	/* 0x22c8: cmp    rdx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_22cc:
	/* 0x22cc: sbb    cl,0xff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SBB, 255ULL);
x86_l_22cf:
	/* 0x22cf: movabs rdx,0xff0000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 280375465082880ULL);
x86_l_22d9:
	/* 0x22d9: and    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_22dc:
	/* 0x22dc: cmp    rdx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_22e0:
	/* 0x22e0: sbb    cl,0xff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SBB, 255ULL);
x86_l_22e3:
	/* 0x22e3: mov    BYTE PTR [r14+rbx*1+0x89],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 137ULL);
x86_l_22eb:
	/* 0x22eb: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_22f1:
	/* 0x22f1: ja     2344 <sys_exit_submit+0x2344> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22f1, 0x2344, x86_l_2344);
x86_l_22f3:
	/* 0x22f3: lea    rdi,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_22f7:
	/* 0x22f7: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_22fe:
	/* 0x22fe: lea    rax,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2303:
	/* 0x2303: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2306:
	/* 0x2306: jns    2315 <sys_exit_submit+0x2315> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2306, 0x2315, x86_l_2315);
x86_l_2308:
	/* 0x2308: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_230b:
	/* 0x230b: jns    233d <sys_exit_submit+0x233d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x230b, 0x233d, x86_l_233d);
x86_l_230d:
	/* 0x230d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2310:
	/* 0x2310: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2313:
	/* 0x2313: jmp    2329 <sys_exit_submit+0x2329> */
	X86_SIM_X86_JMP(0x2313, 0x2329, x86_l_2329);
x86_l_2315:
	/* 0x2315: lea    rdx,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_231a:
	/* 0x231a: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_231f:
	/* 0x231f: call   2324 <sys_exit_submit+0x2324> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2324:
	/* 0x2324: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2327:
	/* 0x2327: js     2344 <sys_exit_submit+0x2344> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2327, 0x2344, x86_l_2344);
x86_l_2329:
	/* 0x2329: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_232c:
	/* 0x232c: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2334:
	/* 0x2334: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_233b:
	/* 0x233b: jmp    2344 <sys_exit_submit+0x2344> */
	X86_SIM_X86_JMP(0x233b, 0x2344, x86_l_2344);
x86_l_233d:
	/* 0x233d: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2344:
	/* 0x2344: mov    r13,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_234b:
	/* 0x234b: lea    rcx,[r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_234f:
	/* 0x234f: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2352:
	/* 0x2352: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2355:
	/* 0x2355: jns    2367 <sys_exit_submit+0x2367> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2355, 0x2367, x86_l_2367);
x86_l_2357:
	/* 0x2357: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_235a:
	/* 0x235a: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_235e:
	/* 0x235e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2361:
	/* 0x2361: js     2373 <sys_exit_submit+0x2373> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2361, 0x2373, x86_l_2373);
x86_l_2363:
	/* 0x2363: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2365:
	/* 0x2365: jmp    2376 <sys_exit_submit+0x2376> */
	X86_SIM_X86_JMP(0x2365, 0x2376, x86_l_2376);
x86_l_2367:
	/* 0x2367: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_236a:
	/* 0x236a: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_236e:
	/* 0x236e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2371:
	/* 0x2371: jns    2363 <sys_exit_submit+0x2363> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2371, 0x2363, x86_l_2363);
x86_l_2373:
	/* 0x2373: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2376:
	/* 0x2376: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_237a:
	/* 0x237a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_237c:
	/* 0x237c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_237f:
	/* 0x237f: jns    2390 <sys_exit_submit+0x2390> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x237f, 0x2390, x86_l_2390);
x86_l_2381:
	/* 0x2381: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2384:
	/* 0x2384: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2389:
	/* 0x2389: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_238c:
	/* 0x238c: js     239d <sys_exit_submit+0x239d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x238c, 0x239d, x86_l_239d);
x86_l_238e:
	/* 0x238e: jmp    239f <sys_exit_submit+0x239f> */
	X86_SIM_X86_JMP(0x238e, 0x239f, x86_l_239f);
x86_l_2390:
	/* 0x2390: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2393:
	/* 0x2393: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2398:
	/* 0x2398: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_239b:
	/* 0x239b: jns    239f <sys_exit_submit+0x239f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x239b, 0x239f, x86_l_239f);
x86_l_239d:
	/* 0x239d: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_239f:
	/* 0x239f: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_23a3:
	/* 0x23a3: lea    rax,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23a7:
	/* 0x23a7: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23aa:
	/* 0x23aa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23ac:
	/* 0x23ac: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23af:
	/* 0x23af: jns    23be <sys_exit_submit+0x23be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23af, 0x23be, x86_l_23be);
x86_l_23b1:
	/* 0x23b1: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23b4:
	/* 0x23b4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23b7:
	/* 0x23b7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23ba:
	/* 0x23ba: js     23c8 <sys_exit_submit+0x23c8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23ba, 0x23c8, x86_l_23c8);
x86_l_23bc:
	/* 0x23bc: jmp    23ca <sys_exit_submit+0x23ca> */
	X86_SIM_X86_JMP(0x23bc, 0x23ca, x86_l_23ca);
x86_l_23be:
	/* 0x23be: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c0:
	/* 0x23c0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23c3:
	/* 0x23c3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23c6:
	/* 0x23c6: jns    23ca <sys_exit_submit+0x23ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c6, 0x23ca, x86_l_23ca);
x86_l_23c8:
	/* 0x23c8: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ca:
	/* 0x23ca: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_23cc:
	/* 0x23cc: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_23d0:
	/* 0x23d0: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_23d3:
	/* 0x23d3: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_23d7:
	/* 0x23d7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d9:
	/* 0x23d9: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23dc:
	/* 0x23dc: jns    23e0 <sys_exit_submit+0x23e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23dc, 0x23e0, x86_l_23e0);
x86_l_23de:
	/* 0x23de: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e0:
	/* 0x23e0: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23e4:
	/* 0x23e4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23e7:
	/* 0x23e7: jns    23ee <sys_exit_submit+0x23ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23e7, 0x23ee, x86_l_23ee);
x86_l_23e9:
	/* 0x23e9: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ec:
	/* 0x23ec: jmp    23f0 <sys_exit_submit+0x23f0> */
	X86_SIM_X86_JMP(0x23ec, 0x23f0, x86_l_23f0);
x86_l_23ee:
	/* 0x23ee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23f0:
	/* 0x23f0: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_23f4:
	/* 0x23f4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23f6:
	/* 0x23f6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23f9:
	/* 0x23f9: jns    2408 <sys_exit_submit+0x2408> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f9, 0x2408, x86_l_2408);
x86_l_23fb:
	/* 0x23fb: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fe:
	/* 0x23fe: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2401:
	/* 0x2401: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2404:
	/* 0x2404: js     2412 <sys_exit_submit+0x2412> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2404, 0x2412, x86_l_2412);
x86_l_2406:
	/* 0x2406: jmp    2414 <sys_exit_submit+0x2414> */
	X86_SIM_X86_JMP(0x2406, 0x2414, x86_l_2414);
x86_l_2408:
	/* 0x2408: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_240a:
	/* 0x240a: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_240d:
	/* 0x240d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2410:
	/* 0x2410: jns    2414 <sys_exit_submit+0x2414> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2410, 0x2414, x86_l_2414);
x86_l_2412:
	/* 0x2412: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2414:
	/* 0x2414: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2416:
	/* 0x2416: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_241a:
	/* 0x241a: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_241d:
	/* 0x241d: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2421:
	/* 0x2421: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2423:
	/* 0x2423: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2426:
	/* 0x2426: jns    242a <sys_exit_submit+0x242a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2426, 0x242a, x86_l_242a);
x86_l_2428:
	/* 0x2428: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_242a:
	/* 0x242a: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_242e:
	/* 0x242e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2430:
	/* 0x2430: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2433:
	/* 0x2433: jns    2442 <sys_exit_submit+0x2442> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2433, 0x2442, x86_l_2442);
x86_l_2435:
	/* 0x2435: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2438:
	/* 0x2438: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_243b:
	/* 0x243b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_243e:
	/* 0x243e: js     244c <sys_exit_submit+0x244c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x243e, 0x244c, x86_l_244c);
x86_l_2440:
	/* 0x2440: jmp    244e <sys_exit_submit+0x244e> */
	X86_SIM_X86_JMP(0x2440, 0x244e, x86_l_244e);
x86_l_2442:
	/* 0x2442: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2444:
	/* 0x2444: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2447:
	/* 0x2447: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_244a:
	/* 0x244a: jns    244e <sys_exit_submit+0x244e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x244a, 0x244e, x86_l_244e);
x86_l_244c:
	/* 0x244c: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244e:
	/* 0x244e: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2450:
	/* 0x2450: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2454:
	/* 0x2454: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2457:
	/* 0x2457: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_245b:
	/* 0x245b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_245d:
	/* 0x245d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2460:
	/* 0x2460: jns    2470 <sys_exit_submit+0x2470> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2460, 0x2470, x86_l_2470);
x86_l_2462:
	/* 0x2462: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2465:
	/* 0x2465: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2469:
	/* 0x2469: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_246c:
	/* 0x246c: js     247b <sys_exit_submit+0x247b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x246c, 0x247b, x86_l_247b);
x86_l_246e:
	/* 0x246e: jmp    247d <sys_exit_submit+0x247d> */
	X86_SIM_X86_JMP(0x246e, 0x247d, x86_l_247d);
x86_l_2470:
	/* 0x2470: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2472:
	/* 0x2472: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2476:
	/* 0x2476: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2479:
	/* 0x2479: jns    247d <sys_exit_submit+0x247d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2479, 0x247d, x86_l_247d);
x86_l_247b:
	/* 0x247b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_247d:
	/* 0x247d: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2482:
	/* 0x2482: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2485:
	/* 0x2485: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2487:
	/* 0x2487: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_248a:
	/* 0x248a: jns    2499 <sys_exit_submit+0x2499> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x248a, 0x2499, x86_l_2499);
x86_l_248c:
	/* 0x248c: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248f:
	/* 0x248f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2492:
	/* 0x2492: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2495:
	/* 0x2495: js     24a3 <sys_exit_submit+0x24a3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2495, 0x24a3, x86_l_24a3);
x86_l_2497:
	/* 0x2497: jmp    24a5 <sys_exit_submit+0x24a5> */
	X86_SIM_X86_JMP(0x2497, 0x24a5, x86_l_24a5);
x86_l_2499:
	/* 0x2499: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_249b:
	/* 0x249b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_249e:
	/* 0x249e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24a1:
	/* 0x24a1: jns    24a5 <sys_exit_submit+0x24a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24a1, 0x24a5, x86_l_24a5);
x86_l_24a3:
	/* 0x24a3: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24a5:
	/* 0x24a5: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_24a7:
	/* 0x24a7: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_24ab:
	/* 0x24ab: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_24ae:
	/* 0x24ae: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_24b2:
	/* 0x24b2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24b4:
	/* 0x24b4: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24b7:
	/* 0x24b7: jns    24c7 <sys_exit_submit+0x24c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24b7, 0x24c7, x86_l_24c7);
x86_l_24b9:
	/* 0x24b9: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24bc:
	/* 0x24bc: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_24c0:
	/* 0x24c0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24c3:
	/* 0x24c3: js     24d2 <sys_exit_submit+0x24d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24c3, 0x24d2, x86_l_24d2);
x86_l_24c5:
	/* 0x24c5: jmp    24d4 <sys_exit_submit+0x24d4> */
	X86_SIM_X86_JMP(0x24c5, 0x24d4, x86_l_24d4);
x86_l_24c7:
	/* 0x24c7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24c9:
	/* 0x24c9: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_24cd:
	/* 0x24cd: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24d0:
	/* 0x24d0: jns    24d4 <sys_exit_submit+0x24d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24d0, 0x24d4, x86_l_24d4);
x86_l_24d2:
	/* 0x24d2: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d4:
	/* 0x24d4: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_24d6:
	/* 0x24d6: jne    250a <sys_exit_submit+0x250a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24d6, 0x250a, x86_l_250a);
x86_l_24d8:
	/* 0x24d8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24da:
	/* 0x24da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24dd:
	/* 0x24dd: jns    24e4 <sys_exit_submit+0x24e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24dd, 0x24e4, x86_l_24e4);
x86_l_24df:
	/* 0x24df: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e2:
	/* 0x24e2: jmp    24e6 <sys_exit_submit+0x24e6> */
	X86_SIM_X86_JMP(0x24e2, 0x24e6, x86_l_24e6);
x86_l_24e4:
	/* 0x24e4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e6:
	/* 0x24e6: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24e9:
	/* 0x24e9: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24ec:
	/* 0x24ec: jns    24f0 <sys_exit_submit+0x24f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ec, 0x24f0, x86_l_24f0);
x86_l_24ee:
	/* 0x24ee: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24f0:
	/* 0x24f0: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_24f2:
	/* 0x24f2: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_24f6:
	/* 0x24f6: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_24f9:
	/* 0x24f9: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_24fd:
	/* 0x24fd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ff:
	/* 0x24ff: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2502:
	/* 0x2502: jns    2506 <sys_exit_submit+0x2506> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2502, 0x2506, x86_l_2506);
x86_l_2504:
	/* 0x2504: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2506:
	/* 0x2506: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_250a:
	/* 0x250a: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_250e:
	/* 0x250e: lea    rbx,[r13+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2515:
	/* 0x2515: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2518:
	/* 0x2518: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_251b:
	/* 0x251b: jns    2522 <sys_exit_submit+0x2522> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x251b, 0x2522, x86_l_2522);
x86_l_251d:
	/* 0x251d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2520:
	/* 0x2520: jmp    2524 <sys_exit_submit+0x2524> */
	X86_SIM_X86_JMP(0x2520, 0x2524, x86_l_2524);
x86_l_2522:
	/* 0x2522: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2524:
	/* 0x2524: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2528:
	/* 0x2528: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_252a:
	/* 0x252a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_252d:
	/* 0x252d: jns    2539 <sys_exit_submit+0x2539> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x252d, 0x2539, x86_l_2539);
x86_l_252f:
	/* 0x252f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2532:
	/* 0x2532: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2535:
	/* 0x2535: js     2540 <sys_exit_submit+0x2540> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2535, 0x2540, x86_l_2540);
x86_l_2537:
	/* 0x2537: jmp    2542 <sys_exit_submit+0x2542> */
	X86_SIM_X86_JMP(0x2537, 0x2542, x86_l_2542);
x86_l_2539:
	/* 0x2539: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_253b:
	/* 0x253b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_253e:
	/* 0x253e: jns    2542 <sys_exit_submit+0x2542> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x253e, 0x2542, x86_l_2542);
x86_l_2540:
	/* 0x2540: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2542:
	/* 0x2542: add    rbp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2546:
	/* 0x2546: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_254a:
	/* 0x254a: call   254f <sys_exit_submit+0x254f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_254f:
	/* 0x254f: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2553:
	/* 0x2553: lea    rax,[r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2557:
	/* 0x2557: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_255a:
	/* 0x255a: jns    2561 <sys_exit_submit+0x2561> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x255a, 0x2561, x86_l_2561);
x86_l_255c:
	/* 0x255c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_255f:
	/* 0x255f: jmp    2563 <sys_exit_submit+0x2563> */
	X86_SIM_X86_JMP(0x255f, 0x2563, x86_l_2563);
x86_l_2561:
	/* 0x2561: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2563:
	/* 0x2563: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2567:
	/* 0x2567: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_256b:
	/* 0x256b: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_256e:
	/* 0x256e: jns    2575 <sys_exit_submit+0x2575> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x256e, 0x2575, x86_l_2575);
x86_l_2570:
	/* 0x2570: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2573:
	/* 0x2573: jmp    2577 <sys_exit_submit+0x2577> */
	X86_SIM_X86_JMP(0x2573, 0x2577, x86_l_2577);
x86_l_2575:
	/* 0x2575: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2577:
	/* 0x2577: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_257b:
	/* 0x257b: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_257f:
	/* 0x257f: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2582:
	/* 0x2582: jns    2593 <sys_exit_submit+0x2593> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2582, 0x2593, x86_l_2593);
x86_l_2584:
	/* 0x2584: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2588:
	/* 0x2588: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_258c:
	/* 0x258c: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_258f:
	/* 0x258f: js     259e <sys_exit_submit+0x259e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x258f, 0x259e, x86_l_259e);
x86_l_2591:
	/* 0x2591: jmp    25ab <sys_exit_submit+0x25ab> */
	X86_SIM_X86_JMP(0x2591, 0x25ab, x86_l_25ab);
x86_l_2593:
	/* 0x2593: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2595:
	/* 0x2595: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2599:
	/* 0x2599: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_259c:
	/* 0x259c: jns    25ab <sys_exit_submit+0x25ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x259c, 0x25ab, x86_l_25ab);
x86_l_259e:
	/* 0x259e: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25a2:
	/* 0x25a2: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_25a4:
	/* 0x25a4: je     25ab <sys_exit_submit+0x25ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a4, 0x25ab, x86_l_25ab);
x86_l_25a6:
	/* 0x25a6: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_25ab:
	/* 0x25ab: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25b0:
	/* 0x25b0: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_25b4:
	/* 0x25b4: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_25bc:
	/* 0x25bc: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_25c4:
	/* 0x25c4: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_25c9:
	/* 0x25c9: call   25ce <sys_exit_submit+0x25ce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_25ce:
	/* 0x25ce: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25d1:
	/* 0x25d1: jns    25e9 <sys_exit_submit+0x25e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25d1, 0x25e9, x86_l_25e9);
x86_l_25d3:
	/* 0x25d3: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25d6:
	/* 0x25d6: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25db:
	/* 0x25db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25de:
	/* 0x25de: js     25f5 <sys_exit_submit+0x25f5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25de, 0x25f5, x86_l_25f5);
x86_l_25e0:
	/* 0x25e0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25e2:
	/* 0x25e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e5:
	/* 0x25e5: js     25fd <sys_exit_submit+0x25fd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25e5, 0x25fd, x86_l_25fd);
x86_l_25e7:
	/* 0x25e7: jmp    263e <sys_exit_submit+0x263e> */
	X86_SIM_X86_JMP(0x25e7, 0x263e, x86_l_263e);
x86_l_25e9:
	/* 0x25e9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25eb:
	/* 0x25eb: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25f0:
	/* 0x25f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25f3:
	/* 0x25f3: jns    25e0 <sys_exit_submit+0x25e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25f3, 0x25e0, x86_l_25e0);
x86_l_25f5:
	/* 0x25f5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25f8:
	/* 0x25f8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25fb:
	/* 0x25fb: jns    263e <sys_exit_submit+0x263e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25fb, 0x263e, x86_l_263e);
x86_l_25fd:
	/* 0x25fd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2600:
	/* 0x2600: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2605:
	/* 0x2605: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2609:
	/* 0x2609: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_260e:
	/* 0x260e: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2612:
	/* 0x2612: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2617:
	/* 0x2617: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_261b:
	/* 0x261b: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2620:
	/* 0x2620: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2624:
	/* 0x2624: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2629:
	/* 0x2629: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_262d:
	/* 0x262d: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2632:
	/* 0x2632: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2636:
	/* 0x2636: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_263a:
	/* 0x263a: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_263e:
	/* 0x263e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2643:
	/* 0x2643: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_2647:
	/* 0x2647: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_264c:
	/* 0x264c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_264f:
	/* 0x264f: jns    2725 <sys_exit_submit+0x2725> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x264f, 0x2725, x86_l_2725);
x86_l_2655:
	/* 0x2655: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2658:
	/* 0x2658: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_265a:
	/* 0x265a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_265c:
	/* 0x265c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x265c, 0x2734, x86_l_2734);
x86_l_2662:
	/* 0x2662: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2666:
	/* 0x2666: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_266a:
	/* 0x266a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_266c:
	/* 0x266c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x266c, 0x2734, x86_l_2734);
x86_l_2672:
	/* 0x2672: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2676:
	/* 0x2676: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_267a:
	/* 0x267a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_267c:
	/* 0x267c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x267c, 0x2734, x86_l_2734);
x86_l_2682:
	/* 0x2682: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2686:
	/* 0x2686: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_268a:
	/* 0x268a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_268c:
	/* 0x268c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x268c, 0x2734, x86_l_2734);
x86_l_2692:
	/* 0x2692: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2696:
	/* 0x2696: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_269a:
	/* 0x269a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_269c:
	/* 0x269c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x269c, 0x2734, x86_l_2734);
x86_l_26a2:
	/* 0x26a2: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_26a6:
	/* 0x26a6: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_26aa:
	/* 0x26aa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26ac:
	/* 0x26ac: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26ac, 0x2734, x86_l_2734);
x86_l_26b2:
	/* 0x26b2: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_26b6:
	/* 0x26b6: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_26ba:
	/* 0x26ba: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26bc:
	/* 0x26bc: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26bc, 0x2734, x86_l_2734);
x86_l_26be:
	/* 0x26be: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_26c2:
	/* 0x26c2: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_26c6:
	/* 0x26c6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26c8:
	/* 0x26c8: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26c8, 0x2734, x86_l_2734);
x86_l_26ca:
	/* 0x26ca: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_26ce:
	/* 0x26ce: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_26d2:
	/* 0x26d2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26d4:
	/* 0x26d4: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d4, 0x2734, x86_l_2734);
x86_l_26d6:
	/* 0x26d6: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_26da:
	/* 0x26da: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_26de:
	/* 0x26de: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26e0:
	/* 0x26e0: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e0, 0x2734, x86_l_2734);
x86_l_26e2:
	/* 0x26e2: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_26e6:
	/* 0x26e6: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_26ea:
	/* 0x26ea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26ec:
	/* 0x26ec: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26ec, 0x2734, x86_l_2734);
x86_l_26ee:
	/* 0x26ee: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_26f2:
	/* 0x26f2: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_26f6:
	/* 0x26f6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_26f8:
	/* 0x26f8: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26f8, 0x2734, x86_l_2734);
x86_l_26fa:
	/* 0x26fa: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_26fe:
	/* 0x26fe: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2702:
	/* 0x2702: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2704:
	/* 0x2704: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2704, 0x2734, x86_l_2734);
x86_l_2706:
	/* 0x2706: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_270a:
	/* 0x270a: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_270e:
	/* 0x270e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2710:
	/* 0x2710: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2710, 0x2734, x86_l_2734);
x86_l_2712:
	/* 0x2712: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2716:
	/* 0x2716: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_271a:
	/* 0x271a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_271c:
	/* 0x271c: je     2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JCC(X86_CC_E, 0x271c, 0x2734, x86_l_2734);
x86_l_271e:
	/* 0x271e: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_2723:
	/* 0x2723: jmp    2734 <sys_exit_submit+0x2734> */
	X86_SIM_X86_JMP(0x2723, 0x2734, x86_l_2734);
x86_l_2725:
	/* 0x2725: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_272d:
	/* 0x272d: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2734:
	/* 0x2734: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2737:
	/* 0x2737: jns    27bd <sys_exit_submit+0x27bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2737, 0x27bd, x86_l_27bd);
x86_l_273d:
	/* 0x273d: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2741:
	/* 0x2741: mov    QWORD PTR [rbx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2744:
	/* 0x2744: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2748:
	/* 0x2748: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_274c:
	/* 0x274c: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2750:
	/* 0x2750: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2754:
	/* 0x2754: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2758:
	/* 0x2758: mov    QWORD PTR [rbx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_275c:
	/* 0x275c: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2760:
	/* 0x2760: mov    QWORD PTR [rbx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2764:
	/* 0x2764: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2768:
	/* 0x2768: mov    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_276c:
	/* 0x276c: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2770:
	/* 0x2770: mov    QWORD PTR [rbx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2774:
	/* 0x2774: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2778:
	/* 0x2778: mov    QWORD PTR [rbx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_277c:
	/* 0x277c: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2780:
	/* 0x2780: mov    QWORD PTR [rbx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2784:
	/* 0x2784: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2788:
	/* 0x2788: mov    QWORD PTR [rbx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_278c:
	/* 0x278c: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2790:
	/* 0x2790: mov    QWORD PTR [rbx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2794:
	/* 0x2794: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2798:
	/* 0x2798: mov    QWORD PTR [rbx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_279c:
	/* 0x279c: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_27a0:
	/* 0x27a0: mov    QWORD PTR [rbx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_27a4:
	/* 0x27a4: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_27a9:
	/* 0x27a9: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27ae:
	/* 0x27ae: test   BYTE PTR [rax+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_27b2:
	/* 0x27b2: jne    2834 <sys_exit_submit+0x2834> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27b2, 0x2834, x86_l_2834);
x86_l_27b8:
	/* 0x27b8: jmp    2850 <sys_exit_submit+0x2850> */
	X86_SIM_X86_JMP(0x27b8, 0x2850, x86_l_2850);
x86_l_27bd:
	/* 0x27bd: mov    QWORD PTR [rbx+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_27c5:
	/* 0x27c5: mov    QWORD PTR [rbx+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_27cd:
	/* 0x27cd: mov    QWORD PTR [rbx+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_27d5:
	/* 0x27d5: mov    QWORD PTR [rbx+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_27dd:
	/* 0x27dd: mov    QWORD PTR [rbx+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_27e5:
	/* 0x27e5: mov    QWORD PTR [rbx+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_27ed:
	/* 0x27ed: mov    QWORD PTR [rbx+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_27f5:
	/* 0x27f5: mov    QWORD PTR [rbx+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_27fd:
	/* 0x27fd: mov    QWORD PTR [rbx+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2805:
	/* 0x2805: mov    QWORD PTR [rbx+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_280d:
	/* 0x280d: mov    QWORD PTR [rbx+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2815:
	/* 0x2815: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_281d:
	/* 0x281d: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2824:
	/* 0x2824: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2829:
	/* 0x2829: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_282e:
	/* 0x282e: test   BYTE PTR [rax+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_2832:
	/* 0x2832: je     2850 <sys_exit_submit+0x2850> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2832, 0x2850, x86_l_2850);
x86_l_2834:
	/* 0x2834: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_283b:
	/* 0x283b: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_2840:
	/* 0x2840: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2843:
	/* 0x2843: call   2848 <sys_exit_submit+0x2848> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_2848:
	/* 0x2848: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_284a:
	/* 0x284a: js     2850 <sys_exit_submit+0x2850> */
	X86_SIM_X86_JCC(X86_CC_S, 0x284a, 0x2850, x86_l_2850);
x86_l_284c:
	/* 0x284c: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2850:
	/* 0x2850: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2858:
	/* 0x2858: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_285d:
	/* 0x285d: jb     2864 <sys_exit_submit+0x2864> */
	X86_SIM_X86_JCC(X86_CC_B, 0x285d, 0x2864, x86_l_2864);
x86_l_285f:
	/* 0x285f: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2864:
	/* 0x2864: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_2869:
	/* 0x2869: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_286d:
	/* 0x286d: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_2874:
	/* 0x2874: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2879:
	/* 0x2879: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_287c:
	/* 0x287c: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_287f:
	/* 0x287f: call   2884 <sys_exit_submit+0x2884> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2884:
	/* 0x2884: mov    edx,DWORD PTR [rbx+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2887:
	/* 0x2887: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_exit_tails));
x86_l_288e:
	/* 0x288e: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2891:
	/* 0x2891: call   2896 <sys_exit_submit+0x2896> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_2896:
	/* 0x2896: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2898:
	/* 0x2898: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_289f:
	/* 0x289f: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a0:
	/* 0x28a0: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a2:
	/* 0x28a2: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a6:
	/* 0x28a6: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a8:
	/* 0x28a8: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28a9:
	/* 0x28a9: jmp    2b87 <sys_exit_submit+0x2b87> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_28ae:
	/* 0x28ae: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b0:
	/* 0x28b0: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28b3:
	/* 0x28b3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28b6:
	/* 0x28b6: jns    28ba <sys_exit_submit+0x28ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b6, 0x28ba, x86_l_28ba);
x86_l_28b8:
	/* 0x28b8: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ba:
	/* 0x28ba: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_28bc:
	/* 0x28bc: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_28c0:
	/* 0x28c0: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28c3:
	/* 0x28c3: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_28c7:
	/* 0x28c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c9:
	/* 0x28c9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28cc:
	/* 0x28cc: jns    28d0 <sys_exit_submit+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28cc, 0x28d0, x86_l_28d0);
x86_l_28ce:
	/* 0x28ce: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d0:
	/* 0x28d0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28d5:
	/* 0x28d5: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28d8:
	/* 0x28d8: mov    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28dd:
	/* 0x28dd: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28e2:
	/* 0x28e2: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28e7:
	/* 0x28e7: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28ea:
	/* 0x28ea: lea    rbp,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_28f1:
	/* 0x28f1: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_28f4:
	/* 0x28f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28f7:
	/* 0x28f7: jns    28fe <sys_exit_submit+0x28fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28f7, 0x28fe, x86_l_28fe);
x86_l_28f9:
	/* 0x28f9: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28fc:
	/* 0x28fc: jmp    2900 <sys_exit_submit+0x2900> */
	X86_SIM_X86_JMP(0x28fc, 0x2900, x86_l_2900);
x86_l_28fe:
	/* 0x28fe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2900:
	/* 0x2900: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2904:
	/* 0x2904: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2906:
	/* 0x2906: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2909:
	/* 0x2909: jns    2910 <sys_exit_submit+0x2910> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2909, 0x2910, x86_l_2910);
x86_l_290b:
	/* 0x290b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_290e:
	/* 0x290e: jmp    2912 <sys_exit_submit+0x2912> */
	X86_SIM_X86_JMP(0x290e, 0x2912, x86_l_2912);
x86_l_2910:
	/* 0x2910: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2912:
	/* 0x2912: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2915:
	/* 0x2915: jns    2919 <sys_exit_submit+0x2919> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2915, 0x2919, x86_l_2919);
x86_l_2917:
	/* 0x2917: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2919:
	/* 0x2919: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_291e:
	/* 0x291e: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2922:
	/* 0x2922: call   2927 <sys_exit_submit+0x2927> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2927:
	/* 0x2927: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_292b:
	/* 0x292b: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_292f:
	/* 0x292f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2932:
	/* 0x2932: jns    2939 <sys_exit_submit+0x2939> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2932, 0x2939, x86_l_2939);
x86_l_2934:
	/* 0x2934: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2937:
	/* 0x2937: jmp    293b <sys_exit_submit+0x293b> */
	X86_SIM_X86_JMP(0x2937, 0x293b, x86_l_293b);
x86_l_2939:
	/* 0x2939: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_293b:
	/* 0x293b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2940:
	/* 0x2940: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2943:
	/* 0x2943: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2947:
	/* 0x2947: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_294a:
	/* 0x294a: jns    2951 <sys_exit_submit+0x2951> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x294a, 0x2951, x86_l_2951);
x86_l_294c:
	/* 0x294c: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_294f:
	/* 0x294f: jmp    2953 <sys_exit_submit+0x2953> */
	X86_SIM_X86_JMP(0x294f, 0x2953, x86_l_2953);
x86_l_2951:
	/* 0x2951: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2953:
	/* 0x2953: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2958:
	/* 0x2958: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_295c:
	/* 0x295c: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2960:
	/* 0x2960: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2963:
	/* 0x2963: jns    296b <sys_exit_submit+0x296b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2963, 0x296b, x86_l_296b);
x86_l_2965:
	/* 0x2965: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2969:
	/* 0x2969: jmp    296d <sys_exit_submit+0x296d> */
	X86_SIM_X86_JMP(0x2969, 0x296d, x86_l_296d);
x86_l_296b:
	/* 0x296b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_296d:
	/* 0x296d: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2972:
	/* 0x2972: mov    QWORD PTR [r15+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2976:
	/* 0x2976: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2979:
	/* 0x2979: jns    2986 <sys_exit_submit+0x2986> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2979, 0x2986, x86_l_2986);
x86_l_297b:
	/* 0x297b: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297d:
	/* 0x297d: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_297f:
	/* 0x297f: je     2986 <sys_exit_submit+0x2986> */
	X86_SIM_X86_JCC(X86_CC_E, 0x297f, 0x2986, x86_l_2986);
x86_l_2981:
	/* 0x2981: or     BYTE PTR [r15+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_2986:
	/* 0x2986: lea    rdi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_298a:
	/* 0x298a: mov    QWORD PTR [r15+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_2992:
	/* 0x2992: mov    QWORD PTR [r15+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_299a:
	/* 0x299a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_299f:
	/* 0x299f: call   29a4 <sys_exit_submit+0x29a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_29a4:
	/* 0x29a4: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_29a7:
	/* 0x29a7: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_29aa:
	/* 0x29aa: jns    29b2 <sys_exit_submit+0x29b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29aa, 0x29b2, x86_l_29b2);
x86_l_29ac:
	/* 0x29ac: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b0:
	/* 0x29b0: jmp    29b4 <sys_exit_submit+0x29b4> */
	X86_SIM_X86_JMP(0x29b0, 0x29b4, x86_l_29b4);
x86_l_29b2:
	/* 0x29b2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29b4:
	/* 0x29b4: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_29b9:
	/* 0x29b9: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29be:
	/* 0x29be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29c1:
	/* 0x29c1: jns    29c8 <sys_exit_submit+0x29c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29c1, 0x29c8, x86_l_29c8);
x86_l_29c3:
	/* 0x29c3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c6:
	/* 0x29c6: jmp    29ca <sys_exit_submit+0x29ca> */
	X86_SIM_X86_JMP(0x29c6, 0x29ca, x86_l_29ca);
x86_l_29c8:
	/* 0x29c8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29ca:
	/* 0x29ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29cd:
	/* 0x29cd: jns    2a1a <sys_exit_submit+0x2a1a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29cd, 0x2a1a, x86_l_2a1a);
x86_l_29cf:
	/* 0x29cf: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d2:
	/* 0x29d2: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29d7:
	/* 0x29d7: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29db:
	/* 0x29db: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29e0:
	/* 0x29e0: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29e4:
	/* 0x29e4: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_29e9:
	/* 0x29e9: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29ed:
	/* 0x29ed: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_29f2:
	/* 0x29f2: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29f6:
	/* 0x29f6: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_29fb:
	/* 0x29fb: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_29ff:
	/* 0x29ff: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2a04:
	/* 0x2a04: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a08:
	/* 0x2a08: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2a0d:
	/* 0x2a0d: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a11:
	/* 0x2a11: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2a16:
	/* 0x2a16: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2a1a:
	/* 0x2a1a: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2a1d:
	/* 0x2a1d: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_2a21:
	/* 0x2a21: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a26:
	/* 0x2a26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a29:
	/* 0x2a29: jns    2b4e <sys_exit_submit+0x2b4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a29, 0x2b4e, x86_l_2b4e);
x86_l_2a2f:
	/* 0x2a2f: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2a32:
	/* 0x2a32: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a34:
	/* 0x2a34: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2a36:
	/* 0x2a36: je     2b5d <sys_exit_submit+0x2b5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a36, 0x2b5d, x86_l_2b5d);
x86_l_2a3c:
	/* 0x2a3c: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2a40:
	/* 0x2a40: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_2a43:
	/* 0x2a43: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a45:
	/* 0x2a45: je     2b5d <sys_exit_submit+0x2b5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a45, 0x2b5d, x86_l_2b5d);
x86_l_2a4b:
	/* 0x2a4b: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2a4f:
	/* 0x2a4f: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_2a52:
	/* 0x2a52: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a54:
	/* 0x2a54: je     2b5d <sys_exit_submit+0x2b5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a54, 0x2b5d, x86_l_2b5d);
x86_l_2a5a:
	/* 0x2a5a: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2a5e:
	/* 0x2a5e: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_2a61:
	/* 0x2a61: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a63:
	/* 0x2a63: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a63, 0x2b67, x86_l_2b67);
x86_l_2a69:
	/* 0x2a69: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2a6d:
	/* 0x2a6d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a72:
	/* 0x2a72: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2a75:
	/* 0x2a75: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a77:
	/* 0x2a77: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a77, 0x2b67, x86_l_2b67);
x86_l_2a7d:
	/* 0x2a7d: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2a81:
	/* 0x2a81: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a86:
	/* 0x2a86: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_2a89:
	/* 0x2a89: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a8b:
	/* 0x2a8b: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8b, 0x2b67, x86_l_2b67);
x86_l_2a91:
	/* 0x2a91: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2a95:
	/* 0x2a95: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a9a:
	/* 0x2a9a: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_2a9d:
	/* 0x2a9d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a9f:
	/* 0x2a9f: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a9f, 0x2b67, x86_l_2b67);
x86_l_2aa5:
	/* 0x2aa5: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2aa9:
	/* 0x2aa9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2aae:
	/* 0x2aae: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_2ab1:
	/* 0x2ab1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2ab3:
	/* 0x2ab3: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ab3, 0x2b67, x86_l_2b67);
x86_l_2ab9:
	/* 0x2ab9: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2abd:
	/* 0x2abd: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ac2:
	/* 0x2ac2: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_2ac5:
	/* 0x2ac5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2ac7:
	/* 0x2ac7: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ac7, 0x2b67, x86_l_2b67);
x86_l_2acd:
	/* 0x2acd: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2ad1:
	/* 0x2ad1: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ad6:
	/* 0x2ad6: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_2ad9:
	/* 0x2ad9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2adb:
	/* 0x2adb: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2adb, 0x2b67, x86_l_2b67);
x86_l_2ae1:
	/* 0x2ae1: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2ae5:
	/* 0x2ae5: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2aea:
	/* 0x2aea: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_2aed:
	/* 0x2aed: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2aef:
	/* 0x2aef: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aef, 0x2b67, x86_l_2b67);
x86_l_2af1:
	/* 0x2af1: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2af5:
	/* 0x2af5: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2afa:
	/* 0x2afa: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2afd:
	/* 0x2afd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2aff:
	/* 0x2aff: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aff, 0x2b67, x86_l_2b67);
x86_l_2b01:
	/* 0x2b01: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2b05:
	/* 0x2b05: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b0a:
	/* 0x2b0a: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b0d:
	/* 0x2b0d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2b0f:
	/* 0x2b0f: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b0f, 0x2b67, x86_l_2b67);
x86_l_2b11:
	/* 0x2b11: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2b15:
	/* 0x2b15: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b1a:
	/* 0x2b1a: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2b1d:
	/* 0x2b1d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2b1f:
	/* 0x2b1f: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b1f, 0x2b67, x86_l_2b67);
x86_l_2b21:
	/* 0x2b21: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2b25:
	/* 0x2b25: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b2a:
	/* 0x2b2a: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2b2d:
	/* 0x2b2d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2b2f:
	/* 0x2b2f: je     2b67 <sys_exit_submit+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b2f, 0x2b67, x86_l_2b67);
x86_l_2b31:
	/* 0x2b31: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b36:
	/* 0x2b36: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_2b3a:
	/* 0x2b3a: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b3f:
	/* 0x2b3f: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b44:
	/* 0x2b44: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b49:
	/* 0x2b49: jmp    222 <sys_exit_submit+0x222> */
	X86_SIM_X86_JMP(0x2b49, 0x222, x86_l_222);
x86_l_2b4e:
	/* 0x2b4e: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2b56:
	/* 0x2b56: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b5d:
	/* 0x2b5d: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b62:
	/* 0x2b62: jmp    222 <sys_exit_submit+0x222> */
	X86_SIM_X86_JMP(0x2b62, 0x222, x86_l_222);
x86_l_2b67:
	/* 0x2b67: mov    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b6c:
	/* 0x2b6c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b71:
	/* 0x2b71: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b76:
	/* 0x2b76: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b7b:
	/* 0x2b7b: jmp    222 <sys_exit_submit+0x222> */
	X86_SIM_X86_JMP(0x2b7b, 0x222, x86_l_222);
x86_l_2b80:
	/* 0x2b80: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b82:
	/* 0x2b82: jmp    2260 <sys_exit_submit+0x2260> */
	X86_SIM_X86_JMP(0x2b82, 0x2260, x86_l_2260);
x86_l_2b87:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
