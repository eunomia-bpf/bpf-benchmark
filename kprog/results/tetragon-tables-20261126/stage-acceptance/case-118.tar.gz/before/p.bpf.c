#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 168U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 data_heap[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: mov    r14,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17:
	/* 0x17: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x3e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data_heap));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2b:
	/* 0x2b: call   410 <__do_bytes+0xe1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_30:
	/* 0x30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33:
	/* 0x33: je     a2 <data_event_bytes+0xa2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33, 0xa2, x86_l_a2);
x86_l_35:
	/* 0x35: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: mov    DWORD PTR [rax],0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3e:
	/* 0x3e: call   423 <__do_bytes+0xf4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_43:
	/* 0x43: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_46:
	/* 0x46: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4a:
	/* 0x4a: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e:
	/* 0x4e: cmp    rax,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_52:
	/* 0x52: jne    5d <data_event_bytes+0x5d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x52, 0x5d, x86_l_5d);
x86_l_54:
	/* 0x54: mov    rax,QWORD PTR [r12+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_59:
	/* 0x59: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d:
	/* 0x5d: call   442 <__do_bytes+0x113> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_62:
	/* 0x62: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_66:
	/* 0x66: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6a:
	/* 0x6a: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e:
	/* 0x6e: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_76:
	/* 0x76: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_79:
	/* 0x79: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7c:
	/* 0x7c: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7f:
	/* 0x7f: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_82:
	/* 0x82: call   d1 <do_bytes> */
	X86_SIM_X86_CALL(x86_l_d1, 0x87ULL);
x86_l_87:
	/* 0x87: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_89:
	/* 0x89: js     a6 <data_event_bytes+0xa6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x89, 0xa6, x86_l_a6);
x86_l_8b:
	/* 0x8b: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_92:
	/* 0x92: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_94:
	/* 0x94: cmp    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_98:
	/* 0x98: je     b3 <data_event_bytes+0xb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x98, 0xb3, x86_l_b3);
x86_l_9a:
	/* 0x9a: sub    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_9d:
	/* 0x9d: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_a0:
	/* 0xa0: jmp    b3 <data_event_bytes+0xb3> */
	X86_SIM_X86_JMP(0xa0, 0xb3, x86_l_b3);
x86_l_a2:
	/* 0xa2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a4:
	/* 0xa4: jmp    be <data_event_bytes+0xbe> */
	X86_SIM_X86_JMP(0xa4, 0xbe, x86_l_be);
x86_l_a6:
	/* 0xa6: mov    DWORD PTR [rbx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a8:
	/* 0xa8: mov    DWORD PTR [rbx+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_af:
	/* 0xaf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b1:
	/* 0xb1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b3:
	/* 0xb3: mov    DWORD PTR [rbx+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b6:
	/* 0xb6: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b9:
	/* 0xb9: mov    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_be:
	/* 0xbe: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_c2:
	/* 0xc2: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_c3:
	/* 0xc3: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_c5:
	/* 0xc5: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_c7:
	/* 0xc7: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_c9:
	/* 0xc9: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cb:
	/* 0xcb: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cc:
	/* 0xcc: jmp    469 <__do_bytes+0x13a> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_469:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_d1 */
x86_l_d1:
	/* 0xd1: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_d2:
	/* 0xd2: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d4:
	/* 0xd4: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_d6:
	/* 0xd6: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d8:
	/* 0xd8: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_da:
	/* 0xda: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_db:
	/* 0xdb: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dc:
	/* 0xdc: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_df:
	/* 0xdf: mov    r14,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e2:
	/* 0xe2: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e5:
	/* 0xe5: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0xedULL);
x86_l_ed:
	/* 0xed: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_ef:
	/* 0xef: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0xef, 0x298, x86_l_298);
x86_l_f5:
	/* 0xf5: mov    r13d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_f8:
	/* 0xf8: and    r13d,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_ff:
	/* 0xff: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_102:
	/* 0x102: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_105:
	/* 0x105: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x105, 0x31d, x86_l_31d);
x86_l_10b:
	/* 0x10b: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_10f:
	/* 0x10f: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_112:
	/* 0x112: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_115:
	/* 0x115: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x11aULL);
x86_l_11a:
	/* 0x11a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11c:
	/* 0x11c: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x11c, 0x298, x86_l_298);
x86_l_122:
	/* 0x122: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_127:
	/* 0x127: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_12d:
	/* 0x12d: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_130:
	/* 0x130: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_133:
	/* 0x133: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x133, 0x31d, x86_l_31d);
x86_l_139:
	/* 0x139: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_13d:
	/* 0x13d: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_140:
	/* 0x140: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_143:
	/* 0x143: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x148ULL);
x86_l_148:
	/* 0x148: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_14a:
	/* 0x14a: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x14a, 0x298, x86_l_298);
x86_l_150:
	/* 0x150: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_155:
	/* 0x155: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_158:
	/* 0x158: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15b:
	/* 0x15b: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15e:
	/* 0x15e: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_161:
	/* 0x161: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x161, 0x31d, x86_l_31d);
x86_l_167:
	/* 0x167: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_16b:
	/* 0x16b: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_171:
	/* 0x171: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x176ULL);
x86_l_176:
	/* 0x176: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_178:
	/* 0x178: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x178, 0x298, x86_l_298);
x86_l_17e:
	/* 0x17e: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_183:
	/* 0x183: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_186:
	/* 0x186: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_189:
	/* 0x189: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18c:
	/* 0x18c: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_18f:
	/* 0x18f: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18f, 0x31d, x86_l_31d);
x86_l_195:
	/* 0x195: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_199:
	/* 0x199: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_19c:
	/* 0x19c: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_19f:
	/* 0x19f: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x1a4ULL);
x86_l_1a4:
	/* 0x1a4: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x1a6, 0x298, x86_l_298);
x86_l_1ac:
	/* 0x1ac: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_1b1:
	/* 0x1b1: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b4:
	/* 0x1b4: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b7:
	/* 0x1b7: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ba:
	/* 0x1ba: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1bd:
	/* 0x1bd: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1bd, 0x31d, x86_l_31d);
x86_l_1c3:
	/* 0x1c3: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1c7:
	/* 0x1c7: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ca:
	/* 0x1ca: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1cd:
	/* 0x1cd: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x1d2ULL);
x86_l_1d2:
	/* 0x1d2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d4:
	/* 0x1d4: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x1d4, 0x298, x86_l_298);
x86_l_1da:
	/* 0x1da: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_1df:
	/* 0x1df: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e2:
	/* 0x1e2: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e5:
	/* 0x1e5: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e8:
	/* 0x1e8: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1eb:
	/* 0x1eb: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1eb, 0x31d, x86_l_31d);
x86_l_1f1:
	/* 0x1f1: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1f5:
	/* 0x1f5: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1f8:
	/* 0x1f8: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1fb:
	/* 0x1fb: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x200ULL);
x86_l_200:
	/* 0x200: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_202:
	/* 0x202: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x202, 0x298, x86_l_298);
x86_l_208:
	/* 0x208: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_20d:
	/* 0x20d: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_210:
	/* 0x210: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_213:
	/* 0x213: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_216:
	/* 0x216: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_219:
	/* 0x219: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x219, 0x31d, x86_l_31d);
x86_l_21f:
	/* 0x21f: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_223:
	/* 0x223: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_226:
	/* 0x226: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_229:
	/* 0x229: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x22eULL);
x86_l_22e:
	/* 0x22e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_230:
	/* 0x230: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x230, 0x298, x86_l_298);
x86_l_232:
	/* 0x232: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_237:
	/* 0x237: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23a:
	/* 0x23a: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_23d:
	/* 0x23d: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_240:
	/* 0x240: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_243:
	/* 0x243: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x243, 0x31d, x86_l_31d);
x86_l_249:
	/* 0x249: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_24d:
	/* 0x24d: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_250:
	/* 0x250: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_253:
	/* 0x253: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x258ULL);
x86_l_258:
	/* 0x258: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_25a:
	/* 0x25a: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x25a, 0x298, x86_l_298);
x86_l_25c:
	/* 0x25c: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_261:
	/* 0x261: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_264:
	/* 0x264: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_267:
	/* 0x267: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26a:
	/* 0x26a: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_26d:
	/* 0x26d: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x26d, 0x31d, x86_l_31d);
x86_l_273:
	/* 0x273: add    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_276:
	/* 0x276: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_279:
	/* 0x279: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_27c:
	/* 0x27c: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_27f:
	/* 0x27f: call   32f <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_32f, 0x284ULL);
x86_l_284:
	/* 0x284: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_286:
	/* 0x286: js     298 <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x286, 0x298, x86_l_298);
x86_l_288:
	/* 0x288: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_28d:
	/* 0x28d: add    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_290:
	/* 0x290: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_293:
	/* 0x293: jmp    31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JMP(0x293, 0x31d, x86_l_31d);
x86_l_298:
	/* 0x298: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_29b:
	/* 0x29b: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_2a3:
	/* 0x2a3: mov    rdi,QWORD PTR [rip+0x4b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_2aa:
	/* 0x2aa: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2af:
	/* 0x2af: call   764 <__do_bytes+0x435> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b4:
	/* 0x2b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b7:
	/* 0x2b7: je     31d <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b7, 0x31d, x86_l_31d);
x86_l_2b9:
	/* 0x2b9: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2bd:
	/* 0x2bd: jg     2d9 <do_bytes+0x208> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2bd, 0x2d9, x86_l_2d9);
x86_l_2bf:
	/* 0x2bf: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_2c3:
	/* 0x2c3: je     2f3 <do_bytes+0x222> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c3, 0x2f3, x86_l_2f3);
x86_l_2c5:
	/* 0x2c5: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2c9:
	/* 0x2c9: je     30b <do_bytes+0x23a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c9, 0x30b, x86_l_30b);
x86_l_2cb:
	/* 0x2cb: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2cf:
	/* 0x2cf: jne    303 <do_bytes+0x232> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2cf, 0x303, x86_l_303);
x86_l_2d1:
	/* 0x2d1: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_2d7:
	/* 0x2d7: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x2d7, 0x319, x86_l_319);
x86_l_2d9:
	/* 0x2d9: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2dd:
	/* 0x2dd: je     2fb <do_bytes+0x22a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2dd, 0x2fb, x86_l_2fb);
x86_l_2df:
	/* 0x2df: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2e3:
	/* 0x2e3: je     313 <do_bytes+0x242> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2e3, 0x313, x86_l_313);
x86_l_2e5:
	/* 0x2e5: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2e9:
	/* 0x2e9: jne    303 <do_bytes+0x232> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2e9, 0x303, x86_l_303);
x86_l_2eb:
	/* 0x2eb: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_2f1:
	/* 0x2f1: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x2f1, 0x319, x86_l_319);
x86_l_2f3:
	/* 0x2f3: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_2f9:
	/* 0x2f9: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x2f9, 0x319, x86_l_319);
x86_l_2fb:
	/* 0x2fb: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_301:
	/* 0x301: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x301, 0x319, x86_l_319);
x86_l_303:
	/* 0x303: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_309:
	/* 0x309: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x309, 0x319, x86_l_319);
x86_l_30b:
	/* 0x30b: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_311:
	/* 0x311: jmp    319 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x311, 0x319, x86_l_319);
x86_l_313:
	/* 0x313: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_319:
	/* 0x319: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_31d:
	/* 0x31d: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_320:
	/* 0x320: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_324:
	/* 0x324: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_325:
	/* 0x325: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_327:
	/* 0x327: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_329:
	/* 0x329: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32b:
	/* 0x32b: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32d:
	/* 0x32d: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32e:
	/* 0x32e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_32e);

	/* native subroutine native_link_sub_32f */
x86_l_32f:
	/* 0x32f: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_331:
	/* 0x331: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_333:
	/* 0x333: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_335:
	/* 0x335: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_336:
	/* 0x336: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_337:
	/* 0x337: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33a:
	/* 0x33a: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_33d:
	/* 0x33d: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_340:
	/* 0x340: cmp    rcx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32736ULL);
x86_l_347:
	/* 0x347: jb     34e <__do_bytes+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x347, 0x34e, x86_l_34e);
x86_l_349:
	/* 0x349: mov    ebx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 32736ULL);
x86_l_34e:
	/* 0x34e: lea    rdi,[r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_352:
	/* 0x352: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_355:
	/* 0x355: js     367 <__do_bytes+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x355, 0x367, x86_l_367);
x86_l_357:
	/* 0x357: mov    esi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_359:
	/* 0x359: call   a6e <__do_bytes+0x73f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_35e:
	/* 0x35e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_360:
	/* 0x360: jns    3b1 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x360, 0x3b1, x86_l_3b1);
x86_l_362:
	/* 0x362: jmp    428 <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JMP(0x362, 0x428, x86_l_428);
x86_l_367:
	/* 0x367: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_36a:
	/* 0x36a: jns    417 <__do_bytes+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x36a, 0x417, x86_l_417);
x86_l_370:
	/* 0x370: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_372:
	/* 0x372: cmp    ebx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_375:
	/* 0x375: jb     391 <__do_bytes+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x375, 0x391, x86_l_391);
x86_l_377:
	/* 0x377: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_379:
	/* 0x379: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37c:
	/* 0x37c: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_380:
	/* 0x380: mov    QWORD PTR [rdi+rcx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_384:
	/* 0x384: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_388:
	/* 0x388: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_38c:
	/* 0x38c: cmp    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_38f:
	/* 0x38f: jbe    379 <__do_bytes+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x38f, 0x379, x86_l_379);
x86_l_391:
	/* 0x391: test   bl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_394:
	/* 0x394: jne    43a <__do_bytes+0x10b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x394, 0x43a, x86_l_43a);
x86_l_39a:
	/* 0x39a: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_39d:
	/* 0x39d: jne    44e <__do_bytes+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x39d, 0x44e, x86_l_44e);
x86_l_3a3:
	/* 0x3a3: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3a6:
	/* 0x3a6: je     3b1 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3a6, 0x3b1, x86_l_3b1);
x86_l_3a8:
	/* 0x3a8: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3aa:
	/* 0x3aa: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_3ae:
	/* 0x3ae: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_3b1:
	/* 0x3b1: lea    r12d,[rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3b5:
	/* 0x3b5: mov    DWORD PTR [r14+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3b9:
	/* 0x3b9: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_3c1:
	/* 0x3c1: mov    rdi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_3c8:
	/* 0x3c8: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3cd:
	/* 0x3cd: call   ae8 <__do_bytes+0x7b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3d2:
	/* 0x3d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d5:
	/* 0x3d5: je     3fd <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d5, 0x3fd, x86_l_3fd);
x86_l_3d7:
	/* 0x3d7: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_3db:
	/* 0x3db: je     3fd <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3db, 0x3fd, x86_l_3fd);
x86_l_3dd:
	/* 0x3dd: mov    rsi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_3e4:
	/* 0x3e4: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_3e9:
	/* 0x3e9: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3ec:
	/* 0x3ec: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3ef:
	/* 0x3ef: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f2:
	/* 0x3f2: call   b0d <__do_bytes+0x7de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_3f7:
	/* 0x3f7: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3f9:
	/* 0x3f9: js     428 <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x3f9, 0x428, x86_l_428);
x86_l_3fb:
	/* 0x3fb: jmp    42b <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x3fb, 0x42b, x86_l_42b);
x86_l_3fd:
	/* 0x3fd: mov    rdi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_404:
	/* 0x404: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_407:
	/* 0x407: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_40a:
	/* 0x40a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_40c:
	/* 0x40c: call   b27 <__do_bytes+0x7f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_411:
	/* 0x411: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_413:
	/* 0x413: js     428 <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x413, 0x428, x86_l_428);
x86_l_415:
	/* 0x415: jmp    42b <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x415, 0x42b, x86_l_42b);
x86_l_417:
	/* 0x417: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_419:
	/* 0x419: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_41c:
	/* 0x41c: call   b37 <__do_bytes+0x808> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_421:
	/* 0x421: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_428:
	/* 0x428: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_42b:
	/* 0x42b: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_42e:
	/* 0x42e: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_432:
	/* 0x432: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_433:
	/* 0x433: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_435:
	/* 0x435: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_437:
	/* 0x437: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_439:
	/* 0x439: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_439);
x86_l_43a:
	/* 0x43a: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_43c:
	/* 0x43c: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_43f:
	/* 0x43f: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_442:
	/* 0x442: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_445:
	/* 0x445: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_448:
	/* 0x448: je     3a3 <__do_bytes+0x74> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x448, 0x3a3, x86_l_3a3);
x86_l_44e:
	/* 0x44e: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_450:
	/* 0x450: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_454:
	/* 0x454: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_458:
	/* 0x458: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_45b:
	/* 0x45b: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_45e:
	/* 0x45e: jne    3a8 <__do_bytes+0x79> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x45e, 0x3a8, x86_l_3a8);
x86_l_464:
	/* 0x464: jmp    3b1 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JMP(0x464, 0x3b1, x86_l_3b1);

x86_sim_ret_dispatch_32e:
	switch (__x86_sim_ret_addr) {
	case 0x87ULL: goto x86_l_87;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_439:
	switch (__x86_sim_ret_addr) {
	case 0xedULL: goto x86_l_ed;
	case 0x11aULL: goto x86_l_11a;
	case 0x148ULL: goto x86_l_148;
	case 0x176ULL: goto x86_l_176;
	case 0x1a4ULL: goto x86_l_1a4;
	case 0x1d2ULL: goto x86_l_1d2;
	case 0x200ULL: goto x86_l_200;
	case 0x22eULL: goto x86_l_22e;
	case 0x258ULL: goto x86_l_258;
	case 0x284ULL: goto x86_l_284;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
