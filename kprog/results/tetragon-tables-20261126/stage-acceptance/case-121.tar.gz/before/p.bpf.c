#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 104U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: mov    r14,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17:
	/* 0x17: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x1cULL);
x86_l_1c:
	/* 0x1c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1e:
	/* 0x1e: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e, 0x1c7, x86_l_1c7);
x86_l_24:
	/* 0x24: mov    r13d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_27:
	/* 0x27: and    r13d,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_2e:
	/* 0x2e: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_31:
	/* 0x31: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_34:
	/* 0x34: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34, 0x24c, x86_l_24c);
x86_l_3a:
	/* 0x3a: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3e:
	/* 0x3e: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_41:
	/* 0x41: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_44:
	/* 0x44: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x49ULL);
x86_l_49:
	/* 0x49: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4b:
	/* 0x4b: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4b, 0x1c7, x86_l_1c7);
x86_l_51:
	/* 0x51: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_56:
	/* 0x56: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_59:
	/* 0x59: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5c:
	/* 0x5c: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_62:
	/* 0x62: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x62, 0x24c, x86_l_24c);
x86_l_68:
	/* 0x68: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_6c:
	/* 0x6c: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6f:
	/* 0x6f: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_72:
	/* 0x72: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x77ULL);
x86_l_77:
	/* 0x77: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_79:
	/* 0x79: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x79, 0x1c7, x86_l_1c7);
x86_l_7f:
	/* 0x7f: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_84:
	/* 0x84: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_87:
	/* 0x87: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_8a:
	/* 0x8a: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_8d:
	/* 0x8d: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_90:
	/* 0x90: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90, 0x24c, x86_l_24c);
x86_l_96:
	/* 0x96: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_9a:
	/* 0x9a: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9d:
	/* 0x9d: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a0:
	/* 0xa0: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0xa5ULL);
x86_l_a5:
	/* 0xa5: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a7:
	/* 0xa7: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0xa7, 0x1c7, x86_l_1c7);
x86_l_ad:
	/* 0xad: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_b2:
	/* 0xb2: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5:
	/* 0xb5: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b8:
	/* 0xb8: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bb:
	/* 0xbb: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_be:
	/* 0xbe: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe, 0x24c, x86_l_24c);
x86_l_c4:
	/* 0xc4: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_c8:
	/* 0xc8: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cb:
	/* 0xcb: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ce:
	/* 0xce: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0xd3ULL);
x86_l_d3:
	/* 0xd3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d5:
	/* 0xd5: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd5, 0x1c7, x86_l_1c7);
x86_l_db:
	/* 0xdb: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_e0:
	/* 0xe0: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e3:
	/* 0xe3: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e6:
	/* 0xe6: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e9:
	/* 0xe9: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_ec:
	/* 0xec: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec, 0x24c, x86_l_24c);
x86_l_f2:
	/* 0xf2: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_f6:
	/* 0xf6: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_f9:
	/* 0xf9: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fc:
	/* 0xfc: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x101ULL);
x86_l_101:
	/* 0x101: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_103:
	/* 0x103: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x103, 0x1c7, x86_l_1c7);
x86_l_109:
	/* 0x109: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_10e:
	/* 0x10e: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_111:
	/* 0x111: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_114:
	/* 0x114: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_117:
	/* 0x117: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_11a:
	/* 0x11a: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11a, 0x24c, x86_l_24c);
x86_l_120:
	/* 0x120: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_124:
	/* 0x124: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_127:
	/* 0x127: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x12fULL);
x86_l_12f:
	/* 0x12f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_131:
	/* 0x131: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x131, 0x1c7, x86_l_1c7);
x86_l_137:
	/* 0x137: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_13c:
	/* 0x13c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13f:
	/* 0x13f: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_142:
	/* 0x142: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_145:
	/* 0x145: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_148:
	/* 0x148: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x148, 0x24c, x86_l_24c);
x86_l_14e:
	/* 0x14e: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_152:
	/* 0x152: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_155:
	/* 0x155: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_158:
	/* 0x158: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x15dULL);
x86_l_15d:
	/* 0x15d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15f:
	/* 0x15f: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15f, 0x1c7, x86_l_1c7);
x86_l_161:
	/* 0x161: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_166:
	/* 0x166: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_169:
	/* 0x169: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16c:
	/* 0x16c: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16f:
	/* 0x16f: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_172:
	/* 0x172: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172, 0x24c, x86_l_24c);
x86_l_178:
	/* 0x178: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_17c:
	/* 0x17c: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_182:
	/* 0x182: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x187ULL);
x86_l_187:
	/* 0x187: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_189:
	/* 0x189: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x189, 0x1c7, x86_l_1c7);
x86_l_18b:
	/* 0x18b: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_190:
	/* 0x190: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_193:
	/* 0x193: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_196:
	/* 0x196: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_199:
	/* 0x199: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_19c:
	/* 0x19c: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c, 0x24c, x86_l_24c);
x86_l_1a2:
	/* 0x1a2: add    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a5:
	/* 0x1a5: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1a8:
	/* 0x1a8: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ab:
	/* 0x1ab: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ae:
	/* 0x1ae: call   262 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_262, 0x1b3ULL);
x86_l_1b3:
	/* 0x1b3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b5:
	/* 0x1b5: js     1c7 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b5, 0x1c7, x86_l_1c7);
x86_l_1b7:
	/* 0x1b7: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_1bc:
	/* 0x1bc: add    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1bf:
	/* 0x1bf: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c2:
	/* 0x1c2: jmp    24c <do_bytes+0x24c> */
	X86_SIM_X86_JMP(0x1c2, 0x24c, x86_l_24c);
x86_l_1c7:
	/* 0x1c7: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_1ca:
	/* 0x1ca: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x4b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1de:
	/* 0x1de: call   693 <__do_bytes+0x431> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e3:
	/* 0x1e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e6:
	/* 0x1e6: je     24c <do_bytes+0x24c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e6, 0x24c, x86_l_24c);
x86_l_1e8:
	/* 0x1e8: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_1ec:
	/* 0x1ec: jg     208 <do_bytes+0x208> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1ec, 0x208, x86_l_208);
x86_l_1ee:
	/* 0x1ee: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_1f2:
	/* 0x1f2: je     222 <do_bytes+0x222> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f2, 0x222, x86_l_222);
x86_l_1f4:
	/* 0x1f4: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_1f8:
	/* 0x1f8: je     23a <do_bytes+0x23a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8, 0x23a, x86_l_23a);
x86_l_1fa:
	/* 0x1fa: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_1fe:
	/* 0x1fe: jne    232 <do_bytes+0x232> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fe, 0x232, x86_l_232);
x86_l_200:
	/* 0x200: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_206:
	/* 0x206: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x206, 0x248, x86_l_248);
x86_l_208:
	/* 0x208: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_20c:
	/* 0x20c: je     22a <do_bytes+0x22a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20c, 0x22a, x86_l_22a);
x86_l_20e:
	/* 0x20e: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_212:
	/* 0x212: je     242 <do_bytes+0x242> */
	X86_SIM_X86_JCC(X86_CC_E, 0x212, 0x242, x86_l_242);
x86_l_214:
	/* 0x214: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_218:
	/* 0x218: jne    232 <do_bytes+0x232> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x218, 0x232, x86_l_232);
x86_l_21a:
	/* 0x21a: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_220:
	/* 0x220: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x220, 0x248, x86_l_248);
x86_l_222:
	/* 0x222: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_228:
	/* 0x228: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x228, 0x248, x86_l_248);
x86_l_22a:
	/* 0x22a: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_230:
	/* 0x230: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x230, 0x248, x86_l_248);
x86_l_232:
	/* 0x232: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_238:
	/* 0x238: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x238, 0x248, x86_l_248);
x86_l_23a:
	/* 0x23a: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_240:
	/* 0x240: jmp    248 <do_bytes+0x248> */
	X86_SIM_X86_JMP(0x240, 0x248, x86_l_248);
x86_l_242:
	/* 0x242: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_248:
	/* 0x248: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_24c:
	/* 0x24c: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24f:
	/* 0x24f: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_253:
	/* 0x253: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_254:
	/* 0x254: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_256:
	/* 0x256: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_258:
	/* 0x258: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25a:
	/* 0x25a: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25c:
	/* 0x25c: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_25d:
	/* 0x25d: jmp    39c <__do_bytes+0x13a> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_39c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_262 */
x86_l_262:
	/* 0x262: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_264:
	/* 0x264: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_266:
	/* 0x266: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_268:
	/* 0x268: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a:
	/* 0x26a: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26d:
	/* 0x26d: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_270:
	/* 0x270: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: cmp    rcx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32736ULL);
x86_l_27a:
	/* 0x27a: jb     281 <__do_bytes+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x27a, 0x281, x86_l_281);
x86_l_27c:
	/* 0x27c: mov    ebx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 32736ULL);
x86_l_281:
	/* 0x281: lea    rdi,[r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_285:
	/* 0x285: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_288:
	/* 0x288: js     29a <__do_bytes+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x288, 0x29a, x86_l_29a);
x86_l_28a:
	/* 0x28a: mov    esi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_28c:
	/* 0x28c: call   9a1 <__do_bytes+0x73f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_291:
	/* 0x291: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_293:
	/* 0x293: jns    2e4 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x293, 0x2e4, x86_l_2e4);
x86_l_295:
	/* 0x295: jmp    35b <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JMP(0x295, 0x35b, x86_l_35b);
x86_l_29a:
	/* 0x29a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29d:
	/* 0x29d: jns    34a <__do_bytes+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x29d, 0x34a, x86_l_34a);
x86_l_2a3:
	/* 0x2a3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a5:
	/* 0x2a5: cmp    ebx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2a8:
	/* 0x2a8: jb     2c4 <__do_bytes+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2a8, 0x2c4, x86_l_2c4);
x86_l_2aa:
	/* 0x2aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ac:
	/* 0x2ac: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af:
	/* 0x2af: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2b3:
	/* 0x2b3: mov    QWORD PTR [rdi+rcx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2b7:
	/* 0x2b7: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bb:
	/* 0x2bb: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2bf:
	/* 0x2bf: cmp    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c2:
	/* 0x2c2: jbe    2ac <__do_bytes+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2c2, 0x2ac, x86_l_2ac);
x86_l_2c4:
	/* 0x2c4: test   bl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_2c7:
	/* 0x2c7: jne    36d <__do_bytes+0x10b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2c7, 0x36d, x86_l_36d);
x86_l_2cd:
	/* 0x2cd: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2d0:
	/* 0x2d0: jne    381 <__do_bytes+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2d0, 0x381, x86_l_381);
x86_l_2d6:
	/* 0x2d6: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2d9:
	/* 0x2d9: je     2e4 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2d9, 0x2e4, x86_l_2e4);
x86_l_2db:
	/* 0x2db: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2dd:
	/* 0x2dd: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_2e1:
	/* 0x2e1: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2e4:
	/* 0x2e4: lea    r12d,[rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e8:
	/* 0x2e8: mov    DWORD PTR [r14+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2ec:
	/* 0x2ec: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_2f4:
	/* 0x2f4: mov    rdi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_2fb:
	/* 0x2fb: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_300:
	/* 0x300: call   a1b <__do_bytes+0x7b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_305:
	/* 0x305: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_308:
	/* 0x308: je     330 <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x308, 0x330, x86_l_330);
x86_l_30a:
	/* 0x30a: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_30e:
	/* 0x30e: je     330 <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x30e, 0x330, x86_l_330);
x86_l_310:
	/* 0x310: mov    rsi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_317:
	/* 0x317: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_31c:
	/* 0x31c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_31f:
	/* 0x31f: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_322:
	/* 0x322: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_325:
	/* 0x325: call   a40 <__do_bytes+0x7de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_32a:
	/* 0x32a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_32c:
	/* 0x32c: js     35b <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x32c, 0x35b, x86_l_35b);
x86_l_32e:
	/* 0x32e: jmp    35e <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x32e, 0x35e, x86_l_35e);
x86_l_330:
	/* 0x330: mov    rdi,QWORD PTR [rip+0x716] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_337:
	/* 0x337: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_33a:
	/* 0x33a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_33d:
	/* 0x33d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33f:
	/* 0x33f: call   a5a <__do_bytes+0x7f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_344:
	/* 0x344: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_346:
	/* 0x346: js     35b <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x346, 0x35b, x86_l_35b);
x86_l_348:
	/* 0x348: jmp    35e <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x348, 0x35e, x86_l_35e);
x86_l_34a:
	/* 0x34a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_34c:
	/* 0x34c: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_34f:
	/* 0x34f: call   a6a <__do_bytes+0x808> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_354:
	/* 0x354: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_35b:
	/* 0x35b: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_35e:
	/* 0x35e: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_361:
	/* 0x361: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_365:
	/* 0x365: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_366:
	/* 0x366: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_368:
	/* 0x368: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_36a:
	/* 0x36a: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_36c:
	/* 0x36c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_36c);
x86_l_36d:
	/* 0x36d: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_36f:
	/* 0x36f: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_372:
	/* 0x372: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_375:
	/* 0x375: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_378:
	/* 0x378: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_37b:
	/* 0x37b: je     2d6 <__do_bytes+0x74> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x37b, 0x2d6, x86_l_2d6);
x86_l_381:
	/* 0x381: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_383:
	/* 0x383: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_387:
	/* 0x387: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_38b:
	/* 0x38b: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_38e:
	/* 0x38e: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_391:
	/* 0x391: jne    2db <__do_bytes+0x79> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x391, 0x2db, x86_l_2db);
x86_l_397:
	/* 0x397: jmp    2e4 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JMP(0x397, 0x2e4, x86_l_2e4);

x86_sim_ret_dispatch_36c:
	switch (__x86_sim_ret_addr) {
	case 0x1cULL: goto x86_l_1c;
	case 0x49ULL: goto x86_l_49;
	case 0x77ULL: goto x86_l_77;
	case 0xa5ULL: goto x86_l_a5;
	case 0xd3ULL: goto x86_l_d3;
	case 0x101ULL: goto x86_l_101;
	case 0x12fULL: goto x86_l_12f;
	case 0x15dULL: goto x86_l_15d;
	case 0x187ULL: goto x86_l_187;
	case 0x1b3ULL: goto x86_l_1b3;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
