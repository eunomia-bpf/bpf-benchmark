#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 40U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1)
#include "../x86_sim_local_bpf.h"

extern __u8 cgroup_map[] __ksym;
extern __u8 hists[] __ksym;
extern __u8 start[] __ksym;
static const __u8 __x86_rodata_0[120] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(19):.bss\",\"size\":120}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 117: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 117, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 118: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 118, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 119: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 119, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 117: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 117, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 118: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 118, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 113: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 113, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 114: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 114, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 115: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 115, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 116: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 116, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 15: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 15, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 16: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 16, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 17: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 17, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 18: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 18, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 19: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 19, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 20: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 20, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 21: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 21, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 22: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 22, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 23: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 23, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 24: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 24, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 25: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 25, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 26: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 26, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 27: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 27, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 28: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 28, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 29: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 29, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 30: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 30, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 31: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 31, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 32: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 32, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 33: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 33, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 34: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 34, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 35: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 35, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 36: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 36, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 37: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 37, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 38: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 38, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 39: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 39, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 40: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 40, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 41: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 41, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 42: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 42, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 43: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 43, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 44: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 44, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 45: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 45, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 46: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 46, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 47: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 47, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 48: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 48, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 49: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 49, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 50: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 50, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 51: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 51, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 52: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 52, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 53: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 53, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 54: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 54, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 55: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 55, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 56: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 56, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 57: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 57, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 58: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 58, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 59: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 59, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 60: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 60, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 61: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 61, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 62: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 62, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 63: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 63, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 64: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 64, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 65: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 65, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 66: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 66, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 67: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 67, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 68: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 68, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 69: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 69, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 70: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 70, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 71: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 71, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 72: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 72, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 73: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 73, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 74: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 74, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 75: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 75, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 76: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 76, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 77: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 77, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 78: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 78, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 79: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 79, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 80: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 80, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 81: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 81, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 82: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 82, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 83: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 83, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 84: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 84, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 85: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 85, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 86: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 86, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 87: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 87, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 88: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 88, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 89: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 89, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 90: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 90, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 91: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 91, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 92: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 92, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 93: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 93, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 94: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 94, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 95: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 95, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 96: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 96, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 97: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 97, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 98: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 98, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 99: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 99, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 100: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 100, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 101: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 101, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 102: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 102, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 103: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 103, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 104: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 104, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 105: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 105, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 106: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 106, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 107: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 107, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 108: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 108, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 109: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 109, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 110: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 110, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 111: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 111, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 112: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 112, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_DIV, X86_OP_DIV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_9:
	/* 0x9: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c:
	/* 0xc: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f:
	/* 0xf: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_cg));
x86_l_16:
	/* 0x16: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19:
	/* 0x19: je     32 <handle_switch+0x32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19, 0x32, x86_l_32);
x86_l_1b:
	/* 0x1b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_map));
x86_l_22:
	/* 0x22: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24:
	/* 0x24: call   29 <handle_switch+0x29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_current_task_under_cgroup);
x86_l_29:
	/* 0x29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c:
	/* 0x2c: je     401 <handle_switch+0x401> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c, 0x401, x86_l_401);
x86_l_32:
	/* 0x32: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_35:
	/* 0x35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: jns    40 <handle_switch+0x40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38, 0x40, x86_l_40);
x86_l_3a:
	/* 0x3a: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c:
	/* 0x3c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3e:
	/* 0x3e: jne    9b <handle_switch+0x9b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e, 0x9b, x86_l_9b);
x86_l_40:
	/* 0x40: lea    rcx,[r14+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_47:
	/* 0x47: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49:
	/* 0x49: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4c:
	/* 0x4c: jns    50 <handle_switch+0x50> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4c, 0x50, x86_l_50);
x86_l_4e:
	/* 0x4e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50:
	/* 0x50: add    r14,0xaf0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2800ULL);
x86_l_57:
	/* 0x57: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5a:
	/* 0x5a: jns    9b <handle_switch+0x9b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5a, 0x9b, x86_l_9b);
x86_l_5c:
	/* 0x5c: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5f:
	/* 0x5f: mov    DWORD PTR [rsp+0x4],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_63:
	/* 0x63: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_65:
	/* 0x65: je     9b <handle_switch+0x9b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65, 0x9b, x86_l_9b);
x86_l_67:
	/* 0x67: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_tgid));
x86_l_6e:
	/* 0x6e: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_71:
	/* 0x71: je     79 <handle_switch+0x79> */
	X86_SIM_X86_JCC(X86_CC_E, 0x71, 0x79, x86_l_79);
x86_l_73:
	/* 0x73: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_75:
	/* 0x75: cmp    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_77:
	/* 0x77: jne    9b <handle_switch+0x9b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x77, 0x9b, x86_l_9b);
x86_l_79:
	/* 0x79: call   7e <handle_switch+0x7e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_7e:
	/* 0x7e: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_83:
	/* 0x83: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_8a:
	/* 0x8a: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8f:
	/* 0x8f: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_94:
	/* 0x94: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_96:
	/* 0x96: call   9b <handle_switch+0x9b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_9b:
	/* 0x9b: lea    rcx,[rbx+0xaf0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2800ULL);
x86_l_a2:
	/* 0xa2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a4:
	/* 0xa4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a7:
	/* 0xa7: jns    ab <handle_switch+0xab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa7, 0xab, x86_l_ab);
x86_l_a9:
	/* 0xa9: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ab:
	/* 0xab: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_af:
	/* 0xaf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_b6:
	/* 0xb6: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bb:
	/* 0xbb: call   c0 <handle_switch+0xc0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c0:
	/* 0xc0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c3:
	/* 0xc3: je     401 <handle_switch+0x401> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3, 0x401, x86_l_401);
x86_l_c9:
	/* 0xc9: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc:
	/* 0xcc: call   d1 <handle_switch+0xd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_d1:
	/* 0xd1: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d4:
	/* 0xd4: sub    r14,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_d7:
	/* 0xd7: js     3f0 <handle_switch+0x3f0> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd7, 0x3f0, x86_l_3f0);
x86_l_dd:
	/* 0xdd: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_process));
x86_l_e4:
	/* 0xe4: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e7:
	/* 0xe7: je     102 <handle_switch+0x102> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe7, 0x102, x86_l_102);
x86_l_e9:
	/* 0xe9: lea    rcx,[rbx+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_f0:
	/* 0xf0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f2:
	/* 0xf2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f5:
	/* 0xf5: jns    f9 <handle_switch+0xf9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf5, 0xf9, x86_l_f9);
x86_l_f7:
	/* 0xf7: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f9:
	/* 0xf9: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fd:
	/* 0xfd: jmp    184 <handle_switch+0x184> */
	X86_SIM_X86_JMP(0xfd, 0x184, x86_l_184);
x86_l_102:
	/* 0x102: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_thread));
x86_l_109:
	/* 0x109: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10c:
	/* 0x10c: je     118 <handle_switch+0x118> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10c, 0x118, x86_l_118);
x86_l_10e:
	/* 0x10e: mov    eax,DWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_112:
	/* 0x112: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_116:
	/* 0x116: jmp    184 <handle_switch+0x184> */
	X86_SIM_X86_JMP(0x116, 0x184, x86_l_184);
x86_l_118:
	/* 0x118: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_per_pidns));
x86_l_11f:
	/* 0x11f: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_122:
	/* 0x122: je     135 <handle_switch+0x135> */
	X86_SIM_X86_JCC(X86_CC_E, 0x122, 0x135, x86_l_135);
x86_l_124:
	/* 0x124: lea    rax,[rbx+0xb58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
x86_l_12b:
	/* 0x12b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12e:
	/* 0x12e: jns    13f <handle_switch+0x13f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12e, 0x13f, x86_l_13f);
x86_l_130:
	/* 0x130: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_133:
	/* 0x133: jmp    141 <handle_switch+0x141> */
	X86_SIM_X86_JMP(0x133, 0x141, x86_l_141);
x86_l_135:
	/* 0x135: mov    DWORD PTR [rsp+0x4],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 21474836479ULL);
x86_l_13d:
	/* 0x13d: jmp    184 <handle_switch+0x184> */
	X86_SIM_X86_JMP(0x13d, 0x184, x86_l_184);
x86_l_13f:
	/* 0x13f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_141:
	/* 0x141: lea    rcx,[rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_145:
	/* 0x145: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_148:
	/* 0x148: jns    150 <handle_switch+0x150> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148, 0x150, x86_l_150);
x86_l_14a:
	/* 0x14a: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c:
	/* 0x14c: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_14e:
	/* 0x14e: jmp    152 <handle_switch+0x152> */
	X86_SIM_X86_JMP(0x14e, 0x152, x86_l_152);
x86_l_150:
	/* 0x150: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_152:
	/* 0x152: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_156:
	/* 0x156: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_159:
	/* 0x159: add    rcx,0x80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
x86_l_160:
	/* 0x160: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_162:
	/* 0x162: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_165:
	/* 0x165: jns    170 <handle_switch+0x170> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x165, 0x170, x86_l_170);
x86_l_167:
	/* 0x167: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a:
	/* 0x16a: mov    rcx,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16e:
	/* 0x16e: jmp    172 <handle_switch+0x172> */
	X86_SIM_X86_JMP(0x16e, 0x172, x86_l_172);
x86_l_170:
	/* 0x170: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_172:
	/* 0x172: add    rcx,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_179:
	/* 0x179: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17c:
	/* 0x17c: jns    180 <handle_switch+0x180> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c, 0x180, x86_l_180);
x86_l_17e:
	/* 0x17e: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180:
	/* 0x180: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_184:
	/* 0x184: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_18b:
	/* 0x18b: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_190:
	/* 0x190: call   195 <handle_switch+0x195> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_195:
	/* 0x195: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_198:
	/* 0x198: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19b:
	/* 0x19b: je     298 <handle_switch+0x298> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b, 0x298, x86_l_298);
x86_l_1a1:
	/* 0x1a1: cmp    BYTE PTR [rcx+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1a5:
	/* 0x1a5: jne    2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a5, 0x2f5, x86_l_2f5);
x86_l_1ab:
	/* 0x1ab: lea    rax,[rcx+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1af:
	/* 0x1af: add    rbx,0xd10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3344ULL);
x86_l_1b6:
	/* 0x1b6: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b9:
	/* 0x1b9: jns    2e6 <handle_switch+0x2e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b9, 0x2e6, x86_l_2e6);
x86_l_1bf:
	/* 0x1bf: movzx  edx,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1c2:
	/* 0x1c2: mov    BYTE PTR [rax],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c4:
	/* 0x1c4: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1c6:
	/* 0x1c6: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c6, 0x2f5, x86_l_2f5);
x86_l_1cc:
	/* 0x1cc: movzx  eax,BYTE PTR [rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1d0:
	/* 0x1d0: mov    BYTE PTR [rcx+0x69],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 105ULL);
x86_l_1d3:
	/* 0x1d3: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1d5:
	/* 0x1d5: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5, 0x2f5, x86_l_2f5);
x86_l_1db:
	/* 0x1db: movzx  eax,BYTE PTR [rbx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1df:
	/* 0x1df: mov    BYTE PTR [rcx+0x6a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 106ULL);
x86_l_1e2:
	/* 0x1e2: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1e4:
	/* 0x1e4: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e4, 0x2f5, x86_l_2f5);
x86_l_1ea:
	/* 0x1ea: movzx  eax,BYTE PTR [rbx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1ee:
	/* 0x1ee: mov    BYTE PTR [rcx+0x6b],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 107ULL);
x86_l_1f1:
	/* 0x1f1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1f3:
	/* 0x1f3: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f3, 0x2f5, x86_l_2f5);
x86_l_1f9:
	/* 0x1f9: movzx  eax,BYTE PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1fd:
	/* 0x1fd: mov    BYTE PTR [rcx+0x6c],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 108ULL);
x86_l_200:
	/* 0x200: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_202:
	/* 0x202: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x202, 0x2f5, x86_l_2f5);
x86_l_208:
	/* 0x208: movzx  eax,BYTE PTR [rbx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_20c:
	/* 0x20c: mov    BYTE PTR [rcx+0x6d],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 109ULL);
x86_l_20f:
	/* 0x20f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_211:
	/* 0x211: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x211, 0x2f5, x86_l_2f5);
x86_l_217:
	/* 0x217: movzx  eax,BYTE PTR [rbx+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_21b:
	/* 0x21b: mov    BYTE PTR [rcx+0x6e],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 110ULL);
x86_l_21e:
	/* 0x21e: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_220:
	/* 0x220: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x220, 0x2f5, x86_l_2f5);
x86_l_226:
	/* 0x226: movzx  eax,BYTE PTR [rbx+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_22a:
	/* 0x22a: mov    BYTE PTR [rcx+0x6f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 111ULL);
x86_l_22d:
	/* 0x22d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_22f:
	/* 0x22f: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22f, 0x2f5, x86_l_2f5);
x86_l_235:
	/* 0x235: movzx  eax,BYTE PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_239:
	/* 0x239: mov    BYTE PTR [rcx+0x70],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_23c:
	/* 0x23c: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_23e:
	/* 0x23e: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23e, 0x2f5, x86_l_2f5);
x86_l_244:
	/* 0x244: movzx  eax,BYTE PTR [rbx+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_248:
	/* 0x248: mov    BYTE PTR [rcx+0x71],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 113ULL);
x86_l_24b:
	/* 0x24b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_24d:
	/* 0x24d: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d, 0x2f5, x86_l_2f5);
x86_l_253:
	/* 0x253: movzx  eax,BYTE PTR [rbx+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_257:
	/* 0x257: mov    BYTE PTR [rcx+0x72],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 114ULL);
x86_l_25a:
	/* 0x25a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_25c:
	/* 0x25c: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c, 0x2f5, x86_l_2f5);
x86_l_262:
	/* 0x262: movzx  eax,BYTE PTR [rbx+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_266:
	/* 0x266: mov    BYTE PTR [rcx+0x73],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 115ULL);
x86_l_269:
	/* 0x269: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_26b:
	/* 0x26b: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26b, 0x2f5, x86_l_2f5);
x86_l_271:
	/* 0x271: movzx  eax,BYTE PTR [rbx+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_275:
	/* 0x275: mov    BYTE PTR [rcx+0x74],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_278:
	/* 0x278: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_27a:
	/* 0x27a: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a, 0x2f5, x86_l_2f5);
x86_l_27c:
	/* 0x27c: movzx  eax,BYTE PTR [rbx+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_280:
	/* 0x280: mov    BYTE PTR [rcx+0x75],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 117ULL);
x86_l_283:
	/* 0x283: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_285:
	/* 0x285: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285, 0x2f5, x86_l_2f5);
x86_l_287:
	/* 0x287: movzx  eax,BYTE PTR [rbx+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_28b:
	/* 0x28b: mov    BYTE PTR [rcx+0x76],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 118ULL);
x86_l_28e:
	/* 0x28e: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_290:
	/* 0x290: je     2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x290, 0x2f5, x86_l_2f5);
x86_l_292:
	/* 0x292: mov    BYTE PTR [rcx+0x77],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 511101108224ULL);
x86_l_296:
	/* 0x296: jmp    2f5 <handle_switch+0x2f5> */
	X86_SIM_X86_JMP(0x296, 0x2f5, x86_l_2f5);
x86_l_298:
	/* 0x298: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_29f:
	/* 0x29f: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_2a6:
	/* 0x2a6: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2ab:
	/* 0x2ab: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2b0:
	/* 0x2b0: call   2b5 <handle_switch+0x2b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2b5:
	/* 0x2b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b8:
	/* 0x2b8: je     2c4 <handle_switch+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b8, 0x2c4, x86_l_2c4);
x86_l_2ba:
	/* 0x2ba: cmp    rax,0xffffffffffffffef */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551599ULL);
x86_l_2be:
	/* 0x2be: jne    3f0 <handle_switch+0x3f0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2be, 0x3f0, x86_l_3f0);
x86_l_2c4:
	/* 0x2c4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hists));
x86_l_2cb:
	/* 0x2cb: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2d0:
	/* 0x2d0: call   2d5 <handle_switch+0x2d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d5:
	/* 0x2d5: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d8:
	/* 0x2d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2db:
	/* 0x2db: jne    1a1 <handle_switch+0x1a1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2db, 0x1a1, x86_l_1a1);
x86_l_2e1:
	/* 0x2e1: jmp    3f0 <handle_switch+0x3f0> */
	X86_SIM_X86_JMP(0x2e1, 0x3f0, x86_l_3f0);
x86_l_2e6:
	/* 0x2e6: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2ee:
	/* 0x2ee: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f5:
	/* 0x2f5: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&targ_ms));
x86_l_2fc:
	/* 0x2fc: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff:
	/* 0x2ff: mov    esi,0x3e8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1000ULL);
x86_l_304:
	/* 0x304: je     30b <handle_switch+0x30b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x304, 0x30b, x86_l_30b);
x86_l_306:
	/* 0x306: mov    esi,0xf4240 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1000000ULL);
x86_l_30b:
	/* 0x30b: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_30e:
	/* 0x30e: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_312:
	/* 0x312: je     37e <handle_switch+0x37e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x312, 0x37e, x86_l_37e);
x86_l_314:
	/* 0x314: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_317:
	/* 0x317: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_319:
	/* 0x319: div    rsi */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_31c:
	/* 0x31c: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31f:
	/* 0x31f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_321:
	/* 0x321: shr    rsi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_325:
	/* 0x325: je     390 <handle_switch+0x390> */
	X86_SIM_X86_JCC(X86_CC_E, 0x325, 0x390, x86_l_390);
x86_l_327:
	/* 0x327: cmp    esi,0x10000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 65536ULL);
x86_l_32d:
	/* 0x32d: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_330:
	/* 0x330: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_333:
	/* 0x333: shrx   esi,esi,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_338:
	/* 0x338: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33a:
	/* 0x33a: cmp    esi,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_340:
	/* 0x340: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_343:
	/* 0x343: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_346:
	/* 0x346: shrx   esi,esi,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_34b:
	/* 0x34b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_34d:
	/* 0x34d: cmp    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_350:
	/* 0x350: setae  dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_354:
	/* 0x354: shl    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_357:
	/* 0x357: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_35c:
	/* 0x35c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35f:
	/* 0x35f: cmp    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_362:
	/* 0x362: setae  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_366:
	/* 0x366: add    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_369:
	/* 0x369: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_36e:
	/* 0x36e: shr    esi,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_370:
	/* 0x370: or     eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_372:
	/* 0x372: or     eax,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_374:
	/* 0x374: or     eax,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_377:
	/* 0x377: or     eax,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_379:
	/* 0x379: add    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 32ULL);
x86_l_37c:
	/* 0x37c: jmp    3e1 <handle_switch+0x3e1> */
	X86_SIM_X86_JMP(0x37c, 0x3e1, x86_l_3e1);
x86_l_37e:
	/* 0x37e: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_381:
	/* 0x381: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_383:
	/* 0x383: div    esi */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_385:
	/* 0x385: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_388:
	/* 0x388: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38a:
	/* 0x38a: shr    rsi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_38e:
	/* 0x38e: jne    327 <handle_switch+0x327> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38e, 0x327, x86_l_327);
x86_l_390:
	/* 0x390: cmp    eax,0x10000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 65536ULL);
x86_l_395:
	/* 0x395: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_398:
	/* 0x398: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_39b:
	/* 0x39b: shrx   esi,eax,edx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RAX, X86_WIDTH_32, X86_RDX, X86_ALU_SHR);
x86_l_3a0:
	/* 0x3a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a2:
	/* 0x3a2: cmp    esi,0x100 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_3a8:
	/* 0x3a8: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3ab:
	/* 0x3ab: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_3ae:
	/* 0x3ae: shrx   esi,esi,eax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RAX, X86_ALU_SHR);
x86_l_3b3:
	/* 0x3b3: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b5:
	/* 0x3b5: cmp    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3b8:
	/* 0x3b8: setae  dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3bc:
	/* 0x3bc: shl    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_3bf:
	/* 0x3bf: shrx   esi,esi,edi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_RDI, X86_ALU_SHR);
x86_l_3c4:
	/* 0x3c4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c7:
	/* 0x3c7: cmp    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3ca:
	/* 0x3ca: setae  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_3ce:
	/* 0x3ce: add    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_3d1:
	/* 0x3d1: shrx   esi,esi,r8d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RSI, X86_RSI, X86_WIDTH_32, X86_R8, X86_ALU_SHR);
x86_l_3d6:
	/* 0x3d6: shr    esi,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3d8:
	/* 0x3d8: or     eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3da:
	/* 0x3da: or     eax,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3dc:
	/* 0x3dc: or     eax,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3df:
	/* 0x3df: or     eax,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_3e1:
	/* 0x3e1: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_3e4:
	/* 0x3e4: mov    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_3e9:
	/* 0x3e9: cmovb  edx,eax */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RAX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_3ec:
	/* 0x3ec: lock inc DWORD PTR [rcx+rdx*4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RCX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_RDX, 2, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3f0:
	/* 0x3f0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)start));
x86_l_3f7:
	/* 0x3f7: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3fc:
	/* 0x3fc: call   401 <handle_switch+0x401> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_401:
	/* 0x401: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_405:
	/* 0x405: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_406:
	/* 0x406: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_408:
	/* 0x408: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_40a:
	/* 0x40a: jmp    40f <handle_switch+0x40f> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_40f:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
