#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 88U
#define X86_SIM_STACK_VALUE_WORDS(M) M(4)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 argfilter_maps[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_5:
	/* 0x5: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_c:
	/* 0xc: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_10:
	/* 0x10: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_14:
	/* 0x14: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16:
	/* 0x16: cmp    r8d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1a:
	/* 0x1a: jg     54 <filter_sockaddr_un+0x54> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1a, 0x54, x86_l_54);
x86_l_1c:
	/* 0x1c: lea    ecx,[r8-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_20:
	/* 0x20: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_23:
	/* 0x23: jae    62 <filter_sockaddr_un+0x62> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x23, 0x62, x86_l_62);
x86_l_25:
	/* 0x25: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28:
	/* 0x28: call   b7 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_b7, 0x2dULL);
x86_l_2d:
	/* 0x2d: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_30:
	/* 0x30: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_34:
	/* 0x34: ja     4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x34, 0x4a, x86_l_4a);
x86_l_36:
	/* 0x36: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_40:
	/* 0x40: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_44:
	/* 0x44: jae    4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x44, 0x4a, x86_l_4a);
x86_l_46:
	/* 0x46: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_4a:
	/* 0x4a: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4e:
	/* 0x4e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4f:
	/* 0x4f: jmp    744 <filter_32ty_map+0x81> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_54:
	/* 0x54: cmp    r8d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_58:
	/* 0x58: je     9c <filter_sockaddr_un+0x9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58, 0x9c, x86_l_9c);
x86_l_5a:
	/* 0x5a: cmp    r8d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_5e:
	/* 0x5e: je     68 <filter_sockaddr_un+0x68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5e, 0x68, x86_l_68);
x86_l_60:
	/* 0x60: jmp    4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JMP(0x60, 0x4a, x86_l_4a);
x86_l_62:
	/* 0x62: cmp    r8d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_66:
	/* 0x66: jne    4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x66, 0x4a, x86_l_4a);
x86_l_68:
	/* 0x68: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b:
	/* 0x6b: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_6e:
	/* 0x6e: mov    edi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_70:
	/* 0x70: call   5a0 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_5a0, 0x75ULL);
x86_l_75:
	/* 0x75: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_78:
	/* 0x78: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_7c:
	/* 0x7c: ja     4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7c, 0x4a, x86_l_4a);
x86_l_7e:
	/* 0x7e: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_88:
	/* 0x88: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8c:
	/* 0x8c: jae    4a <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x8c, 0x4a, x86_l_4a);
x86_l_8e:
	/* 0x8e: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_92:
	/* 0x92: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_96:
	/* 0x96: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_97:
	/* 0x97: jmp    744 <filter_32ty_map+0x81> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_9c:
	/* 0x9c: movzx  eax,WORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_9f:
	/* 0x9f: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a3:
	/* 0xa3: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a8:
	/* 0xa8: call   6c3 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_6c3, 0xadULL);
x86_l_ad:
	/* 0xad: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_b1:
	/* 0xb1: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b2:
	/* 0xb2: jmp    744 <filter_32ty_map+0x81> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_744:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_b7 */
x86_l_b7:
	/* 0xb7: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b8:
	/* 0xb8: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ba:
	/* 0xba: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bc:
	/* 0xbc: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_be:
	/* 0xbe: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c0:
	/* 0xc0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c1:
	/* 0xc1: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c2:
	/* 0xc2: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9:
	/* 0xc9: cmp    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_cf:
	/* 0xcf: ja     498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcf, 0x498, x86_l_498);
x86_l_d5:
	/* 0xd5: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_d8:
	/* 0xd8: cmp    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_dd:
	/* 0xdd: ja     12d <filter_char_buf_equal+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdd, 0x12d, x86_l_12d);
x86_l_df:
	/* 0xdf: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_e2:
	/* 0xe2: imul   ecx,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_e8:
	/* 0xe8: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_eb:
	/* 0xeb: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_ee:
	/* 0xee: lea    ecx,[rcx+rcx*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_f1:
	/* 0xf1: sub    al,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB, 0);
x86_l_f3:
	/* 0xf3: test   dx,dx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_16, 0, 0);
x86_l_f6:
	/* 0xf6: je     101 <filter_char_buf_equal+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf6, 0x101, x86_l_101);
x86_l_f8:
	/* 0xf8: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_fa:
	/* 0xfa: mov    r15d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_fd:
	/* 0xfd: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_ff:
	/* 0xff: je     11a <filter_char_buf_equal+0x63> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xff, 0x11a, x86_l_11a);
x86_l_101:
	/* 0x101: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_104:
	/* 0x104: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_106:
	/* 0x106: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_108:
	/* 0x108: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_10a:
	/* 0x10a: add    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_10d:
	/* 0x10d: movzx  r15d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_111:
	/* 0x111: cmp    cx,0x78 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, 0, 120ULL);
x86_l_115:
	/* 0x115: ja     16b <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x115, 0x16b, x86_l_16b);
x86_l_117:
	/* 0x117: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_11a:
	/* 0x11a: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11d:
	/* 0x11d: imul   ebp,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_123:
	/* 0x123: shr    ebp,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_126:
	/* 0x126: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_128:
	/* 0x128: jmp    1b1 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x128, 0x1b1, x86_l_1b1);
x86_l_12d:
	/* 0x12d: mov    r15d,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_133:
	/* 0x133: cmp    eax,0x101 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 257ULL);
x86_l_138:
	/* 0x138: jb     16b <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x138, 0x16b, x86_l_16b);
x86_l_13a:
	/* 0x13a: mov    r15d,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_140:
	/* 0x140: cmp    eax,0x201 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 513ULL);
x86_l_145:
	/* 0x145: jb     16b <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x145, 0x16b, x86_l_16b);
x86_l_147:
	/* 0x147: mov    r15d,0x400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_14d:
	/* 0x14d: cmp    eax,0x401 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1025ULL);
x86_l_152:
	/* 0x152: jb     16b <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x152, 0x16b, x86_l_16b);
x86_l_154:
	/* 0x154: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157:
	/* 0x157: cmp    eax,0x801 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2049ULL);
x86_l_15c:
	/* 0x15c: setae  r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_160:
	/* 0x160: shl    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_164:
	/* 0x164: add    r15d,0x800 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_16b:
	/* 0x16b: lea    eax,[r15-0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_172:
	/* 0x172: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_178:
	/* 0x178: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_17b:
	/* 0x17b: jg     18d <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x17b, 0x18d, x86_l_18d);
x86_l_17d:
	/* 0x17d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_17f:
	/* 0x17f: je     1a5 <filter_char_buf_equal+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17f, 0x1a5, x86_l_1a5);
x86_l_181:
	/* 0x181: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_184:
	/* 0x184: jne    19e <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x184, 0x19e, x86_l_19e);
x86_l_186:
	/* 0x186: mov    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_18b:
	/* 0x18b: jmp    1b1 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x18b, 0x1b1, x86_l_1b1);
x86_l_18d:
	/* 0x18d: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_190:
	/* 0x190: je     1ac <filter_char_buf_equal+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x190, 0x1ac, x86_l_1ac);
x86_l_192:
	/* 0x192: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_195:
	/* 0x195: jne    19e <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x195, 0x19e, x86_l_19e);
x86_l_197:
	/* 0x197: mov    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_19c:
	/* 0x19c: jmp    1b1 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x19c, 0x1b1, x86_l_1b1);
x86_l_19e:
	/* 0x19e: mov    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1a3:
	/* 0x1a3: jmp    1b1 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1a3, 0x1b1, x86_l_1b1);
x86_l_1a5:
	/* 0x1a5: mov    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1aa:
	/* 0x1aa: jmp    1b1 <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1aa, 0x1b1, x86_l_1b1);
x86_l_1ac:
	/* 0x1ac: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1b1:
	/* 0x1b1: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1b3:
	/* 0x1b3: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1b6:
	/* 0x1b6: mov    r12d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_1bb:
	/* 0x1bb: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1bf:
	/* 0x1bf: je     498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1bf, 0x498, x86_l_498);
x86_l_1c5:
	/* 0x1c5: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c8:
	/* 0x1c8: mov    r13d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1cb:
	/* 0x1cb: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_heap));
x86_l_1d2:
	/* 0x1d2: mov    r14,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1d5:
	/* 0x1d5: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d8:
	/* 0x1d8: call   22cd <filter_32ty_map+0x1c0a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1dd:
	/* 0x1dd: mov    rdi,QWORD PTR [rip+0x20f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_1e4:
	/* 0x1e4: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1e7:
	/* 0x1e7: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ea:
	/* 0x1ea: call   22df <filter_32ty_map+0x1c1c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ef:
	/* 0x1ef: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f1:
	/* 0x1f1: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f4:
	/* 0x1f4: je     49a <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f4, 0x49a, x86_l_49a);
x86_l_1fa:
	/* 0x1fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fd:
	/* 0x1fd: je     49a <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1fd, 0x49a, x86_l_49a);
x86_l_203:
	/* 0x203: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_206:
	/* 0x206: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_209:
	/* 0x209: jg     268 <filter_char_buf_equal+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x209, 0x268, x86_l_268);
x86_l_20b:
	/* 0x20b: mov    BYTE PTR [r14],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e:
	/* 0x20e: lea    rdi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_212:
	/* 0x212: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_215:
	/* 0x215: jns    2be <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x215, 0x2be, x86_l_2be);
x86_l_21b:
	/* 0x21b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21e:
	/* 0x21e: jns    2cb <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x21e, 0x2cb, x86_l_2cb);
x86_l_224:
	/* 0x224: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_226:
	/* 0x226: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_229:
	/* 0x229: jb     249 <filter_char_buf_equal+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x229, 0x249, x86_l_249);
x86_l_22b:
	/* 0x22b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22e:
	/* 0x22e: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_231:
	/* 0x231: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_235:
	/* 0x235: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_239:
	/* 0x239: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23d:
	/* 0x23d: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_241:
	/* 0x241: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_244:
	/* 0x244: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_247:
	/* 0x247: jbe    22e <filter_char_buf_equal+0x177> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x247, 0x22e, x86_l_22e);
x86_l_249:
	/* 0x249: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_24d:
	/* 0x24d: jne    4ac <filter_char_buf_equal+0x3f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x24d, 0x4ac, x86_l_4ac);
x86_l_253:
	/* 0x253: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_257:
	/* 0x257: jne    4c4 <filter_char_buf_equal+0x40d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x257, 0x4c4, x86_l_4c4);
x86_l_25d:
	/* 0x25d: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_261:
	/* 0x261: je     2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x261, 0x2dd, x86_l_2dd);
x86_l_263:
	/* 0x263: jmp    4de <filter_char_buf_equal+0x427> */
	X86_SIM_X86_SUB_JMP(0x263, 0x4de, x86_l_4de);
x86_l_268:
	/* 0x268: mov    WORD PTR [r14],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c:
	/* 0x26c: lea    rdi,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_270:
	/* 0x270: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: jns    2be <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x273, 0x2be, x86_l_2be);
x86_l_275:
	/* 0x275: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_278:
	/* 0x278: jns    2cb <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x278, 0x2cb, x86_l_2cb);
x86_l_27a:
	/* 0x27a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27c:
	/* 0x27c: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_27f:
	/* 0x27f: jb     29f <filter_char_buf_equal+0x1e8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x27f, 0x29f, x86_l_29f);
x86_l_281:
	/* 0x281: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_284:
	/* 0x284: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_287:
	/* 0x287: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_28b:
	/* 0x28b: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_28f:
	/* 0x28f: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_293:
	/* 0x293: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_297:
	/* 0x297: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_29a:
	/* 0x29a: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_29d:
	/* 0x29d: jbe    284 <filter_char_buf_equal+0x1cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x29d, 0x284, x86_l_284);
x86_l_29f:
	/* 0x29f: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_2a3:
	/* 0x2a3: jne    4ec <filter_char_buf_equal+0x435> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2a3, 0x4ec, x86_l_4ec);
x86_l_2a9:
	/* 0x2a9: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2ad:
	/* 0x2ad: jne    504 <filter_char_buf_equal+0x44d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2ad, 0x504, x86_l_504);
x86_l_2b3:
	/* 0x2b3: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2b7:
	/* 0x2b7: je     2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b7, 0x2dd, x86_l_2dd);
x86_l_2b9:
	/* 0x2b9: jmp    51e <filter_char_buf_equal+0x467> */
	X86_SIM_X86_SUB_JMP(0x2b9, 0x51e, x86_l_51e);
x86_l_2be:
	/* 0x2be: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c1:
	/* 0x2c1: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c4:
	/* 0x2c4: call   23cc <filter_32ty_map+0x1d09> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c9:
	/* 0x2c9: jmp    2d7 <filter_char_buf_equal+0x220> */
	X86_SIM_X86_SUB_JMP(0x2c9, 0x2d7, x86_l_2d7);
x86_l_2cb:
	/* 0x2cb: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2cd:
	/* 0x2cd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cf:
	/* 0x2cf: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d2:
	/* 0x2d2: call   23da <filter_32ty_map+0x1d17> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_2d7:
	/* 0x2d7: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_2da:
	/* 0x2da: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2dd:
	/* 0x2dd: sub    r15d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2e0:
	/* 0x2e0: jle    3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x2e0, 0x3b6, x86_l_3b6);
x86_l_2e6:
	/* 0x2e6: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2e8:
	/* 0x2e8: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2eb:
	/* 0x2eb: add    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2ee:
	/* 0x2ee: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2f1:
	/* 0x2f1: and    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2f7:
	/* 0x2f7: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2fa:
	/* 0x2fa: jg     353 <filter_char_buf_equal+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2fa, 0x353, x86_l_353);
x86_l_2fc:
	/* 0x2fc: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_2ff:
	/* 0x2ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_302:
	/* 0x302: jns    3a3 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x302, 0x3a3, x86_l_3a3);
x86_l_308:
	/* 0x308: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30b:
	/* 0x30b: jns    3ad <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x30b, 0x3ad, x86_l_3ad);
x86_l_311:
	/* 0x311: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_313:
	/* 0x313: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_316:
	/* 0x316: jb     334 <filter_char_buf_equal+0x27d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x316, 0x334, x86_l_334);
x86_l_318:
	/* 0x318: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_31a:
	/* 0x31a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31c:
	/* 0x31c: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31f:
	/* 0x31f: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_323:
	/* 0x323: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_327:
	/* 0x327: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32b:
	/* 0x32b: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_32f:
	/* 0x32f: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_332:
	/* 0x332: jbe    31c <filter_char_buf_equal+0x265> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x332, 0x31c, x86_l_31c);
x86_l_334:
	/* 0x334: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_338:
	/* 0x338: jne    52c <filter_char_buf_equal+0x475> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x338, 0x52c, x86_l_52c);
x86_l_33e:
	/* 0x33e: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_342:
	/* 0x342: jne    541 <filter_char_buf_equal+0x48a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x342, 0x541, x86_l_541);
x86_l_348:
	/* 0x348: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_34c:
	/* 0x34c: je     3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x34c, 0x3b6, x86_l_3b6);
x86_l_34e:
	/* 0x34e: jmp    558 <filter_char_buf_equal+0x4a1> */
	X86_SIM_X86_SUB_JMP(0x34e, 0x558, x86_l_558);
x86_l_353:
	/* 0x353: add    rdi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_357:
	/* 0x357: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35a:
	/* 0x35a: jns    3a3 <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x35a, 0x3a3, x86_l_3a3);
x86_l_35c:
	/* 0x35c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35f:
	/* 0x35f: jns    3ad <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x35f, 0x3ad, x86_l_3ad);
x86_l_361:
	/* 0x361: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_363:
	/* 0x363: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_366:
	/* 0x366: jb     384 <filter_char_buf_equal+0x2cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x366, 0x384, x86_l_384);
x86_l_368:
	/* 0x368: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_36a:
	/* 0x36a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36c:
	/* 0x36c: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_36f:
	/* 0x36f: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_373:
	/* 0x373: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_377:
	/* 0x377: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37b:
	/* 0x37b: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_37f:
	/* 0x37f: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_382:
	/* 0x382: jbe    36c <filter_char_buf_equal+0x2b5> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x382, 0x36c, x86_l_36c);
x86_l_384:
	/* 0x384: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_388:
	/* 0x388: jne    566 <filter_char_buf_equal+0x4af> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x388, 0x566, x86_l_566);
x86_l_38e:
	/* 0x38e: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_392:
	/* 0x392: jne    57b <filter_char_buf_equal+0x4c4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x392, 0x57b, x86_l_57b);
x86_l_398:
	/* 0x398: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_39c:
	/* 0x39c: je     3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x39c, 0x3b6, x86_l_3b6);
x86_l_39e:
	/* 0x39e: jmp    592 <filter_char_buf_equal+0x4db> */
	X86_SIM_X86_SUB_JMP(0x39e, 0x592, x86_l_592);
x86_l_3a3:
	/* 0x3a3: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a6:
	/* 0x3a6: call   24ae <filter_32ty_map+0x1deb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3ab:
	/* 0x3ab: jmp    3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x3ab, 0x3b6, x86_l_3b6);
x86_l_3ad:
	/* 0x3ad: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_3af:
	/* 0x3af: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b1:
	/* 0x3b1: call   24b9 <filter_32ty_map+0x1df6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_3b6:
	/* 0x3b6: mov    DWORD PTR [rsp+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3bb:
	/* 0x3bb: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3be:
	/* 0x3be: jle    3e8 <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x3be, 0x3e8, x86_l_3e8);
x86_l_3c0:
	/* 0x3c0: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_3c3:
	/* 0x3c3: jg     409 <filter_char_buf_equal+0x352> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x3c3, 0x409, x86_l_409);
x86_l_3c5:
	/* 0x3c5: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3c8:
	/* 0x3c8: je     464 <filter_char_buf_equal+0x3ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3c8, 0x464, x86_l_464);
x86_l_3ce:
	/* 0x3ce: cmp    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_3d1:
	/* 0x3d1: je     449 <filter_char_buf_equal+0x392> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d1, 0x449, x86_l_449);
x86_l_3d3:
	/* 0x3d3: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_3d6:
	/* 0x3d6: jne    498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3d6, 0x498, x86_l_498);
x86_l_3dc:
	/* 0x3dc: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_7));
x86_l_3e3:
	/* 0x3e3: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x3e3, 0x474, x86_l_474);
x86_l_3e8:
	/* 0x3e8: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3eb:
	/* 0x3eb: jle    425 <filter_char_buf_equal+0x36e> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x3eb, 0x425, x86_l_425);
x86_l_3ed:
	/* 0x3ed: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3f0:
	/* 0x3f0: je     45b <filter_char_buf_equal+0x3a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3f0, 0x45b, x86_l_45b);
x86_l_3f2:
	/* 0x3f2: cmp    ebp,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_3f5:
	/* 0x3f5: je     440 <filter_char_buf_equal+0x389> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3f5, 0x440, x86_l_440);
x86_l_3f7:
	/* 0x3f7: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3fa:
	/* 0x3fa: jne    498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3fa, 0x498, x86_l_498);
x86_l_400:
	/* 0x400: mov    rdi,QWORD PTR [rip+0x2103] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_4));
x86_l_407:
	/* 0x407: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x407, 0x474, x86_l_474);
x86_l_409:
	/* 0x409: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_40c:
	/* 0x40c: je     46d <filter_char_buf_equal+0x3b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x40c, 0x46d, x86_l_46d);
x86_l_40e:
	/* 0x40e: cmp    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_411:
	/* 0x411: je     452 <filter_char_buf_equal+0x39b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x411, 0x452, x86_l_452);
x86_l_413:
	/* 0x413: cmp    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_416:
	/* 0x416: jne    498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x416, 0x498, x86_l_498);
x86_l_41c:
	/* 0x41c: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_10));
x86_l_423:
	/* 0x423: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x423, 0x474, x86_l_474);
x86_l_425:
	/* 0x425: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_427:
	/* 0x427: je     437 <filter_char_buf_equal+0x380> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x427, 0x437, x86_l_437);
x86_l_429:
	/* 0x429: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_42c:
	/* 0x42c: jne    498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x42c, 0x498, x86_l_498);
x86_l_42e:
	/* 0x42e: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_1));
x86_l_435:
	/* 0x435: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x435, 0x474, x86_l_474);
x86_l_437:
	/* 0x437: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_0));
x86_l_43e:
	/* 0x43e: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x43e, 0x474, x86_l_474);
x86_l_440:
	/* 0x440: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_3));
x86_l_447:
	/* 0x447: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x447, 0x474, x86_l_474);
x86_l_449:
	/* 0x449: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_6));
x86_l_450:
	/* 0x450: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x450, 0x474, x86_l_474);
x86_l_452:
	/* 0x452: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_9));
x86_l_459:
	/* 0x459: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x459, 0x474, x86_l_474);
x86_l_45b:
	/* 0x45b: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_2));
x86_l_462:
	/* 0x462: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x462, 0x474, x86_l_474);
x86_l_464:
	/* 0x464: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_5));
x86_l_46b:
	/* 0x46b: jmp    474 <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x46b, 0x474, x86_l_474);
x86_l_46d:
	/* 0x46d: mov    rdi,QWORD PTR [rip+0x20ff] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_8));
x86_l_474:
	/* 0x474: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_479:
	/* 0x479: call   257d <filter_32ty_map+0x1eba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_47e:
	/* 0x47e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_481:
	/* 0x481: je     498 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x481, 0x498, x86_l_498);
x86_l_483:
	/* 0x483: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_486:
	/* 0x486: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_489:
	/* 0x489: call   258d <filter_32ty_map+0x1eca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_48e:
	/* 0x48e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_490:
	/* 0x490: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_493:
	/* 0x493: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_496:
	/* 0x496: jmp    49a <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JMP(0x496, 0x49a, x86_l_49a);
x86_l_498:
	/* 0x498: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49a:
	/* 0x49a: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_49d:
	/* 0x49d: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4a1:
	/* 0x4a1: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4a2:
	/* 0x4a2: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4a4:
	/* 0x4a4: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4a6:
	/* 0x4a6: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4a8:
	/* 0x4a8: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4aa:
	/* 0x4aa: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4ab:
	/* 0x4ab: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4ab);
x86_l_4ac:
	/* 0x4ac: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4af:
	/* 0x4af: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4b3:
	/* 0x4b3: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4b7:
	/* 0x4b7: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_4ba:
	/* 0x4ba: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_4be:
	/* 0x4be: je     25d <filter_char_buf_equal+0x1a6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4be, 0x25d, x86_l_25d);
x86_l_4c4:
	/* 0x4c4: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4c7:
	/* 0x4c7: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_4cc:
	/* 0x4cc: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4d1:
	/* 0x4d1: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_4d4:
	/* 0x4d4: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4d8:
	/* 0x4d8: je     2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d8, 0x2dd, x86_l_2dd);
x86_l_4de:
	/* 0x4de: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4e0:
	/* 0x4e0: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_4e4:
	/* 0x4e4: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4e7:
	/* 0x4e7: jmp    2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x4e7, 0x2dd, x86_l_2dd);
x86_l_4ec:
	/* 0x4ec: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4ef:
	/* 0x4ef: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4f3:
	/* 0x4f3: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4f7:
	/* 0x4f7: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_4fa:
	/* 0x4fa: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_4fe:
	/* 0x4fe: je     2b3 <filter_char_buf_equal+0x1fc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4fe, 0x2b3, x86_l_2b3);
x86_l_504:
	/* 0x504: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_507:
	/* 0x507: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_50c:
	/* 0x50c: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_511:
	/* 0x511: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_514:
	/* 0x514: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_518:
	/* 0x518: je     2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x518, 0x2dd, x86_l_2dd);
x86_l_51e:
	/* 0x51e: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_520:
	/* 0x520: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_524:
	/* 0x524: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_527:
	/* 0x527: jmp    2dd <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x527, 0x2dd, x86_l_2dd);
x86_l_52c:
	/* 0x52c: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_52e:
	/* 0x52e: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_531:
	/* 0x531: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_534:
	/* 0x534: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_537:
	/* 0x537: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_53b:
	/* 0x53b: je     348 <filter_char_buf_equal+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x53b, 0x348, x86_l_348);
x86_l_541:
	/* 0x541: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_543:
	/* 0x543: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_547:
	/* 0x547: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_54b:
	/* 0x54b: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_54e:
	/* 0x54e: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_552:
	/* 0x552: je     3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x552, 0x3b6, x86_l_3b6);
x86_l_558:
	/* 0x558: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_55a:
	/* 0x55a: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_55e:
	/* 0x55e: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_561:
	/* 0x561: jmp    3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x561, 0x3b6, x86_l_3b6);
x86_l_566:
	/* 0x566: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_568:
	/* 0x568: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_56b:
	/* 0x56b: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_56e:
	/* 0x56e: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_571:
	/* 0x571: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_575:
	/* 0x575: je     398 <filter_char_buf_equal+0x2e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x575, 0x398, x86_l_398);
x86_l_57b:
	/* 0x57b: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_57d:
	/* 0x57d: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_581:
	/* 0x581: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_585:
	/* 0x585: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_588:
	/* 0x588: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_58c:
	/* 0x58c: je     3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x58c, 0x3b6, x86_l_3b6);
x86_l_592:
	/* 0x592: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_594:
	/* 0x594: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_598:
	/* 0x598: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_59b:
	/* 0x59b: jmp    3b6 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x59b, 0x3b6, x86_l_3b6);

	/* native subroutine native_link_sub_5a0 */
x86_l_5a0:
	/* 0x5a0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5a1:
	/* 0x5a1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5a3:
	/* 0x5a3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5a5:
	/* 0x5a5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5a6:
	/* 0x5a6: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a7:
	/* 0x5a7: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_5a9:
	/* 0x5a9: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5ac:
	/* 0x5ac: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5b0:
	/* 0x5b0: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b7:
	/* 0x5b7: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps));
x86_l_5be:
	/* 0x5be: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5c3:
	/* 0x5c3: call   2bb8 <filter_32ty_map+0x24f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c8:
	/* 0x5c8: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5cb:
	/* 0x5cb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5cd:
	/* 0x5cd: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_5cf:
	/* 0x5cf: je     6b8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5cf, 0x6b8, x86_l_6b8);
x86_l_5d5:
	/* 0x5d5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5d8:
	/* 0x5d8: je     6b8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5d8, 0x6b8, x86_l_6b8);
x86_l_5de:
	/* 0x5de: mov    rdi,QWORD PTR [rip+0x25f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_5e5:
	/* 0x5e5: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_5e8:
	/* 0x5e8: call   2bdd <filter_32ty_map+0x251a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5ed:
	/* 0x5ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f0:
	/* 0x5f0: je     653 <filter_char_buf_prefix+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5f0, 0x653, x86_l_653);
x86_l_5f2:
	/* 0x5f2: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f5:
	/* 0x5f5: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_5f7:
	/* 0x5f7: cmp    ebp,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_5fd:
	/* 0x5fd: jb     604 <filter_char_buf_prefix+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x5fd, 0x604, x86_l_604);
x86_l_5ff:
	/* 0x5ff: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_604:
	/* 0x604: lea    ecx,[rsi*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_60b:
	/* 0x60b: mov    DWORD PTR [r15],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60e:
	/* 0x60e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_612:
	/* 0x612: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_615:
	/* 0x615: jns    657 <filter_char_buf_prefix+0xb7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x615, 0x657, x86_l_657);
x86_l_617:
	/* 0x617: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_61a:
	/* 0x61a: jns    664 <filter_char_buf_prefix+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x61a, 0x664, x86_l_664);
x86_l_61c:
	/* 0x61c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_61e:
	/* 0x61e: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_621:
	/* 0x621: jb     63f <filter_char_buf_prefix+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x621, 0x63f, x86_l_63f);
x86_l_623:
	/* 0x623: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_625:
	/* 0x625: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_627:
	/* 0x627: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_62a:
	/* 0x62a: mov    rcx,QWORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_62e:
	/* 0x62e: mov    QWORD PTR [rax+rdi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_632:
	/* 0x632: lea    rcx,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_636:
	/* 0x636: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_63a:
	/* 0x63a: cmp    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_63d:
	/* 0x63d: jbe    627 <filter_char_buf_prefix+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x63d, 0x627, x86_l_627);
x86_l_63f:
	/* 0x63f: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_643:
	/* 0x643: jne    672 <filter_char_buf_prefix+0xd2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x643, 0x672, x86_l_672);
x86_l_645:
	/* 0x645: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_649:
	/* 0x649: jne    684 <filter_char_buf_prefix+0xe4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x649, 0x684, x86_l_684);
x86_l_64b:
	/* 0x64b: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_64f:
	/* 0x64f: jne    698 <filter_char_buf_prefix+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x64f, 0x698, x86_l_698);
x86_l_651:
	/* 0x651: jmp    6a2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x651, 0x6a2, x86_l_6a2);
x86_l_653:
	/* 0x653: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_655:
	/* 0x655: jmp    6b8 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JMP(0x655, 0x6b8, x86_l_6b8);
x86_l_657:
	/* 0x657: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65a:
	/* 0x65a: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_65d:
	/* 0x65d: call   2c5b <filter_32ty_map+0x2598> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_662:
	/* 0x662: jmp    6a2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x662, 0x6a2, x86_l_6a2);
x86_l_664:
	/* 0x664: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_666:
	/* 0x666: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_669:
	/* 0x669: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_66b:
	/* 0x66b: call   2c69 <filter_32ty_map+0x25a6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_670:
	/* 0x670: jmp    6a2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x670, 0x6a2, x86_l_6a2);
x86_l_672:
	/* 0x672: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_674:
	/* 0x674: mov    edi,DWORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_678:
	/* 0x678: mov    DWORD PTR [rax+rdx*1],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_67b:
	/* 0x67b: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_67e:
	/* 0x67e: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_682:
	/* 0x682: je     64b <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x682, 0x64b, x86_l_64b);
x86_l_684:
	/* 0x684: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_686:
	/* 0x686: movzx  edi,WORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_68b:
	/* 0x68b: mov    WORD PTR [rax+rdx*1],di */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_68f:
	/* 0x68f: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_692:
	/* 0x692: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_696:
	/* 0x696: je     6a2 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x696, 0x6a2, x86_l_6a2);
x86_l_698:
	/* 0x698: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_69a:
	/* 0x69a: movzx  edx,BYTE PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_69f:
	/* 0x69f: mov    BYTE PTR [rax+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_6a2:
	/* 0x6a2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6a5:
	/* 0x6a5: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6a8:
	/* 0x6a8: call   2ca6 <filter_32ty_map+0x25e3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6ad:
	/* 0x6ad: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b0:
	/* 0x6b0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b2:
	/* 0x6b2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6b5:
	/* 0x6b5: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_6b8:
	/* 0x6b8: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_6bc:
	/* 0x6bc: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6bd:
	/* 0x6bd: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6bf:
	/* 0x6bf: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6c1:
	/* 0x6c1: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6c2:
	/* 0x6c2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_6c2);

	/* native subroutine native_link_sub_6c3 */
x86_l_6c3:
	/* 0x6c3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_6c5:
	/* 0x6c5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6c6:
	/* 0x6c6: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_6ca:
	/* 0x6ca: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_6cd:
	/* 0x6cd: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_6d0:
	/* 0x6d0: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_6d4:
	/* 0x6d4: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6d8:
	/* 0x6d8: mov    rdi,QWORD PTR [rip+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_6df:
	/* 0x6df: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6e4:
	/* 0x6e4: call   1739 <filter_32ty_map+0x1076> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6e9:
	/* 0x6e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ec:
	/* 0x6ec: je     71f <filter_32ty_map+0x5c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6ec, 0x71f, x86_l_71f);
x86_l_6ee:
	/* 0x6ee: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f1:
	/* 0x6f1: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6f6:
	/* 0x6f6: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6fb:
	/* 0x6fb: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6fe:
	/* 0x6fe: call   1753 <filter_32ty_map+0x1090> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_703:
	/* 0x703: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_706:
	/* 0x706: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_708:
	/* 0x708: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_70b:
	/* 0x70b: ja     739 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x70b, 0x739, x86_l_739);
x86_l_70d:
	/* 0x70d: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_712:
	/* 0x712: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_715:
	/* 0x715: jae    729 <filter_32ty_map+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x715, 0x729, x86_l_729);
x86_l_717:
	/* 0x717: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_71a:
	/* 0x71a: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_71d:
	/* 0x71d: jmp    739 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JMP(0x71d, 0x739, x86_l_739);
x86_l_71f:
	/* 0x71f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_721:
	/* 0x721: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_725:
	/* 0x725: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_726:
	/* 0x726: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_728:
	/* 0x728: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_728);
x86_l_729:
	/* 0x729: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_72e:
	/* 0x72e: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_731:
	/* 0x731: jae    739 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x731, 0x739, x86_l_739);
x86_l_733:
	/* 0x733: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_736:
	/* 0x736: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_739:
	/* 0x739: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_73c:
	/* 0x73c: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_740:
	/* 0x740: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_741:
	/* 0x741: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_743:
	/* 0x743: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_728);

x86_sim_ret_dispatch_4ab:
	switch (__x86_sim_ret_addr) {
	case 0x2dULL: goto x86_l_2d;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_6c2:
	switch (__x86_sim_ret_addr) {
	case 0x75ULL: goto x86_l_75;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_728:
	switch (__x86_sim_ret_addr) {
	case 0xadULL: goto x86_l_ad;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
