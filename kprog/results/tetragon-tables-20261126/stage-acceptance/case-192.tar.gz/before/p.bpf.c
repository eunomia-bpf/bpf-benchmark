#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2)
#include "../x86_sim_local_bpf.h"

extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 signal_data_map[] __ksym;
extern __u8 signals[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/cgroup_rmdir_signal")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: sub    rsp,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 32ULL);
x86_l_d:
	/* 0xd: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: mov    DWORD PTR [rsp+0x1c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_18:
	/* 0x18: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_1f:
	/* 0x1f: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24:
	/* 0x24: call   29 <cgroup_rmdir_signal+0x29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_29:
	/* 0x29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c:
	/* 0x2c: je     2f1 <cgroup_rmdir_signal+0x2f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c, 0x2f1, x86_l_2f1);
x86_l_32:
	/* 0x32: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35:
	/* 0x35: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3d:
	/* 0x3d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signal_data_map));
x86_l_44:
	/* 0x44: lea    r12,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49:
	/* 0x49: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4c:
	/* 0x4c: call   51 <cgroup_rmdir_signal+0x51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_51:
	/* 0x51: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54:
	/* 0x54: je     2f1 <cgroup_rmdir_signal+0x2f1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54, 0x2f1, x86_l_2f1);
x86_l_5a:
	/* 0x5a: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5d:
	/* 0x5d: mov    DWORD PTR [rax],0x1389 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5001ULL);
x86_l_63:
	/* 0x63: mov    BYTE PTR [rax+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_67:
	/* 0x67: mov    WORD PTR [rax+0x7d06],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 137464723275776ULL);
x86_l_70:
	/* 0x70: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_73:
	/* 0x73: mov    r15,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_77:
	/* 0x77: lea    rdx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7b:
	/* 0x7b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d:
	/* 0x7d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_80:
	/* 0x80: jns    8c <cgroup_rmdir_signal+0x8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x80, 0x8c, x86_l_8c);
x86_l_82:
	/* 0x82: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85:
	/* 0x85: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_88:
	/* 0x88: js     93 <cgroup_rmdir_signal+0x93> */
	X86_SIM_X86_JCC(X86_CC_S, 0x88, 0x93, x86_l_93);
x86_l_8a:
	/* 0x8a: jmp    95 <cgroup_rmdir_signal+0x95> */
	X86_SIM_X86_JMP(0x8a, 0x95, x86_l_95);
x86_l_8c:
	/* 0x8c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8e:
	/* 0x8e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_91:
	/* 0x91: jns    95 <cgroup_rmdir_signal+0x95> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x91, 0x95, x86_l_95);
x86_l_93:
	/* 0x93: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95:
	/* 0x95: mov    DWORD PTR [rsp+0xc],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_99:
	/* 0x99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c:
	/* 0x9c: jns    c4 <cgroup_rmdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9c, 0xc4, x86_l_c4);
x86_l_9e:
	/* 0x9e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a1:
	/* 0xa1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a4:
	/* 0xa4: je     c4 <cgroup_rmdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa4, 0xc4, x86_l_c4);
x86_l_a6:
	/* 0xa6: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_aa:
	/* 0xaa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad:
	/* 0xad: jns    c4 <cgroup_rmdir_signal+0xc4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xad, 0xc4, x86_l_c4);
x86_l_af:
	/* 0xaf: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b2:
	/* 0xb2: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b7:
	/* 0xb7: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_bb:
	/* 0xbb: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_c0:
	/* 0xc0: jne    d6 <cgroup_rmdir_signal+0xd6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc0, 0xd6, x86_l_d6);
x86_l_c2:
	/* 0xc2: jmp    e0 <cgroup_rmdir_signal+0xe0> */
	X86_SIM_X86_JMP(0xc2, 0xe0, x86_l_e0);
x86_l_c4:
	/* 0xc4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c6:
	/* 0xc6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cb:
	/* 0xcb: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_cf:
	/* 0xcf: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_d4:
	/* 0xd4: je     e0 <cgroup_rmdir_signal+0xe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd4, 0xe0, x86_l_e0);
x86_l_d6:
	/* 0xd6: mov    eax,DWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da:
	/* 0xda: cmp    eax,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 12ULL);
x86_l_de:
	/* 0xde: jne    f1 <cgroup_rmdir_signal+0xf1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xde, 0xf1, x86_l_f1);
x86_l_e0:
	/* 0xe0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_e7:
	/* 0xe7: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ec:
	/* 0xec: call   f1 <cgroup_rmdir_signal+0xf1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_f1:
	/* 0xf1: movzx  r13d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_f9:
	/* 0xf9: cmp    r13,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_100:
	/* 0x100: ja     25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x100, 0x25e, x86_l_25e);
x86_l_106:
	/* 0x106: mov    BYTE PTR [r14+r13*1+0x5],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R13, 0), 21474836480ULL);
x86_l_10c:
	/* 0x10c: cmp    r13d,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_113:
	/* 0x113: jbe    12d <cgroup_rmdir_signal+0x12d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x113, 0x12d, x86_l_12d);
x86_l_115:
	/* 0x115: movzx  r13d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_11d:
	/* 0x11d: movzx  eax,r13w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_R13, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_121:
	/* 0x121: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_126:
	/* 0x126: jbe    183 <cgroup_rmdir_signal+0x183> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x126, 0x183, x86_l_183);
x86_l_128:
	/* 0x128: jmp    25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JMP(0x128, 0x25e, x86_l_25e);
x86_l_12d:
	/* 0x12d: lea    rdi,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_131:
	/* 0x131: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_135:
	/* 0x135: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_138:
	/* 0x138: jns    150 <cgroup_rmdir_signal+0x150> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138, 0x150, x86_l_150);
x86_l_13a:
	/* 0x13a: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13f:
	/* 0x13f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_142:
	/* 0x142: jns    1fd <cgroup_rmdir_signal+0x1fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x142, 0x1fd, x86_l_1fd);
x86_l_148:
	/* 0x148: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14b:
	/* 0x14b: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14e:
	/* 0x14e: jmp    164 <cgroup_rmdir_signal+0x164> */
	X86_SIM_X86_JMP(0x14e, 0x164, x86_l_164);
x86_l_150:
	/* 0x150: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_155:
	/* 0x155: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_15a:
	/* 0x15a: call   15f <cgroup_rmdir_signal+0x15f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15f:
	/* 0x15f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_162:
	/* 0x162: js     115 <cgroup_rmdir_signal+0x115> */
	X86_SIM_X86_JCC(X86_CC_S, 0x162, 0x115, x86_l_115);
x86_l_164:
	/* 0x164: add    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_168:
	/* 0x168: mov    WORD PTR [r14+0x7d06],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_170:
	/* 0x170: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_174:
	/* 0x174: movzx  eax,r13w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_R13, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_178:
	/* 0x178: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_17d:
	/* 0x17d: ja     25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17d, 0x25e, x86_l_25e);
x86_l_183:
	/* 0x183: mov    BYTE PTR [r14+rax*1+0x5],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 21474836481ULL);
x86_l_189:
	/* 0x189: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_191:
	/* 0x191: mov    WORD PTR [r14+0x7d0a],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32010ULL);
x86_l_199:
	/* 0x199: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_19f:
	/* 0x19f: ja     25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x19f, 0x25e, x86_l_25e);
x86_l_1a5:
	/* 0x1a5: lea    rdi,[rax+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1a9:
	/* 0x1a9: add    rdi,0xa */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 10ULL);
x86_l_1ad:
	/* 0x1ad: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1b0:
	/* 0x1b0: js     209 <cgroup_rmdir_signal+0x209> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b0, 0x209, x86_l_209);
x86_l_1b2:
	/* 0x1b2: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1b7:
	/* 0x1b7: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ba:
	/* 0x1ba: call   1bf <cgroup_rmdir_signal+0x1bf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1bf:
	/* 0x1bf: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c2:
	/* 0x1c2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c4:
	/* 0x1c4: jle    25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1c4, 0x25e, x86_l_25e);
x86_l_1ca:
	/* 0x1ca: movzx  edx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_1d2:
	/* 0x1d2: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1d9:
	/* 0x1d9: ja     25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d9, 0x25e, x86_l_25e);
x86_l_1df:
	/* 0x1df: mov    DWORD PTR [rdx+r14*1+0x6],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 6ULL);
x86_l_1e4:
	/* 0x1e4: add    cx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32006ULL);
x86_l_1ec:
	/* 0x1ec: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1ef:
	/* 0x1ef: mov    WORD PTR [r14+0x7d06],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_1f7:
	/* 0x1f7: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_1fb:
	/* 0x1fb: jmp    25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JMP(0x1fb, 0x25e, x86_l_25e);
x86_l_1fd:
	/* 0x1fd: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_204:
	/* 0x204: jmp    115 <cgroup_rmdir_signal+0x115> */
	X86_SIM_X86_JMP(0x204, 0x115, x86_l_115);
x86_l_209:
	/* 0x209: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_20c:
	/* 0x20c: jns    22e <cgroup_rmdir_signal+0x22e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20c, 0x22e, x86_l_22e);
x86_l_20e:
	/* 0x20e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210:
	/* 0x210: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_217:
	/* 0x217: je     23c <cgroup_rmdir_signal+0x23c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x217, 0x23c, x86_l_23c);
x86_l_219:
	/* 0x219: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_21d:
	/* 0x21d: movzx  edx,BYTE PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_222:
	/* 0x222: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_225:
	/* 0x225: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_22a:
	/* 0x22a: jne    210 <cgroup_rmdir_signal+0x210> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22a, 0x210, x86_l_210);
x86_l_22c:
	/* 0x22c: jmp    1bf <cgroup_rmdir_signal+0x1bf> */
	X86_SIM_X86_JMP(0x22c, 0x1bf, x86_l_1bf);
x86_l_22e:
	/* 0x22e: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_233:
	/* 0x233: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_235:
	/* 0x235: call   23a <cgroup_rmdir_signal+0x23a> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_23a:
	/* 0x23a: jmp    25e <cgroup_rmdir_signal+0x25e> */
	X86_SIM_X86_JMP(0x23a, 0x25e, x86_l_25e);
x86_l_23c:
	/* 0x23c: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_243:
	/* 0x243: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_248:
	/* 0x248: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_24d:
	/* 0x24d: movzx  edx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_255:
	/* 0x255: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_25c:
	/* 0x25c: jbe    1df <cgroup_rmdir_signal+0x1df> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x25c, 0x1df, x86_l_1df);
x86_l_25e:
	/* 0x25e: movzx  r15d,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_266:
	/* 0x266: cmp    r15,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_26d:
	/* 0x26d: ja     2bf <cgroup_rmdir_signal+0x2bf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x26d, 0x2bf, x86_l_2bf);
x86_l_26f:
	/* 0x26f: mov    BYTE PTR [r14+r15*1+0x5],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 21474836482ULL);
x86_l_275:
	/* 0x275: cmp    r15d,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_27c:
	/* 0x27c: ja     2bf <cgroup_rmdir_signal+0x2bf> */
	X86_SIM_X86_JCC(X86_CC_A, 0x27c, 0x2bf, x86_l_2bf);
x86_l_27e:
	/* 0x27e: lea    rdi,[r15+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_282:
	/* 0x282: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_286:
	/* 0x286: lea    rax,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_28b:
	/* 0x28b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28e:
	/* 0x28e: jns    29b <cgroup_rmdir_signal+0x29b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28e, 0x29b, x86_l_29b);
x86_l_290:
	/* 0x290: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_293:
	/* 0x293: jns    305 <cgroup_rmdir_signal+0x305> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x293, 0x305, x86_l_305);
x86_l_295:
	/* 0x295: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297:
	/* 0x297: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_299:
	/* 0x299: jmp    2af <cgroup_rmdir_signal+0x2af> */
	X86_SIM_X86_JMP(0x299, 0x2af, x86_l_2af);
x86_l_29b:
	/* 0x29b: lea    rdx,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2a0:
	/* 0x2a0: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2a5:
	/* 0x2a5: call   2aa <cgroup_rmdir_signal+0x2aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2aa:
	/* 0x2aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ad:
	/* 0x2ad: js     2bf <cgroup_rmdir_signal+0x2bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ad, 0x2bf, x86_l_2bf);
x86_l_2af:
	/* 0x2af: add    r15d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2b3:
	/* 0x2b3: mov    WORD PTR [r14+0x7d06],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_2bb:
	/* 0x2bb: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_2bf:
	/* 0x2bf: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_2c7:
	/* 0x2c7: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2cc:
	/* 0x2cc: jb     2d3 <cgroup_rmdir_signal+0x2d3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2cc, 0x2d3, x86_l_2d3);
x86_l_2ce:
	/* 0x2ce: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2d3:
	/* 0x2d3: add    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2d6:
	/* 0x2d6: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2da:
	/* 0x2da: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signals));
x86_l_2e1:
	/* 0x2e1: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2e6:
	/* 0x2e6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2e9:
	/* 0x2e9: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2ec:
	/* 0x2ec: call   2f1 <cgroup_rmdir_signal+0x2f1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2f1:
	/* 0x2f1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f3:
	/* 0x2f3: add    rsp,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2f7:
	/* 0x2f7: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2f8:
	/* 0x2f8: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fa:
	/* 0x2fa: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fc:
	/* 0x2fc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fe:
	/* 0x2fe: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_300:
	/* 0x300: jmp    31c <cgroup_rmdir_signal+0x31c> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_305:
	/* 0x305: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30b:
	/* 0x30b: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_313:
	/* 0x313: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_318:
	/* 0x318: jae    2ce <cgroup_rmdir_signal+0x2ce> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x318, 0x2ce, x86_l_2ce);
x86_l_31a:
	/* 0x31a: jmp    2d3 <cgroup_rmdir_signal+0x2d3> */
	X86_SIM_X86_JMP(0x31a, 0x2d3, x86_l_2d3);
x86_l_31c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
