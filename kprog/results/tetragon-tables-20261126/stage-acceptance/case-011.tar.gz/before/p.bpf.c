#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 216U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9)
#include "../x86_sim_local_bpf.h"

extern __u8 birth[] __ksym;
extern __u8 events[] __ksym;
extern __u8 idents[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MULX, X86_OP_MULX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tracepoint/sock/inet_sock_set_state")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_1c:
	/* 0x1c: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_28:
	/* 0x28: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_31:
	/* 0x31: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_3a:
	/* 0x3a: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_43:
	/* 0x43: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_4c:
	/* 0x4c: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_55:
	/* 0x55: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_5e:
	/* 0x5e: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_67:
	/* 0x67: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_70:
	/* 0x70: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_79:
	/* 0x79: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_82:
	/* 0x82: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_8b:
	/* 0x8b: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_94:
	/* 0x94: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_9d:
	/* 0x9d: lea    rax,[rdi+0x1e] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_a1:
	/* 0xa1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a4:
	/* 0xa4: jns    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa4, 0x5de, x86_l_5de);
x86_l_aa:
	/* 0xaa: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_ad:
	/* 0xad: cmp    ax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 6ULL);
x86_l_b1:
	/* 0xb1: jne    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb1, 0x5de, x86_l_5de);
x86_l_b7:
	/* 0xb7: lea    rax,[rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_bb:
	/* 0xbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be:
	/* 0xbe: jns    d2 <inet_sock_set_state+0xd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbe, 0xd2, x86_l_d2);
x86_l_c0:
	/* 0xc0: movzx  ebp,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_c3:
	/* 0xc3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_family));
x86_l_ca:
	/* 0xca: cmp    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce:
	/* 0xce: jne    e1 <inet_sock_set_state+0xe1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xce, 0xe1, x86_l_e1);
x86_l_d0:
	/* 0xd0: jmp    ea <inet_sock_set_state+0xea> */
	X86_SIM_X86_JMP(0xd0, 0xea, x86_l_ea);
x86_l_d2:
	/* 0xd2: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d4:
	/* 0xd4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_family));
x86_l_db:
	/* 0xdb: cmp    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_df:
	/* 0xdf: je     ea <inet_sock_set_state+0xea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf, 0xea, x86_l_ea);
x86_l_e1:
	/* 0xe1: cmp    bp,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_e4:
	/* 0xe4: jne    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe4, 0x5de, x86_l_5de);
x86_l_ea:
	/* 0xea: lea    rax,[rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ee:
	/* 0xee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f1:
	/* 0xf1: jns    108 <inet_sock_set_state+0x108> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf1, 0x108, x86_l_108);
x86_l_f3:
	/* 0xf3: movzx  r14d,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_f7:
	/* 0xf7: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_sport));
x86_l_fe:
	/* 0xfe: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_101:
	/* 0x101: jne    11b <inet_sock_set_state+0x11b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x101, 0x11b, x86_l_11b);
x86_l_103:
	/* 0x103: jmp    1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JMP(0x103, 0x1df, x86_l_1df);
x86_l_108:
	/* 0x108: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b:
	/* 0x10b: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_sport));
x86_l_112:
	/* 0x112: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_115:
	/* 0x115: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x115, 0x1df, x86_l_1df);
x86_l_11b:
	/* 0x11b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11d:
	/* 0x11d: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_sports));
x86_l_124:
	/* 0x124: cmp    WORD PTR [rcx+rax*2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_129:
	/* 0x129: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x129, 0x5de, x86_l_5de);
x86_l_12f:
	/* 0x12f: cmp    r14w,WORD PTR [rcx+rax*2] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 0ULL);
x86_l_134:
	/* 0x134: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x134, 0x1df, x86_l_1df);
x86_l_13a:
	/* 0x13a: cmp    WORD PTR [rcx+rax*2+0x2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 8589934592ULL);
x86_l_140:
	/* 0x140: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x140, 0x5de, x86_l_5de);
x86_l_146:
	/* 0x146: cmp    r14w,WORD PTR [rcx+rax*2+0x2] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 2ULL);
x86_l_14c:
	/* 0x14c: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14c, 0x1df, x86_l_1df);
x86_l_152:
	/* 0x152: cmp    WORD PTR [rcx+rax*2+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 17179869184ULL);
x86_l_158:
	/* 0x158: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x158, 0x5de, x86_l_5de);
x86_l_15e:
	/* 0x15e: cmp    r14w,WORD PTR [rcx+rax*2+0x4] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 4ULL);
x86_l_164:
	/* 0x164: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x164, 0x1df, x86_l_1df);
x86_l_166:
	/* 0x166: cmp    WORD PTR [rcx+rax*2+0x6],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 25769803776ULL);
x86_l_16c:
	/* 0x16c: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16c, 0x5de, x86_l_5de);
x86_l_172:
	/* 0x172: cmp    r14w,WORD PTR [rcx+rax*2+0x6] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 6ULL);
x86_l_178:
	/* 0x178: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x178, 0x1df, x86_l_1df);
x86_l_17a:
	/* 0x17a: cmp    WORD PTR [rcx+rax*2+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 34359738368ULL);
x86_l_180:
	/* 0x180: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x180, 0x5de, x86_l_5de);
x86_l_186:
	/* 0x186: cmp    r14w,WORD PTR [rcx+rax*2+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 8ULL);
x86_l_18c:
	/* 0x18c: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18c, 0x1df, x86_l_1df);
x86_l_18e:
	/* 0x18e: cmp    WORD PTR [rcx+rax*2+0xa],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 42949672960ULL);
x86_l_194:
	/* 0x194: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194, 0x5de, x86_l_5de);
x86_l_19a:
	/* 0x19a: cmp    r14w,WORD PTR [rcx+rax*2+0xa] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 10ULL);
x86_l_1a0:
	/* 0x1a0: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0, 0x1df, x86_l_1df);
x86_l_1a2:
	/* 0x1a2: cmp    WORD PTR [rcx+rax*2+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 51539607552ULL);
x86_l_1a8:
	/* 0x1a8: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8, 0x5de, x86_l_5de);
x86_l_1ae:
	/* 0x1ae: cmp    r14w,WORD PTR [rcx+rax*2+0xc] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 12ULL);
x86_l_1b4:
	/* 0x1b4: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b4, 0x1df, x86_l_1df);
x86_l_1b6:
	/* 0x1b6: cmp    WORD PTR [rcx+rax*2+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 60129542144ULL);
x86_l_1bc:
	/* 0x1bc: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc, 0x5de, x86_l_5de);
x86_l_1c2:
	/* 0x1c2: cmp    r14w,WORD PTR [rcx+rax*2+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 14ULL);
x86_l_1c8:
	/* 0x1c8: je     1df <inet_sock_set_state+0x1df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c8, 0x1df, x86_l_1df);
x86_l_1ca:
	/* 0x1ca: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1ce:
	/* 0x1ce: cmp    rax,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 1024ULL);
x86_l_1d4:
	/* 0x1d4: jne    124 <inet_sock_set_state+0x124> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d4, 0x124, x86_l_124);
x86_l_1da:
	/* 0x1da: jmp    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JMP(0x1da, 0x5de, x86_l_5de);
x86_l_1df:
	/* 0x1df: lea    rax,[rdi+0x1a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_1e3:
	/* 0x1e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e6:
	/* 0x1e6: jns    1fd <inet_sock_set_state+0x1fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e6, 0x1fd, x86_l_1fd);
x86_l_1e8:
	/* 0x1e8: movzx  r15d,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ec:
	/* 0x1ec: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_dport));
x86_l_1f3:
	/* 0x1f3: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f6:
	/* 0x1f6: jne    210 <inet_sock_set_state+0x210> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f6, 0x210, x86_l_210);
x86_l_1f8:
	/* 0x1f8: jmp    2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JMP(0x1f8, 0x2d4, x86_l_2d4);
x86_l_1fd:
	/* 0x1fd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_200:
	/* 0x200: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_dport));
x86_l_207:
	/* 0x207: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a:
	/* 0x20a: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a, 0x2d4, x86_l_2d4);
x86_l_210:
	/* 0x210: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212:
	/* 0x212: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_dports));
x86_l_219:
	/* 0x219: cmp    WORD PTR [rcx+rax*2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_21e:
	/* 0x21e: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e, 0x5de, x86_l_5de);
x86_l_224:
	/* 0x224: cmp    r15w,WORD PTR [rcx+rax*2] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 0ULL);
x86_l_229:
	/* 0x229: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x229, 0x2d4, x86_l_2d4);
x86_l_22f:
	/* 0x22f: cmp    WORD PTR [rcx+rax*2+0x2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 8589934592ULL);
x86_l_235:
	/* 0x235: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x235, 0x5de, x86_l_5de);
x86_l_23b:
	/* 0x23b: cmp    r15w,WORD PTR [rcx+rax*2+0x2] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 2ULL);
x86_l_241:
	/* 0x241: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x241, 0x2d4, x86_l_2d4);
x86_l_247:
	/* 0x247: cmp    WORD PTR [rcx+rax*2+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 17179869184ULL);
x86_l_24d:
	/* 0x24d: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d, 0x5de, x86_l_5de);
x86_l_253:
	/* 0x253: cmp    r15w,WORD PTR [rcx+rax*2+0x4] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 4ULL);
x86_l_259:
	/* 0x259: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259, 0x2d4, x86_l_2d4);
x86_l_25b:
	/* 0x25b: cmp    WORD PTR [rcx+rax*2+0x6],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 25769803776ULL);
x86_l_261:
	/* 0x261: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261, 0x5de, x86_l_5de);
x86_l_267:
	/* 0x267: cmp    r15w,WORD PTR [rcx+rax*2+0x6] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 6ULL);
x86_l_26d:
	/* 0x26d: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d, 0x2d4, x86_l_2d4);
x86_l_26f:
	/* 0x26f: cmp    WORD PTR [rcx+rax*2+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 34359738368ULL);
x86_l_275:
	/* 0x275: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275, 0x5de, x86_l_5de);
x86_l_27b:
	/* 0x27b: cmp    r15w,WORD PTR [rcx+rax*2+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 8ULL);
x86_l_281:
	/* 0x281: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281, 0x2d4, x86_l_2d4);
x86_l_283:
	/* 0x283: cmp    WORD PTR [rcx+rax*2+0xa],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 42949672960ULL);
x86_l_289:
	/* 0x289: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x289, 0x5de, x86_l_5de);
x86_l_28f:
	/* 0x28f: cmp    r15w,WORD PTR [rcx+rax*2+0xa] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 10ULL);
x86_l_295:
	/* 0x295: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x295, 0x2d4, x86_l_2d4);
x86_l_297:
	/* 0x297: cmp    WORD PTR [rcx+rax*2+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 51539607552ULL);
x86_l_29d:
	/* 0x29d: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29d, 0x5de, x86_l_5de);
x86_l_2a3:
	/* 0x2a3: cmp    r15w,WORD PTR [rcx+rax*2+0xc] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 12ULL);
x86_l_2a9:
	/* 0x2a9: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a9, 0x2d4, x86_l_2d4);
x86_l_2ab:
	/* 0x2ab: cmp    WORD PTR [rcx+rax*2+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 1), 60129542144ULL);
x86_l_2b1:
	/* 0x2b1: je     5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b1, 0x5de, x86_l_5de);
x86_l_2b7:
	/* 0x2b7: cmp    r15w,WORD PTR [rcx+rax*2+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_RAX, 1, X86_WIDTH_16), 14ULL);
x86_l_2bd:
	/* 0x2bd: je     2d4 <inet_sock_set_state+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bd, 0x2d4, x86_l_2d4);
x86_l_2bf:
	/* 0x2bf: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2c3:
	/* 0x2c3: cmp    rax,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 1024ULL);
x86_l_2c9:
	/* 0x2c9: jne    219 <inet_sock_set_state+0x219> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c9, 0x219, x86_l_219);
x86_l_2cf:
	/* 0x2cf: jmp    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JMP(0x2cf, 0x5de, x86_l_5de);
x86_l_2d4:
	/* 0x2d4: lea    rax,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d8:
	/* 0x2d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2db:
	/* 0x2db: jns    2e2 <inet_sock_set_state+0x2e2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2db, 0x2e2, x86_l_2e2);
x86_l_2dd:
	/* 0x2dd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e0:
	/* 0x2e0: jmp    2e4 <inet_sock_set_state+0x2e4> */
	X86_SIM_X86_JMP(0x2e0, 0x2e4, x86_l_2e4);
x86_l_2e2:
	/* 0x2e2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e4:
	/* 0x2e4: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e8:
	/* 0x2e8: lea    rbx,[rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2ec:
	/* 0x2ec: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2ef:
	/* 0x2ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f2:
	/* 0x2f2: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f5:
	/* 0x2f5: jns    2fe <inet_sock_set_state+0x2fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f5, 0x2fe, x86_l_2fe);
x86_l_2f7:
	/* 0x2f7: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f9:
	/* 0x2f9: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2fc:
	/* 0x2fc: jg     31e <inet_sock_set_state+0x31e> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2fc, 0x31e, x86_l_31e);
x86_l_2fe:
	/* 0x2fe: call   303 <inet_sock_set_state+0x303> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_303:
	/* 0x303: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_308:
	/* 0x308: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)birth));
x86_l_30f:
	/* 0x30f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_312:
	/* 0x312: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_317:
	/* 0x317: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_319:
	/* 0x319: call   31e <inet_sock_set_state+0x31e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_31e:
	/* 0x31e: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_321:
	/* 0x321: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_324:
	/* 0x324: jns    32d <inet_sock_set_state+0x32d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x324, 0x32d, x86_l_32d);
x86_l_326:
	/* 0x326: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_328:
	/* 0x328: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_32b:
	/* 0x32b: je     33c <inet_sock_set_state+0x33c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32b, 0x33c, x86_l_33c);
x86_l_32d:
	/* 0x32d: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_330:
	/* 0x330: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_333:
	/* 0x333: jns    384 <inet_sock_set_state+0x384> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x333, 0x384, x86_l_384);
x86_l_335:
	/* 0x335: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_337:
	/* 0x337: cmp    eax,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_33a:
	/* 0x33a: jne    384 <inet_sock_set_state+0x384> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33a, 0x384, x86_l_384);
x86_l_33c:
	/* 0x33c: call   341 <inet_sock_set_state+0x341> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_341:
	/* 0x341: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_345:
	/* 0x345: mov    rcx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_pid));
x86_l_34c:
	/* 0x34c: cmp    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34f:
	/* 0x34f: je     35b <inet_sock_set_state+0x35b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34f, 0x35b, x86_l_35b);
x86_l_351:
	/* 0x351: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_353:
	/* 0x353: cmp    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_355:
	/* 0x355: jne    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x355, 0x5de, x86_l_5de);
x86_l_35b:
	/* 0x35b: mov    DWORD PTR [rsp+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_35f:
	/* 0x35f: lea    rdi,[rsp+0x7c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_364:
	/* 0x364: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_369:
	/* 0x369: call   36e <inet_sock_set_state+0x36e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_36e:
	/* 0x36e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)idents));
x86_l_375:
	/* 0x375: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_378:
	/* 0x378: lea    rdx,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_37d:
	/* 0x37d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37f:
	/* 0x37f: call   384 <inet_sock_set_state+0x384> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_384:
	/* 0x384: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_387:
	/* 0x387: jns    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x387, 0x5de, x86_l_5de);
x86_l_38d:
	/* 0x38d: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38f:
	/* 0x38f: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_392:
	/* 0x392: jne    5de <inet_sock_set_state+0x5de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x392, 0x5de, x86_l_5de);
x86_l_398:
	/* 0x398: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)birth));
x86_l_39f:
	/* 0x39f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_3a2:
	/* 0x3a2: call   3a7 <inet_sock_set_state+0x3a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a7:
	/* 0x3a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3aa:
	/* 0x3aa: je     5cf <inet_sock_set_state+0x5cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3aa, 0x5cf, x86_l_5cf);
x86_l_3b0:
	/* 0x3b0: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b3:
	/* 0x3b3: call   3b8 <inet_sock_set_state+0x3b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_3b8:
	/* 0x3b8: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3bd:
	/* 0x3bd: sub    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 0ULL);
x86_l_3c0:
	/* 0x3c0: shr    rax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_3c4:
	/* 0x3c4: movabs r13,0x20c49ba5e353f7cf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 2361183241434822607ULL);
x86_l_3ce:
	/* 0x3ce: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d1:
	/* 0x3d1: mulx   rbx,rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RBX, X86_R13, X86_WIDTH_64, X86_RBX, 0);
x86_l_3d6:
	/* 0x3d6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)idents));
x86_l_3dd:
	/* 0x3dd: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_3e0:
	/* 0x3e0: call   3e5 <inet_sock_set_state+0x3e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e5:
	/* 0x3e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e8:
	/* 0x3e8: je     3ee <inet_sock_set_state+0x3ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e8, 0x3ee, x86_l_3ee);
x86_l_3ea:
	/* 0x3ea: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ec:
	/* 0x3ec: jmp    40a <inet_sock_set_state+0x40a> */
	X86_SIM_X86_JMP(0x3ec, 0x40a, x86_l_40a);
x86_l_3ee:
	/* 0x3ee: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f1:
	/* 0x3f1: call   3f6 <inet_sock_set_state+0x3f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_3f6:
	/* 0x3f6: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f9:
	/* 0x3f9: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3fc:
	/* 0x3fc: movabs r13,0x20c49ba5e353f7cf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 2361183241434822607ULL);
x86_l_406:
	/* 0x406: shr    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_40a:
	/* 0x40a: mov    rdx,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&target_pid));
x86_l_411:
	/* 0x411: cmp    DWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_414:
	/* 0x414: je     41e <inet_sock_set_state+0x41e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x414, 0x41e, x86_l_41e);
x86_l_416:
	/* 0x416: cmp    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_418:
	/* 0x418: jne    5c0 <inet_sock_set_state+0x5c0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x418, 0x5c0, x86_l_5c0);
x86_l_41e:
	/* 0x41e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_422:
	/* 0x422: lea    rsi,[rdx+0x710] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1808ULL);
x86_l_429:
	/* 0x429: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_42c:
	/* 0x42c: jns    433 <inet_sock_set_state+0x433> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x42c, 0x433, x86_l_433);
x86_l_42e:
	/* 0x42e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_431:
	/* 0x431: jmp    435 <inet_sock_set_state+0x435> */
	X86_SIM_X86_JMP(0x431, 0x435, x86_l_435);
x86_l_433:
	/* 0x433: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_435:
	/* 0x435: shr    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 4ULL);
x86_l_439:
	/* 0x439: add    rdx,0x758 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1880ULL);
x86_l_440:
	/* 0x440: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_443:
	/* 0x443: jns    44a <inet_sock_set_state+0x44a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x443, 0x44a, x86_l_44a);
x86_l_445:
	/* 0x445: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_448:
	/* 0x448: jmp    44c <inet_sock_set_state+0x44c> */
	X86_SIM_X86_JMP(0x448, 0x44c, x86_l_44c);
x86_l_44a:
	/* 0x44a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_44c:
	/* 0x44c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_451:
	/* 0x451: shr    rdx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_455:
	/* 0x455: mulx   rdx,rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RDX, X86_R13, X86_WIDTH_64, X86_RDX, 0);
x86_l_45a:
	/* 0x45a: shr    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 4ULL);
x86_l_45e:
	/* 0x45e: mov    QWORD PTR [rsp+0x30],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_463:
	/* 0x463: mov    QWORD PTR [rsp+0x38],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_468:
	/* 0x468: mov    QWORD PTR [rsp+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_46d:
	/* 0x46d: mov    QWORD PTR [rsp+0x48],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_472:
	/* 0x472: mov    DWORD PTR [rsp+0x50],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_476:
	/* 0x476: mov    WORD PTR [rsp+0x54],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_47c:
	/* 0x47c: mov    WORD PTR [rsp+0x56],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_482:
	/* 0x482: mov    WORD PTR [rsp+0x58],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_487:
	/* 0x487: lea    rdi,[rsp+0x5a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_48c:
	/* 0x48c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_48f:
	/* 0x48f: je     4ad <inet_sock_set_state+0x4ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48f, 0x4ad, x86_l_4ad);
x86_l_491:
	/* 0x491: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_495:
	/* 0x495: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_498:
	/* 0x498: jns    4b9 <inet_sock_set_state+0x4b9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x498, 0x4b9, x86_l_4b9);
x86_l_49a:
	/* 0x49a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_49d:
	/* 0x49d: mov    QWORD PTR [rsp+0x5a],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_4a2:
	/* 0x4a2: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4a6:
	/* 0x4a6: mov    QWORD PTR [rsp+0x62],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 98ULL);
x86_l_4ab:
	/* 0x4ab: jmp    4c8 <inet_sock_set_state+0x4c8> */
	X86_SIM_X86_JMP(0x4ab, 0x4c8, x86_l_4c8);
x86_l_4ad:
	/* 0x4ad: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4b2:
	/* 0x4b2: call   4b7 <inet_sock_set_state+0x4b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_4b7:
	/* 0x4b7: jmp    4c8 <inet_sock_set_state+0x4c8> */
	X86_SIM_X86_JMP(0x4b7, 0x4c8, x86_l_4c8);
x86_l_4b9:
	/* 0x4b9: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_4c1:
	/* 0x4c1: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c8:
	/* 0x4c8: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4cb:
	/* 0x4cb: cmp    bp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, 0, 2ULL);
x86_l_4cf:
	/* 0x4cf: jne    514 <inet_sock_set_state+0x514> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4cf, 0x514, x86_l_514);
x86_l_4d1:
	/* 0x4d1: lea    rax,[rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4d5:
	/* 0x4d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4d8:
	/* 0x4d8: jns    4dc <inet_sock_set_state+0x4dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4d8, 0x4dc, x86_l_4dc);
x86_l_4da:
	/* 0x4da: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4dc:
	/* 0x4dc: lea    rcx,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4e4:
	/* 0x4e4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e6:
	/* 0x4e6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4e9:
	/* 0x4e9: jns    4ed <inet_sock_set_state+0x4ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4e9, 0x4ed, x86_l_4ed);
x86_l_4eb:
	/* 0x4eb: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ed:
	/* 0x4ed: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4f1:
	/* 0x4f1: lea    rax,[rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4f5:
	/* 0x4f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f8:
	/* 0x4f8: jns    4fc <inet_sock_set_state+0x4fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4f8, 0x4fc, x86_l_4fc);
x86_l_4fa:
	/* 0x4fa: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fc:
	/* 0x4fc: lea    rax,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_504:
	/* 0x504: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_507:
	/* 0x507: jns    544 <inet_sock_set_state+0x544> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x507, 0x544, x86_l_544);
x86_l_509:
	/* 0x509: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50b:
	/* 0x50b: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_50f:
	/* 0x50f: jmp    5a4 <inet_sock_set_state+0x5a4> */
	X86_SIM_X86_JMP(0x50f, 0x5a4, x86_l_5a4);
x86_l_514:
	/* 0x514: lea    rax,[rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_518:
	/* 0x518: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51b:
	/* 0x51b: jns    524 <inet_sock_set_state+0x524> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x51b, 0x524, x86_l_524);
x86_l_51d:
	/* 0x51d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_520:
	/* 0x520: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_524:
	/* 0x524: lea    rax,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_52c:
	/* 0x52c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52f:
	/* 0x52f: jns    54e <inet_sock_set_state+0x54e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x52f, 0x54e, x86_l_54e);
x86_l_531:
	/* 0x531: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_534:
	/* 0x534: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_539:
	/* 0x539: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_53d:
	/* 0x53d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_542:
	/* 0x542: jmp    560 <inet_sock_set_state+0x560> */
	X86_SIM_X86_JMP(0x542, 0x560, x86_l_560);
x86_l_544:
	/* 0x544: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_54c:
	/* 0x54c: jmp    5a4 <inet_sock_set_state+0x5a4> */
	X86_SIM_X86_JMP(0x54c, 0x5a4, x86_l_5a4);
x86_l_54e:
	/* 0x54e: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_557:
	/* 0x557: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_560:
	/* 0x560: lea    rax,[rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_564:
	/* 0x564: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_567:
	/* 0x567: jns    570 <inet_sock_set_state+0x570> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x567, 0x570, x86_l_570);
x86_l_569:
	/* 0x569: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56c:
	/* 0x56c: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_570:
	/* 0x570: lea    rax,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_578:
	/* 0x578: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_57b:
	/* 0x57b: jns    590 <inet_sock_set_state+0x590> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x57b, 0x590, x86_l_590);
x86_l_57d:
	/* 0x57d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_580:
	/* 0x580: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_585:
	/* 0x585: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_589:
	/* 0x589: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_58e:
	/* 0x58e: jmp    5a4 <inet_sock_set_state+0x5a4> */
	X86_SIM_X86_JMP(0x58e, 0x5a4, x86_l_5a4);
x86_l_590:
	/* 0x590: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_595:
	/* 0x595: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_59d:
	/* 0x59d: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a4:
	/* 0x5a4: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_5ab:
	/* 0x5ab: lea    rcx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b0:
	/* 0x5b0: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_5b5:
	/* 0x5b5: mov    r8d,0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 96ULL);
x86_l_5bb:
	/* 0x5bb: call   5c0 <inet_sock_set_state+0x5c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_5c0:
	/* 0x5c0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)birth));
x86_l_5c7:
	/* 0x5c7: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_5ca:
	/* 0x5ca: call   5cf <inet_sock_set_state+0x5cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_5cf:
	/* 0x5cf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)idents));
x86_l_5d6:
	/* 0x5d6: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_5d9:
	/* 0x5d9: call   5de <inet_sock_set_state+0x5de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_5de:
	/* 0x5de: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e0:
	/* 0x5e0: add    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_5e7:
	/* 0x5e7: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5e8:
	/* 0x5e8: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5ea:
	/* 0x5ea: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5ec:
	/* 0x5ec: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5ee:
	/* 0x5ee: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5f0:
	/* 0x5f0: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5f1:
	/* 0x5f1: jmp    5f6 <inet_sock_set_state+0x5f6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_5f6:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
