#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(6) M(8) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(19) M(22) M(23) M(24)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/set_fs_pwd")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 200ULL);
x86_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xac],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_set_fs_pwd+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x12d5, x86_l_12d5);
x86_l_3c:
	/* 0x3c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_set_fs_pwd+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x12d5, x86_l_12d5);
x86_l_5c:
	/* 0x5c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r14,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9e:
	/* 0x9e: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a9:
	/* 0xa9: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b4:
	/* 0xb4: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bf:
	/* 0xbf: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ca:
	/* 0xca: call   cf <trace_set_fs_pwd+0xcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f6:
	/* 0xf6: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_116:
	/* 0x116: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11e:
	/* 0x11e: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12e:
	/* 0x12e: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13e:
	/* 0x13e: call   143 <trace_set_fs_pwd+0x143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_143:
	/* 0x143: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [rbp+0x70],0x30d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337933ULL);
x86_l_154:
	/* 0x154: call   159 <trace_set_fs_pwd+0x159> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d:
	/* 0x15d: call   162 <trace_set_fs_pwd+0x162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_162:
	/* 0x162: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_166:
	/* 0x166: call   16b <trace_set_fs_pwd+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16b:
	/* 0x16b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: jns    186 <trace_set_fs_pwd+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175, 0x186, x86_l_186);
x86_l_177:
	/* 0x177: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17e:
	/* 0x17e: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_184:
	/* 0x184: jne    1c3 <trace_set_fs_pwd+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184, 0x1c3, x86_l_1c3);
x86_l_186:
	/* 0x186: call   18b <trace_set_fs_pwd+0x18b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18b:
	/* 0x18b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: call   193 <trace_set_fs_pwd+0x193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_193:
	/* 0x193: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: jns    1aa <trace_set_fs_pwd+0x1aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19a, 0x1aa, x86_l_1aa);
x86_l_19c:
	/* 0x19c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a3:
	/* 0x1a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     1b5 <trace_set_fs_pwd+0x1b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a6, 0x1b5, x86_l_1b5);
x86_l_1a8:
	/* 0x1a8: jmp    1bf <trace_set_fs_pwd+0x1bf> */
	X86_SIM_X86_JMP(0x1a8, 0x1bf, x86_l_1bf);
x86_l_1aa:
	/* 0x1aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac:
	/* 0x1ac: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1b0:
	/* 0x1b0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: jns    1bf <trace_set_fs_pwd+0x1bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3, 0x1bf, x86_l_1bf);
x86_l_1b5:
	/* 0x1b5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7:
	/* 0x1b7: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b9:
	/* 0x1b9: jne    50a <trace_set_fs_pwd+0x50a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b9, 0x50a, x86_l_50a);
x86_l_1bf:
	/* 0x1bf: mov    eax,DWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1cb:
	/* 0x1cb: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1e1:
	/* 0x1e1: call   1e6 <trace_set_fs_pwd+0x1e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e6:
	/* 0x1e6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1eb:
	/* 0x1eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ee:
	/* 0x1ee: je     11ad <trace_set_fs_pwd+0x11ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee, 0x11ad, x86_l_11ad);
x86_l_1f4:
	/* 0x1f4: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f8:
	/* 0x1f8: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_1ff:
	/* 0x1ff: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_206:
	/* 0x206: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_20e:
	/* 0x20e: call   213 <trace_set_fs_pwd+0x213> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_213:
	/* 0x213: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_216:
	/* 0x216: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: je     1236 <trace_set_fs_pwd+0x1236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x219, 0x1236, x86_l_1236);
x86_l_21f:
	/* 0x21f: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_224:
	/* 0x224: jne    22d <trace_set_fs_pwd+0x22d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x224, 0x22d, x86_l_22d);
x86_l_226:
	/* 0x226: call   22b <trace_set_fs_pwd+0x22b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_22b:
	/* 0x22b: jmp    285 <trace_set_fs_pwd+0x285> */
	X86_SIM_X86_JMP(0x22b, 0x285, x86_l_285);
x86_l_22d:
	/* 0x22d: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_232:
	/* 0x232: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_239:
	/* 0x239: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23c:
	/* 0x23c: jns    256 <trace_set_fs_pwd+0x256> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c, 0x256, x86_l_256);
x86_l_23e:
	/* 0x23e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241:
	/* 0x241: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_244:
	/* 0x244: js     25d <trace_set_fs_pwd+0x25d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x244, 0x25d, x86_l_25d);
x86_l_246:
	/* 0x246: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_248:
	/* 0x248: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24b:
	/* 0x24b: js     265 <trace_set_fs_pwd+0x265> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24b, 0x265, x86_l_265);
x86_l_24d:
	/* 0x24d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f:
	/* 0x24f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_252:
	/* 0x252: js     26d <trace_set_fs_pwd+0x26d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x252, 0x26d, x86_l_26d);
x86_l_254:
	/* 0x254: jmp    283 <trace_set_fs_pwd+0x283> */
	X86_SIM_X86_JMP(0x254, 0x283, x86_l_283);
x86_l_256:
	/* 0x256: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258:
	/* 0x258: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: jns    246 <trace_set_fs_pwd+0x246> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25b, 0x246, x86_l_246);
x86_l_25d:
	/* 0x25d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260:
	/* 0x260: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263:
	/* 0x263: jns    24d <trace_set_fs_pwd+0x24d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x263, 0x24d, x86_l_24d);
x86_l_265:
	/* 0x265: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_268:
	/* 0x268: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26b:
	/* 0x26b: jns    283 <trace_set_fs_pwd+0x283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26b, 0x283, x86_l_283);
x86_l_26d:
	/* 0x26d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_270:
	/* 0x270: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: je     283 <trace_set_fs_pwd+0x283> */
	X86_SIM_X86_JCC(X86_CC_E, 0x273, 0x283, x86_l_283);
x86_l_275:
	/* 0x275: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_279:
	/* 0x279: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27c:
	/* 0x27c: jns    283 <trace_set_fs_pwd+0x283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27c, 0x283, x86_l_283);
x86_l_27e:
	/* 0x27e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_281:
	/* 0x281: jmp    285 <trace_set_fs_pwd+0x285> */
	X86_SIM_X86_JMP(0x281, 0x285, x86_l_285);
x86_l_283:
	/* 0x283: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_285:
	/* 0x285: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_289:
	/* 0x289: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28d:
	/* 0x28d: mov    DWORD PTR [rsp+0x3c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_291:
	/* 0x291: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_298:
	/* 0x298: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_29d:
	/* 0x29d: call   2a2 <trace_set_fs_pwd+0x2a2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a2:
	/* 0x2a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a5:
	/* 0x2a5: je     2bd <trace_set_fs_pwd+0x2bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a5, 0x2bd, x86_l_2bd);
x86_l_2a7:
	/* 0x2a7: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2aa:
	/* 0x2aa: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2b0:
	/* 0x2b0: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2b3:
	/* 0x2b3: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2b6:
	/* 0x2b6: jne    2bd <trace_set_fs_pwd+0x2bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b6, 0x2bd, x86_l_2bd);
x86_l_2b8:
	/* 0x2b8: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2bd:
	/* 0x2bd: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2c2:
	/* 0x2c2: cmp    ax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R13, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2c7:
	/* 0x2c7: jne    12dd <trace_set_fs_pwd+0x12dd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c7, 0x12dd, x86_l_12dd);
x86_l_2cd:
	/* 0x2cd: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2d8:
	/* 0x2d8: mov    DWORD PTR [rsp+0x50],0x30d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597384461ULL);
x86_l_2e0:
	/* 0x2e0: mov    WORD PTR [rsp+0x4c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_2e5:
	/* 0x2e5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_2ec:
	/* 0x2ec: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_2f1:
	/* 0x2f1: call   2f6 <trace_set_fs_pwd+0x2f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f6:
	/* 0x2f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: je     364 <trace_set_fs_pwd+0x364> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f9, 0x364, x86_l_364);
x86_l_2fb:
	/* 0x2fb: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_300:
	/* 0x300: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_303:
	/* 0x303: call   308 <trace_set_fs_pwd+0x308> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_308:
	/* 0x308: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30b:
	/* 0x30b: je     364 <trace_set_fs_pwd+0x364> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30b, 0x364, x86_l_364);
x86_l_30d:
	/* 0x30d: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_311:
	/* 0x311: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_318:
	/* 0x318: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31b:
	/* 0x31b: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_322:
	/* 0x322: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_326:
	/* 0x326: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32a:
	/* 0x32a: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_331:
	/* 0x331: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_338:
	/* 0x338: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33c:
	/* 0x33c: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_343:
	/* 0x343: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_347:
	/* 0x347: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_34e:
	/* 0x34e: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_352:
	/* 0x352: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_359:
	/* 0x359: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_35d:
	/* 0x35d: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_364:
	/* 0x364: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_36b:
	/* 0x36b: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_372:
	/* 0x372: mov    ecx,DWORD PTR [r14+0x74] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_376:
	/* 0x376: and    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_379:
	/* 0x379: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37c:
	/* 0x37c: cmp    ecx,0x50 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_37f:
	/* 0x37f: jne    32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x37f, 0x32bd, x86_l_32bd);
x86_l_385:
	/* 0x385: lea    rdx,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_389:
	/* 0x389: mov    ecx,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38d:
	/* 0x38d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_390:
	/* 0x390: cmp    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_392:
	/* 0x392: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_397:
	/* 0x397: mov    QWORD PTR [rsp+0x30],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_39c:
	/* 0x39c: mov    QWORD PTR [rsp+0x28],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3a1:
	/* 0x3a1: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a6:
	/* 0x3a6: jne    3bf <trace_set_fs_pwd+0x3bf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a6, 0x3bf, x86_l_3bf);
x86_l_3a8:
	/* 0x3a8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3aa:
	/* 0x3aa: and    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3ad:
	/* 0x3ad: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3b4:
	/* 0x3b4: jne    cdf <trace_set_fs_pwd+0xcdf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b4, 0xcdf, x86_l_cdf);
x86_l_3ba:
	/* 0x3ba: jmp    32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JMP(0x3ba, 0x32bd, x86_l_32bd);
x86_l_3bf:
	/* 0x3bf: mov    QWORD PTR [rsp+0xc0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3c7:
	/* 0x3c7: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_3ce:
	/* 0x3ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d1:
	/* 0x3d1: je     59b <trace_set_fs_pwd+0x59b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d1, 0x59b, x86_l_59b);
x86_l_3d7:
	/* 0x3d7: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_3de:
	/* 0x3de: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_3e1:
	/* 0x3e1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e3:
	/* 0x3e3: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3e6:
	/* 0x3e6: sete   dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3e9:
	/* 0x3e9: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3ec:
	/* 0x3ec: neg    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3ef:
	/* 0x3ef: xor    rdx,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_3f6:
	/* 0x3f6: or     rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3f9:
	/* 0x3f9: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_400:
	/* 0x400: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_403:
	/* 0x403: je     424 <trace_set_fs_pwd+0x424> */
	X86_SIM_X86_JCC(X86_CC_E, 0x403, 0x424, x86_l_424);
x86_l_405:
	/* 0x405: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_407:
	/* 0x407: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_40e:
	/* 0x40e: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_411:
	/* 0x411: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_414:
	/* 0x414: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_417:
	/* 0x417: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_41e:
	/* 0x41e: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_421:
	/* 0x421: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_424:
	/* 0x424: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_42b:
	/* 0x42b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42e:
	/* 0x42e: je     44a <trace_set_fs_pwd+0x44a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42e, 0x44a, x86_l_44a);
x86_l_430:
	/* 0x430: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_434:
	/* 0x434: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_437:
	/* 0x437: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_43a:
	/* 0x43a: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_43d:
	/* 0x43d: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_444:
	/* 0x444: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_447:
	/* 0x447: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_44a:
	/* 0x44a: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_451:
	/* 0x451: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_454:
	/* 0x454: je     472 <trace_set_fs_pwd+0x472> */
	X86_SIM_X86_JCC(X86_CC_E, 0x454, 0x472, x86_l_472);
x86_l_456:
	/* 0x456: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_459:
	/* 0x459: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45e:
	/* 0x45e: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_462:
	/* 0x462: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_465:
	/* 0x465: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_46c:
	/* 0x46c: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_46f:
	/* 0x46f: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_472:
	/* 0x472: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_477:
	/* 0x477: mov    r15,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_47e:
	/* 0x47e: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_481:
	/* 0x481: mov    WORD PTR [rsp+0x18],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_486:
	/* 0x486: je     610 <trace_set_fs_pwd+0x610> */
	X86_SIM_X86_JCC(X86_CC_E, 0x486, 0x610, x86_l_610);
x86_l_48c:
	/* 0x48c: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_491:
	/* 0x491: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_498:
	/* 0x498: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_4a0:
	/* 0x4a0: mov    rcx,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_4a7:
	/* 0x4a7: mov    QWORD PTR [rsp+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4af:
	/* 0x4af: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_4b6:
	/* 0x4b6: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4be:
	/* 0x4be: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4c3:
	/* 0x4c3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_4ca:
	/* 0x4ca: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4cf:
	/* 0x4cf: call   4d4 <trace_set_fs_pwd+0x4d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4d4:
	/* 0x4d4: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4d7:
	/* 0x4d7: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4db:
	/* 0x4db: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4e0:
	/* 0x4e0: mov    rbx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4e7:
	/* 0x4e7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4ea:
	/* 0x4ea: je     52b <trace_set_fs_pwd+0x52b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ea, 0x52b, x86_l_52b);
x86_l_4ec:
	/* 0x4ec: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4f1:
	/* 0x4f1: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4f4:
	/* 0x4f4: call   4f9 <trace_set_fs_pwd+0x4f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4f9:
	/* 0x4f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4fc:
	/* 0x4fc: je     52b <trace_set_fs_pwd+0x52b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4fc, 0x52b, x86_l_52b);
x86_l_4fe:
	/* 0x4fe: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_501:
	/* 0x501: mov    rbx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_505:
	/* 0x505: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_508:
	/* 0x508: jmp    52d <trace_set_fs_pwd+0x52d> */
	X86_SIM_X86_JMP(0x508, 0x52d, x86_l_52d);
x86_l_50a:
	/* 0x50a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_511:
	/* 0x511: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_516:
	/* 0x516: call   51b <trace_set_fs_pwd+0x51b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_51b:
	/* 0x51b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51e:
	/* 0x51e: je     5b7 <trace_set_fs_pwd+0x5b7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51e, 0x5b7, x86_l_5b7);
x86_l_524:
	/* 0x524: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_526:
	/* 0x526: jmp    1c3 <trace_set_fs_pwd+0x1c3> */
	X86_SIM_X86_JMP(0x526, 0x1c3, x86_l_1c3);
x86_l_52b:
	/* 0x52b: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_52d:
	/* 0x52d: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_532:
	/* 0x532: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_53a:
	/* 0x53a: mov    rdi,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_542:
	/* 0x542: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_547:
	/* 0x547: dec    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_54a:
	/* 0x54a: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54d:
	/* 0x54d: jb     565 <trace_set_fs_pwd+0x565> */
	X86_SIM_X86_JCC(X86_CC_B, 0x54d, 0x565, x86_l_565);
x86_l_54f:
	/* 0x54f: cmp    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_553:
	/* 0x553: je     55a <trace_set_fs_pwd+0x55a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x553, 0x55a, x86_l_55a);
x86_l_555:
	/* 0x555: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_558:
	/* 0x558: jbe    565 <trace_set_fs_pwd+0x565> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x558, 0x565, x86_l_565);
x86_l_55a:
	/* 0x55a: and    rbx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 184ULL);
x86_l_562:
	/* 0x562: or     rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_565:
	/* 0x565: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_569:
	/* 0x569: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_56e:
	/* 0x56e: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_575:
	/* 0x575: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_578:
	/* 0x578: je     5c1 <trace_set_fs_pwd+0x5c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x578, 0x5c1, x86_l_5c1);
x86_l_57a:
	/* 0x57a: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_57d:
	/* 0x57d: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_582:
	/* 0x582: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_585:
	/* 0x585: call   58a <trace_set_fs_pwd+0x58a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_58a:
	/* 0x58a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58d:
	/* 0x58d: je     5d2 <trace_set_fs_pwd+0x5d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58d, 0x5d2, x86_l_5d2);
x86_l_58f:
	/* 0x58f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_592:
	/* 0x592: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_596:
	/* 0x596: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_599:
	/* 0x599: jmp    5d4 <trace_set_fs_pwd+0x5d4> */
	X86_SIM_X86_JMP(0x599, 0x5d4, x86_l_5d4);
x86_l_59b:
	/* 0x59b: mov    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5a2:
	/* 0x5a2: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_5a9:
	/* 0x5a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ac:
	/* 0x5ac: jne    405 <trace_set_fs_pwd+0x405> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5ac, 0x405, x86_l_405);
x86_l_5b2:
	/* 0x5b2: jmp    424 <trace_set_fs_pwd+0x424> */
	X86_SIM_X86_JMP(0x5b2, 0x424, x86_l_424);
x86_l_5b7:
	/* 0x5b7: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_5bc:
	/* 0x5bc: jmp    1c3 <trace_set_fs_pwd+0x1c3> */
	X86_SIM_X86_JMP(0x5bc, 0x1c3, x86_l_1c3);
x86_l_5c1:
	/* 0x5c1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5c3:
	/* 0x5c3: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5c6:
	/* 0x5c6: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5cb:
	/* 0x5cb: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ce:
	/* 0x5ce: jae    5f1 <trace_set_fs_pwd+0x5f1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5ce, 0x5f1, x86_l_5f1);
x86_l_5d0:
	/* 0x5d0: jmp    607 <trace_set_fs_pwd+0x607> */
	X86_SIM_X86_JMP(0x5d0, 0x607, x86_l_607);
x86_l_5d2:
	/* 0x5d2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5d4:
	/* 0x5d4: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5d9:
	/* 0x5d9: mov    rsi,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_5e1:
	/* 0x5e1: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5e4:
	/* 0x5e4: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5e7:
	/* 0x5e7: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5ec:
	/* 0x5ec: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ef:
	/* 0x5ef: jb     607 <trace_set_fs_pwd+0x607> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5ef, 0x607, x86_l_607);
x86_l_5f1:
	/* 0x5f1: cmp    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5f5:
	/* 0x5f5: je     5fc <trace_set_fs_pwd+0x5fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f5, 0x5fc, x86_l_5fc);
x86_l_5f7:
	/* 0x5f7: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5fa:
	/* 0x5fa: jbe    607 <trace_set_fs_pwd+0x607> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5fa, 0x607, x86_l_607);
x86_l_5fc:
	/* 0x5fc: and    r13,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 184ULL);
x86_l_604:
	/* 0x604: or     rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_607:
	/* 0x607: or     rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_60a:
	/* 0x60a: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_60d:
	/* 0x60d: and    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_610:
	/* 0x610: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_618:
	/* 0x618: je     6db <trace_set_fs_pwd+0x6db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x618, 0x6db, x86_l_6db);
x86_l_61e:
	/* 0x61e: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_621:
	/* 0x621: call   626 <trace_set_fs_pwd+0x626> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_626:
	/* 0x626: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62a:
	/* 0x62a: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_631:
	/* 0x631: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_638:
	/* 0x638: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_63d:
	/* 0x63d: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_644:
	/* 0x644: mov    r12,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_64b:
	/* 0x64b: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_650:
	/* 0x650: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_655:
	/* 0x655: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_65c:
	/* 0x65c: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_661:
	/* 0x661: call   666 <trace_set_fs_pwd+0x666> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_666:
	/* 0x666: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_66a:
	/* 0x66a: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_66f:
	/* 0x66f: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_676:
	/* 0x676: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_679:
	/* 0x679: je     699 <trace_set_fs_pwd+0x699> */
	X86_SIM_X86_JCC(X86_CC_E, 0x679, 0x699, x86_l_699);
x86_l_67b:
	/* 0x67b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_680:
	/* 0x680: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_683:
	/* 0x683: call   688 <trace_set_fs_pwd+0x688> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_688:
	/* 0x688: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_68b:
	/* 0x68b: je     699 <trace_set_fs_pwd+0x699> */
	X86_SIM_X86_JCC(X86_CC_E, 0x68b, 0x699, x86_l_699);
x86_l_68d:
	/* 0x68d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_690:
	/* 0x690: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_694:
	/* 0x694: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_697:
	/* 0x697: jmp    69b <trace_set_fs_pwd+0x69b> */
	X86_SIM_X86_JMP(0x697, 0x69b, x86_l_69b);
x86_l_699:
	/* 0x699: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_69b:
	/* 0x69b: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_69e:
	/* 0x69e: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6a1:
	/* 0x6a1: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6a6:
	/* 0x6a6: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6a9:
	/* 0x6a9: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ac:
	/* 0x6ac: jb     6c1 <trace_set_fs_pwd+0x6c1> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6ac, 0x6c1, x86_l_6c1);
x86_l_6ae:
	/* 0x6ae: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6b2:
	/* 0x6b2: je     6b9 <trace_set_fs_pwd+0x6b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b2, 0x6b9, x86_l_6b9);
x86_l_6b4:
	/* 0x6b4: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6b7:
	/* 0x6b7: jbe    6c1 <trace_set_fs_pwd+0x6c1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x6b7, 0x6c1, x86_l_6c1);
x86_l_6b9:
	/* 0x6b9: and    r15,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 64ULL);
x86_l_6be:
	/* 0x6be: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6c1:
	/* 0x6c1: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6c6:
	/* 0x6c6: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6c9:
	/* 0x6c9: and    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_6cc:
	/* 0x6cc: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6d4:
	/* 0x6d4: jne    6ee <trace_set_fs_pwd+0x6ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6d4, 0x6ee, x86_l_6ee);
x86_l_6d6:
	/* 0x6d6: jmp    794 <trace_set_fs_pwd+0x794> */
	X86_SIM_X86_JMP(0x6d6, 0x794, x86_l_794);
x86_l_6db:
	/* 0x6db: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e0:
	/* 0x6e0: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6e8:
	/* 0x6e8: je     794 <trace_set_fs_pwd+0x794> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e8, 0x794, x86_l_794);
x86_l_6ee:
	/* 0x6ee: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6f3:
	/* 0x6f3: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6fa:
	/* 0x6fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6fd:
	/* 0x6fd: jns    704 <trace_set_fs_pwd+0x704> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6fd, 0x704, x86_l_704);
x86_l_6ff:
	/* 0x6ff: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_702:
	/* 0x702: jmp    706 <trace_set_fs_pwd+0x706> */
	X86_SIM_X86_JMP(0x702, 0x706, x86_l_706);
x86_l_704:
	/* 0x704: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_706:
	/* 0x706: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_70a:
	/* 0x70a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_70c:
	/* 0x70c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_70f:
	/* 0x70f: jns    71e <trace_set_fs_pwd+0x71e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x70f, 0x71e, x86_l_71e);
x86_l_711:
	/* 0x711: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_714:
	/* 0x714: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_717:
	/* 0x717: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_71a:
	/* 0x71a: js     728 <trace_set_fs_pwd+0x728> */
	X86_SIM_X86_JCC(X86_CC_S, 0x71a, 0x728, x86_l_728);
x86_l_71c:
	/* 0x71c: jmp    72a <trace_set_fs_pwd+0x72a> */
	X86_SIM_X86_JMP(0x71c, 0x72a, x86_l_72a);
x86_l_71e:
	/* 0x71e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_720:
	/* 0x720: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_723:
	/* 0x723: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_726:
	/* 0x726: jns    72a <trace_set_fs_pwd+0x72a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x726, 0x72a, x86_l_72a);
x86_l_728:
	/* 0x728: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_72a:
	/* 0x72a: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_72e:
	/* 0x72e: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_735:
	/* 0x735: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_73c:
	/* 0x73c: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_73f:
	/* 0x73f: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_744:
	/* 0x744: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_749:
	/* 0x749: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_750:
	/* 0x750: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_755:
	/* 0x755: call   75a <trace_set_fs_pwd+0x75a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_75a:
	/* 0x75a: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_761:
	/* 0x761: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_764:
	/* 0x764: je     783 <trace_set_fs_pwd+0x783> */
	X86_SIM_X86_JCC(X86_CC_E, 0x764, 0x783, x86_l_783);
x86_l_766:
	/* 0x766: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_76a:
	/* 0x76a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_76d:
	/* 0x76d: call   772 <trace_set_fs_pwd+0x772> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_772:
	/* 0x772: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_775:
	/* 0x775: je     783 <trace_set_fs_pwd+0x783> */
	X86_SIM_X86_JCC(X86_CC_E, 0x775, 0x783, x86_l_783);
x86_l_777:
	/* 0x777: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_77a:
	/* 0x77a: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_77e:
	/* 0x77e: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_781:
	/* 0x781: jmp    785 <trace_set_fs_pwd+0x785> */
	X86_SIM_X86_JMP(0x781, 0x785, x86_l_785);
x86_l_783:
	/* 0x783: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_785:
	/* 0x785: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_788:
	/* 0x788: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_78b:
	/* 0x78b: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_78e:
	/* 0x78e: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_791:
	/* 0x791: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_794:
	/* 0x794: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_79c:
	/* 0x79c: je     869 <trace_set_fs_pwd+0x869> */
	X86_SIM_X86_JCC(X86_CC_E, 0x79c, 0x869, x86_l_869);
x86_l_7a2:
	/* 0x7a2: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_7a9:
	/* 0x7a9: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7ad:
	/* 0x7ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7af:
	/* 0x7af: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7b2:
	/* 0x7b2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7b5:
	/* 0x7b5: jns    7c4 <trace_set_fs_pwd+0x7c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7b5, 0x7c4, x86_l_7c4);
x86_l_7b7:
	/* 0x7b7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ba:
	/* 0x7ba: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7bd:
	/* 0x7bd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7c0:
	/* 0x7c0: js     7ce <trace_set_fs_pwd+0x7ce> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7c0, 0x7ce, x86_l_7ce);
x86_l_7c2:
	/* 0x7c2: jmp    7d0 <trace_set_fs_pwd+0x7d0> */
	X86_SIM_X86_JMP(0x7c2, 0x7d0, x86_l_7d0);
x86_l_7c4:
	/* 0x7c4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c6:
	/* 0x7c6: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7c9:
	/* 0x7c9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7cc:
	/* 0x7cc: jns    7d0 <trace_set_fs_pwd+0x7d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7cc, 0x7d0, x86_l_7d0);
x86_l_7ce:
	/* 0x7ce: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7d0:
	/* 0x7d0: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_7d2:
	/* 0x7d2: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_7d6:
	/* 0x7d6: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7d9:
	/* 0x7d9: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7dd:
	/* 0x7dd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7df:
	/* 0x7df: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7e2:
	/* 0x7e2: jns    7f2 <trace_set_fs_pwd+0x7f2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7e2, 0x7f2, x86_l_7f2);
x86_l_7e4:
	/* 0x7e4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e7:
	/* 0x7e7: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7eb:
	/* 0x7eb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7ee:
	/* 0x7ee: js     7fd <trace_set_fs_pwd+0x7fd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7ee, 0x7fd, x86_l_7fd);
x86_l_7f0:
	/* 0x7f0: jmp    7ff <trace_set_fs_pwd+0x7ff> */
	X86_SIM_X86_JMP(0x7f0, 0x7ff, x86_l_7ff);
x86_l_7f2:
	/* 0x7f2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f4:
	/* 0x7f4: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7f8:
	/* 0x7f8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7fb:
	/* 0x7fb: jns    7ff <trace_set_fs_pwd+0x7ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7fb, 0x7ff, x86_l_7ff);
x86_l_7fd:
	/* 0x7fd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ff:
	/* 0x7ff: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_803:
	/* 0x803: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_80a:
	/* 0x80a: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_811:
	/* 0x811: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_814:
	/* 0x814: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_819:
	/* 0x819: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_81e:
	/* 0x81e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_825:
	/* 0x825: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_82a:
	/* 0x82a: call   82f <trace_set_fs_pwd+0x82f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_82f:
	/* 0x82f: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_836:
	/* 0x836: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_839:
	/* 0x839: je     858 <trace_set_fs_pwd+0x858> */
	X86_SIM_X86_JCC(X86_CC_E, 0x839, 0x858, x86_l_858);
x86_l_83b:
	/* 0x83b: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_83f:
	/* 0x83f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_842:
	/* 0x842: call   847 <trace_set_fs_pwd+0x847> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_847:
	/* 0x847: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_84a:
	/* 0x84a: je     858 <trace_set_fs_pwd+0x858> */
	X86_SIM_X86_JCC(X86_CC_E, 0x84a, 0x858, x86_l_858);
x86_l_84c:
	/* 0x84c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84f:
	/* 0x84f: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_853:
	/* 0x853: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_856:
	/* 0x856: jmp    85a <trace_set_fs_pwd+0x85a> */
	X86_SIM_X86_JMP(0x856, 0x85a, x86_l_85a);
x86_l_858:
	/* 0x858: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85a:
	/* 0x85a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_85d:
	/* 0x85d: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_860:
	/* 0x860: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_863:
	/* 0x863: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_866:
	/* 0x866: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_869:
	/* 0x869: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_871:
	/* 0x871: je     a68 <trace_set_fs_pwd+0xa68> */
	X86_SIM_X86_JCC(X86_CC_E, 0x871, 0xa68, x86_l_a68);
x86_l_877:
	/* 0x877: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_87c:
	/* 0x87c: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_883:
	/* 0x883: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_886:
	/* 0x886: jns    899 <trace_set_fs_pwd+0x899> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x886, 0x899, x86_l_899);
x86_l_888:
	/* 0x888: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_88b:
	/* 0x88b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88e:
	/* 0x88e: js     8a0 <trace_set_fs_pwd+0x8a0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x88e, 0x8a0, x86_l_8a0);
x86_l_890:
	/* 0x890: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_892:
	/* 0x892: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_895:
	/* 0x895: js     8a8 <trace_set_fs_pwd+0x8a8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x895, 0x8a8, x86_l_8a8);
x86_l_897:
	/* 0x897: jmp    8f9 <trace_set_fs_pwd+0x8f9> */
	X86_SIM_X86_JMP(0x897, 0x8f9, x86_l_8f9);
x86_l_899:
	/* 0x899: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_89b:
	/* 0x89b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89e:
	/* 0x89e: jns    890 <trace_set_fs_pwd+0x890> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x89e, 0x890, x86_l_890);
x86_l_8a0:
	/* 0x8a0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8a3:
	/* 0x8a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a6:
	/* 0x8a6: jns    8f9 <trace_set_fs_pwd+0x8f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8a6, 0x8f9, x86_l_8f9);
x86_l_8a8:
	/* 0x8a8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8ab:
	/* 0x8ab: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8b0:
	/* 0x8b0: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8b4:
	/* 0x8b4: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_8b9:
	/* 0x8b9: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8bd:
	/* 0x8bd: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8c2:
	/* 0x8c2: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8c6:
	/* 0x8c6: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8cb:
	/* 0x8cb: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8cf:
	/* 0x8cf: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8d4:
	/* 0x8d4: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8d8:
	/* 0x8d8: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_8dd:
	/* 0x8dd: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8e1:
	/* 0x8e1: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8e9:
	/* 0x8e9: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8ed:
	/* 0x8ed: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_8f5:
	/* 0x8f5: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_8f9:
	/* 0x8f9: lea    r12,[rbp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_8fd:
	/* 0x8fd: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_902:
	/* 0x902: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_905:
	/* 0x905: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_90a:
	/* 0x90a: jns    9eb <trace_set_fs_pwd+0x9eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x90a, 0x9eb, x86_l_9eb);
x86_l_910:
	/* 0x910: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_913:
	/* 0x913: mov    BYTE PTR [r12],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_917:
	/* 0x917: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_919:
	/* 0x919: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_91e:
	/* 0x91e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91e, 0xa01, x86_l_a01);
x86_l_924:
	/* 0x924: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_928:
	/* 0x928: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_92c:
	/* 0x92c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_92e:
	/* 0x92e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x92e, 0xa01, x86_l_a01);
x86_l_934:
	/* 0x934: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_938:
	/* 0x938: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_93c:
	/* 0x93c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_93e:
	/* 0x93e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93e, 0xa01, x86_l_a01);
x86_l_944:
	/* 0x944: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_948:
	/* 0x948: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_94c:
	/* 0x94c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_94e:
	/* 0x94e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94e, 0xa01, x86_l_a01);
x86_l_954:
	/* 0x954: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_958:
	/* 0x958: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_95c:
	/* 0x95c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_95e:
	/* 0x95e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95e, 0xa01, x86_l_a01);
x86_l_964:
	/* 0x964: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_968:
	/* 0x968: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_96c:
	/* 0x96c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_96e:
	/* 0x96e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x96e, 0xa01, x86_l_a01);
x86_l_974:
	/* 0x974: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_978:
	/* 0x978: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_97c:
	/* 0x97c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_97e:
	/* 0x97e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x97e, 0xa01, x86_l_a01);
x86_l_984:
	/* 0x984: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_988:
	/* 0x988: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_98c:
	/* 0x98c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_98e:
	/* 0x98e: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x98e, 0xa01, x86_l_a01);
x86_l_990:
	/* 0x990: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_994:
	/* 0x994: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_998:
	/* 0x998: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_99a:
	/* 0x99a: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99a, 0xa01, x86_l_a01);
x86_l_99c:
	/* 0x99c: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_9a0:
	/* 0x9a0: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_9a4:
	/* 0x9a4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a6:
	/* 0x9a6: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a6, 0xa01, x86_l_a01);
x86_l_9a8:
	/* 0x9a8: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_9ac:
	/* 0x9ac: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_9b0:
	/* 0x9b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b2:
	/* 0x9b2: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b2, 0xa01, x86_l_a01);
x86_l_9b4:
	/* 0x9b4: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_9b8:
	/* 0x9b8: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_9bc:
	/* 0x9bc: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9be:
	/* 0x9be: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9be, 0xa01, x86_l_a01);
x86_l_9c0:
	/* 0x9c0: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_9c4:
	/* 0x9c4: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_9c8:
	/* 0x9c8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9ca:
	/* 0x9ca: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ca, 0xa01, x86_l_a01);
x86_l_9cc:
	/* 0x9cc: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_9d0:
	/* 0x9d0: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_9d4:
	/* 0x9d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d6:
	/* 0x9d6: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d6, 0xa01, x86_l_a01);
x86_l_9d8:
	/* 0x9d8: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_9dc:
	/* 0x9dc: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_9e0:
	/* 0x9e0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_9e2:
	/* 0x9e2: je     a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e2, 0xa01, x86_l_a01);
x86_l_9e4:
	/* 0x9e4: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_9e9:
	/* 0x9e9: jmp    a01 <trace_set_fs_pwd+0xa01> */
	X86_SIM_X86_JMP(0x9e9, 0xa01, x86_l_a01);
x86_l_9eb:
	/* 0x9eb: mov    QWORD PTR [r12+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_9f4:
	/* 0x9f4: mov    QWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9fc:
	/* 0x9fc: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_a01:
	/* 0xa01: mov    rbx,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a08:
	/* 0xa08: mov    r15,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a0f:
	/* 0xa0f: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a12:
	/* 0xa12: mov    WORD PTR [rsp+0x50],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a17:
	/* 0xa17: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a1e:
	/* 0xa1e: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a23:
	/* 0xa23: call   a28 <trace_set_fs_pwd+0xa28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a28:
	/* 0xa28: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a2f:
	/* 0xa2f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a32:
	/* 0xa32: je     a50 <trace_set_fs_pwd+0xa50> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa32, 0xa50, x86_l_a50);
x86_l_a34:
	/* 0xa34: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a37:
	/* 0xa37: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_a3a:
	/* 0xa3a: call   a3f <trace_set_fs_pwd+0xa3f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a3f:
	/* 0xa3f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a42:
	/* 0xa42: je     a50 <trace_set_fs_pwd+0xa50> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa42, 0xa50, x86_l_a50);
x86_l_a44:
	/* 0xa44: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a47:
	/* 0xa47: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a4b:
	/* 0xa4b: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a4e:
	/* 0xa4e: jmp    a52 <trace_set_fs_pwd+0xa52> */
	X86_SIM_X86_JMP(0xa4e, 0xa52, x86_l_a52);
x86_l_a50:
	/* 0xa50: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a52:
	/* 0xa52: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a57:
	/* 0xa57: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a5a:
	/* 0xa5a: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a5d:
	/* 0xa5d: or     r13,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a60:
	/* 0xa60: and    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a63:
	/* 0xa63: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a68:
	/* 0xa68: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a70:
	/* 0xa70: je     b0b <trace_set_fs_pwd+0xb0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa70, 0xb0b, x86_l_b0b);
x86_l_a76:
	/* 0xa76: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_a79:
	/* 0xa79: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a7c:
	/* 0xa7c: lea    r12,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a80:
	/* 0xa80: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_a83:
	/* 0xa83: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a88:
	/* 0xa88: call   a8d <trace_set_fs_pwd+0xa8d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_a8d:
	/* 0xa8d: mov    rbx,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_a94:
	/* 0xa94: mov    r15,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_a9b:
	/* 0xa9b: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a9e:
	/* 0xa9e: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_aa3:
	/* 0xaa3: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_aa8:
	/* 0xaa8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_aaf:
	/* 0xaaf: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ab4:
	/* 0xab4: call   ab9 <trace_set_fs_pwd+0xab9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ab9:
	/* 0xab9: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ac0:
	/* 0xac0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac3:
	/* 0xac3: je     ae1 <trace_set_fs_pwd+0xae1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac3, 0xae1, x86_l_ae1);
x86_l_ac5:
	/* 0xac5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac8:
	/* 0xac8: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_acb:
	/* 0xacb: call   ad0 <trace_set_fs_pwd+0xad0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad0:
	/* 0xad0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad3:
	/* 0xad3: je     ae1 <trace_set_fs_pwd+0xae1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad3, 0xae1, x86_l_ae1);
x86_l_ad5:
	/* 0xad5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ad8:
	/* 0xad8: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_adc:
	/* 0xadc: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_adf:
	/* 0xadf: jmp    ae3 <trace_set_fs_pwd+0xae3> */
	X86_SIM_X86_JMP(0xadf, 0xae3, x86_l_ae3);
x86_l_ae1:
	/* 0xae1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ae3:
	/* 0xae3: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ae6:
	/* 0xae6: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_ae9:
	/* 0xae9: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_aec:
	/* 0xaec: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_aef:
	/* 0xaef: or     r13,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_af2:
	/* 0xaf2: and    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_af5:
	/* 0xaf5: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_afa:
	/* 0xafa: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b01:
	/* 0xb01: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b04:
	/* 0xb04: jne    b1a <trace_set_fs_pwd+0xb1a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb04, 0xb1a, x86_l_b1a);
x86_l_b06:
	/* 0xb06: jmp    b88 <trace_set_fs_pwd+0xb88> */
	X86_SIM_X86_JMP(0xb06, 0xb88, x86_l_b88);
x86_l_b0b:
	/* 0xb0b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b0e:
	/* 0xb0e: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b15:
	/* 0xb15: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b18:
	/* 0xb18: je     b88 <trace_set_fs_pwd+0xb88> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb18, 0xb88, x86_l_b88);
x86_l_b1a:
	/* 0xb1a: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b1d:
	/* 0xb1d: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b21:
	/* 0xb21: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b25:
	/* 0xb25: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b2c:
	/* 0xb2c: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b2f:
	/* 0xb2f: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_b34:
	/* 0xb34: mov    WORD PTR [rsp+0x3c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_b39:
	/* 0xb39: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b40:
	/* 0xb40: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_b45:
	/* 0xb45: call   b4a <trace_set_fs_pwd+0xb4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b4a:
	/* 0xb4a: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b51:
	/* 0xb51: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b54:
	/* 0xb54: je     b74 <trace_set_fs_pwd+0xb74> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb54, 0xb74, x86_l_b74);
x86_l_b56:
	/* 0xb56: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b5b:
	/* 0xb5b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5e:
	/* 0xb5e: call   b63 <trace_set_fs_pwd+0xb63> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b63:
	/* 0xb63: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b66:
	/* 0xb66: je     b74 <trace_set_fs_pwd+0xb74> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb66, 0xb74, x86_l_b74);
x86_l_b68:
	/* 0xb68: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b6b:
	/* 0xb6b: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b6f:
	/* 0xb6f: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b72:
	/* 0xb72: jmp    b76 <trace_set_fs_pwd+0xb76> */
	X86_SIM_X86_JMP(0xb72, 0xb76, x86_l_b76);
x86_l_b74:
	/* 0xb74: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b76:
	/* 0xb76: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b79:
	/* 0xb79: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b7c:
	/* 0xb7c: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b7f:
	/* 0xb7f: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b82:
	/* 0xb82: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b85:
	/* 0xb85: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b88:
	/* 0xb88: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b8f:
	/* 0xb8f: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b92:
	/* 0xb92: je     bfd <trace_set_fs_pwd+0xbfd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb92, 0xbfd, x86_l_bfd);
x86_l_b94:
	/* 0xb94: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b97:
	/* 0xb97: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_b9e:
	/* 0xb9e: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ba1:
	/* 0xba1: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_ba6:
	/* 0xba6: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_bab:
	/* 0xbab: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_bb2:
	/* 0xbb2: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_bb7:
	/* 0xbb7: call   bbc <trace_set_fs_pwd+0xbbc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bbc:
	/* 0xbbc: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bc3:
	/* 0xbc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc6:
	/* 0xbc6: je     be9 <trace_set_fs_pwd+0xbe9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc6, 0xbe9, x86_l_be9);
x86_l_bc8:
	/* 0xbc8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bcb:
	/* 0xbcb: mov    rsi,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_bd3:
	/* 0xbd3: call   bd8 <trace_set_fs_pwd+0xbd8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bd8:
	/* 0xbd8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bdb:
	/* 0xbdb: je     be9 <trace_set_fs_pwd+0xbe9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbdb, 0xbe9, x86_l_be9);
x86_l_bdd:
	/* 0xbdd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_be0:
	/* 0xbe0: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be4:
	/* 0xbe4: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_be7:
	/* 0xbe7: jmp    beb <trace_set_fs_pwd+0xbeb> */
	X86_SIM_X86_JMP(0xbe7, 0xbeb, x86_l_beb);
x86_l_be9:
	/* 0xbe9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_beb:
	/* 0xbeb: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bee:
	/* 0xbee: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bf1:
	/* 0xbf1: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bf4:
	/* 0xbf4: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bf7:
	/* 0xbf7: and    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bfa:
	/* 0xbfa: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bfd:
	/* 0xbfd: mov    rbx,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c04:
	/* 0xc04: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c07:
	/* 0xc07: je     c78 <trace_set_fs_pwd+0xc78> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc07, 0xc78, x86_l_c78);
x86_l_c09:
	/* 0xc09: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c0c:
	/* 0xc0c: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c13:
	/* 0xc13: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c16:
	/* 0xc16: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_c1b:
	/* 0xc1b: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c20:
	/* 0xc20: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_c27:
	/* 0xc27: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c2c:
	/* 0xc2c: call   c31 <trace_set_fs_pwd+0xc31> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c31:
	/* 0xc31: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c38:
	/* 0xc38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c3b:
	/* 0xc3b: je     c8b <trace_set_fs_pwd+0xc8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3b, 0xc8b, x86_l_c8b);
x86_l_c3d:
	/* 0xc3d: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c40:
	/* 0xc40: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c45:
	/* 0xc45: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_c49:
	/* 0xc49: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c4c:
	/* 0xc4c: call   c51 <trace_set_fs_pwd+0xc51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c51:
	/* 0xc51: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c54:
	/* 0xc54: jne    c6c <trace_set_fs_pwd+0xc6c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc54, 0xc6c, x86_l_c6c);
x86_l_c56:
	/* 0xc56: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c5b:
	/* 0xc5b: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c5f:
	/* 0xc5f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c62:
	/* 0xc62: call   c67 <trace_set_fs_pwd+0xc67> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c67:
	/* 0xc67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6a:
	/* 0xc6a: je     c8b <trace_set_fs_pwd+0xc8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6a, 0xc8b, x86_l_c8b);
x86_l_c6c:
	/* 0xc6c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c6f:
	/* 0xc6f: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c73:
	/* 0xc73: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c76:
	/* 0xc76: jmp    c8d <trace_set_fs_pwd+0xc8d> */
	X86_SIM_X86_JMP(0xc76, 0xc8d, x86_l_c8d);
x86_l_c78:
	/* 0xc78: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c7d:
	/* 0xc7d: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c84:
	/* 0xc84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c87:
	/* 0xc87: jne    cb5 <trace_set_fs_pwd+0xcb5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc87, 0xcb5, x86_l_cb5);
x86_l_c89:
	/* 0xc89: jmp    cc1 <trace_set_fs_pwd+0xcc1> */
	X86_SIM_X86_JMP(0xc89, 0xcc1, x86_l_cc1);
x86_l_c8b:
	/* 0xc8b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c8d:
	/* 0xc8d: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c90:
	/* 0xc90: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c93:
	/* 0xc93: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c96:
	/* 0xc96: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c99:
	/* 0xc99: and    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c9c:
	/* 0xc9c: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ca1:
	/* 0xca1: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca6:
	/* 0xca6: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ca9:
	/* 0xca9: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_cb0:
	/* 0xcb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cb3:
	/* 0xcb3: je     cc1 <trace_set_fs_pwd+0xcc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcb3, 0xcc1, x86_l_cc1);
x86_l_cb5:
	/* 0xcb5: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cba:
	/* 0xcba: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_cbe:
	/* 0xcbe: or     rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cc1:
	/* 0xcc1: and    rdx,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_cc8:
	/* 0xcc8: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_ccf:
	/* 0xccf: and    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cd2:
	/* 0xcd2: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_cd9:
	/* 0xcd9: je     32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd9, 0x32bd, x86_l_32bd);
x86_l_cdf:
	/* 0xcdf: mov    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_ce6:
	/* 0xce6: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_cea:
	/* 0xcea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ced:
	/* 0xced: jns    cfd <trace_set_fs_pwd+0xcfd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xced, 0xcfd, x86_l_cfd);
x86_l_cef:
	/* 0xcef: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cf2:
	/* 0xcf2: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_cf6:
	/* 0xcf6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cf9:
	/* 0xcf9: js     d08 <trace_set_fs_pwd+0xd08> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcf9, 0xd08, x86_l_d08);
x86_l_cfb:
	/* 0xcfb: jmp    d18 <trace_set_fs_pwd+0xd18> */
	X86_SIM_X86_JMP(0xcfb, 0xd18, x86_l_d18);
x86_l_cfd:
	/* 0xcfd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cff:
	/* 0xcff: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_d03:
	/* 0xd03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d06:
	/* 0xd06: jns    d18 <trace_set_fs_pwd+0xd18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd06, 0xd18, x86_l_d18);
x86_l_d08:
	/* 0xd08: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d0a:
	/* 0xd0a: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d0d:
	/* 0xd0d: test   eax,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_d12:
	/* 0xd12: jne    32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd12, 0x32bd, x86_l_32bd);
x86_l_d18:
	/* 0xd18: cmp    DWORD PTR [r14+0x74],0x50 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 498216206416ULL);
x86_l_d1d:
	/* 0xd1d: jne    d4c <trace_set_fs_pwd+0xd4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd1d, 0xd4c, x86_l_d4c);
x86_l_d1f:
	/* 0xd1f: call   d24 <trace_set_fs_pwd+0xd24> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_d24:
	/* 0xd24: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d27:
	/* 0xd27: call   d2c <trace_set_fs_pwd+0xd2c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_d2c:
	/* 0xd2c: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d33:
	/* 0xd33: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d36:
	/* 0xd36: jns    d43 <trace_set_fs_pwd+0xd43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd36, 0xd43, x86_l_d43);
x86_l_d38:
	/* 0xd38: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d3a:
	/* 0xd3a: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_d3d:
	/* 0xd3d: jne    ecd <trace_set_fs_pwd+0xecd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd3d, 0xecd, x86_l_ecd);
x86_l_d43:
	/* 0xd43: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_d46:
	/* 0xd46: mov    r12,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d4a:
	/* 0xd4a: jmp    d52 <trace_set_fs_pwd+0xd52> */
	X86_SIM_X86_JMP(0xd4a, 0xd52, x86_l_d52);
x86_l_d4c:
	/* 0xd4c: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_d4f:
	/* 0xd4f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d52:
	/* 0xd52: mov    rbx,QWORD PTR [r15+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d56:
	/* 0xd56: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_d5e:
	/* 0xd5e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_d65:
	/* 0xd65: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d6a:
	/* 0xd6a: call   d6f <trace_set_fs_pwd+0xd6f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d6f:
	/* 0xd6f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d72:
	/* 0xd72: je     d96 <trace_set_fs_pwd+0xd96> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd72, 0xd96, x86_l_d96);
x86_l_d74:
	/* 0xd74: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d77:
	/* 0xd77: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d7a:
	/* 0xd7a: je     15dc <trace_set_fs_pwd+0x15dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7a, 0x15dc, x86_l_15dc);
x86_l_d80:
	/* 0xd80: lea    rax,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d84:
	/* 0xd84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d87:
	/* 0xd87: jns    db1 <trace_set_fs_pwd+0xdb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd87, 0xdb1, x86_l_db1);
x86_l_d89:
	/* 0xd89: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d8c:
	/* 0xd8c: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d8f:
	/* 0xd8f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d92:
	/* 0xd92: js     dbc <trace_set_fs_pwd+0xdbc> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd92, 0xdbc, x86_l_dbc);
x86_l_d94:
	/* 0xd94: jmp    dc6 <trace_set_fs_pwd+0xdc6> */
	X86_SIM_X86_JMP(0xd94, 0xdc6, x86_l_dc6);
x86_l_d96:
	/* 0xd96: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d98:
	/* 0xd98: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_da0:
	/* 0xda0: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_da6:
	/* 0xda6: jbe    2be8 <trace_set_fs_pwd+0x2be8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xda6, 0x2be8, x86_l_2be8);
x86_l_dac:
	/* 0xdac: jmp    2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JMP(0xdac, 0x2d85, x86_l_2d85);
x86_l_db1:
	/* 0xdb1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_db4:
	/* 0xdb4: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_db7:
	/* 0xdb7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dba:
	/* 0xdba: jns    dc6 <trace_set_fs_pwd+0xdc6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdba, 0xdc6, x86_l_dc6);
x86_l_dbc:
	/* 0xdbc: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dbe:
	/* 0xdbe: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_dc0:
	/* 0xdc0: jne    ee5 <trace_set_fs_pwd+0xee5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdc0, 0xee5, x86_l_ee5);
x86_l_dc6:
	/* 0xdc6: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_dc9:
	/* 0xdc9: jns    dd0 <trace_set_fs_pwd+0xdd0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdc9, 0xdd0, x86_l_dd0);
x86_l_dcb:
	/* 0xdcb: mov    rsi,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dce:
	/* 0xdce: jmp    dd2 <trace_set_fs_pwd+0xdd2> */
	X86_SIM_X86_JMP(0xdce, 0xdd2, x86_l_dd2);
x86_l_dd0:
	/* 0xdd0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd2:
	/* 0xdd2: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_dd6:
	/* 0xdd6: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd9:
	/* 0xdd9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ddc:
	/* 0xddc: jns    df8 <trace_set_fs_pwd+0xdf8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xddc, 0xdf8, x86_l_df8);
x86_l_dde:
	/* 0xdde: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de1:
	/* 0xde1: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_de4:
	/* 0xde4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_de7:
	/* 0xde7: js     e02 <trace_set_fs_pwd+0xe02> */
	X86_SIM_X86_JCC(X86_CC_S, 0xde7, 0xe02, x86_l_e02);
x86_l_de9:
	/* 0xde9: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_deb:
	/* 0xdeb: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_def:
	/* 0xdef: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_df2:
	/* 0xdf2: js     e0e <trace_set_fs_pwd+0xe0e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdf2, 0xe0e, x86_l_e0e);
x86_l_df4:
	/* 0xdf4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_df6:
	/* 0xdf6: jmp    e11 <trace_set_fs_pwd+0xe11> */
	X86_SIM_X86_JMP(0xdf6, 0xe11, x86_l_e11);
x86_l_df8:
	/* 0xdf8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dfa:
	/* 0xdfa: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_dfd:
	/* 0xdfd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e00:
	/* 0xe00: jns    de9 <trace_set_fs_pwd+0xde9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe00, 0xde9, x86_l_de9);
x86_l_e02:
	/* 0xe02: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e05:
	/* 0xe05: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e09:
	/* 0xe09: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e0c:
	/* 0xe0c: jns    df4 <trace_set_fs_pwd+0xdf4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe0c, 0xdf4, x86_l_df4);
x86_l_e0e:
	/* 0xe0e: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e11:
	/* 0xe11: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e14:
	/* 0xe14: je     ead <trace_set_fs_pwd+0xead> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe14, 0xead, x86_l_ead);
x86_l_e1a:
	/* 0xe1a: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e1d:
	/* 0xe1d: je     ead <trace_set_fs_pwd+0xead> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe1d, 0xead, x86_l_ead);
x86_l_e23:
	/* 0xe23: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e27:
	/* 0xe27: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e2a:
	/* 0xe2a: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e30:
	/* 0xe30: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e33:
	/* 0xe33: jns    e3c <trace_set_fs_pwd+0xe3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe33, 0xe3c, x86_l_e3c);
x86_l_e35:
	/* 0xe35: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e38:
	/* 0xe38: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e3c:
	/* 0xe3c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_e40:
	/* 0xe40: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_e43:
	/* 0xe43: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_e4a:
	/* 0xe4a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_e4d:
	/* 0xe4d: je     1582 <trace_set_fs_pwd+0x1582> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4d, 0x1582, x86_l_1582);
x86_l_e53:
	/* 0xe53: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_e56:
	/* 0xe56: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_e58:
	/* 0xe58: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_e5e:
	/* 0xe5e: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e61:
	/* 0xe61: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e66:
	/* 0xe66: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_e69:
	/* 0xe69: jns    1566 <trace_set_fs_pwd+0x1566> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe69, 0x1566, x86_l_1566);
x86_l_e6f:
	/* 0xe6f: mov    QWORD PTR [rsp+0x18],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e74:
	/* 0xe74: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e77:
	/* 0xe77: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e7a:
	/* 0xe7a: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_e7e:
	/* 0xe7e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e81:
	/* 0xe81: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_e84:
	/* 0xe84: je     f42 <trace_set_fs_pwd+0xf42> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe84, 0xf42, x86_l_f42);
x86_l_e8a:
	/* 0xe8a: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_e8e:
	/* 0xe8e: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e91:
	/* 0xe91: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_e96:
	/* 0xe96: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_e9a:
	/* 0xe9a: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e9d:
	/* 0xe9d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_ea0:
	/* 0xea0: mov    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ea3:
	/* 0xea3: jne    e81 <trace_set_fs_pwd+0xe81> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xea3, 0xe81, x86_l_e81);
x86_l_ea5:
	/* 0xea5: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_ea8:
	/* 0xea8: jmp    f47 <trace_set_fs_pwd+0xf47> */
	X86_SIM_X86_JMP(0xea8, 0xf47, x86_l_f47);
x86_l_ead:
	/* 0xead: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_eb0:
	/* 0xeb0: jne    1582 <trace_set_fs_pwd+0x1582> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xeb0, 0x1582, x86_l_1582);
x86_l_eb6:
	/* 0xeb6: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_eb9:
	/* 0xeb9: je     1582 <trace_set_fs_pwd+0x1582> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeb9, 0x1582, x86_l_1582);
x86_l_ebf:
	/* 0xebf: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_ec3:
	/* 0xec3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ec6:
	/* 0xec6: jns    f1a <trace_set_fs_pwd+0xf1a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xec6, 0xf1a, x86_l_f1a);
x86_l_ec8:
	/* 0xec8: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ecb:
	/* 0xecb: jmp    f1c <trace_set_fs_pwd+0xf1c> */
	X86_SIM_X86_JMP(0xecb, 0xf1c, x86_l_f1c);
x86_l_ecd:
	/* 0xecd: add    rax,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_ed1:
	/* 0xed1: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_ed4:
	/* 0xed4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed7:
	/* 0xed7: jns    d4f <trace_set_fs_pwd+0xd4f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xed7, 0xd4f, x86_l_d4f);
x86_l_edd:
	/* 0xedd: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee0:
	/* 0xee0: jmp    d52 <trace_set_fs_pwd+0xd52> */
	X86_SIM_X86_JMP(0xee0, 0xd52, x86_l_d52);
x86_l_ee5:
	/* 0xee5: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_eec:
	/* 0xeec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_eef:
	/* 0xeef: jns    1597 <trace_set_fs_pwd+0x1597> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeef, 0x1597, x86_l_1597);
x86_l_ef5:
	/* 0xef5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef7:
	/* 0xef7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef9:
	/* 0xef9: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_f00:
	/* 0xf00: je     15d5 <trace_set_fs_pwd+0x15d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf00, 0x15d5, x86_l_15d5);
x86_l_f06:
	/* 0xf06: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_f0a:
	/* 0xf0a: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_f0e:
	/* 0xf0e: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_f11:
	/* 0xf11: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_f13:
	/* 0xf13: jne    ef9 <trace_set_fs_pwd+0xef9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf13, 0xef9, x86_l_ef9);
x86_l_f15:
	/* 0xf15: jmp    2bcb <trace_set_fs_pwd+0x2bcb> */
	X86_SIM_X86_JMP(0xf15, 0x2bcb, x86_l_2bcb);
x86_l_f1a:
	/* 0xf1a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f1c:
	/* 0xf1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f1f:
	/* 0xf1f: jns    f26 <trace_set_fs_pwd+0xf26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf1f, 0xf26, x86_l_f26);
x86_l_f21:
	/* 0xf21: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f24:
	/* 0xf24: jmp    f28 <trace_set_fs_pwd+0xf28> */
	X86_SIM_X86_JMP(0xf24, 0xf28, x86_l_f28);
x86_l_f26:
	/* 0xf26: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f28:
	/* 0xf28: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f2b:
	/* 0xf2b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f2e:
	/* 0xf2e: jns    f35 <trace_set_fs_pwd+0xf35> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf2e, 0xf35, x86_l_f35);
x86_l_f30:
	/* 0xf30: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f33:
	/* 0xf33: jmp    f37 <trace_set_fs_pwd+0xf37> */
	X86_SIM_X86_JMP(0xf33, 0xf37, x86_l_f37);
x86_l_f35:
	/* 0xf35: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f37:
	/* 0xf37: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f3b:
	/* 0xf3b: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_f40:
	/* 0xf40: jmp    f6b <trace_set_fs_pwd+0xf6b> */
	X86_SIM_X86_JMP(0xf40, 0xf6b, x86_l_f6b);
x86_l_f42:
	/* 0xf42: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f47:
	/* 0xf47: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f4b:
	/* 0xf4b: jl     1582 <trace_set_fs_pwd+0x1582> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf4b, 0x1582, x86_l_1582);
x86_l_f51:
	/* 0xf51: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f54:
	/* 0xf54: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f57:
	/* 0xf57: mov    BYTE PTR [rbp+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_f5e:
	/* 0xf5e: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_f63:
	/* 0xf63: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f66:
	/* 0xf66: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f6b:
	/* 0xf6b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f6e:
	/* 0xf6e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f71:
	/* 0xf71: jns    f78 <trace_set_fs_pwd+0xf78> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf71, 0xf78, x86_l_f78);
x86_l_f73:
	/* 0xf73: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f76:
	/* 0xf76: jmp    f7a <trace_set_fs_pwd+0xf7a> */
	X86_SIM_X86_JMP(0xf76, 0xf7a, x86_l_f7a);
x86_l_f78:
	/* 0xf78: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f7a:
	/* 0xf7a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f7e:
	/* 0xf7e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f81:
	/* 0xf81: jns    f88 <trace_set_fs_pwd+0xf88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf81, 0xf88, x86_l_f88);
x86_l_f83:
	/* 0xf83: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f86:
	/* 0xf86: jmp    f8b <trace_set_fs_pwd+0xf8b> */
	X86_SIM_X86_JMP(0xf86, 0xf8b, x86_l_f8b);
x86_l_f88:
	/* 0xf88: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8b:
	/* 0xf8b: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f8e:
	/* 0xf8e: je     1023 <trace_set_fs_pwd+0x1023> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf8e, 0x1023, x86_l_1023);
x86_l_f94:
	/* 0xf94: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f97:
	/* 0xf97: je     1023 <trace_set_fs_pwd+0x1023> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf97, 0x1023, x86_l_1023);
x86_l_f9d:
	/* 0xf9d: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fa1:
	/* 0xfa1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa4:
	/* 0xfa4: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_faa:
	/* 0xfaa: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fad:
	/* 0xfad: jns    fb6 <trace_set_fs_pwd+0xfb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfad, 0xfb6, x86_l_fb6);
x86_l_faf:
	/* 0xfaf: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fb2:
	/* 0xfb2: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fb6:
	/* 0xfb6: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fba:
	/* 0xfba: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_fbd:
	/* 0xfbd: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fc4:
	/* 0xfc4: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_fc6:
	/* 0xfc6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_fc9:
	/* 0xfc9: jb     2bb6 <trace_set_fs_pwd+0x2bb6> */
	X86_SIM_X86_JCC(X86_CC_B, 0xfc9, 0x2bb6, x86_l_2bb6);
x86_l_fcf:
	/* 0xfcf: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_fd2:
	/* 0xfd2: je     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfd2, 0x1573, x86_l_1573);
x86_l_fd8:
	/* 0xfd8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_fde:
	/* 0xfde: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fe1:
	/* 0xfe1: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_fe4:
	/* 0xfe4: jns    1563 <trace_set_fs_pwd+0x1563> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfe4, 0x1563, x86_l_1563);
x86_l_fea:
	/* 0xfea: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_fef:
	/* 0xfef: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ff2:
	/* 0xff2: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ff7:
	/* 0xff7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ffb:
	/* 0xffb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ffe:
	/* 0xffe: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1001:
	/* 0x1001: je     1072 <trace_set_fs_pwd+0x1072> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1001, 0x1072, x86_l_1072);
x86_l_1003:
	/* 0x1003: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1007:
	/* 0x1007: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_100a:
	/* 0x100a: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_100f:
	/* 0x100f: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1013:
	/* 0x1013: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1016:
	/* 0x1016: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1019:
	/* 0x1019: mov    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_101c:
	/* 0x101c: jne    ffe <trace_set_fs_pwd+0xffe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x101c, 0xffe, x86_l_ffe);
x86_l_101e:
	/* 0x101e: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1021:
	/* 0x1021: jmp    1077 <trace_set_fs_pwd+0x1077> */
	X86_SIM_X86_JMP(0x1021, 0x1077, x86_l_1077);
x86_l_1023:
	/* 0x1023: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1026:
	/* 0x1026: jne    1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1026, 0x1573, x86_l_1573);
x86_l_102c:
	/* 0x102c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_102f:
	/* 0x102f: je     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102f, 0x1573, x86_l_1573);
x86_l_1035:
	/* 0x1035: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1039:
	/* 0x1039: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_103c:
	/* 0x103c: jns    1043 <trace_set_fs_pwd+0x1043> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x103c, 0x1043, x86_l_1043);
x86_l_103e:
	/* 0x103e: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1041:
	/* 0x1041: jmp    1046 <trace_set_fs_pwd+0x1046> */
	X86_SIM_X86_JMP(0x1041, 0x1046, x86_l_1046);
x86_l_1043:
	/* 0x1043: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1046:
	/* 0x1046: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1049:
	/* 0x1049: jns    1050 <trace_set_fs_pwd+0x1050> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1049, 0x1050, x86_l_1050);
x86_l_104b:
	/* 0x104b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_104e:
	/* 0x104e: jmp    1052 <trace_set_fs_pwd+0x1052> */
	X86_SIM_X86_JMP(0x104e, 0x1052, x86_l_1052);
x86_l_1050:
	/* 0x1050: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1052:
	/* 0x1052: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1055:
	/* 0x1055: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1058:
	/* 0x1058: jns    105f <trace_set_fs_pwd+0x105f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1058, 0x105f, x86_l_105f);
x86_l_105a:
	/* 0x105a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_105d:
	/* 0x105d: jmp    1061 <trace_set_fs_pwd+0x1061> */
	X86_SIM_X86_JMP(0x105d, 0x1061, x86_l_1061);
x86_l_105f:
	/* 0x105f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1061:
	/* 0x1061: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1065:
	/* 0x1065: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1068:
	/* 0x1068: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_106b:
	/* 0x106b: jns    10a7 <trace_set_fs_pwd+0x10a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x106b, 0x10a7, x86_l_10a7);
x86_l_106d:
	/* 0x106d: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1070:
	/* 0x1070: jmp    10a9 <trace_set_fs_pwd+0x10a9> */
	X86_SIM_X86_JMP(0x1070, 0x10a9, x86_l_10a9);
x86_l_1072:
	/* 0x1072: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1077:
	/* 0x1077: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_107b:
	/* 0x107b: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1080:
	/* 0x1080: jl     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1080, 0x1573, x86_l_1573);
x86_l_1086:
	/* 0x1086: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1089:
	/* 0x1089: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_108c:
	/* 0x108c: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1092:
	/* 0x1092: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1097:
	/* 0x1097: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_109a:
	/* 0x109a: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_109f:
	/* 0x109f: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10a2:
	/* 0x10a2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10a5:
	/* 0x10a5: js     106d <trace_set_fs_pwd+0x106d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10a5, 0x106d, x86_l_106d);
x86_l_10a7:
	/* 0x10a7: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10a9:
	/* 0x10a9: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10ad:
	/* 0x10ad: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10b0:
	/* 0x10b0: jns    10b7 <trace_set_fs_pwd+0x10b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b0, 0x10b7, x86_l_10b7);
x86_l_10b2:
	/* 0x10b2: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b5:
	/* 0x10b5: jmp    10b9 <trace_set_fs_pwd+0x10b9> */
	X86_SIM_X86_JMP(0x10b5, 0x10b9, x86_l_10b9);
x86_l_10b7:
	/* 0x10b7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b9:
	/* 0x10b9: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10bc:
	/* 0x10bc: je     1158 <trace_set_fs_pwd+0x1158> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10bc, 0x1158, x86_l_1158);
x86_l_10c2:
	/* 0x10c2: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10c5:
	/* 0x10c5: je     1158 <trace_set_fs_pwd+0x1158> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10c5, 0x1158, x86_l_1158);
x86_l_10cb:
	/* 0x10cb: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10cf:
	/* 0x10cf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10d2:
	/* 0x10d2: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_10d8:
	/* 0x10d8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10db:
	/* 0x10db: jns    10e4 <trace_set_fs_pwd+0x10e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10db, 0x10e4, x86_l_10e4);
x86_l_10dd:
	/* 0x10dd: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e0:
	/* 0x10e0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10e4:
	/* 0x10e4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_10e8:
	/* 0x10e8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_10eb:
	/* 0x10eb: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10f2:
	/* 0x10f2: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_10f4:
	/* 0x10f4: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10f7:
	/* 0x10f7: jb     2bb6 <trace_set_fs_pwd+0x2bb6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10f7, 0x2bb6, x86_l_2bb6);
x86_l_10fd:
	/* 0x10fd: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1100:
	/* 0x1100: je     1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1100, 0x1570, x86_l_1570);
x86_l_1106:
	/* 0x1106: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_110c:
	/* 0x110c: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_110f:
	/* 0x110f: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1112:
	/* 0x1112: jns    1566 <trace_set_fs_pwd+0x1566> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1112, 0x1566, x86_l_1566);
x86_l_1118:
	/* 0x1118: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_111d:
	/* 0x111d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1120:
	/* 0x1120: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1125:
	/* 0x1125: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1129:
	/* 0x1129: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_112c:
	/* 0x112c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_112f:
	/* 0x112f: je     148b <trace_set_fs_pwd+0x148b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x112f, 0x148b, x86_l_148b);
x86_l_1135:
	/* 0x1135: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1139:
	/* 0x1139: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_113c:
	/* 0x113c: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1141:
	/* 0x1141: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1145:
	/* 0x1145: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1148:
	/* 0x1148: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_114b:
	/* 0x114b: mov    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_114e:
	/* 0x114e: jne    112c <trace_set_fs_pwd+0x112c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x114e, 0x112c, x86_l_112c);
x86_l_1150:
	/* 0x1150: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1153:
	/* 0x1153: jmp    1490 <trace_set_fs_pwd+0x1490> */
	X86_SIM_X86_JMP(0x1153, 0x1490, x86_l_1490);
x86_l_1158:
	/* 0x1158: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_115b:
	/* 0x115b: jne    1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x115b, 0x1570, x86_l_1570);
x86_l_1161:
	/* 0x1161: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1164:
	/* 0x1164: je     1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1164, 0x1570, x86_l_1570);
x86_l_116a:
	/* 0x116a: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_116e:
	/* 0x116e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1171:
	/* 0x1171: jns    1178 <trace_set_fs_pwd+0x1178> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1171, 0x1178, x86_l_1178);
x86_l_1173:
	/* 0x1173: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1176:
	/* 0x1176: jmp    117a <trace_set_fs_pwd+0x117a> */
	X86_SIM_X86_JMP(0x1176, 0x117a, x86_l_117a);
x86_l_1178:
	/* 0x1178: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_117a:
	/* 0x117a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_117d:
	/* 0x117d: jns    1184 <trace_set_fs_pwd+0x1184> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x117d, 0x1184, x86_l_1184);
x86_l_117f:
	/* 0x117f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1182:
	/* 0x1182: jmp    1186 <trace_set_fs_pwd+0x1186> */
	X86_SIM_X86_JMP(0x1182, 0x1186, x86_l_1186);
x86_l_1184:
	/* 0x1184: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1186:
	/* 0x1186: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1189:
	/* 0x1189: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_118c:
	/* 0x118c: jns    1193 <trace_set_fs_pwd+0x1193> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x118c, 0x1193, x86_l_1193);
x86_l_118e:
	/* 0x118e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1191:
	/* 0x1191: jmp    1195 <trace_set_fs_pwd+0x1195> */
	X86_SIM_X86_JMP(0x1191, 0x1195, x86_l_1195);
x86_l_1193:
	/* 0x1193: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1195:
	/* 0x1195: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1199:
	/* 0x1199: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_119c:
	/* 0x119c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_119f:
	/* 0x119f: jns    14c4 <trace_set_fs_pwd+0x14c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x119f, 0x14c4, x86_l_14c4);
x86_l_11a5:
	/* 0x11a5: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11a8:
	/* 0x11a8: jmp    14c6 <trace_set_fs_pwd+0x14c6> */
	X86_SIM_X86_JMP(0x11a8, 0x14c6, x86_l_14c6);
x86_l_11ad:
	/* 0x11ad: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11b0:
	/* 0x11b0: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_11b7:
	/* 0x11b7: mov    DWORD PTR [rsp+0x3c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_11bb:
	/* 0x11bb: mov    DWORD PTR [rsp+0x4c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 326417514496ULL);
x86_l_11c3:
	/* 0x11c3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_11ca:
	/* 0x11ca: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_11cf:
	/* 0x11cf: call   11d4 <trace_set_fs_pwd+0x11d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11d4:
	/* 0x11d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11d7:
	/* 0x11d7: je     12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d7, 0x12d5, x86_l_12d5);
x86_l_11dd:
	/* 0x11dd: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e0:
	/* 0x11e0: mov    eax,DWORD PTR [rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_11e4:
	/* 0x11e4: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_11e8:
	/* 0x11e8: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_11ed:
	/* 0x11ed: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11f0:
	/* 0x11f0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11f2:
	/* 0x11f2: call   11f7 <trace_set_fs_pwd+0x11f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_11f7:
	/* 0x11f7: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_11fe:
	/* 0x11fe: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1203:
	/* 0x1203: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1208:
	/* 0x1208: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_120b:
	/* 0x120b: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_120e:
	/* 0x120e: call   1213 <trace_set_fs_pwd+0x1213> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1213:
	/* 0x1213: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1218:
	/* 0x1218: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_121b:
	/* 0x121b: call   1220 <trace_set_fs_pwd+0x1220> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1220:
	/* 0x1220: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1225:
	/* 0x1225: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1228:
	/* 0x1228: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_122b:
	/* 0x122b: jne    1f4 <trace_set_fs_pwd+0x1f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x122b, 0x1f4, x86_l_1f4);
x86_l_1231:
	/* 0x1231: jmp    12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JMP(0x1231, 0x12d5, x86_l_12d5);
x86_l_1236:
	/* 0x1236: mov    QWORD PTR [rsp+0x28],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_123b:
	/* 0x123b: mov    QWORD PTR [rsp+0x30],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1240:
	/* 0x1240: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_1247:
	/* 0x1247: mov    DWORD PTR [rsp+0x3c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_124b:
	/* 0x124b: mov    DWORD PTR [rsp+0x4c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 326417514496ULL);
x86_l_1253:
	/* 0x1253: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_125a:
	/* 0x125a: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_125f:
	/* 0x125f: call   1264 <trace_set_fs_pwd+0x1264> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1264:
	/* 0x1264: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1267:
	/* 0x1267: je     12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1267, 0x12d5, x86_l_12d5);
x86_l_1269:
	/* 0x1269: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_126c:
	/* 0x126c: mov    eax,DWORD PTR [rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1270:
	/* 0x1270: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1274:
	/* 0x1274: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_1279:
	/* 0x1279: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_127c:
	/* 0x127c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_127e:
	/* 0x127e: call   1283 <trace_set_fs_pwd+0x1283> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_1283:
	/* 0x1283: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_128a:
	/* 0x128a: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_128f:
	/* 0x128f: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1294:
	/* 0x1294: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1297:
	/* 0x1297: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_129a:
	/* 0x129a: call   129f <trace_set_fs_pwd+0x129f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_129f:
	/* 0x129f: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_12a4:
	/* 0x12a4: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12a7:
	/* 0x12a7: call   12ac <trace_set_fs_pwd+0x12ac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12ac:
	/* 0x12ac: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12b1:
	/* 0x12b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12b4:
	/* 0x12b4: je     12d5 <trace_set_fs_pwd+0x12d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12b4, 0x12d5, x86_l_12d5);
x86_l_12b6:
	/* 0x12b6: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_12bd:
	/* 0x12bd: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12c1:
	/* 0x12c1: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12c4:
	/* 0x12c4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12c7:
	/* 0x12c7: jns    1620 <trace_set_fs_pwd+0x1620> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12c7, 0x1620, x86_l_1620);
x86_l_12cd:
	/* 0x12cd: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12d0:
	/* 0x12d0: jmp    1623 <trace_set_fs_pwd+0x1623> */
	X86_SIM_X86_JMP(0x12d0, 0x1623, x86_l_1623);
x86_l_12d5:
	/* 0x12d5: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12d8:
	/* 0x12d8: jmp    32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JMP(0x12d8, 0x32bd, x86_l_32bd);
x86_l_12dd:
	/* 0x12dd: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_12e0:
	/* 0x12e0: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_12e4:
	/* 0x12e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12e7:
	/* 0x12e7: jns    1602 <trace_set_fs_pwd+0x1602> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12e7, 0x1602, x86_l_1602);
x86_l_12ed:
	/* 0x12ed: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12f0:
	/* 0x12f0: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_12f7:
	/* 0x12f7: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12fb:
	/* 0x12fb: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1302:
	/* 0x1302: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1306:
	/* 0x1306: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_130d:
	/* 0x130d: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1311:
	/* 0x1311: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1318:
	/* 0x1318: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_131c:
	/* 0x131c: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_1323:
	/* 0x1323: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1327:
	/* 0x1327: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_132e:
	/* 0x132e: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1332:
	/* 0x1332: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1339:
	/* 0x1339: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_133d:
	/* 0x133d: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_1344:
	/* 0x1344: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1348:
	/* 0x1348: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_134f:
	/* 0x134f: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1353:
	/* 0x1353: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_135a:
	/* 0x135a: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_135e:
	/* 0x135e: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_1365:
	/* 0x1365: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1369:
	/* 0x1369: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1370:
	/* 0x1370: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1374:
	/* 0x1374: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_137b:
	/* 0x137b: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_137f:
	/* 0x137f: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1386:
	/* 0x1386: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_138a:
	/* 0x138a: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1391:
	/* 0x1391: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1395:
	/* 0x1395: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_139c:
	/* 0x139c: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_13a3:
	/* 0x13a3: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_13aa:
	/* 0x13aa: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_13b1:
	/* 0x13b1: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_13b8:
	/* 0x13b8: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_13bf:
	/* 0x13bf: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_13c6:
	/* 0x13c6: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_13cd:
	/* 0x13cd: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_13d4:
	/* 0x13d4: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_13db:
	/* 0x13db: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_13e2:
	/* 0x13e2: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_13e9:
	/* 0x13e9: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_13f0:
	/* 0x13f0: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_13f7:
	/* 0x13f7: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_13fe:
	/* 0x13fe: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1405:
	/* 0x1405: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_140c:
	/* 0x140c: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1413:
	/* 0x1413: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_141a:
	/* 0x141a: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1421:
	/* 0x1421: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1428:
	/* 0x1428: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_142f:
	/* 0x142f: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_1436:
	/* 0x1436: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_143d:
	/* 0x143d: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_1444:
	/* 0x1444: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_144b:
	/* 0x144b: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1452:
	/* 0x1452: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1459:
	/* 0x1459: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1460:
	/* 0x1460: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1467:
	/* 0x1467: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_146e:
	/* 0x146e: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1475:
	/* 0x1475: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_147c:
	/* 0x147c: movzx  eax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1481:
	/* 0x1481: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1486:
	/* 0x1486: jmp    2cd <trace_set_fs_pwd+0x2cd> */
	X86_SIM_X86_JMP(0x1486, 0x2cd, x86_l_2cd);
x86_l_148b:
	/* 0x148b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1490:
	/* 0x1490: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1494:
	/* 0x1494: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1499:
	/* 0x1499: jl     1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1499, 0x1570, x86_l_1570);
x86_l_149f:
	/* 0x149f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a2:
	/* 0x14a2: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_14a5:
	/* 0x14a5: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_14ab:
	/* 0x14ab: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_14b0:
	/* 0x14b0: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_14b3:
	/* 0x14b3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_14b8:
	/* 0x14b8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14bb:
	/* 0x14bb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14be:
	/* 0x14be: js     11a5 <trace_set_fs_pwd+0x11a5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14be, 0x11a5, x86_l_11a5);
x86_l_14c4:
	/* 0x14c4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14c6:
	/* 0x14c6: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14ca:
	/* 0x14ca: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_14cd:
	/* 0x14cd: jns    14d4 <trace_set_fs_pwd+0x14d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14cd, 0x14d4, x86_l_14d4);
x86_l_14cf:
	/* 0x14cf: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14d2:
	/* 0x14d2: jmp    14d7 <trace_set_fs_pwd+0x14d7> */
	X86_SIM_X86_JMP(0x14d2, 0x14d7, x86_l_14d7);
x86_l_14d4:
	/* 0x14d4: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14d7:
	/* 0x14d7: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14da:
	/* 0x14da: je     15e3 <trace_set_fs_pwd+0x15e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14da, 0x15e3, x86_l_15e3);
x86_l_14e0:
	/* 0x14e0: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_14e3:
	/* 0x14e3: je     15e3 <trace_set_fs_pwd+0x15e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e3, 0x15e3, x86_l_15e3);
x86_l_14e9:
	/* 0x14e9: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14ed:
	/* 0x14ed: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14f0:
	/* 0x14f0: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_14f6:
	/* 0x14f6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14f9:
	/* 0x14f9: jns    1502 <trace_set_fs_pwd+0x1502> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14f9, 0x1502, x86_l_1502);
x86_l_14fb:
	/* 0x14fb: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14fe:
	/* 0x14fe: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1502:
	/* 0x1502: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1506:
	/* 0x1506: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1509:
	/* 0x1509: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1510:
	/* 0x1510: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1512:
	/* 0x1512: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1515:
	/* 0x1515: jb     2bb6 <trace_set_fs_pwd+0x2bb6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1515, 0x2bb6, x86_l_2bb6);
x86_l_151b:
	/* 0x151b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_151e:
	/* 0x151e: je     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_E, 0x151e, 0x1573, x86_l_1573);
x86_l_1520:
	/* 0x1520: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1526:
	/* 0x1526: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1529:
	/* 0x1529: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_152c:
	/* 0x152c: jns    1563 <trace_set_fs_pwd+0x1563> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x152c, 0x1563, x86_l_1563);
x86_l_152e:
	/* 0x152e: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1533:
	/* 0x1533: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1536:
	/* 0x1536: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_153a:
	/* 0x153a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_153d:
	/* 0x153d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1540:
	/* 0x1540: je     1a78 <trace_set_fs_pwd+0x1a78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1540, 0x1a78, x86_l_1a78);
x86_l_1546:
	/* 0x1546: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_154a:
	/* 0x154a: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_154f:
	/* 0x154f: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1553:
	/* 0x1553: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1556:
	/* 0x1556: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1559:
	/* 0x1559: jne    153d <trace_set_fs_pwd+0x153d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1559, 0x153d, x86_l_153d);
x86_l_155b:
	/* 0x155b: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_155e:
	/* 0x155e: jmp    1a7d <trace_set_fs_pwd+0x1a7d> */
	X86_SIM_X86_JMP(0x155e, 0x1a7d, x86_l_1a7d);
x86_l_1563:
	/* 0x1563: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1566:
	/* 0x1566: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1569:
	/* 0x1569: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156b:
	/* 0x156b: call   1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1570:
	/* 0x1570: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1573:
	/* 0x1573: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1576:
	/* 0x1576: cmp    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_157c:
	/* 0x157c: jne    2bb6 <trace_set_fs_pwd+0x2bb6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x157c, 0x2bb6, x86_l_2bb6);
x86_l_1582:
	/* 0x1582: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1586:
	/* 0x1586: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1589:
	/* 0x1589: jns    15ad <trace_set_fs_pwd+0x15ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1589, 0x15ad, x86_l_15ad);
x86_l_158b:
	/* 0x158b: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158e:
	/* 0x158e: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1592:
	/* 0x1592: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1595:
	/* 0x1595: js     15b4 <trace_set_fs_pwd+0x15b4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1595, 0x15b4, x86_l_15b4);
x86_l_1597:
	/* 0x1597: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1599:
	/* 0x1599: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_159e:
	/* 0x159e: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_15a1:
	/* 0x15a1: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a3:
	/* 0x15a3: call   15a8 <trace_set_fs_pwd+0x15a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_15a8:
	/* 0x15a8: jmp    2bcb <trace_set_fs_pwd+0x2bcb> */
	X86_SIM_X86_JMP(0x15a8, 0x2bcb, x86_l_2bcb);
x86_l_15ad:
	/* 0x15ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15af:
	/* 0x15af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15b2:
	/* 0x15b2: jns    1597 <trace_set_fs_pwd+0x1597> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15b2, 0x1597, x86_l_1597);
x86_l_15b4:
	/* 0x15b4: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15b6:
	/* 0x15b6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15b8:
	/* 0x15b8: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_15bf:
	/* 0x15bf: je     15d5 <trace_set_fs_pwd+0x15d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15bf, 0x15d5, x86_l_15d5);
x86_l_15c1:
	/* 0x15c1: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_15c5:
	/* 0x15c5: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_15c9:
	/* 0x15c9: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_15cc:
	/* 0x15cc: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_15ce:
	/* 0x15ce: jne    15b8 <trace_set_fs_pwd+0x15b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15ce, 0x15b8, x86_l_15b8);
x86_l_15d0:
	/* 0x15d0: jmp    2bcb <trace_set_fs_pwd+0x2bcb> */
	X86_SIM_X86_JMP(0x15d0, 0x2bcb, x86_l_2bcb);
x86_l_15d5:
	/* 0x15d5: mov    BYTE PTR [rbp+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_15dc:
	/* 0x15dc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15de:
	/* 0x15de: jmp    2bcb <trace_set_fs_pwd+0x2bcb> */
	X86_SIM_X86_JMP(0x15de, 0x2bcb, x86_l_2bcb);
x86_l_15e3:
	/* 0x15e3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15e6:
	/* 0x15e6: jne    1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15e6, 0x1573, x86_l_1573);
x86_l_15e8:
	/* 0x15e8: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15eb:
	/* 0x15eb: je     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15eb, 0x1573, x86_l_1573);
x86_l_15ed:
	/* 0x15ed: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15f1:
	/* 0x15f1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15f4:
	/* 0x15f4: jns    1771 <trace_set_fs_pwd+0x1771> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15f4, 0x1771, x86_l_1771);
x86_l_15fa:
	/* 0x15fa: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15fd:
	/* 0x15fd: jmp    1774 <trace_set_fs_pwd+0x1774> */
	X86_SIM_X86_JMP(0x15fd, 0x1774, x86_l_1774);
x86_l_1602:
	/* 0x1602: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1609:
	/* 0x1609: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_160c:
	/* 0x160c: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1611:
	/* 0x1611: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1614:
	/* 0x1614: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1616:
	/* 0x1616: call   161b <trace_set_fs_pwd+0x161b> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_161b:
	/* 0x161b: jmp    32bd <trace_set_fs_pwd+0x32bd> */
	X86_SIM_X86_JMP(0x161b, 0x32bd, x86_l_32bd);
x86_l_1620:
	/* 0x1620: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1623:
	/* 0x1623: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1627:
	/* 0x1627: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_162a:
	/* 0x162a: jns    1631 <trace_set_fs_pwd+0x1631> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162a, 0x1631, x86_l_1631);
x86_l_162c:
	/* 0x162c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162f:
	/* 0x162f: jmp    1633 <trace_set_fs_pwd+0x1633> */
	X86_SIM_X86_JMP(0x162f, 0x1633, x86_l_1633);
x86_l_1631:
	/* 0x1631: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1633:
	/* 0x1633: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1637:
	/* 0x1637: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1639:
	/* 0x1639: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_163c:
	/* 0x163c: jns    1643 <trace_set_fs_pwd+0x1643> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x163c, 0x1643, x86_l_1643);
x86_l_163e:
	/* 0x163e: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1641:
	/* 0x1641: jmp    1646 <trace_set_fs_pwd+0x1646> */
	X86_SIM_X86_JMP(0x1641, 0x1646, x86_l_1646);
x86_l_1643:
	/* 0x1643: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1646:
	/* 0x1646: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_164b:
	/* 0x164b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_164e:
	/* 0x164e: jns    1652 <trace_set_fs_pwd+0x1652> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x164e, 0x1652, x86_l_1652);
x86_l_1650:
	/* 0x1650: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1652:
	/* 0x1652: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1657:
	/* 0x1657: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_165a:
	/* 0x165a: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_165e:
	/* 0x165e: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1661:
	/* 0x1661: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1663:
	/* 0x1663: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1666:
	/* 0x1666: jns    166d <trace_set_fs_pwd+0x166d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1666, 0x166d, x86_l_166d);
x86_l_1668:
	/* 0x1668: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_166b:
	/* 0x166b: jmp    166f <trace_set_fs_pwd+0x166f> */
	X86_SIM_X86_JMP(0x166b, 0x166f, x86_l_166f);
x86_l_166d:
	/* 0x166d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_166f:
	/* 0x166f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1672:
	/* 0x1672: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1675:
	/* 0x1675: jns    1679 <trace_set_fs_pwd+0x1679> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1675, 0x1679, x86_l_1679);
x86_l_1677:
	/* 0x1677: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1679:
	/* 0x1679: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_167b:
	/* 0x167b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_167f:
	/* 0x167f: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1682:
	/* 0x1682: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1686:
	/* 0x1686: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1688:
	/* 0x1688: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_168b:
	/* 0x168b: jns    168f <trace_set_fs_pwd+0x168f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x168b, 0x168f, x86_l_168f);
x86_l_168d:
	/* 0x168d: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_168f:
	/* 0x168f: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1694:
	/* 0x1694: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1697:
	/* 0x1697: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_169a:
	/* 0x169a: jns    16a1 <trace_set_fs_pwd+0x16a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x169a, 0x16a1, x86_l_16a1);
x86_l_169c:
	/* 0x169c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_169f:
	/* 0x169f: jmp    16a3 <trace_set_fs_pwd+0x16a3> */
	X86_SIM_X86_JMP(0x169f, 0x16a3, x86_l_16a3);
x86_l_16a1:
	/* 0x16a1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a3:
	/* 0x16a3: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_16a7:
	/* 0x16a7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a9:
	/* 0x16a9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16ac:
	/* 0x16ac: jns    16b3 <trace_set_fs_pwd+0x16b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ac, 0x16b3, x86_l_16b3);
x86_l_16ae:
	/* 0x16ae: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16b1:
	/* 0x16b1: jmp    16b5 <trace_set_fs_pwd+0x16b5> */
	X86_SIM_X86_JMP(0x16b1, 0x16b5, x86_l_16b5);
x86_l_16b3:
	/* 0x16b3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16b5:
	/* 0x16b5: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16b8:
	/* 0x16b8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16bb:
	/* 0x16bb: jns    16bf <trace_set_fs_pwd+0x16bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16bb, 0x16bf, x86_l_16bf);
x86_l_16bd:
	/* 0x16bd: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16bf:
	/* 0x16bf: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16c1:
	/* 0x16c1: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16c5:
	/* 0x16c5: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16c8:
	/* 0x16c8: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16cc:
	/* 0x16cc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ce:
	/* 0x16ce: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16d1:
	/* 0x16d1: jns    16d5 <trace_set_fs_pwd+0x16d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16d1, 0x16d5, x86_l_16d5);
x86_l_16d3:
	/* 0x16d3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16d5:
	/* 0x16d5: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_16da:
	/* 0x16da: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16dd:
	/* 0x16dd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16df:
	/* 0x16df: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16e2:
	/* 0x16e2: jns    16e9 <trace_set_fs_pwd+0x16e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e2, 0x16e9, x86_l_16e9);
x86_l_16e4:
	/* 0x16e4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e7:
	/* 0x16e7: jmp    16eb <trace_set_fs_pwd+0x16eb> */
	X86_SIM_X86_JMP(0x16e7, 0x16eb, x86_l_16eb);
x86_l_16e9:
	/* 0x16e9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16eb:
	/* 0x16eb: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16ee:
	/* 0x16ee: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16f1:
	/* 0x16f1: jns    16f5 <trace_set_fs_pwd+0x16f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f1, 0x16f5, x86_l_16f5);
x86_l_16f3:
	/* 0x16f3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16f5:
	/* 0x16f5: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_16f7:
	/* 0x16f7: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16fb:
	/* 0x16fb: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16fe:
	/* 0x16fe: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1702:
	/* 0x1702: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1704:
	/* 0x1704: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1707:
	/* 0x1707: jns    170e <trace_set_fs_pwd+0x170e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1707, 0x170e, x86_l_170e);
x86_l_1709:
	/* 0x1709: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_170c:
	/* 0x170c: jmp    1710 <trace_set_fs_pwd+0x1710> */
	X86_SIM_X86_JMP(0x170c, 0x1710, x86_l_1710);
x86_l_170e:
	/* 0x170e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1710:
	/* 0x1710: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1714:
	/* 0x1714: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1717:
	/* 0x1717: jns    171b <trace_set_fs_pwd+0x171b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1717, 0x171b, x86_l_171b);
x86_l_1719:
	/* 0x1719: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_171b:
	/* 0x171b: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1720:
	/* 0x1720: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1723:
	/* 0x1723: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1725:
	/* 0x1725: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1728:
	/* 0x1728: jns    172f <trace_set_fs_pwd+0x172f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1728, 0x172f, x86_l_172f);
x86_l_172a:
	/* 0x172a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_172d:
	/* 0x172d: jmp    1731 <trace_set_fs_pwd+0x1731> */
	X86_SIM_X86_JMP(0x172d, 0x1731, x86_l_1731);
x86_l_172f:
	/* 0x172f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1731:
	/* 0x1731: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1734:
	/* 0x1734: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1737:
	/* 0x1737: jns    173b <trace_set_fs_pwd+0x173b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1737, 0x173b, x86_l_173b);
x86_l_1739:
	/* 0x1739: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_173b:
	/* 0x173b: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_173d:
	/* 0x173d: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1741:
	/* 0x1741: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1744:
	/* 0x1744: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1748:
	/* 0x1748: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174a:
	/* 0x174a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_174d:
	/* 0x174d: jns    1754 <trace_set_fs_pwd+0x1754> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x174d, 0x1754, x86_l_1754);
x86_l_174f:
	/* 0x174f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1752:
	/* 0x1752: jmp    1756 <trace_set_fs_pwd+0x1756> */
	X86_SIM_X86_JMP(0x1752, 0x1756, x86_l_1756);
x86_l_1754:
	/* 0x1754: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1756:
	/* 0x1756: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_175a:
	/* 0x175a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_175d:
	/* 0x175d: jns    1761 <trace_set_fs_pwd+0x1761> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175d, 0x1761, x86_l_1761);
x86_l_175f:
	/* 0x175f: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1761:
	/* 0x1761: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1763:
	/* 0x1763: jne    17d1 <trace_set_fs_pwd+0x17d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1763, 0x17d1, x86_l_17d1);
x86_l_1765:
	/* 0x1765: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1767:
	/* 0x1767: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_176a:
	/* 0x176a: jns    17a7 <trace_set_fs_pwd+0x17a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x176a, 0x17a7, x86_l_17a7);
x86_l_176c:
	/* 0x176c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_176f:
	/* 0x176f: jmp    17a9 <trace_set_fs_pwd+0x17a9> */
	X86_SIM_X86_JMP(0x176f, 0x17a9, x86_l_17a9);
x86_l_1771:
	/* 0x1771: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1774:
	/* 0x1774: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1777:
	/* 0x1777: jns    177e <trace_set_fs_pwd+0x177e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1777, 0x177e, x86_l_177e);
x86_l_1779:
	/* 0x1779: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_177c:
	/* 0x177c: jmp    1780 <trace_set_fs_pwd+0x1780> */
	X86_SIM_X86_JMP(0x177c, 0x1780, x86_l_1780);
x86_l_177e:
	/* 0x177e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1780:
	/* 0x1780: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1783:
	/* 0x1783: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1786:
	/* 0x1786: jns    178d <trace_set_fs_pwd+0x178d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1786, 0x178d, x86_l_178d);
x86_l_1788:
	/* 0x1788: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_178b:
	/* 0x178b: jmp    178f <trace_set_fs_pwd+0x178f> */
	X86_SIM_X86_JMP(0x178b, 0x178f, x86_l_178f);
x86_l_178d:
	/* 0x178d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_178f:
	/* 0x178f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1793:
	/* 0x1793: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1796:
	/* 0x1796: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1799:
	/* 0x1799: jns    1ab1 <trace_set_fs_pwd+0x1ab1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1799, 0x1ab1, x86_l_1ab1);
x86_l_179f:
	/* 0x179f: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a2:
	/* 0x17a2: jmp    1ab3 <trace_set_fs_pwd+0x1ab3> */
	X86_SIM_X86_JMP(0x17a2, 0x1ab3, x86_l_1ab3);
x86_l_17a7:
	/* 0x17a7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a9:
	/* 0x17a9: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17ac:
	/* 0x17ac: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17af:
	/* 0x17af: jns    17b3 <trace_set_fs_pwd+0x17b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17af, 0x17b3, x86_l_17b3);
x86_l_17b1:
	/* 0x17b1: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b3:
	/* 0x17b3: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17b5:
	/* 0x17b5: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_17b9:
	/* 0x17b9: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17bc:
	/* 0x17bc: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17c0:
	/* 0x17c0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17c2:
	/* 0x17c2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17c5:
	/* 0x17c5: jns    17c9 <trace_set_fs_pwd+0x17c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c5, 0x17c9, x86_l_17c9);
x86_l_17c7:
	/* 0x17c7: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c9:
	/* 0x17c9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17ce:
	/* 0x17ce: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17d1:
	/* 0x17d1: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17d6:
	/* 0x17d6: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17db:
	/* 0x17db: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_17de:
	/* 0x17de: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_17e5:
	/* 0x17e5: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17e8:
	/* 0x17e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17eb:
	/* 0x17eb: jns    17f2 <trace_set_fs_pwd+0x17f2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17eb, 0x17f2, x86_l_17f2);
x86_l_17ed:
	/* 0x17ed: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17f0:
	/* 0x17f0: jmp    17f4 <trace_set_fs_pwd+0x17f4> */
	X86_SIM_X86_JMP(0x17f0, 0x17f4, x86_l_17f4);
x86_l_17f2:
	/* 0x17f2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f4:
	/* 0x17f4: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_17f8:
	/* 0x17f8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17fa:
	/* 0x17fa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17fd:
	/* 0x17fd: jns    1804 <trace_set_fs_pwd+0x1804> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17fd, 0x1804, x86_l_1804);
x86_l_17ff:
	/* 0x17ff: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1802:
	/* 0x1802: jmp    1806 <trace_set_fs_pwd+0x1806> */
	X86_SIM_X86_JMP(0x1802, 0x1806, x86_l_1806);
x86_l_1804:
	/* 0x1804: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1806:
	/* 0x1806: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1809:
	/* 0x1809: jns    180d <trace_set_fs_pwd+0x180d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1809, 0x180d, x86_l_180d);
x86_l_180b:
	/* 0x180b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180d:
	/* 0x180d: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1812:
	/* 0x1812: mov    DWORD PTR [rbp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1815:
	/* 0x1815: call   181a <trace_set_fs_pwd+0x181a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_181a:
	/* 0x181a: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_181d:
	/* 0x181d: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1821:
	/* 0x1821: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1824:
	/* 0x1824: jns    182b <trace_set_fs_pwd+0x182b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1824, 0x182b, x86_l_182b);
x86_l_1826:
	/* 0x1826: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1829:
	/* 0x1829: jmp    182d <trace_set_fs_pwd+0x182d> */
	X86_SIM_X86_JMP(0x1829, 0x182d, x86_l_182d);
x86_l_182b:
	/* 0x182b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_182d:
	/* 0x182d: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1832:
	/* 0x1832: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1835:
	/* 0x1835: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1839:
	/* 0x1839: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_183c:
	/* 0x183c: jns    1843 <trace_set_fs_pwd+0x1843> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x183c, 0x1843, x86_l_1843);
x86_l_183e:
	/* 0x183e: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1841:
	/* 0x1841: jmp    1845 <trace_set_fs_pwd+0x1845> */
	X86_SIM_X86_JMP(0x1841, 0x1845, x86_l_1845);
x86_l_1843:
	/* 0x1843: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1845:
	/* 0x1845: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_184a:
	/* 0x184a: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_184f:
	/* 0x184f: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1853:
	/* 0x1853: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1857:
	/* 0x1857: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_185a:
	/* 0x185a: jns    1862 <trace_set_fs_pwd+0x1862> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x185a, 0x1862, x86_l_1862);
x86_l_185c:
	/* 0x185c: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1860:
	/* 0x1860: jmp    1864 <trace_set_fs_pwd+0x1864> */
	X86_SIM_X86_JMP(0x1860, 0x1864, x86_l_1864);
x86_l_1862:
	/* 0x1862: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1864:
	/* 0x1864: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1869:
	/* 0x1869: mov    QWORD PTR [r12+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_186e:
	/* 0x186e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1871:
	/* 0x1871: jns    187f <trace_set_fs_pwd+0x187f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1871, 0x187f, x86_l_187f);
x86_l_1873:
	/* 0x1873: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1875:
	/* 0x1875: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1877:
	/* 0x1877: je     187f <trace_set_fs_pwd+0x187f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1877, 0x187f, x86_l_187f);
x86_l_1879:
	/* 0x1879: or     BYTE PTR [r12+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_187f:
	/* 0x187f: lea    rdi,[r12+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1884:
	/* 0x1884: mov    QWORD PTR [r12+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_188d:
	/* 0x188d: mov    QWORD PTR [r12+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_1896:
	/* 0x1896: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_189b:
	/* 0x189b: call   18a0 <trace_set_fs_pwd+0x18a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_18a0:
	/* 0x18a0: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18a3:
	/* 0x18a3: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18a6:
	/* 0x18a6: jns    18ae <trace_set_fs_pwd+0x18ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18a6, 0x18ae, x86_l_18ae);
x86_l_18a8:
	/* 0x18a8: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ac:
	/* 0x18ac: jmp    18b0 <trace_set_fs_pwd+0x18b0> */
	X86_SIM_X86_JMP(0x18ac, 0x18b0, x86_l_18b0);
x86_l_18ae:
	/* 0x18ae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b0:
	/* 0x18b0: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18b5:
	/* 0x18b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18b8:
	/* 0x18b8: jns    18bf <trace_set_fs_pwd+0x18bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18b8, 0x18bf, x86_l_18bf);
x86_l_18ba:
	/* 0x18ba: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18bd:
	/* 0x18bd: jmp    18c1 <trace_set_fs_pwd+0x18c1> */
	X86_SIM_X86_JMP(0x18bd, 0x18c1, x86_l_18c1);
x86_l_18bf:
	/* 0x18bf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c1:
	/* 0x18c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c4:
	/* 0x18c4: jns    1917 <trace_set_fs_pwd+0x1917> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c4, 0x1917, x86_l_1917);
x86_l_18c6:
	/* 0x18c6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18c9:
	/* 0x18c9: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18ce:
	/* 0x18ce: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18d2:
	/* 0x18d2: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18d7:
	/* 0x18d7: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18db:
	/* 0x18db: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_18e0:
	/* 0x18e0: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18e4:
	/* 0x18e4: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_18e9:
	/* 0x18e9: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18ed:
	/* 0x18ed: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_18f2:
	/* 0x18f2: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18f6:
	/* 0x18f6: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_18fb:
	/* 0x18fb: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18ff:
	/* 0x18ff: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1907:
	/* 0x1907: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_190b:
	/* 0x190b: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1913:
	/* 0x1913: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1917:
	/* 0x1917: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_191a:
	/* 0x191a: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_191e:
	/* 0x191e: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1923:
	/* 0x1923: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1926:
	/* 0x1926: jns    1a5f <trace_set_fs_pwd+0x1a5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1926, 0x1a5f, x86_l_1a5f);
x86_l_192c:
	/* 0x192c: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_192f:
	/* 0x192f: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1931:
	/* 0x1931: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1933:
	/* 0x1933: je     1a6e <trace_set_fs_pwd+0x1a6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1933, 0x1a6e, x86_l_1a6e);
x86_l_1939:
	/* 0x1939: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_193d:
	/* 0x193d: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_1940:
	/* 0x1940: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1942:
	/* 0x1942: je     1a6e <trace_set_fs_pwd+0x1a6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1942, 0x1a6e, x86_l_1a6e);
x86_l_1948:
	/* 0x1948: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_194c:
	/* 0x194c: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_194f:
	/* 0x194f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1951:
	/* 0x1951: je     1a6e <trace_set_fs_pwd+0x1a6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1951, 0x1a6e, x86_l_1a6e);
x86_l_1957:
	/* 0x1957: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_195b:
	/* 0x195b: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_195e:
	/* 0x195e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1960:
	/* 0x1960: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1960, 0x1b9f, x86_l_1b9f);
x86_l_1966:
	/* 0x1966: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_196a:
	/* 0x196a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_196f:
	/* 0x196f: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1972:
	/* 0x1972: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1974:
	/* 0x1974: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1974, 0x1b9f, x86_l_1b9f);
x86_l_197a:
	/* 0x197a: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_197e:
	/* 0x197e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1983:
	/* 0x1983: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_1986:
	/* 0x1986: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1988:
	/* 0x1988: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1988, 0x1b9f, x86_l_1b9f);
x86_l_198e:
	/* 0x198e: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1992:
	/* 0x1992: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1997:
	/* 0x1997: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_199a:
	/* 0x199a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_199c:
	/* 0x199c: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x199c, 0x1b9f, x86_l_1b9f);
x86_l_19a2:
	/* 0x19a2: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_19a6:
	/* 0x19a6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19ab:
	/* 0x19ab: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_19ae:
	/* 0x19ae: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19b0:
	/* 0x19b0: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b0, 0x1b9f, x86_l_1b9f);
x86_l_19b6:
	/* 0x19b6: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19ba:
	/* 0x19ba: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19bf:
	/* 0x19bf: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_19c2:
	/* 0x19c2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19c4:
	/* 0x19c4: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c4, 0x1b9f, x86_l_1b9f);
x86_l_19ca:
	/* 0x19ca: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_19ce:
	/* 0x19ce: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19d3:
	/* 0x19d3: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_19d6:
	/* 0x19d6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19d8:
	/* 0x19d8: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d8, 0x1b9f, x86_l_1b9f);
x86_l_19de:
	/* 0x19de: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_19e2:
	/* 0x19e2: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19e7:
	/* 0x19e7: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_19ea:
	/* 0x19ea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19ec:
	/* 0x19ec: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ec, 0x1b9f, x86_l_1b9f);
x86_l_19f2:
	/* 0x19f2: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_19f6:
	/* 0x19f6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19fb:
	/* 0x19fb: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_19fe:
	/* 0x19fe: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a00:
	/* 0x1a00: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a00, 0x1b9f, x86_l_1b9f);
x86_l_1a06:
	/* 0x1a06: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1a0a:
	/* 0x1a0a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a0f:
	/* 0x1a0f: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a12:
	/* 0x1a12: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a14:
	/* 0x1a14: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a14, 0x1b9f, x86_l_1b9f);
x86_l_1a1a:
	/* 0x1a1a: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1a1e:
	/* 0x1a1e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a23:
	/* 0x1a23: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1a26:
	/* 0x1a26: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a28:
	/* 0x1a28: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a28, 0x1b9f, x86_l_1b9f);
x86_l_1a2e:
	/* 0x1a2e: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1a32:
	/* 0x1a32: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a37:
	/* 0x1a37: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1a3a:
	/* 0x1a3a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a3c:
	/* 0x1a3c: je     1b9f <trace_set_fs_pwd+0x1b9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a3c, 0x1b9f, x86_l_1b9f);
x86_l_1a42:
	/* 0x1a42: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a47:
	/* 0x1a47: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_1a4b:
	/* 0x1a4b: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a50:
	/* 0x1a50: mov    r13,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a55:
	/* 0x1a55: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a5a:
	/* 0x1a5a: jmp    21f <trace_set_fs_pwd+0x21f> */
	X86_SIM_X86_JMP(0x1a5a, 0x21f, x86_l_21f);
x86_l_1a5f:
	/* 0x1a5f: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1a67:
	/* 0x1a67: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a6e:
	/* 0x1a6e: mov    r13,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a73:
	/* 0x1a73: jmp    21f <trace_set_fs_pwd+0x21f> */
	X86_SIM_X86_JMP(0x1a73, 0x21f, x86_l_21f);
x86_l_1a78:
	/* 0x1a78: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a7d:
	/* 0x1a7d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a81:
	/* 0x1a81: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a86:
	/* 0x1a86: mov    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a89:
	/* 0x1a89: jl     1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a89, 0x1573, x86_l_1573);
x86_l_1a8f:
	/* 0x1a8f: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a92:
	/* 0x1a92: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1a98:
	/* 0x1a98: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1a9d:
	/* 0x1a9d: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1aa0:
	/* 0x1aa0: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1aa5:
	/* 0x1aa5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1aa8:
	/* 0x1aa8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1aab:
	/* 0x1aab: js     179f <trace_set_fs_pwd+0x179f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1aab, 0x179f, x86_l_179f);
x86_l_1ab1:
	/* 0x1ab1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ab3:
	/* 0x1ab3: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ab7:
	/* 0x1ab7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1aba:
	/* 0x1aba: jns    1ac1 <trace_set_fs_pwd+0x1ac1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aba, 0x1ac1, x86_l_1ac1);
x86_l_1abc:
	/* 0x1abc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1abf:
	/* 0x1abf: jmp    1ac3 <trace_set_fs_pwd+0x1ac3> */
	X86_SIM_X86_JMP(0x1abf, 0x1ac3, x86_l_1ac3);
x86_l_1ac1:
	/* 0x1ac1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac3:
	/* 0x1ac3: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ac6:
	/* 0x1ac6: je     1b51 <trace_set_fs_pwd+0x1b51> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac6, 0x1b51, x86_l_1b51);
x86_l_1acc:
	/* 0x1acc: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1acf:
	/* 0x1acf: je     1b51 <trace_set_fs_pwd+0x1b51> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1acf, 0x1b51, x86_l_1b51);
x86_l_1ad5:
	/* 0x1ad5: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ad9:
	/* 0x1ad9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1adc:
	/* 0x1adc: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ae2:
	/* 0x1ae2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ae5:
	/* 0x1ae5: jns    1aee <trace_set_fs_pwd+0x1aee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ae5, 0x1aee, x86_l_1aee);
x86_l_1ae7:
	/* 0x1ae7: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aea:
	/* 0x1aea: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aee:
	/* 0x1aee: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1af2:
	/* 0x1af2: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1af5:
	/* 0x1af5: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1afc:
	/* 0x1afc: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1afe:
	/* 0x1afe: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b01:
	/* 0x1b01: jb     2bb6 <trace_set_fs_pwd+0x2bb6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b01, 0x2bb6, x86_l_2bb6);
x86_l_1b07:
	/* 0x1b07: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1b0a:
	/* 0x1b0a: je     1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b0a, 0x1570, x86_l_1570);
x86_l_1b10:
	/* 0x1b10: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b16:
	/* 0x1b16: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b19:
	/* 0x1b19: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1b1c:
	/* 0x1b1c: jns    1566 <trace_set_fs_pwd+0x1566> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1c, 0x1566, x86_l_1566);
x86_l_1b22:
	/* 0x1b22: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b27:
	/* 0x1b27: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b2b:
	/* 0x1b2b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b2e:
	/* 0x1b2e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b31:
	/* 0x1b31: je     1bb8 <trace_set_fs_pwd+0x1bb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b31, 0x1bb8, x86_l_1bb8);
x86_l_1b37:
	/* 0x1b37: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b3b:
	/* 0x1b3b: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b40:
	/* 0x1b40: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b44:
	/* 0x1b44: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1b47:
	/* 0x1b47: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1b4a:
	/* 0x1b4a: jne    1b2e <trace_set_fs_pwd+0x1b2e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b4a, 0x1b2e, x86_l_1b2e);
x86_l_1b4c:
	/* 0x1b4c: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1b4f:
	/* 0x1b4f: jmp    1bbd <trace_set_fs_pwd+0x1bbd> */
	X86_SIM_X86_JMP(0x1b4f, 0x1bbd, x86_l_1bbd);
x86_l_1b51:
	/* 0x1b51: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b54:
	/* 0x1b54: jne    1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b54, 0x1570, x86_l_1570);
x86_l_1b5a:
	/* 0x1b5a: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b5d:
	/* 0x1b5d: je     1570 <trace_set_fs_pwd+0x1570> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5d, 0x1570, x86_l_1570);
x86_l_1b63:
	/* 0x1b63: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b67:
	/* 0x1b67: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b6a:
	/* 0x1b6a: jns    1b71 <trace_set_fs_pwd+0x1b71> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b6a, 0x1b71, x86_l_1b71);
x86_l_1b6c:
	/* 0x1b6c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b6f:
	/* 0x1b6f: jmp    1b73 <trace_set_fs_pwd+0x1b73> */
	X86_SIM_X86_JMP(0x1b6f, 0x1b73, x86_l_1b73);
x86_l_1b71:
	/* 0x1b71: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b73:
	/* 0x1b73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b76:
	/* 0x1b76: jns    1b7d <trace_set_fs_pwd+0x1b7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b76, 0x1b7d, x86_l_1b7d);
x86_l_1b78:
	/* 0x1b78: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7b:
	/* 0x1b7b: jmp    1b7f <trace_set_fs_pwd+0x1b7f> */
	X86_SIM_X86_JMP(0x1b7b, 0x1b7f, x86_l_1b7f);
x86_l_1b7d:
	/* 0x1b7d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b7f:
	/* 0x1b7f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b82:
	/* 0x1b82: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b85:
	/* 0x1b85: jns    1b8c <trace_set_fs_pwd+0x1b8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b85, 0x1b8c, x86_l_1b8c);
x86_l_1b87:
	/* 0x1b87: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b8a:
	/* 0x1b8a: jmp    1b8e <trace_set_fs_pwd+0x1b8e> */
	X86_SIM_X86_JMP(0x1b8a, 0x1b8e, x86_l_1b8e);
x86_l_1b8c:
	/* 0x1b8c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b8e:
	/* 0x1b8e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b92:
	/* 0x1b92: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b95:
	/* 0x1b95: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b98:
	/* 0x1b98: jns    1be5 <trace_set_fs_pwd+0x1be5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b98, 0x1be5, x86_l_1be5);
x86_l_1b9a:
	/* 0x1b9a: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9d:
	/* 0x1b9d: jmp    1be7 <trace_set_fs_pwd+0x1be7> */
	X86_SIM_X86_JMP(0x1b9d, 0x1be7, x86_l_1be7);
x86_l_1b9f:
	/* 0x1b9f: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ba4:
	/* 0x1ba4: mov    r13,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ba9:
	/* 0x1ba9: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bae:
	/* 0x1bae: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bb3:
	/* 0x1bb3: jmp    21f <trace_set_fs_pwd+0x21f> */
	X86_SIM_X86_JMP(0x1bb3, 0x21f, x86_l_21f);
x86_l_1bb8:
	/* 0x1bb8: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1bbd:
	/* 0x1bbd: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bc1:
	/* 0x1bc1: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1bc1, 0x2b55, x86_l_2b55);
x86_l_1bc7:
	/* 0x1bc7: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bca:
	/* 0x1bca: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1bd0:
	/* 0x1bd0: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1bd5:
	/* 0x1bd5: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1bd8:
	/* 0x1bd8: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bdd:
	/* 0x1bdd: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1be0:
	/* 0x1be0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1be3:
	/* 0x1be3: js     1b9a <trace_set_fs_pwd+0x1b9a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1be3, 0x1b9a, x86_l_1b9a);
x86_l_1be5:
	/* 0x1be5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1be7:
	/* 0x1be7: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1beb:
	/* 0x1beb: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1bee:
	/* 0x1bee: jns    1bf5 <trace_set_fs_pwd+0x1bf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bee, 0x1bf5, x86_l_1bf5);
x86_l_1bf0:
	/* 0x1bf0: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf3:
	/* 0x1bf3: jmp    1bf8 <trace_set_fs_pwd+0x1bf8> */
	X86_SIM_X86_JMP(0x1bf3, 0x1bf8, x86_l_1bf8);
x86_l_1bf5:
	/* 0x1bf5: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bf8:
	/* 0x1bf8: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bfb:
	/* 0x1bfb: mov    QWORD PTR [rsp+0x10],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c00:
	/* 0x1c00: je     1c8e <trace_set_fs_pwd+0x1c8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c00, 0x1c8e, x86_l_1c8e);
x86_l_1c06:
	/* 0x1c06: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c09:
	/* 0x1c09: je     1c8e <trace_set_fs_pwd+0x1c8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c09, 0x1c8e, x86_l_1c8e);
x86_l_1c0f:
	/* 0x1c0f: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c14:
	/* 0x1c14: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c17:
	/* 0x1c17: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c1b:
	/* 0x1c1b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c1e:
	/* 0x1c1e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c24:
	/* 0x1c24: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c27:
	/* 0x1c27: jns    1c30 <trace_set_fs_pwd+0x1c30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c27, 0x1c30, x86_l_1c30);
x86_l_1c29:
	/* 0x1c29: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c2c:
	/* 0x1c2c: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c30:
	/* 0x1c30: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c34:
	/* 0x1c34: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c37:
	/* 0x1c37: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c3e:
	/* 0x1c3e: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1c40:
	/* 0x1c40: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c43:
	/* 0x1c43: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c43, 0x2bac, x86_l_2bac);
x86_l_1c49:
	/* 0x1c49: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1c4c:
	/* 0x1c4c: je     1dde <trace_set_fs_pwd+0x1dde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4c, 0x1dde, x86_l_1dde);
x86_l_1c52:
	/* 0x1c52: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c58:
	/* 0x1c58: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c5b:
	/* 0x1c5b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c5e:
	/* 0x1c5e: jns    1cf5 <trace_set_fs_pwd+0x1cf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c5e, 0x1cf5, x86_l_1cf5);
x86_l_1c64:
	/* 0x1c64: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c68:
	/* 0x1c68: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c6b:
	/* 0x1c6b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c6e:
	/* 0x1c6e: je     1cfd <trace_set_fs_pwd+0x1cfd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c6e, 0x1cfd, x86_l_1cfd);
x86_l_1c74:
	/* 0x1c74: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c78:
	/* 0x1c78: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c7d:
	/* 0x1c7d: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c81:
	/* 0x1c81: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1c84:
	/* 0x1c84: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1c87:
	/* 0x1c87: jne    1c6b <trace_set_fs_pwd+0x1c6b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c87, 0x1c6b, x86_l_1c6b);
x86_l_1c89:
	/* 0x1c89: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1c8c:
	/* 0x1c8c: jmp    1d02 <trace_set_fs_pwd+0x1d02> */
	X86_SIM_X86_JMP(0x1c8c, 0x1d02, x86_l_1d02);
x86_l_1c8e:
	/* 0x1c8e: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c91:
	/* 0x1c91: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c94:
	/* 0x1c94: jne    1cac <trace_set_fs_pwd+0x1cac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c94, 0x1cac, x86_l_1cac);
x86_l_1c96:
	/* 0x1c96: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c99:
	/* 0x1c99: je     1cac <trace_set_fs_pwd+0x1cac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c99, 0x1cac, x86_l_1cac);
x86_l_1c9b:
	/* 0x1c9b: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c9e:
	/* 0x1c9e: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ca2:
	/* 0x1ca2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ca5:
	/* 0x1ca5: jns    1cbe <trace_set_fs_pwd+0x1cbe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca5, 0x1cbe, x86_l_1cbe);
x86_l_1ca7:
	/* 0x1ca7: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1caa:
	/* 0x1caa: jmp    1cc1 <trace_set_fs_pwd+0x1cc1> */
	X86_SIM_X86_JMP(0x1caa, 0x1cc1, x86_l_1cc1);
x86_l_1cac:
	/* 0x1cac: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cb1:
	/* 0x1cb1: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cb6:
	/* 0x1cb6: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cb9:
	/* 0x1cb9: jmp    1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JMP(0x1cb9, 0x1573, x86_l_1573);
x86_l_1cbe:
	/* 0x1cbe: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cc1:
	/* 0x1cc1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cc4:
	/* 0x1cc4: jns    1cce <trace_set_fs_pwd+0x1cce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc4, 0x1cce, x86_l_1cce);
x86_l_1cc6:
	/* 0x1cc6: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cc9:
	/* 0x1cc9: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ccc:
	/* 0x1ccc: jmp    1cd0 <trace_set_fs_pwd+0x1cd0> */
	X86_SIM_X86_JMP(0x1ccc, 0x1cd0, x86_l_1cd0);
x86_l_1cce:
	/* 0x1cce: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cd0:
	/* 0x1cd0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cd3:
	/* 0x1cd3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cd6:
	/* 0x1cd6: jns    1cdd <trace_set_fs_pwd+0x1cdd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cd6, 0x1cdd, x86_l_1cdd);
x86_l_1cd8:
	/* 0x1cd8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cdb:
	/* 0x1cdb: jmp    1cdf <trace_set_fs_pwd+0x1cdf> */
	X86_SIM_X86_JMP(0x1cdb, 0x1cdf, x86_l_1cdf);
x86_l_1cdd:
	/* 0x1cdd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cdf:
	/* 0x1cdf: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ce4:
	/* 0x1ce4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ce8:
	/* 0x1ce8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ceb:
	/* 0x1ceb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cee:
	/* 0x1cee: jns    1d25 <trace_set_fs_pwd+0x1d25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cee, 0x1d25, x86_l_1d25);
x86_l_1cf0:
	/* 0x1cf0: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf3:
	/* 0x1cf3: jmp    1d27 <trace_set_fs_pwd+0x1d27> */
	X86_SIM_X86_JMP(0x1cf3, 0x1d27, x86_l_1d27);
x86_l_1cf5:
	/* 0x1cf5: mov    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cf8:
	/* 0x1cf8: jmp    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JMP(0x1cf8, 0x29aa, x86_l_29aa);
x86_l_1cfd:
	/* 0x1cfd: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d02:
	/* 0x1d02: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d06:
	/* 0x1d06: jl     1dde <trace_set_fs_pwd+0x1dde> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d06, 0x1dde, x86_l_1dde);
x86_l_1d0c:
	/* 0x1d0c: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d0f:
	/* 0x1d0f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d15:
	/* 0x1d15: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1d1a:
	/* 0x1d1a: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d1d:
	/* 0x1d1d: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d20:
	/* 0x1d20: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d23:
	/* 0x1d23: js     1cf0 <trace_set_fs_pwd+0x1cf0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d23, 0x1cf0, x86_l_1cf0);
x86_l_1d25:
	/* 0x1d25: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d27:
	/* 0x1d27: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d2b:
	/* 0x1d2b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d2e:
	/* 0x1d2e: jns    1d35 <trace_set_fs_pwd+0x1d35> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d2e, 0x1d35, x86_l_1d35);
x86_l_1d30:
	/* 0x1d30: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d33:
	/* 0x1d33: jmp    1d37 <trace_set_fs_pwd+0x1d37> */
	X86_SIM_X86_JMP(0x1d33, 0x1d37, x86_l_1d37);
x86_l_1d35:
	/* 0x1d35: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d37:
	/* 0x1d37: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d3a:
	/* 0x1d3a: je     1dbc <trace_set_fs_pwd+0x1dbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d3a, 0x1dbc, x86_l_1dbc);
x86_l_1d40:
	/* 0x1d40: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d43:
	/* 0x1d43: je     1dbc <trace_set_fs_pwd+0x1dbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d43, 0x1dbc, x86_l_1dbc);
x86_l_1d45:
	/* 0x1d45: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d49:
	/* 0x1d49: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d4c:
	/* 0x1d4c: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d52:
	/* 0x1d52: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d55:
	/* 0x1d55: jns    1d5e <trace_set_fs_pwd+0x1d5e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d55, 0x1d5e, x86_l_1d5e);
x86_l_1d57:
	/* 0x1d57: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d5a:
	/* 0x1d5a: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d5e:
	/* 0x1d5e: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1d62:
	/* 0x1d62: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d65:
	/* 0x1d65: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d6c:
	/* 0x1d6c: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d6e:
	/* 0x1d6e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d71:
	/* 0x1d71: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d71, 0x2bac, x86_l_2bac);
x86_l_1d77:
	/* 0x1d77: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1d7a:
	/* 0x1d7a: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d7a, 0x2b55, x86_l_2b55);
x86_l_1d80:
	/* 0x1d80: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d86:
	/* 0x1d86: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d89:
	/* 0x1d89: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1d8c:
	/* 0x1d8c: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d8c, 0x29aa, x86_l_29aa);
x86_l_1d92:
	/* 0x1d92: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d96:
	/* 0x1d96: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d99:
	/* 0x1d99: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d9c:
	/* 0x1d9c: je     1e29 <trace_set_fs_pwd+0x1e29> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d9c, 0x1e29, x86_l_1e29);
x86_l_1da2:
	/* 0x1da2: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1da6:
	/* 0x1da6: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1dab:
	/* 0x1dab: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1daf:
	/* 0x1daf: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1db2:
	/* 0x1db2: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1db5:
	/* 0x1db5: jne    1d99 <trace_set_fs_pwd+0x1d99> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1db5, 0x1d99, x86_l_1d99);
x86_l_1db7:
	/* 0x1db7: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1dba:
	/* 0x1dba: jmp    1e2e <trace_set_fs_pwd+0x1e2e> */
	X86_SIM_X86_JMP(0x1dba, 0x1e2e, x86_l_1e2e);
x86_l_1dbc:
	/* 0x1dbc: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1dbf:
	/* 0x1dbf: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dbf, 0x2b55, x86_l_2b55);
x86_l_1dc5:
	/* 0x1dc5: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1dca:
	/* 0x1dca: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dca, 0x2b55, x86_l_2b55);
x86_l_1dd0:
	/* 0x1dd0: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dd4:
	/* 0x1dd4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dd7:
	/* 0x1dd7: jns    1df0 <trace_set_fs_pwd+0x1df0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dd7, 0x1df0, x86_l_1df0);
x86_l_1dd9:
	/* 0x1dd9: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ddc:
	/* 0x1ddc: jmp    1df2 <trace_set_fs_pwd+0x1df2> */
	X86_SIM_X86_JMP(0x1ddc, 0x1df2, x86_l_1df2);
x86_l_1dde:
	/* 0x1dde: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1de3:
	/* 0x1de3: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1de8:
	/* 0x1de8: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1deb:
	/* 0x1deb: jmp    1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JMP(0x1deb, 0x1573, x86_l_1573);
x86_l_1df0:
	/* 0x1df0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1df2:
	/* 0x1df2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1df5:
	/* 0x1df5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1df8:
	/* 0x1df8: jns    1e02 <trace_set_fs_pwd+0x1e02> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1df8, 0x1e02, x86_l_1e02);
x86_l_1dfa:
	/* 0x1dfa: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dfd:
	/* 0x1dfd: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e00:
	/* 0x1e00: jmp    1e04 <trace_set_fs_pwd+0x1e04> */
	X86_SIM_X86_JMP(0x1e00, 0x1e04, x86_l_1e04);
x86_l_1e02:
	/* 0x1e02: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e04:
	/* 0x1e04: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e07:
	/* 0x1e07: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e0a:
	/* 0x1e0a: jns    1e11 <trace_set_fs_pwd+0x1e11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e0a, 0x1e11, x86_l_1e11);
x86_l_1e0c:
	/* 0x1e0c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e0f:
	/* 0x1e0f: jmp    1e13 <trace_set_fs_pwd+0x1e13> */
	X86_SIM_X86_JMP(0x1e0f, 0x1e13, x86_l_1e13);
x86_l_1e11:
	/* 0x1e11: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e13:
	/* 0x1e13: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e18:
	/* 0x1e18: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e1c:
	/* 0x1e1c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e1f:
	/* 0x1e1f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e22:
	/* 0x1e22: jns    1e51 <trace_set_fs_pwd+0x1e51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e22, 0x1e51, x86_l_1e51);
x86_l_1e24:
	/* 0x1e24: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e27:
	/* 0x1e27: jmp    1e53 <trace_set_fs_pwd+0x1e53> */
	X86_SIM_X86_JMP(0x1e27, 0x1e53, x86_l_1e53);
x86_l_1e29:
	/* 0x1e29: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e2e:
	/* 0x1e2e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e32:
	/* 0x1e32: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e32, 0x2b55, x86_l_2b55);
x86_l_1e38:
	/* 0x1e38: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e3b:
	/* 0x1e3b: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1e41:
	/* 0x1e41: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1e46:
	/* 0x1e46: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e49:
	/* 0x1e49: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e4c:
	/* 0x1e4c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e4f:
	/* 0x1e4f: js     1e24 <trace_set_fs_pwd+0x1e24> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e4f, 0x1e24, x86_l_1e24);
x86_l_1e51:
	/* 0x1e51: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e53:
	/* 0x1e53: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e57:
	/* 0x1e57: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e5a:
	/* 0x1e5a: jns    1e61 <trace_set_fs_pwd+0x1e61> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e5a, 0x1e61, x86_l_1e61);
x86_l_1e5c:
	/* 0x1e5c: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e5f:
	/* 0x1e5f: jmp    1e64 <trace_set_fs_pwd+0x1e64> */
	X86_SIM_X86_JMP(0x1e5f, 0x1e64, x86_l_1e64);
x86_l_1e61:
	/* 0x1e61: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e64:
	/* 0x1e64: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e67:
	/* 0x1e67: je     1ee1 <trace_set_fs_pwd+0x1ee1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e67, 0x1ee1, x86_l_1ee1);
x86_l_1e69:
	/* 0x1e69: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1e6c:
	/* 0x1e6c: je     1ee1 <trace_set_fs_pwd+0x1ee1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e6c, 0x1ee1, x86_l_1ee1);
x86_l_1e6e:
	/* 0x1e6e: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e72:
	/* 0x1e72: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e75:
	/* 0x1e75: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1e7b:
	/* 0x1e7b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e7e:
	/* 0x1e7e: jns    1e87 <trace_set_fs_pwd+0x1e87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e7e, 0x1e87, x86_l_1e87);
x86_l_1e80:
	/* 0x1e80: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e83:
	/* 0x1e83: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e87:
	/* 0x1e87: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e8b:
	/* 0x1e8b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e8e:
	/* 0x1e8e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e95:
	/* 0x1e95: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1e97:
	/* 0x1e97: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e9a:
	/* 0x1e9a: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e9a, 0x2bac, x86_l_2bac);
x86_l_1ea0:
	/* 0x1ea0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1ea3:
	/* 0x1ea3: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea3, 0x2b58, x86_l_2b58);
x86_l_1ea9:
	/* 0x1ea9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1eaf:
	/* 0x1eaf: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1eb2:
	/* 0x1eb2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1eb5:
	/* 0x1eb5: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eb5, 0x29a7, x86_l_29a7);
x86_l_1ebb:
	/* 0x1ebb: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ebf:
	/* 0x1ebf: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec2:
	/* 0x1ec2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ec5:
	/* 0x1ec5: je     1f3d <trace_set_fs_pwd+0x1f3d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec5, 0x1f3d, x86_l_1f3d);
x86_l_1ec7:
	/* 0x1ec7: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ecb:
	/* 0x1ecb: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1ed0:
	/* 0x1ed0: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ed4:
	/* 0x1ed4: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ed7:
	/* 0x1ed7: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1eda:
	/* 0x1eda: jne    1ec2 <trace_set_fs_pwd+0x1ec2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eda, 0x1ec2, x86_l_1ec2);
x86_l_1edc:
	/* 0x1edc: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1edf:
	/* 0x1edf: jmp    1f42 <trace_set_fs_pwd+0x1f42> */
	X86_SIM_X86_JMP(0x1edf, 0x1f42, x86_l_1f42);
x86_l_1ee1:
	/* 0x1ee1: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ee4:
	/* 0x1ee4: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee4, 0x2b58, x86_l_2b58);
x86_l_1eea:
	/* 0x1eea: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1eef:
	/* 0x1eef: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eef, 0x2b58, x86_l_2b58);
x86_l_1ef5:
	/* 0x1ef5: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ef9:
	/* 0x1ef9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1efc:
	/* 0x1efc: jns    1f03 <trace_set_fs_pwd+0x1f03> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1efc, 0x1f03, x86_l_1f03);
x86_l_1efe:
	/* 0x1efe: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f01:
	/* 0x1f01: jmp    1f06 <trace_set_fs_pwd+0x1f06> */
	X86_SIM_X86_JMP(0x1f01, 0x1f06, x86_l_1f06);
x86_l_1f03:
	/* 0x1f03: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f06:
	/* 0x1f06: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f09:
	/* 0x1f09: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f0c:
	/* 0x1f0c: jns    1f16 <trace_set_fs_pwd+0x1f16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f0c, 0x1f16, x86_l_1f16);
x86_l_1f0e:
	/* 0x1f0e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f11:
	/* 0x1f11: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f14:
	/* 0x1f14: jmp    1f18 <trace_set_fs_pwd+0x1f18> */
	X86_SIM_X86_JMP(0x1f14, 0x1f18, x86_l_1f18);
x86_l_1f16:
	/* 0x1f16: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f18:
	/* 0x1f18: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f1b:
	/* 0x1f1b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f1e:
	/* 0x1f1e: jns    1f25 <trace_set_fs_pwd+0x1f25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f1e, 0x1f25, x86_l_1f25);
x86_l_1f20:
	/* 0x1f20: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f23:
	/* 0x1f23: jmp    1f27 <trace_set_fs_pwd+0x1f27> */
	X86_SIM_X86_JMP(0x1f23, 0x1f27, x86_l_1f27);
x86_l_1f25:
	/* 0x1f25: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f27:
	/* 0x1f27: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f2c:
	/* 0x1f2c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f30:
	/* 0x1f30: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f33:
	/* 0x1f33: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f36:
	/* 0x1f36: jns    1f65 <trace_set_fs_pwd+0x1f65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f36, 0x1f65, x86_l_1f65);
x86_l_1f38:
	/* 0x1f38: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f3b:
	/* 0x1f3b: jmp    1f67 <trace_set_fs_pwd+0x1f67> */
	X86_SIM_X86_JMP(0x1f3b, 0x1f67, x86_l_1f67);
x86_l_1f3d:
	/* 0x1f3d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1f42:
	/* 0x1f42: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f46:
	/* 0x1f46: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f46, 0x2b58, x86_l_2b58);
x86_l_1f4c:
	/* 0x1f4c: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f4f:
	/* 0x1f4f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f55:
	/* 0x1f55: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1f5a:
	/* 0x1f5a: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f5d:
	/* 0x1f5d: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f60:
	/* 0x1f60: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f63:
	/* 0x1f63: js     1f38 <trace_set_fs_pwd+0x1f38> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f63, 0x1f38, x86_l_1f38);
x86_l_1f65:
	/* 0x1f65: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f67:
	/* 0x1f67: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f6b:
	/* 0x1f6b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f6e:
	/* 0x1f6e: jns    1f75 <trace_set_fs_pwd+0x1f75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6e, 0x1f75, x86_l_1f75);
x86_l_1f70:
	/* 0x1f70: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f73:
	/* 0x1f73: jmp    1f77 <trace_set_fs_pwd+0x1f77> */
	X86_SIM_X86_JMP(0x1f73, 0x1f77, x86_l_1f77);
x86_l_1f75:
	/* 0x1f75: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f77:
	/* 0x1f77: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f7a:
	/* 0x1f7a: je     1ff4 <trace_set_fs_pwd+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7a, 0x1ff4, x86_l_1ff4);
x86_l_1f7c:
	/* 0x1f7c: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f7f:
	/* 0x1f7f: je     1ff4 <trace_set_fs_pwd+0x1ff4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7f, 0x1ff4, x86_l_1ff4);
x86_l_1f81:
	/* 0x1f81: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f85:
	/* 0x1f85: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f88:
	/* 0x1f88: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f8e:
	/* 0x1f8e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f91:
	/* 0x1f91: jns    1f9a <trace_set_fs_pwd+0x1f9a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f91, 0x1f9a, x86_l_1f9a);
x86_l_1f93:
	/* 0x1f93: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f96:
	/* 0x1f96: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f9a:
	/* 0x1f9a: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f9e:
	/* 0x1f9e: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1fa1:
	/* 0x1fa1: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1fa8:
	/* 0x1fa8: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1faa:
	/* 0x1faa: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fad:
	/* 0x1fad: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1fad, 0x2bac, x86_l_2bac);
x86_l_1fb3:
	/* 0x1fb3: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1fb6:
	/* 0x1fb6: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb6, 0x2b55, x86_l_2b55);
x86_l_1fbc:
	/* 0x1fbc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1fc2:
	/* 0x1fc2: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fc5:
	/* 0x1fc5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1fc8:
	/* 0x1fc8: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc8, 0x29aa, x86_l_29aa);
x86_l_1fce:
	/* 0x1fce: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fd2:
	/* 0x1fd2: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fd5:
	/* 0x1fd5: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1fd8:
	/* 0x1fd8: je     204f <trace_set_fs_pwd+0x204f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd8, 0x204f, x86_l_204f);
x86_l_1fda:
	/* 0x1fda: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1fde:
	/* 0x1fde: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1fe3:
	/* 0x1fe3: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1fe7:
	/* 0x1fe7: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1fea:
	/* 0x1fea: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1fed:
	/* 0x1fed: jne    1fd5 <trace_set_fs_pwd+0x1fd5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fed, 0x1fd5, x86_l_1fd5);
x86_l_1fef:
	/* 0x1fef: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1ff2:
	/* 0x1ff2: jmp    2054 <trace_set_fs_pwd+0x2054> */
	X86_SIM_X86_JMP(0x1ff2, 0x2054, x86_l_2054);
x86_l_1ff4:
	/* 0x1ff4: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ff7:
	/* 0x1ff7: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ff7, 0x2b55, x86_l_2b55);
x86_l_1ffd:
	/* 0x1ffd: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2002:
	/* 0x2002: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2002, 0x2b55, x86_l_2b55);
x86_l_2008:
	/* 0x2008: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_200c:
	/* 0x200c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_200f:
	/* 0x200f: jns    2016 <trace_set_fs_pwd+0x2016> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x200f, 0x2016, x86_l_2016);
x86_l_2011:
	/* 0x2011: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2014:
	/* 0x2014: jmp    2018 <trace_set_fs_pwd+0x2018> */
	X86_SIM_X86_JMP(0x2014, 0x2018, x86_l_2018);
x86_l_2016:
	/* 0x2016: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2018:
	/* 0x2018: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201b:
	/* 0x201b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_201e:
	/* 0x201e: jns    2028 <trace_set_fs_pwd+0x2028> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x201e, 0x2028, x86_l_2028);
x86_l_2020:
	/* 0x2020: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2023:
	/* 0x2023: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2026:
	/* 0x2026: jmp    202a <trace_set_fs_pwd+0x202a> */
	X86_SIM_X86_JMP(0x2026, 0x202a, x86_l_202a);
x86_l_2028:
	/* 0x2028: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_202a:
	/* 0x202a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_202d:
	/* 0x202d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2030:
	/* 0x2030: jns    2037 <trace_set_fs_pwd+0x2037> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2030, 0x2037, x86_l_2037);
x86_l_2032:
	/* 0x2032: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2035:
	/* 0x2035: jmp    2039 <trace_set_fs_pwd+0x2039> */
	X86_SIM_X86_JMP(0x2035, 0x2039, x86_l_2039);
x86_l_2037:
	/* 0x2037: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2039:
	/* 0x2039: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_203e:
	/* 0x203e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2042:
	/* 0x2042: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2045:
	/* 0x2045: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2048:
	/* 0x2048: jns    2077 <trace_set_fs_pwd+0x2077> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2048, 0x2077, x86_l_2077);
x86_l_204a:
	/* 0x204a: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_204d:
	/* 0x204d: jmp    2079 <trace_set_fs_pwd+0x2079> */
	X86_SIM_X86_JMP(0x204d, 0x2079, x86_l_2079);
x86_l_204f:
	/* 0x204f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2054:
	/* 0x2054: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2058:
	/* 0x2058: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2058, 0x2b55, x86_l_2b55);
x86_l_205e:
	/* 0x205e: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2061:
	/* 0x2061: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2067:
	/* 0x2067: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_206c:
	/* 0x206c: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_206f:
	/* 0x206f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2072:
	/* 0x2072: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2075:
	/* 0x2075: js     204a <trace_set_fs_pwd+0x204a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2075, 0x204a, x86_l_204a);
x86_l_2077:
	/* 0x2077: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2079:
	/* 0x2079: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_207d:
	/* 0x207d: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2080:
	/* 0x2080: jns    2087 <trace_set_fs_pwd+0x2087> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2080, 0x2087, x86_l_2087);
x86_l_2082:
	/* 0x2082: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2085:
	/* 0x2085: jmp    208a <trace_set_fs_pwd+0x208a> */
	X86_SIM_X86_JMP(0x2085, 0x208a, x86_l_208a);
x86_l_2087:
	/* 0x2087: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208a:
	/* 0x208a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_208d:
	/* 0x208d: je     2107 <trace_set_fs_pwd+0x2107> */
	X86_SIM_X86_JCC(X86_CC_E, 0x208d, 0x2107, x86_l_2107);
x86_l_208f:
	/* 0x208f: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2092:
	/* 0x2092: je     2107 <trace_set_fs_pwd+0x2107> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2092, 0x2107, x86_l_2107);
x86_l_2094:
	/* 0x2094: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2098:
	/* 0x2098: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_209b:
	/* 0x209b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_20a1:
	/* 0x20a1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20a4:
	/* 0x20a4: jns    20ad <trace_set_fs_pwd+0x20ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20a4, 0x20ad, x86_l_20ad);
x86_l_20a6:
	/* 0x20a6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a9:
	/* 0x20a9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20ad:
	/* 0x20ad: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_20b1:
	/* 0x20b1: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20b4:
	/* 0x20b4: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20bb:
	/* 0x20bb: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20bd:
	/* 0x20bd: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20c0:
	/* 0x20c0: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20c0, 0x2bac, x86_l_2bac);
x86_l_20c6:
	/* 0x20c6: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_20c9:
	/* 0x20c9: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20c9, 0x2b58, x86_l_2b58);
x86_l_20cf:
	/* 0x20cf: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20d5:
	/* 0x20d5: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20d8:
	/* 0x20d8: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_20db:
	/* 0x20db: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20db, 0x29a7, x86_l_29a7);
x86_l_20e1:
	/* 0x20e1: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20e5:
	/* 0x20e5: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20e8:
	/* 0x20e8: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_20eb:
	/* 0x20eb: je     2163 <trace_set_fs_pwd+0x2163> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20eb, 0x2163, x86_l_2163);
x86_l_20ed:
	/* 0x20ed: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20f1:
	/* 0x20f1: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_20f6:
	/* 0x20f6: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_20fa:
	/* 0x20fa: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_20fd:
	/* 0x20fd: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2100:
	/* 0x2100: jne    20e8 <trace_set_fs_pwd+0x20e8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2100, 0x20e8, x86_l_20e8);
x86_l_2102:
	/* 0x2102: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2105:
	/* 0x2105: jmp    2168 <trace_set_fs_pwd+0x2168> */
	X86_SIM_X86_JMP(0x2105, 0x2168, x86_l_2168);
x86_l_2107:
	/* 0x2107: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_210a:
	/* 0x210a: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x210a, 0x2b58, x86_l_2b58);
x86_l_2110:
	/* 0x2110: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2115:
	/* 0x2115: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2115, 0x2b58, x86_l_2b58);
x86_l_211b:
	/* 0x211b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_211f:
	/* 0x211f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2122:
	/* 0x2122: jns    2129 <trace_set_fs_pwd+0x2129> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2122, 0x2129, x86_l_2129);
x86_l_2124:
	/* 0x2124: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2127:
	/* 0x2127: jmp    212c <trace_set_fs_pwd+0x212c> */
	X86_SIM_X86_JMP(0x2127, 0x212c, x86_l_212c);
x86_l_2129:
	/* 0x2129: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212c:
	/* 0x212c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_212f:
	/* 0x212f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2132:
	/* 0x2132: jns    213c <trace_set_fs_pwd+0x213c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2132, 0x213c, x86_l_213c);
x86_l_2134:
	/* 0x2134: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2137:
	/* 0x2137: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213a:
	/* 0x213a: jmp    213e <trace_set_fs_pwd+0x213e> */
	X86_SIM_X86_JMP(0x213a, 0x213e, x86_l_213e);
x86_l_213c:
	/* 0x213c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_213e:
	/* 0x213e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2141:
	/* 0x2141: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2144:
	/* 0x2144: jns    214b <trace_set_fs_pwd+0x214b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2144, 0x214b, x86_l_214b);
x86_l_2146:
	/* 0x2146: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2149:
	/* 0x2149: jmp    214d <trace_set_fs_pwd+0x214d> */
	X86_SIM_X86_JMP(0x2149, 0x214d, x86_l_214d);
x86_l_214b:
	/* 0x214b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214d:
	/* 0x214d: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2152:
	/* 0x2152: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2156:
	/* 0x2156: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2159:
	/* 0x2159: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_215c:
	/* 0x215c: jns    218b <trace_set_fs_pwd+0x218b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x215c, 0x218b, x86_l_218b);
x86_l_215e:
	/* 0x215e: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2161:
	/* 0x2161: jmp    218d <trace_set_fs_pwd+0x218d> */
	X86_SIM_X86_JMP(0x2161, 0x218d, x86_l_218d);
x86_l_2163:
	/* 0x2163: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2168:
	/* 0x2168: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_216c:
	/* 0x216c: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x216c, 0x2b58, x86_l_2b58);
x86_l_2172:
	/* 0x2172: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2175:
	/* 0x2175: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_217b:
	/* 0x217b: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2180:
	/* 0x2180: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2183:
	/* 0x2183: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2186:
	/* 0x2186: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2189:
	/* 0x2189: js     215e <trace_set_fs_pwd+0x215e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2189, 0x215e, x86_l_215e);
x86_l_218b:
	/* 0x218b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_218d:
	/* 0x218d: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2191:
	/* 0x2191: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2194:
	/* 0x2194: jns    219b <trace_set_fs_pwd+0x219b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2194, 0x219b, x86_l_219b);
x86_l_2196:
	/* 0x2196: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2199:
	/* 0x2199: jmp    219d <trace_set_fs_pwd+0x219d> */
	X86_SIM_X86_JMP(0x2199, 0x219d, x86_l_219d);
x86_l_219b:
	/* 0x219b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_219d:
	/* 0x219d: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21a0:
	/* 0x21a0: je     221a <trace_set_fs_pwd+0x221a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a0, 0x221a, x86_l_221a);
x86_l_21a2:
	/* 0x21a2: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21a5:
	/* 0x21a5: je     221a <trace_set_fs_pwd+0x221a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a5, 0x221a, x86_l_221a);
x86_l_21a7:
	/* 0x21a7: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21ab:
	/* 0x21ab: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21ae:
	/* 0x21ae: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_21b4:
	/* 0x21b4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21b7:
	/* 0x21b7: jns    21c0 <trace_set_fs_pwd+0x21c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21b7, 0x21c0, x86_l_21c0);
x86_l_21b9:
	/* 0x21b9: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21bc:
	/* 0x21bc: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21c0:
	/* 0x21c0: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_21c4:
	/* 0x21c4: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21c7:
	/* 0x21c7: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_21ce:
	/* 0x21ce: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21d0:
	/* 0x21d0: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21d3:
	/* 0x21d3: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21d3, 0x2bac, x86_l_2bac);
x86_l_21d9:
	/* 0x21d9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_21dc:
	/* 0x21dc: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21dc, 0x2b55, x86_l_2b55);
x86_l_21e2:
	/* 0x21e2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_21e8:
	/* 0x21e8: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_21eb:
	/* 0x21eb: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_21ee:
	/* 0x21ee: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21ee, 0x29aa, x86_l_29aa);
x86_l_21f4:
	/* 0x21f4: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21f8:
	/* 0x21f8: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21fb:
	/* 0x21fb: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_21fe:
	/* 0x21fe: je     2275 <trace_set_fs_pwd+0x2275> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21fe, 0x2275, x86_l_2275);
x86_l_2200:
	/* 0x2200: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2204:
	/* 0x2204: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2209:
	/* 0x2209: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_220d:
	/* 0x220d: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2210:
	/* 0x2210: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2213:
	/* 0x2213: jne    21fb <trace_set_fs_pwd+0x21fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2213, 0x21fb, x86_l_21fb);
x86_l_2215:
	/* 0x2215: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2218:
	/* 0x2218: jmp    227a <trace_set_fs_pwd+0x227a> */
	X86_SIM_X86_JMP(0x2218, 0x227a, x86_l_227a);
x86_l_221a:
	/* 0x221a: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_221d:
	/* 0x221d: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x221d, 0x2b55, x86_l_2b55);
x86_l_2223:
	/* 0x2223: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2228:
	/* 0x2228: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2228, 0x2b55, x86_l_2b55);
x86_l_222e:
	/* 0x222e: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2232:
	/* 0x2232: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2235:
	/* 0x2235: jns    223c <trace_set_fs_pwd+0x223c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2235, 0x223c, x86_l_223c);
x86_l_2237:
	/* 0x2237: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_223a:
	/* 0x223a: jmp    223e <trace_set_fs_pwd+0x223e> */
	X86_SIM_X86_JMP(0x223a, 0x223e, x86_l_223e);
x86_l_223c:
	/* 0x223c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_223e:
	/* 0x223e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2241:
	/* 0x2241: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2244:
	/* 0x2244: jns    224e <trace_set_fs_pwd+0x224e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2244, 0x224e, x86_l_224e);
x86_l_2246:
	/* 0x2246: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2249:
	/* 0x2249: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_224c:
	/* 0x224c: jmp    2250 <trace_set_fs_pwd+0x2250> */
	X86_SIM_X86_JMP(0x224c, 0x2250, x86_l_2250);
x86_l_224e:
	/* 0x224e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2250:
	/* 0x2250: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2253:
	/* 0x2253: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2256:
	/* 0x2256: jns    225d <trace_set_fs_pwd+0x225d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2256, 0x225d, x86_l_225d);
x86_l_2258:
	/* 0x2258: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225b:
	/* 0x225b: jmp    225f <trace_set_fs_pwd+0x225f> */
	X86_SIM_X86_JMP(0x225b, 0x225f, x86_l_225f);
x86_l_225d:
	/* 0x225d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_225f:
	/* 0x225f: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2264:
	/* 0x2264: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2268:
	/* 0x2268: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_226b:
	/* 0x226b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_226e:
	/* 0x226e: jns    229d <trace_set_fs_pwd+0x229d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x226e, 0x229d, x86_l_229d);
x86_l_2270:
	/* 0x2270: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2273:
	/* 0x2273: jmp    229f <trace_set_fs_pwd+0x229f> */
	X86_SIM_X86_JMP(0x2273, 0x229f, x86_l_229f);
x86_l_2275:
	/* 0x2275: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_227a:
	/* 0x227a: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_227e:
	/* 0x227e: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x227e, 0x2b55, x86_l_2b55);
x86_l_2284:
	/* 0x2284: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2287:
	/* 0x2287: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_228d:
	/* 0x228d: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2292:
	/* 0x2292: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2295:
	/* 0x2295: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2298:
	/* 0x2298: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_229b:
	/* 0x229b: js     2270 <trace_set_fs_pwd+0x2270> */
	X86_SIM_X86_JCC(X86_CC_S, 0x229b, 0x2270, x86_l_2270);
x86_l_229d:
	/* 0x229d: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_229f:
	/* 0x229f: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22a3:
	/* 0x22a3: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_22a6:
	/* 0x22a6: jns    22ad <trace_set_fs_pwd+0x22ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a6, 0x22ad, x86_l_22ad);
x86_l_22a8:
	/* 0x22a8: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ab:
	/* 0x22ab: jmp    22b0 <trace_set_fs_pwd+0x22b0> */
	X86_SIM_X86_JMP(0x22ab, 0x22b0, x86_l_22b0);
x86_l_22ad:
	/* 0x22ad: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22b0:
	/* 0x22b0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22b3:
	/* 0x22b3: je     232d <trace_set_fs_pwd+0x232d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b3, 0x232d, x86_l_232d);
x86_l_22b5:
	/* 0x22b5: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_22b8:
	/* 0x22b8: je     232d <trace_set_fs_pwd+0x232d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b8, 0x232d, x86_l_232d);
x86_l_22ba:
	/* 0x22ba: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22be:
	/* 0x22be: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22c1:
	/* 0x22c1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_22c7:
	/* 0x22c7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22ca:
	/* 0x22ca: jns    22d3 <trace_set_fs_pwd+0x22d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22ca, 0x22d3, x86_l_22d3);
x86_l_22cc:
	/* 0x22cc: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22cf:
	/* 0x22cf: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d3:
	/* 0x22d3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22d7:
	/* 0x22d7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22da:
	/* 0x22da: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22e1:
	/* 0x22e1: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_22e3:
	/* 0x22e3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22e6:
	/* 0x22e6: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22e6, 0x2bac, x86_l_2bac);
x86_l_22ec:
	/* 0x22ec: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_22ef:
	/* 0x22ef: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22ef, 0x2b58, x86_l_2b58);
x86_l_22f5:
	/* 0x22f5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_22fb:
	/* 0x22fb: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_22fe:
	/* 0x22fe: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2301:
	/* 0x2301: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2301, 0x29a7, x86_l_29a7);
x86_l_2307:
	/* 0x2307: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_230b:
	/* 0x230b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_230e:
	/* 0x230e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2311:
	/* 0x2311: je     2389 <trace_set_fs_pwd+0x2389> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2311, 0x2389, x86_l_2389);
x86_l_2313:
	/* 0x2313: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2317:
	/* 0x2317: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_231c:
	/* 0x231c: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2320:
	/* 0x2320: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2323:
	/* 0x2323: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2326:
	/* 0x2326: jne    230e <trace_set_fs_pwd+0x230e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2326, 0x230e, x86_l_230e);
x86_l_2328:
	/* 0x2328: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_232b:
	/* 0x232b: jmp    238e <trace_set_fs_pwd+0x238e> */
	X86_SIM_X86_JMP(0x232b, 0x238e, x86_l_238e);
x86_l_232d:
	/* 0x232d: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2330:
	/* 0x2330: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2330, 0x2b58, x86_l_2b58);
x86_l_2336:
	/* 0x2336: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_233b:
	/* 0x233b: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x233b, 0x2b58, x86_l_2b58);
x86_l_2341:
	/* 0x2341: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2345:
	/* 0x2345: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2348:
	/* 0x2348: jns    234f <trace_set_fs_pwd+0x234f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2348, 0x234f, x86_l_234f);
x86_l_234a:
	/* 0x234a: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_234d:
	/* 0x234d: jmp    2352 <trace_set_fs_pwd+0x2352> */
	X86_SIM_X86_JMP(0x234d, 0x2352, x86_l_2352);
x86_l_234f:
	/* 0x234f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2352:
	/* 0x2352: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2355:
	/* 0x2355: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2358:
	/* 0x2358: jns    2362 <trace_set_fs_pwd+0x2362> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2358, 0x2362, x86_l_2362);
x86_l_235a:
	/* 0x235a: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_235d:
	/* 0x235d: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2360:
	/* 0x2360: jmp    2364 <trace_set_fs_pwd+0x2364> */
	X86_SIM_X86_JMP(0x2360, 0x2364, x86_l_2364);
x86_l_2362:
	/* 0x2362: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2364:
	/* 0x2364: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2367:
	/* 0x2367: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_236a:
	/* 0x236a: jns    2371 <trace_set_fs_pwd+0x2371> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x236a, 0x2371, x86_l_2371);
x86_l_236c:
	/* 0x236c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_236f:
	/* 0x236f: jmp    2373 <trace_set_fs_pwd+0x2373> */
	X86_SIM_X86_JMP(0x236f, 0x2373, x86_l_2373);
x86_l_2371:
	/* 0x2371: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2373:
	/* 0x2373: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2378:
	/* 0x2378: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_237c:
	/* 0x237c: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_237f:
	/* 0x237f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2382:
	/* 0x2382: jns    23b1 <trace_set_fs_pwd+0x23b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2382, 0x23b1, x86_l_23b1);
x86_l_2384:
	/* 0x2384: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2387:
	/* 0x2387: jmp    23b3 <trace_set_fs_pwd+0x23b3> */
	X86_SIM_X86_JMP(0x2387, 0x23b3, x86_l_23b3);
x86_l_2389:
	/* 0x2389: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_238e:
	/* 0x238e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2392:
	/* 0x2392: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2392, 0x2b58, x86_l_2b58);
x86_l_2398:
	/* 0x2398: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_239b:
	/* 0x239b: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23a1:
	/* 0x23a1: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_23a6:
	/* 0x23a6: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23a9:
	/* 0x23a9: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23ac:
	/* 0x23ac: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23af:
	/* 0x23af: js     2384 <trace_set_fs_pwd+0x2384> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23af, 0x2384, x86_l_2384);
x86_l_23b1:
	/* 0x23b1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b3:
	/* 0x23b3: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23b7:
	/* 0x23b7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23ba:
	/* 0x23ba: jns    23c1 <trace_set_fs_pwd+0x23c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23ba, 0x23c1, x86_l_23c1);
x86_l_23bc:
	/* 0x23bc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23bf:
	/* 0x23bf: jmp    23c3 <trace_set_fs_pwd+0x23c3> */
	X86_SIM_X86_JMP(0x23bf, 0x23c3, x86_l_23c3);
x86_l_23c1:
	/* 0x23c1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c3:
	/* 0x23c3: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23c6:
	/* 0x23c6: je     2440 <trace_set_fs_pwd+0x2440> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23c6, 0x2440, x86_l_2440);
x86_l_23c8:
	/* 0x23c8: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23cb:
	/* 0x23cb: je     2440 <trace_set_fs_pwd+0x2440> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23cb, 0x2440, x86_l_2440);
x86_l_23cd:
	/* 0x23cd: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d1:
	/* 0x23d1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d4:
	/* 0x23d4: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_23da:
	/* 0x23da: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23dd:
	/* 0x23dd: jns    23e6 <trace_set_fs_pwd+0x23e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23dd, 0x23e6, x86_l_23e6);
x86_l_23df:
	/* 0x23df: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e2:
	/* 0x23e2: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23e6:
	/* 0x23e6: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_23ea:
	/* 0x23ea: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23ed:
	/* 0x23ed: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_23f4:
	/* 0x23f4: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_23f6:
	/* 0x23f6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23f9:
	/* 0x23f9: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x23f9, 0x2bac, x86_l_2bac);
x86_l_23ff:
	/* 0x23ff: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2402:
	/* 0x2402: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2402, 0x2b55, x86_l_2b55);
x86_l_2408:
	/* 0x2408: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_240e:
	/* 0x240e: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2411:
	/* 0x2411: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2414:
	/* 0x2414: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2414, 0x29aa, x86_l_29aa);
x86_l_241a:
	/* 0x241a: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_241e:
	/* 0x241e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2421:
	/* 0x2421: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2424:
	/* 0x2424: je     249b <trace_set_fs_pwd+0x249b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2424, 0x249b, x86_l_249b);
x86_l_2426:
	/* 0x2426: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_242a:
	/* 0x242a: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_242f:
	/* 0x242f: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2433:
	/* 0x2433: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2436:
	/* 0x2436: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2439:
	/* 0x2439: jne    2421 <trace_set_fs_pwd+0x2421> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2439, 0x2421, x86_l_2421);
x86_l_243b:
	/* 0x243b: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_243e:
	/* 0x243e: jmp    24a0 <trace_set_fs_pwd+0x24a0> */
	X86_SIM_X86_JMP(0x243e, 0x24a0, x86_l_24a0);
x86_l_2440:
	/* 0x2440: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2443:
	/* 0x2443: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2443, 0x2b55, x86_l_2b55);
x86_l_2449:
	/* 0x2449: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_244e:
	/* 0x244e: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244e, 0x2b55, x86_l_2b55);
x86_l_2454:
	/* 0x2454: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2458:
	/* 0x2458: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_245b:
	/* 0x245b: jns    2462 <trace_set_fs_pwd+0x2462> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x245b, 0x2462, x86_l_2462);
x86_l_245d:
	/* 0x245d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2460:
	/* 0x2460: jmp    2464 <trace_set_fs_pwd+0x2464> */
	X86_SIM_X86_JMP(0x2460, 0x2464, x86_l_2464);
x86_l_2462:
	/* 0x2462: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2464:
	/* 0x2464: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2467:
	/* 0x2467: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_246a:
	/* 0x246a: jns    2474 <trace_set_fs_pwd+0x2474> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x246a, 0x2474, x86_l_2474);
x86_l_246c:
	/* 0x246c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_246f:
	/* 0x246f: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2472:
	/* 0x2472: jmp    2476 <trace_set_fs_pwd+0x2476> */
	X86_SIM_X86_JMP(0x2472, 0x2476, x86_l_2476);
x86_l_2474:
	/* 0x2474: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2476:
	/* 0x2476: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2479:
	/* 0x2479: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_247c:
	/* 0x247c: jns    2483 <trace_set_fs_pwd+0x2483> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x247c, 0x2483, x86_l_2483);
x86_l_247e:
	/* 0x247e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2481:
	/* 0x2481: jmp    2485 <trace_set_fs_pwd+0x2485> */
	X86_SIM_X86_JMP(0x2481, 0x2485, x86_l_2485);
x86_l_2483:
	/* 0x2483: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2485:
	/* 0x2485: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_248a:
	/* 0x248a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_248e:
	/* 0x248e: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2491:
	/* 0x2491: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2494:
	/* 0x2494: jns    24c3 <trace_set_fs_pwd+0x24c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2494, 0x24c3, x86_l_24c3);
x86_l_2496:
	/* 0x2496: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2499:
	/* 0x2499: jmp    24c5 <trace_set_fs_pwd+0x24c5> */
	X86_SIM_X86_JMP(0x2499, 0x24c5, x86_l_24c5);
x86_l_249b:
	/* 0x249b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_24a0:
	/* 0x24a0: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24a4:
	/* 0x24a4: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x24a4, 0x2b55, x86_l_2b55);
x86_l_24aa:
	/* 0x24aa: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24ad:
	/* 0x24ad: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_24b3:
	/* 0x24b3: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_24b8:
	/* 0x24b8: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24bb:
	/* 0x24bb: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24be:
	/* 0x24be: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24c1:
	/* 0x24c1: js     2496 <trace_set_fs_pwd+0x2496> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24c1, 0x2496, x86_l_2496);
x86_l_24c3:
	/* 0x24c3: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24c5:
	/* 0x24c5: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24c9:
	/* 0x24c9: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24cc:
	/* 0x24cc: jns    24d3 <trace_set_fs_pwd+0x24d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24cc, 0x24d3, x86_l_24d3);
x86_l_24ce:
	/* 0x24ce: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d1:
	/* 0x24d1: jmp    24d6 <trace_set_fs_pwd+0x24d6> */
	X86_SIM_X86_JMP(0x24d1, 0x24d6, x86_l_24d6);
x86_l_24d3:
	/* 0x24d3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24d6:
	/* 0x24d6: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24d9:
	/* 0x24d9: je     2553 <trace_set_fs_pwd+0x2553> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d9, 0x2553, x86_l_2553);
x86_l_24db:
	/* 0x24db: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_24de:
	/* 0x24de: je     2553 <trace_set_fs_pwd+0x2553> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24de, 0x2553, x86_l_2553);
x86_l_24e0:
	/* 0x24e0: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24e4:
	/* 0x24e4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e7:
	/* 0x24e7: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_24ed:
	/* 0x24ed: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24f0:
	/* 0x24f0: jns    24f9 <trace_set_fs_pwd+0x24f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f0, 0x24f9, x86_l_24f9);
x86_l_24f2:
	/* 0x24f2: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24f5:
	/* 0x24f5: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24f9:
	/* 0x24f9: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_24fd:
	/* 0x24fd: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2500:
	/* 0x2500: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2507:
	/* 0x2507: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2509:
	/* 0x2509: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_250c:
	/* 0x250c: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x250c, 0x2bac, x86_l_2bac);
x86_l_2512:
	/* 0x2512: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2515:
	/* 0x2515: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2515, 0x2b58, x86_l_2b58);
x86_l_251b:
	/* 0x251b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2521:
	/* 0x2521: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2524:
	/* 0x2524: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2527:
	/* 0x2527: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2527, 0x29a7, x86_l_29a7);
x86_l_252d:
	/* 0x252d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2531:
	/* 0x2531: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2534:
	/* 0x2534: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2537:
	/* 0x2537: je     25af <trace_set_fs_pwd+0x25af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2537, 0x25af, x86_l_25af);
x86_l_2539:
	/* 0x2539: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_253d:
	/* 0x253d: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2542:
	/* 0x2542: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2546:
	/* 0x2546: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2549:
	/* 0x2549: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_254c:
	/* 0x254c: jne    2534 <trace_set_fs_pwd+0x2534> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x254c, 0x2534, x86_l_2534);
x86_l_254e:
	/* 0x254e: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2551:
	/* 0x2551: jmp    25b4 <trace_set_fs_pwd+0x25b4> */
	X86_SIM_X86_JMP(0x2551, 0x25b4, x86_l_25b4);
x86_l_2553:
	/* 0x2553: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2556:
	/* 0x2556: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2556, 0x2b58, x86_l_2b58);
x86_l_255c:
	/* 0x255c: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2561:
	/* 0x2561: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2561, 0x2b58, x86_l_2b58);
x86_l_2567:
	/* 0x2567: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_256b:
	/* 0x256b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_256e:
	/* 0x256e: jns    2575 <trace_set_fs_pwd+0x2575> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x256e, 0x2575, x86_l_2575);
x86_l_2570:
	/* 0x2570: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2573:
	/* 0x2573: jmp    2578 <trace_set_fs_pwd+0x2578> */
	X86_SIM_X86_JMP(0x2573, 0x2578, x86_l_2578);
x86_l_2575:
	/* 0x2575: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2578:
	/* 0x2578: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_257b:
	/* 0x257b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_257e:
	/* 0x257e: jns    2588 <trace_set_fs_pwd+0x2588> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x257e, 0x2588, x86_l_2588);
x86_l_2580:
	/* 0x2580: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2583:
	/* 0x2583: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2586:
	/* 0x2586: jmp    258a <trace_set_fs_pwd+0x258a> */
	X86_SIM_X86_JMP(0x2586, 0x258a, x86_l_258a);
x86_l_2588:
	/* 0x2588: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258a:
	/* 0x258a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_258d:
	/* 0x258d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2590:
	/* 0x2590: jns    2597 <trace_set_fs_pwd+0x2597> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2590, 0x2597, x86_l_2597);
x86_l_2592:
	/* 0x2592: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2595:
	/* 0x2595: jmp    2599 <trace_set_fs_pwd+0x2599> */
	X86_SIM_X86_JMP(0x2595, 0x2599, x86_l_2599);
x86_l_2597:
	/* 0x2597: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2599:
	/* 0x2599: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_259e:
	/* 0x259e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a2:
	/* 0x25a2: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25a5:
	/* 0x25a5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25a8:
	/* 0x25a8: jns    25d7 <trace_set_fs_pwd+0x25d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25a8, 0x25d7, x86_l_25d7);
x86_l_25aa:
	/* 0x25aa: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ad:
	/* 0x25ad: jmp    25d9 <trace_set_fs_pwd+0x25d9> */
	X86_SIM_X86_JMP(0x25ad, 0x25d9, x86_l_25d9);
x86_l_25af:
	/* 0x25af: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_25b4:
	/* 0x25b4: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_25b8:
	/* 0x25b8: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x25b8, 0x2b58, x86_l_2b58);
x86_l_25be:
	/* 0x25be: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25c1:
	/* 0x25c1: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_25c7:
	/* 0x25c7: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_25cc:
	/* 0x25cc: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25cf:
	/* 0x25cf: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25d2:
	/* 0x25d2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25d5:
	/* 0x25d5: js     25aa <trace_set_fs_pwd+0x25aa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25d5, 0x25aa, x86_l_25aa);
x86_l_25d7:
	/* 0x25d7: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25d9:
	/* 0x25d9: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25dd:
	/* 0x25dd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25e0:
	/* 0x25e0: jns    25e7 <trace_set_fs_pwd+0x25e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e0, 0x25e7, x86_l_25e7);
x86_l_25e2:
	/* 0x25e2: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25e5:
	/* 0x25e5: jmp    25e9 <trace_set_fs_pwd+0x25e9> */
	X86_SIM_X86_JMP(0x25e5, 0x25e9, x86_l_25e9);
x86_l_25e7:
	/* 0x25e7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25e9:
	/* 0x25e9: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25ec:
	/* 0x25ec: je     2666 <trace_set_fs_pwd+0x2666> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ec, 0x2666, x86_l_2666);
x86_l_25ee:
	/* 0x25ee: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25f1:
	/* 0x25f1: je     2666 <trace_set_fs_pwd+0x2666> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f1, 0x2666, x86_l_2666);
x86_l_25f3:
	/* 0x25f3: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25f7:
	/* 0x25f7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25fa:
	/* 0x25fa: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2600:
	/* 0x2600: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2603:
	/* 0x2603: jns    260c <trace_set_fs_pwd+0x260c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2603, 0x260c, x86_l_260c);
x86_l_2605:
	/* 0x2605: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2608:
	/* 0x2608: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_260c:
	/* 0x260c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2610:
	/* 0x2610: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2613:
	/* 0x2613: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_261a:
	/* 0x261a: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_261c:
	/* 0x261c: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_261f:
	/* 0x261f: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x261f, 0x2bac, x86_l_2bac);
x86_l_2625:
	/* 0x2625: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2628:
	/* 0x2628: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2628, 0x2b55, x86_l_2b55);
x86_l_262e:
	/* 0x262e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2634:
	/* 0x2634: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2637:
	/* 0x2637: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_263a:
	/* 0x263a: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x263a, 0x29aa, x86_l_29aa);
x86_l_2640:
	/* 0x2640: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2644:
	/* 0x2644: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2647:
	/* 0x2647: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_264a:
	/* 0x264a: je     26c1 <trace_set_fs_pwd+0x26c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x264a, 0x26c1, x86_l_26c1);
x86_l_264c:
	/* 0x264c: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2650:
	/* 0x2650: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2655:
	/* 0x2655: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2659:
	/* 0x2659: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_265c:
	/* 0x265c: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_265f:
	/* 0x265f: jne    2647 <trace_set_fs_pwd+0x2647> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x265f, 0x2647, x86_l_2647);
x86_l_2661:
	/* 0x2661: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2664:
	/* 0x2664: jmp    26c6 <trace_set_fs_pwd+0x26c6> */
	X86_SIM_X86_JMP(0x2664, 0x26c6, x86_l_26c6);
x86_l_2666:
	/* 0x2666: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2669:
	/* 0x2669: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2669, 0x2b55, x86_l_2b55);
x86_l_266f:
	/* 0x266f: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2674:
	/* 0x2674: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2674, 0x2b55, x86_l_2b55);
x86_l_267a:
	/* 0x267a: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_267e:
	/* 0x267e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2681:
	/* 0x2681: jns    2688 <trace_set_fs_pwd+0x2688> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2681, 0x2688, x86_l_2688);
x86_l_2683:
	/* 0x2683: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2686:
	/* 0x2686: jmp    268a <trace_set_fs_pwd+0x268a> */
	X86_SIM_X86_JMP(0x2686, 0x268a, x86_l_268a);
x86_l_2688:
	/* 0x2688: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268a:
	/* 0x268a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_268d:
	/* 0x268d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2690:
	/* 0x2690: jns    269a <trace_set_fs_pwd+0x269a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2690, 0x269a, x86_l_269a);
x86_l_2692:
	/* 0x2692: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2695:
	/* 0x2695: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2698:
	/* 0x2698: jmp    269c <trace_set_fs_pwd+0x269c> */
	X86_SIM_X86_JMP(0x2698, 0x269c, x86_l_269c);
x86_l_269a:
	/* 0x269a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269c:
	/* 0x269c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_269f:
	/* 0x269f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26a2:
	/* 0x26a2: jns    26a9 <trace_set_fs_pwd+0x26a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26a2, 0x26a9, x86_l_26a9);
x86_l_26a4:
	/* 0x26a4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a7:
	/* 0x26a7: jmp    26ab <trace_set_fs_pwd+0x26ab> */
	X86_SIM_X86_JMP(0x26a7, 0x26ab, x86_l_26ab);
x86_l_26a9:
	/* 0x26a9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26ab:
	/* 0x26ab: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26b0:
	/* 0x26b0: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26b4:
	/* 0x26b4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26b7:
	/* 0x26b7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26ba:
	/* 0x26ba: jns    26e9 <trace_set_fs_pwd+0x26e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26ba, 0x26e9, x86_l_26e9);
x86_l_26bc:
	/* 0x26bc: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26bf:
	/* 0x26bf: jmp    26eb <trace_set_fs_pwd+0x26eb> */
	X86_SIM_X86_JMP(0x26bf, 0x26eb, x86_l_26eb);
x86_l_26c1:
	/* 0x26c1: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_26c6:
	/* 0x26c6: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_26ca:
	/* 0x26ca: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x26ca, 0x2b55, x86_l_2b55);
x86_l_26d0:
	/* 0x26d0: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26d3:
	/* 0x26d3: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_26d9:
	/* 0x26d9: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_26de:
	/* 0x26de: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26e1:
	/* 0x26e1: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26e4:
	/* 0x26e4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26e7:
	/* 0x26e7: js     26bc <trace_set_fs_pwd+0x26bc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26e7, 0x26bc, x86_l_26bc);
x86_l_26e9:
	/* 0x26e9: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26eb:
	/* 0x26eb: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26ef:
	/* 0x26ef: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26f2:
	/* 0x26f2: jns    26f9 <trace_set_fs_pwd+0x26f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f2, 0x26f9, x86_l_26f9);
x86_l_26f4:
	/* 0x26f4: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f7:
	/* 0x26f7: jmp    26fc <trace_set_fs_pwd+0x26fc> */
	X86_SIM_X86_JMP(0x26f7, 0x26fc, x86_l_26fc);
x86_l_26f9:
	/* 0x26f9: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26fc:
	/* 0x26fc: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26ff:
	/* 0x26ff: je     2779 <trace_set_fs_pwd+0x2779> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26ff, 0x2779, x86_l_2779);
x86_l_2701:
	/* 0x2701: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2704:
	/* 0x2704: je     2779 <trace_set_fs_pwd+0x2779> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2704, 0x2779, x86_l_2779);
x86_l_2706:
	/* 0x2706: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_270a:
	/* 0x270a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_270d:
	/* 0x270d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2713:
	/* 0x2713: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2716:
	/* 0x2716: jns    271f <trace_set_fs_pwd+0x271f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2716, 0x271f, x86_l_271f);
x86_l_2718:
	/* 0x2718: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_271b:
	/* 0x271b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_271f:
	/* 0x271f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2723:
	/* 0x2723: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2726:
	/* 0x2726: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_272d:
	/* 0x272d: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_272f:
	/* 0x272f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2732:
	/* 0x2732: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2732, 0x2bac, x86_l_2bac);
x86_l_2738:
	/* 0x2738: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_273b:
	/* 0x273b: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x273b, 0x2b58, x86_l_2b58);
x86_l_2741:
	/* 0x2741: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2747:
	/* 0x2747: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_274a:
	/* 0x274a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_274d:
	/* 0x274d: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x274d, 0x29a7, x86_l_29a7);
x86_l_2753:
	/* 0x2753: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2757:
	/* 0x2757: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_275a:
	/* 0x275a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_275d:
	/* 0x275d: je     27d5 <trace_set_fs_pwd+0x27d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275d, 0x27d5, x86_l_27d5);
x86_l_275f:
	/* 0x275f: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2763:
	/* 0x2763: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2768:
	/* 0x2768: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_276c:
	/* 0x276c: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_276f:
	/* 0x276f: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2772:
	/* 0x2772: jne    275a <trace_set_fs_pwd+0x275a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2772, 0x275a, x86_l_275a);
x86_l_2774:
	/* 0x2774: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2777:
	/* 0x2777: jmp    27da <trace_set_fs_pwd+0x27da> */
	X86_SIM_X86_JMP(0x2777, 0x27da, x86_l_27da);
x86_l_2779:
	/* 0x2779: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_277c:
	/* 0x277c: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277c, 0x2b58, x86_l_2b58);
x86_l_2782:
	/* 0x2782: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2787:
	/* 0x2787: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2787, 0x2b58, x86_l_2b58);
x86_l_278d:
	/* 0x278d: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2791:
	/* 0x2791: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2794:
	/* 0x2794: jns    279b <trace_set_fs_pwd+0x279b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2794, 0x279b, x86_l_279b);
x86_l_2796:
	/* 0x2796: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2799:
	/* 0x2799: jmp    279e <trace_set_fs_pwd+0x279e> */
	X86_SIM_X86_JMP(0x2799, 0x279e, x86_l_279e);
x86_l_279b:
	/* 0x279b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_279e:
	/* 0x279e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27a1:
	/* 0x27a1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27a4:
	/* 0x27a4: jns    27ae <trace_set_fs_pwd+0x27ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a4, 0x27ae, x86_l_27ae);
x86_l_27a6:
	/* 0x27a6: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27a9:
	/* 0x27a9: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ac:
	/* 0x27ac: jmp    27b0 <trace_set_fs_pwd+0x27b0> */
	X86_SIM_X86_JMP(0x27ac, 0x27b0, x86_l_27b0);
x86_l_27ae:
	/* 0x27ae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b0:
	/* 0x27b0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27b3:
	/* 0x27b3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27b6:
	/* 0x27b6: jns    27bd <trace_set_fs_pwd+0x27bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27b6, 0x27bd, x86_l_27bd);
x86_l_27b8:
	/* 0x27b8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27bb:
	/* 0x27bb: jmp    27bf <trace_set_fs_pwd+0x27bf> */
	X86_SIM_X86_JMP(0x27bb, 0x27bf, x86_l_27bf);
x86_l_27bd:
	/* 0x27bd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27bf:
	/* 0x27bf: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_27c4:
	/* 0x27c4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27c8:
	/* 0x27c8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27cb:
	/* 0x27cb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27ce:
	/* 0x27ce: jns    27fd <trace_set_fs_pwd+0x27fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ce, 0x27fd, x86_l_27fd);
x86_l_27d0:
	/* 0x27d0: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d3:
	/* 0x27d3: jmp    27ff <trace_set_fs_pwd+0x27ff> */
	X86_SIM_X86_JMP(0x27d3, 0x27ff, x86_l_27ff);
x86_l_27d5:
	/* 0x27d5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_27da:
	/* 0x27da: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27de:
	/* 0x27de: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x27de, 0x2b58, x86_l_2b58);
x86_l_27e4:
	/* 0x27e4: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27e7:
	/* 0x27e7: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_27ed:
	/* 0x27ed: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_27f2:
	/* 0x27f2: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27f5:
	/* 0x27f5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27f8:
	/* 0x27f8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27fb:
	/* 0x27fb: js     27d0 <trace_set_fs_pwd+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27fb, 0x27d0, x86_l_27d0);
x86_l_27fd:
	/* 0x27fd: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27ff:
	/* 0x27ff: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2803:
	/* 0x2803: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2806:
	/* 0x2806: jns    280d <trace_set_fs_pwd+0x280d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2806, 0x280d, x86_l_280d);
x86_l_2808:
	/* 0x2808: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280b:
	/* 0x280b: jmp    280f <trace_set_fs_pwd+0x280f> */
	X86_SIM_X86_JMP(0x280b, 0x280f, x86_l_280f);
x86_l_280d:
	/* 0x280d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_280f:
	/* 0x280f: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2812:
	/* 0x2812: je     288c <trace_set_fs_pwd+0x288c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2812, 0x288c, x86_l_288c);
x86_l_2814:
	/* 0x2814: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2817:
	/* 0x2817: je     288c <trace_set_fs_pwd+0x288c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2817, 0x288c, x86_l_288c);
x86_l_2819:
	/* 0x2819: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_281d:
	/* 0x281d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2820:
	/* 0x2820: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2826:
	/* 0x2826: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2829:
	/* 0x2829: jns    2832 <trace_set_fs_pwd+0x2832> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2829, 0x2832, x86_l_2832);
x86_l_282b:
	/* 0x282b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_282e:
	/* 0x282e: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2832:
	/* 0x2832: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2836:
	/* 0x2836: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2839:
	/* 0x2839: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2840:
	/* 0x2840: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2842:
	/* 0x2842: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2845:
	/* 0x2845: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2845, 0x2bac, x86_l_2bac);
x86_l_284b:
	/* 0x284b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_284e:
	/* 0x284e: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x284e, 0x2b55, x86_l_2b55);
x86_l_2854:
	/* 0x2854: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_285a:
	/* 0x285a: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_285d:
	/* 0x285d: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2860:
	/* 0x2860: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2860, 0x29aa, x86_l_29aa);
x86_l_2866:
	/* 0x2866: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_286a:
	/* 0x286a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286d:
	/* 0x286d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2870:
	/* 0x2870: je     28e7 <trace_set_fs_pwd+0x28e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2870, 0x28e7, x86_l_28e7);
x86_l_2872:
	/* 0x2872: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2876:
	/* 0x2876: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_287b:
	/* 0x287b: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_287f:
	/* 0x287f: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2882:
	/* 0x2882: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2885:
	/* 0x2885: jne    286d <trace_set_fs_pwd+0x286d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2885, 0x286d, x86_l_286d);
x86_l_2887:
	/* 0x2887: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_288a:
	/* 0x288a: jmp    28ec <trace_set_fs_pwd+0x28ec> */
	X86_SIM_X86_JMP(0x288a, 0x28ec, x86_l_28ec);
x86_l_288c:
	/* 0x288c: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_288f:
	/* 0x288f: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x288f, 0x2b55, x86_l_2b55);
x86_l_2895:
	/* 0x2895: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_289a:
	/* 0x289a: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x289a, 0x2b55, x86_l_2b55);
x86_l_28a0:
	/* 0x28a0: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28a4:
	/* 0x28a4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28a7:
	/* 0x28a7: jns    28ae <trace_set_fs_pwd+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28a7, 0x28ae, x86_l_28ae);
x86_l_28a9:
	/* 0x28a9: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ac:
	/* 0x28ac: jmp    28b0 <trace_set_fs_pwd+0x28b0> */
	X86_SIM_X86_JMP(0x28ac, 0x28b0, x86_l_28b0);
x86_l_28ae:
	/* 0x28ae: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b0:
	/* 0x28b0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28b3:
	/* 0x28b3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28b6:
	/* 0x28b6: jns    28c0 <trace_set_fs_pwd+0x28c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b6, 0x28c0, x86_l_28c0);
x86_l_28b8:
	/* 0x28b8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28bb:
	/* 0x28bb: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28be:
	/* 0x28be: jmp    28c2 <trace_set_fs_pwd+0x28c2> */
	X86_SIM_X86_JMP(0x28be, 0x28c2, x86_l_28c2);
x86_l_28c0:
	/* 0x28c0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c2:
	/* 0x28c2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28c5:
	/* 0x28c5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28c8:
	/* 0x28c8: jns    28cf <trace_set_fs_pwd+0x28cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c8, 0x28cf, x86_l_28cf);
x86_l_28ca:
	/* 0x28ca: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28cd:
	/* 0x28cd: jmp    28d1 <trace_set_fs_pwd+0x28d1> */
	X86_SIM_X86_JMP(0x28cd, 0x28d1, x86_l_28d1);
x86_l_28cf:
	/* 0x28cf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d1:
	/* 0x28d1: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28d6:
	/* 0x28d6: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28da:
	/* 0x28da: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28dd:
	/* 0x28dd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28e0:
	/* 0x28e0: jns    290f <trace_set_fs_pwd+0x290f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28e0, 0x290f, x86_l_290f);
x86_l_28e2:
	/* 0x28e2: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28e5:
	/* 0x28e5: jmp    2911 <trace_set_fs_pwd+0x2911> */
	X86_SIM_X86_JMP(0x28e5, 0x2911, x86_l_2911);
x86_l_28e7:
	/* 0x28e7: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_28ec:
	/* 0x28ec: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_28f0:
	/* 0x28f0: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x28f0, 0x2b55, x86_l_2b55);
x86_l_28f6:
	/* 0x28f6: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_28f9:
	/* 0x28f9: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_28ff:
	/* 0x28ff: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2904:
	/* 0x2904: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2907:
	/* 0x2907: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_290a:
	/* 0x290a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_290d:
	/* 0x290d: js     28e2 <trace_set_fs_pwd+0x28e2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x290d, 0x28e2, x86_l_28e2);
x86_l_290f:
	/* 0x290f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2911:
	/* 0x2911: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2915:
	/* 0x2915: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2918:
	/* 0x2918: jns    291f <trace_set_fs_pwd+0x291f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2918, 0x291f, x86_l_291f);
x86_l_291a:
	/* 0x291a: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_291d:
	/* 0x291d: jmp    2922 <trace_set_fs_pwd+0x2922> */
	X86_SIM_X86_JMP(0x291d, 0x2922, x86_l_2922);
x86_l_291f:
	/* 0x291f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2922:
	/* 0x2922: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2925:
	/* 0x2925: je     29b9 <trace_set_fs_pwd+0x29b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2925, 0x29b9, x86_l_29b9);
x86_l_292b:
	/* 0x292b: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_292e:
	/* 0x292e: je     29b9 <trace_set_fs_pwd+0x29b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x292e, 0x29b9, x86_l_29b9);
x86_l_2934:
	/* 0x2934: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2938:
	/* 0x2938: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_293b:
	/* 0x293b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2941:
	/* 0x2941: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2944:
	/* 0x2944: jns    294d <trace_set_fs_pwd+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2944, 0x294d, x86_l_294d);
x86_l_2946:
	/* 0x2946: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2949:
	/* 0x2949: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_294d:
	/* 0x294d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2951:
	/* 0x2951: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2954:
	/* 0x2954: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_295b:
	/* 0x295b: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_295d:
	/* 0x295d: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2960:
	/* 0x2960: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2960, 0x2bac, x86_l_2bac);
x86_l_2966:
	/* 0x2966: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2969:
	/* 0x2969: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2969, 0x2b58, x86_l_2b58);
x86_l_296f:
	/* 0x296f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2975:
	/* 0x2975: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2978:
	/* 0x2978: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_297b:
	/* 0x297b: jns    29a7 <trace_set_fs_pwd+0x29a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x297b, 0x29a7, x86_l_29a7);
x86_l_297d:
	/* 0x297d: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2981:
	/* 0x2981: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2984:
	/* 0x2984: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2987:
	/* 0x2987: je     2a15 <trace_set_fs_pwd+0x2a15> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2987, 0x2a15, x86_l_2a15);
x86_l_298d:
	/* 0x298d: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2991:
	/* 0x2991: movzx  r13d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2996:
	/* 0x2996: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_299a:
	/* 0x299a: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_299d:
	/* 0x299d: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_29a0:
	/* 0x29a0: jne    2984 <trace_set_fs_pwd+0x2984> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29a0, 0x2984, x86_l_2984);
x86_l_29a2:
	/* 0x29a2: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_29a5:
	/* 0x29a5: jmp    2a1a <trace_set_fs_pwd+0x2a1a> */
	X86_SIM_X86_JMP(0x29a5, 0x2a1a, x86_l_2a1a);
x86_l_29a7:
	/* 0x29a7: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29aa:
	/* 0x29aa: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29af:
	/* 0x29af: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29b4:
	/* 0x29b4: jmp    1566 <trace_set_fs_pwd+0x1566> */
	X86_SIM_X86_JMP(0x29b4, 0x1566, x86_l_1566);
x86_l_29b9:
	/* 0x29b9: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29bc:
	/* 0x29bc: jne    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29bc, 0x2b58, x86_l_2b58);
x86_l_29c2:
	/* 0x29c2: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_29c7:
	/* 0x29c7: je     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29c7, 0x2b58, x86_l_2b58);
x86_l_29cd:
	/* 0x29cd: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29d1:
	/* 0x29d1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29d4:
	/* 0x29d4: jns    29db <trace_set_fs_pwd+0x29db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d4, 0x29db, x86_l_29db);
x86_l_29d6:
	/* 0x29d6: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d9:
	/* 0x29d9: jmp    29de <trace_set_fs_pwd+0x29de> */
	X86_SIM_X86_JMP(0x29d9, 0x29de, x86_l_29de);
x86_l_29db:
	/* 0x29db: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29de:
	/* 0x29de: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29e1:
	/* 0x29e1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29e4:
	/* 0x29e4: jns    29ee <trace_set_fs_pwd+0x29ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29e4, 0x29ee, x86_l_29ee);
x86_l_29e6:
	/* 0x29e6: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29e9:
	/* 0x29e9: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ec:
	/* 0x29ec: jmp    29f0 <trace_set_fs_pwd+0x29f0> */
	X86_SIM_X86_JMP(0x29ec, 0x29f0, x86_l_29f0);
x86_l_29ee:
	/* 0x29ee: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f0:
	/* 0x29f0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29f3:
	/* 0x29f3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29f6:
	/* 0x29f6: jns    29fd <trace_set_fs_pwd+0x29fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f6, 0x29fd, x86_l_29fd);
x86_l_29f8:
	/* 0x29f8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29fb:
	/* 0x29fb: jmp    29ff <trace_set_fs_pwd+0x29ff> */
	X86_SIM_X86_JMP(0x29fb, 0x29ff, x86_l_29ff);
x86_l_29fd:
	/* 0x29fd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29ff:
	/* 0x29ff: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a04:
	/* 0x2a04: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a08:
	/* 0x2a08: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a0b:
	/* 0x2a0b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a0e:
	/* 0x2a0e: jns    2a3d <trace_set_fs_pwd+0x2a3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a0e, 0x2a3d, x86_l_2a3d);
x86_l_2a10:
	/* 0x2a10: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a13:
	/* 0x2a13: jmp    2a3f <trace_set_fs_pwd+0x2a3f> */
	X86_SIM_X86_JMP(0x2a13, 0x2a3f, x86_l_2a3f);
x86_l_2a15:
	/* 0x2a15: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2a1a:
	/* 0x2a1a: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2a1e:
	/* 0x2a1e: jl     2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2a1e, 0x2b58, x86_l_2b58);
x86_l_2a24:
	/* 0x2a24: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a27:
	/* 0x2a27: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2a2d:
	/* 0x2a2d: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2a32:
	/* 0x2a32: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a35:
	/* 0x2a35: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a38:
	/* 0x2a38: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a3b:
	/* 0x2a3b: js     2a10 <trace_set_fs_pwd+0x2a10> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a3b, 0x2a10, x86_l_2a10);
x86_l_2a3d:
	/* 0x2a3d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a3f:
	/* 0x2a3f: lea    rdi,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a43:
	/* 0x2a43: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a46:
	/* 0x2a46: jns    2a4d <trace_set_fs_pwd+0x2a4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a46, 0x2a4d, x86_l_2a4d);
x86_l_2a48:
	/* 0x2a48: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a4b:
	/* 0x2a4b: jmp    2a50 <trace_set_fs_pwd+0x2a50> */
	X86_SIM_X86_JMP(0x2a4b, 0x2a50, x86_l_2a50);
x86_l_2a4d:
	/* 0x2a4d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a50:
	/* 0x2a50: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a53:
	/* 0x2a53: je     2acc <trace_set_fs_pwd+0x2acc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a53, 0x2acc, x86_l_2acc);
x86_l_2a55:
	/* 0x2a55: cmp    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2a58:
	/* 0x2a58: je     2acc <trace_set_fs_pwd+0x2acc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a58, 0x2acc, x86_l_2acc);
x86_l_2a5a:
	/* 0x2a5a: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a5e:
	/* 0x2a5e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a61:
	/* 0x2a61: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2a66:
	/* 0x2a66: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a69:
	/* 0x2a69: jns    2a72 <trace_set_fs_pwd+0x2a72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a69, 0x2a72, x86_l_2a72);
x86_l_2a6b:
	/* 0x2a6b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a72:
	/* 0x2a72: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2a76:
	/* 0x2a76: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a79:
	/* 0x2a79: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a80:
	/* 0x2a80: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2a82:
	/* 0x2a82: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a85:
	/* 0x2a85: jb     2bac <trace_set_fs_pwd+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a85, 0x2bac, x86_l_2bac);
x86_l_2a8b:
	/* 0x2a8b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2a8e:
	/* 0x2a8e: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8e, 0x2b55, x86_l_2b55);
x86_l_2a94:
	/* 0x2a94: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a9a:
	/* 0x2a9a: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a9d:
	/* 0x2a9d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2aa0:
	/* 0x2aa0: jns    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aa0, 0x29aa, x86_l_29aa);
x86_l_2aa6:
	/* 0x2aa6: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2aaa:
	/* 0x2aaa: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aad:
	/* 0x2aad: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2ab0:
	/* 0x2ab0: je     2b24 <trace_set_fs_pwd+0x2b24> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ab0, 0x2b24, x86_l_2b24);
x86_l_2ab2:
	/* 0x2ab2: lea    r12,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2ab6:
	/* 0x2ab6: movzx  r13d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2abb:
	/* 0x2abb: mov    BYTE PTR [rdi+r11*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2abf:
	/* 0x2abf: mov    r11,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ac2:
	/* 0x2ac2: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_2ac5:
	/* 0x2ac5: jne    2aad <trace_set_fs_pwd+0x2aad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ac5, 0x2aad, x86_l_2aad);
x86_l_2ac7:
	/* 0x2ac7: mov    r8d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2aca:
	/* 0x2aca: jmp    2b29 <trace_set_fs_pwd+0x2b29> */
	X86_SIM_X86_JMP(0x2aca, 0x2b29, x86_l_2b29);
x86_l_2acc:
	/* 0x2acc: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2acf:
	/* 0x2acf: jne    2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2acf, 0x2b55, x86_l_2b55);
x86_l_2ad5:
	/* 0x2ad5: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2ada:
	/* 0x2ada: je     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ada, 0x2b55, x86_l_2b55);
x86_l_2adc:
	/* 0x2adc: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ae0:
	/* 0x2ae0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ae3:
	/* 0x2ae3: jns    2aea <trace_set_fs_pwd+0x2aea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ae3, 0x2aea, x86_l_2aea);
x86_l_2ae5:
	/* 0x2ae5: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae8:
	/* 0x2ae8: jmp    2aed <trace_set_fs_pwd+0x2aed> */
	X86_SIM_X86_JMP(0x2ae8, 0x2aed, x86_l_2aed);
x86_l_2aea:
	/* 0x2aea: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aed:
	/* 0x2aed: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af0:
	/* 0x2af0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2af3:
	/* 0x2af3: jns    2afd <trace_set_fs_pwd+0x2afd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2af3, 0x2afd, x86_l_2afd);
x86_l_2af5:
	/* 0x2af5: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2af8:
	/* 0x2af8: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2afb:
	/* 0x2afb: jmp    2aff <trace_set_fs_pwd+0x2aff> */
	X86_SIM_X86_JMP(0x2afb, 0x2aff, x86_l_2aff);
x86_l_2afd:
	/* 0x2afd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aff:
	/* 0x2aff: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b02:
	/* 0x2b02: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b05:
	/* 0x2b05: jns    2b0c <trace_set_fs_pwd+0x2b0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b05, 0x2b0c, x86_l_2b0c);
x86_l_2b07:
	/* 0x2b07: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b0a:
	/* 0x2b0a: jmp    2b0e <trace_set_fs_pwd+0x2b0e> */
	X86_SIM_X86_JMP(0x2b0a, 0x2b0e, x86_l_2b0e);
x86_l_2b0c:
	/* 0x2b0c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b0e:
	/* 0x2b0e: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b13:
	/* 0x2b13: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b17:
	/* 0x2b17: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b1a:
	/* 0x2b1a: jns    2b45 <trace_set_fs_pwd+0x2b45> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b1a, 0x2b45, x86_l_2b45);
x86_l_2b1c:
	/* 0x2b1c: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b1f:
	/* 0x2b1f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b22:
	/* 0x2b22: jmp    2b47 <trace_set_fs_pwd+0x2b47> */
	X86_SIM_X86_JMP(0x2b22, 0x2b47, x86_l_2b47);
x86_l_2b24:
	/* 0x2b24: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2b29:
	/* 0x2b29: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2b2d:
	/* 0x2b2d: jl     2b55 <trace_set_fs_pwd+0x2b55> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2b2d, 0x2b55, x86_l_2b55);
x86_l_2b2f:
	/* 0x2b2f: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2b32:
	/* 0x2b32: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b38:
	/* 0x2b38: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2b3d:
	/* 0x2b3d: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b40:
	/* 0x2b40: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b43:
	/* 0x2b43: js     2b1c <trace_set_fs_pwd+0x2b1c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b43, 0x2b1c, x86_l_2b1c);
x86_l_2b45:
	/* 0x2b45: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b47:
	/* 0x2b47: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b4b:
	/* 0x2b4b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b4e:
	/* 0x2b4e: jns    2b67 <trace_set_fs_pwd+0x2b67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b4e, 0x2b67, x86_l_2b67);
x86_l_2b50:
	/* 0x2b50: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b53:
	/* 0x2b53: jmp    2b69 <trace_set_fs_pwd+0x2b69> */
	X86_SIM_X86_JMP(0x2b53, 0x2b69, x86_l_2b69);
x86_l_2b55:
	/* 0x2b55: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2b58:
	/* 0x2b58: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b5d:
	/* 0x2b5d: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b62:
	/* 0x2b62: jmp    1573 <trace_set_fs_pwd+0x1573> */
	X86_SIM_X86_JMP(0x2b62, 0x1573, x86_l_1573);
x86_l_2b67:
	/* 0x2b67: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b69:
	/* 0x2b69: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b6c:
	/* 0x2b6c: je     32d6 <trace_set_fs_pwd+0x32d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b6c, 0x32d6, x86_l_32d6);
x86_l_2b72:
	/* 0x2b72: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b75:
	/* 0x2b75: je     32d6 <trace_set_fs_pwd+0x32d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b75, 0x32d6, x86_l_32d6);
x86_l_2b7b:
	/* 0x2b7b: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b7f:
	/* 0x2b7f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b82:
	/* 0x2b82: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2b87:
	/* 0x2b87: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b8a:
	/* 0x2b8a: jns    2b93 <trace_set_fs_pwd+0x2b93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b8a, 0x2b93, x86_l_2b93);
x86_l_2b8c:
	/* 0x2b8c: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b8f:
	/* 0x2b8f: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b93:
	/* 0x2b93: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b97:
	/* 0x2b97: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b9a:
	/* 0x2b9a: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2ba1:
	/* 0x2ba1: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2ba3:
	/* 0x2ba3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2ba6:
	/* 0x2ba6: jae    32f8 <trace_set_fs_pwd+0x32f8> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2ba6, 0x32f8, x86_l_32f8);
x86_l_2bac:
	/* 0x2bac: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bb1:
	/* 0x2bb1: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bb6:
	/* 0x2bb6: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2bb8:
	/* 0x2bb8: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2bba:
	/* 0x2bba: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2bbf:
	/* 0x2bbf: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2bc4:
	/* 0x2bc4: mov    BYTE PTR [rbp+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2bcb:
	/* 0x2bcb: and    ebx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2bd1:
	/* 0x2bd1: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2bd4:
	/* 0x2bd4: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2bdc:
	/* 0x2bdc: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2be2:
	/* 0x2be2: ja     2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2be2, 0x2d85, x86_l_2d85);
x86_l_2be8:
	/* 0x2be8: mov    BYTE PTR [r14+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_2bf1:
	/* 0x2bf1: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2bf9:
	/* 0x2bf9: mov    WORD PTR [r14+0x7d8c],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2c01:
	/* 0x2c01: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2c08:
	/* 0x2c08: ja     2cb5 <trace_set_fs_pwd+0x2cb5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c08, 0x2cb5, x86_l_2cb5);
x86_l_2c0e:
	/* 0x2c0e: lea    rdi,[rdx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2c12:
	/* 0x2c12: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2c19:
	/* 0x2c19: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c1c:
	/* 0x2c1c: jns    2c43 <trace_set_fs_pwd+0x2c43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c1c, 0x2c43, x86_l_2c43);
x86_l_2c1e:
	/* 0x2c1e: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c21:
	/* 0x2c21: jns    2c59 <trace_set_fs_pwd+0x2c59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c21, 0x2c59, x86_l_2c59);
x86_l_2c23:
	/* 0x2c23: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c25:
	/* 0x2c25: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2c2c:
	/* 0x2c2c: je     2c6f <trace_set_fs_pwd+0x2c6f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c2c, 0x2c6f, x86_l_2c6f);
x86_l_2c2e:
	/* 0x2c2e: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2c32:
	/* 0x2c32: movzx  edx,BYTE PTR [r12+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2c37:
	/* 0x2c37: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2c3a:
	/* 0x2c3a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c3d:
	/* 0x2c3d: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2c3f:
	/* 0x2c3f: jne    2c25 <trace_set_fs_pwd+0x2c25> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c3f, 0x2c25, x86_l_2c25);
x86_l_2c41:
	/* 0x2c41: jmp    2c50 <trace_set_fs_pwd+0x2c50> */
	X86_SIM_X86_JMP(0x2c41, 0x2c50, x86_l_2c50);
x86_l_2c43:
	/* 0x2c43: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c48:
	/* 0x2c48: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c4b:
	/* 0x2c4b: call   2c50 <trace_set_fs_pwd+0x2c50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2c50:
	/* 0x2c50: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c53:
	/* 0x2c53: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2c55:
	/* 0x2c55: jg     2c80 <trace_set_fs_pwd+0x2c80> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2c55, 0x2c80, x86_l_2c80);
x86_l_2c57:
	/* 0x2c57: jmp    2c65 <trace_set_fs_pwd+0x2c65> */
	X86_SIM_X86_JMP(0x2c57, 0x2c65, x86_l_2c65);
x86_l_2c59:
	/* 0x2c59: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c5e:
	/* 0x2c5e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c60:
	/* 0x2c60: call   2c65 <trace_set_fs_pwd+0x2c65> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2c65:
	/* 0x2c65: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2c6d:
	/* 0x2c6d: jmp    2cb5 <trace_set_fs_pwd+0x2cb5> */
	X86_SIM_X86_JMP(0x2c6d, 0x2cb5, x86_l_2cb5);
x86_l_2c6f:
	/* 0x2c6f: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2c76:
	/* 0x2c76: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c7b:
	/* 0x2c7b: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2c80:
	/* 0x2c80: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2c88:
	/* 0x2c88: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2c8f:
	/* 0x2c8f: ja     2cb5 <trace_set_fs_pwd+0x2cb5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c8f, 0x2cb5, x86_l_2cb5);
x86_l_2c91:
	/* 0x2c91: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2c99:
	/* 0x2c99: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2ca1:
	/* 0x2ca1: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2ca4:
	/* 0x2ca4: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2cac:
	/* 0x2cac: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2cb3:
	/* 0x2cb3: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2cb5:
	/* 0x2cb5: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2cb8:
	/* 0x2cb8: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_2cbd:
	/* 0x2cbd: ja     2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cbd, 0x2d85, x86_l_2d85);
x86_l_2cc3:
	/* 0x2cc3: mov    BYTE PTR [r14+rax*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519553ULL);
x86_l_2ccc:
	/* 0x2ccc: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2cd4:
	/* 0x2cd4: mov    WORD PTR [r14+0x7d8e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32142ULL);
x86_l_2cdc:
	/* 0x2cdc: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2ce2:
	/* 0x2ce2: ja     2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ce2, 0x2d85, x86_l_2d85);
x86_l_2ce8:
	/* 0x2ce8: lea    rdi,[rax+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2cec:
	/* 0x2cec: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2cf3:
	/* 0x2cf3: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2cf6:
	/* 0x2cf6: jns    2d1d <trace_set_fs_pwd+0x2d1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cf6, 0x2d1d, x86_l_2d1d);
x86_l_2cf8:
	/* 0x2cf8: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2cfb:
	/* 0x2cfb: jns    2d33 <trace_set_fs_pwd+0x2d33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cfb, 0x2d33, x86_l_2d33);
x86_l_2cfd:
	/* 0x2cfd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cff:
	/* 0x2cff: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2d06:
	/* 0x2d06: je     2d41 <trace_set_fs_pwd+0x2d41> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d06, 0x2d41, x86_l_2d41);
x86_l_2d08:
	/* 0x2d08: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d0c:
	/* 0x2d0c: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2d11:
	/* 0x2d11: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2d14:
	/* 0x2d14: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d17:
	/* 0x2d17: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2d19:
	/* 0x2d19: jne    2cff <trace_set_fs_pwd+0x2cff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d19, 0x2cff, x86_l_2cff);
x86_l_2d1b:
	/* 0x2d1b: jmp    2d2a <trace_set_fs_pwd+0x2d2a> */
	X86_SIM_X86_JMP(0x2d1b, 0x2d2a, x86_l_2d2a);
x86_l_2d1d:
	/* 0x2d1d: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d22:
	/* 0x2d22: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d25:
	/* 0x2d25: call   2d2a <trace_set_fs_pwd+0x2d2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2d2a:
	/* 0x2d2a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d2d:
	/* 0x2d2d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d2f:
	/* 0x2d2f: jg     2d52 <trace_set_fs_pwd+0x2d52> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d2f, 0x2d52, x86_l_2d52);
x86_l_2d31:
	/* 0x2d31: jmp    2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JMP(0x2d31, 0x2d85, x86_l_2d85);
x86_l_2d33:
	/* 0x2d33: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d38:
	/* 0x2d38: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d3a:
	/* 0x2d3a: call   2d3f <trace_set_fs_pwd+0x2d3f> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2d3f:
	/* 0x2d3f: jmp    2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JMP(0x2d3f, 0x2d85, x86_l_2d85);
x86_l_2d41:
	/* 0x2d41: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2d48:
	/* 0x2d48: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d4d:
	/* 0x2d4d: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d52:
	/* 0x2d52: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d5a:
	/* 0x2d5a: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2d61:
	/* 0x2d61: ja     2d85 <trace_set_fs_pwd+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d61, 0x2d85, x86_l_2d85);
x86_l_2d63:
	/* 0x2d63: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2d6b:
	/* 0x2d6b: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2d73:
	/* 0x2d73: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2d76:
	/* 0x2d76: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2d7e:
	/* 0x2d7e: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2d85:
	/* 0x2d85: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2d8c:
	/* 0x2d8c: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d90:
	/* 0x2d90: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d93:
	/* 0x2d93: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d96:
	/* 0x2d96: jns    2da8 <trace_set_fs_pwd+0x2da8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d96, 0x2da8, x86_l_2da8);
x86_l_2d98:
	/* 0x2d98: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d9b:
	/* 0x2d9b: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d9f:
	/* 0x2d9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2da2:
	/* 0x2da2: js     2db4 <trace_set_fs_pwd+0x2db4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2da2, 0x2db4, x86_l_2db4);
x86_l_2da4:
	/* 0x2da4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2da6:
	/* 0x2da6: jmp    2db7 <trace_set_fs_pwd+0x2db7> */
	X86_SIM_X86_JMP(0x2da6, 0x2db7, x86_l_2db7);
x86_l_2da8:
	/* 0x2da8: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dab:
	/* 0x2dab: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2daf:
	/* 0x2daf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2db2:
	/* 0x2db2: jns    2da4 <trace_set_fs_pwd+0x2da4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2db2, 0x2da4, x86_l_2da4);
x86_l_2db4:
	/* 0x2db4: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db7:
	/* 0x2db7: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2dbb:
	/* 0x2dbb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dbd:
	/* 0x2dbd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2dc0:
	/* 0x2dc0: jns    2dd1 <trace_set_fs_pwd+0x2dd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dc0, 0x2dd1, x86_l_2dd1);
x86_l_2dc2:
	/* 0x2dc2: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dc5:
	/* 0x2dc5: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2dca:
	/* 0x2dca: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2dcd:
	/* 0x2dcd: js     2dde <trace_set_fs_pwd+0x2dde> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dcd, 0x2dde, x86_l_2dde);
x86_l_2dcf:
	/* 0x2dcf: jmp    2de0 <trace_set_fs_pwd+0x2de0> */
	X86_SIM_X86_JMP(0x2dcf, 0x2de0, x86_l_2de0);
x86_l_2dd1:
	/* 0x2dd1: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dd4:
	/* 0x2dd4: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2dd9:
	/* 0x2dd9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ddc:
	/* 0x2ddc: jns    2de0 <trace_set_fs_pwd+0x2de0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ddc, 0x2de0, x86_l_2de0);
x86_l_2dde:
	/* 0x2dde: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de0:
	/* 0x2de0: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2de4:
	/* 0x2de4: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2de8:
	/* 0x2de8: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2deb:
	/* 0x2deb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ded:
	/* 0x2ded: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2df0:
	/* 0x2df0: jns    2dff <trace_set_fs_pwd+0x2dff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2df0, 0x2dff, x86_l_2dff);
x86_l_2df2:
	/* 0x2df2: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2df5:
	/* 0x2df5: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2df8:
	/* 0x2df8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2dfb:
	/* 0x2dfb: js     2e09 <trace_set_fs_pwd+0x2e09> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dfb, 0x2e09, x86_l_2e09);
x86_l_2dfd:
	/* 0x2dfd: jmp    2e0b <trace_set_fs_pwd+0x2e0b> */
	X86_SIM_X86_JMP(0x2dfd, 0x2e0b, x86_l_2e0b);
x86_l_2dff:
	/* 0x2dff: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e01:
	/* 0x2e01: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e04:
	/* 0x2e04: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2e07:
	/* 0x2e07: jns    2e0b <trace_set_fs_pwd+0x2e0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e07, 0x2e0b, x86_l_2e0b);
x86_l_2e09:
	/* 0x2e09: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e0b:
	/* 0x2e0b: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2e0d:
	/* 0x2e0d: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2e11:
	/* 0x2e11: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e14:
	/* 0x2e14: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2e18:
	/* 0x2e18: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e1a:
	/* 0x2e1a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e1d:
	/* 0x2e1d: jns    2e21 <trace_set_fs_pwd+0x2e21> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1d, 0x2e21, x86_l_2e21);
x86_l_2e1f:
	/* 0x2e1f: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e21:
	/* 0x2e21: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2e25:
	/* 0x2e25: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e28:
	/* 0x2e28: jns    2e2f <trace_set_fs_pwd+0x2e2f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e28, 0x2e2f, x86_l_2e2f);
x86_l_2e2a:
	/* 0x2e2a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e2d:
	/* 0x2e2d: jmp    2e31 <trace_set_fs_pwd+0x2e31> */
	X86_SIM_X86_JMP(0x2e2d, 0x2e31, x86_l_2e31);
x86_l_2e2f:
	/* 0x2e2f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e31:
	/* 0x2e31: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e35:
	/* 0x2e35: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e37:
	/* 0x2e37: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e3a:
	/* 0x2e3a: jns    2e49 <trace_set_fs_pwd+0x2e49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e3a, 0x2e49, x86_l_2e49);
x86_l_2e3c:
	/* 0x2e3c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e3f:
	/* 0x2e3f: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e42:
	/* 0x2e42: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e45:
	/* 0x2e45: js     2e53 <trace_set_fs_pwd+0x2e53> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e45, 0x2e53, x86_l_2e53);
x86_l_2e47:
	/* 0x2e47: jmp    2e55 <trace_set_fs_pwd+0x2e55> */
	X86_SIM_X86_JMP(0x2e47, 0x2e55, x86_l_2e55);
x86_l_2e49:
	/* 0x2e49: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e4b:
	/* 0x2e4b: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e4e:
	/* 0x2e4e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e51:
	/* 0x2e51: jns    2e55 <trace_set_fs_pwd+0x2e55> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e51, 0x2e55, x86_l_2e55);
x86_l_2e53:
	/* 0x2e53: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e55:
	/* 0x2e55: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2e57:
	/* 0x2e57: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2e5b:
	/* 0x2e5b: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e5e:
	/* 0x2e5e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2e62:
	/* 0x2e62: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e64:
	/* 0x2e64: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e67:
	/* 0x2e67: jns    2e6b <trace_set_fs_pwd+0x2e6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e67, 0x2e6b, x86_l_2e6b);
x86_l_2e69:
	/* 0x2e69: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e6b:
	/* 0x2e6b: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2e6f:
	/* 0x2e6f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e71:
	/* 0x2e71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e74:
	/* 0x2e74: jns    2e83 <trace_set_fs_pwd+0x2e83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e74, 0x2e83, x86_l_2e83);
x86_l_2e76:
	/* 0x2e76: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e79:
	/* 0x2e79: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e7c:
	/* 0x2e7c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e7f:
	/* 0x2e7f: js     2e8d <trace_set_fs_pwd+0x2e8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e7f, 0x2e8d, x86_l_2e8d);
x86_l_2e81:
	/* 0x2e81: jmp    2e8f <trace_set_fs_pwd+0x2e8f> */
	X86_SIM_X86_JMP(0x2e81, 0x2e8f, x86_l_2e8f);
x86_l_2e83:
	/* 0x2e83: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e85:
	/* 0x2e85: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e88:
	/* 0x2e88: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e8b:
	/* 0x2e8b: jns    2e8f <trace_set_fs_pwd+0x2e8f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e8b, 0x2e8f, x86_l_2e8f);
x86_l_2e8d:
	/* 0x2e8d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e8f:
	/* 0x2e8f: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2e91:
	/* 0x2e91: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2e95:
	/* 0x2e95: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e98:
	/* 0x2e98: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e9c:
	/* 0x2e9c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e9e:
	/* 0x2e9e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ea1:
	/* 0x2ea1: jns    2eb1 <trace_set_fs_pwd+0x2eb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ea1, 0x2eb1, x86_l_2eb1);
x86_l_2ea3:
	/* 0x2ea3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea6:
	/* 0x2ea6: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2eaa:
	/* 0x2eaa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ead:
	/* 0x2ead: js     2ebc <trace_set_fs_pwd+0x2ebc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ead, 0x2ebc, x86_l_2ebc);
x86_l_2eaf:
	/* 0x2eaf: jmp    2ebe <trace_set_fs_pwd+0x2ebe> */
	X86_SIM_X86_JMP(0x2eaf, 0x2ebe, x86_l_2ebe);
x86_l_2eb1:
	/* 0x2eb1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eb3:
	/* 0x2eb3: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2eb7:
	/* 0x2eb7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2eba:
	/* 0x2eba: jns    2ebe <trace_set_fs_pwd+0x2ebe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eba, 0x2ebe, x86_l_2ebe);
x86_l_2ebc:
	/* 0x2ebc: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ebe:
	/* 0x2ebe: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ec3:
	/* 0x2ec3: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ec6:
	/* 0x2ec6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ec8:
	/* 0x2ec8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ecb:
	/* 0x2ecb: jns    2eda <trace_set_fs_pwd+0x2eda> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ecb, 0x2eda, x86_l_2eda);
x86_l_2ecd:
	/* 0x2ecd: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ed0:
	/* 0x2ed0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ed3:
	/* 0x2ed3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2ed6:
	/* 0x2ed6: js     2ee4 <trace_set_fs_pwd+0x2ee4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ed6, 0x2ee4, x86_l_2ee4);
x86_l_2ed8:
	/* 0x2ed8: jmp    2ee6 <trace_set_fs_pwd+0x2ee6> */
	X86_SIM_X86_JMP(0x2ed8, 0x2ee6, x86_l_2ee6);
x86_l_2eda:
	/* 0x2eda: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2edc:
	/* 0x2edc: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2edf:
	/* 0x2edf: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2ee2:
	/* 0x2ee2: jns    2ee6 <trace_set_fs_pwd+0x2ee6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee2, 0x2ee6, x86_l_2ee6);
x86_l_2ee4:
	/* 0x2ee4: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee6:
	/* 0x2ee6: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2ee8:
	/* 0x2ee8: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2eec:
	/* 0x2eec: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2eef:
	/* 0x2eef: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2ef3:
	/* 0x2ef3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ef5:
	/* 0x2ef5: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ef8:
	/* 0x2ef8: jns    2f08 <trace_set_fs_pwd+0x2f08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ef8, 0x2f08, x86_l_2f08);
x86_l_2efa:
	/* 0x2efa: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2efd:
	/* 0x2efd: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2f01:
	/* 0x2f01: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f04:
	/* 0x2f04: js     2f13 <trace_set_fs_pwd+0x2f13> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f04, 0x2f13, x86_l_2f13);
x86_l_2f06:
	/* 0x2f06: jmp    2f15 <trace_set_fs_pwd+0x2f15> */
	X86_SIM_X86_JMP(0x2f06, 0x2f15, x86_l_2f15);
x86_l_2f08:
	/* 0x2f08: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f0a:
	/* 0x2f0a: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2f0e:
	/* 0x2f0e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f11:
	/* 0x2f11: jns    2f15 <trace_set_fs_pwd+0x2f15> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f11, 0x2f15, x86_l_2f15);
x86_l_2f13:
	/* 0x2f13: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f15:
	/* 0x2f15: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f17:
	/* 0x2f17: jne    2f53 <trace_set_fs_pwd+0x2f53> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f17, 0x2f53, x86_l_2f53);
x86_l_2f19:
	/* 0x2f19: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f1b:
	/* 0x2f1b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f1e:
	/* 0x2f1e: jns    2f2d <trace_set_fs_pwd+0x2f2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f1e, 0x2f2d, x86_l_2f2d);
x86_l_2f20:
	/* 0x2f20: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f23:
	/* 0x2f23: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f26:
	/* 0x2f26: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f29:
	/* 0x2f29: js     2f37 <trace_set_fs_pwd+0x2f37> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f29, 0x2f37, x86_l_2f37);
x86_l_2f2b:
	/* 0x2f2b: jmp    2f39 <trace_set_fs_pwd+0x2f39> */
	X86_SIM_X86_JMP(0x2f2b, 0x2f39, x86_l_2f39);
x86_l_2f2d:
	/* 0x2f2d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f2f:
	/* 0x2f2f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f32:
	/* 0x2f32: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f35:
	/* 0x2f35: jns    2f39 <trace_set_fs_pwd+0x2f39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f35, 0x2f39, x86_l_2f39);
x86_l_2f37:
	/* 0x2f37: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f39:
	/* 0x2f39: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f3b:
	/* 0x2f3b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f3f:
	/* 0x2f3f: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f42:
	/* 0x2f42: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f46:
	/* 0x2f46: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f48:
	/* 0x2f48: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f4b:
	/* 0x2f4b: jns    2f4f <trace_set_fs_pwd+0x2f4f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f4b, 0x2f4f, x86_l_2f4f);
x86_l_2f4d:
	/* 0x2f4d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f4f:
	/* 0x2f4f: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f53:
	/* 0x2f53: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f57:
	/* 0x2f57: lea    rbp,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2f5e:
	/* 0x2f5e: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f61:
	/* 0x2f61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f64:
	/* 0x2f64: jns    2f6b <trace_set_fs_pwd+0x2f6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f64, 0x2f6b, x86_l_2f6b);
x86_l_2f66:
	/* 0x2f66: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f69:
	/* 0x2f69: jmp    2f6d <trace_set_fs_pwd+0x2f6d> */
	X86_SIM_X86_JMP(0x2f69, 0x2f6d, x86_l_2f6d);
x86_l_2f6b:
	/* 0x2f6b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f6d:
	/* 0x2f6d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f71:
	/* 0x2f71: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f73:
	/* 0x2f73: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f76:
	/* 0x2f76: jns    2f82 <trace_set_fs_pwd+0x2f82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f76, 0x2f82, x86_l_2f82);
x86_l_2f78:
	/* 0x2f78: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f7b:
	/* 0x2f7b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f7e:
	/* 0x2f7e: js     2f89 <trace_set_fs_pwd+0x2f89> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f7e, 0x2f89, x86_l_2f89);
x86_l_2f80:
	/* 0x2f80: jmp    2f8b <trace_set_fs_pwd+0x2f8b> */
	X86_SIM_X86_JMP(0x2f80, 0x2f8b, x86_l_2f8b);
x86_l_2f82:
	/* 0x2f82: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f84:
	/* 0x2f84: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f87:
	/* 0x2f87: jns    2f8b <trace_set_fs_pwd+0x2f8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f87, 0x2f8b, x86_l_2f8b);
x86_l_2f89:
	/* 0x2f89: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f8b:
	/* 0x2f8b: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f8f:
	/* 0x2f8f: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2f93:
	/* 0x2f93: call   2f98 <trace_set_fs_pwd+0x2f98> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2f98:
	/* 0x2f98: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f9c:
	/* 0x2f9c: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2fa0:
	/* 0x2fa0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fa3:
	/* 0x2fa3: jns    2faa <trace_set_fs_pwd+0x2faa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fa3, 0x2faa, x86_l_2faa);
x86_l_2fa5:
	/* 0x2fa5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fa8:
	/* 0x2fa8: jmp    2fac <trace_set_fs_pwd+0x2fac> */
	X86_SIM_X86_JMP(0x2fa8, 0x2fac, x86_l_2fac);
x86_l_2faa:
	/* 0x2faa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fac:
	/* 0x2fac: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fb0:
	/* 0x2fb0: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2fb4:
	/* 0x2fb4: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2fb7:
	/* 0x2fb7: jns    2fbe <trace_set_fs_pwd+0x2fbe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fb7, 0x2fbe, x86_l_2fbe);
x86_l_2fb9:
	/* 0x2fb9: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fbc:
	/* 0x2fbc: jmp    2fc0 <trace_set_fs_pwd+0x2fc0> */
	X86_SIM_X86_JMP(0x2fbc, 0x2fc0, x86_l_2fc0);
x86_l_2fbe:
	/* 0x2fbe: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fc0:
	/* 0x2fc0: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2fc5:
	/* 0x2fc5: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2fc9:
	/* 0x2fc9: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2fcd:
	/* 0x2fcd: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2fd0:
	/* 0x2fd0: jns    2fe1 <trace_set_fs_pwd+0x2fe1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd0, 0x2fe1, x86_l_2fe1);
x86_l_2fd2:
	/* 0x2fd2: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd6:
	/* 0x2fd6: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2fda:
	/* 0x2fda: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2fdd:
	/* 0x2fdd: js     2fec <trace_set_fs_pwd+0x2fec> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2fdd, 0x2fec, x86_l_2fec);
x86_l_2fdf:
	/* 0x2fdf: jmp    2ff7 <trace_set_fs_pwd+0x2ff7> */
	X86_SIM_X86_JMP(0x2fdf, 0x2ff7, x86_l_2ff7);
x86_l_2fe1:
	/* 0x2fe1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fe3:
	/* 0x2fe3: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2fe7:
	/* 0x2fe7: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2fea:
	/* 0x2fea: jns    2ff7 <trace_set_fs_pwd+0x2ff7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fea, 0x2ff7, x86_l_2ff7);
x86_l_2fec:
	/* 0x2fec: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fee:
	/* 0x2fee: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2ff0:
	/* 0x2ff0: je     2ff7 <trace_set_fs_pwd+0x2ff7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ff0, 0x2ff7, x86_l_2ff7);
x86_l_2ff2:
	/* 0x2ff2: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_2ff7:
	/* 0x2ff7: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ffc:
	/* 0x2ffc: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3000:
	/* 0x3000: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_3008:
	/* 0x3008: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_3010:
	/* 0x3010: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3015:
	/* 0x3015: call   301a <trace_set_fs_pwd+0x301a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_301a:
	/* 0x301a: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_301d:
	/* 0x301d: jns    3036 <trace_set_fs_pwd+0x3036> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x301d, 0x3036, x86_l_3036);
x86_l_301f:
	/* 0x301f: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3023:
	/* 0x3023: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3028:
	/* 0x3028: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_302b:
	/* 0x302b: js     3042 <trace_set_fs_pwd+0x3042> */
	X86_SIM_X86_JCC(X86_CC_S, 0x302b, 0x3042, x86_l_3042);
x86_l_302d:
	/* 0x302d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_302f:
	/* 0x302f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3032:
	/* 0x3032: js     304a <trace_set_fs_pwd+0x304a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3032, 0x304a, x86_l_304a);
x86_l_3034:
	/* 0x3034: jmp    308b <trace_set_fs_pwd+0x308b> */
	X86_SIM_X86_JMP(0x3034, 0x308b, x86_l_308b);
x86_l_3036:
	/* 0x3036: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3038:
	/* 0x3038: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_303d:
	/* 0x303d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3040:
	/* 0x3040: jns    302d <trace_set_fs_pwd+0x302d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3040, 0x302d, x86_l_302d);
x86_l_3042:
	/* 0x3042: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3045:
	/* 0x3045: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3048:
	/* 0x3048: jns    308b <trace_set_fs_pwd+0x308b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3048, 0x308b, x86_l_308b);
x86_l_304a:
	/* 0x304a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_304d:
	/* 0x304d: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3052:
	/* 0x3052: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3056:
	/* 0x3056: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_305b:
	/* 0x305b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_305f:
	/* 0x305f: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3064:
	/* 0x3064: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3068:
	/* 0x3068: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_306d:
	/* 0x306d: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3071:
	/* 0x3071: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3076:
	/* 0x3076: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_307a:
	/* 0x307a: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_307f:
	/* 0x307f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3083:
	/* 0x3083: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3087:
	/* 0x3087: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_308b:
	/* 0x308b: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3090:
	/* 0x3090: add    rbx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_3094:
	/* 0x3094: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3099:
	/* 0x3099: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_309c:
	/* 0x309c: jns    3172 <trace_set_fs_pwd+0x3172> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x309c, 0x3172, x86_l_3172);
x86_l_30a2:
	/* 0x30a2: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_30a5:
	/* 0x30a5: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30a7:
	/* 0x30a7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30a9:
	/* 0x30a9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30a9, 0x3181, x86_l_3181);
x86_l_30af:
	/* 0x30af: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_30b3:
	/* 0x30b3: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_30b7:
	/* 0x30b7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30b9:
	/* 0x30b9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30b9, 0x3181, x86_l_3181);
x86_l_30bf:
	/* 0x30bf: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_30c3:
	/* 0x30c3: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_30c7:
	/* 0x30c7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30c9:
	/* 0x30c9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30c9, 0x3181, x86_l_3181);
x86_l_30cf:
	/* 0x30cf: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_30d3:
	/* 0x30d3: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_30d7:
	/* 0x30d7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30d9:
	/* 0x30d9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30d9, 0x3181, x86_l_3181);
x86_l_30df:
	/* 0x30df: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_30e3:
	/* 0x30e3: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_30e7:
	/* 0x30e7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30e9:
	/* 0x30e9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30e9, 0x3181, x86_l_3181);
x86_l_30ef:
	/* 0x30ef: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_30f3:
	/* 0x30f3: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_30f7:
	/* 0x30f7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30f9:
	/* 0x30f9: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30f9, 0x3181, x86_l_3181);
x86_l_30ff:
	/* 0x30ff: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3103:
	/* 0x3103: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_3107:
	/* 0x3107: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3109:
	/* 0x3109: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3109, 0x3181, x86_l_3181);
x86_l_310b:
	/* 0x310b: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_310f:
	/* 0x310f: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_3113:
	/* 0x3113: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3115:
	/* 0x3115: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3115, 0x3181, x86_l_3181);
x86_l_3117:
	/* 0x3117: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_311b:
	/* 0x311b: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_311f:
	/* 0x311f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3121:
	/* 0x3121: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3121, 0x3181, x86_l_3181);
x86_l_3123:
	/* 0x3123: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_3127:
	/* 0x3127: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_312b:
	/* 0x312b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_312d:
	/* 0x312d: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x312d, 0x3181, x86_l_3181);
x86_l_312f:
	/* 0x312f: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_3133:
	/* 0x3133: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_3137:
	/* 0x3137: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3139:
	/* 0x3139: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3139, 0x3181, x86_l_3181);
x86_l_313b:
	/* 0x313b: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_313f:
	/* 0x313f: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_3143:
	/* 0x3143: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3145:
	/* 0x3145: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3145, 0x3181, x86_l_3181);
x86_l_3147:
	/* 0x3147: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_314b:
	/* 0x314b: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_314f:
	/* 0x314f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3151:
	/* 0x3151: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3151, 0x3181, x86_l_3181);
x86_l_3153:
	/* 0x3153: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_3157:
	/* 0x3157: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_315b:
	/* 0x315b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_315d:
	/* 0x315d: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x315d, 0x3181, x86_l_3181);
x86_l_315f:
	/* 0x315f: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_3163:
	/* 0x3163: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_3167:
	/* 0x3167: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_3169:
	/* 0x3169: je     3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3169, 0x3181, x86_l_3181);
x86_l_316b:
	/* 0x316b: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_3170:
	/* 0x3170: jmp    3181 <trace_set_fs_pwd+0x3181> */
	X86_SIM_X86_JMP(0x3170, 0x3181, x86_l_3181);
x86_l_3172:
	/* 0x3172: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_317a:
	/* 0x317a: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3181:
	/* 0x3181: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3184:
	/* 0x3184: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3189:
	/* 0x3189: jns    31fd <trace_set_fs_pwd+0x31fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3189, 0x31fd, x86_l_31fd);
x86_l_318b:
	/* 0x318b: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_318f:
	/* 0x318f: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3192:
	/* 0x3192: mov    rax,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3196:
	/* 0x3196: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_319a:
	/* 0x319a: mov    rax,QWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_319e:
	/* 0x319e: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31a2:
	/* 0x31a2: mov    rax,QWORD PTR [r13+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31a6:
	/* 0x31a6: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31aa:
	/* 0x31aa: mov    rax,QWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_31ae:
	/* 0x31ae: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_31b2:
	/* 0x31b2: mov    rax,QWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31b6:
	/* 0x31b6: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31ba:
	/* 0x31ba: mov    rax,QWORD PTR [r13+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31be:
	/* 0x31be: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31c2:
	/* 0x31c2: mov    rax,QWORD PTR [r13+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31c6:
	/* 0x31c6: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31ca:
	/* 0x31ca: mov    rax,QWORD PTR [r13+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31ce:
	/* 0x31ce: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31d2:
	/* 0x31d2: mov    rax,QWORD PTR [r13+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_31d6:
	/* 0x31d6: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_31da:
	/* 0x31da: mov    rax,QWORD PTR [r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_31de:
	/* 0x31de: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_31e2:
	/* 0x31e2: mov    rax,QWORD PTR [r13+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_31e6:
	/* 0x31e6: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_31ea:
	/* 0x31ea: mov    rax,QWORD PTR [r13+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_31ee:
	/* 0x31ee: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_31f2:
	/* 0x31f2: test   BYTE PTR [rdx+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_31f6:
	/* 0x31f6: jne    326a <trace_set_fs_pwd+0x326a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31f6, 0x326a, x86_l_326a);
x86_l_31f8:
	/* 0x31f8: jmp    3286 <trace_set_fs_pwd+0x3286> */
	X86_SIM_X86_JMP(0x31f8, 0x3286, x86_l_3286);
x86_l_31fd:
	/* 0x31fd: mov    QWORD PTR [rcx+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3205:
	/* 0x3205: mov    QWORD PTR [rcx+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_320d:
	/* 0x320d: mov    QWORD PTR [rcx+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3215:
	/* 0x3215: mov    QWORD PTR [rcx+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_321d:
	/* 0x321d: mov    QWORD PTR [rcx+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3225:
	/* 0x3225: mov    QWORD PTR [rcx+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_322d:
	/* 0x322d: mov    QWORD PTR [rcx+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3235:
	/* 0x3235: mov    QWORD PTR [rcx+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_323d:
	/* 0x323d: mov    QWORD PTR [rcx+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_3245:
	/* 0x3245: mov    QWORD PTR [rcx+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_324d:
	/* 0x324d: mov    QWORD PTR [rcx+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3255:
	/* 0x3255: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_325d:
	/* 0x325d: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3264:
	/* 0x3264: test   BYTE PTR [rdx+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_3268:
	/* 0x3268: je     3286 <trace_set_fs_pwd+0x3286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3268, 0x3286, x86_l_3286);
x86_l_326a:
	/* 0x326a: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_3271:
	/* 0x3271: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_3276:
	/* 0x3276: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3279:
	/* 0x3279: call   327e <trace_set_fs_pwd+0x327e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_327e:
	/* 0x327e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3280:
	/* 0x3280: js     3286 <trace_set_fs_pwd+0x3286> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3280, 0x3286, x86_l_3286);
x86_l_3282:
	/* 0x3282: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_3286:
	/* 0x3286: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_328e:
	/* 0x328e: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_3293:
	/* 0x3293: jb     329a <trace_set_fs_pwd+0x329a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3293, 0x329a, x86_l_329a);
x86_l_3295:
	/* 0x3295: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_329a:
	/* 0x329a: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_329f:
	/* 0x329f: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_32a3:
	/* 0x32a3: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_32aa:
	/* 0x32aa: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_32af:
	/* 0x32af: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_32b2:
	/* 0x32b2: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_32b5:
	/* 0x32b5: call   32ba <trace_set_fs_pwd+0x32ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_32ba:
	/* 0x32ba: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32bd:
	/* 0x32bd: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_32c0:
	/* 0x32c0: add    rsp,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
x86_l_32c7:
	/* 0x32c7: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32c8:
	/* 0x32c8: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32ca:
	/* 0x32ca: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32cc:
	/* 0x32cc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32ce:
	/* 0x32ce: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32d0:
	/* 0x32d0: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_32d1:
	/* 0x32d1: jmp    3388 <trace_set_fs_pwd+0x3388> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_32d6:
	/* 0x32d6: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_32d9:
	/* 0x32d9: jne    3380 <trace_set_fs_pwd+0x3380> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32d9, 0x3380, x86_l_3380);
x86_l_32df:
	/* 0x32df: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_32e4:
	/* 0x32e4: je     3380 <trace_set_fs_pwd+0x3380> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32e4, 0x3380, x86_l_3380);
x86_l_32ea:
	/* 0x32ea: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32ee:
	/* 0x32ee: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_32f1:
	/* 0x32f1: jns    3334 <trace_set_fs_pwd+0x3334> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32f1, 0x3334, x86_l_3334);
x86_l_32f3:
	/* 0x32f3: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32f6:
	/* 0x32f6: jmp    3336 <trace_set_fs_pwd+0x3336> */
	X86_SIM_X86_JMP(0x32f6, 0x3336, x86_l_3336);
x86_l_32f8:
	/* 0x32f8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_32fb:
	/* 0x32fb: je     3380 <trace_set_fs_pwd+0x3380> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32fb, 0x3380, x86_l_3380);
x86_l_3301:
	/* 0x3301: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3307:
	/* 0x3307: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_330a:
	/* 0x330a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_330d:
	/* 0x330d: jns    3359 <trace_set_fs_pwd+0x3359> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x330d, 0x3359, x86_l_3359);
x86_l_330f:
	/* 0x330f: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3313:
	/* 0x3313: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3315:
	/* 0x3315: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3318:
	/* 0x3318: je     3361 <trace_set_fs_pwd+0x3361> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3318, 0x3361, x86_l_3361);
x86_l_331a:
	/* 0x331a: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_331e:
	/* 0x331e: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_3323:
	/* 0x3323: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3327:
	/* 0x3327: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_332a:
	/* 0x332a: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_332d:
	/* 0x332d: jne    3315 <trace_set_fs_pwd+0x3315> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x332d, 0x3315, x86_l_3315);
x86_l_332f:
	/* 0x332f: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_3332:
	/* 0x3332: jmp    3365 <trace_set_fs_pwd+0x3365> */
	X86_SIM_X86_JMP(0x3332, 0x3365, x86_l_3365);
x86_l_3334:
	/* 0x3334: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3336:
	/* 0x3336: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3339:
	/* 0x3339: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_333c:
	/* 0x333c: jns    3346 <trace_set_fs_pwd+0x3346> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x333c, 0x3346, x86_l_3346);
x86_l_333e:
	/* 0x333e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3341:
	/* 0x3341: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3344:
	/* 0x3344: jmp    3348 <trace_set_fs_pwd+0x3348> */
	X86_SIM_X86_JMP(0x3344, 0x3348, x86_l_3348);
x86_l_3346:
	/* 0x3346: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3348:
	/* 0x3348: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_334b:
	/* 0x334b: jns    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x334b, 0x2b58, x86_l_2b58);
x86_l_3351:
	/* 0x3351: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3354:
	/* 0x3354: jmp    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JMP(0x3354, 0x2b58, x86_l_2b58);
x86_l_3359:
	/* 0x3359: mov    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_335c:
	/* 0x335c: jmp    29aa <trace_set_fs_pwd+0x29aa> */
	X86_SIM_X86_JMP(0x335c, 0x29aa, x86_l_29aa);
x86_l_3361:
	/* 0x3361: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3365:
	/* 0x3365: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3369:
	/* 0x3369: jl     3380 <trace_set_fs_pwd+0x3380> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3369, 0x3380, x86_l_3380);
x86_l_336b:
	/* 0x336b: lea    eax,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_336e:
	/* 0x336e: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3373:
	/* 0x3373: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_3378:
	/* 0x3378: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_337b:
	/* 0x337b: jmp    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JMP(0x337b, 0x2b58, x86_l_2b58);
x86_l_3380:
	/* 0x3380: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3383:
	/* 0x3383: jmp    2b58 <trace_set_fs_pwd+0x2b58> */
	X86_SIM_X86_JMP(0x3383, 0x2b58, x86_l_2b58);
x86_l_3388:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
