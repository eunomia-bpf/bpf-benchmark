#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 160U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(6) M(7) M(9) M(10) M(11) M(13)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 config_map[] __ksym;
extern __u8 enforcer_data[] __ksym;
extern __u8 enforcer_missed_notifications[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 heap[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 policy_stats[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 ratelimit_heap[] __ksym;
extern __u8 ratelimit_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 stack_trace_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 write_offload[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BZHI_MEM, X86_OP_BZHI_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_MEM_IMM, X86_OP_IMUL_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 104ULL);
x86_l_e:
	/* 0xe: mov    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_11:
	/* 0x11: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16:
	/* 0x16: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19:
	/* 0x19: mov    r14d,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1c:
	/* 0x1c: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f:
	/* 0x1f: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_21:
	/* 0x21: movsxd r12,DWORD PTR [rdx+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_RAX, 2, X86_WIDTH_32), 4ULL);
x86_l_26:
	/* 0x26: mov    DWORD PTR [rsp+0x5c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
x86_l_2e:
	/* 0x2e: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_35:
	/* 0x35: lea    rsi,[rsp+0x5c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_3a:
	/* 0x3a: call   2bdf <read_reg+0x2000> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3f:
	/* 0x3f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42:
	/* 0x42: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_44:
	/* 0x44: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_47:
	/* 0x47: je     b99 <do_action+0xb99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47, 0xb99, x86_l_b99);
x86_l_4d:
	/* 0x4d: cmp    r12d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_51:
	/* 0x51: jg     7b <do_action+0x7b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x51, 0x7b, x86_l_7b);
x86_l_53:
	/* 0x53: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_57:
	/* 0x57: jg     b4 <do_action+0xb4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x57, 0xb4, x86_l_b4);
x86_l_59:
	/* 0x59: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5d:
	/* 0x5d: jg     2b3 <do_action+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_G, 0x5d, 0x2b3, x86_l_2b3);
x86_l_63:
	/* 0x63: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_66:
	/* 0x66: je     56a <do_action+0x56a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x66, 0x56a, x86_l_56a);
x86_l_6c:
	/* 0x6c: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_70:
	/* 0x70: je     2cc <do_action+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70, 0x2cc, x86_l_2cc);
x86_l_76:
	/* 0x76: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0x76, 0xb8f, x86_l_b8f);
x86_l_7b:
	/* 0x7b: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_7f:
	/* 0x7f: jg     1ae <do_action+0x1ae> */
	X86_SIM_X86_JCC(X86_CC_G, 0x7f, 0x1ae, x86_l_1ae);
x86_l_85:
	/* 0x85: lea    ecx,[r12-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_8a:
	/* 0x8a: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_8d:
	/* 0x8d: jb     402 <do_action+0x402> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8d, 0x402, x86_l_402);
x86_l_93:
	/* 0x93: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_97:
	/* 0x97: je     4dd <do_action+0x4dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x97, 0x4dd, x86_l_4dd);
x86_l_9d:
	/* 0x9d: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_a1:
	/* 0xa1: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa1, 0xb8f, x86_l_b8f);
x86_l_a7:
	/* 0xa7: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_aa:
	/* 0xaa: mov    edi,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_af:
	/* 0xaf: jmp    4ae <do_action+0x4ae> */
	X86_SIM_X86_JMP(0xaf, 0x4ae, x86_l_4ae);
x86_l_b4:
	/* 0xb4: lea    eax,[r12-0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_b9:
	/* 0xb9: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_bc:
	/* 0xbc: jb     4cd <do_action+0x4cd> */
	X86_SIM_X86_JCC(X86_CC_B, 0xbc, 0x4cd, x86_l_4cd);
x86_l_c2:
	/* 0xc2: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_c6:
	/* 0xc6: je     4ea <do_action+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6, 0x4ea, x86_l_4ea);
x86_l_cc:
	/* 0xcc: cmp    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_d0:
	/* 0xd0: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd0, 0xb8f, x86_l_b8f);
x86_l_d6:
	/* 0xd6: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_da:
	/* 0xda: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_df:
	/* 0xdf: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_e3:
	/* 0xe3: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_e6:
	/* 0xe6: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_e9:
	/* 0xe9: ja     b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe9, 0xb8f, x86_l_b8f);
x86_l_ef:
	/* 0xef: cmp    DWORD PTR [rbx+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_f7:
	/* 0xf7: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf7, 0xb8f, x86_l_b8f);
x86_l_fd:
	/* 0xfd: mov    r15d,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_102:
	/* 0x102: mov    rax,QWORD PTR [rbx+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_10a:
	/* 0x10a: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_10f:
	/* 0x10f: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_117:
	/* 0x117: mov    eax,DWORD PTR [rbx+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_11e:
	/* 0x11e: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_122:
	/* 0x122: call   2cc7 <read_reg+0x20e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_127:
	/* 0x127: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_12b:
	/* 0x12b: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12f:
	/* 0x12f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_136:
	/* 0x136: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_139:
	/* 0x139: call   2cde <read_reg+0x20ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_13e:
	/* 0x13e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_141:
	/* 0x141: je     b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x141, 0xb8f, x86_l_b8f);
x86_l_147:
	/* 0x147: and    r15d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_14b:
	/* 0x14b: cmp    r15d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14f:
	/* 0x14f: ja     b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14f, 0xb8f, x86_l_b8f);
x86_l_155:
	/* 0x155: cmp    DWORD PTR [rbx+r15*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 104041287778304ULL);
x86_l_15e:
	/* 0x15e: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15e, 0xb8f, x86_l_b8f);
x86_l_164:
	/* 0x164: mov    rcx,QWORD PTR [rbx+r15*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 3), 24184ULL);
x86_l_16c:
	/* 0x16c: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_172:
	/* 0x172: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_17a:
	/* 0x17a: mov    ecx,DWORD PTR [rbx+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_181:
	/* 0x181: mov    DWORD PTR [rsp+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_185:
	/* 0x185: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_188:
	/* 0x188: call   2d2d <read_reg+0x214e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_18d:
	/* 0x18d: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_191:
	/* 0x191: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_195:
	/* 0x195: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_19c:
	/* 0x19c: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_19f:
	/* 0x19f: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1a2:
	/* 0x1a2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a4:
	/* 0x1a4: call   2d49 <read_reg+0x216a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1a9:
	/* 0x1a9: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0x1a9, 0xb8f, x86_l_b8f);
x86_l_1ae:
	/* 0x1ae: cmp    r12d,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1b2:
	/* 0x1b2: je     60d <do_action+0x60d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2, 0x60d, x86_l_60d);
x86_l_1b8:
	/* 0x1b8: cmp    r12d,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1bc:
	/* 0x1bc: je     4fa <do_action+0x4fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc, 0x4fa, x86_l_4fa);
x86_l_1c2:
	/* 0x1c2: cmp    r12d,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_1c6:
	/* 0x1c6: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c6, 0xb8f, x86_l_b8f);
x86_l_1cc:
	/* 0x1cc: mov    QWORD PTR [rsp+0x48],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1d1:
	/* 0x1d1: lea    eax,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_1d5:
	/* 0x1d5: mov    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1db:
	/* 0x1db: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1de:
	/* 0x1de: je     61e <do_action+0x61e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de, 0x61e, x86_l_61e);
x86_l_1e4:
	/* 0x1e4: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e8:
	/* 0x1e8: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1ea:
	/* 0x1ea: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_1ef:
	/* 0x1ef: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f2:
	/* 0x1f2: mov    r14d,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_1f7:
	/* 0x1f7: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1fa:
	/* 0x1fa: add    rsi,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_201:
	/* 0x201: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_208:
	/* 0x208: call   2dad <read_reg+0x21ce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20d:
	/* 0x20d: mov    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_213:
	/* 0x213: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_216:
	/* 0x216: je     b2c <do_action+0xb2c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x216, 0xb2c, x86_l_b2c);
x86_l_21c:
	/* 0x21c: and    r14d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_220:
	/* 0x220: lea    r14,[r14+r14*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 1), 0ULL);
x86_l_224:
	/* 0x224: cmp    BYTE PTR [rax+r14*8+0x211],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R14, 3), 2272037699587ULL);
x86_l_22d:
	/* 0x22d: jne    688 <do_action+0x688> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22d, 0x688, x86_l_688);
x86_l_233:
	/* 0x233: mov    esi,DWORD PTR [rax+r14*8+0x208] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 3), 520ULL);
x86_l_23b:
	/* 0x23b: mov    rdi,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_240:
	/* 0x240: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_242:
	/* 0x242: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_245:
	/* 0x245: call   bdf <read_reg> */
	X86_SIM_X86_CALL(x86_l_bdf, 0x24aULL);
x86_l_24a:
	/* 0x24a: add    rax,QWORD PTR [r15+r14*8+0x200] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_R14, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 512ULL);
x86_l_252:
	/* 0x252: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_256:
	/* 0x256: mov    DWORD PTR [rsp+0x8],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25a:
	/* 0x25a: call   2dff <read_reg+0x2220> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_25f:
	/* 0x25f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_264:
	/* 0x264: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)write_offload));
x86_l_26b:
	/* 0x26b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_270:
	/* 0x270: call   2e15 <read_reg+0x2236> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_275:
	/* 0x275: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_278:
	/* 0x278: je     a94 <do_action+0xa94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x278, 0xa94, x86_l_a94);
x86_l_27e:
	/* 0x27e: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_281:
	/* 0x281: mov    DWORD PTR [rsp+0x18],0xe0011 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103080132625ULL);
x86_l_289:
	/* 0x289: mov    QWORD PTR [rsp+0x1c],0x371 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120259085169ULL);
x86_l_292:
	/* 0x292: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_299:
	/* 0x299: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29e:
	/* 0x29e: call   2e43 <read_reg+0x2264> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a3:
	/* 0x2a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a6:
	/* 0x2a6: je     afc <do_action+0xafc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6, 0xafc, x86_l_afc);
x86_l_2ac:
	/* 0x2ac: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2ae:
	/* 0x2ae: jmp    b1c <do_action+0xb1c> */
	X86_SIM_X86_JMP(0x2ae, 0xb1c, x86_l_b1c);
x86_l_2b3:
	/* 0x2b3: mov    edi,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2b8:
	/* 0x2b8: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2bc:
	/* 0x2bc: je     4ae <do_action+0x4ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bc, 0x4ae, x86_l_4ae);
x86_l_2c2:
	/* 0x2c2: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2c6:
	/* 0x2c6: jne    b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c6, 0xb8f, x86_l_b8f);
x86_l_2cc:
	/* 0x2cc: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d0:
	/* 0x2d0: mov    r13d,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_2d5:
	/* 0x2d5: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_2d9:
	/* 0x2d9: mov    ebp,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_2de:
	/* 0x2de: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2e6:
	/* 0x2e6: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap));
x86_l_2ed:
	/* 0x2ed: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2f2:
	/* 0x2f2: call   2e97 <read_reg+0x22b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f7:
	/* 0x2f7: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fa:
	/* 0x2fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fd:
	/* 0x2fd: je     b88 <do_action+0xb88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fd, 0xb88, x86_l_b88);
x86_l_303:
	/* 0x303: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_306:
	/* 0x306: and    r13d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_30a:
	/* 0x30a: cmp    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_30e:
	/* 0x30e: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_313:
	/* 0x313: ja     b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x313, 0xb8a, x86_l_b8a);
x86_l_319:
	/* 0x319: cmp    DWORD PTR [rbx+r13*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 104041287778304ULL);
x86_l_322:
	/* 0x322: jne    b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x322, 0xb8a, x86_l_b8a);
x86_l_328:
	/* 0x328: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32d:
	/* 0x32d: mov    rax,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_335:
	/* 0x335: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_33a:
	/* 0x33a: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_342:
	/* 0x342: mov    eax,DWORD PTR [rbx+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_349:
	/* 0x349: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34d:
	/* 0x34d: call   2ef2 <read_reg+0x2313> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_352:
	/* 0x352: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_356:
	/* 0x356: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35a:
	/* 0x35a: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_35e:
	/* 0x35e: jne    691 <do_action+0x691> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35e, 0x691, x86_l_691);
x86_l_364:
	/* 0x364: and    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_367:
	/* 0x367: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_36a:
	/* 0x36a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36f:
	/* 0x36f: ja     b88 <do_action+0xb88> */
	X86_SIM_X86_JCC(X86_CC_A, 0x36f, 0xb88, x86_l_b88);
x86_l_375:
	/* 0x375: cmp    DWORD PTR [rbx+rbp*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 104041287778304ULL);
x86_l_37d:
	/* 0x37d: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_382:
	/* 0x382: jne    b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x382, 0xb8a, x86_l_b8a);
x86_l_388:
	/* 0x388: mov    rcx,QWORD PTR [rbx+rbp*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 3), 24184ULL);
x86_l_390:
	/* 0x390: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_396:
	/* 0x396: lea    rax,[rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_39a:
	/* 0x39a: add    rax,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_3a0:
	/* 0x3a0: mov    esi,DWORD PTR [rbx+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_3a7:
	/* 0x3a7: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_3a9:
	/* 0x3a9: and    ecx,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3af:
	/* 0x3af: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3b3:
	/* 0x3b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b6:
	/* 0x3b6: jns    b53 <do_action+0xb53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b6, 0xb53, x86_l_b53);
x86_l_3bc:
	/* 0x3bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bf:
	/* 0x3bf: jns    b62 <do_action+0xb62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3bf, 0xb62, x86_l_b62);
x86_l_3c5:
	/* 0x3c5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c7:
	/* 0x3c7: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3ca:
	/* 0x3ca: mov    rdi,QWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_3ce:
	/* 0x3ce: mov    QWORD PTR [rdx+r8*1],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_3d2:
	/* 0x3d2: lea    rdi,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3d6:
	/* 0x3d6: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3da:
	/* 0x3da: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3dd:
	/* 0x3dd: jbe    3c7 <do_action+0x3c7> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3dd, 0x3c7, x86_l_3c7);
x86_l_3df:
	/* 0x3df: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_3e3:
	/* 0x3e3: jne    bac <do_action+0xbac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3e3, 0xbac, x86_l_bac);
x86_l_3e9:
	/* 0x3e9: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3ed:
	/* 0x3ed: jne    bbf <do_action+0xbbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ed, 0xbbf, x86_l_bbf);
x86_l_3f3:
	/* 0x3f3: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3f7:
	/* 0x3f7: je     b74 <do_action+0xb74> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f7, 0xb74, x86_l_b74);
x86_l_3fd:
	/* 0x3fd: jmp    bd4 <do_action+0xbd4> */
	X86_SIM_X86_JMP(0x3fd, 0xbd4, x86_l_bd4);
x86_l_402:
	/* 0x402: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_405:
	/* 0x405: mov    ecx,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_40a:
	/* 0x40a: and    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_40d:
	/* 0x40d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_410:
	/* 0x410: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_413:
	/* 0x413: ja     b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x413, 0xb8a, x86_l_b8a);
x86_l_419:
	/* 0x419: cmp    DWORD PTR [rbx+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_421:
	/* 0x421: jne    b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x421, 0xb8a, x86_l_b8a);
x86_l_427:
	/* 0x427: mov    rcx,QWORD PTR [rbx+rcx*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24184ULL);
x86_l_42f:
	/* 0x42f: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_435:
	/* 0x435: mov    rcx,QWORD PTR [rbx+rcx*1+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 184ULL);
x86_l_43d:
	/* 0x43d: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_442:
	/* 0x442: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_445:
	/* 0x445: je     b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x445, 0xb8a, x86_l_b8a);
x86_l_44b:
	/* 0x44b: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_44f:
	/* 0x44f: jne    69d <do_action+0x69d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44f, 0x69d, x86_l_69d);
x86_l_455:
	/* 0x455: call   2ffa <read_reg+0x241b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_45a:
	/* 0x45a: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45d:
	/* 0x45d: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_461:
	/* 0x461: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_464:
	/* 0x464: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_46b:
	/* 0x46b: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_46e:
	/* 0x46e: call   3013 <read_reg+0x2434> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_473:
	/* 0x473: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_476:
	/* 0x476: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_479:
	/* 0x479: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_47e:
	/* 0x47e: je     b8a <do_action+0xb8a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47e, 0xb8a, x86_l_b8a);
x86_l_484:
	/* 0x484: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_486:
	/* 0x486: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_489:
	/* 0x489: mov    DWORD PTR [rsp+0x4],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_48e:
	/* 0x48e: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_492:
	/* 0x492: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_497:
	/* 0x497: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_49e:
	/* 0x49e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a1:
	/* 0x4a1: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a6:
	/* 0x4a6: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_4a9:
	/* 0x4a9: jmp    b81 <do_action+0xb81> */
	X86_SIM_X86_JMP(0x4a9, 0xb81, x86_l_b81);
x86_l_4ae:
	/* 0x4ae: mov    r13d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_4b4:
	/* 0x4b4: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_4b7:
	/* 0x4b7: je     b31 <do_action+0xb31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b7, 0xb31, x86_l_b31);
x86_l_4bd:
	/* 0x4bd: call   3062 <read_reg+0x2483> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_send_signal);
x86_l_4c2:
	/* 0x4c2: mov    r13d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4c8:
	/* 0x4c8: jmp    b31 <do_action+0xb31> */
	X86_SIM_X86_JMP(0x4c8, 0xb31, x86_l_b31);
x86_l_4cd:
	/* 0x4cd: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_4d0:
	/* 0x4d0: mov    eax,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_4d5:
	/* 0x4d5: mov    DWORD PTR [rbx+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_4d8:
	/* 0x4d8: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0x4d8, 0xb8f, x86_l_b8f);
x86_l_4dd:
	/* 0x4dd: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e2:
	/* 0x4e2: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e5:
	/* 0x4e5: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0x4e5, 0xb8f, x86_l_b8f);
x86_l_4ea:
	/* 0x4ea: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_4ed:
	/* 0x4ed: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_4f1:
	/* 0x4f1: xor    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 5ULL);
x86_l_4f5:
	/* 0x4f5: jmp    b31 <do_action+0xb31> */
	X86_SIM_X86_JMP(0x4f5, 0xb31, x86_l_b31);
x86_l_4fa:
	/* 0x4fa: call   309f <read_reg+0x24c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_4ff:
	/* 0x4ff: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_504:
	/* 0x504: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_50b:
	/* 0x50b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_510:
	/* 0x510: call   30b5 <read_reg+0x24d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_515:
	/* 0x515: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_518:
	/* 0x518: je     b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x518, 0xb8f, x86_l_b8f);
x86_l_51e:
	/* 0x51e: mov    rax,QWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_522:
	/* 0x522: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_527:
	/* 0x527: mov    DWORD PTR [rsp+0x20],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953474ULL);
x86_l_52f:
	/* 0x52f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_536:
	/* 0x536: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_53b:
	/* 0x53b: call   30e0 <read_reg+0x2501> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_540:
	/* 0x540: mov    DWORD PTR [rsp+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_548:
	/* 0x548: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54b:
	/* 0x54b: je     626 <do_action+0x626> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54b, 0x626, x86_l_626);
x86_l_551:
	/* 0x551: lock inc DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_554:
	/* 0x554: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_55b:
	/* 0x55b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_560:
	/* 0x560: call   3105 <read_reg+0x2526> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_565:
	/* 0x565: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0x565, 0xb8f, x86_l_b8f);
x86_l_56a:
	/* 0x56a: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_56e:
	/* 0x56e: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_573:
	/* 0x573: lea    eax,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_577:
	/* 0x577: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_57c:
	/* 0x57c: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_580:
	/* 0x580: call   3125 <read_reg+0x2546> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_585:
	/* 0x585: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_589:
	/* 0x589: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_591:
	/* 0x591: mov    QWORD PTR [rsp+0x60],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_596:
	/* 0x596: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_599:
	/* 0x599: je     a28 <do_action+0xa28> */
	X86_SIM_X86_JCC(X86_CC_E, 0x599, 0xa28, x86_l_a28);
x86_l_59f:
	/* 0x59f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_heap));
x86_l_5a6:
	/* 0x5a6: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5ab:
	/* 0x5ab: call   3150 <read_reg+0x2571> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5b0:
	/* 0x5b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b3:
	/* 0x5b3: je     a28 <do_action+0xa28> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b3, 0xa28, x86_l_a28);
x86_l_5b9:
	/* 0x5b9: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5be:
	/* 0x5be: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c1:
	/* 0x5c1: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_5c8:
	/* 0x5c8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5cd:
	/* 0x5cd: call   3172 <read_reg+0x2593> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5d2:
	/* 0x5d2: mov    rcx,QWORD PTR [rbx+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_5d6:
	/* 0x5d6: mov    QWORD PTR [rbp+0x0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5da:
	/* 0x5da: mov    rcx,QWORD PTR [rbx+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5de:
	/* 0x5de: mov    QWORD PTR [rsp+0x40],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5e3:
	/* 0x5e3: mov    QWORD PTR [rbp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e7:
	/* 0x5e7: mov    ecx,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5eb:
	/* 0x5eb: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5ee:
	/* 0x5ee: je     6bb <do_action+0x6bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ee, 0x6bb, x86_l_6bb);
x86_l_5f4:
	/* 0x5f4: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_5f7:
	/* 0x5f7: je     6b6 <do_action+0x6b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f7, 0x6b6, x86_l_6b6);
x86_l_5fd:
	/* 0x5fd: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5ff:
	/* 0x5ff: jne    a28 <do_action+0xa28> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5ff, 0xa28, x86_l_a28);
x86_l_605:
	/* 0x605: mov    ecx,DWORD PTR [rbx+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_608:
	/* 0x608: jmp    6bd <do_action+0x6bd> */
	X86_SIM_X86_JMP(0x608, 0x6bd, x86_l_6bd);
x86_l_60d:
	/* 0x60d: add    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_611:
	/* 0x611: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_615:
	/* 0x615: xor    r13,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 7ULL);
x86_l_619:
	/* 0x619: jmp    b31 <do_action+0xb31> */
	X86_SIM_X86_JMP(0x619, 0xb31, x86_l_b31);
x86_l_61e:
	/* 0x61e: mov    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_621:
	/* 0x621: jmp    b31 <do_action+0xb31> */
	X86_SIM_X86_JMP(0x621, 0xb31, x86_l_b31);
x86_l_626:
	/* 0x626: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_62d:
	/* 0x62d: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_632:
	/* 0x632: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_637:
	/* 0x637: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_63c:
	/* 0x63c: call   31e1 <read_reg+0x2602> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_641:
	/* 0x641: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_644:
	/* 0x644: je     554 <do_action+0x554> */
	X86_SIM_X86_JCC(X86_CC_E, 0x644, 0x554, x86_l_554);
x86_l_64a:
	/* 0x64a: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64d:
	/* 0x64d: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_64f:
	/* 0x64f: mov    WORD PTR [rsp],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_653:
	/* 0x653: mov    WORD PTR [rsp+0x2],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934595ULL);
x86_l_65a:
	/* 0x65a: movabs rax,0x20000003b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8589934651ULL);
x86_l_664:
	/* 0x664: mov    QWORD PTR [rsp+0x4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_669:
	/* 0x669: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_670:
	/* 0x670: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_673:
	/* 0x673: call   3218 <read_reg+0x2639> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_678:
	/* 0x678: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67b:
	/* 0x67b: je     aaf <do_action+0xaaf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67b, 0xaaf, x86_l_aaf);
x86_l_681:
	/* 0x681: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_683:
	/* 0x683: jmp    acd <do_action+0xacd> */
	X86_SIM_X86_JMP(0x683, 0xacd, x86_l_acd);
x86_l_688:
	/* 0x688: or     BYTE PTR [rbx+0x1],0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967328ULL);
x86_l_68c:
	/* 0x68c: jmp    b2c <do_action+0xb2c> */
	X86_SIM_X86_JMP(0x68c, 0xb2c, x86_l_b2c);
x86_l_691:
	/* 0x691: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_698:
	/* 0x698: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_69b:
	/* 0x69b: jmp    6a9 <do_action+0x6a9> */
	X86_SIM_X86_JMP(0x69b, 0x6a9, x86_l_6a9);
x86_l_69d:
	/* 0x69d: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_6a4:
	/* 0x6a4: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6a9:
	/* 0x6a9: call   324e <read_reg+0x266f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_6ae:
	/* 0x6ae: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b1:
	/* 0x6b1: jmp    b88 <do_action+0xb88> */
	X86_SIM_X86_JMP(0x6b1, 0xb88, x86_l_b88);
x86_l_6b6:
	/* 0x6b6: mov    ecx,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b9:
	/* 0x6b9: jmp    6bd <do_action+0x6bd> */
	X86_SIM_X86_JMP(0x6b9, 0x6bd, x86_l_6bd);
x86_l_6bb:
	/* 0x6bb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6bd:
	/* 0x6bd: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_6bf:
	/* 0x6bf: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6c4:
	/* 0x6c4: mov    QWORD PTR [rdx+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6c8:
	/* 0x6c8: mov    rdi,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6cd:
	/* 0x6cd: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_6d1:
	/* 0x6d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d4:
	/* 0x6d4: mov    QWORD PTR [rsp+0x48],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_6d9:
	/* 0x6d9: mov    QWORD PTR [rsp+0x50],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6de:
	/* 0x6de: jns    7fa <do_action+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6de, 0x7fa, x86_l_7fa);
x86_l_6e4:
	/* 0x6e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e7:
	/* 0x6e7: jns    809 <do_action+0x809> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6e7, 0x809, x86_l_809);
x86_l_6ed:
	/* 0x6ed: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f0:
	/* 0x6f0: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6f5:
	/* 0x6f5: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6f9:
	/* 0x6f9: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6fd:
	/* 0x6fd: mov    QWORD PTR [rdx+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_701:
	/* 0x701: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_705:
	/* 0x705: mov    QWORD PTR [rdx+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_709:
	/* 0x709: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_70d:
	/* 0x70d: mov    QWORD PTR [rdx+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_711:
	/* 0x711: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_715:
	/* 0x715: mov    QWORD PTR [rdx+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_719:
	/* 0x719: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_71d:
	/* 0x71d: mov    QWORD PTR [rdx+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_721:
	/* 0x721: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_725:
	/* 0x725: mov    QWORD PTR [rdx+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_729:
	/* 0x729: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_72d:
	/* 0x72d: mov    QWORD PTR [rdx+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_731:
	/* 0x731: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_735:
	/* 0x735: mov    QWORD PTR [rdx+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_739:
	/* 0x739: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_73d:
	/* 0x73d: mov    QWORD PTR [rdx+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_741:
	/* 0x741: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_745:
	/* 0x745: mov    QWORD PTR [rdx+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_749:
	/* 0x749: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_74d:
	/* 0x74d: mov    QWORD PTR [rdx+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_751:
	/* 0x751: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_755:
	/* 0x755: mov    QWORD PTR [rdx+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_759:
	/* 0x759: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_75d:
	/* 0x75d: mov    QWORD PTR [rdx+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_764:
	/* 0x764: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_768:
	/* 0x768: mov    QWORD PTR [rdx+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_76f:
	/* 0x76f: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_773:
	/* 0x773: mov    QWORD PTR [rdx+0x90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_77a:
	/* 0x77a: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_781:
	/* 0x781: mov    QWORD PTR [rdx+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_788:
	/* 0x788: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_78f:
	/* 0x78f: mov    QWORD PTR [rdx+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_796:
	/* 0x796: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_79d:
	/* 0x79d: mov    QWORD PTR [rdx+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_7a4:
	/* 0x7a4: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_7ab:
	/* 0x7ab: mov    QWORD PTR [rdx+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_7b2:
	/* 0x7b2: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_7b9:
	/* 0x7b9: mov    QWORD PTR [rdx+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_7c0:
	/* 0x7c0: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_7c7:
	/* 0x7c7: mov    QWORD PTR [rdx+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_7ce:
	/* 0x7ce: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_7d5:
	/* 0x7d5: mov    QWORD PTR [rdx+0xc8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_7dc:
	/* 0x7dc: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_7e3:
	/* 0x7e3: mov    QWORD PTR [rdx+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_7ea:
	/* 0x7ea: mov    rax,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_7f1:
	/* 0x7f1: mov    QWORD PTR [rdx+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_7f8:
	/* 0x7f8: jmp    815 <do_action+0x815> */
	X86_SIM_X86_JMP(0x7f8, 0x815, x86_l_815);
x86_l_7fa:
	/* 0x7fa: mov    esi,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_7ff:
	/* 0x7ff: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_802:
	/* 0x802: call   33a7 <read_reg+0x27c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_807:
	/* 0x807: jmp    815 <do_action+0x815> */
	X86_SIM_X86_JMP(0x807, 0x815, x86_l_815);
x86_l_809:
	/* 0x809: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_80e:
	/* 0x80e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_810:
	/* 0x810: call   33b5 <read_reg+0x27d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_815:
	/* 0x815: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_818:
	/* 0x818: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_81f:
	/* 0x81f: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_827:
	/* 0x827: jmp    855 <do_action+0x855> */
	X86_SIM_X86_JMP(0x827, 0x855, x86_l_855);
x86_l_829:
	/* 0x829: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_82b:
	/* 0x82b: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_830:
	/* 0x830: call   33d5 <read_reg+0x27f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_835:
	/* 0x835: mov    r8,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_83a:
	/* 0x83a: add    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_83d:
	/* 0x83d: mov    DWORD PTR [rsp+0x28],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_841:
	/* 0x841: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_848:
	/* 0x848: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_84b:
	/* 0x84b: cmp    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 5ULL);
x86_l_84f:
	/* 0x84f: je     9db <do_action+0x9db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x84f, 0x9db, x86_l_9db);
x86_l_855:
	/* 0x855: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_85d:
	/* 0x85d: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_860:
	/* 0x860: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_865:
	/* 0x865: call   340a <read_reg+0x282b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_86a:
	/* 0x86a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86d:
	/* 0x86d: je     9db <do_action+0x9db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x86d, 0x9db, x86_l_9db);
x86_l_873:
	/* 0x873: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_879:
	/* 0x879: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_880:
	/* 0x880: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_883:
	/* 0x883: call   3428 <read_reg+0x2849> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_888:
	/* 0x888: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88b:
	/* 0x88b: je     9db <do_action+0x9db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x88b, 0x9db, x86_l_9db);
x86_l_891:
	/* 0x891: cmp    DWORD PTR [rax+r13*4+0x40],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 279172874239ULL);
x86_l_897:
	/* 0x897: je     9db <do_action+0x9db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x897, 0x9db, x86_l_9db);
x86_l_89d:
	/* 0x89d: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_8a5:
	/* 0x8a5: mov    eax,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8a8:
	/* 0x8a8: cmp    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ab:
	/* 0x8ab: jge    9db <do_action+0x9db> */
	X86_SIM_X86_JCC(X86_CC_GE, 0x8ab, 0x9db, x86_l_9db);
x86_l_8b1:
	/* 0x8b1: cmp    r13,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_8b5:
	/* 0x8b5: je     90f <do_action+0x90f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b5, 0x90f, x86_l_90f);
x86_l_8b7:
	/* 0x8b7: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_8bf:
	/* 0x8bf: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_8c2:
	/* 0x8c2: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8c7:
	/* 0x8c7: call   346c <read_reg+0x288d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8cc:
	/* 0x8cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8cf:
	/* 0x8cf: je     907 <do_action+0x907> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8cf, 0x907, x86_l_907);
x86_l_8d1:
	/* 0x8d1: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_8d7:
	/* 0x8d7: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_8de:
	/* 0x8de: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e1:
	/* 0x8e1: call   3486 <read_reg+0x28a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8e6:
	/* 0x8e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e9:
	/* 0x8e9: je     907 <do_action+0x907> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e9, 0x907, x86_l_907);
x86_l_8eb:
	/* 0x8eb: cmp    DWORD PTR [rax+r13*4+0x44],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 296352743423ULL);
x86_l_8f1:
	/* 0x8f1: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_8f9:
	/* 0x8f9: je     90f <do_action+0x90f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f9, 0x90f, x86_l_90f);
x86_l_8fb:
	/* 0x8fb: mov    ecx,DWORD PTR [rbx+r13*8+0x5e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 24192ULL);
x86_l_903:
	/* 0x903: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_905:
	/* 0x905: jmp    917 <do_action+0x917> */
	X86_SIM_X86_JMP(0x905, 0x917, x86_l_917);
x86_l_907:
	/* 0x907: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_90f:
	/* 0x90f: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_912:
	/* 0x912: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_914:
	/* 0x914: add    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_917:
	/* 0x917: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_919:
	/* 0x919: jle    848 <do_action+0x848> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x919, 0x848, x86_l_848);
x86_l_91f:
	/* 0x91f: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_921:
	/* 0x921: cmp    ecx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_924:
	/* 0x924: jl     92b <do_action+0x92b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x924, 0x92b, x86_l_92b);
x86_l_926:
	/* 0x926: mov    ebp,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_92b:
	/* 0x92b: add    edx,0x3ffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16380ULL);
x86_l_931:
	/* 0x931: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_937:
	/* 0x937: movzx  r8d,BYTE PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 40ULL);
x86_l_93d:
	/* 0x93d: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_942:
	/* 0x942: lea    rdi,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_946:
	/* 0x946: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_949:
	/* 0x949: add    rdx,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_950:
	/* 0x950: jns    829 <do_action+0x829> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x950, 0x829, x86_l_829);
x86_l_956:
	/* 0x956: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_959:
	/* 0x959: jns    992 <do_action+0x992> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x959, 0x992, x86_l_992);
x86_l_95b:
	/* 0x95b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_95d:
	/* 0x95d: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_960:
	/* 0x960: jb     97a <do_action+0x97a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x960, 0x97a, x86_l_97a);
x86_l_962:
	/* 0x962: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_964:
	/* 0x964: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_966:
	/* 0x966: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_96a:
	/* 0x96a: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_96e:
	/* 0x96e: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_971:
	/* 0x971: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_974:
	/* 0x974: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_976:
	/* 0x976: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_978:
	/* 0x978: jbe    964 <do_action+0x964> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x978, 0x964, x86_l_964);
x86_l_97a:
	/* 0x97a: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_97e:
	/* 0x97e: jne    9a5 <do_action+0x9a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x97e, 0x9a5, x86_l_9a5);
x86_l_980:
	/* 0x980: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_984:
	/* 0x984: jne    9b6 <do_action+0x9b6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x984, 0x9b6, x86_l_9b6);
x86_l_986:
	/* 0x986: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_98a:
	/* 0x98a: je     83a <do_action+0x83a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x98a, 0x83a, x86_l_83a);
x86_l_990:
	/* 0x990: jmp    9cd <do_action+0x9cd> */
	X86_SIM_X86_JMP(0x990, 0x9cd, x86_l_9cd);
x86_l_992:
	/* 0x992: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_994:
	/* 0x994: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_996:
	/* 0x996: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_99b:
	/* 0x99b: call   3540 <read_reg+0x2961> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_9a0:
	/* 0x9a0: jmp    835 <do_action+0x835> */
	X86_SIM_X86_JMP(0x9a0, 0x835, x86_l_835);
x86_l_9a5:
	/* 0x9a5: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_9a7:
	/* 0x9a7: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_9aa:
	/* 0x9aa: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_9ad:
	/* 0x9ad: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_9b0:
	/* 0x9b0: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_9b4:
	/* 0x9b4: je     986 <do_action+0x986> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b4, 0x986, x86_l_986);
x86_l_9b6:
	/* 0x9b6: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_9b8:
	/* 0x9b8: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_9bc:
	/* 0x9bc: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_9c0:
	/* 0x9c0: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_9c3:
	/* 0x9c3: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_9c7:
	/* 0x9c7: je     83a <do_action+0x83a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c7, 0x83a, x86_l_83a);
x86_l_9cd:
	/* 0x9cd: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_9cf:
	/* 0x9cf: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_9d3:
	/* 0x9d3: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_9d6:
	/* 0x9d6: jmp    83a <do_action+0x83a> */
	X86_SIM_X86_JMP(0x9d6, 0x83a, x86_l_83a);
x86_l_9db:
	/* 0x9db: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_9e2:
	/* 0x9e2: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9e7:
	/* 0x9e7: call   358c <read_reg+0x29ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9ec:
	/* 0x9ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ef:
	/* 0x9ef: je     a0d <do_action+0xa0d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ef, 0xa0d, x86_l_a0d);
x86_l_9f1:
	/* 0x9f1: imul   rcx,QWORD PTR [rsp+0x60],0xfffffffffff0bdc0 */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 416610827712ULL);
x86_l_9fa:
	/* 0x9fa: add    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_9fe:
	/* 0x9fe: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a01:
	/* 0xa01: jbe    a0d <do_action+0xa0d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa01, 0xa0d, x86_l_a0d);
x86_l_a03:
	/* 0xa03: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a08:
	/* 0xa08: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a0b:
	/* 0xa0b: jmp    a23 <do_action+0xa23> */
	X86_SIM_X86_JMP(0xa0b, 0xa23, x86_l_a23);
x86_l_a0d:
	/* 0xa0d: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_a14:
	/* 0xa14: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_a17:
	/* 0xa17: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a1c:
	/* 0xa1c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a1e:
	/* 0xa1e: call   35c3 <read_reg+0x29e4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_a23:
	/* 0xa23: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_a28:
	/* 0xa28: lea    eax,[r14+0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_a2c:
	/* 0xa2c: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_a32:
	/* 0xa32: je     a50 <do_action+0xa50> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa32, 0xa50, x86_l_a50);
x86_l_a34:
	/* 0xa34: or     BYTE PTR [rbx+0x1],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967298ULL);
x86_l_a38:
	/* 0xa38: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_a3f:
	/* 0xa3f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a42:
	/* 0xa42: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a44:
	/* 0xa44: call   35e9 <read_reg+0x2a0a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_a49:
	/* 0xa49: mov    QWORD PTR [rbx+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_a50:
	/* 0xa50: lea    eax,[r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a54:
	/* 0xa54: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_a5a:
	/* 0xa5a: je     a7b <do_action+0xa7b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5a, 0xa7b, x86_l_a7b);
x86_l_a5c:
	/* 0xa5c: or     BYTE PTR [rbx+0x1],0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967300ULL);
x86_l_a60:
	/* 0xa60: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_a67:
	/* 0xa67: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_a6c:
	/* 0xa6c: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a6f:
	/* 0xa6f: call   3614 <read_reg+0x2a35> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_a74:
	/* 0xa74: mov    QWORD PTR [rbx+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_a7b:
	/* 0xa7b: add    r14d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_a7f:
	/* 0xa7f: cmp    DWORD PTR [r15+r14*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 17179869184ULL);
x86_l_a85:
	/* 0xa85: je     b8f <do_action+0xb8f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa85, 0xb8f, x86_l_b8f);
x86_l_a8b:
	/* 0xa8b: or     BYTE PTR [rbx+0x1],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967304ULL);
x86_l_a8f:
	/* 0xa8f: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0xa8f, 0xb8f, x86_l_b8f);
x86_l_a94:
	/* 0xa94: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)write_offload));
x86_l_a9b:
	/* 0xa9b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_aa0:
	/* 0xaa0: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_aa3:
	/* 0xaa3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aa5:
	/* 0xaa5: call   364a <read_reg+0x2a6b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_aaa:
	/* 0xaaa: jmp    b2c <do_action+0xb2c> */
	X86_SIM_X86_JMP(0xaaa, 0xb2c, x86_l_b2c);
x86_l_aaf:
	/* 0xaaf: mov    DWORD PTR [rsp+0x38],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518168577ULL);
x86_l_ab7:
	/* 0xab7: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_abe:
	/* 0xabe: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_ac1:
	/* 0xac1: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ac6:
	/* 0xac6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac8:
	/* 0xac8: call   366a <read_reg+0x2a8b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_acd:
	/* 0xacd: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_ad0:
	/* 0xad0: je     554 <do_action+0x554> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad0, 0x554, x86_l_554);
x86_l_ad6:
	/* 0xad6: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_add:
	/* 0xadd: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ae2:
	/* 0xae2: call   3684 <read_reg+0x2aa5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae7:
	/* 0xae7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aea:
	/* 0xaea: je     554 <do_action+0x554> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaea, 0x554, x86_l_554);
x86_l_af0:
	/* 0xaf0: mov    ecx,DWORD PTR [rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_af4:
	/* 0xaf4: lock add DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RCX, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_af7:
	/* 0xaf7: jmp    554 <do_action+0x554> */
	X86_SIM_X86_JMP(0xaf7, 0x554, x86_l_554);
x86_l_afc:
	/* 0xafc: mov    DWORD PTR [rsp+0x38],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518168577ULL);
x86_l_b04:
	/* 0xb04: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_b0b:
	/* 0xb0b: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b10:
	/* 0xb10: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_b15:
	/* 0xb15: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b17:
	/* 0xb17: call   36b9 <read_reg+0x2ada> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b1c:
	/* 0xb1c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b20:
	/* 0xb20: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b25:
	/* 0xb25: mov    QWORD PTR [r14+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b29:
	/* 0xb29: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b2c:
	/* 0xb2c: mov    r14d,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b31:
	/* 0xb31: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b38:
	/* 0xb38: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_stats));
x86_l_b3f:
	/* 0xb3f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b42:
	/* 0xb42: call   36e4 <read_reg+0x2b05> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b47:
	/* 0xb47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4a:
	/* 0xb4a: je     b51 <do_action+0xb51> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4a, 0xb51, x86_l_b51);
x86_l_b4c:
	/* 0xb4c: lock inc QWORD PTR [rax+r13*8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_R13, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_b51:
	/* 0xb51: jmp    b8f <do_action+0xb8f> */
	X86_SIM_X86_JMP(0xb51, 0xb8f, x86_l_b8f);
x86_l_b53:
	/* 0xb53: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b56:
	/* 0xb56: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b58:
	/* 0xb58: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5b:
	/* 0xb5b: call   36fd <read_reg+0x2b1e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b60:
	/* 0xb60: jmp    b6f <do_action+0xb6f> */
	X86_SIM_X86_JMP(0xb60, 0xb6f, x86_l_b6f);
x86_l_b62:
	/* 0xb62: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b65:
	/* 0xb65: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b67:
	/* 0xb67: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b6a:
	/* 0xb6a: call   370c <read_reg+0x2b2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_b6f:
	/* 0xb6f: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b74:
	/* 0xb74: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_b7b:
	/* 0xb7b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b7e:
	/* 0xb7e: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b81:
	/* 0xb81: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b83:
	/* 0xb83: call   3725 <read_reg+0x2b46> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b88:
	/* 0xb88: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b8a:
	/* 0xb8a: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_b8d:
	/* 0xb8d: jne    b99 <do_action+0xb99> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb8d, 0xb99, x86_l_b99);
x86_l_b8f:
	/* 0xb8f: mov    QWORD PTR [rbx+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_b93:
	/* 0xb93: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_b96:
	/* 0xb96: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_b99:
	/* 0xb99: add    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 104ULL);
x86_l_b9d:
	/* 0xb9d: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b9e:
	/* 0xb9e: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ba0:
	/* 0xba0: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ba2:
	/* 0xba2: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ba4:
	/* 0xba4: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ba6:
	/* 0xba6: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ba7:
	/* 0xba7: jmp    cf5 <read_reg+0x116> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_bac:
	/* 0xbac: mov    ecx,DWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_baf:
	/* 0xbaf: mov    DWORD PTR [rdx+rdi*1],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_bb2:
	/* 0xbb2: add    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_bb5:
	/* 0xbb5: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_bb9:
	/* 0xbb9: je     3f3 <do_action+0x3f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb9, 0x3f3, x86_l_3f3);
x86_l_bbf:
	/* 0xbbf: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_bc1:
	/* 0xbc1: movzx  r8d,WORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_bc6:
	/* 0xbc6: mov    WORD PTR [rdx+rcx*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_bcb:
	/* 0xbcb: add    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_bce:
	/* 0xbce: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_bd2:
	/* 0xbd2: je     b74 <do_action+0xb74> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd2, 0xb74, x86_l_b74);
x86_l_bd4:
	/* 0xbd4: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_bd6:
	/* 0xbd6: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_bda:
	/* 0xbda: mov    BYTE PTR [rdx+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_bdd:
	/* 0xbdd: jmp    b74 <do_action+0xb74> */
	X86_SIM_X86_JMP(0xbdd, 0xb74, x86_l_b74);
x86_l_cf5:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_bdf */
x86_l_bdf:
	/* 0xbdf: rorx   ecx,esi,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 3ULL);
x86_l_be5:
	/* 0xbe5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_be7:
	/* 0xbe7: cmp    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_bea:
	/* 0xbea: jle    c21 <read_reg+0x42> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xbea, 0xc21, x86_l_c21);
x86_l_bec:
	/* 0xbec: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_bef:
	/* 0xbef: jle    c45 <read_reg+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xbef, 0xc45, x86_l_c45);
x86_l_bf1:
	/* 0xbf1: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_bf4:
	/* 0xbf4: jle    caa <read_reg+0xcb> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xbf4, 0xcaa, x86_l_caa);
x86_l_bfa:
	/* 0xbfa: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_bfd:
	/* 0xbfd: je     cde <read_reg+0xff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbfd, 0xcde, x86_l_cde);
x86_l_c03:
	/* 0xc03: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_c06:
	/* 0xc06: je     cc6 <read_reg+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc06, 0xcc6, x86_l_cc6);
x86_l_c0c:
	/* 0xc0c: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_c0f:
	/* 0xc0f: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc0f, 0xcf4, x86_l_cf4);
x86_l_c15:
	/* 0xc15: add    rdi,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_c1c:
	/* 0xc1c: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc1c, 0xce8, x86_l_ce8);
x86_l_c21:
	/* 0xc21: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_c24:
	/* 0xc24: jg     c61 <read_reg+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc24, 0xc61, x86_l_c61);
x86_l_c26:
	/* 0xc26: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_c29:
	/* 0xc29: jg     c8a <read_reg+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc29, 0xc8a, x86_l_c8a);
x86_l_c2b:
	/* 0xc2b: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c2d:
	/* 0xc2d: je     ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc2d, 0xce8, x86_l_ce8);
x86_l_c33:
	/* 0xc33: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_c36:
	/* 0xc36: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc36, 0xcf4, x86_l_cf4);
x86_l_c3c:
	/* 0xc3c: add    rdi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_c40:
	/* 0xc40: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc40, 0xce8, x86_l_ce8);
x86_l_c45:
	/* 0xc45: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_c48:
	/* 0xc48: jg     c7a <read_reg+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc48, 0xc7a, x86_l_c7a);
x86_l_c4a:
	/* 0xc4a: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_c4d:
	/* 0xc4d: je     cba <read_reg+0xdb> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc4d, 0xcba, x86_l_cba);
x86_l_c4f:
	/* 0xc4f: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_c52:
	/* 0xc52: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc52, 0xcf4, x86_l_cf4);
x86_l_c58:
	/* 0xc58: add    rdi,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_c5c:
	/* 0xc5c: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc5c, 0xce8, x86_l_ce8);
x86_l_c61:
	/* 0xc61: cmp    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_c64:
	/* 0xc64: jg     c9a <read_reg+0xbb> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc64, 0xc9a, x86_l_c9a);
x86_l_c66:
	/* 0xc66: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_c69:
	/* 0xc69: je     ccc <read_reg+0xed> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc69, 0xccc, x86_l_ccc);
x86_l_c6b:
	/* 0xc6b: cmp    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_c6e:
	/* 0xc6e: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc6e, 0xcf4, x86_l_cf4);
x86_l_c74:
	/* 0xc74: add    rdi,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_c78:
	/* 0xc78: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc78, 0xce8, x86_l_ce8);
x86_l_c7a:
	/* 0xc7a: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_c7d:
	/* 0xc7d: je     cc0 <read_reg+0xe1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc7d, 0xcc0, x86_l_cc0);
x86_l_c7f:
	/* 0xc7f: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_c82:
	/* 0xc82: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc82, 0xcf4, x86_l_cf4);
x86_l_c84:
	/* 0xc84: add    rdi,0x58 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_c88:
	/* 0xc88: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc88, 0xce8, x86_l_ce8);
x86_l_c8a:
	/* 0xc8a: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_c8d:
	/* 0xc8d: je     cd2 <read_reg+0xf3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc8d, 0xcd2, x86_l_cd2);
x86_l_c8f:
	/* 0xc8f: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_c92:
	/* 0xc92: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xc92, 0xcf4, x86_l_cf4);
x86_l_c94:
	/* 0xc94: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_c98:
	/* 0xc98: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xc98, 0xce8, x86_l_ce8);
x86_l_c9a:
	/* 0xc9a: cmp    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_c9d:
	/* 0xc9d: je     cd8 <read_reg+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc9d, 0xcd8, x86_l_cd8);
x86_l_c9f:
	/* 0xc9f: cmp    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_ca2:
	/* 0xca2: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xca2, 0xcf4, x86_l_cf4);
x86_l_ca4:
	/* 0xca4: add    rdi,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_ca8:
	/* 0xca8: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xca8, 0xce8, x86_l_ce8);
x86_l_caa:
	/* 0xcaa: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_cad:
	/* 0xcad: je     ce4 <read_reg+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcad, 0xce4, x86_l_ce4);
x86_l_caf:
	/* 0xcaf: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_cb2:
	/* 0xcb2: jne    cf4 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xcb2, 0xcf4, x86_l_cf4);
x86_l_cb4:
	/* 0xcb4: add    rdi,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 104ULL);
x86_l_cb8:
	/* 0xcb8: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcb8, 0xce8, x86_l_ce8);
x86_l_cba:
	/* 0xcba: add    rdi,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_cbe:
	/* 0xcbe: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcbe, 0xce8, x86_l_ce8);
x86_l_cc0:
	/* 0xcc0: add    rdi,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_cc4:
	/* 0xcc4: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcc4, 0xce8, x86_l_ce8);
x86_l_cc6:
	/* 0xcc6: sub    rdi,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_cca:
	/* 0xcca: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcca, 0xce8, x86_l_ce8);
x86_l_ccc:
	/* 0xccc: add    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_cd0:
	/* 0xcd0: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcd0, 0xce8, x86_l_ce8);
x86_l_cd2:
	/* 0xcd2: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_cd6:
	/* 0xcd6: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcd6, 0xce8, x86_l_ce8);
x86_l_cd8:
	/* 0xcd8: add    rdi,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_cdc:
	/* 0xcdc: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xcdc, 0xce8, x86_l_ce8);
x86_l_cde:
	/* 0xcde: add    rdi,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_ce2:
	/* 0xce2: jmp    ce8 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xce2, 0xce8, x86_l_ce8);
x86_l_ce4:
	/* 0xce4: add    rdi,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_ce8:
	/* 0xce8: mov    eax,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_ced:
	/* 0xced: sub    eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_cef:
	/* 0xcef: bzhi   rax,QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RAX, X86_RDI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_cf4:
	/* 0xcf4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_cf4);

x86_sim_ret_dispatch_cf4:
	switch (__x86_sim_ret_addr) {
	case 0x24aULL: goto x86_l_24a;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
