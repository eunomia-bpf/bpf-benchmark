#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 408U
#define X86_SIM_STACK_VALUE_WORDS(M) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30) M(31) M(32) M(34) M(35) M(36) M(37) M(38) M(39) M(40) M(41) M(43) M(44)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 buffer_heap_map[] __ksym;
extern __u8 data_heap[] __ksym;
extern __u8 execve_calls[] __ksym;
extern __u8 execve_heap[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 execve_msg_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_cgtracker_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 tg_execve_joined_info_map[] __ksym;
extern __u8 tg_execve_joined_info_map_stats[] __ksym;
extern __u8 tg_mbset_gen[] __ksym;
extern __u8 tg_mbset_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC_MEM, X86_OP_SETCC_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tracepoint/sys_execve")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: call   19 <event_execve+0x19> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_19:
	/* 0x19: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c:
	/* 0x1c: movzx  r12d,WORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_21:
	/* 0x21: mov    DWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_2c:
	/* 0x2c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_msg_heap_map));
x86_l_33:
	/* 0x33: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3b:
	/* 0x3b: call   40 <event_execve+0x40> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_40:
	/* 0x40: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_43:
	/* 0x43: je     1e4b <event_execve+0x1e4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43, 0x1e4b, x86_l_1e4b);
x86_l_49:
	/* 0x49: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c:
	/* 0x4c: call   51 <event_execve+0x51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_51:
	/* 0x51: mov    QWORD PTR [rsp+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_56:
	/* 0x56: call   5b <event_execve+0x5b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_5b:
	/* 0x5b: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_61:
	/* 0x61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64:
	/* 0x64: mov    QWORD PTR [rsp+0x70],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_69:
	/* 0x69: mov    QWORD PTR [rsp+0xa8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_71:
	/* 0x71: jns    27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x71, 0x27d, x86_l_27d);
x86_l_77:
	/* 0x77: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7a:
	/* 0x7a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7d:
	/* 0x7d: je     27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d, 0x27d, x86_l_27d);
x86_l_83:
	/* 0x83: lea    rcx,[r15+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_8a:
	/* 0x8a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8c:
	/* 0x8c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8f:
	/* 0x8f: jns    93 <event_execve+0x93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8f, 0x93, x86_l_93);
x86_l_91:
	/* 0x91: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_93:
	/* 0x93: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_97:
	/* 0x97: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_9e:
	/* 0x9e: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a3:
	/* 0xa3: call   a8 <event_execve+0xa8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a8:
	/* 0xa8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ab:
	/* 0xab: je     18a <event_execve+0x18a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xab, 0x18a, x86_l_18a);
x86_l_b1:
	/* 0xb1: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4:
	/* 0xb4: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_b9:
	/* 0xb9: je     18a <event_execve+0x18a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9, 0x18a, x86_l_18a);
x86_l_bf:
	/* 0xbf: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c2:
	/* 0xc2: mov    rcx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c6:
	/* 0xc6: mov    QWORD PTR [r14+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_cd:
	/* 0xcd: mov    QWORD PTR [r14+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_d4:
	/* 0xd4: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_dc:
	/* 0xdc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_mbset_gen));
x86_l_e3:
	/* 0xe3: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e8:
	/* 0xe8: call   ed <event_execve+0xed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ed:
	/* 0xed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f0:
	/* 0xf0: je     990 <event_execve+0x990> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0, 0x990, x86_l_990);
x86_l_f6:
	/* 0xf6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f9:
	/* 0xf9: cmp    rcx,QWORD PTR [rbx+0x378] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 888ULL);
x86_l_100:
	/* 0x100: je     990 <event_execve+0x990> */
	X86_SIM_X86_JCC(X86_CC_E, 0x100, 0x990, x86_l_990);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_10e:
	/* 0x10e: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_115:
	/* 0x115: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_118:
	/* 0x118: je     91a <event_execve+0x91a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x118, 0x91a, x86_l_91a);
x86_l_11e:
	/* 0x11e: mov    ebp,0x1869f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 99999ULL);
x86_l_123:
	/* 0x123: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_126:
	/* 0x126: mov    eax,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_129:
	/* 0x129: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12d:
	/* 0x12d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_134:
	/* 0x134: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_139:
	/* 0x139: call   13e <event_execve+0x13e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_13e:
	/* 0x13e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_141:
	/* 0x141: je     979 <event_execve+0x979> */
	X86_SIM_X86_JCC(X86_CC_E, 0x141, 0x979, x86_l_979);
x86_l_147:
	/* 0x147: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a:
	/* 0x14a: lea    rsi,[rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_14e:
	/* 0x14e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_mbset_map));
x86_l_155:
	/* 0x155: call   15a <event_execve+0x15a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15a:
	/* 0x15a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15d:
	/* 0x15d: je     16f <event_execve+0x16f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15d, 0x16f, x86_l_16f);
x86_l_15f:
	/* 0x15f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162:
	/* 0x162: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165:
	/* 0x165: je     16f <event_execve+0x16f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x165, 0x16f, x86_l_16f);
x86_l_167:
	/* 0x167: lock or QWORD PTR [rbx+0x370],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RBX, X86_RAX, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 880ULL);
x86_l_16f:
	/* 0x16f: sub    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SUB, 1ULL);
x86_l_172:
	/* 0x172: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_175:
	/* 0x175: cmp    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_178:
	/* 0x178: je     979 <event_execve+0x979> */
	X86_SIM_X86_JCC(X86_CC_E, 0x178, 0x979, x86_l_979);
x86_l_17e:
	/* 0x17e: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_181:
	/* 0x181: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_183:
	/* 0x183: je     126 <event_execve+0x126> */
	X86_SIM_X86_JCC(X86_CC_E, 0x183, 0x126, x86_l_126);
x86_l_185:
	/* 0x185: jmp    979 <event_execve+0x979> */
	X86_SIM_X86_JMP(0x185, 0x979, x86_l_979);
x86_l_18a:
	/* 0x18a: add    r15,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_191:
	/* 0x191: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_194:
	/* 0x194: jns    27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x194, 0x27d, x86_l_27d);
x86_l_19a:
	/* 0x19a: mov    r15,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19d:
	/* 0x19d: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1a0:
	/* 0x1a0: je     27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0, 0x27d, x86_l_27d);
x86_l_1a6:
	/* 0x1a6: lea    rcx,[r15+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1ad:
	/* 0x1ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1af:
	/* 0x1af: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b2:
	/* 0x1b2: jns    1b6 <event_execve+0x1b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b2, 0x1b6, x86_l_1b6);
x86_l_1b4:
	/* 0x1b4: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b6:
	/* 0x1b6: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ba:
	/* 0x1ba: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_1c1:
	/* 0x1c1: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c6:
	/* 0x1c6: call   1cb <event_execve+0x1cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cb:
	/* 0x1cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ce:
	/* 0x1ce: je     1de <event_execve+0x1de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce, 0x1de, x86_l_1de);
x86_l_1d0:
	/* 0x1d0: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d3:
	/* 0x1d3: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1d8:
	/* 0x1d8: jne    bf <event_execve+0xbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d8, 0xbf, x86_l_bf);
x86_l_1de:
	/* 0x1de: add    r15,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1e5:
	/* 0x1e5: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1e8:
	/* 0x1e8: jns    27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e8, 0x27d, x86_l_27d);
x86_l_1ee:
	/* 0x1ee: mov    r15,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f1:
	/* 0x1f1: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1f4:
	/* 0x1f4: je     27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f4, 0x27d, x86_l_27d);
x86_l_1fa:
	/* 0x1fa: lea    rcx,[r15+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_201:
	/* 0x201: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_203:
	/* 0x203: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_206:
	/* 0x206: jns    20a <event_execve+0x20a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x206, 0x20a, x86_l_20a);
x86_l_208:
	/* 0x208: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a:
	/* 0x20a: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20e:
	/* 0x20e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_215:
	/* 0x215: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21a:
	/* 0x21a: call   21f <event_execve+0x21f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_21f:
	/* 0x21f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_222:
	/* 0x222: je     232 <event_execve+0x232> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222, 0x232, x86_l_232);
x86_l_224:
	/* 0x224: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_227:
	/* 0x227: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_22c:
	/* 0x22c: jne    bf <event_execve+0xbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22c, 0xbf, x86_l_bf);
x86_l_232:
	/* 0x232: add    r15,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_239:
	/* 0x239: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_23c:
	/* 0x23c: jns    27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c, 0x27d, x86_l_27d);
x86_l_23e:
	/* 0x23e: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241:
	/* 0x241: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_244:
	/* 0x244: je     27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244, 0x27d, x86_l_27d);
x86_l_246:
	/* 0x246: add    rax,0xaf4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
x86_l_24c:
	/* 0x24c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e:
	/* 0x24e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_251:
	/* 0x251: jns    255 <event_execve+0x255> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x251, 0x255, x86_l_255);
x86_l_253:
	/* 0x253: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_255:
	/* 0x255: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_259:
	/* 0x259: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_260:
	/* 0x260: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_265:
	/* 0x265: call   26a <event_execve+0x26a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26a:
	/* 0x26a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26d:
	/* 0x26d: je     27d <event_execve+0x27d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d, 0x27d, x86_l_27d);
x86_l_26f:
	/* 0x26f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_272:
	/* 0x272: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_277:
	/* 0x277: jne    bf <event_execve+0xbf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277, 0xbf, x86_l_bf);
x86_l_27d:
	/* 0x27d: lea    rcx,[rbp+0xb00] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2816ULL);
x86_l_284:
	/* 0x284: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286:
	/* 0x286: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_289:
	/* 0x289: jns    2a8 <event_execve+0x2a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x289, 0x2a8, x86_l_2a8);
x86_l_28b:
	/* 0x28b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28e:
	/* 0x28e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_291:
	/* 0x291: je     2a8 <event_execve+0x2a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x291, 0x2a8, x86_l_2a8);
x86_l_293:
	/* 0x293: add    rcx,0xaf4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
x86_l_29a:
	/* 0x29a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29d:
	/* 0x29d: mov    rbx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2a2:
	/* 0x2a2: jns    2ad <event_execve+0x2ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a2, 0x2ad, x86_l_2ad);
x86_l_2a4:
	/* 0x2a4: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a6:
	/* 0x2a6: jmp    2ad <event_execve+0x2ad> */
	X86_SIM_X86_JMP(0x2a6, 0x2ad, x86_l_2ad);
x86_l_2a8:
	/* 0x2a8: mov    rbx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2ad:
	/* 0x2ad: mov    DWORD PTR [r14+0xa0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2b4:
	/* 0x2b4: mov    QWORD PTR [r14+0xa8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_2bf:
	/* 0x2bf: mov    eax,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_2c4:
	/* 0x2c4: mov    QWORD PTR [r14+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2cb:
	/* 0x2cb: mov    DWORD PTR [r14+0x15c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619009ULL);
x86_l_2d6:
	/* 0x2d6: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2d9:
	/* 0x2d9: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2dd:
	/* 0x2dd: mov    QWORD PTR [r14+0x178],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1614907703296ULL);
x86_l_2e8:
	/* 0x2e8: mov    DWORD PTR [r14+0x144],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 324ULL);
x86_l_2ef:
	/* 0x2ef: mov    DWORD PTR [r14+0x148],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
x86_l_2f6:
	/* 0x2f6: call   2fb <event_execve+0x2fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_2fb:
	/* 0x2fb: add    rax,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_2ff:
	/* 0x2ff: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_301:
	/* 0x301: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_304:
	/* 0x304: jns    335 <event_execve+0x335> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x304, 0x335, x86_l_335);
x86_l_306:
	/* 0x306: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_309:
	/* 0x309: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30c:
	/* 0x30c: je     335 <event_execve+0x335> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30c, 0x335, x86_l_335);
x86_l_30e:
	/* 0x30e: lea    rdx,[rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_312:
	/* 0x312: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_315:
	/* 0x315: jns    335 <event_execve+0x335> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x315, 0x335, x86_l_335);
x86_l_317:
	/* 0x317: mov    edx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_319:
	/* 0x319: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_31b:
	/* 0x31b: je     335 <event_execve+0x335> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31b, 0x335, x86_l_335);
x86_l_31d:
	/* 0x31d: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_320:
	/* 0x320: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_323:
	/* 0x323: add    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
x86_l_329:
	/* 0x329: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32c:
	/* 0x32c: jns    335 <event_execve+0x335> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32c, 0x335, x86_l_335);
x86_l_32e:
	/* 0x32e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_331:
	/* 0x331: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_335:
	/* 0x335: mov    DWORD PTR [r14+0x14c],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 332ULL);
x86_l_33c:
	/* 0x33c: call   341 <event_execve+0x341> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_341:
	/* 0x341: mov    QWORD PTR [r14+0x170],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_348:
	/* 0x348: mov    DWORD PTR [r14+0x140],0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1374389534784ULL);
x86_l_353:
	/* 0x353: call   358 <event_execve+0x358> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_358:
	/* 0x358: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_361:
	/* 0x361: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_364:
	/* 0x364: je     376 <event_execve+0x376> */
	X86_SIM_X86_JCC(X86_CC_E, 0x364, 0x376, x86_l_376);
x86_l_366:
	/* 0x366: add    rax,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_36a:
	/* 0x36a: jns    37a <event_execve+0x37a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36a, 0x37a, x86_l_37a);
x86_l_36c:
	/* 0x36c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36f:
	/* 0x36f: jns    376 <event_execve+0x376> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36f, 0x376, x86_l_376);
x86_l_371:
	/* 0x371: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_374:
	/* 0x374: jmp    391 <event_execve+0x391> */
	X86_SIM_X86_JMP(0x374, 0x391, x86_l_391);
x86_l_376:
	/* 0x376: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_378:
	/* 0x378: jmp    391 <event_execve+0x391> */
	X86_SIM_X86_JMP(0x378, 0x391, x86_l_391);
x86_l_37a:
	/* 0x37a: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_37f:
	/* 0x37f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_384:
	/* 0x384: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_387:
	/* 0x387: call   38c <event_execve+0x38c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_38c:
	/* 0x38c: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_391:
	/* 0x391: add    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_394:
	/* 0x394: mov    DWORD PTR [r14+0x158],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_39b:
	/* 0x39b: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a0:
	/* 0x3a0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map));
x86_l_3a7:
	/* 0x3a7: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3ac:
	/* 0x3ac: call   3b1 <event_execve+0x3b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3b1:
	/* 0x3b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b4:
	/* 0x3b4: je     411 <event_execve+0x411> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b4, 0x411, x86_l_411);
x86_l_3b6:
	/* 0x3b6: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b8:
	/* 0x3b8: mov    DWORD PTR [r14+0x150],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
x86_l_3bf:
	/* 0x3bf: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3c3:
	/* 0x3c3: mov    QWORD PTR [r14+0x168],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_3ca:
	/* 0x3ca: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3cd:
	/* 0x3cd: mov    DWORD PTR [r14+0x160],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_3d4:
	/* 0x3d4: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3d9:
	/* 0x3d9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map));
x86_l_3e0:
	/* 0x3e0: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e5:
	/* 0x3e5: call   3ea <event_execve+0x3ea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_3ea:
	/* 0x3ea: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3ec:
	/* 0x3ec: je     434 <event_execve+0x434> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ec, 0x434, x86_l_434);
x86_l_3ee:
	/* 0x3ee: mov    DWORD PTR [rsp+0x10],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476738ULL);
x86_l_3f6:
	/* 0x3f6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map_stats));
x86_l_3fd:
	/* 0x3fd: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_402:
	/* 0x402: call   407 <event_execve+0x407> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_407:
	/* 0x407: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40a:
	/* 0x40a: je     455 <event_execve+0x455> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40a, 0x455, x86_l_455);
x86_l_40c:
	/* 0x40c: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_40f:
	/* 0x40f: jmp    455 <event_execve+0x455> */
	X86_SIM_X86_JMP(0x40f, 0x455, x86_l_455);
x86_l_411:
	/* 0x411: mov    DWORD PTR [r14+0x150],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1443109011456ULL);
x86_l_41c:
	/* 0x41c: mov    QWORD PTR [r14+0x168],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1546188226560ULL);
x86_l_427:
	/* 0x427: mov    DWORD PTR [r14+0x160],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1511828488192ULL);
x86_l_432:
	/* 0x432: jmp    455 <event_execve+0x455> */
	X86_SIM_X86_JMP(0x432, 0x455, x86_l_455);
x86_l_434:
	/* 0x434: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_43c:
	/* 0x43c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map_stats));
x86_l_443:
	/* 0x443: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_448:
	/* 0x448: call   44d <event_execve+0x44d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_44d:
	/* 0x44d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_450:
	/* 0x450: je     455 <event_execve+0x455> */
	X86_SIM_X86_JCC(X86_CC_E, 0x450, 0x455, x86_l_455);
x86_l_452:
	/* 0x452: dec    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_DEC)), 0ULL);
x86_l_455:
	/* 0x455: lea    rbx,[r14+0x180] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
x86_l_45c:
	/* 0x45c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_45f:
	/* 0x45f: jns    49f <event_execve+0x49f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45f, 0x49f, x86_l_49f);
x86_l_461:
	/* 0x461: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_464:
	/* 0x464: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_467:
	/* 0x467: jns    4bd <event_execve+0x4bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x467, 0x4bd, x86_l_4bd);
x86_l_469:
	/* 0x469: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46b:
	/* 0x46b: cmp    rdx,0xfe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 254ULL);
x86_l_472:
	/* 0x472: je     4db <event_execve+0x4db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x472, 0x4db, x86_l_4db);
x86_l_474:
	/* 0x474: lea    rax,[rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_478:
	/* 0x478: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_47c:
	/* 0x47c: mov    BYTE PTR [rbx+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_480:
	/* 0x480: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_483:
	/* 0x483: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_486:
	/* 0x486: jne    46b <event_execve+0x46b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x486, 0x46b, x86_l_46b);
x86_l_488:
	/* 0x488: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_48a:
	/* 0x48a: js     4b3 <event_execve+0x4b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x48a, 0x4b3, x86_l_4b3);
x86_l_48c:
	/* 0x48c: je     4d6 <event_execve+0x4d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48c, 0x4d6, x86_l_4d6);
x86_l_48e:
	/* 0x48e: cmp    eax,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_493:
	/* 0x493: je     4e3 <event_execve+0x4e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x493, 0x4e3, x86_l_4e3);
x86_l_495:
	/* 0x495: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_498:
	/* 0x498: dec    r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_49b:
	/* 0x49b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49d:
	/* 0x49d: jmp    503 <event_execve+0x503> */
	X86_SIM_X86_JMP(0x49d, 0x503, x86_l_503);
x86_l_49f:
	/* 0x49f: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4a2:
	/* 0x4a2: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_4a7:
	/* 0x4a7: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4aa:
	/* 0x4aa: call   4af <event_execve+0x4af> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_4af:
	/* 0x4af: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4b1:
	/* 0x4b1: jns    48c <event_execve+0x48c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4b1, 0x48c, x86_l_48c);
x86_l_4b3:
	/* 0x4b3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b6:
	/* 0x4b6: mov    eax,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_4bb:
	/* 0x4bb: jmp    503 <event_execve+0x503> */
	X86_SIM_X86_JMP(0x4bb, 0x503, x86_l_503);
x86_l_4bd:
	/* 0x4bd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c0:
	/* 0x4c0: mov    edx,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_4c5:
	/* 0x4c5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4c8:
	/* 0x4c8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ca:
	/* 0x4ca: call   4cf <event_execve+0x4cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 255ULL);
x86_l_4cf:
	/* 0x4cf: mov    eax,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_4d4:
	/* 0x4d4: jmp    503 <event_execve+0x503> */
	X86_SIM_X86_JMP(0x4d4, 0x503, x86_l_503);
x86_l_4d6:
	/* 0x4d6: mov    r15d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4d9:
	/* 0x4d9: jmp    503 <event_execve+0x503> */
	X86_SIM_X86_JMP(0x4d9, 0x503, x86_l_503);
x86_l_4db:
	/* 0x4db: mov    BYTE PTR [r14+0x27e],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2740189134848ULL);
x86_l_4e3:
	/* 0x4e3: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4e6:
	/* 0x4e6: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4e9:
	/* 0x4e9: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4ec:
	/* 0x4ec: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_l_21e6, 0x4f1ULL);
x86_l_4f1:
	/* 0x4f1: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f4:
	/* 0x4f4: mov    eax,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_4f9:
	/* 0x4f9: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4fc:
	/* 0x4fc: je     503 <event_execve+0x503> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4fc, 0x503, x86_l_503);
x86_l_4fe:
	/* 0x4fe: mov    eax,0x800000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 8388608ULL);
x86_l_503:
	/* 0x503: mov    WORD PTR [r14+0x178],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
x86_l_50b:
	/* 0x50b: or     DWORD PTR [r14+0x15c],eax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
x86_l_512:
	/* 0x512: add    DWORD PTR [r14+0x140],r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R14, X86_R15, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 320ULL);
x86_l_519:
	/* 0x519: call   51e <event_execve+0x51e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_51e:
	/* 0x51e: mov    DWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_526:
	/* 0x526: add    rax,0xa78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2680ULL);
x86_l_52c:
	/* 0x52c: jns    540 <event_execve+0x540> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x52c, 0x540, x86_l_540);
x86_l_52e:
	/* 0x52e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_531:
	/* 0x531: jns    559 <event_execve+0x559> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x531, 0x559, x86_l_559);
x86_l_533:
	/* 0x533: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_536:
	/* 0x536: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_53b:
	/* 0x53b: jmp    5c5 <event_execve+0x5c5> */
	X86_SIM_X86_JMP(0x53b, 0x5c5, x86_l_5c5);
x86_l_540:
	/* 0x540: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_545:
	/* 0x545: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_54a:
	/* 0x54a: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54d:
	/* 0x54d: call   552 <event_execve+0x552> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_552:
	/* 0x552: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_555:
	/* 0x555: jne    569 <event_execve+0x569> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x555, 0x569, x86_l_569);
x86_l_557:
	/* 0x557: jmp    5c0 <event_execve+0x5c0> */
	X86_SIM_X86_JMP(0x557, 0x5c0, x86_l_5c0);
x86_l_559:
	/* 0x559: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_562:
	/* 0x562: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_569:
	/* 0x569: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_56b:
	/* 0x56b: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_570:
	/* 0x570: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_577:
	/* 0x577: movabs rax,0x400000042 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869250ULL);
x86_l_581:
	/* 0x581: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_586:
	/* 0x586: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_58d:
	/* 0x58d: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_592:
	/* 0x592: call   597 <event_execve+0x597> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_597:
	/* 0x597: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_59a:
	/* 0x59a: je     5a0 <event_execve+0x5a0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59a, 0x5a0, x86_l_5a0);
x86_l_59c:
	/* 0x59c: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_59e:
	/* 0x59e: jmp    5c0 <event_execve+0x5c0> */
	X86_SIM_X86_JMP(0x59e, 0x5c0, x86_l_5c0);
x86_l_5a0:
	/* 0x5a0: mov    DWORD PTR [rsp+0x10],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476737ULL);
x86_l_5a8:
	/* 0x5a8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_5af:
	/* 0x5af: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5b4:
	/* 0x5b4: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b9:
	/* 0x5b9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5bb:
	/* 0x5bb: call   5c0 <event_execve+0x5c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_5c0:
	/* 0x5c0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c5:
	/* 0x5c5: lea    r12,[r14+0x140] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_5cc:
	/* 0x5cc: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ce:
	/* 0x5ce: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_5d3:
	/* 0x5d3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5d6:
	/* 0x5d6: je     a62 <event_execve+0xa62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d6, 0xa62, x86_l_a62);
x86_l_5dc:
	/* 0x5dc: add    rdx,0x2b8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 696ULL);
x86_l_5e3:
	/* 0x5e3: jns    61d <event_execve+0x61d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5e3, 0x61d, x86_l_61d);
x86_l_5e5:
	/* 0x5e5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5e8:
	/* 0x5e8: jns    633 <event_execve+0x633> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5e8, 0x633, x86_l_633);
x86_l_5ea:
	/* 0x5ea: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ed:
	/* 0x5ed: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5f2:
	/* 0x5f2: mov    edx,0x2c0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 704ULL);
x86_l_5f7:
	/* 0x5f7: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_5fc:
	/* 0x5fc: js     68c <event_execve+0x68c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5fc, 0x68c, x86_l_68c);
x86_l_602:
	/* 0x602: mov    rdi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_605:
	/* 0x605: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_60a:
	/* 0x60a: call   60f <event_execve+0x60f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_60f:
	/* 0x60f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_612:
	/* 0x612: jne    6b9 <event_execve+0x6b9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x612, 0x6b9, x86_l_6b9);
x86_l_618:
	/* 0x618: jmp    6f2 <event_execve+0x6f2> */
	X86_SIM_X86_JMP(0x618, 0x6f2, x86_l_6f2);
x86_l_61d:
	/* 0x61d: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_622:
	/* 0x622: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_627:
	/* 0x627: call   62c <event_execve+0x62c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_62c:
	/* 0x62c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62f:
	/* 0x62f: jne    643 <event_execve+0x643> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62f, 0x643, x86_l_643);
x86_l_631:
	/* 0x631: jmp    67c <event_execve+0x67c> */
	X86_SIM_X86_JMP(0x631, 0x67c, x86_l_67c);
x86_l_633:
	/* 0x633: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_63c:
	/* 0x63c: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_643:
	/* 0x643: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_645:
	/* 0x645: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_64a:
	/* 0x64a: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_651:
	/* 0x651: movabs rax,0x400000047 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869255ULL);
x86_l_65b:
	/* 0x65b: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_660:
	/* 0x660: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_667:
	/* 0x667: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_66c:
	/* 0x66c: call   671 <event_execve+0x671> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_671:
	/* 0x671: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_674:
	/* 0x674: je     7ef <event_execve+0x7ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x674, 0x7ef, x86_l_7ef);
x86_l_67a:
	/* 0x67a: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_67c:
	/* 0x67c: mov    edx,0x2c0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 704ULL);
x86_l_681:
	/* 0x681: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_686:
	/* 0x686: jns    602 <event_execve+0x602> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x686, 0x602, x86_l_602);
x86_l_68c:
	/* 0x68c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_68f:
	/* 0x68f: jns    6aa <event_execve+0x6aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x68f, 0x6aa, x86_l_6aa);
x86_l_691:
	/* 0x691: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_694:
	/* 0x694: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_698:
	/* 0x698: cmp    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_69e:
	/* 0x69e: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_6a3:
	/* 0x6a3: jne    703 <event_execve+0x703> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6a3, 0x703, x86_l_703);
x86_l_6a5:
	/* 0x6a5: jmp    a62 <event_execve+0xa62> */
	X86_SIM_X86_JMP(0x6a5, 0xa62, x86_l_a62);
x86_l_6aa:
	/* 0x6aa: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b2:
	/* 0x6b2: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_6b9:
	/* 0x6b9: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_6bb:
	/* 0x6bb: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6c0:
	/* 0x6c0: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_6c7:
	/* 0x6c7: movabs rax,0x400000048 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869256ULL);
x86_l_6d1:
	/* 0x6d1: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_6d6:
	/* 0x6d6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_6dd:
	/* 0x6dd: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6e2:
	/* 0x6e2: call   6e7 <event_execve+0x6e7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6e7:
	/* 0x6e7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ea:
	/* 0x6ea: je     821 <event_execve+0x821> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ea, 0x821, x86_l_821);
x86_l_6f0:
	/* 0x6f0: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6f2:
	/* 0x6f2: cmp    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_6f8:
	/* 0x6f8: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_6fd:
	/* 0x6fd: je     a62 <event_execve+0xa62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6fd, 0xa62, x86_l_a62);
x86_l_703:
	/* 0x703: cmp    QWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_708:
	/* 0x708: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_70d:
	/* 0x70d: je     a62 <event_execve+0xa62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70d, 0xa62, x86_l_a62);
x86_l_713:
	/* 0x713: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_heap));
x86_l_71a:
	/* 0x71a: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_71f:
	/* 0x71f: call   724 <event_execve+0x724> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_724:
	/* 0x724: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_729:
	/* 0x729: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_72c:
	/* 0x72c: je     a62 <event_execve+0xa62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x72c, 0xa62, x86_l_a62);
x86_l_732:
	/* 0x732: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_735:
	/* 0x735: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_73a:
	/* 0x73a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_73d:
	/* 0x73d: js     857 <event_execve+0x857> */
	X86_SIM_X86_JCC(X86_CC_S, 0x73d, 0x857, x86_l_857);
x86_l_743:
	/* 0x743: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_748:
	/* 0x748: call   74d <event_execve+0x74d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_74d:
	/* 0x74d: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_752:
	/* 0x752: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_755:
	/* 0x755: js     a62 <event_execve+0xa62> */
	X86_SIM_X86_JCC(X86_CC_S, 0x755, 0xa62, x86_l_a62);
x86_l_75b:
	/* 0x75b: add    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_760:
	/* 0x760: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_765:
	/* 0x765: mov    ecx,DWORD PTR [r14+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_76c:
	/* 0x76c: and    ecx,0x1ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 511ULL);
x86_l_772:
	/* 0x772: lea    rsi,[r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_776:
	/* 0x776: add    rsi,0x140 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 320ULL);
x86_l_77d:
	/* 0x77d: mov    DWORD PTR [r14+0x184c],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6220ULL);
x86_l_784:
	/* 0x784: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_788:
	/* 0x788: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_78b:
	/* 0x78b: sub    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_78e:
	/* 0x78e: cmp    rcx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 1023ULL);
x86_l_795:
	/* 0x795: ja     884 <event_execve+0x884> */
	X86_SIM_X86_JCC(X86_CC_A, 0x795, 0x884, x86_l_884);
x86_l_79b:
	/* 0x79b: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_79e:
	/* 0x79e: sub    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_7a1:
	/* 0x7a1: add    rdi,0x400 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1024ULL);
x86_l_7a8:
	/* 0x7a8: cmp    rcx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_7ab:
	/* 0x7ab: jae    884 <event_execve+0x884> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x7ab, 0x884, x86_l_884);
x86_l_7b1:
	/* 0x7b1: dec    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_7b3:
	/* 0x7b3: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_7b9:
	/* 0x7b9: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7bb:
	/* 0x7bb: cmp    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7be:
	/* 0x7be: je     7c2 <event_execve+0x7c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7be, 0x7c2, x86_l_7c2);
x86_l_7c0:
	/* 0x7c0: mov    ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7c2:
	/* 0x7c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c5:
	/* 0x7c5: js     8bd <event_execve+0x8bd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7c5, 0x8bd, x86_l_8bd);
x86_l_7cb:
	/* 0x7cb: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_7ce:
	/* 0x7ce: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7d1:
	/* 0x7d1: mov    esi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_7d3:
	/* 0x7d3: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d6:
	/* 0x7d6: call   7db <event_execve+0x7db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_7db:
	/* 0x7db: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7de:
	/* 0x7de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e1:
	/* 0x7e1: jne    9b2 <event_execve+0x9b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7e1, 0x9b2, x86_l_9b2);
x86_l_7e7:
	/* 0x7e7: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7ea:
	/* 0x7ea: jmp    a53 <event_execve+0xa53> */
	X86_SIM_X86_JMP(0x7ea, 0xa53, x86_l_a53);
x86_l_7ef:
	/* 0x7ef: mov    DWORD PTR [rsp],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_7f6:
	/* 0x7f6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_7fd:
	/* 0x7fd: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_802:
	/* 0x802: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_805:
	/* 0x805: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_807:
	/* 0x807: call   80c <event_execve+0x80c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_80c:
	/* 0x80c: mov    edx,0x2c0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 704ULL);
x86_l_811:
	/* 0x811: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_816:
	/* 0x816: js     68c <event_execve+0x68c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x816, 0x68c, x86_l_68c);
x86_l_81c:
	/* 0x81c: jmp    602 <event_execve+0x602> */
	X86_SIM_X86_JMP(0x81c, 0x602, x86_l_602);
x86_l_821:
	/* 0x821: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
x86_l_829:
	/* 0x829: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_830:
	/* 0x830: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_835:
	/* 0x835: lea    rdx,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_83a:
	/* 0x83a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_83c:
	/* 0x83c: call   841 <event_execve+0x841> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_841:
	/* 0x841: cmp    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_847:
	/* 0x847: mov    ebx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_84c:
	/* 0x84c: jne    703 <event_execve+0x703> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x84c, 0x703, x86_l_703);
x86_l_852:
	/* 0x852: jmp    a62 <event_execve+0xa62> */
	X86_SIM_X86_JMP(0x852, 0xa62, x86_l_a62);
x86_l_857:
	/* 0x857: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_85a:
	/* 0x85a: jns    8a3 <event_execve+0x8a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x85a, 0x8a3, x86_l_8a3);
x86_l_85c:
	/* 0x85c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85e:
	/* 0x85e: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_865:
	/* 0x865: je     909 <event_execve+0x909> */
	X86_SIM_X86_JCC(X86_CC_E, 0x865, 0x909, x86_l_909);
x86_l_86b:
	/* 0x86b: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_86f:
	/* 0x86f: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_873:
	/* 0x873: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_877:
	/* 0x877: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_87a:
	/* 0x87a: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_87d:
	/* 0x87d: jne    85e <event_execve+0x85e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x87d, 0x85e, x86_l_85e);
x86_l_87f:
	/* 0x87f: jmp    75b <event_execve+0x75b> */
	X86_SIM_X86_JMP(0x87f, 0x75b, x86_l_75b);
x86_l_884:
	/* 0x884: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_887:
	/* 0x887: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88a:
	/* 0x88a: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_l_229b, 0x88fULL);
x86_l_88f:
	/* 0x88f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_892:
	/* 0x892: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_894:
	/* 0x894: je     8b6 <event_execve+0x8b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x894, 0x8b6, x86_l_8b6);
x86_l_896:
	/* 0x896: or     BYTE PTR [r14+0x15f],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 1507533520897ULL);
x86_l_89e:
	/* 0x89e: jmp    a53 <event_execve+0xa53> */
	X86_SIM_X86_JMP(0x89e, 0xa53, x86_l_a53);
x86_l_8a3:
	/* 0x8a3: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8a5:
	/* 0x8a5: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_8aa:
	/* 0x8aa: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8ac:
	/* 0x8ac: call   8b1 <event_execve+0x8b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_8b1:
	/* 0x8b1: jmp    a62 <event_execve+0xa62> */
	X86_SIM_X86_JMP(0x8b1, 0xa62, x86_l_a62);
x86_l_8b6:
	/* 0x8b6: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8b8:
	/* 0x8b8: jmp    a53 <event_execve+0xa53> */
	X86_SIM_X86_JMP(0x8b8, 0xa53, x86_l_a53);
x86_l_8bd:
	/* 0x8bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c0:
	/* 0x8c0: jns    99c <event_execve+0x99c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c0, 0x99c, x86_l_99c);
x86_l_8c6:
	/* 0x8c6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8c8:
	/* 0x8c8: cmp    ebx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_8cb:
	/* 0x8cb: jb     8e9 <event_execve+0x8e9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8cb, 0x8e9, x86_l_8e9);
x86_l_8cd:
	/* 0x8cd: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_8cf:
	/* 0x8cf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d1:
	/* 0x8d1: mov    r8,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_8d4:
	/* 0x8d4: mov    rdx,QWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_8d8:
	/* 0x8d8: mov    QWORD PTR [rsi+r8*1],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_8dc:
	/* 0x8dc: lea    rdx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8e0:
	/* 0x8e0: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_8e4:
	/* 0x8e4: cmp    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8e7:
	/* 0x8e7: jbe    8d1 <event_execve+0x8d1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x8e7, 0x8d1, x86_l_8d1);
x86_l_8e9:
	/* 0x8e9: test   bl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_8ec:
	/* 0x8ec: jne    a1e <event_execve+0xa1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8ec, 0xa1e, x86_l_a1e);
x86_l_8f2:
	/* 0x8f2: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_8f5:
	/* 0x8f5: jne    a34 <event_execve+0xa34> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8f5, 0xa34, x86_l_a34);
x86_l_8fb:
	/* 0x8fb: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_8fe:
	/* 0x8fe: jne    a48 <event_execve+0xa48> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8fe, 0xa48, x86_l_a48);
x86_l_904:
	/* 0x904: jmp    a53 <event_execve+0xa53> */
	X86_SIM_X86_JMP(0x904, 0xa53, x86_l_a53);
x86_l_909:
	/* 0x909: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_910:
	/* 0x910: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_915:
	/* 0x915: jmp    75b <event_execve+0x75b> */
	X86_SIM_X86_JMP(0x915, 0x75b, x86_l_75b);
x86_l_91a:
	/* 0x91a: mov    ebp,0x3ff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1023ULL);
x86_l_91f:
	/* 0x91f: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_922:
	/* 0x922: mov    eax,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_925:
	/* 0x925: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_929:
	/* 0x929: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_930:
	/* 0x930: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_935:
	/* 0x935: call   93a <event_execve+0x93a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_93a:
	/* 0x93a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_93d:
	/* 0x93d: je     979 <event_execve+0x979> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93d, 0x979, x86_l_979);
x86_l_93f:
	/* 0x93f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_942:
	/* 0x942: lea    rsi,[rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_946:
	/* 0x946: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_mbset_map));
x86_l_94d:
	/* 0x94d: call   952 <event_execve+0x952> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_952:
	/* 0x952: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_955:
	/* 0x955: je     967 <event_execve+0x967> */
	X86_SIM_X86_JCC(X86_CC_E, 0x955, 0x967, x86_l_967);
x86_l_957:
	/* 0x957: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95a:
	/* 0x95a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_95d:
	/* 0x95d: je     967 <event_execve+0x967> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95d, 0x967, x86_l_967);
x86_l_95f:
	/* 0x95f: lock or QWORD PTR [rbx+0x370],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RBX, X86_RAX, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 880ULL);
x86_l_967:
	/* 0x967: sub    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SUB, 1ULL);
x86_l_96a:
	/* 0x96a: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_96d:
	/* 0x96d: cmp    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_970:
	/* 0x970: je     979 <event_execve+0x979> */
	X86_SIM_X86_JCC(X86_CC_E, 0x970, 0x979, x86_l_979);
x86_l_972:
	/* 0x972: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_975:
	/* 0x975: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_977:
	/* 0x977: je     922 <event_execve+0x922> */
	X86_SIM_X86_JCC(X86_CC_E, 0x977, 0x922, x86_l_922);
x86_l_979:
	/* 0x979: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_981:
	/* 0x981: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_984:
	/* 0x984: mov    QWORD PTR [rbx+0x378],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 888ULL);
x86_l_98b:
	/* 0x98b: mov    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_990:
	/* 0x990: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_992:
	/* 0x992: mov    rbx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_997:
	/* 0x997: jmp    2c4 <event_execve+0x2c4> */
	X86_SIM_X86_JMP(0x997, 0x2c4, x86_l_2c4);
x86_l_99c:
	/* 0x99c: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_99f:
	/* 0x99f: mov    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_9a1:
	/* 0x9a1: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_9a4:
	/* 0x9a4: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9a6:
	/* 0x9a6: call   9ab <event_execve+0x9ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_9ab:
	/* 0x9ab: mov    rbx,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_9b2:
	/* 0x9b2: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_9b4:
	/* 0x9b4: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_9b6:
	/* 0x9b6: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9bb:
	/* 0x9bb: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_9c2:
	/* 0x9c2: movabs rax,0x40000006c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869292ULL);
x86_l_9cc:
	/* 0x9cc: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_9d1:
	/* 0x9d1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_9d8:
	/* 0x9d8: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9dd:
	/* 0x9dd: call   9e2 <event_execve+0x9e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9e2:
	/* 0x9e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9e5:
	/* 0x9e5: je     9eb <event_execve+0x9eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e5, 0x9eb, x86_l_9eb);
x86_l_9e7:
	/* 0x9e7: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_9e9:
	/* 0x9e9: jmp    a0b <event_execve+0xa0b> */
	X86_SIM_X86_JMP(0x9e9, 0xa0b, x86_l_a0b);
x86_l_9eb:
	/* 0x9eb: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
x86_l_9f3:
	/* 0x9f3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_9fa:
	/* 0x9fa: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9ff:
	/* 0x9ff: lea    rdx,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a04:
	/* 0xa04: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a06:
	/* 0xa06: call   a0b <event_execve+0xa0b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_a0b:
	/* 0xa0b: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_a0d:
	/* 0xa0d: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a10:
	/* 0xa10: jns    a53 <event_execve+0xa53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa10, 0xa53, x86_l_a53);
x86_l_a12:
	/* 0xa12: or     BYTE PTR [r14+0x15d],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 1498943586306ULL);
x86_l_a1a:
	/* 0xa1a: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a1c:
	/* 0xa1c: jmp    a53 <event_execve+0xa53> */
	X86_SIM_X86_JMP(0xa1c, 0xa53, x86_l_a53);
x86_l_a1e:
	/* 0xa1e: mov    edi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_a20:
	/* 0xa20: mov    r8d,DWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_a24:
	/* 0xa24: mov    DWORD PTR [rsi+rdi*1],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_a28:
	/* 0xa28: or     edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_a2b:
	/* 0xa2b: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_a2e:
	/* 0xa2e: je     8fb <event_execve+0x8fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa2e, 0x8fb, x86_l_8fb);
x86_l_a34:
	/* 0xa34: mov    edi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_a36:
	/* 0xa36: movzx  r8d,WORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDI, 0, X86_WIDTH_16), 0ULL);
x86_l_a3b:
	/* 0xa3b: mov    WORD PTR [rsi+rdi*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_a40:
	/* 0xa40: add    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_a43:
	/* 0xa43: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a46:
	/* 0xa46: je     a53 <event_execve+0xa53> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa46, 0xa53, x86_l_a53);
x86_l_a48:
	/* 0xa48: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_a4a:
	/* 0xa4a: movzx  eax,BYTE PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_a4e:
	/* 0xa4e: mov    BYTE PTR [rsi+rdx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_a51:
	/* 0xa51: mov    ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a53:
	/* 0xa53: mov    DWORD PTR [r14+0x1848],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6216ULL);
x86_l_a5a:
	/* 0xa5a: mov    WORD PTR [r14+0x17a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 378ULL);
x86_l_a62:
	/* 0xa62: add    ebx,DWORD PTR [r14+0x140] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBX, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 320ULL);
x86_l_a69:
	/* 0xa69: mov    DWORD PTR [r14+0x140],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_a70:
	/* 0xa70: test   BYTE PTR [r14+0x15d],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1498943586336ULL);
x86_l_a78:
	/* 0xa78: jne    12b5 <event_execve+0x12b5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa78, 0x12b5, x86_l_12b5);
x86_l_a7e:
	/* 0xa7e: mov    QWORD PTR [rsp+0x88],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_a86:
	/* 0xa86: mov    ebx,DWORD PTR [r14+0x144] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 324ULL);
x86_l_a8d:
	/* 0xa8d: call   a92 <event_execve+0xa92> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_a92:
	/* 0xa92: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a95:
	/* 0xa95: je     b33 <event_execve+0xb33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa95, 0xb33, x86_l_b33);
x86_l_a9b:
	/* 0xa9b: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_aa2:
	/* 0xaa2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aa4:
	/* 0xaa4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_aa7:
	/* 0xaa7: jns    afb <event_execve+0xafb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaa7, 0xafb, x86_l_afb);
x86_l_aa9:
	/* 0xaa9: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aab:
	/* 0xaab: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_aad:
	/* 0xaad: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_aaf:
	/* 0xaaf: je     b01 <event_execve+0xb01> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaaf, 0xb01, x86_l_b01);
x86_l_ab1:
	/* 0xab1: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_ab7:
	/* 0xab7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aba:
	/* 0xaba: jns    bb9 <event_execve+0xbb9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaba, 0xbb9, x86_l_bb9);
x86_l_ac0:
	/* 0xac0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ac3:
	/* 0xac3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac5:
	/* 0xac5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac8:
	/* 0xac8: je     bc6 <event_execve+0xbc6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac8, 0xbc6, x86_l_bc6);
x86_l_ace:
	/* 0xace: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_ad5:
	/* 0xad5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ad8:
	/* 0xad8: jns    adc <event_execve+0xadc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xad8, 0xadc, x86_l_adc);
x86_l_ada:
	/* 0xada: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_adc:
	/* 0xadc: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_ade:
	/* 0xade: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xade, 0x219c, x86_l_219c);
x86_l_ae4:
	/* 0xae4: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_aea:
	/* 0xaea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aed:
	/* 0xaed: jns    1bd2 <event_execve+0x1bd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaed, 0x1bd2, x86_l_1bd2);
x86_l_af3:
	/* 0xaf3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af6:
	/* 0xaf6: jmp    1bd4 <event_execve+0x1bd4> */
	X86_SIM_X86_JMP(0xaf6, 0x1bd4, x86_l_1bd4);
x86_l_afb:
	/* 0xafb: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_afd:
	/* 0xafd: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_aff:
	/* 0xaff: jne    ab1 <event_execve+0xab1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaff, 0xab1, x86_l_ab1);
x86_l_b01:
	/* 0xb01: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_b03:
	/* 0xb03: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb03, 0xb3b, x86_l_b3b);
x86_l_b05:
	/* 0xb05: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b07:
	/* 0xb07: add    rax,0xd50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3408ULL);
x86_l_b0d:
	/* 0xb0d: js     b43 <event_execve+0xb43> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb0d, 0xb43, x86_l_b43);
x86_l_b0f:
	/* 0xb0f: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_b17:
	/* 0xb17: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b1c:
	/* 0xb1c: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1f:
	/* 0xb1f: call   b24 <event_execve+0xb24> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b24:
	/* 0xb24: mov    rbp,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_b2c:
	/* 0xb2c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b2f:
	/* 0xb2f: jne    b58 <event_execve+0xb58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb2f, 0xb58, x86_l_b58);
x86_l_b31:
	/* 0xb31: jmp    baa <event_execve+0xbaa> */
	X86_SIM_X86_JMP(0xb31, 0xbaa, x86_l_baa);
x86_l_b33:
	/* 0xb33: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b35:
	/* 0xb35: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b37:
	/* 0xb37: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_b39:
	/* 0xb39: jne    b05 <event_execve+0xb05> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb39, 0xb05, x86_l_b05);
x86_l_b3b:
	/* 0xb3b: add    rax,0xd50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3408ULL);
x86_l_b41:
	/* 0xb41: jns    b0f <event_execve+0xb0f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb41, 0xb0f, x86_l_b0f);
x86_l_b43:
	/* 0xb43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b46:
	/* 0xb46: jns    b9e <event_execve+0xb9e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb46, 0xb9e, x86_l_b9e);
x86_l_b48:
	/* 0xb48: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b4b:
	/* 0xb4b: mov    QWORD PTR [rsp+0x90],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_b53:
	/* 0xb53: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b56:
	/* 0xb56: je     baa <event_execve+0xbaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb56, 0xbaa, x86_l_baa);
x86_l_b58:
	/* 0xb58: mov    DWORD PTR [rsp+0xa4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_b63:
	/* 0xb63: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)buffer_heap_map));
x86_l_b6a:
	/* 0xb6a: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_b72:
	/* 0xb72: call   b77 <event_execve+0xb77> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b77:
	/* 0xb77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b7a:
	/* 0xb7a: je     bb2 <event_execve+0xbb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb7a, 0xbb2, x86_l_bb2);
x86_l_b7c:
	/* 0xb7c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b7f:
	/* 0xb7f: call   b84 <event_execve+0xb84> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_b84:
	/* 0xb84: add    rax,0xd50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3408ULL);
x86_l_b8a:
	/* 0xb8a: jns    bd7 <event_execve+0xbd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb8a, 0xbd7, x86_l_bd7);
x86_l_b8c:
	/* 0xb8c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8f:
	/* 0xb8f: jns    bf6 <event_execve+0xbf6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb8f, 0xbf6, x86_l_bf6);
x86_l_b91:
	/* 0xb91: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b94:
	/* 0xb94: mov    QWORD PTR [rsp+0x98],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_b9c:
	/* 0xb9c: jmp    c05 <event_execve+0xc05> */
	X86_SIM_X86_JMP(0xb9c, 0xc05, x86_l_c05);
x86_l_b9e:
	/* 0xb9e: mov    QWORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_baa:
	/* 0xbaa: or     BYTE PTR [r14+0x15d],0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 1498943586336ULL);
x86_l_bb2:
	/* 0xbb2: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bb4:
	/* 0xbb4: jmp    12b1 <event_execve+0x12b1> */
	X86_SIM_X86_JMP(0xbb4, 0x12b1, x86_l_12b1);
x86_l_bb9:
	/* 0xbb9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bbb:
	/* 0xbbb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bbd:
	/* 0xbbd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc0:
	/* 0xbc0: jne    ace <event_execve+0xace> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbc0, 0xace, x86_l_ace);
x86_l_bc6:
	/* 0xbc6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bc8:
	/* 0xbc8: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_bca:
	/* 0xbca: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_bcc:
	/* 0xbcc: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbcc, 0xb3b, x86_l_b3b);
x86_l_bd2:
	/* 0xbd2: jmp    b05 <event_execve+0xb05> */
	X86_SIM_X86_JMP(0xbd2, 0xb05, x86_l_b05);
x86_l_bd7:
	/* 0xbd7: lea    rdi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_bdf:
	/* 0xbdf: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_be4:
	/* 0xbe4: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be7:
	/* 0xbe7: call   bec <event_execve+0xbec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_bec:
	/* 0xbec: mov    r15,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_bf4:
	/* 0xbf4: jmp    c05 <event_execve+0xc05> */
	X86_SIM_X86_JMP(0xbf4, 0xc05, x86_l_c05);
x86_l_bf6:
	/* 0xbf6: mov    QWORD PTR [rsp+0x98],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 652835028992ULL);
x86_l_c02:
	/* 0xc02: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c05:
	/* 0xc05: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c08:
	/* 0xc08: add    rcx,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_c0c:
	/* 0xc0c: mov    QWORD PTR [rsp+0x60],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_c11:
	/* 0xc11: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c19:
	/* 0xc19: jns    c3d <event_execve+0xc3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc19, 0xc3d, x86_l_c3d);
x86_l_c1b:
	/* 0xc1b: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c1e:
	/* 0xc1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c21:
	/* 0xc21: jns    c6e <event_execve+0xc6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc21, 0xc6e, x86_l_c6e);
x86_l_c23:
	/* 0xc23: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c26:
	/* 0xc26: mov    QWORD PTR [rsp+0x78],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c2b:
	/* 0xc2b: lea    rbx,[r13+0x1000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_c32:
	/* 0xc32: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c35:
	/* 0xc35: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c39:
	/* 0xc39: js     c64 <event_execve+0xc64> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc39, 0xc64, x86_l_c64);
x86_l_c3b:
	/* 0xc3b: jmp    c8a <event_execve+0xc8a> */
	X86_SIM_X86_JMP(0xc3b, 0xc8a, x86_l_c8a);
x86_l_c3d:
	/* 0xc3d: lea    rdi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c42:
	/* 0xc42: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_c47:
	/* 0xc47: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c4a:
	/* 0xc4a: call   c4f <event_execve+0xc4f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_c4f:
	/* 0xc4f: mov    r12,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c54:
	/* 0xc54: lea    rbx,[r13+0x1000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_c5b:
	/* 0xc5b: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c5e:
	/* 0xc5e: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c62:
	/* 0xc62: jns    c8a <event_execve+0xc8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc62, 0xc8a, x86_l_c8a);
x86_l_c64:
	/* 0xc64: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c67:
	/* 0xc67: jns    ca8 <event_execve+0xca8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc67, 0xca8, x86_l_ca8);
x86_l_c69:
	/* 0xc69: mov    rcx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c6c:
	/* 0xc6c: jmp    c9e <event_execve+0xc9e> */
	X86_SIM_X86_JMP(0xc6c, 0xc9e, x86_l_c9e);
x86_l_c6e:
	/* 0xc6e: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_c77:
	/* 0xc77: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c7a:
	/* 0xc7a: lea    rbx,[r13+0x1000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_c81:
	/* 0xc81: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c84:
	/* 0xc84: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c88:
	/* 0xc88: js     c64 <event_execve+0xc64> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc88, 0xc64, x86_l_c64);
x86_l_c8a:
	/* 0xc8a: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c8f:
	/* 0xc8f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_c94:
	/* 0xc94: call   c99 <event_execve+0xc99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_c99:
	/* 0xc99: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c9e:
	/* 0xc9e: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_ca3:
	/* 0xca3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ca6:
	/* 0xca6: jne    d0c <event_execve+0xd0c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xca6, 0xd0c, x86_l_d0c);
x86_l_ca8:
	/* 0xca8: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cab:
	/* 0xcab: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_caf:
	/* 0xcaf: jns    cc9 <event_execve+0xcc9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcaf, 0xcc9, x86_l_cc9);
x86_l_cb1:
	/* 0xcb1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cb4:
	/* 0xcb4: jns    1c27 <event_execve+0x1c27> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcb4, 0x1c27, x86_l_1c27);
x86_l_cba:
	/* 0xcba: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cbd:
	/* 0xcbd: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cc0:
	/* 0xcc0: jne    ce2 <event_execve+0xce2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcc0, 0xce2, x86_l_ce2);
x86_l_cc2:
	/* 0xcc2: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_cc7:
	/* 0xcc7: jmp    d0c <event_execve+0xd0c> */
	X86_SIM_X86_JMP(0xcc7, 0xd0c, x86_l_d0c);
x86_l_cc9:
	/* 0xcc9: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_cce:
	/* 0xcce: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_cd3:
	/* 0xcd3: call   cd8 <event_execve+0xcd8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_cd8:
	/* 0xcd8: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_cdd:
	/* 0xcdd: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ce0:
	/* 0xce0: je     cc2 <event_execve+0xcc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xce0, 0xcc2, x86_l_cc2);
x86_l_ce2:
	/* 0xce2: mov    rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_ce5:
	/* 0xce5: add    rbx,0xff6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4086ULL);
x86_l_cec:
	/* 0xcec: movabs rax,0x6574656c65642820 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310579611361093664ULL);
x86_l_cf6:
	/* 0xcf6: mov    QWORD PTR [r13+0xff6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4086ULL);
x86_l_cfd:
	/* 0xcfd: mov    WORD PTR [r13+0xffe],0x2964 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 17583596120420ULL);
x86_l_d07:
	/* 0xd07: mov    eax,0xff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4086ULL);
x86_l_d0c:
	/* 0xd0c: mov    r12,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d11:
	/* 0xd11: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_d1a:
	/* 0xd1a: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_d23:
	/* 0xd23: mov    QWORD PTR [rsp+0x30],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d28:
	/* 0xd28: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_d31:
	/* 0xd31: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_d3a:
	/* 0xd3a: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_d43:
	/* 0xd43: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_d48:
	/* 0xd48: lea    r13,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d4c:
	/* 0xd4c: mov    DWORD PTR [rsp+0x58],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d50:
	/* 0xd50: mov    BYTE PTR [rsp+0x5c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
x86_l_d55:
	/* 0xd55: add    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_d59:
	/* 0xd59: mov    QWORD PTR [rsp+0xb0],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_d61:
	/* 0xd61: jns    d77 <event_execve+0xd77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd61, 0xd77, x86_l_d77);
x86_l_d63:
	/* 0xd63: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d66:
	/* 0xd66: jns    d9e <event_execve+0xd9e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd66, 0xd9e, x86_l_d9e);
x86_l_d68:
	/* 0xd68: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d6b:
	/* 0xd6b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d70:
	/* 0xd70: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d73:
	/* 0xd73: js     d8e <event_execve+0xd8e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd73, 0xd8e, x86_l_d8e);
x86_l_d75:
	/* 0xd75: jmp    dac <event_execve+0xdac> */
	X86_SIM_X86_JMP(0xd75, 0xdac, x86_l_dac);
x86_l_d77:
	/* 0xd77: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d7c:
	/* 0xd7c: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_d81:
	/* 0xd81: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d84:
	/* 0xd84: call   d89 <event_execve+0xd89> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d89:
	/* 0xd89: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d8c:
	/* 0xd8c: jns    dac <event_execve+0xdac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd8c, 0xdac, x86_l_dac);
x86_l_d8e:
	/* 0xd8e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d91:
	/* 0xd91: jns    dc0 <event_execve+0xdc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd91, 0xdc0, x86_l_dc0);
x86_l_d93:
	/* 0xd93: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d97:
	/* 0xd97: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d9c:
	/* 0xd9c: jmp    dc9 <event_execve+0xdc9> */
	X86_SIM_X86_JMP(0xd9c, 0xdc9, x86_l_dc9);
x86_l_d9e:
	/* 0xd9e: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_da7:
	/* 0xda7: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_daa:
	/* 0xdaa: js     d8e <event_execve+0xd8e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdaa, 0xd8e, x86_l_d8e);
x86_l_dac:
	/* 0xdac: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_db1:
	/* 0xdb1: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_db6:
	/* 0xdb6: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_db9:
	/* 0xdb9: call   dbe <event_execve+0xdbe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_dbe:
	/* 0xdbe: jmp    dc9 <event_execve+0xdc9> */
	X86_SIM_X86_JMP(0xdbe, 0xdc9, x86_l_dc9);
x86_l_dc0:
	/* 0xdc0: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_dc9:
	/* 0xdc9: mov    rdx,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_dd1:
	/* 0xdd1: add    rbp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_dd5:
	/* 0xdd5: lea    rdi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_dda:
	/* 0xdda: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ddd:
	/* 0xddd: jns    df3 <event_execve+0xdf3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xddd, 0xdf3, x86_l_df3);
x86_l_ddf:
	/* 0xddf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_de2:
	/* 0xde2: jns    e12 <event_execve+0xe12> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde2, 0xe12, x86_l_e12);
x86_l_de4:
	/* 0xde4: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de7:
	/* 0xde7: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_dec:
	/* 0xdec: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_def:
	/* 0xdef: js     e02 <event_execve+0xe02> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdef, 0xe02, x86_l_e02);
x86_l_df1:
	/* 0xdf1: jmp    e20 <event_execve+0xe20> */
	X86_SIM_X86_JMP(0xdf1, 0xe20, x86_l_e20);
x86_l_df3:
	/* 0xdf3: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_df8:
	/* 0xdf8: call   dfd <event_execve+0xdfd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_dfd:
	/* 0xdfd: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e00:
	/* 0xe00: jns    e20 <event_execve+0xe20> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe00, 0xe20, x86_l_e20);
x86_l_e02:
	/* 0xe02: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e05:
	/* 0xe05: jns    e39 <event_execve+0xe39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe05, 0xe39, x86_l_e39);
x86_l_e07:
	/* 0xe07: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e0b:
	/* 0xe0b: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e10:
	/* 0xe10: jmp    e44 <event_execve+0xe44> */
	X86_SIM_X86_JMP(0xe10, 0xe44, x86_l_e44);
x86_l_e12:
	/* 0xe12: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_e1b:
	/* 0xe1b: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e1e:
	/* 0xe1e: js     e02 <event_execve+0xe02> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe1e, 0xe02, x86_l_e02);
x86_l_e20:
	/* 0xe20: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e25:
	/* 0xe25: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e2a:
	/* 0xe2a: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e2d:
	/* 0xe2d: call   e32 <event_execve+0xe32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e32:
	/* 0xe32: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e37:
	/* 0xe37: jmp    e44 <event_execve+0xe44> */
	X86_SIM_X86_JMP(0xe37, 0xe44, x86_l_e44);
x86_l_e39:
	/* 0xe39: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_e42:
	/* 0xe42: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e44:
	/* 0xe44: add    rax,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_e48:
	/* 0xe48: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_e4d:
	/* 0xe4d: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_e54:
	/* 0xe54: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e57:
	/* 0xe57: je     1193 <event_execve+0x1193> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe57, 0x1193, x86_l_1193);
x86_l_e5d:
	/* 0xe5d: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e5f:
	/* 0xe5f: jmp    e93 <event_execve+0xe93> */
	X86_SIM_X86_JMP(0xe5f, 0xe93, x86_l_e93);
x86_l_e61:
	/* 0xe61: lea    rdi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_e66:
	/* 0xe66: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e6b:
	/* 0xe6b: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e6e:
	/* 0xe6e: call   e73 <event_execve+0xe73> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e73:
	/* 0xe73: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e77:
	/* 0xe77: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_e7c:
	/* 0xe7c: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_e80:
	/* 0xe80: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e85:
	/* 0xe85: inc    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_e87:
	/* 0xe87: cmp    ebp,0x800 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_e8d:
	/* 0xe8d: je     11cd <event_execve+0x11cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8d, 0x11cd, x86_l_11cd);
x86_l_e93:
	/* 0xe93: mov    r15,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_e98:
	/* 0xe98: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e9d:
	/* 0xe9d: mov    rbx,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_ea2:
	/* 0xea2: cmp    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_ea7:
	/* 0xea7: jne    eb4 <event_execve+0xeb4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xea7, 0xeb4, x86_l_eb4);
x86_l_ea9:
	/* 0xea9: cmp    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_eae:
	/* 0xeae: je     11c3 <event_execve+0x11c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeae, 0x11c3, x86_l_11c3);
x86_l_eb4:
	/* 0xeb4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_eb7:
	/* 0xeb7: jns    ed0 <event_execve+0xed0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeb7, 0xed0, x86_l_ed0);
x86_l_eb9:
	/* 0xeb9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ebc:
	/* 0xebc: jns    eee <event_execve+0xeee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xebc, 0xeee, x86_l_eee);
x86_l_ebe:
	/* 0xebe: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ec1:
	/* 0xec1: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ec6:
	/* 0xec6: cmp    r15,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ec9:
	/* 0xec9: jne    f02 <event_execve+0xf02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xec9, 0xf02, x86_l_f02);
x86_l_ecb:
	/* 0xecb: jmp    f90 <event_execve+0xf90> */
	X86_SIM_X86_JMP(0xecb, 0xf90, x86_l_f90);
x86_l_ed0:
	/* 0xed0: lea    rdi,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ed5:
	/* 0xed5: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_eda:
	/* 0xeda: call   edf <event_execve+0xedf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_edf:
	/* 0xedf: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ee4:
	/* 0xee4: cmp    r15,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ee7:
	/* 0xee7: jne    f02 <event_execve+0xf02> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xee7, 0xf02, x86_l_f02);
x86_l_ee9:
	/* 0xee9: jmp    f90 <event_execve+0xf90> */
	X86_SIM_X86_JMP(0xee9, 0xf90, x86_l_f90);
x86_l_eee:
	/* 0xeee: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_ef7:
	/* 0xef7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef9:
	/* 0xef9: cmp    r15,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_efc:
	/* 0xefc: je     f90 <event_execve+0xf90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xefc, 0xf90, x86_l_f90);
x86_l_f02:
	/* 0xf02: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f05:
	/* 0xf05: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f09:
	/* 0xf09: jns    f1d <event_execve+0xf1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf09, 0xf1d, x86_l_f1d);
x86_l_f0b:
	/* 0xf0b: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f0e:
	/* 0xf0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f11:
	/* 0xf11: jns    f6e <event_execve+0xf6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf11, 0xf6e, x86_l_f6e);
x86_l_f13:
	/* 0xf13: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f16:
	/* 0xf16: cmp    r15,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f19:
	/* 0xf19: jne    f73 <event_execve+0xf73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf19, 0xf73, x86_l_f73);
x86_l_f1b:
	/* 0xf1b: jmp    f90 <event_execve+0xf90> */
	X86_SIM_X86_JMP(0xf1b, 0xf90, x86_l_f90);
x86_l_f1d:
	/* 0xf1d: mov    rdi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_f20:
	/* 0xf20: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_f25:
	/* 0xf25: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f28:
	/* 0xf28: call   f2d <event_execve+0xf2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f2d:
	/* 0xf2d: cmp    QWORD PTR [rsp],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f31:
	/* 0xf31: je     f90 <event_execve+0xf90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf31, 0xf90, x86_l_f90);
x86_l_f33:
	/* 0xf33: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f38:
	/* 0xf38: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_f3d:
	/* 0xf3d: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f40:
	/* 0xf40: call   f45 <event_execve+0xf45> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f45:
	/* 0xf45: add    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_f49:
	/* 0xf49: jns    1036 <event_execve+0x1036> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf49, 0x1036, x86_l_1036);
x86_l_f4f:
	/* 0xf4f: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f52:
	/* 0xf52: jns    100d <event_execve+0x100d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf52, 0x100d, x86_l_100d);
x86_l_f58:
	/* 0xf58: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f5b:
	/* 0xf5b: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f60:
	/* 0xf60: mov    rdx,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f64:
	/* 0xf64: mov    QWORD PTR [rsp+0x18],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f69:
	/* 0xf69: jmp    104d <event_execve+0x104d> */
	X86_SIM_X86_JMP(0xf69, 0x104d, x86_l_104d);
x86_l_f6e:
	/* 0xf6e: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f71:
	/* 0xf71: je     f90 <event_execve+0xf90> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf71, 0xf90, x86_l_f90);
x86_l_f73:
	/* 0xf73: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f76:
	/* 0xf76: jns    1023 <event_execve+0x1023> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf76, 0x1023, x86_l_1023);
x86_l_f7c:
	/* 0xf7c: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f80:
	/* 0xf80: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f85:
	/* 0xf85: add    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_f89:
	/* 0xf89: js     f4f <event_execve+0xf4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf89, 0xf4f, x86_l_f4f);
x86_l_f8b:
	/* 0xf8b: jmp    1036 <event_execve+0x1036> */
	X86_SIM_X86_JMP(0xf8b, 0x1036, x86_l_1036);
x86_l_f90:
	/* 0xf90: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f93:
	/* 0xf93: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_f97:
	/* 0xf97: jns    fb1 <event_execve+0xfb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf97, 0xfb1, x86_l_fb1);
x86_l_f99:
	/* 0xf99: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f9c:
	/* 0xf9c: jns    fce <event_execve+0xfce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf9c, 0xfce, x86_l_fce);
x86_l_f9e:
	/* 0xf9e: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fa1:
	/* 0xfa1: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fa5:
	/* 0xfa5: cmp    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_faa:
	/* 0xfaa: jne    fe3 <event_execve+0xfe3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfaa, 0xfe3, x86_l_fe3);
x86_l_fac:
	/* 0xfac: jmp    1c37 <event_execve+0x1c37> */
	X86_SIM_X86_JMP(0xfac, 0x1c37, x86_l_1c37);
x86_l_fb1:
	/* 0xfb1: mov    rdi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_fb4:
	/* 0xfb4: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_fb9:
	/* 0xfb9: call   fbe <event_execve+0xfbe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_fbe:
	/* 0xfbe: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fc2:
	/* 0xfc2: cmp    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_fc7:
	/* 0xfc7: jne    fe3 <event_execve+0xfe3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfc7, 0xfe3, x86_l_fe3);
x86_l_fc9:
	/* 0xfc9: jmp    1c37 <event_execve+0x1c37> */
	X86_SIM_X86_JMP(0xfc9, 0x1c37, x86_l_1c37);
x86_l_fce:
	/* 0xfce: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fd6:
	/* 0xfd6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fd8:
	/* 0xfd8: cmp    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_fdd:
	/* 0xfdd: je     1c37 <event_execve+0x1c37> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfdd, 0x1c37, x86_l_1c37);
x86_l_fe3:
	/* 0xfe3: add    rbx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_fe7:
	/* 0xfe7: jns    e61 <event_execve+0xe61> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfe7, 0xe61, x86_l_e61);
x86_l_fed:
	/* 0xfed: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ff0:
	/* 0xff0: jns    fff <event_execve+0xfff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xff0, 0xfff, x86_l_fff);
x86_l_ff2:
	/* 0xff2: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ff5:
	/* 0xff5: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ffa:
	/* 0xffa: jmp    e73 <event_execve+0xe73> */
	X86_SIM_X86_JMP(0xffa, 0xe73, x86_l_e73);
x86_l_fff:
	/* 0xfff: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1008:
	/* 0x1008: jmp    e73 <event_execve+0xe73> */
	X86_SIM_X86_JMP(0x1008, 0xe73, x86_l_e73);
x86_l_100d:
	/* 0x100d: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1016:
	/* 0x1016: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_101f:
	/* 0x101f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1021:
	/* 0x1021: jmp    104d <event_execve+0x104d> */
	X86_SIM_X86_JMP(0x1021, 0x104d, x86_l_104d);
x86_l_1023:
	/* 0x1023: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_102c:
	/* 0x102c: add    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1030:
	/* 0x1030: js     f4f <event_execve+0xf4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1030, 0xf4f, x86_l_f4f);
x86_l_1036:
	/* 0x1036: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_103b:
	/* 0x103b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1040:
	/* 0x1040: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1043:
	/* 0x1043: call   1048 <event_execve+0x1048> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1048:
	/* 0x1048: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_104d:
	/* 0x104d: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1052:
	/* 0x1052: mov    r12,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1057:
	/* 0x1057: mov    r15d,DWORD PTR [rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_105c:
	/* 0x105c: mov    r13d,DWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1061:
	/* 0x1061: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1063:
	/* 0x1063: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1066:
	/* 0x1066: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1069:
	/* 0x1069: sub    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_106c:
	/* 0x106c: mov    edi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1071:
	/* 0x1071: cmovb  ecx,edi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RDI, X86_WIDTH_32, X86_CC_B, 0);
x86_l_1074:
	/* 0x1074: setb   dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_1078:
	/* 0x1078: ja     107d <event_execve+0x107d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1078, 0x107d, x86_l_107d);
x86_l_107a:
	/* 0x107a: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_107d:
	/* 0x107d: sub    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1080:
	/* 0x1080: mov    sil,dil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDI, X86_WIDTH_8, 0, 0);
x86_l_1083:
	/* 0x1083: add    esi,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1085:
	/* 0x1085: mov    edi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1088:
	/* 0x1088: sub    edi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_108a:
	/* 0x108a: mov    DWORD PTR [rsp+0x58],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_108e:
	/* 0x108e: sub    r12,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1091:
	/* 0x1091: jb     11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1091, 0x11c8, x86_l_11c8);
x86_l_1097:
	/* 0x1097: cmp    r12,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_109e:
	/* 0x109e: ja     11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x109e, 0x11c8, x86_l_11c8);
x86_l_10a4:
	/* 0x10a4: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_10a7:
	/* 0x10a7: jbe    10ae <event_execve+0x10ae> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x10a7, 0x10ae, x86_l_10ae);
x86_l_10a9:
	/* 0x10a9: mov    BYTE PTR [rbx+r12*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R12, 0), 47ULL);
x86_l_10ae:
	/* 0x10ae: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_10b1:
	/* 0x10b1: cmp    r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_10b4:
	/* 0x10b4: movzx  esi,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_10b7:
	/* 0x10b7: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10ba:
	/* 0x10ba: adc    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADC, 0);
x86_l_10bd:
	/* 0x10bd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10c0:
	/* 0x10c0: jns    1108 <event_execve+0x1108> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10c0, 0x1108, x86_l_1108);
x86_l_10c2:
	/* 0x10c2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10c5:
	/* 0x10c5: jns    111f <event_execve+0x111f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10c5, 0x111f, x86_l_111f);
x86_l_10c7:
	/* 0x10c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10c9:
	/* 0x10c9: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_10cc:
	/* 0x10cc: jb     10ea <event_execve+0x10ea> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10cc, 0x10ea, x86_l_10ea);
x86_l_10ce:
	/* 0x10ce: mov    esi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_10d0:
	/* 0x10d0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10d2:
	/* 0x10d2: mov    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10d5:
	/* 0x10d5: mov    rcx,QWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_10d9:
	/* 0x10d9: mov    QWORD PTR [rdi+r8*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_10dd:
	/* 0x10dd: lea    rcx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10e1:
	/* 0x10e1: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_10e5:
	/* 0x10e5: cmp    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10e8:
	/* 0x10e8: jbe    10d2 <event_execve+0x10d2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x10e8, 0x10d2, x86_l_10d2);
x86_l_10ea:
	/* 0x10ea: test   al,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_10ec:
	/* 0x10ec: jne    113a <event_execve+0x113a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10ec, 0x113a, x86_l_113a);
x86_l_10ee:
	/* 0x10ee: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_10f0:
	/* 0x10f0: jne    114b <event_execve+0x114b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10f0, 0x114b, x86_l_114b);
x86_l_10f2:
	/* 0x10f2: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_10f4:
	/* 0x10f4: jne    115e <event_execve+0x115e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10f4, 0x115e, x86_l_115e);
x86_l_10f6:
	/* 0x10f6: add    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_10f9:
	/* 0x10f9: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_10fe:
	/* 0x10fe: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1101:
	/* 0x1101: ja     1174 <event_execve+0x1174> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1101, 0x1174, x86_l_1174);
x86_l_1103:
	/* 0x1103: jmp    11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JMP(0x1103, 0x11c8, x86_l_11c8);
x86_l_1108:
	/* 0x1108: call   110d <event_execve+0x110d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_110d:
	/* 0x110d: add    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1110:
	/* 0x1110: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1115:
	/* 0x1115: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1118:
	/* 0x1118: ja     1174 <event_execve+0x1174> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1118, 0x1174, x86_l_1174);
x86_l_111a:
	/* 0x111a: jmp    11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JMP(0x111a, 0x11c8, x86_l_11c8);
x86_l_111f:
	/* 0x111f: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1121:
	/* 0x1121: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1123:
	/* 0x1123: call   1128 <event_execve+0x1128> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1128:
	/* 0x1128: add    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_112b:
	/* 0x112b: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1130:
	/* 0x1130: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1133:
	/* 0x1133: ja     1174 <event_execve+0x1174> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1133, 0x1174, x86_l_1174);
x86_l_1135:
	/* 0x1135: jmp    11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JMP(0x1135, 0x11c8, x86_l_11c8);
x86_l_113a:
	/* 0x113a: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_113c:
	/* 0x113c: mov    r8d,DWORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1140:
	/* 0x1140: mov    DWORD PTR [rdi+rsi*1],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1144:
	/* 0x1144: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1147:
	/* 0x1147: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1149:
	/* 0x1149: je     10f2 <event_execve+0x10f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1149, 0x10f2, x86_l_10f2);
x86_l_114b:
	/* 0x114b: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_114d:
	/* 0x114d: movzx  r8d,WORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_16), 0ULL);
x86_l_1152:
	/* 0x1152: mov    WORD PTR [rdi+rsi*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1157:
	/* 0x1157: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_115a:
	/* 0x115a: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_115c:
	/* 0x115c: je     10f6 <event_execve+0x10f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x115c, 0x10f6, x86_l_10f6);
x86_l_115e:
	/* 0x115e: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1160:
	/* 0x1160: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1164:
	/* 0x1164: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1167:
	/* 0x1167: add    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_116a:
	/* 0x116a: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_116f:
	/* 0x116f: cmp    r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1172:
	/* 0x1172: jbe    11c8 <event_execve+0x11c8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1172, 0x11c8, x86_l_11c8);
x86_l_1174:
	/* 0x1174: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1179:
	/* 0x1179: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_117e:
	/* 0x117e: mov    r12,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1183:
	/* 0x1183: inc    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1185:
	/* 0x1185: cmp    ebp,0x800 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_118b:
	/* 0x118b: jne    e93 <event_execve+0xe93> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x118b, 0xe93, x86_l_e93);
x86_l_1191:
	/* 0x1191: jmp    11cd <event_execve+0x11cd> */
	X86_SIM_X86_JMP(0x1191, 0x11cd, x86_l_11cd);
x86_l_1193:
	/* 0x1193: lea    rsi,[rip+0x0] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x2368ULL);
x86_l_119a:
	/* 0x119a: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_119f:
	/* 0x119f: mov    edi,0x800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_11a4:
	/* 0x11a4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11a6:
	/* 0x11a6: call   11ab <event_execve+0x11ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_loop);
x86_l_11ab:
	/* 0x11ab: mov    rcx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_11b0:
	/* 0x11b0: mov    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_11b8:
	/* 0x11b8: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_11bb:
	/* 0x11bb: jne    11df <event_execve+0x11df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11bb, 0x11df, x86_l_11df);
x86_l_11bd:
	/* 0x11bd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11bf:
	/* 0x11bf: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c1:
	/* 0x11c1: jmp    120a <event_execve+0x120a> */
	X86_SIM_X86_JMP(0x11c1, 0x120a, x86_l_120a);
x86_l_11c3:
	/* 0x11c3: mov    BYTE PTR [rsp+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991233ULL);
x86_l_11c8:
	/* 0x11c8: mov    r12,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_11cd:
	/* 0x11cd: mov    rcx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_11d2:
	/* 0x11d2: mov    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_11da:
	/* 0x11da: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_11dd:
	/* 0x11dd: je     11bd <event_execve+0x11bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11dd, 0x11bd, x86_l_11bd);
x86_l_11df:
	/* 0x11df: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11e1:
	/* 0x11e1: cmp    BYTE PTR [rsp+0x5c],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
x86_l_11e6:
	/* 0x11e6: sete   dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_11e9:
	/* 0x11e9: mov    eax,DWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_11ed:
	/* 0x11ed: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11ef:
	/* 0x11ef: jle    11fa <event_execve+0x11fa> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x11ef, 0x11fa, x86_l_11fa);
x86_l_11f1:
	/* 0x11f1: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_11f6:
	/* 0x11f6: sub    esi,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_11f8:
	/* 0x11f8: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_11fa:
	/* 0x11fa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11fd:
	/* 0x11fd: je     bb2 <event_execve+0xbb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11fd, 0xbb2, x86_l_bb2);
x86_l_1203:
	/* 0x1203: mov    bl,dl */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1205:
	/* 0x1205: add    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1207:
	/* 0x1207: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_120a:
	/* 0x120a: mov    rdi,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1212:
	/* 0x1212: and    edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_1218:
	/* 0x1218: mov    ebp,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_121a:
	/* 0x121a: and    ebp,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1220:
	/* 0x1220: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1223:
	/* 0x1223: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1226:
	/* 0x1226: jns    1272 <event_execve+0x1272> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1226, 0x1272, x86_l_1272);
x86_l_1228:
	/* 0x1228: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_122b:
	/* 0x122b: jns    127b <event_execve+0x127b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x122b, 0x127b, x86_l_127b);
x86_l_122d:
	/* 0x122d: mov    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1230:
	/* 0x1230: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1232:
	/* 0x1232: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1235:
	/* 0x1235: jb     1259 <event_execve+0x1259> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1235, 0x1259, x86_l_1259);
x86_l_1237:
	/* 0x1237: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1239:
	/* 0x1239: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_123b:
	/* 0x123b: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_123e:
	/* 0x123e: mov    r10,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1241:
	/* 0x1241: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1244:
	/* 0x1244: mov    rcx,QWORD PTR [r10+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1248:
	/* 0x1248: mov    QWORD PTR [r8+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_124c:
	/* 0x124c: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1250:
	/* 0x1250: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1254:
	/* 0x1254: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1257:
	/* 0x1257: jbe    1241 <event_execve+0x1241> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1257, 0x1241, x86_l_1241);
x86_l_1259:
	/* 0x1259: test   al,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_125b:
	/* 0x125b: jne    1c57 <event_execve+0x1c57> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x125b, 0x1c57, x86_l_1c57);
x86_l_1261:
	/* 0x1261: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1263:
	/* 0x1263: jne    1c6b <event_execve+0x1c6b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1263, 0x1c6b, x86_l_1c6b);
x86_l_1269:
	/* 0x1269: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_126b:
	/* 0x126b: je     1284 <event_execve+0x1284> */
	X86_SIM_X86_JCC(X86_CC_E, 0x126b, 0x1284, x86_l_1284);
x86_l_126d:
	/* 0x126d: jmp    1c81 <event_execve+0x1c81> */
	X86_SIM_X86_JMP(0x126d, 0x1c81, x86_l_1c81);
x86_l_1272:
	/* 0x1272: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1274:
	/* 0x1274: call   1279 <event_execve+0x1279> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1279:
	/* 0x1279: jmp    1284 <event_execve+0x1284> */
	X86_SIM_X86_JMP(0x1279, 0x1284, x86_l_1284);
x86_l_127b:
	/* 0x127b: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_127d:
	/* 0x127d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_127f:
	/* 0x127f: call   1284 <event_execve+0x1284> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1284:
	/* 0x1284: mov    eax,DWORD PTR [r14+0x15c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 348ULL);
x86_l_128b:
	/* 0x128b: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_128d:
	/* 0x128d: jne    1294 <event_execve+0x1294> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x128d, 0x1294, x86_l_1294);
x86_l_128f:
	/* 0x128f: or     eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4096ULL);
x86_l_1294:
	/* 0x1294: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1296:
	/* 0x1296: je     129d <event_execve+0x129d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1296, 0x129d, x86_l_129d);
x86_l_1298:
	/* 0x1298: or     eax,0x400000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4194304ULL);
x86_l_129d:
	/* 0x129d: and    eax,0xffffdbff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294958079ULL);
x86_l_12a2:
	/* 0x12a2: mov    DWORD PTR [r14+0x15c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 348ULL);
x86_l_12a9:
	/* 0x12a9: mov    WORD PTR [r14+0x17c],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 380ULL);
x86_l_12b1:
	/* 0x12b1: mov    ebx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b5:
	/* 0x12b5: add    ebx,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_12b7:
	/* 0x12b7: mov    DWORD PTR [r12],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12bb:
	/* 0x12bb: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_12c4:
	/* 0x12c4: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&ENV_VARS_ENABLED));
x86_l_12cb:
	/* 0x12cb: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ce:
	/* 0x12ce: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12d1:
	/* 0x12d1: je     1306 <event_execve+0x1306> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d1, 0x1306, x86_l_1306);
x86_l_12d3:
	/* 0x12d3: cmp    ebx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 1023ULL);
x86_l_12d9:
	/* 0x12d9: mov    r12,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_12e1:
	/* 0x12e1: ja     130e <event_execve+0x130e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x12e1, 0x130e, x86_l_130e);
x86_l_12e3:
	/* 0x12e3: call   12e8 <event_execve+0x12e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_12e8:
	/* 0x12e8: add    rax,0xa78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2680ULL);
x86_l_12ee:
	/* 0x12ee: jns    1962 <event_execve+0x1962> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12ee, 0x1962, x86_l_1962);
x86_l_12f4:
	/* 0x12f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12f7:
	/* 0x12f7: jns    130e <event_execve+0x130e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f7, 0x130e, x86_l_130e);
x86_l_12f9:
	/* 0x12f9: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12fc:
	/* 0x12fc: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1301:
	/* 0x1301: jmp    1979 <event_execve+0x1979> */
	X86_SIM_X86_JMP(0x1301, 0x1979, x86_l_1979);
x86_l_1306:
	/* 0x1306: mov    r12,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_130e:
	/* 0x130e: mov    eax,DWORD PTR [r14+0x140] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_1315:
	/* 0x1315: lea    ecx,[rax+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1319:
	/* 0x1319: mov    DWORD PTR [r14+0x140],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
x86_l_1320:
	/* 0x1320: mov    WORD PTR [r14],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_1326:
	/* 0x1326: mov    rcx,QWORD PTR [r14+0x170] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
x86_l_132d:
	/* 0x132d: mov    QWORD PTR [r14+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1331:
	/* 0x1331: add    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1334:
	/* 0x1334: add    eax,0x140 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 320ULL);
x86_l_1339:
	/* 0x1339: mov    DWORD PTR [r14+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_133d:
	/* 0x133d: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1340:
	/* 0x1340: add    rdx,0xd00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3328ULL);
x86_l_1347:
	/* 0x1347: jns    136a <event_execve+0x136a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1347, 0x136a, x86_l_136a);
x86_l_1349:
	/* 0x1349: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_134c:
	/* 0x134c: jns    13ad <event_execve+0x13ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x134c, 0x13ad, x86_l_13ad);
x86_l_134e:
	/* 0x134e: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1351:
	/* 0x1351: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1356:
	/* 0x1356: mov    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_135b:
	/* 0x135b: lea    rdi,[r14+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1362:
	/* 0x1362: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1366:
	/* 0x1366: js     1390 <event_execve+0x1390> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1366, 0x1390, x86_l_1390);
x86_l_1368:
	/* 0x1368: jmp    13ca <event_execve+0x13ca> */
	X86_SIM_X86_JMP(0x1368, 0x13ca, x86_l_13ca);
x86_l_136a:
	/* 0x136a: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_136f:
	/* 0x136f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1374:
	/* 0x1374: call   1379 <event_execve+0x1379> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1379:
	/* 0x1379: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_137e:
	/* 0x137e: mov    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1383:
	/* 0x1383: lea    rdi,[r14+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_138a:
	/* 0x138a: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_138e:
	/* 0x138e: jns    13ca <event_execve+0x13ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138e, 0x13ca, x86_l_13ca);
x86_l_1390:
	/* 0x1390: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1393:
	/* 0x1393: jns    1403 <event_execve+0x1403> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1393, 0x1403, x86_l_1403);
x86_l_1395:
	/* 0x1395: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1397:
	/* 0x1397: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1399:
	/* 0x1399: lea    rdi,[r14+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_13a0:
	/* 0x13a0: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13a5:
	/* 0x13a5: add    rdx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_13a9:
	/* 0x13a9: js     13e6 <event_execve+0x13e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13a9, 0x13e6, x86_l_13e6);
x86_l_13ab:
	/* 0x13ab: jmp    141b <event_execve+0x141b> */
	X86_SIM_X86_JMP(0x13ab, 0x141b, x86_l_141b);
x86_l_13ad:
	/* 0x13ad: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_13b6:
	/* 0x13b6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13b8:
	/* 0x13b8: mov    r13,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_13bd:
	/* 0x13bd: lea    rdi,[r14+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_13c4:
	/* 0x13c4: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_13c8:
	/* 0x13c8: js     1390 <event_execve+0x1390> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13c8, 0x1390, x86_l_1390);
x86_l_13ca:
	/* 0x13ca: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_13cf:
	/* 0x13cf: call   13d4 <event_execve+0x13d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_13d4:
	/* 0x13d4: lea    rdi,[r14+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_13db:
	/* 0x13db: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13e0:
	/* 0x13e0: add    rdx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_13e4:
	/* 0x13e4: jns    141b <event_execve+0x141b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e4, 0x141b, x86_l_141b);
x86_l_13e6:
	/* 0x13e6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13e9:
	/* 0x13e9: jns    1454 <event_execve+0x1454> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e9, 0x1454, x86_l_1454);
x86_l_13eb:
	/* 0x13eb: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ed:
	/* 0x13ed: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ef:
	/* 0x13ef: lea    rdi,[r14+0xc8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_13f6:
	/* 0x13f6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13fb:
	/* 0x13fb: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_13ff:
	/* 0x13ff: js     1437 <event_execve+0x1437> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13ff, 0x1437, x86_l_1437);
x86_l_1401:
	/* 0x1401: jmp    146c <event_execve+0x146c> */
	X86_SIM_X86_JMP(0x1401, 0x146c, x86_l_146c);
x86_l_1403:
	/* 0x1403: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1409:
	/* 0x1409: lea    rdi,[r14+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_1410:
	/* 0x1410: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1415:
	/* 0x1415: add    rdx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1419:
	/* 0x1419: js     13e6 <event_execve+0x13e6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1419, 0x13e6, x86_l_13e6);
x86_l_141b:
	/* 0x141b: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1420:
	/* 0x1420: call   1425 <event_execve+0x1425> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1425:
	/* 0x1425: lea    rdi,[r14+0xc8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_142c:
	/* 0x142c: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1431:
	/* 0x1431: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1435:
	/* 0x1435: jns    146c <event_execve+0x146c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1435, 0x146c, x86_l_146c);
x86_l_1437:
	/* 0x1437: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_143a:
	/* 0x143a: jns    14a5 <event_execve+0x14a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x143a, 0x14a5, x86_l_14a5);
x86_l_143c:
	/* 0x143c: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_143e:
	/* 0x143e: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1440:
	/* 0x1440: lea    rdi,[r14+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_1447:
	/* 0x1447: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_144c:
	/* 0x144c: add    rdx,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
x86_l_1450:
	/* 0x1450: js     1488 <event_execve+0x1488> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1450, 0x1488, x86_l_1488);
x86_l_1452:
	/* 0x1452: jmp    14bd <event_execve+0x14bd> */
	X86_SIM_X86_JMP(0x1452, 0x14bd, x86_l_14bd);
x86_l_1454:
	/* 0x1454: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_145a:
	/* 0x145a: lea    rdi,[r14+0xc8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1461:
	/* 0x1461: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1466:
	/* 0x1466: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_146a:
	/* 0x146a: js     1437 <event_execve+0x1437> */
	X86_SIM_X86_JCC(X86_CC_S, 0x146a, 0x1437, x86_l_1437);
x86_l_146c:
	/* 0x146c: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1471:
	/* 0x1471: call   1476 <event_execve+0x1476> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1476:
	/* 0x1476: lea    rdi,[r14+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_147d:
	/* 0x147d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1482:
	/* 0x1482: add    rdx,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
x86_l_1486:
	/* 0x1486: jns    14bd <event_execve+0x14bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1486, 0x14bd, x86_l_14bd);
x86_l_1488:
	/* 0x1488: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_148b:
	/* 0x148b: jns    14f6 <event_execve+0x14f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148b, 0x14f6, x86_l_14f6);
x86_l_148d:
	/* 0x148d: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_148f:
	/* 0x148f: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1491:
	/* 0x1491: lea    rdi,[r14+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1498:
	/* 0x1498: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_149d:
	/* 0x149d: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14a1:
	/* 0x14a1: js     14d9 <event_execve+0x14d9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14a1, 0x14d9, x86_l_14d9);
x86_l_14a3:
	/* 0x14a3: jmp    150e <event_execve+0x150e> */
	X86_SIM_X86_JMP(0x14a3, 0x150e, x86_l_150e);
x86_l_14a5:
	/* 0x14a5: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ab:
	/* 0x14ab: lea    rdi,[r14+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_14b2:
	/* 0x14b2: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14b7:
	/* 0x14b7: add    rdx,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
x86_l_14bb:
	/* 0x14bb: js     1488 <event_execve+0x1488> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14bb, 0x1488, x86_l_1488);
x86_l_14bd:
	/* 0x14bd: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14c2:
	/* 0x14c2: call   14c7 <event_execve+0x14c7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14c7:
	/* 0x14c7: lea    rdi,[r14+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_14ce:
	/* 0x14ce: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14d3:
	/* 0x14d3: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14d7:
	/* 0x14d7: jns    150e <event_execve+0x150e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14d7, 0x150e, x86_l_150e);
x86_l_14d9:
	/* 0x14d9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14dc:
	/* 0x14dc: jns    1547 <event_execve+0x1547> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14dc, 0x1547, x86_l_1547);
x86_l_14de:
	/* 0x14de: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14e0:
	/* 0x14e0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14e2:
	/* 0x14e2: lea    rdi,[r14+0xc4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_14e9:
	/* 0x14e9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14ee:
	/* 0x14ee: add    rdx,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
x86_l_14f2:
	/* 0x14f2: js     152a <event_execve+0x152a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14f2, 0x152a, x86_l_152a);
x86_l_14f4:
	/* 0x14f4: jmp    155f <event_execve+0x155f> */
	X86_SIM_X86_JMP(0x14f4, 0x155f, x86_l_155f);
x86_l_14f6:
	/* 0x14f6: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14fc:
	/* 0x14fc: lea    rdi,[r14+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1503:
	/* 0x1503: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1508:
	/* 0x1508: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_150c:
	/* 0x150c: js     14d9 <event_execve+0x14d9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x150c, 0x14d9, x86_l_14d9);
x86_l_150e:
	/* 0x150e: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1513:
	/* 0x1513: call   1518 <event_execve+0x1518> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1518:
	/* 0x1518: lea    rdi,[r14+0xc4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_151f:
	/* 0x151f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1524:
	/* 0x1524: add    rdx,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
x86_l_1528:
	/* 0x1528: jns    155f <event_execve+0x155f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1528, 0x155f, x86_l_155f);
x86_l_152a:
	/* 0x152a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_152d:
	/* 0x152d: jns    1598 <event_execve+0x1598> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x152d, 0x1598, x86_l_1598);
x86_l_152f:
	/* 0x152f: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1531:
	/* 0x1531: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1533:
	/* 0x1533: lea    rdi,[r14+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_153a:
	/* 0x153a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_153f:
	/* 0x153f: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1543:
	/* 0x1543: js     157b <event_execve+0x157b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1543, 0x157b, x86_l_157b);
x86_l_1545:
	/* 0x1545: jmp    15b0 <event_execve+0x15b0> */
	X86_SIM_X86_JMP(0x1545, 0x15b0, x86_l_15b0);
x86_l_1547:
	/* 0x1547: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154d:
	/* 0x154d: lea    rdi,[r14+0xc4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_1554:
	/* 0x1554: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1559:
	/* 0x1559: add    rdx,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
x86_l_155d:
	/* 0x155d: js     152a <event_execve+0x152a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x155d, 0x152a, x86_l_152a);
x86_l_155f:
	/* 0x155f: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1564:
	/* 0x1564: call   1569 <event_execve+0x1569> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1569:
	/* 0x1569: lea    rdi,[r14+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1570:
	/* 0x1570: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1575:
	/* 0x1575: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1579:
	/* 0x1579: jns    15b0 <event_execve+0x15b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1579, 0x15b0, x86_l_15b0);
x86_l_157b:
	/* 0x157b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: jns    15e9 <event_execve+0x15e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157e, 0x15e9, x86_l_15e9);
x86_l_1580:
	/* 0x1580: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1582:
	/* 0x1582: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1584:
	/* 0x1584: lea    rdi,[r14+0xd4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_158b:
	/* 0x158b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1590:
	/* 0x1590: add    rdx,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_1594:
	/* 0x1594: js     15cc <event_execve+0x15cc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1594, 0x15cc, x86_l_15cc);
x86_l_1596:
	/* 0x1596: jmp    1601 <event_execve+0x1601> */
	X86_SIM_X86_JMP(0x1596, 0x1601, x86_l_1601);
x86_l_1598:
	/* 0x1598: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_159e:
	/* 0x159e: lea    rdi,[r14+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_15a5:
	/* 0x15a5: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15aa:
	/* 0x15aa: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_15ae:
	/* 0x15ae: js     157b <event_execve+0x157b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15ae, 0x157b, x86_l_157b);
x86_l_15b0:
	/* 0x15b0: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_15b5:
	/* 0x15b5: call   15ba <event_execve+0x15ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15ba:
	/* 0x15ba: lea    rdi,[r14+0xd4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_15c1:
	/* 0x15c1: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15c6:
	/* 0x15c6: add    rdx,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_15ca:
	/* 0x15ca: jns    1601 <event_execve+0x1601> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ca, 0x1601, x86_l_1601);
x86_l_15cc:
	/* 0x15cc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15cf:
	/* 0x15cf: jns    1632 <event_execve+0x1632> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15cf, 0x1632, x86_l_1632);
x86_l_15d1:
	/* 0x15d1: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d3:
	/* 0x15d3: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d5:
	/* 0x15d5: lea    rdi,[r14+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_15dc:
	/* 0x15dc: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15e1:
	/* 0x15e1: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_15e5:
	/* 0x15e5: js     161d <event_execve+0x161d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15e5, 0x161d, x86_l_161d);
x86_l_15e7:
	/* 0x15e7: jmp    164a <event_execve+0x164a> */
	X86_SIM_X86_JMP(0x15e7, 0x164a, x86_l_164a);
x86_l_15e9:
	/* 0x15e9: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ef:
	/* 0x15ef: lea    rdi,[r14+0xd4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_15f6:
	/* 0x15f6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15fb:
	/* 0x15fb: add    rdx,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_15ff:
	/* 0x15ff: js     15cc <event_execve+0x15cc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15ff, 0x15cc, x86_l_15cc);
x86_l_1601:
	/* 0x1601: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1606:
	/* 0x1606: call   160b <event_execve+0x160b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_160b:
	/* 0x160b: lea    rdi,[r14+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1612:
	/* 0x1612: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1617:
	/* 0x1617: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_161b:
	/* 0x161b: jns    164a <event_execve+0x164a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161b, 0x164a, x86_l_164a);
x86_l_161d:
	/* 0x161d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1620:
	/* 0x1620: jns    167a <event_execve+0x167a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1620, 0x167a, x86_l_167a);
x86_l_1622:
	/* 0x1622: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1624:
	/* 0x1624: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1626:
	/* 0x1626: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_162b:
	/* 0x162b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_162e:
	/* 0x162e: jne    165e <event_execve+0x165e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x162e, 0x165e, x86_l_165e);
x86_l_1630:
	/* 0x1630: jmp    168a <event_execve+0x168a> */
	X86_SIM_X86_JMP(0x1630, 0x168a, x86_l_168a);
x86_l_1632:
	/* 0x1632: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1638:
	/* 0x1638: lea    rdi,[r14+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_163f:
	/* 0x163f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1644:
	/* 0x1644: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1648:
	/* 0x1648: js     161d <event_execve+0x161d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1648, 0x161d, x86_l_161d);
x86_l_164a:
	/* 0x164a: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_164f:
	/* 0x164f: call   1654 <event_execve+0x1654> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1654:
	/* 0x1654: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1659:
	/* 0x1659: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165c:
	/* 0x165c: je     168a <event_execve+0x168a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x165c, 0x168a, x86_l_168a);
x86_l_165e:
	/* 0x165e: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1662:
	/* 0x1662: mov    QWORD PTR [r14+0xe8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1669:
	/* 0x1669: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_166d:
	/* 0x166d: mov    QWORD PTR [r14+0xf0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1674:
	/* 0x1674: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1678:
	/* 0x1678: jmp    16a2 <event_execve+0x16a2> */
	X86_SIM_X86_JMP(0x1678, 0x16a2, x86_l_16a2);
x86_l_167a:
	/* 0x167a: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1680:
	/* 0x1680: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1685:
	/* 0x1685: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1688:
	/* 0x1688: jne    165e <event_execve+0x165e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1688, 0x165e, x86_l_165e);
x86_l_168a:
	/* 0x168a: mov    QWORD PTR [r14+0xf0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1030792151040ULL);
x86_l_1695:
	/* 0x1695: mov    QWORD PTR [r14+0xe8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 996432412672ULL);
x86_l_16a0:
	/* 0x16a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a2:
	/* 0x16a2: mov    QWORD PTR [r14+0xe0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_16a9:
	/* 0x16a9: mov    eax,DWORD PTR [r14+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_16b0:
	/* 0x16b0: mov    DWORD PTR [r14+0x154],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 340ULL);
x86_l_16b7:
	/* 0x16b7: lea    rsi,[r14+0x108] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_16be:
	/* 0x16be: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_16c1:
	/* 0x16c1: je     16e9 <event_execve+0x16e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16c1, 0x16e9, x86_l_16e9);
x86_l_16c3:
	/* 0x16c3: mov    rcx,QWORD PTR [r12+0xd70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3440ULL);
x86_l_16cb:
	/* 0x16cb: mov    rax,QWORD PTR [r12+0xa78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2680ULL);
x86_l_16d3:
	/* 0x16d3: mov    rdx,QWORD PTR [r12+0xb58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
x86_l_16db:
	/* 0x16db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16de:
	/* 0x16de: je     16ed <event_execve+0x16ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16de, 0x16ed, x86_l_16ed);
x86_l_16e0:
	/* 0x16e0: mov    rax,QWORD PTR [rax+0x5a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1440ULL);
x86_l_16e7:
	/* 0x16e7: jmp    16ef <event_execve+0x16ef> */
	X86_SIM_X86_JMP(0x16e7, 0x16ef, x86_l_16ef);
x86_l_16e9:
	/* 0x16e9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16eb:
	/* 0x16eb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ed:
	/* 0x16ed: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ef:
	/* 0x16ef: mov    QWORD PTR [rsi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_16f7:
	/* 0x16f7: mov    QWORD PTR [rsi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_16ff:
	/* 0x16ff: mov    QWORD PTR [rsi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1707:
	/* 0x1707: mov    QWORD PTR [rsi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_170f:
	/* 0x170f: mov    QWORD PTR [rsi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1716:
	/* 0x1716: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1719:
	/* 0x1719: je     1800 <event_execve+0x1800> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1719, 0x1800, x86_l_1800);
x86_l_171f:
	/* 0x171f: mov    rdi,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1723:
	/* 0x1723: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1726:
	/* 0x1726: je     1730 <event_execve+0x1730> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1726, 0x1730, x86_l_1730);
x86_l_1728:
	/* 0x1728: mov    edi,DWORD PTR [rdi+0x218] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_172e:
	/* 0x172e: mov    DWORD PTR [rsi],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1730:
	/* 0x1730: mov    rsi,QWORD PTR [rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1734:
	/* 0x1734: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1737:
	/* 0x1737: je     1746 <event_execve+0x1746> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1737, 0x1746, x86_l_1746);
x86_l_1739:
	/* 0x1739: mov    esi,DWORD PTR [rsi+0x4d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1240ULL);
x86_l_173f:
	/* 0x173f: mov    DWORD PTR [r14+0x10c],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 268ULL);
x86_l_1746:
	/* 0x1746: mov    rsi,QWORD PTR [rcx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_174a:
	/* 0x174a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_174d:
	/* 0x174d: je     1759 <event_execve+0x1759> */
	X86_SIM_X86_JCC(X86_CC_E, 0x174d, 0x1759, x86_l_1759);
x86_l_174f:
	/* 0x174f: mov    esi,DWORD PTR [rsi+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1752:
	/* 0x1752: mov    DWORD PTR [r14+0x110],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_1759:
	/* 0x1759: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_175c:
	/* 0x175c: je     1783 <event_execve+0x1783> */
	X86_SIM_X86_JCC(X86_CC_E, 0x175c, 0x1783, x86_l_1783);
x86_l_175e:
	/* 0x175e: mov    esi,DWORD PTR [rdx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1761:
	/* 0x1761: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1763:
	/* 0x1763: js     1783 <event_execve+0x1783> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1763, 0x1783, x86_l_1783);
x86_l_1765:
	/* 0x1765: shl    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1769:
	/* 0x1769: mov    rdx,QWORD PTR [rdx+rsi*1+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 136ULL);
x86_l_1771:
	/* 0x1771: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1774:
	/* 0x1774: je     1783 <event_execve+0x1783> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1774, 0x1783, x86_l_1783);
x86_l_1776:
	/* 0x1776: mov    edx,DWORD PTR [rdx+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_177c:
	/* 0x177c: mov    DWORD PTR [r14+0x114],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 276ULL);
x86_l_1783:
	/* 0x1783: mov    rdx,QWORD PTR [rcx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1787:
	/* 0x1787: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_178a:
	/* 0x178a: je     1799 <event_execve+0x1799> */
	X86_SIM_X86_JCC(X86_CC_E, 0x178a, 0x1799, x86_l_1799);
x86_l_178c:
	/* 0x178c: mov    edx,DWORD PTR [rdx+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_1792:
	/* 0x1792: mov    DWORD PTR [r14+0x118],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_1799:
	/* 0x1799: mov    rdx,QWORD PTR [rcx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_179d:
	/* 0x179d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17a0:
	/* 0x17a0: je     17af <event_execve+0x17af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17a0, 0x17af, x86_l_17af);
x86_l_17a2:
	/* 0x17a2: mov    edx,DWORD PTR [rdx+0x118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_17a8:
	/* 0x17a8: mov    DWORD PTR [r14+0x11c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 284ULL);
x86_l_17af:
	/* 0x17af: mov    rdx,QWORD PTR [rcx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_17b3:
	/* 0x17b3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17b6:
	/* 0x17b6: je     17c5 <event_execve+0x17c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17b6, 0x17c5, x86_l_17c5);
x86_l_17b8:
	/* 0x17b8: mov    edx,DWORD PTR [rdx+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_17be:
	/* 0x17be: mov    DWORD PTR [r14+0x120],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
x86_l_17c5:
	/* 0x17c5: mov    rdx,QWORD PTR [rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_17c9:
	/* 0x17c9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17cc:
	/* 0x17cc: je     17db <event_execve+0x17db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17cc, 0x17db, x86_l_17db);
x86_l_17ce:
	/* 0x17ce: mov    edx,DWORD PTR [rdx+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_17d4:
	/* 0x17d4: mov    DWORD PTR [r14+0x124],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 292ULL);
x86_l_17db:
	/* 0x17db: mov    rcx,QWORD PTR [rcx+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_17df:
	/* 0x17df: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17e2:
	/* 0x17e2: je     17ee <event_execve+0x17ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17e2, 0x17ee, x86_l_17ee);
x86_l_17e4:
	/* 0x17e4: mov    ecx,DWORD PTR [rcx+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_17e7:
	/* 0x17e7: mov    DWORD PTR [r14+0x128],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
x86_l_17ee:
	/* 0x17ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f1:
	/* 0x17f1: je     1800 <event_execve+0x1800> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17f1, 0x1800, x86_l_1800);
x86_l_17f3:
	/* 0x17f3: mov    eax,DWORD PTR [rax+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_17f9:
	/* 0x17f9: mov    DWORD PTR [r14+0x12c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 300ULL);
x86_l_1800:
	/* 0x1800: lea    rbx,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1804:
	/* 0x1804: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_180c:
	/* 0x180c: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_180f:
	/* 0x180f: mov    edx,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1814:
	/* 0x1814: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1817:
	/* 0x1817: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1819:
	/* 0x1819: call   181e <event_execve+0x181e> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 144ULL);
x86_l_181e:
	/* 0x181e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_1825:
	/* 0x1825: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_182a:
	/* 0x182a: call   182f <event_execve+0x182f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_182f:
	/* 0x182f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1832:
	/* 0x1832: je     184c <event_execve+0x184c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1832, 0x184c, x86_l_184c);
x86_l_1834:
	/* 0x1834: mov    rdx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1838:
	/* 0x1838: mov    eax,DWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_183b:
	/* 0x183b: add    r12,0xf88 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3976ULL);
x86_l_1842:
	/* 0x1842: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1845:
	/* 0x1845: js     1860 <event_execve+0x1860> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1845, 0x1860, x86_l_1860);
x86_l_1847:
	/* 0x1847: jmp    1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JMP(0x1847, 0x1e1d, x86_l_1e1d);
x86_l_184c:
	/* 0x184c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_184e:
	/* 0x184e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1850:
	/* 0x1850: add    r12,0xf88 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3976ULL);
x86_l_1857:
	/* 0x1857: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_185a:
	/* 0x185a: jns    1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x185a, 0x1e1d, x86_l_1e1d);
x86_l_1860:
	/* 0x1860: mov    rcx,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1864:
	/* 0x1864: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1867:
	/* 0x1867: je     1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1867, 0x1e1d, x86_l_1e1d);
x86_l_186d:
	/* 0x186d: cmp    rdx,0x63677270 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 1667723888ULL);
x86_l_1874:
	/* 0x1874: jne    18df <event_execve+0x18df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1874, 0x18df, x86_l_18df);
x86_l_1876:
	/* 0x1876: add    rcx,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_187a:
	/* 0x187a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_187d:
	/* 0x187d: jns    1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x187d, 0x1e1d, x86_l_1e1d);
x86_l_1883:
	/* 0x1883: mov    r12,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1886:
	/* 0x1886: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1889:
	/* 0x1889: je     1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1889, 0x1e1d, x86_l_1e1d);
x86_l_188f:
	/* 0x188f: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1891:
	/* 0x1891: call   1896 <event_execve+0x1896> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_1896:
	/* 0x1896: mov    QWORD PTR [rbx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1899:
	/* 0x1899: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_189c:
	/* 0x189c: je     1a97 <event_execve+0x1a97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x189c, 0x1a97, x86_l_1a97);
x86_l_18a2:
	/* 0x18a2: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18a7:
	/* 0x18a7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_cgtracker_map));
x86_l_18ae:
	/* 0x18ae: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18b3:
	/* 0x18b3: call   18b8 <event_execve+0x18b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_18b8:
	/* 0x18b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18bb:
	/* 0x18bb: je     1c0c <event_execve+0x1c0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18bb, 0x1c0c, x86_l_1c0c);
x86_l_18c1:
	/* 0x18c1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18c4:
	/* 0x18c4: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18c8:
	/* 0x18c8: add    r12,0x100 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 256ULL);
x86_l_18cf:
	/* 0x18cf: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18d2:
	/* 0x18d2: js     1aad <event_execve+0x1aad> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18d2, 0x1aad, x86_l_1aad);
x86_l_18d8:
	/* 0x18d8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18da:
	/* 0x18da: jmp    1ab1 <event_execve+0x1ab1> */
	X86_SIM_X86_JMP(0x18da, 0x1ab1, x86_l_1ab1);
x86_l_18df:
	/* 0x18df: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_18e2:
	/* 0x18e2: ja     1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x18e2, 0x1e1d, x86_l_1e1d);
x86_l_18e8:
	/* 0x18e8: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_18ea:
	/* 0x18ea: lea    rax,[rcx+rax*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 0ULL);
x86_l_18ee:
	/* 0x18ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18f1:
	/* 0x18f1: jns    1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18f1, 0x1e1d, x86_l_1e1d);
x86_l_18f7:
	/* 0x18f7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18fa:
	/* 0x18fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18fd:
	/* 0x18fd: je     1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18fd, 0x1e1d, x86_l_1e1d);
x86_l_1903:
	/* 0x1903: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1906:
	/* 0x1906: jns    1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1906, 0x1e1d, x86_l_1e1d);
x86_l_190c:
	/* 0x190c: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_190f:
	/* 0x190f: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1911:
	/* 0x1911: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1914:
	/* 0x1914: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1917:
	/* 0x1917: je     1e1d <event_execve+0x1e1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1917, 0x1e1d, x86_l_1e1d);
x86_l_191d:
	/* 0x191d: mov    bpl,al */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1920:
	/* 0x1920: shl    ebp,0x12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 18ULL);
x86_l_1923:
	/* 0x1923: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1926:
	/* 0x1926: add    rax,0x100 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 256ULL);
x86_l_192c:
	/* 0x192c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_192f:
	/* 0x192f: jns    1a90 <event_execve+0x1a90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x192f, 0x1a90, x86_l_1a90);
x86_l_1935:
	/* 0x1935: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1938:
	/* 0x1938: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_193b:
	/* 0x193b: je     1a90 <event_execve+0x1a90> */
	X86_SIM_X86_JCC(X86_CC_E, 0x193b, 0x1a90, x86_l_1a90);
x86_l_1941:
	/* 0x1941: add    rax,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_1945:
	/* 0x1945: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1948:
	/* 0x1948: jns    1a90 <event_execve+0x1a90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1948, 0x1a90, x86_l_1a90);
x86_l_194e:
	/* 0x194e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1951:
	/* 0x1951: mov    QWORD PTR [rbx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1954:
	/* 0x1954: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1957:
	/* 0x1957: jne    18a2 <event_execve+0x18a2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1957, 0x18a2, x86_l_18a2);
x86_l_195d:
	/* 0x195d: jmp    1a97 <event_execve+0x1a97> */
	X86_SIM_X86_JMP(0x195d, 0x1a97, x86_l_1a97);
x86_l_1962:
	/* 0x1962: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1967:
	/* 0x1967: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_196c:
	/* 0x196c: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_196f:
	/* 0x196f: call   1974 <event_execve+0x1974> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1974:
	/* 0x1974: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1979:
	/* 0x1979: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_197c:
	/* 0x197c: je     130e <event_execve+0x130e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x197c, 0x130e, x86_l_130e);
x86_l_1982:
	/* 0x1982: add    rdx,0x2c8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 712ULL);
x86_l_1989:
	/* 0x1989: jns    19c4 <event_execve+0x19c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1989, 0x19c4, x86_l_19c4);
x86_l_198b:
	/* 0x198b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_198e:
	/* 0x198e: jns    19d8 <event_execve+0x19d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x198e, 0x19d8, x86_l_19d8);
x86_l_1990:
	/* 0x1990: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1993:
	/* 0x1993: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1997:
	/* 0x1997: mov    edx,0x2d0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 720ULL);
x86_l_199c:
	/* 0x199c: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_19a1:
	/* 0x19a1: js     1a30 <event_execve+0x1a30> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19a1, 0x1a30, x86_l_1a30);
x86_l_19a7:
	/* 0x19a7: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ac:
	/* 0x19ac: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_19b1:
	/* 0x19b1: call   19b6 <event_execve+0x19b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_19b6:
	/* 0x19b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19b9:
	/* 0x19b9: jne    1a52 <event_execve+0x1a52> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19b9, 0x1a52, x86_l_1a52);
x86_l_19bf:
	/* 0x19bf: jmp    1b44 <event_execve+0x1b44> */
	X86_SIM_X86_JMP(0x19bf, 0x1b44, x86_l_1b44);
x86_l_19c4:
	/* 0x19c4: mov    rdi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_19c7:
	/* 0x19c7: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_19cc:
	/* 0x19cc: call   19d1 <event_execve+0x19d1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_19d1:
	/* 0x19d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19d4:
	/* 0x19d4: jne    19e7 <event_execve+0x19e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19d4, 0x19e7, x86_l_19e7);
x86_l_19d6:
	/* 0x19d6: jmp    1a20 <event_execve+0x1a20> */
	X86_SIM_X86_JMP(0x19d6, 0x1a20, x86_l_1a20);
x86_l_19d8:
	/* 0x19d8: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19e0:
	/* 0x19e0: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_19e7:
	/* 0x19e7: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_19e9:
	/* 0x19e9: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19ee:
	/* 0x19ee: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_19f5:
	/* 0x19f5: movabs rax,0x40000009a */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869338ULL);
x86_l_19ff:
	/* 0x19ff: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1a04:
	/* 0x1a04: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_1a0b:
	/* 0x1a0b: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a10:
	/* 0x1a10: call   1a15 <event_execve+0x1a15> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a15:
	/* 0x1a15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a18:
	/* 0x1a18: je     1aef <event_execve+0x1aef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a18, 0x1aef, x86_l_1aef);
x86_l_1a1e:
	/* 0x1a1e: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1a20:
	/* 0x1a20: mov    edx,0x2d0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 720ULL);
x86_l_1a25:
	/* 0x1a25: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1a2a:
	/* 0x1a2a: jns    19a7 <event_execve+0x19a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a2a, 0x19a7, x86_l_19a7);
x86_l_1a30:
	/* 0x1a30: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a33:
	/* 0x1a33: jns    1a42 <event_execve+0x1a42> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a33, 0x1a42, x86_l_1a42);
x86_l_1a35:
	/* 0x1a35: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a38:
	/* 0x1a38: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3d:
	/* 0x1a3d: jmp    1b44 <event_execve+0x1b44> */
	X86_SIM_X86_JMP(0x1a3d, 0x1b44, x86_l_1b44);
x86_l_1a42:
	/* 0x1a42: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1a4b:
	/* 0x1a4b: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_1a52:
	/* 0x1a52: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_1a54:
	/* 0x1a54: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a59:
	/* 0x1a59: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
x86_l_1a60:
	/* 0x1a60: movabs rax,0x40000009b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 17179869339ULL);
x86_l_1a6a:
	/* 0x1a6a: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1a6f:
	/* 0x1a6f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_1a76:
	/* 0x1a76: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a7b:
	/* 0x1a7b: call   1a80 <event_execve+0x1a80> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a80:
	/* 0x1a80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a83:
	/* 0x1a83: je     1b24 <event_execve+0x1b24> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a83, 0x1b24, x86_l_1b24);
x86_l_1a89:
	/* 0x1a89: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1a8b:
	/* 0x1a8b: jmp    1b44 <event_execve+0x1b44> */
	X86_SIM_X86_JMP(0x1a8b, 0x1b44, x86_l_1b44);
x86_l_1a90:
	/* 0x1a90: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a97:
	/* 0x1a97: or     ebp,0x200000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2097152ULL);
x86_l_1a9d:
	/* 0x1a9d: add    r12,0x100 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 256ULL);
x86_l_1aa4:
	/* 0x1aa4: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1aa7:
	/* 0x1aa7: jns    18d8 <event_execve+0x18d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aa7, 0x18d8, x86_l_18d8);
x86_l_1aad:
	/* 0x1aad: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab1:
	/* 0x1ab1: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1ab5:
	/* 0x1ab5: mov    r15d,0x10000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 65536ULL);
x86_l_1abb:
	/* 0x1abb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1abe:
	/* 0x1abe: jns    1e1a <event_execve+0x1e1a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1abe, 0x1e1a, x86_l_1e1a);
x86_l_1ac4:
	/* 0x1ac4: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ac7:
	/* 0x1ac7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1aca:
	/* 0x1aca: je     1e1a <event_execve+0x1e1a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aca, 0x1e1a, x86_l_1e1a);
x86_l_1ad0:
	/* 0x1ad0: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ad3:
	/* 0x1ad3: add    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1ad7:
	/* 0x1ad7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ada:
	/* 0x1ada: js     1cf4 <event_execve+0x1cf4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ada, 0x1cf4, x86_l_1cf4);
x86_l_1ae0:
	/* 0x1ae0: mov    esi,0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 128ULL);
x86_l_1ae5:
	/* 0x1ae5: call   1aea <event_execve+0x1aea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1aea:
	/* 0x1aea: jmp    1e17 <event_execve+0x1e17> */
	X86_SIM_X86_JMP(0x1aea, 0x1e17, x86_l_1e17);
x86_l_1aef:
	/* 0x1aef: mov    DWORD PTR [rsp+0x8],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738369ULL);
x86_l_1af7:
	/* 0x1af7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_1afe:
	/* 0x1afe: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b03:
	/* 0x1b03: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b08:
	/* 0x1b08: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b0a:
	/* 0x1b0a: call   1b0f <event_execve+0x1b0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1b0f:
	/* 0x1b0f: mov    edx,0x2d0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 720ULL);
x86_l_1b14:
	/* 0x1b14: add    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1b19:
	/* 0x1b19: js     1a30 <event_execve+0x1a30> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b19, 0x1a30, x86_l_1a30);
x86_l_1b1f:
	/* 0x1b1f: jmp    19a7 <event_execve+0x19a7> */
	X86_SIM_X86_JMP(0x1b1f, 0x19a7, x86_l_19a7);
x86_l_1b24:
	/* 0x1b24: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
x86_l_1b2c:
	/* 0x1b2c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_1b33:
	/* 0x1b33: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b38:
	/* 0x1b38: lea    rdx,[rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1b3d:
	/* 0x1b3d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b3f:
	/* 0x1b3f: call   1b44 <event_execve+0x1b44> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1b44:
	/* 0x1b44: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b48:
	/* 0x1b48: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b4b:
	/* 0x1b4b: je     130e <event_execve+0x130e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b4b, 0x130e, x86_l_130e);
x86_l_1b51:
	/* 0x1b51: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b56:
	/* 0x1b56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b59:
	/* 0x1b59: je     130e <event_execve+0x130e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b59, 0x130e, x86_l_130e);
x86_l_1b5f:
	/* 0x1b5f: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1b61:
	/* 0x1b61: lea    rsi,[r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1b65:
	/* 0x1b65: add    rsi,0x140 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 320ULL);
x86_l_1b6c:
	/* 0x1b6c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b6f:
	/* 0x1b6f: sub    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1b72:
	/* 0x1b72: cmp    rcx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 1023ULL);
x86_l_1b79:
	/* 0x1b79: ja     1bb6 <event_execve+0x1bb6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b79, 0x1bb6, x86_l_1bb6);
x86_l_1b7b:
	/* 0x1b7b: lea    rdi,[r14+0x540] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1344ULL);
x86_l_1b82:
	/* 0x1b82: sub    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1b85:
	/* 0x1b85: cmp    rcx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b88:
	/* 0x1b88: jae    1bb6 <event_execve+0x1bb6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1b88, 0x1bb6, x86_l_1bb6);
x86_l_1b8a:
	/* 0x1b8a: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b8d:
	/* 0x1b8d: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b90:
	/* 0x1b90: je     1b9d <event_execve+0x1b9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b90, 0x1b9d, x86_l_1b9d);
x86_l_1b92:
	/* 0x1b92: dec    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1b94:
	/* 0x1b94: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_1b9a:
	/* 0x1b9a: mov    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1b9d:
	/* 0x1b9d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ba0:
	/* 0x1ba0: js     1c9f <event_execve+0x1c9f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ba0, 0x1c9f, x86_l_1c9f);
x86_l_1ba6:
	/* 0x1ba6: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ba9:
	/* 0x1ba9: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1bac:
	/* 0x1bac: call   1bb1 <event_execve+0x1bb1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1bb1:
	/* 0x1bb1: jmp    1d6d <event_execve+0x1d6d> */
	X86_SIM_X86_JMP(0x1bb1, 0x1d6d, x86_l_1d6d);
x86_l_1bb6:
	/* 0x1bb6: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1bbb:
	/* 0x1bbb: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_l_229b, 0x1bc0ULL);
x86_l_1bc0:
	/* 0x1bc0: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bc3:
	/* 0x1bc3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc5:
	/* 0x1bc5: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1bc8:
	/* 0x1bc8: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1bcb:
	/* 0x1bcb: add    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1bcd:
	/* 0x1bcd: jmp    1d7a <event_execve+0x1d7a> */
	X86_SIM_X86_JMP(0x1bcd, 0x1d7a, x86_l_1d7a);
x86_l_1bd2:
	/* 0x1bd2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bd4:
	/* 0x1bd4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bd6:
	/* 0x1bd6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bd9:
	/* 0x1bd9: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bd9, 0x21d7, x86_l_21d7);
x86_l_1bdf:
	/* 0x1bdf: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1be6:
	/* 0x1be6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1be9:
	/* 0x1be9: jns    1bed <event_execve+0x1bed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1be9, 0x1bed, x86_l_1bed);
x86_l_1beb:
	/* 0x1beb: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bed:
	/* 0x1bed: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1bef:
	/* 0x1bef: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bef, 0x219c, x86_l_219c);
x86_l_1bf5:
	/* 0x1bf5: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1bfb:
	/* 0x1bfb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bfe:
	/* 0x1bfe: jns    1d1f <event_execve+0x1d1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bfe, 0x1d1f, x86_l_1d1f);
x86_l_1c04:
	/* 0x1c04: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c07:
	/* 0x1c07: jmp    1d21 <event_execve+0x1d21> */
	X86_SIM_X86_JMP(0x1c07, 0x1d21, x86_l_1d21);
x86_l_1c0c:
	/* 0x1c0c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c0e:
	/* 0x1c0e: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c12:
	/* 0x1c12: add    r12,0x100 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 256ULL);
x86_l_1c19:
	/* 0x1c19: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1c1c:
	/* 0x1c1c: js     1aad <event_execve+0x1aad> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c1c, 0x1aad, x86_l_1aad);
x86_l_1c22:
	/* 0x1c22: jmp    18d8 <event_execve+0x18d8> */
	X86_SIM_X86_JMP(0x1c22, 0x18d8, x86_l_18d8);
x86_l_1c27:
	/* 0x1c27: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c29:
	/* 0x1c29: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1c2c:
	/* 0x1c2c: jne    ce2 <event_execve+0xce2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c2c, 0xce2, x86_l_ce2);
x86_l_1c32:
	/* 0x1c32: jmp    cc2 <event_execve+0xcc2> */
	X86_SIM_X86_JMP(0x1c32, 0xcc2, x86_l_cc2);
x86_l_1c37:
	/* 0x1c37: mov    BYTE PTR [rsp+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991233ULL);
x86_l_1c3c:
	/* 0x1c3c: mov    rcx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c41:
	/* 0x1c41: mov    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1c49:
	/* 0x1c49: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c4c:
	/* 0x1c4c: jne    11df <event_execve+0x11df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c4c, 0x11df, x86_l_11df);
x86_l_1c52:
	/* 0x1c52: jmp    11bd <event_execve+0x11bd> */
	X86_SIM_X86_JMP(0x1c52, 0x11bd, x86_l_11bd);
x86_l_1c57:
	/* 0x1c57: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1c59:
	/* 0x1c59: mov    esi,DWORD PTR [r9+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1c5d:
	/* 0x1c5d: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1c60:
	/* 0x1c60: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1c63:
	/* 0x1c63: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c65:
	/* 0x1c65: je     1269 <event_execve+0x1269> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c65, 0x1269, x86_l_1269);
x86_l_1c6b:
	/* 0x1c6b: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1c6d:
	/* 0x1c6d: movzx  esi,WORD PTR [r9+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_1c72:
	/* 0x1c72: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1c76:
	/* 0x1c76: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1c79:
	/* 0x1c79: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1c7b:
	/* 0x1c7b: je     1284 <event_execve+0x1284> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c7b, 0x1284, x86_l_1284);
x86_l_1c81:
	/* 0x1c81: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1c83:
	/* 0x1c83: movzx  ecx,BYTE PTR [r9+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1c88:
	/* 0x1c88: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1c8b:
	/* 0x1c8b: mov    eax,DWORD PTR [r14+0x15c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 348ULL);
x86_l_1c92:
	/* 0x1c92: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1c94:
	/* 0x1c94: jne    1298 <event_execve+0x1298> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c94, 0x1298, x86_l_1298);
x86_l_1c9a:
	/* 0x1c9a: jmp    129d <event_execve+0x129d> */
	X86_SIM_X86_JMP(0x1c9a, 0x129d, x86_l_129d);
x86_l_1c9f:
	/* 0x1c9f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ca2:
	/* 0x1ca2: jns    1d59 <event_execve+0x1d59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca2, 0x1d59, x86_l_1d59);
x86_l_1ca8:
	/* 0x1ca8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1caa:
	/* 0x1caa: cmp    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1cae:
	/* 0x1cae: jb     1ccd <event_execve+0x1ccd> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cae, 0x1ccd, x86_l_1ccd);
x86_l_1cb0:
	/* 0x1cb0: mov    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1cb3:
	/* 0x1cb3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cb5:
	/* 0x1cb5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb8:
	/* 0x1cb8: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1cbc:
	/* 0x1cbc: mov    QWORD PTR [rsi+rdi*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_1cc0:
	/* 0x1cc0: lea    rax,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cc4:
	/* 0x1cc4: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1cc8:
	/* 0x1cc8: cmp    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ccb:
	/* 0x1ccb: jbe    1cb5 <event_execve+0x1cb5> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1ccb, 0x1cb5, x86_l_1cb5);
x86_l_1ccd:
	/* 0x1ccd: test   r13b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1cd1:
	/* 0x1cd1: jne    1e63 <event_execve+0x1e63> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cd1, 0x1e63, x86_l_1e63);
x86_l_1cd7:
	/* 0x1cd7: test   r13b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1cdb:
	/* 0x1cdb: jne    1e78 <event_execve+0x1e78> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cdb, 0x1e78, x86_l_1e78);
x86_l_1ce1:
	/* 0x1ce1: test   r13b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1ce5:
	/* 0x1ce5: je     1cf0 <event_execve+0x1cf0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce5, 0x1cf0, x86_l_1cf0);
x86_l_1ce7:
	/* 0x1ce7: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1ce9:
	/* 0x1ce9: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1ced:
	/* 0x1ced: mov    BYTE PTR [rsi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1cf0:
	/* 0x1cf0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cf2:
	/* 0x1cf2: jmp    1d6d <event_execve+0x1d6d> */
	X86_SIM_X86_JMP(0x1cf2, 0x1d6d, x86_l_1d6d);
x86_l_1cf4:
	/* 0x1cf4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cf7:
	/* 0x1cf7: jns    1d8e <event_execve+0x1d8e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cf7, 0x1d8e, x86_l_1d8e);
x86_l_1cfd:
	/* 0x1cfd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cff:
	/* 0x1cff: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_1d03:
	/* 0x1d03: je     1e0f <event_execve+0x1e0f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d03, 0x1e0f, x86_l_1e0f);
x86_l_1d09:
	/* 0x1d09: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1d0d:
	/* 0x1d0d: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1d10:
	/* 0x1d10: inc    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1d13:
	/* 0x1d13: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d16:
	/* 0x1d16: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1d18:
	/* 0x1d18: jne    1cff <event_execve+0x1cff> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d18, 0x1cff, x86_l_1cff);
x86_l_1d1a:
	/* 0x1d1a: jmp    1e1a <event_execve+0x1e1a> */
	X86_SIM_X86_JMP(0x1d1a, 0x1e1a, x86_l_1e1a);
x86_l_1d1f:
	/* 0x1d1f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d21:
	/* 0x1d21: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d23:
	/* 0x1d23: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d26:
	/* 0x1d26: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d26, 0x21ab, x86_l_21ab);
x86_l_1d2c:
	/* 0x1d2c: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1d33:
	/* 0x1d33: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d36:
	/* 0x1d36: jns    1d3a <event_execve+0x1d3a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d36, 0x1d3a, x86_l_1d3a);
x86_l_1d38:
	/* 0x1d38: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d3a:
	/* 0x1d3a: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d3c:
	/* 0x1d3c: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d3c, 0x219c, x86_l_219c);
x86_l_1d42:
	/* 0x1d42: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1d48:
	/* 0x1d48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d4b:
	/* 0x1d4b: jns    1e94 <event_execve+0x1e94> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d4b, 0x1e94, x86_l_1e94);
x86_l_1d51:
	/* 0x1d51: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d54:
	/* 0x1d54: jmp    1e96 <event_execve+0x1e96> */
	X86_SIM_X86_JMP(0x1d54, 0x1e96, x86_l_1e96);
x86_l_1d59:
	/* 0x1d59: mov    edx,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1d5c:
	/* 0x1d5c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d5f:
	/* 0x1d5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d61:
	/* 0x1d61: call   1d66 <event_execve+0x1d66> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1d66:
	/* 0x1d66: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_1d6d:
	/* 0x1d6d: and    eax,0x80000000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483648ULL);
x86_l_1d72:
	/* 0x1d72: je     1d77 <event_execve+0x1d77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d72, 0x1d77, x86_l_1d77);
x86_l_1d74:
	/* 0x1d74: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d77:
	/* 0x1d77: shr    eax,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
x86_l_1d7a:
	/* 0x1d7a: mov    WORD PTR [r14+0x17e],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 382ULL);
x86_l_1d82:
	/* 0x1d82: or     DWORD PTR [r14+0x15c],eax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
x86_l_1d89:
	/* 0x1d89: jmp    130e <event_execve+0x130e> */
	X86_SIM_X86_JMP(0x1d89, 0x130e, x86_l_130e);
x86_l_1d8e:
	/* 0x1d8e: mov    QWORD PTR [rdi+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_1d96:
	/* 0x1d96: mov    QWORD PTR [rdi+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_1d9e:
	/* 0x1d9e: mov    QWORD PTR [rdi+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1da6:
	/* 0x1da6: mov    QWORD PTR [rdi+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1dae:
	/* 0x1dae: mov    QWORD PTR [rdi+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_1db6:
	/* 0x1db6: mov    QWORD PTR [rdi+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1dbe:
	/* 0x1dbe: mov    QWORD PTR [rdi+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1dc6:
	/* 0x1dc6: mov    QWORD PTR [rdi+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1dce:
	/* 0x1dce: mov    QWORD PTR [rdi+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1dd6:
	/* 0x1dd6: mov    QWORD PTR [rdi+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1dde:
	/* 0x1dde: mov    QWORD PTR [rdi+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1de6:
	/* 0x1de6: mov    QWORD PTR [rdi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1dee:
	/* 0x1dee: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1df6:
	/* 0x1df6: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1dfe:
	/* 0x1dfe: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1e06:
	/* 0x1e06: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e0d:
	/* 0x1e0d: jmp    1e17 <event_execve+0x1e17> */
	X86_SIM_X86_JMP(0x1e0d, 0x1e17, x86_l_1e17);
x86_l_1e0f:
	/* 0x1e0f: mov    BYTE PTR [r14+0x9f],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 682899800064ULL);
x86_l_1e17:
	/* 0x1e17: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e1a:
	/* 0x1e1a: or     r15d,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_32, X86_ALU_OR, 0);
x86_l_1e1d:
	/* 0x1e1d: or     DWORD PTR [r14+0x15c],r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R14, X86_R15, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
x86_l_1e24:
	/* 0x1e24: mov    QWORD PTR [r14+0x130],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1305670057984ULL);
x86_l_1e2f:
	/* 0x1e2f: mov    QWORD PTR [r14+0x138],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1340029796352ULL);
x86_l_1e3a:
	/* 0x1e3a: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_calls));
x86_l_1e41:
	/* 0x1e41: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e44:
	/* 0x1e44: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e46:
	/* 0x1e46: call   1e4b <event_execve+0x1e4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_1e4b:
	/* 0x1e4b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e4d:
	/* 0x1e4d: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_1e54:
	/* 0x1e54: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e55:
	/* 0x1e55: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e57:
	/* 0x1e57: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e59:
	/* 0x1e59: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e5b:
	/* 0x1e5b: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e5d:
	/* 0x1e5d: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e5e:
	/* 0x1e5e: jmp    2c88 <__do_str+0x1f5> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1e63:
	/* 0x1e63: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1e65:
	/* 0x1e65: mov    edi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1e68:
	/* 0x1e68: mov    DWORD PTR [rsi+rcx*1],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1e6b:
	/* 0x1e6b: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1e6e:
	/* 0x1e6e: test   r13b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1e72:
	/* 0x1e72: je     1ce1 <event_execve+0x1ce1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e72, 0x1ce1, x86_l_1ce1);
x86_l_1e78:
	/* 0x1e78: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1e7a:
	/* 0x1e7a: movzx  edi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_1e7e:
	/* 0x1e7e: mov    WORD PTR [rsi+rcx*1],di */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1e82:
	/* 0x1e82: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1e85:
	/* 0x1e85: test   r13b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1e89:
	/* 0x1e89: je     1cf0 <event_execve+0x1cf0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e89, 0x1cf0, x86_l_1cf0);
x86_l_1e8f:
	/* 0x1e8f: jmp    1ce7 <event_execve+0x1ce7> */
	X86_SIM_X86_JMP(0x1e8f, 0x1ce7, x86_l_1ce7);
x86_l_1e94:
	/* 0x1e94: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e96:
	/* 0x1e96: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e98:
	/* 0x1e98: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e9b:
	/* 0x1e9b: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e9b, 0x21d7, x86_l_21d7);
x86_l_1ea1:
	/* 0x1ea1: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1ea8:
	/* 0x1ea8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1eab:
	/* 0x1eab: jns    1eaf <event_execve+0x1eaf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eab, 0x1eaf, x86_l_1eaf);
x86_l_1ead:
	/* 0x1ead: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eaf:
	/* 0x1eaf: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1eb1:
	/* 0x1eb1: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eb1, 0x219c, x86_l_219c);
x86_l_1eb7:
	/* 0x1eb7: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1ebd:
	/* 0x1ebd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ec0:
	/* 0x1ec0: jns    1ec7 <event_execve+0x1ec7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ec0, 0x1ec7, x86_l_1ec7);
x86_l_1ec2:
	/* 0x1ec2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ec5:
	/* 0x1ec5: jmp    1ec9 <event_execve+0x1ec9> */
	X86_SIM_X86_JMP(0x1ec5, 0x1ec9, x86_l_1ec9);
x86_l_1ec7:
	/* 0x1ec7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec9:
	/* 0x1ec9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ecb:
	/* 0x1ecb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ece:
	/* 0x1ece: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ece, 0x21ab, x86_l_21ab);
x86_l_1ed4:
	/* 0x1ed4: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1edb:
	/* 0x1edb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ede:
	/* 0x1ede: jns    1ee2 <event_execve+0x1ee2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ede, 0x1ee2, x86_l_1ee2);
x86_l_1ee0:
	/* 0x1ee0: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee2:
	/* 0x1ee2: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1ee4:
	/* 0x1ee4: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee4, 0x219c, x86_l_219c);
x86_l_1eea:
	/* 0x1eea: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1ef0:
	/* 0x1ef0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ef3:
	/* 0x1ef3: jns    1efa <event_execve+0x1efa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ef3, 0x1efa, x86_l_1efa);
x86_l_1ef5:
	/* 0x1ef5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ef8:
	/* 0x1ef8: jmp    1efc <event_execve+0x1efc> */
	X86_SIM_X86_JMP(0x1ef8, 0x1efc, x86_l_1efc);
x86_l_1efa:
	/* 0x1efa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1efc:
	/* 0x1efc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1efe:
	/* 0x1efe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f01:
	/* 0x1f01: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f01, 0x21d7, x86_l_21d7);
x86_l_1f07:
	/* 0x1f07: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1f0e:
	/* 0x1f0e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f11:
	/* 0x1f11: jns    1f15 <event_execve+0x1f15> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f11, 0x1f15, x86_l_1f15);
x86_l_1f13:
	/* 0x1f13: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f15:
	/* 0x1f15: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f17:
	/* 0x1f17: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f17, 0x219c, x86_l_219c);
x86_l_1f1d:
	/* 0x1f1d: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1f23:
	/* 0x1f23: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f26:
	/* 0x1f26: jns    1f2d <event_execve+0x1f2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f26, 0x1f2d, x86_l_1f2d);
x86_l_1f28:
	/* 0x1f28: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f2b:
	/* 0x1f2b: jmp    1f2f <event_execve+0x1f2f> */
	X86_SIM_X86_JMP(0x1f2b, 0x1f2f, x86_l_1f2f);
x86_l_1f2d:
	/* 0x1f2d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f2f:
	/* 0x1f2f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f31:
	/* 0x1f31: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f34:
	/* 0x1f34: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f34, 0x21ab, x86_l_21ab);
x86_l_1f3a:
	/* 0x1f3a: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1f41:
	/* 0x1f41: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f44:
	/* 0x1f44: jns    1f48 <event_execve+0x1f48> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f44, 0x1f48, x86_l_1f48);
x86_l_1f46:
	/* 0x1f46: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f48:
	/* 0x1f48: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f4a:
	/* 0x1f4a: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f4a, 0x219c, x86_l_219c);
x86_l_1f50:
	/* 0x1f50: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1f56:
	/* 0x1f56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f59:
	/* 0x1f59: jns    1f60 <event_execve+0x1f60> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f59, 0x1f60, x86_l_1f60);
x86_l_1f5b:
	/* 0x1f5b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5e:
	/* 0x1f5e: jmp    1f62 <event_execve+0x1f62> */
	X86_SIM_X86_JMP(0x1f5e, 0x1f62, x86_l_1f62);
x86_l_1f60:
	/* 0x1f60: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f62:
	/* 0x1f62: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f64:
	/* 0x1f64: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f67:
	/* 0x1f67: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f67, 0x21d7, x86_l_21d7);
x86_l_1f6d:
	/* 0x1f6d: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1f74:
	/* 0x1f74: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f77:
	/* 0x1f77: jns    1f7b <event_execve+0x1f7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f77, 0x1f7b, x86_l_1f7b);
x86_l_1f79:
	/* 0x1f79: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f7b:
	/* 0x1f7b: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f7d:
	/* 0x1f7d: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7d, 0x219c, x86_l_219c);
x86_l_1f83:
	/* 0x1f83: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1f89:
	/* 0x1f89: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f8c:
	/* 0x1f8c: jns    1f93 <event_execve+0x1f93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f8c, 0x1f93, x86_l_1f93);
x86_l_1f8e:
	/* 0x1f8e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f91:
	/* 0x1f91: jmp    1f95 <event_execve+0x1f95> */
	X86_SIM_X86_JMP(0x1f91, 0x1f95, x86_l_1f95);
x86_l_1f93:
	/* 0x1f93: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f95:
	/* 0x1f95: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f97:
	/* 0x1f97: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f9a:
	/* 0x1f9a: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9a, 0x21ab, x86_l_21ab);
x86_l_1fa0:
	/* 0x1fa0: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1fa7:
	/* 0x1fa7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1faa:
	/* 0x1faa: jns    1fae <event_execve+0x1fae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1faa, 0x1fae, x86_l_1fae);
x86_l_1fac:
	/* 0x1fac: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fae:
	/* 0x1fae: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1fb0:
	/* 0x1fb0: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb0, 0x219c, x86_l_219c);
x86_l_1fb6:
	/* 0x1fb6: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1fbc:
	/* 0x1fbc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fbf:
	/* 0x1fbf: jns    1fc6 <event_execve+0x1fc6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fbf, 0x1fc6, x86_l_1fc6);
x86_l_1fc1:
	/* 0x1fc1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc4:
	/* 0x1fc4: jmp    1fc8 <event_execve+0x1fc8> */
	X86_SIM_X86_JMP(0x1fc4, 0x1fc8, x86_l_1fc8);
x86_l_1fc6:
	/* 0x1fc6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fc8:
	/* 0x1fc8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fca:
	/* 0x1fca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fcd:
	/* 0x1fcd: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fcd, 0x21d7, x86_l_21d7);
x86_l_1fd3:
	/* 0x1fd3: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_1fda:
	/* 0x1fda: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fdd:
	/* 0x1fdd: jns    1fe1 <event_execve+0x1fe1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fdd, 0x1fe1, x86_l_1fe1);
x86_l_1fdf:
	/* 0x1fdf: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe1:
	/* 0x1fe1: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1fe3:
	/* 0x1fe3: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe3, 0x219c, x86_l_219c);
x86_l_1fe9:
	/* 0x1fe9: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_1fef:
	/* 0x1fef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ff2:
	/* 0x1ff2: jns    1ff9 <event_execve+0x1ff9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff2, 0x1ff9, x86_l_1ff9);
x86_l_1ff4:
	/* 0x1ff4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff7:
	/* 0x1ff7: jmp    1ffb <event_execve+0x1ffb> */
	X86_SIM_X86_JMP(0x1ff7, 0x1ffb, x86_l_1ffb);
x86_l_1ff9:
	/* 0x1ff9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ffb:
	/* 0x1ffb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ffd:
	/* 0x1ffd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2000:
	/* 0x2000: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2000, 0x21ab, x86_l_21ab);
x86_l_2006:
	/* 0x2006: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_200d:
	/* 0x200d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2010:
	/* 0x2010: jns    2014 <event_execve+0x2014> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2010, 0x2014, x86_l_2014);
x86_l_2012:
	/* 0x2012: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2014:
	/* 0x2014: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2016:
	/* 0x2016: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2016, 0x219c, x86_l_219c);
x86_l_201c:
	/* 0x201c: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_2022:
	/* 0x2022: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2025:
	/* 0x2025: jns    202c <event_execve+0x202c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2025, 0x202c, x86_l_202c);
x86_l_2027:
	/* 0x2027: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_202a:
	/* 0x202a: jmp    202e <event_execve+0x202e> */
	X86_SIM_X86_JMP(0x202a, 0x202e, x86_l_202e);
x86_l_202c:
	/* 0x202c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_202e:
	/* 0x202e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2030:
	/* 0x2030: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2033:
	/* 0x2033: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2033, 0x21d7, x86_l_21d7);
x86_l_2039:
	/* 0x2039: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_2040:
	/* 0x2040: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2043:
	/* 0x2043: jns    2047 <event_execve+0x2047> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2043, 0x2047, x86_l_2047);
x86_l_2045:
	/* 0x2045: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2047:
	/* 0x2047: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2049:
	/* 0x2049: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2049, 0x219c, x86_l_219c);
x86_l_204f:
	/* 0x204f: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_2055:
	/* 0x2055: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2058:
	/* 0x2058: jns    205f <event_execve+0x205f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2058, 0x205f, x86_l_205f);
x86_l_205a:
	/* 0x205a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_205d:
	/* 0x205d: jmp    2061 <event_execve+0x2061> */
	X86_SIM_X86_JMP(0x205d, 0x2061, x86_l_2061);
x86_l_205f:
	/* 0x205f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2061:
	/* 0x2061: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2063:
	/* 0x2063: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2066:
	/* 0x2066: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2066, 0x21ab, x86_l_21ab);
x86_l_206c:
	/* 0x206c: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_2073:
	/* 0x2073: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2076:
	/* 0x2076: jns    207a <event_execve+0x207a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2076, 0x207a, x86_l_207a);
x86_l_2078:
	/* 0x2078: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_207a:
	/* 0x207a: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_207c:
	/* 0x207c: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207c, 0x219c, x86_l_219c);
x86_l_2082:
	/* 0x2082: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_2088:
	/* 0x2088: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_208b:
	/* 0x208b: jns    2092 <event_execve+0x2092> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x208b, 0x2092, x86_l_2092);
x86_l_208d:
	/* 0x208d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2090:
	/* 0x2090: jmp    2094 <event_execve+0x2094> */
	X86_SIM_X86_JMP(0x2090, 0x2094, x86_l_2094);
x86_l_2092:
	/* 0x2092: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2094:
	/* 0x2094: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2096:
	/* 0x2096: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2099:
	/* 0x2099: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2099, 0x21d7, x86_l_21d7);
x86_l_209f:
	/* 0x209f: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_20a6:
	/* 0x20a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20a9:
	/* 0x20a9: jns    20ad <event_execve+0x20ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20a9, 0x20ad, x86_l_20ad);
x86_l_20ab:
	/* 0x20ab: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20ad:
	/* 0x20ad: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20af:
	/* 0x20af: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20af, 0x219c, x86_l_219c);
x86_l_20b5:
	/* 0x20b5: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_20bb:
	/* 0x20bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20be:
	/* 0x20be: jns    20c5 <event_execve+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20be, 0x20c5, x86_l_20c5);
x86_l_20c0:
	/* 0x20c0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c3:
	/* 0x20c3: jmp    20c7 <event_execve+0x20c7> */
	X86_SIM_X86_JMP(0x20c3, 0x20c7, x86_l_20c7);
x86_l_20c5:
	/* 0x20c5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20c7:
	/* 0x20c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20c9:
	/* 0x20c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20cc:
	/* 0x20cc: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20cc, 0x21ab, x86_l_21ab);
x86_l_20d2:
	/* 0x20d2: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_20d9:
	/* 0x20d9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_20dc:
	/* 0x20dc: jns    20e0 <event_execve+0x20e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20dc, 0x20e0, x86_l_20e0);
x86_l_20de:
	/* 0x20de: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e0:
	/* 0x20e0: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20e2:
	/* 0x20e2: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e2, 0x219c, x86_l_219c);
x86_l_20e8:
	/* 0x20e8: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_20ee:
	/* 0x20ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20f1:
	/* 0x20f1: jns    20f8 <event_execve+0x20f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20f1, 0x20f8, x86_l_20f8);
x86_l_20f3:
	/* 0x20f3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20f6:
	/* 0x20f6: jmp    20fa <event_execve+0x20fa> */
	X86_SIM_X86_JMP(0x20f6, 0x20fa, x86_l_20fa);
x86_l_20f8:
	/* 0x20f8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20fa:
	/* 0x20fa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20fc:
	/* 0x20fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20ff:
	/* 0x20ff: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ff, 0x21d7, x86_l_21d7);
x86_l_2105:
	/* 0x2105: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_210c:
	/* 0x210c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_210f:
	/* 0x210f: jns    2113 <event_execve+0x2113> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x210f, 0x2113, x86_l_2113);
x86_l_2111:
	/* 0x2111: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2113:
	/* 0x2113: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2115:
	/* 0x2115: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2115, 0x219c, x86_l_219c);
x86_l_211b:
	/* 0x211b: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_2121:
	/* 0x2121: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2124:
	/* 0x2124: jns    212b <event_execve+0x212b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2124, 0x212b, x86_l_212b);
x86_l_2126:
	/* 0x2126: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2129:
	/* 0x2129: jmp    212d <event_execve+0x212d> */
	X86_SIM_X86_JMP(0x2129, 0x212d, x86_l_212d);
x86_l_212b:
	/* 0x212b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212d:
	/* 0x212d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212f:
	/* 0x212f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2132:
	/* 0x2132: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2132, 0x21ab, x86_l_21ab);
x86_l_2134:
	/* 0x2134: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_213b:
	/* 0x213b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_213e:
	/* 0x213e: jns    2142 <event_execve+0x2142> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x213e, 0x2142, x86_l_2142);
x86_l_2140:
	/* 0x2140: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2142:
	/* 0x2142: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2144:
	/* 0x2144: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2144, 0x219c, x86_l_219c);
x86_l_2146:
	/* 0x2146: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_214c:
	/* 0x214c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_214f:
	/* 0x214f: jns    2156 <event_execve+0x2156> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x214f, 0x2156, x86_l_2156);
x86_l_2151:
	/* 0x2151: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2154:
	/* 0x2154: jmp    2158 <event_execve+0x2158> */
	X86_SIM_X86_JMP(0x2154, 0x2158, x86_l_2158);
x86_l_2156:
	/* 0x2156: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2158:
	/* 0x2158: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215a:
	/* 0x215a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_215d:
	/* 0x215d: je     21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215d, 0x21d7, x86_l_21d7);
x86_l_215f:
	/* 0x215f: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_2166:
	/* 0x2166: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2169:
	/* 0x2169: jns    216d <event_execve+0x216d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2169, 0x216d, x86_l_216d);
x86_l_216b:
	/* 0x216b: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216d:
	/* 0x216d: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_216f:
	/* 0x216f: je     219c <event_execve+0x219c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x216f, 0x219c, x86_l_219c);
x86_l_2171:
	/* 0x2171: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_2177:
	/* 0x2177: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_217a:
	/* 0x217a: jns    2181 <event_execve+0x2181> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x217a, 0x2181, x86_l_2181);
x86_l_217c:
	/* 0x217c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217f:
	/* 0x217f: jmp    2183 <event_execve+0x2183> */
	X86_SIM_X86_JMP(0x217f, 0x2183, x86_l_2183);
x86_l_2181:
	/* 0x2181: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2183:
	/* 0x2183: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2185:
	/* 0x2185: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2188:
	/* 0x2188: je     21ab <event_execve+0x21ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2188, 0x21ab, x86_l_21ab);
x86_l_218a:
	/* 0x218a: lea    rdx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_2191:
	/* 0x2191: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2194:
	/* 0x2194: jns    2198 <event_execve+0x2198> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2194, 0x2198, x86_l_2198);
x86_l_2196:
	/* 0x2196: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2198:
	/* 0x2198: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_219a:
	/* 0x219a: jne    21bc <event_execve+0x21bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x219a, 0x21bc, x86_l_21bc);
x86_l_219c:
	/* 0x219c: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_219e:
	/* 0x219e: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21a0:
	/* 0x21a0: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a0, 0xb3b, x86_l_b3b);
x86_l_21a6:
	/* 0x21a6: jmp    b05 <event_execve+0xb05> */
	X86_SIM_X86_JMP(0x21a6, 0xb05, x86_l_b05);
x86_l_21ab:
	/* 0x21ab: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21ad:
	/* 0x21ad: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_21af:
	/* 0x21af: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21b1:
	/* 0x21b1: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b1, 0xb3b, x86_l_b3b);
x86_l_21b7:
	/* 0x21b7: jmp    b05 <event_execve+0xb05> */
	X86_SIM_X86_JMP(0x21b7, 0xb05, x86_l_b05);
x86_l_21bc:
	/* 0x21bc: add    rax,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_21c2:
	/* 0x21c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21c5:
	/* 0x21c5: jns    21d7 <event_execve+0x21d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21c5, 0x21d7, x86_l_21d7);
x86_l_21c7:
	/* 0x21c7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21ca:
	/* 0x21ca: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21cc:
	/* 0x21cc: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21cc, 0xb3b, x86_l_b3b);
x86_l_21d2:
	/* 0x21d2: jmp    b05 <event_execve+0xb05> */
	X86_SIM_X86_JMP(0x21d2, 0xb05, x86_l_b05);
x86_l_21d7:
	/* 0x21d7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d9:
	/* 0x21d9: cmp    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21db:
	/* 0x21db: je     b3b <event_execve+0xb3b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21db, 0xb3b, x86_l_b3b);
x86_l_21e1:
	/* 0x21e1: jmp    b05 <event_execve+0xb05> */
	X86_SIM_X86_JMP(0x21e1, 0xb05, x86_l_b05);
x86_l_2c88:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_21e6 */
x86_l_21e6:
	/* 0x21e6: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_21e8:
	/* 0x21e8: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_21ea:
	/* 0x21ea: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21ec:
	/* 0x21ec: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_21ee:
	/* 0x21ee: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21ef:
	/* 0x21ef: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_21f3:
	/* 0x21f3: mov    r14,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21f6:
	/* 0x21f6: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21f9:
	/* 0x21f9: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21fc:
	/* 0x21fc: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2204:
	/* 0x2204: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data_heap));
x86_l_220b:
	/* 0x220b: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2210:
	/* 0x2210: call   2215 <data_event_str+0x2f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2215:
	/* 0x2215: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2218:
	/* 0x2218: je     228b <data_event_str+0xa5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2218, 0x228b, x86_l_228b);
x86_l_221a:
	/* 0x221a: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_221d:
	/* 0x221d: mov    DWORD PTR [rax],0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2223:
	/* 0x2223: call   2228 <data_event_str+0x42> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_2228:
	/* 0x2228: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_222b:
	/* 0x222b: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_222f:
	/* 0x222f: mov    QWORD PTR [r12+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2234:
	/* 0x2234: cmp    rax,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2238:
	/* 0x2238: jne    2242 <data_event_str+0x5c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2238, 0x2242, x86_l_2242);
x86_l_223a:
	/* 0x223a: mov    rax,QWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_223e:
	/* 0x223e: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2242:
	/* 0x2242: call   2247 <data_event_str+0x61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_2247:
	/* 0x2247: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_224c:
	/* 0x224c: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2250:
	/* 0x2250: mov    rcx,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2254:
	/* 0x2254: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2258:
	/* 0x2258: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_225c:
	/* 0x225c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_225f:
	/* 0x225f: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2262:
	/* 0x2262: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2265:
	/* 0x2265: call   2a30 <do_str> */
	X86_SIM_X86_CALL(x86_l_2a30, 0x226aULL);
x86_l_226a:
	/* 0x226a: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_226c:
	/* 0x226c: sar    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 31ULL);
x86_l_226f:
	/* 0x226f: and    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_AND, 0);
x86_l_2271:
	/* 0x2271: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2273:
	/* 0x2273: jg     2277 <data_event_str+0x91> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2273, 0x2277, x86_l_2277);
x86_l_2275:
	/* 0x2275: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2277:
	/* 0x2277: mov    DWORD PTR [rbx],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2279:
	/* 0x2279: mov    QWORD PTR [rbx+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_2281:
	/* 0x2281: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2284:
	/* 0x2284: mov    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2289:
	/* 0x2289: jmp    228d <data_event_str+0xa7> */
	X86_SIM_X86_SUB_JMP(0x2289, 0x228d, x86_l_228d);
x86_l_228b:
	/* 0x228b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_228d:
	/* 0x228d: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2291:
	/* 0x2291: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2292:
	/* 0x2292: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2294:
	/* 0x2294: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2296:
	/* 0x2296: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2298:
	/* 0x2298: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_229a:
	/* 0x229a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_229a);

	/* native subroutine native_link_sub_229b */
x86_l_229b:
	/* 0x229b: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_229c:
	/* 0x229c: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_229e:
	/* 0x229e: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_22a0:
	/* 0x22a0: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_22a2:
	/* 0x22a2: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_22a4:
	/* 0x22a4: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_22a5:
	/* 0x22a5: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22a6:
	/* 0x22a6: mov    r14,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22a9:
	/* 0x22a9: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22ac:
	/* 0x22ac: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22af:
	/* 0x22af: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22b2:
	/* 0x22b2: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_22ba:
	/* 0x22ba: mov    rdi,QWORD PTR [rip+0x330] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data_heap));
x86_l_22c1:
	/* 0x22c1: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_22c6:
	/* 0x22c6: call   25fb <cwd_read_v61+0x293> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22cb:
	/* 0x22cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22ce:
	/* 0x22ce: je     233d <data_event_bytes+0xa2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22ce, 0x233d, x86_l_233d);
x86_l_22d0:
	/* 0x22d0: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22d3:
	/* 0x22d3: mov    DWORD PTR [rax],0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22d9:
	/* 0x22d9: call   260e <cwd_read_v61+0x2a6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_22de:
	/* 0x22de: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_22e1:
	/* 0x22e1: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_22e5:
	/* 0x22e5: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22e9:
	/* 0x22e9: cmp    rax,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_22ed:
	/* 0x22ed: jne    22f8 <data_event_bytes+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22ed, 0x22f8, x86_l_22f8);
x86_l_22ef:
	/* 0x22ef: mov    rax,QWORD PTR [r12+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22f4:
	/* 0x22f4: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22f8:
	/* 0x22f8: call   262d <cwd_read_v61+0x2c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_22fd:
	/* 0x22fd: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2301:
	/* 0x2301: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2305:
	/* 0x2305: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2309:
	/* 0x2309: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_230d:
	/* 0x230d: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2311:
	/* 0x2311: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2314:
	/* 0x2314: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2317:
	/* 0x2317: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_231a:
	/* 0x231a: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_231d:
	/* 0x231d: call   2698 <do_bytes> */
	X86_SIM_X86_CALL(x86_l_2698, 0x2322ULL);
x86_l_2322:
	/* 0x2322: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2324:
	/* 0x2324: js     2341 <data_event_bytes+0xa6> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2324, 0x2341, x86_l_2341);
x86_l_2326:
	/* 0x2326: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_232d:
	/* 0x232d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_232f:
	/* 0x232f: cmp    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2333:
	/* 0x2333: je     234e <data_event_bytes+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2333, 0x234e, x86_l_234e);
x86_l_2335:
	/* 0x2335: sub    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2338:
	/* 0x2338: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_233b:
	/* 0x233b: jmp    234e <data_event_bytes+0xb3> */
	X86_SIM_X86_SUB_JMP(0x233b, 0x234e, x86_l_234e);
x86_l_233d:
	/* 0x233d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_233f:
	/* 0x233f: jmp    2359 <data_event_bytes+0xbe> */
	X86_SIM_X86_SUB_JMP(0x233f, 0x2359, x86_l_2359);
x86_l_2341:
	/* 0x2341: mov    DWORD PTR [rbx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2343:
	/* 0x2343: mov    DWORD PTR [rbx+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_234a:
	/* 0x234a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_234c:
	/* 0x234c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_234e:
	/* 0x234e: mov    DWORD PTR [rbx+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2351:
	/* 0x2351: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2354:
	/* 0x2354: mov    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2359:
	/* 0x2359: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_235d:
	/* 0x235d: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_235e:
	/* 0x235e: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2360:
	/* 0x2360: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2362:
	/* 0x2362: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2364:
	/* 0x2364: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2366:
	/* 0x2366: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2367:
	/* 0x2367: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2367);

	/* native subroutine native_link_sub_2368 */
x86_l_2368:
	/* 0x2368: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2369:
	/* 0x2369: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_236b:
	/* 0x236b: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_236d:
	/* 0x236d: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_236f:
	/* 0x236f: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2371:
	/* 0x2371: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2372:
	/* 0x2372: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_2376:
	/* 0x2376: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2379:
	/* 0x2379: mov    r12,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_237d:
	/* 0x237d: mov    rdx,QWORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2381:
	/* 0x2381: mov    r15,QWORD PTR [rsi+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2385:
	/* 0x2385: cmp    r12,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_2388:
	/* 0x2388: jne    2394 <cwd_read_v61+0x2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2388, 0x2394, x86_l_2394);
x86_l_238a:
	/* 0x238a: cmp    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_238e:
	/* 0x238e: je     24f9 <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x238e, 0x24f9, x86_l_24f9);
x86_l_2394:
	/* 0x2394: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2397:
	/* 0x2397: jns    23b4 <cwd_read_v61+0x4c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2397, 0x23b4, x86_l_23b4);
x86_l_2399:
	/* 0x2399: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_239c:
	/* 0x239c: jns    23d6 <cwd_read_v61+0x6e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x239c, 0x23d6, x86_l_23d6);
x86_l_239e:
	/* 0x239e: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23a1:
	/* 0x23a1: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23a6:
	/* 0x23a6: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23aa:
	/* 0x23aa: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23ad:
	/* 0x23ad: jne    23ee <cwd_read_v61+0x86> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x23ad, 0x23ee, x86_l_23ee);
x86_l_23af:
	/* 0x23af: jmp    2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x23af, 0x2481, x86_l_2481);
x86_l_23b4:
	/* 0x23b4: lea    rdi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23b9:
	/* 0x23b9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_23be:
	/* 0x23be: call   2b63 <__do_str+0xd0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_23c3:
	/* 0x23c3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23c8:
	/* 0x23c8: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23cc:
	/* 0x23cc: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23cf:
	/* 0x23cf: jne    23ee <cwd_read_v61+0x86> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x23cf, 0x23ee, x86_l_23ee);
x86_l_23d1:
	/* 0x23d1: jmp    2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x23d1, 0x2481, x86_l_2481);
x86_l_23d6:
	/* 0x23d6: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_23df:
	/* 0x23df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e1:
	/* 0x23e1: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23e5:
	/* 0x23e5: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23e8:
	/* 0x23e8: je     2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23e8, 0x2481, x86_l_2481);
x86_l_23ee:
	/* 0x23ee: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_23f1:
	/* 0x23f1: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_23f5:
	/* 0x23f5: jns    2409 <cwd_read_v61+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x23f5, 0x2409, x86_l_2409);
x86_l_23f7:
	/* 0x23f7: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_23fa:
	/* 0x23fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23fd:
	/* 0x23fd: jns    243f <cwd_read_v61+0xd7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x23fd, 0x243f, x86_l_243f);
x86_l_23ff:
	/* 0x23ff: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2402:
	/* 0x2402: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2405:
	/* 0x2405: jne    2444 <cwd_read_v61+0xdc> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2405, 0x2444, x86_l_2444);
x86_l_2407:
	/* 0x2407: jmp    2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x2407, 0x2481, x86_l_2481);
x86_l_2409:
	/* 0x2409: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_240e:
	/* 0x240e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2413:
	/* 0x2413: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2416:
	/* 0x2416: call   2bbb <__do_str+0x128> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_241b:
	/* 0x241b: cmp    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2420:
	/* 0x2420: je     2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2420, 0x2481, x86_l_2481);
x86_l_2422:
	/* 0x2422: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2427:
	/* 0x2427: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_242c:
	/* 0x242c: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_242f:
	/* 0x242f: call   2bd4 <__do_str+0x141> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2434:
	/* 0x2434: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2438:
	/* 0x2438: jns    2460 <cwd_read_v61+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2438, 0x2460, x86_l_2460);
x86_l_243a:
	/* 0x243a: jmp    251a <cwd_read_v61+0x1b2> */
	X86_SIM_X86_SUB_JMP(0x243a, 0x251a, x86_l_251a);
x86_l_243f:
	/* 0x243f: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2442:
	/* 0x2442: je     2481 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2442, 0x2481, x86_l_2481);
x86_l_2444:
	/* 0x2444: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2447:
	/* 0x2447: jns    2507 <cwd_read_v61+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2447, 0x2507, x86_l_2507);
x86_l_244d:
	/* 0x244d: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2451:
	/* 0x2451: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2456:
	/* 0x2456: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_245a:
	/* 0x245a: js     251a <cwd_read_v61+0x1b2> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x245a, 0x251a, x86_l_251a);
x86_l_2460:
	/* 0x2460: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2465:
	/* 0x2465: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_246a:
	/* 0x246a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_246d:
	/* 0x246d: call   2c12 <__do_str+0x17f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2472:
	/* 0x2472: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2477:
	/* 0x2477: mov    r15d,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_247c:
	/* 0x247c: jmp    254f <cwd_read_v61+0x1e7> */
	X86_SIM_X86_SUB_JMP(0x247c, 0x254f, x86_l_254f);
x86_l_2481:
	/* 0x2481: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2484:
	/* 0x2484: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2488:
	/* 0x2488: jns    249f <cwd_read_v61+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2488, 0x249f, x86_l_249f);
x86_l_248a:
	/* 0x248a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_248d:
	/* 0x248d: jns    24e8 <cwd_read_v61+0x180> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x248d, 0x24e8, x86_l_24e8);
x86_l_248f:
	/* 0x248f: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2492:
	/* 0x2492: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2497:
	/* 0x2497: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_249b:
	/* 0x249b: jne    24b9 <cwd_read_v61+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x249b, 0x24b9, x86_l_24b9);
x86_l_249d:
	/* 0x249d: jmp    24f9 <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JMP(0x249d, 0x24f9, x86_l_24f9);
x86_l_249f:
	/* 0x249f: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24a4:
	/* 0x24a4: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_24a9:
	/* 0x24a9: call   2c4e <__do_str+0x1bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_24ae:
	/* 0x24ae: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b3:
	/* 0x24b3: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24b7:
	/* 0x24b7: je     24f9 <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24b7, 0x24f9, x86_l_24f9);
x86_l_24b9:
	/* 0x24b9: add    r15,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_24bd:
	/* 0x24bd: jns    24d3 <cwd_read_v61+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x24bd, 0x24d3, x86_l_24d3);
x86_l_24bf:
	/* 0x24bf: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_24c2:
	/* 0x24c2: jns    2604 <cwd_read_v61+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x24c2, 0x2604, x86_l_2604);
x86_l_24c8:
	/* 0x24c8: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24cb:
	/* 0x24cb: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24ce:
	/* 0x24ce: jmp    260b <cwd_read_v61+0x2a3> */
	X86_SIM_X86_SUB_JMP(0x24ce, 0x260b, x86_l_260b);
x86_l_24d3:
	/* 0x24d3: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_24d6:
	/* 0x24d6: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_24db:
	/* 0x24db: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_24de:
	/* 0x24de: call   2c83 <__do_str+0x1f0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_24e3:
	/* 0x24e3: jmp    260b <cwd_read_v61+0x2a3> */
	X86_SIM_X86_SUB_JMP(0x24e3, 0x260b, x86_l_260b);
x86_l_24e8:
	/* 0x24e8: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_24f1:
	/* 0x24f1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f3:
	/* 0x24f3: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24f7:
	/* 0x24f7: jne    24b9 <cwd_read_v61+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x24f7, 0x24b9, x86_l_24b9);
x86_l_24f9:
	/* 0x24f9: mov    BYTE PTR [rbx+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_24fd:
	/* 0x24fd: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2502:
	/* 0x2502: jmp    261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JMP(0x2502, 0x261e, x86_l_261e);
x86_l_2507:
	/* 0x2507: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2510:
	/* 0x2510: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2514:
	/* 0x2514: jns    2460 <cwd_read_v61+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2514, 0x2460, x86_l_2460);
x86_l_251a:
	/* 0x251a: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_251d:
	/* 0x251d: jns    2538 <cwd_read_v61+0x1d0> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x251d, 0x2538, x86_l_2538);
x86_l_251f:
	/* 0x251f: mov    r15,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2523:
	/* 0x2523: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2528:
	/* 0x2528: mov    rdx,QWORD PTR [r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_252d:
	/* 0x252d: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2532:
	/* 0x2532: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2536:
	/* 0x2536: jmp    254f <cwd_read_v61+0x1e7> */
	X86_SIM_X86_SUB_JMP(0x2536, 0x254f, x86_l_254f);
x86_l_2538:
	/* 0x2538: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2541:
	/* 0x2541: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_254a:
	/* 0x254a: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_254d:
	/* 0x254d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_254f:
	/* 0x254f: mov    rdi,QWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2553:
	/* 0x2553: mov    r8,QWORD PTR [rbx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2557:
	/* 0x2557: sub    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_255a:
	/* 0x255a: mov    ebp,DWORD PTR [rbx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_255d:
	/* 0x255d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_255f:
	/* 0x255f: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2562:
	/* 0x2562: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2565:
	/* 0x2565: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_2567:
	/* 0x2567: sub    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2569:
	/* 0x2569: cmovb  esi,eax */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RAX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_256c:
	/* 0x256c: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_256f:
	/* 0x256f: ja     2574 <cwd_read_v61+0x20c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x256f, 0x2574, x86_l_2574);
x86_l_2571:
	/* 0x2571: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2574:
	/* 0x2574: mov    r9b,al */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2577:
	/* 0x2577: add    r9d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_257a:
	/* 0x257a: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_257c:
	/* 0x257c: sub    eax,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_257f:
	/* 0x257f: mov    DWORD PTR [rbx+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2582:
	/* 0x2582: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2587:
	/* 0x2587: sub    r8,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R9, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_258a:
	/* 0x258a: jb     261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x258a, 0x261e, x86_l_261e);
x86_l_2590:
	/* 0x2590: cmp    r8,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2597:
	/* 0x2597: ja     261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2597, 0x261e, x86_l_261e);
x86_l_259d:
	/* 0x259d: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25a0:
	/* 0x25a0: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_25a3:
	/* 0x25a3: jbe    25aa <cwd_read_v61+0x242> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x25a3, 0x25aa, x86_l_25aa);
x86_l_25a5:
	/* 0x25a5: mov    BYTE PTR [rdi+r8*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 47ULL);
x86_l_25aa:
	/* 0x25aa: lea    r12,[rdi+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_25ae:
	/* 0x25ae: cmp    r15d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_25b1:
	/* 0x25b1: movzx  esi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RSI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_25b4:
	/* 0x25b4: adc    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_64, X86_ALU_ADC, 0);
x86_l_25b7:
	/* 0x25b7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25ba:
	/* 0x25ba: jns    262d <cwd_read_v61+0x2c5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x25ba, 0x262d, x86_l_262d);
x86_l_25bc:
	/* 0x25bc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25bf:
	/* 0x25bf: jns    2634 <cwd_read_v61+0x2cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x25bf, 0x2634, x86_l_2634);
x86_l_25c1:
	/* 0x25c1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25c4:
	/* 0x25c4: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_25c7:
	/* 0x25c7: jb     25e6 <cwd_read_v61+0x27e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x25c7, 0x25e6, x86_l_25e6);
x86_l_25c9:
	/* 0x25c9: mov    esi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_25cb:
	/* 0x25cb: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25ce:
	/* 0x25ce: mov    r9,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_25d1:
	/* 0x25d1: mov    r8,QWORD PTR [rdx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_25d5:
	/* 0x25d5: mov    QWORD PTR [rdi+r9*1],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_25d9:
	/* 0x25d9: lea    r8,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25dd:
	/* 0x25dd: add    r9,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_25e1:
	/* 0x25e1: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25e4:
	/* 0x25e4: jbe    25ce <cwd_read_v61+0x266> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x25e4, 0x25ce, x86_l_25ce);
x86_l_25e6:
	/* 0x25e6: test   cl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_25e9:
	/* 0x25e9: jne    2655 <cwd_read_v61+0x2ed> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x25e9, 0x2655, x86_l_2655);
x86_l_25eb:
	/* 0x25eb: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_25ee:
	/* 0x25ee: jne    2669 <cwd_read_v61+0x301> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x25ee, 0x2669, x86_l_2669);
x86_l_25f0:
	/* 0x25f0: test   cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_25f3:
	/* 0x25f3: jne    2683 <cwd_read_v61+0x31b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x25f3, 0x2683, x86_l_2683);
x86_l_25f9:
	/* 0x25f9: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25fd:
	/* 0x25fd: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2600:
	/* 0x2600: jbe    261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2600, 0x261e, x86_l_261e);
x86_l_2602:
	/* 0x2602: jmp    264b <cwd_read_v61+0x2e3> */
	X86_SIM_X86_SUB_JMP(0x2602, 0x264b, x86_l_264b);
x86_l_2604:
	/* 0x2604: mov    QWORD PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260b:
	/* 0x260b: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2610:
	/* 0x2610: mov    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2614:
	/* 0x2614: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2618:
	/* 0x2618: mov    QWORD PTR [rbx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_261c:
	/* 0x261c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_261e:
	/* 0x261e: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2622:
	/* 0x2622: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2623:
	/* 0x2623: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2625:
	/* 0x2625: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2627:
	/* 0x2627: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2629:
	/* 0x2629: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_262b:
	/* 0x262b: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_262c:
	/* 0x262c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_262c);
x86_l_262d:
	/* 0x262d: call   2ddc <__do_str+0x349> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2632:
	/* 0x2632: jmp    263d <cwd_read_v61+0x2d5> */
	X86_SIM_X86_SUB_JMP(0x2632, 0x263d, x86_l_263d);
x86_l_2634:
	/* 0x2634: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2636:
	/* 0x2636: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2638:
	/* 0x2638: call   2de7 <__do_str+0x354> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_263d:
	/* 0x263d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2642:
	/* 0x2642: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2646:
	/* 0x2646: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2649:
	/* 0x2649: jbe    261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2649, 0x261e, x86_l_261e);
x86_l_264b:
	/* 0x264b: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2650:
	/* 0x2650: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2653:
	/* 0x2653: jmp    261c <cwd_read_v61+0x2b4> */
	X86_SIM_X86_SUB_JMP(0x2653, 0x261c, x86_l_261c);
x86_l_2655:
	/* 0x2655: mov    esi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2658:
	/* 0x2658: mov    r9d,DWORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_265c:
	/* 0x265c: mov    DWORD PTR [rdi+rsi*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_2660:
	/* 0x2660: or     r8d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_2664:
	/* 0x2664: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2667:
	/* 0x2667: je     25f0 <cwd_read_v61+0x288> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2667, 0x25f0, x86_l_25f0);
x86_l_2669:
	/* 0x2669: mov    esi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_266c:
	/* 0x266c: movzx  r9d,WORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_16), 0ULL);
x86_l_2671:
	/* 0x2671: mov    WORD PTR [rdi+rsi*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_2676:
	/* 0x2676: add    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_267a:
	/* 0x267a: test   cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_267d:
	/* 0x267d: je     25f9 <cwd_read_v61+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x267d, 0x25f9, x86_l_25f9);
x86_l_2683:
	/* 0x2683: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2686:
	/* 0x2686: movzx  edx,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_268a:
	/* 0x268a: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_268d:
	/* 0x268d: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2691:
	/* 0x2691: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2694:
	/* 0x2694: jbe    261e <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2694, 0x261e, x86_l_261e);
x86_l_2696:
	/* 0x2696: jmp    264b <cwd_read_v61+0x2e3> */
	X86_SIM_X86_SUB_JMP(0x2696, 0x264b, x86_l_264b);

	/* native subroutine native_link_sub_2698 */
x86_l_2698:
	/* 0x2698: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2699:
	/* 0x2699: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_269b:
	/* 0x269b: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_269d:
	/* 0x269d: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_269f:
	/* 0x269f: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_26a1:
	/* 0x26a1: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26a2:
	/* 0x26a2: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a3:
	/* 0x26a3: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26a6:
	/* 0x26a6: mov    r14,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26a9:
	/* 0x26a9: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26ac:
	/* 0x26ac: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26af:
	/* 0x26af: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x26b4ULL);
x86_l_26b4:
	/* 0x26b4: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_26b6:
	/* 0x26b6: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x26b6, 0x285f, x86_l_285f);
x86_l_26bc:
	/* 0x26bc: mov    r13d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_26bf:
	/* 0x26bf: and    r13d,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_26c6:
	/* 0x26c6: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26c9:
	/* 0x26c9: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_26cc:
	/* 0x26cc: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x26cc, 0x28e4, x86_l_28e4);
x86_l_26d2:
	/* 0x26d2: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_26d6:
	/* 0x26d6: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_26d9:
	/* 0x26d9: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_26dc:
	/* 0x26dc: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x26e1ULL);
x86_l_26e1:
	/* 0x26e1: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_26e3:
	/* 0x26e3: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x26e3, 0x285f, x86_l_285f);
x86_l_26e9:
	/* 0x26e9: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_26ee:
	/* 0x26ee: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26f1:
	/* 0x26f1: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26f4:
	/* 0x26f4: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26f7:
	/* 0x26f7: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_26fa:
	/* 0x26fa: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x26fa, 0x28e4, x86_l_28e4);
x86_l_2700:
	/* 0x2700: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2704:
	/* 0x2704: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2707:
	/* 0x2707: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_270a:
	/* 0x270a: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x270fULL);
x86_l_270f:
	/* 0x270f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2711:
	/* 0x2711: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2711, 0x285f, x86_l_285f);
x86_l_2717:
	/* 0x2717: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_271c:
	/* 0x271c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271f:
	/* 0x271f: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2722:
	/* 0x2722: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2725:
	/* 0x2725: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2728:
	/* 0x2728: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2728, 0x28e4, x86_l_28e4);
x86_l_272e:
	/* 0x272e: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2732:
	/* 0x2732: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2735:
	/* 0x2735: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2738:
	/* 0x2738: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x273dULL);
x86_l_273d:
	/* 0x273d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_273f:
	/* 0x273f: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x273f, 0x285f, x86_l_285f);
x86_l_2745:
	/* 0x2745: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_274a:
	/* 0x274a: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_274d:
	/* 0x274d: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2750:
	/* 0x2750: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2753:
	/* 0x2753: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2756:
	/* 0x2756: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2756, 0x28e4, x86_l_28e4);
x86_l_275c:
	/* 0x275c: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2760:
	/* 0x2760: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2763:
	/* 0x2763: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2766:
	/* 0x2766: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x276bULL);
x86_l_276b:
	/* 0x276b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_276d:
	/* 0x276d: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x276d, 0x285f, x86_l_285f);
x86_l_2773:
	/* 0x2773: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_2778:
	/* 0x2778: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_277b:
	/* 0x277b: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_277e:
	/* 0x277e: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2781:
	/* 0x2781: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2784:
	/* 0x2784: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2784, 0x28e4, x86_l_28e4);
x86_l_278a:
	/* 0x278a: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_278e:
	/* 0x278e: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2791:
	/* 0x2791: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2794:
	/* 0x2794: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x2799ULL);
x86_l_2799:
	/* 0x2799: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_279b:
	/* 0x279b: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x279b, 0x285f, x86_l_285f);
x86_l_27a1:
	/* 0x27a1: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_27a6:
	/* 0x27a6: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27a9:
	/* 0x27a9: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27ac:
	/* 0x27ac: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_27af:
	/* 0x27af: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_27b2:
	/* 0x27b2: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x27b2, 0x28e4, x86_l_28e4);
x86_l_27b8:
	/* 0x27b8: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_27bc:
	/* 0x27bc: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_27bf:
	/* 0x27bf: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_27c2:
	/* 0x27c2: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x27c7ULL);
x86_l_27c7:
	/* 0x27c7: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_27c9:
	/* 0x27c9: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x27c9, 0x285f, x86_l_285f);
x86_l_27cf:
	/* 0x27cf: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_27d4:
	/* 0x27d4: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27d7:
	/* 0x27d7: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27da:
	/* 0x27da: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_27dd:
	/* 0x27dd: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_27e0:
	/* 0x27e0: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x27e0, 0x28e4, x86_l_28e4);
x86_l_27e6:
	/* 0x27e6: lea    rdx,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_27ea:
	/* 0x27ea: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_27ed:
	/* 0x27ed: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_27f0:
	/* 0x27f0: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x27f5ULL);
x86_l_27f5:
	/* 0x27f5: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_27f7:
	/* 0x27f7: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x27f7, 0x285f, x86_l_285f);
x86_l_27f9:
	/* 0x27f9: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_27fe:
	/* 0x27fe: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2801:
	/* 0x2801: add    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2804:
	/* 0x2804: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2807:
	/* 0x2807: sub    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_280a:
	/* 0x280a: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x280a, 0x28e4, x86_l_28e4);
x86_l_2810:
	/* 0x2810: lea    rdx,[r14+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2814:
	/* 0x2814: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2817:
	/* 0x2817: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_281a:
	/* 0x281a: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x281fULL);
x86_l_281f:
	/* 0x281f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2821:
	/* 0x2821: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2821, 0x285f, x86_l_285f);
x86_l_2823:
	/* 0x2823: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_2828:
	/* 0x2828: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_282b:
	/* 0x282b: add    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_282e:
	/* 0x282e: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2831:
	/* 0x2831: sub    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2834:
	/* 0x2834: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2834, 0x28e4, x86_l_28e4);
x86_l_283a:
	/* 0x283a: add    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_283d:
	/* 0x283d: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2840:
	/* 0x2840: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2843:
	/* 0x2843: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2846:
	/* 0x2846: call   28f6 <__do_bytes> */
	X86_SIM_X86_CALL(x86_l_28f6, 0x284bULL);
x86_l_284b:
	/* 0x284b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_284d:
	/* 0x284d: js     285f <do_bytes+0x1c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x284d, 0x285f, x86_l_285f);
x86_l_284f:
	/* 0x284f: and    eax,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_2854:
	/* 0x2854: add    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2857:
	/* 0x2857: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_285a:
	/* 0x285a: jmp    28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JMP(0x285a, 0x28e4, x86_l_28e4);
x86_l_285f:
	/* 0x285f: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2862:
	/* 0x2862: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_286a:
	/* 0x286a: mov    rdi,QWORD PTR [rip+0x400] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_2871:
	/* 0x2871: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2876:
	/* 0x2876: call   2c7b <__do_str+0x1e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_287b:
	/* 0x287b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_287e:
	/* 0x287e: je     28e4 <do_bytes+0x24c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x287e, 0x28e4, x86_l_28e4);
x86_l_2880:
	/* 0x2880: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2884:
	/* 0x2884: jg     28a0 <do_bytes+0x208> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2884, 0x28a0, x86_l_28a0);
x86_l_2886:
	/* 0x2886: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_288a:
	/* 0x288a: je     28ba <do_bytes+0x222> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x288a, 0x28ba, x86_l_28ba);
x86_l_288c:
	/* 0x288c: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2890:
	/* 0x2890: je     28d2 <do_bytes+0x23a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2890, 0x28d2, x86_l_28d2);
x86_l_2892:
	/* 0x2892: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2896:
	/* 0x2896: jne    28ca <do_bytes+0x232> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2896, 0x28ca, x86_l_28ca);
x86_l_2898:
	/* 0x2898: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_289e:
	/* 0x289e: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x289e, 0x28e0, x86_l_28e0);
x86_l_28a0:
	/* 0x28a0: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_28a4:
	/* 0x28a4: je     28c2 <do_bytes+0x22a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x28a4, 0x28c2, x86_l_28c2);
x86_l_28a6:
	/* 0x28a6: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_28aa:
	/* 0x28aa: je     28da <do_bytes+0x242> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x28aa, 0x28da, x86_l_28da);
x86_l_28ac:
	/* 0x28ac: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_28b0:
	/* 0x28b0: jne    28ca <do_bytes+0x232> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x28b0, 0x28ca, x86_l_28ca);
x86_l_28b2:
	/* 0x28b2: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_28b8:
	/* 0x28b8: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x28b8, 0x28e0, x86_l_28e0);
x86_l_28ba:
	/* 0x28ba: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_28c0:
	/* 0x28c0: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x28c0, 0x28e0, x86_l_28e0);
x86_l_28c2:
	/* 0x28c2: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_28c8:
	/* 0x28c8: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x28c8, 0x28e0, x86_l_28e0);
x86_l_28ca:
	/* 0x28ca: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_28d0:
	/* 0x28d0: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x28d0, 0x28e0, x86_l_28e0);
x86_l_28d2:
	/* 0x28d2: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_28d8:
	/* 0x28d8: jmp    28e0 <do_bytes+0x248> */
	X86_SIM_X86_SUB_JMP(0x28d8, 0x28e0, x86_l_28e0);
x86_l_28da:
	/* 0x28da: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_28e0:
	/* 0x28e0: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_28e4:
	/* 0x28e4: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_28e7:
	/* 0x28e7: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_28eb:
	/* 0x28eb: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28ec:
	/* 0x28ec: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28ee:
	/* 0x28ee: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28f0:
	/* 0x28f0: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28f2:
	/* 0x28f2: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28f4:
	/* 0x28f4: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_28f5:
	/* 0x28f5: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_28f5);

	/* native subroutine native_link_sub_28f6 */
x86_l_28f6:
	/* 0x28f6: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_28f8:
	/* 0x28f8: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_28fa:
	/* 0x28fa: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_28fc:
	/* 0x28fc: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_28fd:
	/* 0x28fd: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28fe:
	/* 0x28fe: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2901:
	/* 0x2901: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2904:
	/* 0x2904: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2907:
	/* 0x2907: cmp    rcx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32736ULL);
x86_l_290e:
	/* 0x290e: jb     2915 <__do_bytes+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x290e, 0x2915, x86_l_2915);
x86_l_2910:
	/* 0x2910: mov    ebx,0x7fe0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 32736ULL);
x86_l_2915:
	/* 0x2915: lea    rdi,[r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2919:
	/* 0x2919: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_291c:
	/* 0x291c: js     292e <__do_bytes+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x291c, 0x292e, x86_l_292e);
x86_l_291e:
	/* 0x291e: mov    esi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2920:
	/* 0x2920: call   2f85 <__do_str+0x4f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2925:
	/* 0x2925: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2927:
	/* 0x2927: jns    2978 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2927, 0x2978, x86_l_2978);
x86_l_2929:
	/* 0x2929: jmp    29ef <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JMP(0x2929, 0x29ef, x86_l_29ef);
x86_l_292e:
	/* 0x292e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2931:
	/* 0x2931: jns    29de <__do_bytes+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2931, 0x29de, x86_l_29de);
x86_l_2937:
	/* 0x2937: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2939:
	/* 0x2939: cmp    ebx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_293c:
	/* 0x293c: jb     2958 <__do_bytes+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x293c, 0x2958, x86_l_2958);
x86_l_293e:
	/* 0x293e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2940:
	/* 0x2940: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2943:
	/* 0x2943: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2947:
	/* 0x2947: mov    QWORD PTR [rdi+rcx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_294b:
	/* 0x294b: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_294f:
	/* 0x294f: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2953:
	/* 0x2953: cmp    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2956:
	/* 0x2956: jbe    2940 <__do_bytes+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2956, 0x2940, x86_l_2940);
x86_l_2958:
	/* 0x2958: test   bl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_295b:
	/* 0x295b: jne    2a01 <__do_bytes+0x10b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x295b, 0x2a01, x86_l_2a01);
x86_l_2961:
	/* 0x2961: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2964:
	/* 0x2964: jne    2a15 <__do_bytes+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2964, 0x2a15, x86_l_2a15);
x86_l_296a:
	/* 0x296a: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_296d:
	/* 0x296d: je     2978 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x296d, 0x2978, x86_l_2978);
x86_l_296f:
	/* 0x296f: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2971:
	/* 0x2971: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_2975:
	/* 0x2975: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2978:
	/* 0x2978: lea    r12d,[rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_297c:
	/* 0x297c: mov    DWORD PTR [r14+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2980:
	/* 0x2980: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_2988:
	/* 0x2988: mov    rdi,QWORD PTR [rip+0x666] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_298f:
	/* 0x298f: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2994:
	/* 0x2994: call   2fff <__do_str+0x56c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2999:
	/* 0x2999: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_299c:
	/* 0x299c: je     29c4 <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x299c, 0x29c4, x86_l_29c4);
x86_l_299e:
	/* 0x299e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_29a2:
	/* 0x29a2: je     29c4 <__do_bytes+0xce> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x29a2, 0x29c4, x86_l_29c4);
x86_l_29a4:
	/* 0x29a4: mov    rsi,QWORD PTR [rip+0x666] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_29ab:
	/* 0x29ab: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_29b0:
	/* 0x29b0: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_29b3:
	/* 0x29b3: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_29b6:
	/* 0x29b6: mov    r8,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_29b9:
	/* 0x29b9: call   3024 <__do_str+0x591> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_29be:
	/* 0x29be: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_29c0:
	/* 0x29c0: js     29ef <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x29c0, 0x29ef, x86_l_29ef);
x86_l_29c2:
	/* 0x29c2: jmp    29f2 <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x29c2, 0x29f2, x86_l_29f2);
x86_l_29c4:
	/* 0x29c4: mov    rdi,QWORD PTR [rip+0x666] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_29cb:
	/* 0x29cb: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_29ce:
	/* 0x29ce: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_29d1:
	/* 0x29d1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d3:
	/* 0x29d3: call   303e <__do_str+0x5ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_29d8:
	/* 0x29d8: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_29da:
	/* 0x29da: js     29ef <__do_bytes+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x29da, 0x29ef, x86_l_29ef);
x86_l_29dc:
	/* 0x29dc: jmp    29f2 <__do_bytes+0xfc> */
	X86_SIM_X86_SUB_JMP(0x29dc, 0x29f2, x86_l_29f2);
x86_l_29de:
	/* 0x29de: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e0:
	/* 0x29e0: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_29e3:
	/* 0x29e3: call   304e <__do_str+0x5bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_29e8:
	/* 0x29e8: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_29ef:
	/* 0x29ef: movsxd rbx,eax */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_29f2:
	/* 0x29f2: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_29f5:
	/* 0x29f5: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29f9:
	/* 0x29f9: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29fa:
	/* 0x29fa: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29fc:
	/* 0x29fc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29fe:
	/* 0x29fe: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a00:
	/* 0x2a00: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2a00);
x86_l_2a01:
	/* 0x2a01: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2a03:
	/* 0x2a03: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2a06:
	/* 0x2a06: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2a09:
	/* 0x2a09: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_2a0c:
	/* 0x2a0c: test   bl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2a0f:
	/* 0x2a0f: je     296a <__do_bytes+0x74> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2a0f, 0x296a, x86_l_296a);
x86_l_2a15:
	/* 0x2a15: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2a17:
	/* 0x2a17: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_2a1b:
	/* 0x2a1b: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2a1f:
	/* 0x2a1f: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_2a22:
	/* 0x2a22: test   bl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2a25:
	/* 0x2a25: jne    296f <__do_bytes+0x79> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2a25, 0x296f, x86_l_296f);
x86_l_2a2b:
	/* 0x2a2b: jmp    2978 <__do_bytes+0x82> */
	X86_SIM_X86_SUB_JMP(0x2a2b, 0x2978, x86_l_2978);

	/* native subroutine native_link_sub_2a30 */
x86_l_2a30:
	/* 0x2a30: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2a32:
	/* 0x2a32: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a34:
	/* 0x2a34: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a36:
	/* 0x2a36: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2a37:
	/* 0x2a37: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a38:
	/* 0x2a38: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a3b:
	/* 0x2a3b: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a3e:
	/* 0x2a3e: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a41:
	/* 0x2a41: mov    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_2a46:
	/* 0x2a46: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_2a4b:
	/* 0x2a4b: call   2a93 <__do_str> */
	X86_SIM_X86_CALL(x86_l_2a93, 0x2a50ULL);
x86_l_2a50:
	/* 0x2a50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a53:
	/* 0x2a53: js     2a87 <do_str+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2a53, 0x2a87, x86_l_2a87);
x86_l_2a55:
	/* 0x2a55: cmp    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_2a5a:
	/* 0x2a5a: jne    2a87 <do_str+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2a5a, 0x2a87, x86_l_2a87);
x86_l_2a5c:
	/* 0x2a5c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a5f:
	/* 0x2a5f: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a62:
	/* 0x2a62: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a65:
	/* 0x2a65: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_2a6a:
	/* 0x2a6a: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a6d:
	/* 0x2a6d: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2a70:
	/* 0x2a70: call   2a93 <__do_str> */
	X86_SIM_X86_CALL(x86_l_2a93, 0x2a75ULL);
x86_l_2a75:
	/* 0x2a75: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a78:
	/* 0x2a78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a7b:
	/* 0x2a7b: js     2a82 <do_str+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2a7b, 0x2a82, x86_l_2a82);
x86_l_2a7d:
	/* 0x2a7d: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a80:
	/* 0x2a80: jmp    2a84 <do_str+0x54> */
	X86_SIM_X86_SUB_JMP(0x2a80, 0x2a84, x86_l_2a84);
x86_l_2a82:
	/* 0x2a82: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a84:
	/* 0x2a84: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a87:
	/* 0x2a87: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2a8b:
	/* 0x2a8b: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a8c:
	/* 0x2a8c: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a8e:
	/* 0x2a8e: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a90:
	/* 0x2a90: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a92:
	/* 0x2a92: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2a92);

	/* native subroutine native_link_sub_2a93 */
x86_l_2a93:
	/* 0x2a93: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2a95:
	/* 0x2a95: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a97:
	/* 0x2a97: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a99:
	/* 0x2a99: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2a9a:
	/* 0x2a9a: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_2a9e:
	/* 0x2a9e: mov    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2aa1:
	/* 0x2aa1: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2aa4:
	/* 0x2aa4: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2aa7:
	/* 0x2aa7: lea    rdi,[rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2aab:
	/* 0x2aab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2aae:
	/* 0x2aae: js     2ad9 <__do_str+0x46> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2aae, 0x2ad9, x86_l_2ad9);
x86_l_2ab0:
	/* 0x2ab0: mov    esi,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_2ab5:
	/* 0x2ab5: call   2be7 <__do_str+0x154> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2aba:
	/* 0x2aba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2abd:
	/* 0x2abd: js     2c7c <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x2abd, 0x2c7c, x86_l_2c7c);
x86_l_2ac3:
	/* 0x2ac3: cmp    rax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_2ac9:
	/* 0x2ac9: setne  BYTE PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_SETCC_MEM, X86_R15, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 0ULL);
x86_l_2acd:
	/* 0x2acd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ad0:
	/* 0x2ad0: jne    2b27 <__do_str+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2ad0, 0x2b27, x86_l_2b27);
x86_l_2ad2:
	/* 0x2ad2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ad4:
	/* 0x2ad4: jmp    2c7c <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JMP(0x2ad4, 0x2c7c, x86_l_2c7c);
x86_l_2ad9:
	/* 0x2ad9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2adc:
	/* 0x2adc: jns    2aff <__do_str+0x6c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2adc, 0x2aff, x86_l_2aff);
x86_l_2ade:
	/* 0x2ade: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ae0:
	/* 0x2ae0: cmp    rcx,0x7fde */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32734ULL);
x86_l_2ae7:
	/* 0x2ae7: je     2b17 <__do_str+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2ae7, 0x2b17, x86_l_2b17);
x86_l_2ae9:
	/* 0x2ae9: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2aed:
	/* 0x2aed: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2af1:
	/* 0x2af1: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2af5:
	/* 0x2af5: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af8:
	/* 0x2af8: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_2afb:
	/* 0x2afb: jne    2ae0 <__do_str+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2afb, 0x2ae0, x86_l_2ae0);
x86_l_2afd:
	/* 0x2afd: jmp    2ac3 <__do_str+0x30> */
	X86_SIM_X86_SUB_JMP(0x2afd, 0x2ac3, x86_l_2ac3);
x86_l_2aff:
	/* 0x2aff: mov    edx,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_2b04:
	/* 0x2b04: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b06:
	/* 0x2b06: call   2c3e <__do_str+0x1ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_2b0b:
	/* 0x2b0b: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_2b12:
	/* 0x2b12: jmp    2c7c <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JMP(0x2b12, 0x2c7c, x86_l_2c7c);
x86_l_2b17:
	/* 0x2b17: mov    BYTE PTR [rbx+0x7ffe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 140728898420736ULL);
x86_l_2b1e:
	/* 0x2b1e: mov    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b22:
	/* 0x2b22: mov    eax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_2b27:
	/* 0x2b27: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b2a:
	/* 0x2b2a: lea    r15d,[rax+0x1f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
x86_l_2b2e:
	/* 0x2b2e: and    r15d,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b35:
	/* 0x2b35: mov    DWORD PTR [rbx+0x4],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2b39:
	/* 0x2b39: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2b41:
	/* 0x2b41: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_2b48:
	/* 0x2b48: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2b4d:
	/* 0x2b4d: call   2c85 <__do_str+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b52:
	/* 0x2b52: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b55:
	/* 0x2b55: je     2bca <__do_str+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b55, 0x2bca, x86_l_2bca);
x86_l_2b57:
	/* 0x2b57: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2b5b:
	/* 0x2b5b: je     2bca <__do_str+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b5b, 0x2bca, x86_l_2bca);
x86_l_2b5d:
	/* 0x2b5d: mov    rsi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_2b64:
	/* 0x2b64: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2b69:
	/* 0x2b69: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2b6c:
	/* 0x2b6c: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2b6f:
	/* 0x2b6f: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2b72:
	/* 0x2b72: call   2caa <__do_str+0x217> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2b77:
	/* 0x2b77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b7a:
	/* 0x2b7a: jns    2c76 <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2b7a, 0x2c76, x86_l_2c76);
x86_l_2b80:
	/* 0x2b80: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b83:
	/* 0x2b83: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2b8b:
	/* 0x2b8b: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_2b92:
	/* 0x2b92: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2b97:
	/* 0x2b97: call   2ccf <__do_str+0x23c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b9c:
	/* 0x2b9c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b9f:
	/* 0x2b9f: je     2c76 <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b9f, 0x2c76, x86_l_2c76);
x86_l_2ba5:
	/* 0x2ba5: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2ba9:
	/* 0x2ba9: jg     2c42 <__do_str+0x1af> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2ba9, 0x2c42, x86_l_2c42);
x86_l_2baf:
	/* 0x2baf: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_2bb3:
	/* 0x2bb3: je     2c5c <__do_str+0x1c9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2bb3, 0x2c5c, x86_l_2c5c);
x86_l_2bb9:
	/* 0x2bb9: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2bbd:
	/* 0x2bbd: jne    2c1a <__do_str+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2bbd, 0x2c1a, x86_l_2c1a);
x86_l_2bbf:
	/* 0x2bbf: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_2bc5:
	/* 0x2bc5: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2bc5, 0x2c72, x86_l_2c72);
x86_l_2bca:
	/* 0x2bca: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_2bd1:
	/* 0x2bd1: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2bd4:
	/* 0x2bd4: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2bd7:
	/* 0x2bd7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bd9:
	/* 0x2bd9: call   2d11 <__do_str+0x27e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_2bde:
	/* 0x2bde: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2be1:
	/* 0x2be1: jns    2c76 <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x2be1, 0x2c76, x86_l_2c76);
x86_l_2be7:
	/* 0x2be7: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bea:
	/* 0x2bea: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2bf2:
	/* 0x2bf2: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_2bf9:
	/* 0x2bf9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bfe:
	/* 0x2bfe: call   2d36 <__do_str+0x2a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c03:
	/* 0x2c03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c06:
	/* 0x2c06: je     2c76 <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c06, 0x2c76, x86_l_2c76);
x86_l_2c08:
	/* 0x2c08: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2c0c:
	/* 0x2c0c: jg     2c28 <__do_str+0x195> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2c0c, 0x2c28, x86_l_2c28);
x86_l_2c0e:
	/* 0x2c0e: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_2c12:
	/* 0x2c12: je     2c5c <__do_str+0x1c9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c12, 0x2c5c, x86_l_2c5c);
x86_l_2c14:
	/* 0x2c14: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2c18:
	/* 0x2c18: je     2bbf <__do_str+0x12c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c18, 0x2bbf, x86_l_2bbf);
x86_l_2c1a:
	/* 0x2c1a: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2c1e:
	/* 0x2c1e: jne    2c54 <__do_str+0x1c1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2c1e, 0x2c54, x86_l_2c54);
x86_l_2c20:
	/* 0x2c20: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_2c26:
	/* 0x2c26: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c26, 0x2c72, x86_l_2c72);
x86_l_2c28:
	/* 0x2c28: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2c2c:
	/* 0x2c2c: je     2c64 <__do_str+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c2c, 0x2c64, x86_l_2c64);
x86_l_2c2e:
	/* 0x2c2e: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2c32:
	/* 0x2c32: je     2c6c <__do_str+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c32, 0x2c6c, x86_l_2c6c);
x86_l_2c34:
	/* 0x2c34: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2c38:
	/* 0x2c38: jne    2c54 <__do_str+0x1c1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2c38, 0x2c54, x86_l_2c54);
x86_l_2c3a:
	/* 0x2c3a: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_2c40:
	/* 0x2c40: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c40, 0x2c72, x86_l_2c72);
x86_l_2c42:
	/* 0x2c42: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2c46:
	/* 0x2c46: je     2c64 <__do_str+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c46, 0x2c64, x86_l_2c64);
x86_l_2c48:
	/* 0x2c48: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2c4c:
	/* 0x2c4c: je     2c6c <__do_str+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c4c, 0x2c6c, x86_l_2c6c);
x86_l_2c4e:
	/* 0x2c4e: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2c52:
	/* 0x2c52: je     2c3a <__do_str+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c52, 0x2c3a, x86_l_2c3a);
x86_l_2c54:
	/* 0x2c54: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_2c5a:
	/* 0x2c5a: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c5a, 0x2c72, x86_l_2c72);
x86_l_2c5c:
	/* 0x2c5c: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_2c62:
	/* 0x2c62: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c62, 0x2c72, x86_l_2c72);
x86_l_2c64:
	/* 0x2c64: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_2c6a:
	/* 0x2c6a: jmp    2c72 <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c6a, 0x2c72, x86_l_2c72);
x86_l_2c6c:
	/* 0x2c6c: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_2c72:
	/* 0x2c72: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2c76:
	/* 0x2c76: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c79:
	/* 0x2c79: dec    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_2c7c:
	/* 0x2c7c: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2c80:
	/* 0x2c80: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2c81:
	/* 0x2c81: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2c83:
	/* 0x2c83: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2c85:
	/* 0x2c85: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2c87:
	/* 0x2c87: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2c87);

x86_sim_ret_dispatch_229a:
	switch (__x86_sim_ret_addr) {
	case 0x4f1ULL: goto x86_l_4f1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2367:
	switch (__x86_sim_ret_addr) {
	case 0x88fULL: goto x86_l_88f;
	case 0x1bc0ULL: goto x86_l_1bc0;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_262c:
	switch (__x86_sim_ret_addr) {
	case 0x4f1ULL: goto x86_l_4f1;
	case 0x88fULL: goto x86_l_88f;
	case 0x1bc0ULL: goto x86_l_1bc0;
	case 0x226aULL: goto x86_l_226a;
	case 0x2322ULL: goto x86_l_2322;
	case 0x26b4ULL: goto x86_l_26b4;
	case 0x26e1ULL: goto x86_l_26e1;
	case 0x270fULL: goto x86_l_270f;
	case 0x273dULL: goto x86_l_273d;
	case 0x276bULL: goto x86_l_276b;
	case 0x2799ULL: goto x86_l_2799;
	case 0x27c7ULL: goto x86_l_27c7;
	case 0x27f5ULL: goto x86_l_27f5;
	case 0x281fULL: goto x86_l_281f;
	case 0x284bULL: goto x86_l_284b;
	case 0x2a50ULL: goto x86_l_2a50;
	case 0x2a75ULL: goto x86_l_2a75;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_28f5:
	switch (__x86_sim_ret_addr) {
	case 0x2322ULL: goto x86_l_2322;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2a00:
	switch (__x86_sim_ret_addr) {
	case 0x26b4ULL: goto x86_l_26b4;
	case 0x26e1ULL: goto x86_l_26e1;
	case 0x270fULL: goto x86_l_270f;
	case 0x273dULL: goto x86_l_273d;
	case 0x276bULL: goto x86_l_276b;
	case 0x2799ULL: goto x86_l_2799;
	case 0x27c7ULL: goto x86_l_27c7;
	case 0x27f5ULL: goto x86_l_27f5;
	case 0x281fULL: goto x86_l_281f;
	case 0x284bULL: goto x86_l_284b;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2a92:
	switch (__x86_sim_ret_addr) {
	case 0x226aULL: goto x86_l_226a;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2c87:
	switch (__x86_sim_ret_addr) {
	case 0x2a50ULL: goto x86_l_2a50;
	case 0x2a75ULL: goto x86_l_2a75;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
