#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 208U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(6) M(7) M(9) M(10) M(11) M(13)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 config_map[] __ksym;
extern __u8 enforcer_data[] __ksym;
extern __u8 enforcer_missed_notifications[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 policy_conf[] __ksym;
extern __u8 policy_stats[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 ratelimit_heap[] __ksym;
extern __u8 ratelimit_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 stack_trace_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 usdt_calls[] __ksym;
extern __u8 write_offload[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BZHI_MEM, X86_OP_BZHI_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_MEM_IMM, X86_OP_IMUL_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("uprobe.multi")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_8:
	/* 0x8: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_13:
	/* 0x13: mov    rdi,QWORD PTR [rip+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_1a:
	/* 0x1a: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f:
	/* 0x1f: call   7ee4 <read_reg+0x71d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24:
	/* 0x24: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27:
	/* 0x27: je     121 <generic_usdt_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27, 0x121, x86_l_121);
x86_l_2d:
	/* 0x2d: mov    r14d,DWORD PTR [rax+0x5f04] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_34:
	/* 0x34: cmp    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_38:
	/* 0x38: jl     121 <generic_usdt_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_L, 0x38, 0x121, x86_l_121);
x86_l_3e:
	/* 0x3e: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_4b:
	/* 0x4b: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e:
	/* 0x4e: call   7f13 <read_reg+0x7208> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     121 <generic_usdt_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x121, x86_l_121);
x86_l_5c:
	/* 0x5c: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_5f:
	/* 0x5f: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_65:
	/* 0x65: add    r14d,DWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_69:
	/* 0x69: and    r14d,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_70:
	/* 0x70: add    r14,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_73:
	/* 0x73: mov    BYTE PTR [rsp+0x7],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771073ULL);
x86_l_78:
	/* 0x78: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_80:
	/* 0x80: mov    rdi,QWORD PTR [rip+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_conf));
x86_l_87:
	/* 0x87: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8c:
	/* 0x8c: call   7f51 <read_reg+0x7246> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_91:
	/* 0x91: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_94:
	/* 0x94: je     a4 <generic_usdt_actions+0xa4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94, 0xa4, x86_l_a4);
x86_l_96:
	/* 0x96: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_99:
	/* 0x99: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_9c:
	/* 0x9c: cmp    DWORD PTR [r14],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_a0:
	/* 0xa0: jae    ac <generic_usdt_actions+0xac> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xa0, 0xac, x86_l_ac);
x86_l_a2:
	/* 0xa2: jmp    106 <generic_usdt_actions+0x106> */
	X86_SIM_X86_JMP(0xa2, 0x106, x86_l_106);
x86_l_a4:
	/* 0xa4: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a6:
	/* 0xa6: cmp    DWORD PTR [r14],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_aa:
	/* 0xaa: jb     106 <generic_usdt_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_B, 0xaa, 0x106, x86_l_106);
x86_l_ac:
	/* 0xac: movzx  ebp,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_af:
	/* 0xaf: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_b4:
	/* 0xb4: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b7:
	/* 0xb7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b9:
	/* 0xb9: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bc:
	/* 0xbc: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_bf:
	/* 0xbf: call   0 <generic_usdt_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0xc4ULL);
x86_l_c4:
	/* 0xc4: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_cb:
	/* 0xcb: cmp    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_ce:
	/* 0xce: jae    106 <generic_usdt_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xce, 0x106, x86_l_106);
x86_l_d0:
	/* 0xd0: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_d5:
	/* 0xd5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d8:
	/* 0xd8: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_da:
	/* 0xda: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_dd:
	/* 0xdd: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_e0:
	/* 0xe0: call   0 <generic_usdt_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0xe5ULL);
x86_l_e5:
	/* 0xe5: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_ec:
	/* 0xec: cmp    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_ef:
	/* 0xef: jae    106 <generic_usdt_actions+0x106> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xef, 0x106, x86_l_106);
x86_l_f1:
	/* 0xf1: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_f6:
	/* 0xf6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f9:
	/* 0xf9: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_fb:
	/* 0xfb: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fe:
	/* 0xfe: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_101:
	/* 0x101: call   0 <generic_usdt_actions> */
	X86_SIM_X86_CALL(x86_l_130, 0x106ULL);
x86_l_106:
	/* 0x106: cmp    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_10b:
	/* 0x10b: je     121 <generic_usdt_actions+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10b, 0x121, x86_l_121);
x86_l_10d:
	/* 0x10d: mov    rsi,QWORD PTR [rip+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)usdt_calls));
x86_l_114:
	/* 0x114: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_117:
	/* 0x117: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_11c:
	/* 0x11c: call   7fe1 <read_reg+0x72d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_121:
	/* 0x121: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_123:
	/* 0x123: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_127:
	/* 0x127: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_128:
	/* 0x128: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_12b:
	/* 0x12b: jmp    e21 <read_reg+0x116> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_e21:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_130 */
x86_l_130:
	/* 0x130: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_131:
	/* 0x131: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_133:
	/* 0x133: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_135:
	/* 0x135: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_139:
	/* 0x139: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13a:
	/* 0x13a: sub    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 104ULL);
x86_l_13e:
	/* 0x13e: mov    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_141:
	/* 0x141: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_146:
	/* 0x146: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_149:
	/* 0x149: mov    r14d,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14c:
	/* 0x14c: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14f:
	/* 0x14f: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_151:
	/* 0x151: movsxd r12,DWORD PTR [rdx+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_RAX, 2, X86_WIDTH_32), 4ULL);
x86_l_156:
	/* 0x156: mov    DWORD PTR [rsp+0x5c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
x86_l_15e:
	/* 0x15e: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_165:
	/* 0x165: lea    rsi,[rsp+0x5c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_16a:
	/* 0x16a: call   2d0f <read_reg+0x2004> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16f:
	/* 0x16f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_172:
	/* 0x172: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174:
	/* 0x174: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_177:
	/* 0x177: je     cc9 <do_action+0xb99> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x177, 0xcc9, x86_l_cc9);
x86_l_17d:
	/* 0x17d: cmp    r12d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_181:
	/* 0x181: jg     1ab <do_action+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x181, 0x1ab, x86_l_1ab);
x86_l_183:
	/* 0x183: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_187:
	/* 0x187: jg     1e4 <do_action+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x187, 0x1e4, x86_l_1e4);
x86_l_189:
	/* 0x189: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_18d:
	/* 0x18d: jg     3e3 <do_action+0x2b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x18d, 0x3e3, x86_l_3e3);
x86_l_193:
	/* 0x193: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_196:
	/* 0x196: je     69a <do_action+0x56a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x196, 0x69a, x86_l_69a);
x86_l_19c:
	/* 0x19c: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1a0:
	/* 0x1a0: je     3fc <do_action+0x2cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a0, 0x3fc, x86_l_3fc);
x86_l_1a6:
	/* 0x1a6: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0x1a6, 0xcbf, x86_l_cbf);
x86_l_1ab:
	/* 0x1ab: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1af:
	/* 0x1af: jg     2de <do_action+0x1ae> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1af, 0x2de, x86_l_2de);
x86_l_1b5:
	/* 0x1b5: lea    ecx,[r12-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_1ba:
	/* 0x1ba: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bd:
	/* 0x1bd: jb     532 <do_action+0x402> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bd, 0x532, x86_l_532);
x86_l_1c3:
	/* 0x1c3: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1c7:
	/* 0x1c7: je     60d <do_action+0x4dd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c7, 0x60d, x86_l_60d);
x86_l_1cd:
	/* 0x1cd: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1d1:
	/* 0x1d1: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d1, 0xcbf, x86_l_cbf);
x86_l_1d7:
	/* 0x1d7: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1da:
	/* 0x1da: mov    edi,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_1df:
	/* 0x1df: jmp    5de <do_action+0x4ae> */
	X86_SIM_X86_SUB_JMP(0x1df, 0x5de, x86_l_5de);
x86_l_1e4:
	/* 0x1e4: lea    eax,[r12-0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_1e9:
	/* 0x1e9: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ec:
	/* 0x1ec: jb     5fd <do_action+0x4cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ec, 0x5fd, x86_l_5fd);
x86_l_1f2:
	/* 0x1f2: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f6:
	/* 0x1f6: je     61a <do_action+0x4ea> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f6, 0x61a, x86_l_61a);
x86_l_1fc:
	/* 0x1fc: cmp    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_200:
	/* 0x200: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x200, 0xcbf, x86_l_cbf);
x86_l_206:
	/* 0x206: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20a:
	/* 0x20a: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_20f:
	/* 0x20f: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_213:
	/* 0x213: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_216:
	/* 0x216: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_219:
	/* 0x219: ja     cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x219, 0xcbf, x86_l_cbf);
x86_l_21f:
	/* 0x21f: cmp    DWORD PTR [rbx+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_227:
	/* 0x227: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x227, 0xcbf, x86_l_cbf);
x86_l_22d:
	/* 0x22d: mov    r15d,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_232:
	/* 0x232: mov    rax,QWORD PTR [rbx+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_23a:
	/* 0x23a: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_23f:
	/* 0x23f: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_247:
	/* 0x247: mov    eax,DWORD PTR [rbx+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_24e:
	/* 0x24e: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_252:
	/* 0x252: call   2df7 <read_reg+0x20ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_257:
	/* 0x257: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_25b:
	/* 0x25b: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25f:
	/* 0x25f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_266:
	/* 0x266: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: call   2e0e <read_reg+0x2103> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26e:
	/* 0x26e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271:
	/* 0x271: je     cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x271, 0xcbf, x86_l_cbf);
x86_l_277:
	/* 0x277: and    r15d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_27b:
	/* 0x27b: cmp    r15d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_27f:
	/* 0x27f: ja     cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x27f, 0xcbf, x86_l_cbf);
x86_l_285:
	/* 0x285: cmp    DWORD PTR [rbx+r15*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 104041287778304ULL);
x86_l_28e:
	/* 0x28e: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x28e, 0xcbf, x86_l_cbf);
x86_l_294:
	/* 0x294: mov    rcx,QWORD PTR [rbx+r15*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 3), 24184ULL);
x86_l_29c:
	/* 0x29c: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_2a2:
	/* 0x2a2: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2aa:
	/* 0x2aa: mov    ecx,DWORD PTR [rbx+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_2b1:
	/* 0x2b1: mov    DWORD PTR [rsp+0x8],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b5:
	/* 0x2b5: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b8:
	/* 0x2b8: call   2e5d <read_reg+0x2152> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_2bd:
	/* 0x2bd: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2c1:
	/* 0x2c1: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c5:
	/* 0x2c5: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_2cc:
	/* 0x2cc: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_2cf:
	/* 0x2cf: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d2:
	/* 0x2d2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d4:
	/* 0x2d4: call   2e79 <read_reg+0x216e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2d9:
	/* 0x2d9: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0x2d9, 0xcbf, x86_l_cbf);
x86_l_2de:
	/* 0x2de: cmp    r12d,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2e2:
	/* 0x2e2: je     73d <do_action+0x60d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2e2, 0x73d, x86_l_73d);
x86_l_2e8:
	/* 0x2e8: cmp    r12d,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2ec:
	/* 0x2ec: je     62a <do_action+0x4fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2ec, 0x62a, x86_l_62a);
x86_l_2f2:
	/* 0x2f2: cmp    r12d,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_2f6:
	/* 0x2f6: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2f6, 0xcbf, x86_l_cbf);
x86_l_2fc:
	/* 0x2fc: mov    QWORD PTR [rsp+0x48],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_301:
	/* 0x301: lea    eax,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_305:
	/* 0x305: mov    r13d,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_30b:
	/* 0x30b: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_30e:
	/* 0x30e: je     74e <do_action+0x61e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x30e, 0x74e, x86_l_74e);
x86_l_314:
	/* 0x314: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_318:
	/* 0x318: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_31a:
	/* 0x31a: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_31f:
	/* 0x31f: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_322:
	/* 0x322: mov    r14d,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_327:
	/* 0x327: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_32a:
	/* 0x32a: add    rsi,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_331:
	/* 0x331: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_338:
	/* 0x338: call   2edd <read_reg+0x21d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33d:
	/* 0x33d: mov    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_343:
	/* 0x343: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_346:
	/* 0x346: je     c5c <do_action+0xb2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x346, 0xc5c, x86_l_c5c);
x86_l_34c:
	/* 0x34c: and    r14d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_350:
	/* 0x350: lea    r14,[r14+r14*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 1), 0ULL);
x86_l_354:
	/* 0x354: cmp    BYTE PTR [rax+r14*8+0x211],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R14, 3), 2272037699587ULL);
x86_l_35d:
	/* 0x35d: jne    7b8 <do_action+0x688> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x35d, 0x7b8, x86_l_7b8);
x86_l_363:
	/* 0x363: mov    esi,DWORD PTR [rax+r14*8+0x208] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 3), 520ULL);
x86_l_36b:
	/* 0x36b: mov    rdi,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_370:
	/* 0x370: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_372:
	/* 0x372: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_375:
	/* 0x375: call   d0b <read_reg> */
	X86_SIM_X86_CALL(x86_l_d0b, 0x37aULL);
x86_l_37a:
	/* 0x37a: add    rax,QWORD PTR [r15+r14*8+0x200] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_R14, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 512ULL);
x86_l_382:
	/* 0x382: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_386:
	/* 0x386: mov    DWORD PTR [rsp+0x8],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38a:
	/* 0x38a: call   2f2f <read_reg+0x2224> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_38f:
	/* 0x38f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_394:
	/* 0x394: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)write_offload));
x86_l_39b:
	/* 0x39b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3a0:
	/* 0x3a0: call   2f45 <read_reg+0x223a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a5:
	/* 0x3a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a8:
	/* 0x3a8: je     bc4 <do_action+0xa94> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3a8, 0xbc4, x86_l_bc4);
x86_l_3ae:
	/* 0x3ae: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b1:
	/* 0x3b1: mov    DWORD PTR [rsp+0x18],0xe0011 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103080132625ULL);
x86_l_3b9:
	/* 0x3b9: mov    QWORD PTR [rsp+0x1c],0x371 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120259085169ULL);
x86_l_3c2:
	/* 0x3c2: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_3c9:
	/* 0x3c9: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3ce:
	/* 0x3ce: call   2f73 <read_reg+0x2268> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3d3:
	/* 0x3d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d6:
	/* 0x3d6: je     c2c <do_action+0xafc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3d6, 0xc2c, x86_l_c2c);
x86_l_3dc:
	/* 0x3dc: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3de:
	/* 0x3de: jmp    c4c <do_action+0xb1c> */
	X86_SIM_X86_SUB_JMP(0x3de, 0xc4c, x86_l_c4c);
x86_l_3e3:
	/* 0x3e3: mov    edi,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_3e8:
	/* 0x3e8: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3ec:
	/* 0x3ec: je     5de <do_action+0x4ae> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x3ec, 0x5de, x86_l_5de);
x86_l_3f2:
	/* 0x3f2: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_3f6:
	/* 0x3f6: jne    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3f6, 0xcbf, x86_l_cbf);
x86_l_3fc:
	/* 0x3fc: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_400:
	/* 0x400: mov    r13d,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_405:
	/* 0x405: add    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_409:
	/* 0x409: mov    ebp,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_40e:
	/* 0x40e: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_416:
	/* 0x416: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap));
x86_l_41d:
	/* 0x41d: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_422:
	/* 0x422: call   2fc7 <read_reg+0x22bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_427:
	/* 0x427: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42a:
	/* 0x42a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42d:
	/* 0x42d: je     cb8 <do_action+0xb88> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x42d, 0xcb8, x86_l_cb8);
x86_l_433:
	/* 0x433: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_436:
	/* 0x436: and    r13d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_43a:
	/* 0x43a: cmp    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_43e:
	/* 0x43e: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_443:
	/* 0x443: ja     cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x443, 0xcba, x86_l_cba);
x86_l_449:
	/* 0x449: cmp    DWORD PTR [rbx+r13*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 104041287778304ULL);
x86_l_452:
	/* 0x452: jne    cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x452, 0xcba, x86_l_cba);
x86_l_458:
	/* 0x458: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_45d:
	/* 0x45d: mov    rax,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_465:
	/* 0x465: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_46a:
	/* 0x46a: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_472:
	/* 0x472: mov    eax,DWORD PTR [rbx+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_479:
	/* 0x479: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_47d:
	/* 0x47d: call   3022 <read_reg+0x2317> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_482:
	/* 0x482: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_486:
	/* 0x486: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_48a:
	/* 0x48a: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_48e:
	/* 0x48e: jne    7c1 <do_action+0x691> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x48e, 0x7c1, x86_l_7c1);
x86_l_494:
	/* 0x494: and    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_497:
	/* 0x497: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_49a:
	/* 0x49a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49f:
	/* 0x49f: ja     cb8 <do_action+0xb88> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x49f, 0xcb8, x86_l_cb8);
x86_l_4a5:
	/* 0x4a5: cmp    DWORD PTR [rbx+rbp*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 104041287778304ULL);
x86_l_4ad:
	/* 0x4ad: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_4b2:
	/* 0x4b2: jne    cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4b2, 0xcba, x86_l_cba);
x86_l_4b8:
	/* 0x4b8: mov    rcx,QWORD PTR [rbx+rbp*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 3), 24184ULL);
x86_l_4c0:
	/* 0x4c0: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_4c6:
	/* 0x4c6: lea    rax,[rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4ca:
	/* 0x4ca: add    rax,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_4d0:
	/* 0x4d0: mov    esi,DWORD PTR [rbx+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_4d7:
	/* 0x4d7: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_4d9:
	/* 0x4d9: and    ecx,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_4df:
	/* 0x4df: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4e3:
	/* 0x4e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e6:
	/* 0x4e6: jns    c83 <do_action+0xb53> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4e6, 0xc83, x86_l_c83);
x86_l_4ec:
	/* 0x4ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ef:
	/* 0x4ef: jns    c92 <do_action+0xb62> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4ef, 0xc92, x86_l_c92);
x86_l_4f5:
	/* 0x4f5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4f7:
	/* 0x4f7: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4fa:
	/* 0x4fa: mov    rdi,QWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_4fe:
	/* 0x4fe: mov    QWORD PTR [rdx+r8*1],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_502:
	/* 0x502: lea    rdi,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_506:
	/* 0x506: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_50a:
	/* 0x50a: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_50d:
	/* 0x50d: jbe    4f7 <do_action+0x3c7> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x50d, 0x4f7, x86_l_4f7);
x86_l_50f:
	/* 0x50f: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_513:
	/* 0x513: jne    cd8 <do_action+0xba8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x513, 0xcd8, x86_l_cd8);
x86_l_519:
	/* 0x519: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_51d:
	/* 0x51d: jne    ceb <do_action+0xbbb> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x51d, 0xceb, x86_l_ceb);
x86_l_523:
	/* 0x523: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_527:
	/* 0x527: je     ca4 <do_action+0xb74> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x527, 0xca4, x86_l_ca4);
x86_l_52d:
	/* 0x52d: jmp    d00 <do_action+0xbd0> */
	X86_SIM_X86_SUB_JMP(0x52d, 0xd00, x86_l_d00);
x86_l_532:
	/* 0x532: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_535:
	/* 0x535: mov    ecx,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_53a:
	/* 0x53a: and    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_53d:
	/* 0x53d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_540:
	/* 0x540: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_543:
	/* 0x543: ja     cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x543, 0xcba, x86_l_cba);
x86_l_549:
	/* 0x549: cmp    DWORD PTR [rbx+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_551:
	/* 0x551: jne    cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x551, 0xcba, x86_l_cba);
x86_l_557:
	/* 0x557: mov    rcx,QWORD PTR [rbx+rcx*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24184ULL);
x86_l_55f:
	/* 0x55f: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_565:
	/* 0x565: mov    rcx,QWORD PTR [rbx+rcx*1+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 184ULL);
x86_l_56d:
	/* 0x56d: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_572:
	/* 0x572: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_575:
	/* 0x575: je     cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x575, 0xcba, x86_l_cba);
x86_l_57b:
	/* 0x57b: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_57f:
	/* 0x57f: jne    7cd <do_action+0x69d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x57f, 0x7cd, x86_l_7cd);
x86_l_585:
	/* 0x585: call   312a <read_reg+0x241f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_58a:
	/* 0x58a: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58d:
	/* 0x58d: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_591:
	/* 0x591: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_594:
	/* 0x594: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_59b:
	/* 0x59b: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_59e:
	/* 0x59e: call   3143 <read_reg+0x2438> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5a3:
	/* 0x5a3: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a6:
	/* 0x5a6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a9:
	/* 0x5a9: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_5ae:
	/* 0x5ae: je     cba <do_action+0xb8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5ae, 0xcba, x86_l_cba);
x86_l_5b4:
	/* 0x5b4: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b6:
	/* 0x5b6: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b9:
	/* 0x5b9: mov    DWORD PTR [rsp+0x4],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5be:
	/* 0x5be: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c2:
	/* 0x5c2: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c7:
	/* 0x5c7: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_5ce:
	/* 0x5ce: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5d1:
	/* 0x5d1: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5d6:
	/* 0x5d6: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_5d9:
	/* 0x5d9: jmp    cb1 <do_action+0xb81> */
	X86_SIM_X86_SUB_JMP(0x5d9, 0xcb1, x86_l_cb1);
x86_l_5de:
	/* 0x5de: mov    r13d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_5e4:
	/* 0x5e4: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_5e7:
	/* 0x5e7: je     c61 <do_action+0xb31> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5e7, 0xc61, x86_l_c61);
x86_l_5ed:
	/* 0x5ed: call   3192 <read_reg+0x2487> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_send_signal);
x86_l_5f2:
	/* 0x5f2: mov    r13d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5f8:
	/* 0x5f8: jmp    c61 <do_action+0xb31> */
	X86_SIM_X86_SUB_JMP(0x5f8, 0xc61, x86_l_c61);
x86_l_5fd:
	/* 0x5fd: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_600:
	/* 0x600: mov    eax,DWORD PTR [r15+r14*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 4ULL);
x86_l_605:
	/* 0x605: mov    DWORD PTR [rbx+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_608:
	/* 0x608: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0x608, 0xcbf, x86_l_cbf);
x86_l_60d:
	/* 0x60d: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_612:
	/* 0x612: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_615:
	/* 0x615: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0x615, 0xcbf, x86_l_cbf);
x86_l_61a:
	/* 0x61a: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_61d:
	/* 0x61d: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_621:
	/* 0x621: xor    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 5ULL);
x86_l_625:
	/* 0x625: jmp    c61 <do_action+0xb31> */
	X86_SIM_X86_SUB_JMP(0x625, 0xc61, x86_l_c61);
x86_l_62a:
	/* 0x62a: call   31cf <read_reg+0x24c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_62f:
	/* 0x62f: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_634:
	/* 0x634: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_63b:
	/* 0x63b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_640:
	/* 0x640: call   31e5 <read_reg+0x24da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_645:
	/* 0x645: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_648:
	/* 0x648: je     cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x648, 0xcbf, x86_l_cbf);
x86_l_64e:
	/* 0x64e: mov    rax,QWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_652:
	/* 0x652: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_657:
	/* 0x657: mov    DWORD PTR [rsp+0x20],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953474ULL);
x86_l_65f:
	/* 0x65f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_666:
	/* 0x666: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_66b:
	/* 0x66b: call   3210 <read_reg+0x2505> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_670:
	/* 0x670: mov    DWORD PTR [rsp+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_678:
	/* 0x678: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67b:
	/* 0x67b: je     756 <do_action+0x626> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x67b, 0x756, x86_l_756);
x86_l_681:
	/* 0x681: lock inc DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_684:
	/* 0x684: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_68b:
	/* 0x68b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_690:
	/* 0x690: call   3235 <read_reg+0x252a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_695:
	/* 0x695: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0x695, 0xcbf, x86_l_cbf);
x86_l_69a:
	/* 0x69a: lea    eax,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_69e:
	/* 0x69e: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_6a3:
	/* 0x6a3: lea    eax,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_6a7:
	/* 0x6a7: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_6ac:
	/* 0x6ac: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6b0:
	/* 0x6b0: call   3255 <read_reg+0x254a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_6b5:
	/* 0x6b5: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b9:
	/* 0x6b9: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_6c1:
	/* 0x6c1: mov    QWORD PTR [rsp+0x60],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_6c6:
	/* 0x6c6: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_6c9:
	/* 0x6c9: je     b58 <do_action+0xa28> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6c9, 0xb58, x86_l_b58);
x86_l_6cf:
	/* 0x6cf: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_heap));
x86_l_6d6:
	/* 0x6d6: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6db:
	/* 0x6db: call   3280 <read_reg+0x2575> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6e0:
	/* 0x6e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e3:
	/* 0x6e3: je     b58 <do_action+0xa28> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6e3, 0xb58, x86_l_b58);
x86_l_6e9:
	/* 0x6e9: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_6ee:
	/* 0x6ee: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f1:
	/* 0x6f1: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_6f8:
	/* 0x6f8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6fd:
	/* 0x6fd: call   32a2 <read_reg+0x2597> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_702:
	/* 0x702: mov    rcx,QWORD PTR [rbx+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_706:
	/* 0x706: mov    QWORD PTR [rbp+0x0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_70a:
	/* 0x70a: mov    rcx,QWORD PTR [rbx+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_70e:
	/* 0x70e: mov    QWORD PTR [rsp+0x40],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_713:
	/* 0x713: mov    QWORD PTR [rbp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_717:
	/* 0x717: mov    ecx,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_71b:
	/* 0x71b: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_71e:
	/* 0x71e: je     7eb <do_action+0x6bb> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x71e, 0x7eb, x86_l_7eb);
x86_l_724:
	/* 0x724: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_727:
	/* 0x727: je     7e6 <do_action+0x6b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x727, 0x7e6, x86_l_7e6);
x86_l_72d:
	/* 0x72d: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_72f:
	/* 0x72f: jne    b58 <do_action+0xa28> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x72f, 0xb58, x86_l_b58);
x86_l_735:
	/* 0x735: mov    ecx,DWORD PTR [rbx+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_738:
	/* 0x738: jmp    7ed <do_action+0x6bd> */
	X86_SIM_X86_SUB_JMP(0x738, 0x7ed, x86_l_7ed);
x86_l_73d:
	/* 0x73d: add    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_741:
	/* 0x741: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_745:
	/* 0x745: xor    r13,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 7ULL);
x86_l_749:
	/* 0x749: jmp    c61 <do_action+0xb31> */
	X86_SIM_X86_SUB_JMP(0x749, 0xc61, x86_l_c61);
x86_l_74e:
	/* 0x74e: mov    r14d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_751:
	/* 0x751: jmp    c61 <do_action+0xb31> */
	X86_SIM_X86_SUB_JMP(0x751, 0xc61, x86_l_c61);
x86_l_756:
	/* 0x756: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_75d:
	/* 0x75d: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_762:
	/* 0x762: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_767:
	/* 0x767: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_76c:
	/* 0x76c: call   3311 <read_reg+0x2606> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_771:
	/* 0x771: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_774:
	/* 0x774: je     684 <do_action+0x554> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x774, 0x684, x86_l_684);
x86_l_77a:
	/* 0x77a: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77d:
	/* 0x77d: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_77f:
	/* 0x77f: mov    WORD PTR [rsp],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_783:
	/* 0x783: mov    WORD PTR [rsp+0x2],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934595ULL);
x86_l_78a:
	/* 0x78a: movabs rax,0x20000003b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8589934651ULL);
x86_l_794:
	/* 0x794: mov    QWORD PTR [rsp+0x4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_799:
	/* 0x799: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_7a0:
	/* 0x7a0: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_7a3:
	/* 0x7a3: call   3348 <read_reg+0x263d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7a8:
	/* 0x7a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ab:
	/* 0x7ab: je     bdf <do_action+0xaaf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7ab, 0xbdf, x86_l_bdf);
x86_l_7b1:
	/* 0x7b1: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7b3:
	/* 0x7b3: jmp    bfd <do_action+0xacd> */
	X86_SIM_X86_SUB_JMP(0x7b3, 0xbfd, x86_l_bfd);
x86_l_7b8:
	/* 0x7b8: or     BYTE PTR [rbx+0x1],0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967328ULL);
x86_l_7bc:
	/* 0x7bc: jmp    c5c <do_action+0xb2c> */
	X86_SIM_X86_SUB_JMP(0x7bc, 0xc5c, x86_l_c5c);
x86_l_7c1:
	/* 0x7c1: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_7c8:
	/* 0x7c8: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_7cb:
	/* 0x7cb: jmp    7d9 <do_action+0x6a9> */
	X86_SIM_X86_SUB_JMP(0x7cb, 0x7d9, x86_l_7d9);
x86_l_7cd:
	/* 0x7cd: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_7d4:
	/* 0x7d4: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7d9:
	/* 0x7d9: call   337e <read_reg+0x2673> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_7de:
	/* 0x7de: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e1:
	/* 0x7e1: jmp    cb8 <do_action+0xb88> */
	X86_SIM_X86_SUB_JMP(0x7e1, 0xcb8, x86_l_cb8);
x86_l_7e6:
	/* 0x7e6: mov    ecx,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7e9:
	/* 0x7e9: jmp    7ed <do_action+0x6bd> */
	X86_SIM_X86_SUB_JMP(0x7e9, 0x7ed, x86_l_7ed);
x86_l_7eb:
	/* 0x7eb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ed:
	/* 0x7ed: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7ef:
	/* 0x7ef: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7f4:
	/* 0x7f4: mov    QWORD PTR [rdx+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7f8:
	/* 0x7f8: mov    rdi,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7fd:
	/* 0x7fd: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_801:
	/* 0x801: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_804:
	/* 0x804: mov    QWORD PTR [rsp+0x48],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_809:
	/* 0x809: mov    QWORD PTR [rsp+0x50],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_80e:
	/* 0x80e: jns    92a <do_action+0x7fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x80e, 0x92a, x86_l_92a);
x86_l_814:
	/* 0x814: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_817:
	/* 0x817: jns    939 <do_action+0x809> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x817, 0x939, x86_l_939);
x86_l_81d:
	/* 0x81d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_820:
	/* 0x820: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_825:
	/* 0x825: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_829:
	/* 0x829: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_82d:
	/* 0x82d: mov    QWORD PTR [rdx+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_831:
	/* 0x831: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_835:
	/* 0x835: mov    QWORD PTR [rdx+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_839:
	/* 0x839: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_83d:
	/* 0x83d: mov    QWORD PTR [rdx+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_841:
	/* 0x841: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_845:
	/* 0x845: mov    QWORD PTR [rdx+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_849:
	/* 0x849: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_84d:
	/* 0x84d: mov    QWORD PTR [rdx+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_851:
	/* 0x851: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_855:
	/* 0x855: mov    QWORD PTR [rdx+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_859:
	/* 0x859: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_85d:
	/* 0x85d: mov    QWORD PTR [rdx+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_861:
	/* 0x861: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_865:
	/* 0x865: mov    QWORD PTR [rdx+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_869:
	/* 0x869: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_86d:
	/* 0x86d: mov    QWORD PTR [rdx+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_871:
	/* 0x871: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_875:
	/* 0x875: mov    QWORD PTR [rdx+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_879:
	/* 0x879: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_87d:
	/* 0x87d: mov    QWORD PTR [rdx+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_881:
	/* 0x881: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_885:
	/* 0x885: mov    QWORD PTR [rdx+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_889:
	/* 0x889: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_88d:
	/* 0x88d: mov    QWORD PTR [rdx+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_894:
	/* 0x894: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_898:
	/* 0x898: mov    QWORD PTR [rdx+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_89f:
	/* 0x89f: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_8a3:
	/* 0x8a3: mov    QWORD PTR [rdx+0x90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_8aa:
	/* 0x8aa: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8b1:
	/* 0x8b1: mov    QWORD PTR [rdx+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_8b8:
	/* 0x8b8: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_8bf:
	/* 0x8bf: mov    QWORD PTR [rdx+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_8c6:
	/* 0x8c6: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_8cd:
	/* 0x8cd: mov    QWORD PTR [rdx+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_8d4:
	/* 0x8d4: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_8db:
	/* 0x8db: mov    QWORD PTR [rdx+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_8e2:
	/* 0x8e2: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_8e9:
	/* 0x8e9: mov    QWORD PTR [rdx+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_8f0:
	/* 0x8f0: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_8f7:
	/* 0x8f7: mov    QWORD PTR [rdx+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_8fe:
	/* 0x8fe: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_905:
	/* 0x905: mov    QWORD PTR [rdx+0xc8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_90c:
	/* 0x90c: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_913:
	/* 0x913: mov    QWORD PTR [rdx+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_91a:
	/* 0x91a: mov    rax,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_921:
	/* 0x921: mov    QWORD PTR [rdx+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_928:
	/* 0x928: jmp    945 <do_action+0x815> */
	X86_SIM_X86_SUB_JMP(0x928, 0x945, x86_l_945);
x86_l_92a:
	/* 0x92a: mov    esi,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_92f:
	/* 0x92f: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_932:
	/* 0x932: call   34d7 <read_reg+0x27cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_937:
	/* 0x937: jmp    945 <do_action+0x815> */
	X86_SIM_X86_SUB_JMP(0x937, 0x945, x86_l_945);
x86_l_939:
	/* 0x939: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_93e:
	/* 0x93e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_940:
	/* 0x940: call   34e5 <read_reg+0x27da> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_945:
	/* 0x945: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_948:
	/* 0x948: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_94f:
	/* 0x94f: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_957:
	/* 0x957: jmp    985 <do_action+0x855> */
	X86_SIM_X86_SUB_JMP(0x957, 0x985, x86_l_985);
x86_l_959:
	/* 0x959: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_95b:
	/* 0x95b: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_960:
	/* 0x960: call   3505 <read_reg+0x27fa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_965:
	/* 0x965: mov    r8,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_96a:
	/* 0x96a: add    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_96d:
	/* 0x96d: mov    DWORD PTR [rsp+0x28],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_971:
	/* 0x971: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_978:
	/* 0x978: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_97b:
	/* 0x97b: cmp    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 5ULL);
x86_l_97f:
	/* 0x97f: je     b0b <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x97f, 0xb0b, x86_l_b0b);
x86_l_985:
	/* 0x985: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_98d:
	/* 0x98d: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_990:
	/* 0x990: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_995:
	/* 0x995: call   353a <read_reg+0x282f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_99a:
	/* 0x99a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_99d:
	/* 0x99d: je     b0b <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x99d, 0xb0b, x86_l_b0b);
x86_l_9a3:
	/* 0x9a3: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_9a9:
	/* 0x9a9: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_9b0:
	/* 0x9b0: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9b3:
	/* 0x9b3: call   3558 <read_reg+0x284d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9b8:
	/* 0x9b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9bb:
	/* 0x9bb: je     b0b <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9bb, 0xb0b, x86_l_b0b);
x86_l_9c1:
	/* 0x9c1: cmp    DWORD PTR [rax+r13*4+0x40],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 279172874239ULL);
x86_l_9c7:
	/* 0x9c7: je     b0b <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9c7, 0xb0b, x86_l_b0b);
x86_l_9cd:
	/* 0x9cd: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_9d5:
	/* 0x9d5: mov    eax,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9d8:
	/* 0x9d8: cmp    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9db:
	/* 0x9db: jge    b0b <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x9db, 0xb0b, x86_l_b0b);
x86_l_9e1:
	/* 0x9e1: cmp    r13,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_9e5:
	/* 0x9e5: je     a3f <do_action+0x90f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9e5, 0xa3f, x86_l_a3f);
x86_l_9e7:
	/* 0x9e7: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_9ef:
	/* 0x9ef: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_9f2:
	/* 0x9f2: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_9f7:
	/* 0x9f7: call   359c <read_reg+0x2891> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9fc:
	/* 0x9fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ff:
	/* 0x9ff: je     a37 <do_action+0x907> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9ff, 0xa37, x86_l_a37);
x86_l_a01:
	/* 0xa01: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_a07:
	/* 0xa07: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_a0e:
	/* 0xa0e: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a11:
	/* 0xa11: call   35b6 <read_reg+0x28ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a16:
	/* 0xa16: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a19:
	/* 0xa19: je     a37 <do_action+0x907> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa19, 0xa37, x86_l_a37);
x86_l_a1b:
	/* 0xa1b: cmp    DWORD PTR [rax+r13*4+0x44],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 296352743423ULL);
x86_l_a21:
	/* 0xa21: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_a29:
	/* 0xa29: je     a3f <do_action+0x90f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa29, 0xa3f, x86_l_a3f);
x86_l_a2b:
	/* 0xa2b: mov    ecx,DWORD PTR [rbx+r13*8+0x5e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 24192ULL);
x86_l_a33:
	/* 0xa33: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_a35:
	/* 0xa35: jmp    a47 <do_action+0x917> */
	X86_SIM_X86_SUB_JMP(0xa35, 0xa47, x86_l_a47);
x86_l_a37:
	/* 0xa37: mov    rdx,QWORD PTR [rbx+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_a3f:
	/* 0xa3f: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a42:
	/* 0xa42: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_a44:
	/* 0xa44: add    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_a47:
	/* 0xa47: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a49:
	/* 0xa49: jle    978 <do_action+0x848> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xa49, 0x978, x86_l_978);
x86_l_a4f:
	/* 0xa4f: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a51:
	/* 0xa51: cmp    ecx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_a54:
	/* 0xa54: jl     a5b <do_action+0x92b> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xa54, 0xa5b, x86_l_a5b);
x86_l_a56:
	/* 0xa56: mov    ebp,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_a5b:
	/* 0xa5b: add    edx,0x3ffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16380ULL);
x86_l_a61:
	/* 0xa61: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_a67:
	/* 0xa67: movzx  r8d,BYTE PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 40ULL);
x86_l_a6d:
	/* 0xa6d: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a72:
	/* 0xa72: lea    rdi,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_a76:
	/* 0xa76: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a79:
	/* 0xa79: add    rdx,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_a80:
	/* 0xa80: jns    959 <do_action+0x829> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xa80, 0x959, x86_l_959);
x86_l_a86:
	/* 0xa86: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a89:
	/* 0xa89: jns    ac2 <do_action+0x992> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xa89, 0xac2, x86_l_ac2);
x86_l_a8b:
	/* 0xa8b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a8d:
	/* 0xa8d: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_a90:
	/* 0xa90: jb     aaa <do_action+0x97a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa90, 0xaaa, x86_l_aaa);
x86_l_a92:
	/* 0xa92: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a94:
	/* 0xa94: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a96:
	/* 0xa96: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_a9a:
	/* 0xa9a: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_a9e:
	/* 0xa9e: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aa1:
	/* 0xaa1: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_aa4:
	/* 0xaa4: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_aa6:
	/* 0xaa6: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_aa8:
	/* 0xaa8: jbe    a94 <do_action+0x964> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xaa8, 0xa94, x86_l_a94);
x86_l_aaa:
	/* 0xaaa: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_aae:
	/* 0xaae: jne    ad5 <do_action+0x9a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xaae, 0xad5, x86_l_ad5);
x86_l_ab0:
	/* 0xab0: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_ab4:
	/* 0xab4: jne    ae6 <do_action+0x9b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xab4, 0xae6, x86_l_ae6);
x86_l_ab6:
	/* 0xab6: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_aba:
	/* 0xaba: je     96a <do_action+0x83a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaba, 0x96a, x86_l_96a);
x86_l_ac0:
	/* 0xac0: jmp    afd <do_action+0x9cd> */
	X86_SIM_X86_SUB_JMP(0xac0, 0xafd, x86_l_afd);
x86_l_ac2:
	/* 0xac2: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_ac4:
	/* 0xac4: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac6:
	/* 0xac6: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_acb:
	/* 0xacb: call   3670 <read_reg+0x2965> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_ad0:
	/* 0xad0: jmp    965 <do_action+0x835> */
	X86_SIM_X86_SUB_JMP(0xad0, 0x965, x86_l_965);
x86_l_ad5:
	/* 0xad5: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_ad7:
	/* 0xad7: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_ada:
	/* 0xada: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_add:
	/* 0xadd: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_ae0:
	/* 0xae0: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_ae4:
	/* 0xae4: je     ab6 <do_action+0x986> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xae4, 0xab6, x86_l_ab6);
x86_l_ae6:
	/* 0xae6: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_ae8:
	/* 0xae8: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_aec:
	/* 0xaec: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_af0:
	/* 0xaf0: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_af3:
	/* 0xaf3: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_af7:
	/* 0xaf7: je     96a <do_action+0x83a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaf7, 0x96a, x86_l_96a);
x86_l_afd:
	/* 0xafd: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_aff:
	/* 0xaff: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_b03:
	/* 0xb03: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_b06:
	/* 0xb06: jmp    96a <do_action+0x83a> */
	X86_SIM_X86_SUB_JMP(0xb06, 0x96a, x86_l_96a);
x86_l_b0b:
	/* 0xb0b: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_b12:
	/* 0xb12: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b17:
	/* 0xb17: call   36bc <read_reg+0x29b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b1c:
	/* 0xb1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1f:
	/* 0xb1f: je     b3d <do_action+0xa0d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb1f, 0xb3d, x86_l_b3d);
x86_l_b21:
	/* 0xb21: imul   rcx,QWORD PTR [rsp+0x60],0xfffffffffff0bdc0 */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 416610827712ULL);
x86_l_b2a:
	/* 0xb2a: add    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b2e:
	/* 0xb2e: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b31:
	/* 0xb31: jbe    b3d <do_action+0xa0d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xb31, 0xb3d, x86_l_b3d);
x86_l_b33:
	/* 0xb33: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b38:
	/* 0xb38: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b3b:
	/* 0xb3b: jmp    b53 <do_action+0xa23> */
	X86_SIM_X86_SUB_JMP(0xb3b, 0xb53, x86_l_b53);
x86_l_b3d:
	/* 0xb3d: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_b44:
	/* 0xb44: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b47:
	/* 0xb47: mov    rsi,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b4c:
	/* 0xb4c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b4e:
	/* 0xb4e: call   36f3 <read_reg+0x29e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b53:
	/* 0xb53: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_b58:
	/* 0xb58: lea    eax,[r14+0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_b5c:
	/* 0xb5c: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_b62:
	/* 0xb62: je     b80 <do_action+0xa50> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb62, 0xb80, x86_l_b80);
x86_l_b64:
	/* 0xb64: or     BYTE PTR [rbx+0x1],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967298ULL);
x86_l_b68:
	/* 0xb68: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_b6f:
	/* 0xb6f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b72:
	/* 0xb72: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b74:
	/* 0xb74: call   3719 <read_reg+0x2a0e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_b79:
	/* 0xb79: mov    QWORD PTR [rbx+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_b80:
	/* 0xb80: lea    eax,[r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b84:
	/* 0xb84: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_b8a:
	/* 0xb8a: je     bab <do_action+0xa7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb8a, 0xbab, x86_l_bab);
x86_l_b8c:
	/* 0xb8c: or     BYTE PTR [rbx+0x1],0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967300ULL);
x86_l_b90:
	/* 0xb90: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_b97:
	/* 0xb97: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_b9c:
	/* 0xb9c: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b9f:
	/* 0xb9f: call   3744 <read_reg+0x2a39> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_ba4:
	/* 0xba4: mov    QWORD PTR [rbx+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_bab:
	/* 0xbab: add    r14d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_baf:
	/* 0xbaf: cmp    DWORD PTR [r15+r14*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 2), 17179869184ULL);
x86_l_bb5:
	/* 0xbb5: je     cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbb5, 0xcbf, x86_l_cbf);
x86_l_bbb:
	/* 0xbbb: or     BYTE PTR [rbx+0x1],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967304ULL);
x86_l_bbf:
	/* 0xbbf: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0xbbf, 0xcbf, x86_l_cbf);
x86_l_bc4:
	/* 0xbc4: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)write_offload));
x86_l_bcb:
	/* 0xbcb: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bd0:
	/* 0xbd0: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_bd3:
	/* 0xbd3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bd5:
	/* 0xbd5: call   377a <read_reg+0x2a6f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_bda:
	/* 0xbda: jmp    c5c <do_action+0xb2c> */
	X86_SIM_X86_SUB_JMP(0xbda, 0xc5c, x86_l_c5c);
x86_l_bdf:
	/* 0xbdf: mov    DWORD PTR [rsp+0x38],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518168577ULL);
x86_l_be7:
	/* 0xbe7: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_bee:
	/* 0xbee: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_bf1:
	/* 0xbf1: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_bf6:
	/* 0xbf6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bf8:
	/* 0xbf8: call   379a <read_reg+0x2a8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_bfd:
	/* 0xbfd: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_c00:
	/* 0xc00: je     684 <do_action+0x554> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc00, 0x684, x86_l_684);
x86_l_c06:
	/* 0xc06: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_c0d:
	/* 0xc0d: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c12:
	/* 0xc12: call   37b4 <read_reg+0x2aa9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c17:
	/* 0xc17: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c1a:
	/* 0xc1a: je     684 <do_action+0x554> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc1a, 0x684, x86_l_684);
x86_l_c20:
	/* 0xc20: mov    ecx,DWORD PTR [rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_c24:
	/* 0xc24: lock add DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RCX, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_c27:
	/* 0xc27: jmp    684 <do_action+0x554> */
	X86_SIM_X86_SUB_JMP(0xc27, 0x684, x86_l_684);
x86_l_c2c:
	/* 0xc2c: mov    DWORD PTR [rsp+0x38],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 240518168577ULL);
x86_l_c34:
	/* 0xc34: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_c3b:
	/* 0xc3b: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c40:
	/* 0xc40: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c45:
	/* 0xc45: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c47:
	/* 0xc47: call   37e9 <read_reg+0x2ade> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_c4c:
	/* 0xc4c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c50:
	/* 0xc50: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c55:
	/* 0xc55: mov    QWORD PTR [r14+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c59:
	/* 0xc59: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5c:
	/* 0xc5c: mov    r14d,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c61:
	/* 0xc61: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c68:
	/* 0xc68: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_stats));
x86_l_c6f:
	/* 0xc6f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_c72:
	/* 0xc72: call   3814 <read_reg+0x2b09> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c77:
	/* 0xc77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7a:
	/* 0xc7a: je     c81 <do_action+0xb51> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc7a, 0xc81, x86_l_c81);
x86_l_c7c:
	/* 0xc7c: lock inc QWORD PTR [rax+r13*8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_R13, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_c81:
	/* 0xc81: jmp    cbf <do_action+0xb8f> */
	X86_SIM_X86_SUB_JMP(0xc81, 0xcbf, x86_l_cbf);
x86_l_c83:
	/* 0xc83: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c86:
	/* 0xc86: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c88:
	/* 0xc88: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c8b:
	/* 0xc8b: call   382d <read_reg+0x2b22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_c90:
	/* 0xc90: jmp    c9f <do_action+0xb6f> */
	X86_SIM_X86_SUB_JMP(0xc90, 0xc9f, x86_l_c9f);
x86_l_c92:
	/* 0xc92: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c95:
	/* 0xc95: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c97:
	/* 0xc97: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c9a:
	/* 0xc9a: call   383c <read_reg+0x2b31> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_c9f:
	/* 0xc9f: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ca4:
	/* 0xca4: mov    rdi,QWORD PTR [rip+0x2b9d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_cab:
	/* 0xcab: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cae:
	/* 0xcae: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_cb1:
	/* 0xcb1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cb3:
	/* 0xcb3: call   3855 <read_reg+0x2b4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_cb8:
	/* 0xcb8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cba:
	/* 0xcba: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_cbd:
	/* 0xcbd: jne    cc9 <do_action+0xb99> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xcbd, 0xcc9, x86_l_cc9);
x86_l_cbf:
	/* 0xcbf: mov    QWORD PTR [rbx+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_cc3:
	/* 0xcc3: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_cc6:
	/* 0xcc6: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_cc9:
	/* 0xcc9: add    rsp,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 104ULL);
x86_l_ccd:
	/* 0xccd: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cce:
	/* 0xcce: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cd0:
	/* 0xcd0: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cd2:
	/* 0xcd2: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cd4:
	/* 0xcd4: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cd6:
	/* 0xcd6: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_cd7:
	/* 0xcd7: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_cd7);
x86_l_cd8:
	/* 0xcd8: mov    ecx,DWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_cdb:
	/* 0xcdb: mov    DWORD PTR [rdx+rdi*1],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_cde:
	/* 0xcde: add    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_ce1:
	/* 0xce1: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_ce5:
	/* 0xce5: je     523 <do_action+0x3f3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xce5, 0x523, x86_l_523);
x86_l_ceb:
	/* 0xceb: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_ced:
	/* 0xced: movzx  r8d,WORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_cf2:
	/* 0xcf2: mov    WORD PTR [rdx+rcx*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_cf7:
	/* 0xcf7: add    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_cfa:
	/* 0xcfa: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_cfe:
	/* 0xcfe: je     ca4 <do_action+0xb74> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcfe, 0xca4, x86_l_ca4);
x86_l_d00:
	/* 0xd00: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_d02:
	/* 0xd02: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_d06:
	/* 0xd06: mov    BYTE PTR [rdx+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_d09:
	/* 0xd09: jmp    ca4 <do_action+0xb74> */
	X86_SIM_X86_SUB_JMP(0xd09, 0xca4, x86_l_ca4);

	/* native subroutine native_link_sub_d0b */
x86_l_d0b:
	/* 0xd0b: rorx   ecx,esi,0x3 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 3ULL);
x86_l_d11:
	/* 0xd11: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d13:
	/* 0xd13: cmp    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_d16:
	/* 0xd16: jle    d4d <read_reg+0x42> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd16, 0xd4d, x86_l_d4d);
x86_l_d18:
	/* 0xd18: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_d1b:
	/* 0xd1b: jle    d71 <read_reg+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd1b, 0xd71, x86_l_d71);
x86_l_d1d:
	/* 0xd1d: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_d20:
	/* 0xd20: jle    dd6 <read_reg+0xcb> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd20, 0xdd6, x86_l_dd6);
x86_l_d26:
	/* 0xd26: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_d29:
	/* 0xd29: je     e0a <read_reg+0xff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd29, 0xe0a, x86_l_e0a);
x86_l_d2f:
	/* 0xd2f: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_d32:
	/* 0xd32: je     df2 <read_reg+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd32, 0xdf2, x86_l_df2);
x86_l_d38:
	/* 0xd38: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_d3b:
	/* 0xd3b: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd3b, 0xe20, x86_l_e20);
x86_l_d41:
	/* 0xd41: add    rdi,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_d48:
	/* 0xd48: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xd48, 0xe14, x86_l_e14);
x86_l_d4d:
	/* 0xd4d: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_d50:
	/* 0xd50: jg     d8d <read_reg+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd50, 0xd8d, x86_l_d8d);
x86_l_d52:
	/* 0xd52: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d55:
	/* 0xd55: jg     db6 <read_reg+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd55, 0xdb6, x86_l_db6);
x86_l_d57:
	/* 0xd57: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d59:
	/* 0xd59: je     e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd59, 0xe14, x86_l_e14);
x86_l_d5f:
	/* 0xd5f: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d62:
	/* 0xd62: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd62, 0xe20, x86_l_e20);
x86_l_d68:
	/* 0xd68: add    rdi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_d6c:
	/* 0xd6c: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xd6c, 0xe14, x86_l_e14);
x86_l_d71:
	/* 0xd71: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_d74:
	/* 0xd74: jg     da6 <read_reg+0x9b> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd74, 0xda6, x86_l_da6);
x86_l_d76:
	/* 0xd76: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_d79:
	/* 0xd79: je     de6 <read_reg+0xdb> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd79, 0xde6, x86_l_de6);
x86_l_d7b:
	/* 0xd7b: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_d7e:
	/* 0xd7e: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd7e, 0xe20, x86_l_e20);
x86_l_d84:
	/* 0xd84: add    rdi,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_d88:
	/* 0xd88: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xd88, 0xe14, x86_l_e14);
x86_l_d8d:
	/* 0xd8d: cmp    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_d90:
	/* 0xd90: jg     dc6 <read_reg+0xbb> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd90, 0xdc6, x86_l_dc6);
x86_l_d92:
	/* 0xd92: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_d95:
	/* 0xd95: je     df8 <read_reg+0xed> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd95, 0xdf8, x86_l_df8);
x86_l_d97:
	/* 0xd97: cmp    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_d9a:
	/* 0xd9a: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd9a, 0xe20, x86_l_e20);
x86_l_da0:
	/* 0xda0: add    rdi,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_da4:
	/* 0xda4: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xda4, 0xe14, x86_l_e14);
x86_l_da6:
	/* 0xda6: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_da9:
	/* 0xda9: je     dec <read_reg+0xe1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xda9, 0xdec, x86_l_dec);
x86_l_dab:
	/* 0xdab: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_dae:
	/* 0xdae: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xdae, 0xe20, x86_l_e20);
x86_l_db0:
	/* 0xdb0: add    rdi,0x58 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_db4:
	/* 0xdb4: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdb4, 0xe14, x86_l_e14);
x86_l_db6:
	/* 0xdb6: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_db9:
	/* 0xdb9: je     dfe <read_reg+0xf3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xdb9, 0xdfe, x86_l_dfe);
x86_l_dbb:
	/* 0xdbb: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_dbe:
	/* 0xdbe: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xdbe, 0xe20, x86_l_e20);
x86_l_dc0:
	/* 0xdc0: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_dc4:
	/* 0xdc4: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdc4, 0xe14, x86_l_e14);
x86_l_dc6:
	/* 0xdc6: cmp    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_dc9:
	/* 0xdc9: je     e04 <read_reg+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xdc9, 0xe04, x86_l_e04);
x86_l_dcb:
	/* 0xdcb: cmp    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_dce:
	/* 0xdce: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xdce, 0xe20, x86_l_e20);
x86_l_dd0:
	/* 0xdd0: add    rdi,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_dd4:
	/* 0xdd4: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdd4, 0xe14, x86_l_e14);
x86_l_dd6:
	/* 0xdd6: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_dd9:
	/* 0xdd9: je     e10 <read_reg+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xdd9, 0xe10, x86_l_e10);
x86_l_ddb:
	/* 0xddb: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_dde:
	/* 0xdde: jne    e20 <read_reg+0x115> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xdde, 0xe20, x86_l_e20);
x86_l_de0:
	/* 0xde0: add    rdi,0x68 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 104ULL);
x86_l_de4:
	/* 0xde4: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xde4, 0xe14, x86_l_e14);
x86_l_de6:
	/* 0xde6: add    rdi,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_dea:
	/* 0xdea: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdea, 0xe14, x86_l_e14);
x86_l_dec:
	/* 0xdec: add    rdi,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_df0:
	/* 0xdf0: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdf0, 0xe14, x86_l_e14);
x86_l_df2:
	/* 0xdf2: sub    rdi,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_df6:
	/* 0xdf6: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdf6, 0xe14, x86_l_e14);
x86_l_df8:
	/* 0xdf8: add    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_dfc:
	/* 0xdfc: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xdfc, 0xe14, x86_l_e14);
x86_l_dfe:
	/* 0xdfe: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_e02:
	/* 0xe02: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xe02, 0xe14, x86_l_e14);
x86_l_e04:
	/* 0xe04: add    rdi,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_e08:
	/* 0xe08: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xe08, 0xe14, x86_l_e14);
x86_l_e0a:
	/* 0xe0a: add    rdi,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_e0e:
	/* 0xe0e: jmp    e14 <read_reg+0x109> */
	X86_SIM_X86_SUB_JMP(0xe0e, 0xe14, x86_l_e14);
x86_l_e10:
	/* 0xe10: add    rdi,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_e14:
	/* 0xe14: mov    eax,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_e19:
	/* 0xe19: sub    eax,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e1b:
	/* 0xe1b: bzhi   rax,QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RAX, X86_RDI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 0ULL);
x86_l_e20:
	/* 0xe20: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_e20);

x86_sim_ret_dispatch_cd7:
	switch (__x86_sim_ret_addr) {
	case 0xc4ULL: goto x86_l_c4;
	case 0xe5ULL: goto x86_l_e5;
	case 0x106ULL: goto x86_l_106;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_e20:
	switch (__x86_sim_ret_addr) {
	case 0x37aULL: goto x86_l_37a;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
