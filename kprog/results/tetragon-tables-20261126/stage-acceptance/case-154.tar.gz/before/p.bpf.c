#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 312U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 buffer_heap_map[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 fexit_calls[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 tg_ipv6_ext_heap[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_STORE, X86_OP_MOVBE_STORE)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC_MEM, X86_OP_SETCC_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("fexit/generic_fexit")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 264ULL);
x86_l_11:
	/* 0x11: mov    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: lea    rsi,[rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_1c:
	/* 0x1c: call   21 <generic_fexit_event+0x21> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_func_ret);
x86_l_21:
	/* 0x21: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_29:
	/* 0x29: mov    QWORD PTR [rsp+0xd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_31:
	/* 0x31: mov    DWORD PTR [rsp+0xf4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1047972020224ULL);
x86_l_3c:
	/* 0x3c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_43:
	/* 0x43: lea    rsi,[rsp+0xf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244ULL);
x86_l_4b:
	/* 0x4b: call   50 <generic_fexit_event+0x50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_50:
	/* 0x50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: je     860 <generic_fexit_event+0x860> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53, 0x860, x86_l_860);
x86_l_59:
	/* 0x59: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c:
	/* 0x5c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: lea    rsi,[rax+0x5ef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_66:
	/* 0x66: mov    DWORD PTR [r12+0x5ef8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104419244900352ULL);
x86_l_72:
	/* 0x72: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_79:
	/* 0x79: call   7e <generic_fexit_event+0x7e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7e:
	/* 0x7e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_81:
	/* 0x81: je     860 <generic_fexit_event+0x860> */
	X86_SIM_X86_JCC(X86_CC_E, 0x81, 0x860, x86_l_860);
x86_l_87:
	/* 0x87: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a:
	/* 0x8a: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c:
	/* 0x8c: mov    QWORD PTR [rbx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_90:
	/* 0x90: call   95 <generic_fexit_event+0x95> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_95:
	/* 0x95: cmp    rax,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_99:
	/* 0x99: jne    9f <generic_fexit_event+0x9f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x99, 0x9f, x86_l_9f);
x86_l_9b:
	/* 0x9b: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9f:
	/* 0x9f: mov    QWORD PTR [rbx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a3:
	/* 0xa3: call   a8 <generic_fexit_event+0xa8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_a8:
	/* 0xa8: mov    DWORD PTR [rbx+0x7c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_ab:
	/* 0xab: mov    rax,QWORD PTR [rbx+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_af:
	/* 0xaf: mov    rcx,QWORD PTR [rbx+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_b3:
	/* 0xb3: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b8:
	/* 0xb8: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_bd:
	/* 0xbd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_c4:
	/* 0xc4: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c9:
	/* 0xc9: call   ce <generic_fexit_event+0xce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ce:
	/* 0xce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d1:
	/* 0xd1: je     860 <generic_fexit_event+0x860> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd1, 0x860, x86_l_860);
x86_l_d7:
	/* 0xd7: mov    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_da:
	/* 0xda: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e3:
	/* 0xe3: mov    rax,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e7:
	/* 0xe7: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_ef:
	/* 0xef: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_f6:
	/* 0xf6: lea    r13,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fb:
	/* 0xfb: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_fe:
	/* 0xfe: call   103 <generic_fexit_event+0x103> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_103:
	/* 0x103: mov    QWORD PTR [rbx+0x90],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_10a:
	/* 0x10a: mov    eax,DWORD PTR [r15+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_10e:
	/* 0x10e: mov    r14d,DWORD PTR [r15+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_112:
	/* 0x112: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_115:
	/* 0x115: mov    QWORD PTR [rsp+0xb8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_11d:
	/* 0x11d: mov    QWORD PTR [rsp+0xe0],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_125:
	/* 0x125: je     1f2 <generic_fexit_event+0x1f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x125, 0x1f2, x86_l_1f2);
x86_l_12b:
	/* 0x12b: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12f:
	/* 0x12f: mov    DWORD PTR [rbx+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104041287778304ULL);
x86_l_139:
	/* 0x139: mov    rbp,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_141:
	/* 0x141: mov    DWORD PTR [rsp+0xf8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1065151889408ULL);
x86_l_14c:
	/* 0x14c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_153:
	/* 0x153: lea    rsi,[rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_15b:
	/* 0x15b: call   160 <generic_fexit_event+0x160> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_160:
	/* 0x160: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_163:
	/* 0x163: je     268 <generic_fexit_event+0x268> */
	X86_SIM_X86_JCC(X86_CC_E, 0x163, 0x268, x86_l_268);
x86_l_169:
	/* 0x169: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16c:
	/* 0x16c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16f:
	/* 0x16f: mov    eax,DWORD PTR [rax+0x5ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24224ULL);
x86_l_175:
	/* 0x175: mov    DWORD PTR [rcx+0x98],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_17b:
	/* 0x17b: mov    QWORD PTR [rcx+0x5e78],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103869489086476ULL);
x86_l_186:
	/* 0x186: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_188:
	/* 0x188: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18d:
	/* 0x18d: je     31f <generic_fexit_event+0x31f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18d, 0x31f, x86_l_31f);
x86_l_193:
	/* 0x193: mov    rbp,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_19b:
	/* 0x19b: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1a1:
	/* 0x1a1: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a5:
	/* 0x1a5: mov    eax,DWORD PTR [r15+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a9:
	/* 0x1a9: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1ac:
	/* 0x1ac: je     289 <generic_fexit_event+0x289> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ac, 0x289, x86_l_289);
x86_l_1b2:
	/* 0x1b2: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1b5:
	/* 0x1b5: jne    2a2 <generic_fexit_event+0x2a2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b5, 0x2a2, x86_l_2a2);
x86_l_1bb:
	/* 0x1bb: mov    eax,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1be:
	/* 0x1be: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c2:
	/* 0x1c2: mov    eax,DWORD PTR [rbx+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_1c5:
	/* 0x1c5: mov    DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1c9:
	/* 0x1c9: mov    rax,QWORD PTR [rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cd:
	/* 0x1cd: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1e1:
	/* 0x1e1: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e6:
	/* 0x1e6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e8:
	/* 0x1e8: call   1ed <generic_fexit_event+0x1ed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1ed:
	/* 0x1ed: jmp    29d <generic_fexit_event+0x29d> */
	X86_SIM_X86_JMP(0x1ed, 0x29d, x86_l_29d);
x86_l_1f2:
	/* 0x1f2: mov    r13d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1f8:
	/* 0x1f8: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1fd:
	/* 0x1fd: add    r12,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_204:
	/* 0x204: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_207:
	/* 0x207: jne    2bd <generic_fexit_event+0x2bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x207, 0x2bd, x86_l_2bd);
x86_l_20d:
	/* 0x20d: mov    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_210:
	/* 0x210: mov    DWORD PTR [r12+r13*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_218:
	/* 0x218: lea    r12,[r13+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_21c:
	/* 0x21c: cmp    QWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_225:
	/* 0x225: je     3d5 <generic_fexit_event+0x3d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x225, 0x3d5, x86_l_3d5);
x86_l_22b:
	/* 0x22b: mov    r8,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_233:
	/* 0x233: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_236:
	/* 0x236: js     3e9 <generic_fexit_event+0x3e9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x236, 0x3e9, x86_l_3e9);
x86_l_23c:
	/* 0x23c: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_241:
	/* 0x241: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_246:
	/* 0x246: mov    r15,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_249:
	/* 0x249: call   24e <generic_fexit_event+0x24e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_24e:
	/* 0x24e: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_253:
	/* 0x253: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_255:
	/* 0x255: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x255, 0x6ae, x86_l_6ae);
x86_l_25b:
	/* 0x25b: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_25e:
	/* 0x25e: mov    r15,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_263:
	/* 0x263: jmp    40b <generic_fexit_event+0x40b> */
	X86_SIM_X86_JMP(0x263, 0x40b, x86_l_40b);
x86_l_268:
	/* 0x268: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b:
	/* 0x26b: mov    rbp,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_273:
	/* 0x273: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_278:
	/* 0x278: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_27c:
	/* 0x27c: mov    eax,DWORD PTR [r15+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_280:
	/* 0x280: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_283:
	/* 0x283: jne    1b2 <generic_fexit_event+0x1b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x283, 0x1b2, x86_l_1b2);
x86_l_289:
	/* 0x289: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_290:
	/* 0x290: lea    rsi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_298:
	/* 0x298: call   29d <generic_fexit_event+0x29d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_29d:
	/* 0x29d: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a2:
	/* 0x2a2: and    r13d,0x1fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 8191ULL);
x86_l_2a9:
	/* 0x2a9: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ad:
	/* 0x2ad: add    r12,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2b4:
	/* 0x2b4: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2b7:
	/* 0x2b7: je     20d <generic_fexit_event+0x20d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b7, 0x20d, x86_l_20d);
x86_l_2bd:
	/* 0x2bd: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c0:
	/* 0x2c0: jne    6c5 <generic_fexit_event+0x6c5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c0, 0x6c5, x86_l_6c5);
x86_l_2c6:
	/* 0x2c6: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c9:
	/* 0x2c9: mov    DWORD PTR [r12+r13*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2d1:
	/* 0x2d1: mov    r15,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2d9:
	/* 0x2d9: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2dc:
	/* 0x2dc: cmp    r15,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2e3:
	/* 0x2e3: jb     2eb <generic_fexit_event+0x2eb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e3, 0x2eb, x86_l_2eb);
x86_l_2e5:
	/* 0x2e5: mov    r12d,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_2eb:
	/* 0x2eb: lea    r14,[r13+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2ef:
	/* 0x2ef: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2f2:
	/* 0x2f2: add    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f5:
	/* 0x2f5: add    r13,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2f9:
	/* 0x2f9: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2fd:
	/* 0x2fd: add    rdi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_301:
	/* 0x301: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_304:
	/* 0x304: js     398 <generic_fexit_event+0x398> */
	X86_SIM_X86_JCC(X86_CC_S, 0x304, 0x398, x86_l_398);
x86_l_30a:
	/* 0x30a: mov    esi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_30d:
	/* 0x30d: call   312 <generic_fexit_event+0x312> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_312:
	/* 0x312: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_314:
	/* 0x314: js     4d1 <generic_fexit_event+0x4d1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x314, 0x4d1, x86_l_4d1);
x86_l_31a:
	/* 0x31a: jmp    5df <generic_fexit_event+0x5df> */
	X86_SIM_X86_JMP(0x31a, 0x5df, x86_l_5df);
x86_l_31f:
	/* 0x31f: mov    QWORD PTR [rsp+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_324:
	/* 0x324: lea    rax,[rsi+0x9c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_32b:
	/* 0x32b: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_330:
	/* 0x330: mov    QWORD PTR [rsp+0x40],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_335:
	/* 0x335: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_341:
	/* 0x341: cmp    r14d,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_345:
	/* 0x345: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34a:
	/* 0x34a: mov    QWORD PTR [rsp+0x38],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_34f:
	/* 0x34f: jle    4e5 <generic_fexit_event+0x4e5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x34f, 0x4e5, x86_l_4e5);
x86_l_355:
	/* 0x355: cmp    r14d,0x2a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 42ULL);
x86_l_359:
	/* 0x359: je     639 <generic_fexit_event+0x639> */
	X86_SIM_X86_JCC(X86_CC_E, 0x359, 0x639, x86_l_639);
x86_l_35f:
	/* 0x35f: cmp    r14d,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_363:
	/* 0x363: je     65a <generic_fexit_event+0x65a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x363, 0x65a, x86_l_65a);
x86_l_369:
	/* 0x369: cmp    r14d,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_36d:
	/* 0x36d: jne    4f9 <generic_fexit_event+0x4f9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36d, 0x4f9, x86_l_4f9);
x86_l_373:
	/* 0x373: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_376:
	/* 0x376: js     981 <generic_fexit_event+0x981> */
	X86_SIM_X86_JCC(X86_CC_S, 0x376, 0x981, x86_l_981);
x86_l_37c:
	/* 0x37c: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_381:
	/* 0x381: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_386:
	/* 0x386: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_389:
	/* 0x389: call   38e <generic_fexit_event+0x38e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_38e:
	/* 0x38e: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_393:
	/* 0x393: jmp    a73 <generic_fexit_event+0xa73> */
	X86_SIM_X86_JMP(0x393, 0xa73, x86_l_a73);
x86_l_398:
	/* 0x398: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_39b:
	/* 0x39b: jns    4c7 <generic_fexit_event+0x4c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x39b, 0x4c7, x86_l_4c7);
x86_l_3a1:
	/* 0x3a1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a3:
	/* 0x3a3: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3a7:
	/* 0x3a7: jb     3c3 <generic_fexit_event+0x3c3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3a7, 0x3c3, x86_l_3c3);
x86_l_3a9:
	/* 0x3a9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ab:
	/* 0x3ab: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3ae:
	/* 0x3ae: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_3b2:
	/* 0x3b2: mov    QWORD PTR [rdi+rcx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3b6:
	/* 0x3b6: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3ba:
	/* 0x3ba: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3be:
	/* 0x3be: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3c1:
	/* 0x3c1: jbe    3ab <generic_fexit_event+0x3ab> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3c1, 0x3ab, x86_l_3ab);
x86_l_3c3:
	/* 0x3c3: test   r12b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_3c7:
	/* 0x3c7: jne    5af <generic_fexit_event+0x5af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c7, 0x5af, x86_l_5af);
x86_l_3cd:
	/* 0x3cd: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3d0:
	/* 0x3d0: jmp    5bd <generic_fexit_event+0x5bd> */
	X86_SIM_X86_JMP(0x3d0, 0x5bd, x86_l_5bd);
x86_l_3d5:
	/* 0x3d5: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d7:
	/* 0x3d7: mov    DWORD PTR [r14+r12*1],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_3db:
	/* 0x3db: mov    DWORD PTR [r14+r12*1+0x4],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_R12, 0), 4ULL);
x86_l_3e0:
	/* 0x3e0: add    rbp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3e4:
	/* 0x3e4: jmp    6b7 <generic_fexit_event+0x6b7> */
	X86_SIM_X86_JMP(0x3e4, 0x6b7, x86_l_6b7);
x86_l_3e9:
	/* 0x3e9: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ec:
	/* 0x3ec: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_3f1:
	/* 0x3f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f4:
	/* 0x3f4: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f4, 0x6ae, x86_l_6ae);
x86_l_3fa:
	/* 0x3fa: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fd:
	/* 0x3fd: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_402:
	/* 0x402: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_406:
	/* 0x406: mov    QWORD PTR [rsp+0x48],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_40b:
	/* 0x40b: mov    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_40e:
	/* 0x40e: cmp    r15,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_411:
	/* 0x411: jb     42e <generic_fexit_event+0x42e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x411, 0x42e, x86_l_42e);
x86_l_413:
	/* 0x413: mov    rbp,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_416:
	/* 0x416: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_419:
	/* 0x419: jne    433 <generic_fexit_event+0x433> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x419, 0x433, x86_l_433);
x86_l_41b:
	/* 0x41b: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_420:
	/* 0x420: cmp    r15,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_427:
	/* 0x427: jbe    448 <generic_fexit_event+0x448> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x427, 0x448, x86_l_448);
x86_l_429:
	/* 0x429: jmp    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JMP(0x429, 0x6ae, x86_l_6ae);
x86_l_42e:
	/* 0x42e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_431:
	/* 0x431: je     41b <generic_fexit_event+0x41b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x431, 0x41b, x86_l_41b);
x86_l_433:
	/* 0x433: mov    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_436:
	/* 0x436: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_43b:
	/* 0x43b: cmp    r15,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_442:
	/* 0x442: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x442, 0x6ae, x86_l_6ae);
x86_l_448:
	/* 0x448: add    r13,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_44c:
	/* 0x44c: mov    QWORD PTR [rsp+0x30],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_451:
	/* 0x451: lea    rdi,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_455:
	/* 0x455: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_45a:
	/* 0x45a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_45d:
	/* 0x45d: jns    5f6 <generic_fexit_event+0x5f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45d, 0x5f6, x86_l_5f6);
x86_l_463:
	/* 0x463: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_466:
	/* 0x466: jns    69f <generic_fexit_event+0x69f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x466, 0x69f, x86_l_69f);
x86_l_46c:
	/* 0x46c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46e:
	/* 0x46e: cmp    r15d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_472:
	/* 0x472: jb     48d <generic_fexit_event+0x48d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x472, 0x48d, x86_l_48d);
x86_l_474:
	/* 0x474: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_476:
	/* 0x476: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_478:
	/* 0x478: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_47c:
	/* 0x47c: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_480:
	/* 0x480: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_483:
	/* 0x483: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_486:
	/* 0x486: cmp    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_489:
	/* 0x489: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_48b:
	/* 0x48b: jbe    476 <generic_fexit_event+0x476> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x48b, 0x476, x86_l_476);
x86_l_48d:
	/* 0x48d: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_491:
	/* 0x491: jne    a15 <generic_fexit_event+0xa15> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x491, 0xa15, x86_l_a15);
x86_l_497:
	/* 0x497: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_49b:
	/* 0x49b: jne    a2a <generic_fexit_event+0xa2a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49b, 0xa2a, x86_l_a2a);
x86_l_4a1:
	/* 0x4a1: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4a5:
	/* 0x4a5: jne    a41 <generic_fexit_event+0xa41> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a5, 0xa41, x86_l_a41);
x86_l_4ab:
	/* 0x4ab: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4b3:
	/* 0x4b3: je     61f <generic_fexit_event+0x61f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4b3, 0x61f, x86_l_61f);
x86_l_4b9:
	/* 0x4b9: sub    r8,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4bc:
	/* 0x4bc: jne    622 <generic_fexit_event+0x622> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4bc, 0x622, x86_l_622);
x86_l_4c2:
	/* 0x4c2: jmp    3d7 <generic_fexit_event+0x3d7> */
	X86_SIM_X86_JMP(0x4c2, 0x3d7, x86_l_3d7);
x86_l_4c7:
	/* 0x4c7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c9:
	/* 0x4c9: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4cc:
	/* 0x4cc: call   4d1 <generic_fexit_event+0x4d1> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_4d1:
	/* 0x4d1: mov    DWORD PTR [r13+0x0],0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4294967294ULL);
x86_l_4d9:
	/* 0x4d9: add    r14,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4dd:
	/* 0x4dd: mov    r13,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4e0:
	/* 0x4e0: jmp    6c5 <generic_fexit_event+0x6c5> */
	X86_SIM_X86_JMP(0x4e0, 0x6c5, x86_l_6c5);
x86_l_4e5:
	/* 0x4e5: cmp    r14d,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_4e9:
	/* 0x4e9: je     680 <generic_fexit_event+0x680> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e9, 0x680, x86_l_680);
x86_l_4ef:
	/* 0x4ef: cmp    r14d,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4f3:
	/* 0x4f3: je     a78 <generic_fexit_event+0xa78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f3, 0xa78, x86_l_a78);
x86_l_4f9:
	/* 0x4f9: cmp    r14d,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_4fd:
	/* 0x4fd: ja     8bc <generic_fexit_event+0x8bc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4fd, 0x8bc, x86_l_8bc);
x86_l_503:
	/* 0x503: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_506:
	/* 0x506: movabs rcx,0x11c1f2027cf2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 19524686609650ULL);
x86_l_510:
	/* 0x510: bt     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_514:
	/* 0x514: jae    8bc <generic_fexit_event+0x8bc> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x514, 0x8bc, x86_l_8bc);
x86_l_51a:
	/* 0x51a: mov    QWORD PTR [rsp+0x28],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_51f:
	/* 0x51f: mov    DWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_52a:
	/* 0x52a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_531:
	/* 0x531: lea    rsi,[rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_539:
	/* 0x539: call   53e <generic_fexit_event+0x53e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53e:
	/* 0x53e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_541:
	/* 0x541: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_547:
	/* 0x547: je     998 <generic_fexit_event+0x998> */
	X86_SIM_X86_JCC(X86_CC_E, 0x547, 0x998, x86_l_998);
x86_l_54d:
	/* 0x54d: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_550:
	/* 0x550: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_553:
	/* 0x553: cmp    r14d,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_557:
	/* 0x557: jle    9a0 <generic_fexit_event+0x9a0> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x557, 0x9a0, x86_l_9a0);
x86_l_55d:
	/* 0x55d: cmp    r14d,0x1e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_561:
	/* 0x561: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_566:
	/* 0x566: jle    1387 <generic_fexit_event+0x1387> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x566, 0x1387, x86_l_1387);
x86_l_56c:
	/* 0x56c: cmp    r14d,0x26 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 38ULL);
x86_l_570:
	/* 0x570: jg     1430 <generic_fexit_event+0x1430> */
	X86_SIM_X86_JCC(X86_CC_G, 0x570, 0x1430, x86_l_1430);
x86_l_576:
	/* 0x576: lea    eax,[r14-0x1f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551585ULL);
x86_l_57a:
	/* 0x57a: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_57d:
	/* 0x57d: jae    17a7 <generic_fexit_event+0x17a7> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x57d, 0x17a7, x86_l_17a7);
x86_l_583:
	/* 0x583: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_588:
	/* 0x588: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58b:
	/* 0x58b: jns    18e0 <generic_fexit_event+0x18e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x58b, 0x18e0, x86_l_18e0);
x86_l_591:
	/* 0x591: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_594:
	/* 0x594: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_599:
	/* 0x599: jns    1d25 <generic_fexit_event+0x1d25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x599, 0x1d25, x86_l_1d25);
x86_l_59f:
	/* 0x59f: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_5a2:
	/* 0x5a2: mov    BYTE PTR [rcx],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5a4:
	/* 0x5a4: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_5aa:
	/* 0x5aa: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x5aa, 0x42c7, x86_l_42c7);
x86_l_5af:
	/* 0x5af: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5b1:
	/* 0x5b1: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5b4:
	/* 0x5b4: mov    edx,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_5b7:
	/* 0x5b7: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_5ba:
	/* 0x5ba: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_5bd:
	/* 0x5bd: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_5c1:
	/* 0x5c1: je     5d0 <generic_fexit_event+0x5d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c1, 0x5d0, x86_l_5d0);
x86_l_5c3:
	/* 0x5c3: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5c5:
	/* 0x5c5: movzx  edx,WORD PTR [rsi+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_5c9:
	/* 0x5c9: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_5cd:
	/* 0x5cd: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_5d0:
	/* 0x5d0: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_5d4:
	/* 0x5d4: je     5df <generic_fexit_event+0x5df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d4, 0x5df, x86_l_5df);
x86_l_5d6:
	/* 0x5d6: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_5d8:
	/* 0x5d8: movzx  ecx,BYTE PTR [rsi+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_5dc:
	/* 0x5dc: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_5df:
	/* 0x5df: mov    DWORD PTR [r13+0x0],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e3:
	/* 0x5e3: mov    DWORD PTR [r13+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5e7:
	/* 0x5e7: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_5eb:
	/* 0x5eb: add    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_5ee:
	/* 0x5ee: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5f1:
	/* 0x5f1: jmp    6c5 <generic_fexit_event+0x6c5> */
	X86_SIM_X86_JMP(0x5f1, 0x6c5, x86_l_6c5);
x86_l_5f6:
	/* 0x5f6: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_5f9:
	/* 0x5f9: mov    r13,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_5fc:
	/* 0x5fc: call   601 <generic_fexit_event+0x601> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_601:
	/* 0x601: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_606:
	/* 0x606: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_608:
	/* 0x608: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x608, 0x6ae, x86_l_6ae);
x86_l_60e:
	/* 0x60e: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_611:
	/* 0x611: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_614:
	/* 0x614: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_619:
	/* 0x619: jne    4b9 <generic_fexit_event+0x4b9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x619, 0x4b9, x86_l_4b9);
x86_l_61f:
	/* 0x61f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_622:
	/* 0x622: cmp    QWORD PTR [rsp+0xb0],0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244097ULL);
x86_l_62b:
	/* 0x62b: jne    94b <generic_fexit_event+0x94b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x62b, 0x94b, x86_l_94b);
x86_l_631:
	/* 0x631: mov    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_634:
	/* 0x634: jmp    3d7 <generic_fexit_event+0x3d7> */
	X86_SIM_X86_JMP(0x634, 0x3d7, x86_l_3d7);
x86_l_639:
	/* 0x639: mov    QWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_645:
	/* 0x645: mov    QWORD PTR [rsp+0xa8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_64d:
	/* 0x64d: lea    r12,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_655:
	/* 0x655: jmp    aae <generic_fexit_event+0xaae> */
	X86_SIM_X86_JMP(0x655, 0xaae, x86_l_aae);
x86_l_65a:
	/* 0x65a: add    rbp,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_65e:
	/* 0x65e: mov    QWORD PTR [rsp+0x40],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_663:
	/* 0x663: jns    878 <generic_fexit_event+0x878> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x663, 0x878, x86_l_878);
x86_l_669:
	/* 0x669: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_66c:
	/* 0x66c: jns    a5d <generic_fexit_event+0xa5d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x66c, 0xa5d, x86_l_a5d);
x86_l_672:
	/* 0x672: mov    r12,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_676:
	/* 0x676: mov    QWORD PTR [rsp+0x28],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_67b:
	/* 0x67b: jmp    aaa <generic_fexit_event+0xaaa> */
	X86_SIM_X86_JMP(0x67b, 0xaaa, x86_l_aaa);
x86_l_680:
	/* 0x680: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_683:
	/* 0x683: jns    894 <generic_fexit_event+0x894> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x683, 0x894, x86_l_894);
x86_l_689:
	/* 0x689: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_68e:
	/* 0x68e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_691:
	/* 0x691: jns    8bc <generic_fexit_event+0x8bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x691, 0x8bc, x86_l_8bc);
x86_l_697:
	/* 0x697: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_69a:
	/* 0x69a: jmp    8b3 <generic_fexit_event+0x8b3> */
	X86_SIM_X86_JMP(0x69a, 0x8b3, x86_l_8b3);
x86_l_69f:
	/* 0x69f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a1:
	/* 0x6a1: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_6a4:
	/* 0x6a4: call   6a9 <generic_fexit_event+0x6a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_6a9:
	/* 0x6a9: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_6ae:
	/* 0x6ae: mov    DWORD PTR [r14+r12*1],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_6b2:
	/* 0x6b2: mov    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_6b7:
	/* 0x6b7: add    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6ba:
	/* 0x6ba: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_6bd:
	/* 0x6bd: mov    rbp,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_6c5:
	/* 0x6c5: call   6ca <generic_fexit_event+0x6ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_6ca:
	/* 0x6ca: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6cd:
	/* 0x6cd: lea    rcx,[rax+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_6d4:
	/* 0x6d4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6d6:
	/* 0x6d6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6d9:
	/* 0x6d9: jns    6dd <generic_fexit_event+0x6dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6d9, 0x6dd, x86_l_6dd);
x86_l_6db:
	/* 0x6db: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6dd:
	/* 0x6dd: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6e1:
	/* 0x6e1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_6e8:
	/* 0x6e8: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6ed:
	/* 0x6ed: call   6f2 <generic_fexit_event+0x6f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6f2:
	/* 0x6f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f5:
	/* 0x6f5: je     705 <generic_fexit_event+0x705> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f5, 0x705, x86_l_705);
x86_l_6f7:
	/* 0x6f7: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6fa:
	/* 0x6fa: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_6ff:
	/* 0x6ff: jne    80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6ff, 0x80d, x86_l_80d);
x86_l_705:
	/* 0x705: add    r12,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_70c:
	/* 0x70c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_70f:
	/* 0x70f: jns    80a <generic_fexit_event+0x80a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x70f, 0x80a, x86_l_80a);
x86_l_715:
	/* 0x715: mov    r14,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_719:
	/* 0x719: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71c:
	/* 0x71c: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_71f:
	/* 0x71f: je     80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x71f, 0x80d, x86_l_80d);
x86_l_725:
	/* 0x725: lea    rax,[r14+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_72c:
	/* 0x72c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_72f:
	/* 0x72f: jns    734 <generic_fexit_event+0x734> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x72f, 0x734, x86_l_734);
x86_l_731:
	/* 0x731: mov    r15d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_734:
	/* 0x734: mov    DWORD PTR [rsp+0x40],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_739:
	/* 0x739: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_740:
	/* 0x740: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_745:
	/* 0x745: call   74a <generic_fexit_event+0x74a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_74a:
	/* 0x74a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_74d:
	/* 0x74d: je     75d <generic_fexit_event+0x75d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x74d, 0x75d, x86_l_75d);
x86_l_74f:
	/* 0x74f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_752:
	/* 0x752: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_757:
	/* 0x757: jne    80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x757, 0x80d, x86_l_80d);
x86_l_75d:
	/* 0x75d: add    r14,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_764:
	/* 0x764: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_767:
	/* 0x767: jns    80a <generic_fexit_event+0x80a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x767, 0x80a, x86_l_80a);
x86_l_76d:
	/* 0x76d: mov    r14,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_770:
	/* 0x770: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_773:
	/* 0x773: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_776:
	/* 0x776: je     80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x776, 0x80d, x86_l_80d);
x86_l_77c:
	/* 0x77c: lea    rax,[r14+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_783:
	/* 0x783: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_786:
	/* 0x786: jns    78b <generic_fexit_event+0x78b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x786, 0x78b, x86_l_78b);
x86_l_788:
	/* 0x788: mov    r15d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_78b:
	/* 0x78b: mov    DWORD PTR [rsp+0x40],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_790:
	/* 0x790: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_797:
	/* 0x797: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_79c:
	/* 0x79c: call   7a1 <generic_fexit_event+0x7a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7a1:
	/* 0x7a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a4:
	/* 0x7a4: je     7b0 <generic_fexit_event+0x7b0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a4, 0x7b0, x86_l_7b0);
x86_l_7a6:
	/* 0x7a6: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a9:
	/* 0x7a9: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_7ae:
	/* 0x7ae: jne    80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7ae, 0x80d, x86_l_80d);
x86_l_7b0:
	/* 0x7b0: add    r14,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_7b7:
	/* 0x7b7: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_7ba:
	/* 0x7ba: jns    80a <generic_fexit_event+0x80a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ba, 0x80a, x86_l_80a);
x86_l_7bc:
	/* 0x7bc: mov    r14,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7bf:
	/* 0x7bf: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c2:
	/* 0x7c2: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_7c5:
	/* 0x7c5: je     80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c5, 0x80d, x86_l_80d);
x86_l_7c7:
	/* 0x7c7: lea    rax,[r14+0xaf4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
x86_l_7ce:
	/* 0x7ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d1:
	/* 0x7d1: jns    7d6 <generic_fexit_event+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7d1, 0x7d6, x86_l_7d6);
x86_l_7d3:
	/* 0x7d3: mov    r15d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7d6:
	/* 0x7d6: mov    DWORD PTR [rsp+0x40],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7db:
	/* 0x7db: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_7e2:
	/* 0x7e2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7e7:
	/* 0x7e7: call   7ec <generic_fexit_event+0x7ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7ec:
	/* 0x7ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ef:
	/* 0x7ef: je     7fb <generic_fexit_event+0x7fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7ef, 0x7fb, x86_l_7fb);
x86_l_7f1:
	/* 0x7f1: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f4:
	/* 0x7f4: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_7f9:
	/* 0x7f9: jne    80d <generic_fexit_event+0x80d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7f9, 0x80d, x86_l_80d);
x86_l_7fb:
	/* 0x7fb: add    r14,0xb00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
x86_l_802:
	/* 0x802: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_805:
	/* 0x805: jns    80a <generic_fexit_event+0x80a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x805, 0x80a, x86_l_80a);
x86_l_807:
	/* 0x807: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_80a:
	/* 0x80a: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80d:
	/* 0x80d: mov    DWORD PTR [rbx],0x10d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 269ULL);
x86_l_813:
	/* 0x813: mov    DWORD PTR [rbx+0x4],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_817:
	/* 0x817: call   81c <generic_fexit_event+0x81c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_81c:
	/* 0x81c: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_820:
	/* 0x820: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_823:
	/* 0x823: je     833 <generic_fexit_event+0x833> */
	X86_SIM_X86_JCC(X86_CC_E, 0x823, 0x833, x86_l_833);
x86_l_825:
	/* 0x825: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_828:
	/* 0x828: mov    DWORD PTR [rbx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_82b:
	/* 0x82b: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_82f:
	/* 0x82f: mov    QWORD PTR [rbx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_833:
	/* 0x833: mov    DWORD PTR [rbx+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_83a:
	/* 0x83a: mov    rax,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_842:
	/* 0x842: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_844:
	/* 0x844: mov    QWORD PTR [rbx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_848:
	/* 0x848: mov    DWORD PTR [rbx+0x4],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_84c:
	/* 0x84c: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fexit_calls));
x86_l_853:
	/* 0x853: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_856:
	/* 0x856: mov    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_85b:
	/* 0x85b: call   860 <generic_fexit_event+0x860> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_860:
	/* 0x860: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_862:
	/* 0x862: add    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 264ULL);
x86_l_869:
	/* 0x869: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_86a:
	/* 0x86a: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_86c:
	/* 0x86c: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_86e:
	/* 0x86e: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_870:
	/* 0x870: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_872:
	/* 0x872: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_873:
	/* 0x873: jmp    4d6c <cwd_read_v61+0x330> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_878:
	/* 0x878: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_87d:
	/* 0x87d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_882:
	/* 0x882: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_885:
	/* 0x885: call   88a <generic_fexit_event+0x88a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_88a:
	/* 0x88a: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_88f:
	/* 0x88f: jmp    aaa <generic_fexit_event+0xaaa> */
	X86_SIM_X86_JMP(0x88f, 0xaaa, x86_l_aaa);
x86_l_894:
	/* 0x894: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_89c:
	/* 0x89c: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_8a1:
	/* 0x8a1: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_8a6:
	/* 0x8a6: call   8ab <generic_fexit_event+0x8ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_8ab:
	/* 0x8ab: mov    r12,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8b3:
	/* 0x8b3: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8b6:
	/* 0x8b6: jne    aae <generic_fexit_event+0xaae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8b6, 0xaae, x86_l_aae);
x86_l_8bc:
	/* 0x8bc: mov    DWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_8c7:
	/* 0x8c7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_8ce:
	/* 0x8ce: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_8d6:
	/* 0x8d6: call   8db <generic_fexit_event+0x8db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8db:
	/* 0x8db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8de:
	/* 0x8de: je     21b4 <generic_fexit_event+0x21b4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8de, 0x21b4, x86_l_21b4);
x86_l_8e4:
	/* 0x8e4: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e7:
	/* 0x8e7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8ea:
	/* 0x8ea: cmp    r14d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_8ee:
	/* 0x8ee: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8f3:
	/* 0x8f3: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8f8:
	/* 0x8f8: jg     125d <generic_fexit_event+0x125d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8f8, 0x125d, x86_l_125d);
x86_l_8fe:
	/* 0x8fe: cmp    r14d,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_902:
	/* 0x902: jle    13fc <generic_fexit_event+0x13fc> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x902, 0x13fc, x86_l_13fc);
x86_l_908:
	/* 0x908: cmp    r14d,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_90c:
	/* 0x90c: jle    1743 <generic_fexit_event+0x1743> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x90c, 0x1743, x86_l_1743);
x86_l_912:
	/* 0x912: cmp    r14d,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_916:
	/* 0x916: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_91c:
	/* 0x91c: je     1ba1 <generic_fexit_event+0x1ba1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91c, 0x1ba1, x86_l_1ba1);
x86_l_922:
	/* 0x922: cmp    r14d,0x16 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 22ULL);
x86_l_926:
	/* 0x926: je     1b7a <generic_fexit_event+0x1b7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x926, 0x1b7a, x86_l_1b7a);
x86_l_92c:
	/* 0x92c: cmp    r14d,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_930:
	/* 0x930: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x930, 0x42d1, x86_l_42d1);
x86_l_936:
	/* 0x936: mov    DWORD PTR [rsi+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_940:
	/* 0x940: mov    DWORD PTR [rsi+0x9c],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_946:
	/* 0x946: jmp    1cd3 <generic_fexit_event+0x1cd3> */
	X86_SIM_X86_JMP(0x946, 0x1cd3, x86_l_1cd3);
x86_l_94b:
	/* 0x94b: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_94f:
	/* 0x94f: js     12a4 <generic_fexit_event+0x12a4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x94f, 0x12a4, x86_l_12a4);
x86_l_955:
	/* 0x955: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_95a:
	/* 0x95a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_95f:
	/* 0x95f: mov    r13,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_962:
	/* 0x962: call   967 <generic_fexit_event+0x967> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_967:
	/* 0x967: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_96c:
	/* 0x96c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_96e:
	/* 0x96e: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x96e, 0x6ae, x86_l_6ae);
x86_l_974:
	/* 0x974: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_977:
	/* 0x977: mov    r10,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_97c:
	/* 0x97c: jmp    12c3 <generic_fexit_event+0x12c3> */
	X86_SIM_X86_JMP(0x97c, 0x12c3, x86_l_12c3);
x86_l_981:
	/* 0x981: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_984:
	/* 0x984: jns    a68 <generic_fexit_event+0xa68> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x984, 0xa68, x86_l_a68);
x86_l_98a:
	/* 0x98a: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_98e:
	/* 0x98e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_993:
	/* 0x993: jmp    a73 <generic_fexit_event+0xa73> */
	X86_SIM_X86_JMP(0x993, 0xa73, x86_l_a73);
x86_l_998:
	/* 0x998: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_99b:
	/* 0x99b: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x99b, 0x42c7, x86_l_42c7);
x86_l_9a0:
	/* 0x9a0: cmp    r14d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_9a4:
	/* 0x9a4: jg     13b4 <generic_fexit_event+0x13b4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x9a4, 0x13b4, x86_l_13b4);
x86_l_9aa:
	/* 0x9aa: cmp    r14d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_9ae:
	/* 0x9ae: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9b3:
	/* 0x9b3: jle    151d <generic_fexit_event+0x151d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x9b3, 0x151d, x86_l_151d);
x86_l_9b9:
	/* 0x9b9: cmp    r14d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_9bd:
	/* 0x9bd: je     18b2 <generic_fexit_event+0x18b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9bd, 0x18b2, x86_l_18b2);
x86_l_9c3:
	/* 0x9c3: cmp    r14d,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_9c7:
	/* 0x9c7: je     2883 <generic_fexit_event+0x2883> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c7, 0x2883, x86_l_2883);
x86_l_9cd:
	/* 0x9cd: cmp    r14d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_9d1:
	/* 0x9d1: jne    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9d1, 0x42c7, x86_l_42c7);
x86_l_9d7:
	/* 0x9d7: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9dc:
	/* 0x9dc: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9e1:
	/* 0x9e1: mov    QWORD PTR [rax+0xc4],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_9e8:
	/* 0x9e8: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9ed:
	/* 0x9ed: lea    rdi,[rcx+0xc2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 194ULL);
x86_l_9f4:
	/* 0x9f4: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9f7:
	/* 0x9f7: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_9fb:
	/* 0x9fb: jns    1d3d <generic_fexit_event+0x1d3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9fb, 0x1d3d, x86_l_1d3d);
x86_l_a01:
	/* 0xa01: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a04:
	/* 0xa04: jns    25fa <generic_fexit_event+0x25fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa04, 0x25fa, x86_l_25fa);
x86_l_a0a:
	/* 0xa0a: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_a0d:
	/* 0xa0d: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a10:
	/* 0xa10: jmp    25ff <generic_fexit_event+0x25ff> */
	X86_SIM_X86_JMP(0xa10, 0x25ff, x86_l_25ff);
x86_l_a15:
	/* 0xa15: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a17:
	/* 0xa17: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a1a:
	/* 0xa1a: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a1d:
	/* 0xa1d: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_a20:
	/* 0xa20: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_a24:
	/* 0xa24: je     4a1 <generic_fexit_event+0x4a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa24, 0x4a1, x86_l_4a1);
x86_l_a2a:
	/* 0xa2a: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a2c:
	/* 0xa2c: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_a30:
	/* 0xa30: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_a34:
	/* 0xa34: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_a37:
	/* 0xa37: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_a3b:
	/* 0xa3b: je     4ab <generic_fexit_event+0x4ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa3b, 0x4ab, x86_l_4ab);
x86_l_a41:
	/* 0xa41: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_a43:
	/* 0xa43: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_a47:
	/* 0xa47: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_a4a:
	/* 0xa4a: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_a4d:
	/* 0xa4d: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a52:
	/* 0xa52: jne    4b9 <generic_fexit_event+0x4b9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa52, 0x4b9, x86_l_4b9);
x86_l_a58:
	/* 0xa58: jmp    61f <generic_fexit_event+0x61f> */
	X86_SIM_X86_JMP(0xa58, 0x61f, x86_l_61f);
x86_l_a5d:
	/* 0xa5d: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_a66:
	/* 0xa66: jmp    aa7 <generic_fexit_event+0xaa7> */
	X86_SIM_X86_JMP(0xa66, 0xaa7, x86_l_aa7);
x86_l_a68:
	/* 0xa68: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_a71:
	/* 0xa71: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a73:
	/* 0xa73: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a78:
	/* 0xa78: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a7b:
	/* 0xa7b: jns    a8c <generic_fexit_event+0xa8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa7b, 0xa8c, x86_l_a8c);
x86_l_a7d:
	/* 0xa7d: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a82:
	/* 0xa82: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a85:
	/* 0xa85: jns    aa7 <generic_fexit_event+0xaa7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa85, 0xaa7, x86_l_aa7);
x86_l_a87:
	/* 0xa87: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a8a:
	/* 0xa8a: jmp    aaa <generic_fexit_event+0xaaa> */
	X86_SIM_X86_JMP(0xa8a, 0xaaa, x86_l_aaa);
x86_l_a8c:
	/* 0xa8c: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a91:
	/* 0xa91: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a96:
	/* 0xa96: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_a9b:
	/* 0xa9b: call   aa0 <generic_fexit_event+0xaa0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_aa0:
	/* 0xaa0: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_aa5:
	/* 0xaa5: jmp    aaa <generic_fexit_event+0xaaa> */
	X86_SIM_X86_JMP(0xaa5, 0xaaa, x86_l_aaa);
x86_l_aa7:
	/* 0xaa7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aaa:
	/* 0xaaa: add    r12,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_aae:
	/* 0xaae: mov    DWORD PTR [rsp+0xfc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1082331758592ULL);
x86_l_ab9:
	/* 0xab9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)buffer_heap_map));
x86_l_ac0:
	/* 0xac0: lea    rsi,[rsp+0xfc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 252ULL);
x86_l_ac8:
	/* 0xac8: call   acd <generic_fexit_event+0xacd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_acd:
	/* 0xacd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad0:
	/* 0xad0: je     1113 <generic_fexit_event+0x1113> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad0, 0x1113, x86_l_1113);
x86_l_ad6:
	/* 0xad6: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad9:
	/* 0xad9: call   ade <generic_fexit_event+0xade> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_ade:
	/* 0xade: add    rax,0xd50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3408ULL);
x86_l_ae4:
	/* 0xae4: jns    af8 <generic_fexit_event+0xaf8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xae4, 0xaf8, x86_l_af8);
x86_l_ae6:
	/* 0xae6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae9:
	/* 0xae9: jns    b17 <generic_fexit_event+0xb17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xae9, 0xb17, x86_l_b17);
x86_l_aeb:
	/* 0xaeb: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_aee:
	/* 0xaee: mov    QWORD PTR [rsp+0xe8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_af6:
	/* 0xaf6: jmp    b25 <generic_fexit_event+0xb25> */
	X86_SIM_X86_JMP(0xaf6, 0xb25, x86_l_b25);
x86_l_af8:
	/* 0xaf8: lea    rdi,[rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_b00:
	/* 0xb00: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b05:
	/* 0xb05: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b08:
	/* 0xb08: call   b0d <generic_fexit_event+0xb0d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b0d:
	/* 0xb0d: mov    rbp,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_b15:
	/* 0xb15: jmp    b25 <generic_fexit_event+0xb25> */
	X86_SIM_X86_JMP(0xb15, 0xb25, x86_l_b25);
x86_l_b17:
	/* 0xb17: mov    QWORD PTR [rsp+0xe8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 996432412672ULL);
x86_l_b23:
	/* 0xb23: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b25:
	/* 0xb25: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_b28:
	/* 0xb28: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_b2c:
	/* 0xb2c: mov    QWORD PTR [rsp+0x98],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_b34:
	/* 0xb34: jns    b4b <generic_fexit_event+0xb4b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb34, 0xb4b, x86_l_b4b);
x86_l_b36:
	/* 0xb36: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b39:
	/* 0xb39: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b3c:
	/* 0xb3c: jns    b67 <generic_fexit_event+0xb67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb3c, 0xb67, x86_l_b67);
x86_l_b3e:
	/* 0xb3e: mov    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b41:
	/* 0xb41: mov    QWORD PTR [rsp+0xc0],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_b49:
	/* 0xb49: jmp    b76 <generic_fexit_event+0xb76> */
	X86_SIM_X86_JMP(0xb49, 0xb76, x86_l_b76);
x86_l_b4b:
	/* 0xb4b: lea    rdi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_b53:
	/* 0xb53: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b58:
	/* 0xb58: call   b5d <generic_fexit_event+0xb5d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b5d:
	/* 0xb5d: mov    r14,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_b65:
	/* 0xb65: jmp    b76 <generic_fexit_event+0xb76> */
	X86_SIM_X86_JMP(0xb65, 0xb76, x86_l_b76);
x86_l_b67:
	/* 0xb67: mov    QWORD PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_b73:
	/* 0xb73: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b76:
	/* 0xb76: lea    r15,[r13+0x1000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_b7d:
	/* 0xb7d: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_b80:
	/* 0xb80: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_b84:
	/* 0xb84: jns    b90 <generic_fexit_event+0xb90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb84, 0xb90, x86_l_b90);
x86_l_b86:
	/* 0xb86: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b89:
	/* 0xb89: jns    bae <generic_fexit_event+0xbae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb89, 0xbae, x86_l_bae);
x86_l_b8b:
	/* 0xb8b: mov    rcx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b8e:
	/* 0xb8e: jmp    ba4 <generic_fexit_event+0xba4> */
	X86_SIM_X86_JMP(0xb8e, 0xba4, x86_l_ba4);
x86_l_b90:
	/* 0xb90: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b95:
	/* 0xb95: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b9a:
	/* 0xb9a: call   b9f <generic_fexit_event+0xb9f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b9f:
	/* 0xb9f: mov    rcx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ba4:
	/* 0xba4: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_ba9:
	/* 0xba9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bac:
	/* 0xbac: jne    c0f <generic_fexit_event+0xc0f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbac, 0xc0f, x86_l_c0f);
x86_l_bae:
	/* 0xbae: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bb1:
	/* 0xbb1: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_bb5:
	/* 0xbb5: jns    bc1 <generic_fexit_event+0xbc1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbb5, 0xbc1, x86_l_bc1);
x86_l_bb7:
	/* 0xbb7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_bba:
	/* 0xbba: jns    bd7 <generic_fexit_event+0xbd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbba, 0xbd7, x86_l_bd7);
x86_l_bbc:
	/* 0xbbc: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bbf:
	/* 0xbbf: jmp    bd9 <generic_fexit_event+0xbd9> */
	X86_SIM_X86_JMP(0xbbf, 0xbd9, x86_l_bd9);
x86_l_bc1:
	/* 0xbc1: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bc6:
	/* 0xbc6: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_bcb:
	/* 0xbcb: call   bd0 <generic_fexit_event+0xbd0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_bd0:
	/* 0xbd0: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bd5:
	/* 0xbd5: jmp    bd9 <generic_fexit_event+0xbd9> */
	X86_SIM_X86_JMP(0xbd5, 0xbd9, x86_l_bd9);
x86_l_bd7:
	/* 0xbd7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bd9:
	/* 0xbd9: cmp    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bdc:
	/* 0xbdc: je     c0a <generic_fexit_event+0xc0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbdc, 0xc0a, x86_l_c0a);
x86_l_bde:
	/* 0xbde: mov    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_be1:
	/* 0xbe1: add    r15,0xff6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4086ULL);
x86_l_be8:
	/* 0xbe8: movabs rax,0x6574656c65642820 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 7310579611361093664ULL);
x86_l_bf2:
	/* 0xbf2: mov    QWORD PTR [r13+0xff6],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4086ULL);
x86_l_bf9:
	/* 0xbf9: mov    WORD PTR [r13+0xffe],0x2964 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 17583596120420ULL);
x86_l_c03:
	/* 0xc03: mov    eax,0xff6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4086ULL);
x86_l_c08:
	/* 0xc08: jmp    c0f <generic_fexit_event+0xc0f> */
	X86_SIM_X86_JMP(0xc08, 0xc0f, x86_l_c0f);
x86_l_c0a:
	/* 0xc0a: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_c0f:
	/* 0xc0f: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_c18:
	/* 0xc18: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_c21:
	/* 0xc21: mov    QWORD PTR [rsp+0x50],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c26:
	/* 0xc26: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_c2f:
	/* 0xc2f: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_c38:
	/* 0xc38: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_c41:
	/* 0xc41: mov    QWORD PTR [rsp+0x70],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c46:
	/* 0xc46: lea    r13,[rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c4a:
	/* 0xc4a: mov    DWORD PTR [rsp+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c4e:
	/* 0xc4e: mov    BYTE PTR [rsp+0x7c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_c53:
	/* 0xc53: add    rbp,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_c57:
	/* 0xc57: jns    c69 <generic_fexit_event+0xc69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc57, 0xc69, x86_l_c69);
x86_l_c59:
	/* 0xc59: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c5c:
	/* 0xc5c: jns    c7d <generic_fexit_event+0xc7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc5c, 0xc7d, x86_l_c7d);
x86_l_c5e:
	/* 0xc5e: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c62:
	/* 0xc62: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c67:
	/* 0xc67: jmp    c86 <generic_fexit_event+0xc86> */
	X86_SIM_X86_JMP(0xc67, 0xc86, x86_l_c86);
x86_l_c69:
	/* 0xc69: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c6e:
	/* 0xc6e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_c73:
	/* 0xc73: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c76:
	/* 0xc76: call   c7b <generic_fexit_event+0xc7b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_c7b:
	/* 0xc7b: jmp    c86 <generic_fexit_event+0xc86> */
	X86_SIM_X86_JMP(0xc7b, 0xc86, x86_l_c86);
x86_l_c7d:
	/* 0xc7d: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_c86:
	/* 0xc86: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c89:
	/* 0xc89: jns    c9b <generic_fexit_event+0xc9b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc89, 0xc9b, x86_l_c9b);
x86_l_c8b:
	/* 0xc8b: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c8e:
	/* 0xc8e: jns    caf <generic_fexit_event+0xcaf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc8e, 0xcaf, x86_l_caf);
x86_l_c90:
	/* 0xc90: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c94:
	/* 0xc94: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_c99:
	/* 0xc99: jmp    cb8 <generic_fexit_event+0xcb8> */
	X86_SIM_X86_JMP(0xc99, 0xcb8, x86_l_cb8);
x86_l_c9b:
	/* 0xc9b: lea    rdi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_ca0:
	/* 0xca0: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_ca5:
	/* 0xca5: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_ca8:
	/* 0xca8: call   cad <generic_fexit_event+0xcad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_cad:
	/* 0xcad: jmp    cb8 <generic_fexit_event+0xcb8> */
	X86_SIM_X86_JMP(0xcad, 0xcb8, x86_l_cb8);
x86_l_caf:
	/* 0xcaf: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_cb8:
	/* 0xcb8: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_cbe:
	/* 0xcbe: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cc6:
	/* 0xcc6: lea    rdi,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ccb:
	/* 0xccb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cce:
	/* 0xcce: jns    ce2 <generic_fexit_event+0xce2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcce, 0xce2, x86_l_ce2);
x86_l_cd0:
	/* 0xcd0: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cd3:
	/* 0xcd3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd6:
	/* 0xcd6: jns    cee <generic_fexit_event+0xcee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd6, 0xcee, x86_l_cee);
x86_l_cd8:
	/* 0xcd8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cdb:
	/* 0xcdb: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ce0:
	/* 0xce0: jmp    cf7 <generic_fexit_event+0xcf7> */
	X86_SIM_X86_JMP(0xce0, 0xcf7, x86_l_cf7);
x86_l_ce2:
	/* 0xce2: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_ce7:
	/* 0xce7: call   cec <generic_fexit_event+0xcec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_cec:
	/* 0xcec: jmp    cf7 <generic_fexit_event+0xcf7> */
	X86_SIM_X86_JMP(0xcec, 0xcf7, x86_l_cf7);
x86_l_cee:
	/* 0xcee: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_cf7:
	/* 0xcf7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cfa:
	/* 0xcfa: jns    d0c <generic_fexit_event+0xd0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcfa, 0xd0c, x86_l_d0c);
x86_l_cfc:
	/* 0xcfc: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_cff:
	/* 0xcff: jns    d25 <generic_fexit_event+0xd25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcff, 0xd25, x86_l_d25);
x86_l_d01:
	/* 0xd01: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d05:
	/* 0xd05: mov    QWORD PTR [rsp+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d0a:
	/* 0xd0a: jmp    d30 <generic_fexit_event+0xd30> */
	X86_SIM_X86_JMP(0xd0a, 0xd30, x86_l_d30);
x86_l_d0c:
	/* 0xd0c: lea    rdi,[rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d11:
	/* 0xd11: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_d16:
	/* 0xd16: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_d19:
	/* 0xd19: call   d1e <generic_fexit_event+0xd1e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d1e:
	/* 0xd1e: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d23:
	/* 0xd23: jmp    d30 <generic_fexit_event+0xd30> */
	X86_SIM_X86_JMP(0xd23, 0xd30, x86_l_d30);
x86_l_d25:
	/* 0xd25: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_d2e:
	/* 0xd2e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d30:
	/* 0xd30: add    rax,0xffffffffffffffe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
x86_l_d34:
	/* 0xd34: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d39:
	/* 0xd39: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM));
x86_l_d40:
	/* 0xd40: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d43:
	/* 0xd43: je     10a0 <generic_fexit_event+0x10a0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd43, 0x10a0, x86_l_10a0);
x86_l_d49:
	/* 0xd49: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d4c:
	/* 0xd4c: mov    QWORD PTR [rsp+0xc8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_d54:
	/* 0xd54: jmp    d91 <generic_fexit_event+0xd91> */
	X86_SIM_X86_JMP(0xd54, 0xd91, x86_l_d91);
x86_l_d56:
	/* 0xd56: lea    rdi,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d5b:
	/* 0xd5b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_d60:
	/* 0xd60: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d63:
	/* 0xd63: call   d68 <generic_fexit_event+0xd68> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d68:
	/* 0xd68: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_d6e:
	/* 0xd6e: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_d73:
	/* 0xd73: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d78:
	/* 0xd78: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_d7c:
	/* 0xd7c: mov    QWORD PTR [rsp+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d81:
	/* 0xd81: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d84:
	/* 0xd84: cmp    r14d,0x800 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_d8b:
	/* 0xd8b: je     10da <generic_fexit_event+0x10da> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd8b, 0x10da, x86_l_10da);
x86_l_d91:
	/* 0xd91: mov    r12,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_d96:
	/* 0xd96: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d9b:
	/* 0xd9b: mov    r13,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_da0:
	/* 0xda0: cmp    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 64ULL);
x86_l_da5:
	/* 0xda5: jne    db2 <generic_fexit_event+0xdb2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xda5, 0xdb2, x86_l_db2);
x86_l_da7:
	/* 0xda7: cmp    rdx,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_dac:
	/* 0xdac: je     10ba <generic_fexit_event+0x10ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdac, 0x10ba, x86_l_10ba);
x86_l_db2:
	/* 0xdb2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_db5:
	/* 0xdb5: jns    dd1 <generic_fexit_event+0xdd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdb5, 0xdd1, x86_l_dd1);
x86_l_db7:
	/* 0xdb7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_dba:
	/* 0xdba: jns    df5 <generic_fexit_event+0xdf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdba, 0xdf5, x86_l_df5);
x86_l_dbc:
	/* 0xdbc: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dbf:
	/* 0xdbf: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_dc7:
	/* 0xdc7: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dca:
	/* 0xdca: jne    e08 <generic_fexit_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdca, 0xe08, x86_l_e08);
x86_l_dcc:
	/* 0xdcc: jmp    e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JMP(0xdcc, 0xe72, x86_l_e72);
x86_l_dd1:
	/* 0xdd1: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_dd9:
	/* 0xdd9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_dde:
	/* 0xdde: call   de3 <generic_fexit_event+0xde3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_de3:
	/* 0xde3: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_deb:
	/* 0xdeb: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dee:
	/* 0xdee: jne    e08 <generic_fexit_event+0xe08> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdee, 0xe08, x86_l_e08);
x86_l_df0:
	/* 0xdf0: jmp    e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JMP(0xdf0, 0xe72, x86_l_e72);
x86_l_df5:
	/* 0xdf5: mov    QWORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_e01:
	/* 0xe01: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e03:
	/* 0xe03: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e06:
	/* 0xe06: je     e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe06, 0xe72, x86_l_e72);
x86_l_e08:
	/* 0xe08: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e0b:
	/* 0xe0b: add    rbp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_e0f:
	/* 0xe0f: jns    e23 <generic_fexit_event+0xe23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe0f, 0xe23, x86_l_e23);
x86_l_e11:
	/* 0xe11: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e14:
	/* 0xe14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e17:
	/* 0xe17: jns    e56 <generic_fexit_event+0xe56> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe17, 0xe56, x86_l_e56);
x86_l_e19:
	/* 0xe19: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e1c:
	/* 0xe1c: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e1f:
	/* 0xe1f: jne    e5b <generic_fexit_event+0xe5b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe1f, 0xe5b, x86_l_e5b);
x86_l_e21:
	/* 0xe21: jmp    e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JMP(0xe21, 0xe72, x86_l_e72);
x86_l_e23:
	/* 0xe23: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e28:
	/* 0xe28: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e2d:
	/* 0xe2d: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e30:
	/* 0xe30: call   e35 <generic_fexit_event+0xe35> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e35:
	/* 0xe35: cmp    QWORD PTR [rsp+0x28],r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e3a:
	/* 0xe3a: je     e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe3a, 0xe72, x86_l_e72);
x86_l_e3c:
	/* 0xe3c: lea    rdi,[rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_e44:
	/* 0xe44: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e49:
	/* 0xe49: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e4c:
	/* 0xe4c: call   e51 <generic_fexit_event+0xe51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e51:
	/* 0xe51: jmp    eed <generic_fexit_event+0xeed> */
	X86_SIM_X86_JMP(0xe51, 0xeed, x86_l_eed);
x86_l_e56:
	/* 0xe56: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e59:
	/* 0xe59: je     e72 <generic_fexit_event+0xe72> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe59, 0xe72, x86_l_e72);
x86_l_e5b:
	/* 0xe5b: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_e5e:
	/* 0xe5e: jns    ee1 <generic_fexit_event+0xee1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe5e, 0xee1, x86_l_ee1);
x86_l_e64:
	/* 0xe64: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e68:
	/* 0xe68: mov    QWORD PTR [rsp+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_e70:
	/* 0xe70: jmp    eed <generic_fexit_event+0xeed> */
	X86_SIM_X86_JMP(0xe70, 0xeed, x86_l_eed);
x86_l_e72:
	/* 0xe72: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_e75:
	/* 0xe75: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_e79:
	/* 0xe79: jns    e8a <generic_fexit_event+0xe8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe79, 0xe8a, x86_l_e8a);
x86_l_e7b:
	/* 0xe7b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e7e:
	/* 0xe7e: jns    ea0 <generic_fexit_event+0xea0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe7e, 0xea0, x86_l_ea0);
x86_l_e80:
	/* 0xe80: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e83:
	/* 0xe83: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e88:
	/* 0xe88: jmp    eab <generic_fexit_event+0xeab> */
	X86_SIM_X86_JMP(0xe88, 0xeab, x86_l_eab);
x86_l_e8a:
	/* 0xe8a: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e8f:
	/* 0xe8f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e94:
	/* 0xe94: call   e99 <generic_fexit_event+0xe99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_e99:
	/* 0xe99: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e9e:
	/* 0xe9e: jmp    eab <generic_fexit_event+0xeab> */
	X86_SIM_X86_JMP(0xe9e, 0xeab, x86_l_eab);
x86_l_ea0:
	/* 0xea0: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_ea9:
	/* 0xea9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eab:
	/* 0xeab: cmp    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_eb0:
	/* 0xeb0: je     10cf <generic_fexit_event+0x10cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeb0, 0x10cf, x86_l_10cf);
x86_l_eb6:
	/* 0xeb6: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_eba:
	/* 0xeba: jns    d56 <generic_fexit_event+0xd56> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeba, 0xd56, x86_l_d56);
x86_l_ec0:
	/* 0xec0: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_ec3:
	/* 0xec3: jns    ed3 <generic_fexit_event+0xed3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xec3, 0xed3, x86_l_ed3);
x86_l_ec5:
	/* 0xec5: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ec9:
	/* 0xec9: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ece:
	/* 0xece: jmp    d68 <generic_fexit_event+0xd68> */
	X86_SIM_X86_JMP(0xece, 0xd68, x86_l_d68);
x86_l_ed3:
	/* 0xed3: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_edc:
	/* 0xedc: jmp    d68 <generic_fexit_event+0xd68> */
	X86_SIM_X86_JMP(0xedc, 0xd68, x86_l_d68);
x86_l_ee1:
	/* 0xee1: mov    QWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_eed:
	/* 0xeed: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_ef1:
	/* 0xef1: jns    f13 <generic_fexit_event+0xf13> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xef1, 0xf13, x86_l_f13);
x86_l_ef3:
	/* 0xef3: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ef6:
	/* 0xef6: jns    f32 <generic_fexit_event+0xf32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xef6, 0xf32, x86_l_f32);
x86_l_ef8:
	/* 0xef8: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_efc:
	/* 0xefc: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_f04:
	/* 0xf04: mov    rdx,QWORD PTR [r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f09:
	/* 0xf09: mov    QWORD PTR [rsp+0x88],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_f11:
	/* 0xf11: jmp    f4c <generic_fexit_event+0xf4c> */
	X86_SIM_X86_JMP(0xf11, 0xf4c, x86_l_f4c);
x86_l_f13:
	/* 0xf13: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_f1b:
	/* 0xf1b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_f20:
	/* 0xf20: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_f23:
	/* 0xf23: call   f28 <generic_fexit_event+0xf28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f28:
	/* 0xf28: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_f30:
	/* 0xf30: jmp    f4c <generic_fexit_event+0xf4c> */
	X86_SIM_X86_JMP(0xf30, 0xf4c, x86_l_f4c);
x86_l_f32:
	/* 0xf32: mov    QWORD PTR [rsp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_f3e:
	/* 0xf3e: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_f4a:
	/* 0xf4a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f4c:
	/* 0xf4c: mov    r12,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_f51:
	/* 0xf51: mov    r15,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_f56:
	/* 0xf56: mov    ebp,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_f5d:
	/* 0xf5d: mov    r13d,DWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_f62:
	/* 0xf62: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f64:
	/* 0xf64: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_f66:
	/* 0xf66: mov    eax,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_f69:
	/* 0xf69: sub    ecx,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R13, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f6c:
	/* 0xf6c: mov    edi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_f71:
	/* 0xf71: cmovb  ecx,edi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RDI, X86_WIDTH_32, X86_CC_B, 0);
x86_l_f74:
	/* 0xf74: setb   dil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_f78:
	/* 0xf78: ja     f7c <generic_fexit_event+0xf7c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf78, 0xf7c, x86_l_f7c);
x86_l_f7a:
	/* 0xf7a: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_f7c:
	/* 0xf7c: sub    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_f7f:
	/* 0xf7f: mov    sil,dil */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDI, X86_WIDTH_8, 0, 0);
x86_l_f82:
	/* 0xf82: add    esi,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_f84:
	/* 0xf84: mov    edi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_f87:
	/* 0xf87: sub    edi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f89:
	/* 0xf89: mov    DWORD PTR [rsp+0x78],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_f8d:
	/* 0xf8d: sub    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_f90:
	/* 0xf90: jb     10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf90, 0x10bf, x86_l_10bf);
x86_l_f96:
	/* 0xf96: cmp    r15,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_f9d:
	/* 0xf9d: ja     10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf9d, 0x10bf, x86_l_10bf);
x86_l_fa3:
	/* 0xfa3: cmp    r13d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_fa6:
	/* 0xfa6: jbe    fad <generic_fexit_event+0xfad> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xfa6, 0xfad, x86_l_fad);
x86_l_fa8:
	/* 0xfa8: mov    BYTE PTR [r12+r15*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 47ULL);
x86_l_fad:
	/* 0xfad: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fb0:
	/* 0xfb0: cmp    ebp,r13d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_fb3:
	/* 0xfb3: movzx  esi,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_fb6:
	/* 0xfb6: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_fb9:
	/* 0xfb9: adc    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADC, 0);
x86_l_fbc:
	/* 0xfbc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fbf:
	/* 0xfbf: jns    1007 <generic_fexit_event+0x1007> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfbf, 0x1007, x86_l_1007);
x86_l_fc1:
	/* 0xfc1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fc4:
	/* 0xfc4: jns    101e <generic_fexit_event+0x101e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfc4, 0x101e, x86_l_101e);
x86_l_fc6:
	/* 0xfc6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fc8:
	/* 0xfc8: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_fcb:
	/* 0xfcb: jb     fe9 <generic_fexit_event+0xfe9> */
	X86_SIM_X86_JCC(X86_CC_B, 0xfcb, 0xfe9, x86_l_fe9);
x86_l_fcd:
	/* 0xfcd: mov    esi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_fcf:
	/* 0xfcf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fd1:
	/* 0xfd1: mov    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_fd4:
	/* 0xfd4: mov    rcx,QWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_fd8:
	/* 0xfd8: mov    QWORD PTR [rdi+r8*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_fdc:
	/* 0xfdc: lea    rcx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fe0:
	/* 0xfe0: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_fe4:
	/* 0xfe4: cmp    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_fe7:
	/* 0xfe7: jbe    fd1 <generic_fexit_event+0xfd1> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xfe7, 0xfd1, x86_l_fd1);
x86_l_fe9:
	/* 0xfe9: test   al,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_feb:
	/* 0xfeb: jne    1039 <generic_fexit_event+0x1039> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfeb, 0x1039, x86_l_1039);
x86_l_fed:
	/* 0xfed: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_fef:
	/* 0xfef: jne    104a <generic_fexit_event+0x104a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfef, 0x104a, x86_l_104a);
x86_l_ff1:
	/* 0xff1: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_ff3:
	/* 0xff3: jne    105d <generic_fexit_event+0x105d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xff3, 0x105d, x86_l_105d);
x86_l_ff5:
	/* 0xff5: add    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_ff8:
	/* 0xff8: mov    QWORD PTR [rsp+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_ffd:
	/* 0xffd: cmp    r13d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1000:
	/* 0x1000: ja     1073 <generic_fexit_event+0x1073> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1000, 0x1073, x86_l_1073);
x86_l_1002:
	/* 0x1002: jmp    10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JMP(0x1002, 0x10bf, x86_l_10bf);
x86_l_1007:
	/* 0x1007: call   100c <generic_fexit_event+0x100c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_100c:
	/* 0x100c: add    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_100f:
	/* 0x100f: mov    QWORD PTR [rsp+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1014:
	/* 0x1014: cmp    r13d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1017:
	/* 0x1017: ja     1073 <generic_fexit_event+0x1073> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1017, 0x1073, x86_l_1073);
x86_l_1019:
	/* 0x1019: jmp    10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JMP(0x1019, 0x10bf, x86_l_10bf);
x86_l_101e:
	/* 0x101e: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1020:
	/* 0x1020: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1022:
	/* 0x1022: call   1027 <generic_fexit_event+0x1027> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1027:
	/* 0x1027: add    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_102a:
	/* 0x102a: mov    QWORD PTR [rsp+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_102f:
	/* 0x102f: cmp    r13d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1032:
	/* 0x1032: ja     1073 <generic_fexit_event+0x1073> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1032, 0x1073, x86_l_1073);
x86_l_1034:
	/* 0x1034: jmp    10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JMP(0x1034, 0x10bf, x86_l_10bf);
x86_l_1039:
	/* 0x1039: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_103b:
	/* 0x103b: mov    r8d,DWORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_103f:
	/* 0x103f: mov    DWORD PTR [rdi+rsi*1],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1043:
	/* 0x1043: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1046:
	/* 0x1046: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1048:
	/* 0x1048: je     ff1 <generic_fexit_event+0xff1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1048, 0xff1, x86_l_ff1);
x86_l_104a:
	/* 0x104a: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_104c:
	/* 0x104c: movzx  r8d,WORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_16), 0ULL);
x86_l_1051:
	/* 0x1051: mov    WORD PTR [rdi+rsi*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1056:
	/* 0x1056: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1059:
	/* 0x1059: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_105b:
	/* 0x105b: je     ff5 <generic_fexit_event+0xff5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x105b, 0xff5, x86_l_ff5);
x86_l_105d:
	/* 0x105d: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_105f:
	/* 0x105f: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1063:
	/* 0x1063: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1066:
	/* 0x1066: add    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1069:
	/* 0x1069: mov    QWORD PTR [rsp+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_106e:
	/* 0x106e: cmp    r13d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1071:
	/* 0x1071: jbe    10bf <generic_fexit_event+0x10bf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1071, 0x10bf, x86_l_10bf);
x86_l_1073:
	/* 0x1073: mov    rax,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_107b:
	/* 0x107b: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1080:
	/* 0x1080: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1086:
	/* 0x1086: mov    r15,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_108e:
	/* 0x108e: inc    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1091:
	/* 0x1091: cmp    r14d,0x800 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_1098:
	/* 0x1098: jne    d91 <generic_fexit_event+0xd91> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1098, 0xd91, x86_l_d91);
x86_l_109e:
	/* 0x109e: jmp    10da <generic_fexit_event+0x10da> */
	X86_SIM_X86_JMP(0x109e, 0x10da, x86_l_10da);
x86_l_10a0:
	/* 0x10a0: lea    rsi,[rip+0x0] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x4a3cULL);
x86_l_10a7:
	/* 0x10a7: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_10ac:
	/* 0x10ac: mov    edi,0x800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2048ULL);
x86_l_10b1:
	/* 0x10b1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b3:
	/* 0x10b3: call   10b8 <generic_fexit_event+0x10b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_loop);
x86_l_10b8:
	/* 0x10b8: jmp    10da <generic_fexit_event+0x10da> */
	X86_SIM_X86_JMP(0x10b8, 0x10da, x86_l_10da);
x86_l_10ba:
	/* 0x10ba: mov    BYTE PTR [rsp+0x7c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 532575944705ULL);
x86_l_10bf:
	/* 0x10bf: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_10c5:
	/* 0x10c5: mov    r15,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_10cd:
	/* 0x10cd: jmp    10da <generic_fexit_event+0x10da> */
	X86_SIM_X86_JMP(0x10cd, 0x10da, x86_l_10da);
x86_l_10cf:
	/* 0x10cf: mov    BYTE PTR [rsp+0x7c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 532575944705ULL);
x86_l_10d4:
	/* 0x10d4: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_10da:
	/* 0x10da: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_10df:
	/* 0x10df: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10e1:
	/* 0x10e1: cmp    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10e4:
	/* 0x10e4: je     1128 <generic_fexit_event+0x1128> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e4, 0x1128, x86_l_1128);
x86_l_10e6:
	/* 0x10e6: cmp    BYTE PTR [rsp+0x7c],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 532575944704ULL);
x86_l_10eb:
	/* 0x10eb: sete   dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_10ee:
	/* 0x10ee: mov    eax,DWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_10f2:
	/* 0x10f2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_10f4:
	/* 0x10f4: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_10f9:
	/* 0x10f9: jle    1104 <generic_fexit_event+0x1104> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x10f9, 0x1104, x86_l_1104);
x86_l_10fb:
	/* 0x10fb: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1100:
	/* 0x1100: sub    esi,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1102:
	/* 0x1102: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1104:
	/* 0x1104: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1107:
	/* 0x1107: je     1113 <generic_fexit_event+0x1113> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1107, 0x1113, x86_l_1113);
x86_l_1109:
	/* 0x1109: mov    bpl,dl */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_110c:
	/* 0x110c: add    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_110e:
	/* 0x110e: mov    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1111:
	/* 0x1111: jmp    112f <generic_fexit_event+0x112f> */
	X86_SIM_X86_JMP(0x1111, 0x112f, x86_l_112f);
x86_l_1113:
	/* 0x1113: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1116:
	/* 0x1116: mov    rbp,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_111e:
	/* 0x111e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1123:
	/* 0x1123: jmp    42de <generic_fexit_event+0x42de> */
	X86_SIM_X86_JMP(0x1123, 0x42de, x86_l_42de);
x86_l_1128:
	/* 0x1128: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_112a:
	/* 0x112a: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_112f:
	/* 0x112f: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1134:
	/* 0x1134: add    rdi,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_113b:
	/* 0x113b: mov    r12d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_113e:
	/* 0x113e: and    r12d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1145:
	/* 0x1145: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1148:
	/* 0x1148: jns    11ae <generic_fexit_event+0x11ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1148, 0x11ae, x86_l_11ae);
x86_l_114a:
	/* 0x114a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_114d:
	/* 0x114d: jns    11bb <generic_fexit_event+0x11bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x114d, 0x11bb, x86_l_11bb);
x86_l_114f:
	/* 0x114f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1151:
	/* 0x1151: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1155:
	/* 0x1155: jb     1177 <generic_fexit_event+0x1177> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1155, 0x1177, x86_l_1177);
x86_l_1157:
	/* 0x1157: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_115a:
	/* 0x115a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_115c:
	/* 0x115c: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_115f:
	/* 0x115f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1162:
	/* 0x1162: mov    rcx,QWORD PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1166:
	/* 0x1166: mov    QWORD PTR [r8+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_116a:
	/* 0x116a: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_116e:
	/* 0x116e: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1172:
	/* 0x1172: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1175:
	/* 0x1175: jbe    115f <generic_fexit_event+0x115f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1175, 0x115f, x86_l_115f);
x86_l_1177:
	/* 0x1177: test   al,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1179:
	/* 0x1179: mov    r8,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1181:
	/* 0x1181: jne    1211 <generic_fexit_event+0x1211> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1181, 0x1211, x86_l_1211);
x86_l_1187:
	/* 0x1187: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1189:
	/* 0x1189: jne    1225 <generic_fexit_event+0x1225> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1189, 0x1225, x86_l_1225);
x86_l_118f:
	/* 0x118f: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1194:
	/* 0x1194: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1199:
	/* 0x1199: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_119b:
	/* 0x119b: jne    1245 <generic_fexit_event+0x1245> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x119b, 0x1245, x86_l_1245);
x86_l_11a1:
	/* 0x11a1: mov    DWORD PTR [r14],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11a4:
	/* 0x11a4: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_11a7:
	/* 0x11a7: jns    11df <generic_fexit_event+0x11df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11a7, 0x11df, x86_l_11df);
x86_l_11a9:
	/* 0x11a9: mov    rax,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ac:
	/* 0x11ac: jmp    11e1 <generic_fexit_event+0x11e1> */
	X86_SIM_X86_JMP(0x11ac, 0x11e1, x86_l_11e1);
x86_l_11ae:
	/* 0x11ae: mov    esi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_11b1:
	/* 0x11b1: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11b4:
	/* 0x11b4: call   11b9 <generic_fexit_event+0x11b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_11b9:
	/* 0x11b9: jmp    11c5 <generic_fexit_event+0x11c5> */
	X86_SIM_X86_JMP(0x11b9, 0x11c5, x86_l_11c5);
x86_l_11bb:
	/* 0x11bb: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_11be:
	/* 0x11be: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c0:
	/* 0x11c0: call   11c5 <generic_fexit_event+0x11c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_11c5:
	/* 0x11c5: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11ca:
	/* 0x11ca: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11cf:
	/* 0x11cf: mov    r8,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_11d7:
	/* 0x11d7: mov    DWORD PTR [r14],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11da:
	/* 0x11da: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_11dd:
	/* 0x11dd: js     11a9 <generic_fexit_event+0x11a9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11dd, 0x11a9, x86_l_11a9);
x86_l_11df:
	/* 0x11df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11e1:
	/* 0x11e1: add    rax,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_11e5:
	/* 0x11e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e8:
	/* 0x11e8: jns    11ef <generic_fexit_event+0x11ef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11e8, 0x11ef, x86_l_11ef);
x86_l_11ea:
	/* 0x11ea: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ed:
	/* 0x11ed: jmp    11f1 <generic_fexit_event+0x11f1> */
	X86_SIM_X86_JMP(0x11ed, 0x11f1, x86_l_11f1);
x86_l_11ef:
	/* 0x11ef: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11f1:
	/* 0x11f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11f4:
	/* 0x11f4: jns    11fb <generic_fexit_event+0x11fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11f4, 0x11fb, x86_l_11fb);
x86_l_11f6:
	/* 0x11f6: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_11f9:
	/* 0x11f9: jmp    11fd <generic_fexit_event+0x11fd> */
	X86_SIM_X86_JMP(0x11f9, 0x11fd, x86_l_11fd);
x86_l_11fb:
	/* 0x11fb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11fd:
	/* 0x11fd: mov    DWORD PTR [r14+r12*1+0x4],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_R12, 0), 4ULL);
x86_l_1202:
	/* 0x1202: mov    WORD PTR [r14+r12*1+0x8],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_R12, 0), 8ULL);
x86_l_1208:
	/* 0x1208: add    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 10ULL);
x86_l_120c:
	/* 0x120c: jmp    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JMP(0x120c, 0x42d1, x86_l_42d1);
x86_l_1211:
	/* 0x1211: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1213:
	/* 0x1213: mov    esi,DWORD PTR [r15+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1217:
	/* 0x1217: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_121a:
	/* 0x121a: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_121d:
	/* 0x121d: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_121f:
	/* 0x121f: je     118f <generic_fexit_event+0x118f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x121f, 0x118f, x86_l_118f);
x86_l_1225:
	/* 0x1225: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1227:
	/* 0x1227: movzx  esi,WORD PTR [r15+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_122c:
	/* 0x122c: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1230:
	/* 0x1230: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1233:
	/* 0x1233: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1238:
	/* 0x1238: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_123d:
	/* 0x123d: test   al,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_123f:
	/* 0x123f: je     11a1 <generic_fexit_event+0x11a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x123f, 0x11a1, x86_l_11a1);
x86_l_1245:
	/* 0x1245: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1247:
	/* 0x1247: movzx  ecx,BYTE PTR [r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_124c:
	/* 0x124c: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_124f:
	/* 0x124f: mov    DWORD PTR [r14],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1252:
	/* 0x1252: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1255:
	/* 0x1255: js     11a9 <generic_fexit_event+0x11a9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1255, 0x11a9, x86_l_11a9);
x86_l_125b:
	/* 0x125b: jmp    11df <generic_fexit_event+0x11df> */
	X86_SIM_X86_JMP(0x125b, 0x11df, x86_l_11df);
x86_l_125d:
	/* 0x125d: cmp    r14d,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_1261:
	/* 0x1261: jle    165a <generic_fexit_event+0x165a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1261, 0x165a, x86_l_165a);
x86_l_1267:
	/* 0x1267: lea    eax,[r14-0x21] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551583ULL);
x86_l_126b:
	/* 0x126b: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_126e:
	/* 0x126e: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1274:
	/* 0x1274: jae    1620 <generic_fexit_event+0x1620> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1274, 0x1620, x86_l_1620);
x86_l_127a:
	/* 0x127a: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_127d:
	/* 0x127d: js     180c <generic_fexit_event+0x180c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x127d, 0x180c, x86_l_180c);
x86_l_1283:
	/* 0x1283: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1288:
	/* 0x1288: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_128d:
	/* 0x128d: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1290:
	/* 0x1290: call   1295 <generic_fexit_event+0x1295> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1295:
	/* 0x1295: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_129a:
	/* 0x129a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_129f:
	/* 0x129f: jmp    1cd3 <generic_fexit_event+0x1cd3> */
	X86_SIM_X86_JMP(0x129f, 0x1cd3, x86_l_1cd3);
x86_l_12a4:
	/* 0x12a4: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_12a9:
	/* 0x12a9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12ac:
	/* 0x12ac: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12ac, 0x6ae, x86_l_6ae);
x86_l_12b2:
	/* 0x12b2: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b5:
	/* 0x12b5: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_12ba:
	/* 0x12ba: mov    r10,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12be:
	/* 0x12be: mov    QWORD PTR [rsp+0x48],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12c3:
	/* 0x12c3: mov    rbp,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_12c6:
	/* 0x12c6: cmp    r10,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_12c9:
	/* 0x12c9: jb     12e7 <generic_fexit_event+0x12e7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x12c9, 0x12e7, x86_l_12e7);
x86_l_12cb:
	/* 0x12cb: mov    rbp,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_12ce:
	/* 0x12ce: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_12d1:
	/* 0x12d1: jne    12ec <generic_fexit_event+0x12ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12d1, 0x12ec, x86_l_12ec);
x86_l_12d3:
	/* 0x12d3: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_12d8:
	/* 0x12d8: cmp    r10,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_12df:
	/* 0x12df: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x12df, 0x6ae, x86_l_6ae);
x86_l_12e5:
	/* 0x12e5: jmp    1301 <generic_fexit_event+0x1301> */
	X86_SIM_X86_JMP(0x12e5, 0x1301, x86_l_1301);
x86_l_12e7:
	/* 0x12e7: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_12ea:
	/* 0x12ea: je     12d3 <generic_fexit_event+0x12d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12ea, 0x12d3, x86_l_12d3);
x86_l_12ec:
	/* 0x12ec: mov    r10,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_12ef:
	/* 0x12ef: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_12f4:
	/* 0x12f4: cmp    r10,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_12fb:
	/* 0x12fb: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x12fb, 0x6ae, x86_l_6ae);
x86_l_1301:
	/* 0x1301: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1306:
	/* 0x1306: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1309:
	/* 0x1309: mov    QWORD PTR [rsp+0x30],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_130e:
	/* 0x130e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1314:
	/* 0x1314: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1317:
	/* 0x1317: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_131c:
	/* 0x131c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_131f:
	/* 0x131f: jns    15a0 <generic_fexit_event+0x15a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x131f, 0x15a0, x86_l_15a0);
x86_l_1325:
	/* 0x1325: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1328:
	/* 0x1328: jns    1afa <generic_fexit_event+0x1afa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1328, 0x1afa, x86_l_1afa);
x86_l_132e:
	/* 0x132e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1330:
	/* 0x1330: cmp    r10d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1334:
	/* 0x1334: jb     134f <generic_fexit_event+0x134f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1334, 0x134f, x86_l_134f);
x86_l_1336:
	/* 0x1336: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1338:
	/* 0x1338: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_133a:
	/* 0x133a: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_133e:
	/* 0x133e: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1342:
	/* 0x1342: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1345:
	/* 0x1345: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1348:
	/* 0x1348: cmp    ecx,r10d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_134b:
	/* 0x134b: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_134d:
	/* 0x134d: jbe    1338 <generic_fexit_event+0x1338> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x134d, 0x1338, x86_l_1338);
x86_l_134f:
	/* 0x134f: test   r10b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1353:
	/* 0x1353: jne    1d89 <generic_fexit_event+0x1d89> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1353, 0x1d89, x86_l_1d89);
x86_l_1359:
	/* 0x1359: test   r10b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_135d:
	/* 0x135d: jne    1d9e <generic_fexit_event+0x1d9e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x135d, 0x1d9e, x86_l_1d9e);
x86_l_1363:
	/* 0x1363: test   r10b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1367:
	/* 0x1367: jne    1db5 <generic_fexit_event+0x1db5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1367, 0x1db5, x86_l_1db5);
x86_l_136d:
	/* 0x136d: add    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1370:
	/* 0x1370: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1373:
	/* 0x1373: je     15d1 <generic_fexit_event+0x15d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1373, 0x15d1, x86_l_15d1);
x86_l_1379:
	/* 0x1379: sub    r8,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RBP, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_137c:
	/* 0x137c: jne    15d4 <generic_fexit_event+0x15d4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x137c, 0x15d4, x86_l_15d4);
x86_l_1382:
	/* 0x1382: jmp    631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JMP(0x1382, 0x631, x86_l_631);
x86_l_1387:
	/* 0x1387: cmp    r14d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_138b:
	/* 0x138b: jg     14f0 <generic_fexit_event+0x14f0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x138b, 0x14f0, x86_l_14f0);
x86_l_1391:
	/* 0x1391: cmp    r14d,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1395:
	/* 0x1395: je     183a <generic_fexit_event+0x183a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1395, 0x183a, x86_l_183a);
x86_l_139b:
	/* 0x139b: cmp    r14d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_139f:
	/* 0x139f: je     187f <generic_fexit_event+0x187f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x139f, 0x187f, x86_l_187f);
x86_l_13a5:
	/* 0x13a5: cmp    r14d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_13a9:
	/* 0x13a9: je     152d <generic_fexit_event+0x152d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13a9, 0x152d, x86_l_152d);
x86_l_13af:
	/* 0x13af: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x13af, 0x42c7, x86_l_42c7);
x86_l_13b4:
	/* 0x13b4: lea    eax,[r14-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_13b8:
	/* 0x13b8: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_13bb:
	/* 0x13bb: jb     152d <generic_fexit_event+0x152d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13bb, 0x152d, x86_l_152d);
x86_l_13c1:
	/* 0x13c1: lea    eax,[r14-0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_13c5:
	/* 0x13c5: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_13c8:
	/* 0x13c8: jb     1556 <generic_fexit_event+0x1556> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13c8, 0x1556, x86_l_1556);
x86_l_13ce:
	/* 0x13ce: cmp    r14d,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_13d2:
	/* 0x13d2: jne    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13d2, 0x42c7, x86_l_42c7);
x86_l_13d8:
	/* 0x13d8: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13dd:
	/* 0x13dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13e0:
	/* 0x13e0: jns    1d51 <generic_fexit_event+0x1d51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e0, 0x1d51, x86_l_1d51);
x86_l_13e6:
	/* 0x13e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13e9:
	/* 0x13e9: jns    27aa <generic_fexit_event+0x27aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13e9, 0x27aa, x86_l_27aa);
x86_l_13ef:
	/* 0x13ef: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13f2:
	/* 0x13f2: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13f7:
	/* 0x13f7: jmp    1d6a <generic_fexit_event+0x1d6a> */
	X86_SIM_X86_JMP(0x13f7, 0x1d6a, x86_l_1d6a);
x86_l_13fc:
	/* 0x13fc: cmp    r14d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1400:
	/* 0x1400: jg     1709 <generic_fexit_event+0x1709> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1400, 0x1709, x86_l_1709);
x86_l_1406:
	/* 0x1406: cmp    r14d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_140a:
	/* 0x140a: je     1b15 <generic_fexit_event+0x1b15> */
	X86_SIM_X86_JCC(X86_CC_E, 0x140a, 0x1b15, x86_l_1b15);
x86_l_1410:
	/* 0x1410: cmp    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1414:
	/* 0x1414: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_141a:
	/* 0x141a: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x141a, 0x42d1, x86_l_42d1);
x86_l_1420:
	/* 0x1420: mov    QWORD PTR [r15+0x9c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_142b:
	/* 0x142b: jmp    1cd3 <generic_fexit_event+0x1cd3> */
	X86_SIM_X86_JMP(0x142b, 0x1cd3, x86_l_1cd3);
x86_l_1430:
	/* 0x1430: cmp    r14d,0x27 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 39ULL);
x86_l_1434:
	/* 0x1434: je     18ff <generic_fexit_event+0x18ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1434, 0x18ff, x86_l_18ff);
x86_l_143a:
	/* 0x143a: cmp    r14d,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_143e:
	/* 0x143e: je     1a9c <generic_fexit_event+0x1a9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x143e, 0x1a9c, x86_l_1a9c);
x86_l_1444:
	/* 0x1444: cmp    r14d,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_1448:
	/* 0x1448: jne    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1448, 0x42c7, x86_l_42c7);
x86_l_144e:
	/* 0x144e: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1453:
	/* 0x1453: mov    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1458:
	/* 0x1458: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_145d:
	/* 0x145d: mov    QWORD PTR [rdi+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_1465:
	/* 0x1465: mov    QWORD PTR [rdi+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_146d:
	/* 0x146d: mov    QWORD PTR [rdi+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_1475:
	/* 0x1475: mov    QWORD PTR [rdi+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_147d:
	/* 0x147d: mov    QWORD PTR [rdi+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1485:
	/* 0x1485: mov    QWORD PTR [rdi+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_148d:
	/* 0x148d: mov    QWORD PTR [rdi+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1495:
	/* 0x1495: mov    QWORD PTR [rdi+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_149d:
	/* 0x149d: mov    QWORD PTR [rdi+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_14a5:
	/* 0x14a5: mov    QWORD PTR [rdi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_14ad:
	/* 0x14ad: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_14b5:
	/* 0x14b5: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_14bd:
	/* 0x14bd: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_14c5:
	/* 0x14c5: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14cc:
	/* 0x14cc: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_14cf:
	/* 0x14cf: js     1e1a <generic_fexit_event+0x1e1a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14cf, 0x1e1a, x86_l_1e1a);
x86_l_14d5:
	/* 0x14d5: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_14da:
	/* 0x14da: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_14dd:
	/* 0x14dd: call   14e2 <generic_fexit_event+0x14e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14e2:
	/* 0x14e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e5:
	/* 0x14e5: jns    1e31 <generic_fexit_event+0x1e31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14e5, 0x1e31, x86_l_1e31);
x86_l_14eb:
	/* 0x14eb: jmp    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JMP(0x14eb, 0x42bb, x86_l_42bb);
x86_l_14f0:
	/* 0x14f0: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_14f5:
	/* 0x14f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14f8:
	/* 0x14f8: jns    1826 <generic_fexit_event+0x1826> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14f8, 0x1826, x86_l_1826);
x86_l_14fe:
	/* 0x14fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1501:
	/* 0x1501: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1506:
	/* 0x1506: jns    1cde <generic_fexit_event+0x1cde> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1506, 0x1cde, x86_l_1cde);
x86_l_150c:
	/* 0x150c: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_150f:
	/* 0x150f: mov    WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1512:
	/* 0x1512: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1518:
	/* 0x1518: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1518, 0x42c7, x86_l_42c7);
x86_l_151d:
	/* 0x151d: cmp    r14d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1521:
	/* 0x1521: je     1556 <generic_fexit_event+0x1556> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1521, 0x1556, x86_l_1556);
x86_l_1523:
	/* 0x1523: cmp    r14d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1527:
	/* 0x1527: jne    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1527, 0x42c7, x86_l_42c7);
x86_l_152d:
	/* 0x152d: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1532:
	/* 0x1532: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1535:
	/* 0x1535: jns    1581 <generic_fexit_event+0x1581> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1535, 0x1581, x86_l_1581);
x86_l_1537:
	/* 0x1537: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153a:
	/* 0x153a: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_153f:
	/* 0x153f: jns    1ae8 <generic_fexit_event+0x1ae8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x153f, 0x1ae8, x86_l_1ae8);
x86_l_1545:
	/* 0x1545: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1548:
	/* 0x1548: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154b:
	/* 0x154b: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1551:
	/* 0x1551: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1551, 0x42c7, x86_l_42c7);
x86_l_1556:
	/* 0x1556: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_155b:
	/* 0x155b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_155e:
	/* 0x155e: jns    1793 <generic_fexit_event+0x1793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x155e, 0x1793, x86_l_1793);
x86_l_1564:
	/* 0x1564: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1567:
	/* 0x1567: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_156c:
	/* 0x156c: jns    1b04 <generic_fexit_event+0x1b04> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156c, 0x1b04, x86_l_1b04);
x86_l_1572:
	/* 0x1572: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1574:
	/* 0x1574: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1576:
	/* 0x1576: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_157c:
	/* 0x157c: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x157c, 0x42c7, x86_l_42c7);
x86_l_1581:
	/* 0x1581: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1586:
	/* 0x1586: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_158b:
	/* 0x158b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1590:
	/* 0x1590: call   1595 <generic_fexit_event+0x1595> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1595:
	/* 0x1595: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_159b:
	/* 0x159b: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x159b, 0x42c7, x86_l_42c7);
x86_l_15a0:
	/* 0x15a0: mov    esi,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_15a3:
	/* 0x15a3: mov    r13,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_15a6:
	/* 0x15a6: mov    QWORD PTR [rsp+0x38],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_15ab:
	/* 0x15ab: call   15b0 <generic_fexit_event+0x15b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15b0:
	/* 0x15b0: mov    r10,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_15b5:
	/* 0x15b5: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_15ba:
	/* 0x15ba: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15bc:
	/* 0x15bc: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15bc, 0x6ae, x86_l_6ae);
x86_l_15c2:
	/* 0x15c2: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_15c5:
	/* 0x15c5: add    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15c8:
	/* 0x15c8: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_15cb:
	/* 0x15cb: jne    1379 <generic_fexit_event+0x1379> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15cb, 0x1379, x86_l_1379);
x86_l_15d1:
	/* 0x15d1: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15d4:
	/* 0x15d4: cmp    QWORD PTR [rsp+0xb0],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244099ULL);
x86_l_15dd:
	/* 0x15dd: jb     631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15dd, 0x631, x86_l_631);
x86_l_15e3:
	/* 0x15e3: mov    rbp,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_15e6:
	/* 0x15e6: mov    QWORD PTR [rsp+0x38],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_15eb:
	/* 0x15eb: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15f0:
	/* 0x15f0: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_15f4:
	/* 0x15f4: js     2257 <generic_fexit_event+0x2257> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15f4, 0x2257, x86_l_2257);
x86_l_15fa:
	/* 0x15fa: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_15ff:
	/* 0x15ff: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1604:
	/* 0x1604: call   1609 <generic_fexit_event+0x1609> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1609:
	/* 0x1609: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_160e:
	/* 0x160e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1610:
	/* 0x1610: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1610, 0x6ae, x86_l_6ae);
x86_l_1616:
	/* 0x1616: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_161b:
	/* 0x161b: jmp    2279 <generic_fexit_event+0x2279> */
	X86_SIM_X86_JMP(0x161b, 0x2279, x86_l_2279);
x86_l_1620:
	/* 0x1620: cmp    r14d,0x2b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_1624:
	/* 0x1624: je     1be5 <generic_fexit_event+0x1be5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1624, 0x1be5, x86_l_1be5);
x86_l_162a:
	/* 0x162a: cmp    r14d,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_162e:
	/* 0x162e: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x162e, 0x42d1, x86_l_42d1);
x86_l_1634:
	/* 0x1634: add    rbp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1638:
	/* 0x1638: jns    2148 <generic_fexit_event+0x2148> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1638, 0x2148, x86_l_2148);
x86_l_163e:
	/* 0x163e: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1641:
	/* 0x1641: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1646:
	/* 0x1646: jns    3ffc <generic_fexit_event+0x3ffc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1646, 0x3ffc, x86_l_3ffc);
x86_l_164c:
	/* 0x164c: mov    r12,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1650:
	/* 0x1650: mov    QWORD PTR [rsp+0x40],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1655:
	/* 0x1655: jmp    215f <generic_fexit_event+0x215f> */
	X86_SIM_X86_JMP(0x1655, 0x215f, x86_l_215f);
x86_l_165a:
	/* 0x165a: cmp    r14d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_165e:
	/* 0x165e: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1664:
	/* 0x1664: je     1c2a <generic_fexit_event+0x1c2a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1664, 0x1c2a, x86_l_1c2a);
x86_l_166a:
	/* 0x166a: cmp    r14d,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_166e:
	/* 0x166e: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x166e, 0x42d1, x86_l_42d1);
x86_l_1674:
	/* 0x1674: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1679:
	/* 0x1679: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1681:
	/* 0x1681: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1689:
	/* 0x1689: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1691:
	/* 0x1691: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1699:
	/* 0x1699: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_16a1:
	/* 0x16a1: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_16a9:
	/* 0x16a9: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_16b1:
	/* 0x16b1: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_16b9:
	/* 0x16b9: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_16c1:
	/* 0x16c1: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16c8:
	/* 0x16c8: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16cd:
	/* 0x16cd: add    rdi,0xac */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 172ULL);
x86_l_16d4:
	/* 0x16d4: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_16d7:
	/* 0x16d7: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_16db:
	/* 0x16db: jns    21a1 <generic_fexit_event+0x21a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16db, 0x21a1, x86_l_21a1);
x86_l_16e1:
	/* 0x16e1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16e4:
	/* 0x16e4: jns    2f99 <generic_fexit_event+0x2f99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e4, 0x2f99, x86_l_2f99);
x86_l_16ea:
	/* 0x16ea: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ec:
	/* 0x16ec: cmp    rax,0x3e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 62ULL);
x86_l_16f0:
	/* 0x16f0: je     3513 <generic_fexit_event+0x3513> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16f0, 0x3513, x86_l_3513);
x86_l_16f6:
	/* 0x16f6: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_16fa:
	/* 0x16fa: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_16fd:
	/* 0x16fd: inc    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1700:
	/* 0x1700: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1702:
	/* 0x1702: jne    16ec <generic_fexit_event+0x16ec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1702, 0x16ec, x86_l_16ec);
x86_l_1704:
	/* 0x1704: jmp    351f <generic_fexit_event+0x351f> */
	X86_SIM_X86_JMP(0x1704, 0x351f, x86_l_351f);
x86_l_1709:
	/* 0x1709: cmp    r14d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_170d:
	/* 0x170d: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1713:
	/* 0x1713: je     1b56 <generic_fexit_event+0x1b56> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1713, 0x1b56, x86_l_1b56);
x86_l_1719:
	/* 0x1719: cmp    r14d,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_171d:
	/* 0x171d: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x171d, 0x42d1, x86_l_42d1);
x86_l_1723:
	/* 0x1723: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1726:
	/* 0x1726: js     221f <generic_fexit_event+0x221f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1726, 0x221f, x86_l_221f);
x86_l_172c:
	/* 0x172c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_172f:
	/* 0x172f: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1734:
	/* 0x1734: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1736:
	/* 0x1736: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1739:
	/* 0x1739: call   173e <generic_fexit_event+0x173e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_173e:
	/* 0x173e: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x173e, 0x42c7, x86_l_42c7);
x86_l_1743:
	/* 0x1743: cmp    r14d,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_1747:
	/* 0x1747: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_174d:
	/* 0x174d: je     1bc5 <generic_fexit_event+0x1bc5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x174d, 0x1bc5, x86_l_1bc5);
x86_l_1753:
	/* 0x1753: cmp    r14d,0x14 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 20ULL);
x86_l_1757:
	/* 0x1757: jne    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1757, 0x42d1, x86_l_42d1);
x86_l_175d:
	/* 0x175d: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1766:
	/* 0x1766: lea    r12,[rbp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_176d:
	/* 0x176d: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1770:
	/* 0x1770: add    rdx,0x110 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 272ULL);
x86_l_1777:
	/* 0x1777: jns    1f4f <generic_fexit_event+0x1f4f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1777, 0x1f4f, x86_l_1f4f);
x86_l_177d:
	/* 0x177d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1780:
	/* 0x1780: jns    2ebe <generic_fexit_event+0x2ebe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1780, 0x2ebe, x86_l_2ebe);
x86_l_1786:
	/* 0x1786: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1789:
	/* 0x1789: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_178e:
	/* 0x178e: jmp    1f63 <generic_fexit_event+0x1f63> */
	X86_SIM_X86_JMP(0x178e, 0x1f63, x86_l_1f63);
x86_l_1793:
	/* 0x1793: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1798:
	/* 0x1798: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_179d:
	/* 0x179d: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_17a2:
	/* 0x17a2: jmp    18ef <generic_fexit_event+0x18ef> */
	X86_SIM_X86_JMP(0x17a2, 0x18ef, x86_l_18ef);
x86_l_17a7:
	/* 0x17a7: cmp    r14d,0x26 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 38ULL);
x86_l_17ab:
	/* 0x17ab: jne    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17ab, 0x42c7, x86_l_42c7);
x86_l_17b1:
	/* 0x17b1: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_17b6:
	/* 0x17b6: movzx  edx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_17b9:
	/* 0x17b9: shr    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_17bc:
	/* 0x17bc: and    eax,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_17c1:
	/* 0x17c1: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17c6:
	/* 0x17c6: add    rdi,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_17cd:
	/* 0x17cd: lea    esi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17d0:
	/* 0x17d0: add    rdx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 184ULL);
x86_l_17d8:
	/* 0x17d8: jns    289c <generic_fexit_event+0x289c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17d8, 0x289c, x86_l_289c);
x86_l_17de:
	/* 0x17de: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17e1:
	/* 0x17e1: jns    27a3 <generic_fexit_event+0x27a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17e1, 0x27a3, x86_l_27a3);
x86_l_17e7:
	/* 0x17e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17e9:
	/* 0x17e9: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17ec:
	/* 0x17ec: je     324f <generic_fexit_event+0x324f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ec, 0x324f, x86_l_324f);
x86_l_17f2:
	/* 0x17f2: lea    r12,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17f6:
	/* 0x17f6: movzx  r8d,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_17fb:
	/* 0x17fb: mov    BYTE PTR [rdi+rcx*1],r8b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_17ff:
	/* 0x17ff: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1802:
	/* 0x1802: test   r8b,r8b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_8, 0, 0);
x86_l_1805:
	/* 0x1805: jne    17e9 <generic_fexit_event+0x17e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1805, 0x17e9, x86_l_17e9);
x86_l_1807:
	/* 0x1807: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x1807, 0x28ad, x86_l_28ad);
x86_l_180c:
	/* 0x180c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_180f:
	/* 0x180f: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1814:
	/* 0x1814: jns    1ccc <generic_fexit_event+0x1ccc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1814, 0x1ccc, x86_l_1ccc);
x86_l_181a:
	/* 0x181a: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_181e:
	/* 0x181e: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1821:
	/* 0x1821: jmp    1cd3 <generic_fexit_event+0x1cd3> */
	X86_SIM_X86_JMP(0x1821, 0x1cd3, x86_l_1cd3);
x86_l_1826:
	/* 0x1826: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_182b:
	/* 0x182b: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1830:
	/* 0x1830: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1835:
	/* 0x1835: jmp    18ef <generic_fexit_event+0x18ef> */
	X86_SIM_X86_JMP(0x1835, 0x18ef, x86_l_18ef);
x86_l_183a:
	/* 0x183a: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1843:
	/* 0x1843: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_184c:
	/* 0x184c: call   1851 <generic_fexit_event+0x1851> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1851:
	/* 0x1851: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1855:
	/* 0x1855: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_185a:
	/* 0x185a: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_185f:
	/* 0x185f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1862:
	/* 0x1862: jns    1cee <generic_fexit_event+0x1cee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1862, 0x1cee, x86_l_1cee);
x86_l_1868:
	/* 0x1868: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_186b:
	/* 0x186b: jns    2337 <generic_fexit_event+0x2337> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x186b, 0x2337, x86_l_2337);
x86_l_1871:
	/* 0x1871: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1873:
	/* 0x1873: mov    DWORD PTR [rsp+0x80],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_187a:
	/* 0x187a: jmp    2344 <generic_fexit_event+0x2344> */
	X86_SIM_X86_JMP(0x187a, 0x2344, x86_l_2344);
x86_l_187f:
	/* 0x187f: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1882:
	/* 0x1882: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1887:
	/* 0x1887: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_188a:
	/* 0x188a: js     1dcf <generic_fexit_event+0x1dcf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x188a, 0x1dcf, x86_l_1dcf);
x86_l_1890:
	/* 0x1890: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1898:
	/* 0x1898: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_189d:
	/* 0x189d: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18a0:
	/* 0x18a0: call   18a5 <generic_fexit_event+0x18a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_18a5:
	/* 0x18a5: movzx  eax,BYTE PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 144ULL);
x86_l_18ad:
	/* 0x18ad: jmp    1de5 <generic_fexit_event+0x1de5> */
	X86_SIM_X86_JMP(0x18ad, 0x1de5, x86_l_1de5);
x86_l_18b2:
	/* 0x18b2: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18b7:
	/* 0x18b7: lea    rdi,[rcx+0xc4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_18be:
	/* 0x18be: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_18c1:
	/* 0x18c1: add    rdx,0x98 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 152ULL);
x86_l_18c8:
	/* 0x18c8: jns    1d11 <generic_fexit_event+0x1d11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c8, 0x1d11, x86_l_1d11);
x86_l_18ce:
	/* 0x18ce: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18d1:
	/* 0x18d1: jns    23b0 <generic_fexit_event+0x23b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18d1, 0x23b0, x86_l_23b0);
x86_l_18d7:
	/* 0x18d7: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d9:
	/* 0x18d9: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18db:
	/* 0x18db: jmp    23b6 <generic_fexit_event+0x23b6> */
	X86_SIM_X86_JMP(0x18db, 0x23b6, x86_l_23b6);
x86_l_18e0:
	/* 0x18e0: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18e5:
	/* 0x18e5: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18ea:
	/* 0x18ea: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_18ef:
	/* 0x18ef: call   18f4 <generic_fexit_event+0x18f4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_18f4:
	/* 0x18f4: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_18fa:
	/* 0x18fa: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x18fa, 0x42c7, x86_l_42c7);
x86_l_18ff:
	/* 0x18ff: add    rdi,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_1906:
	/* 0x1906: mov    edx,0x118 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 280ULL);
x86_l_190b:
	/* 0x190b: add    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_1910:
	/* 0x1910: jns    1d33 <generic_fexit_event+0x1d33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1910, 0x1d33, x86_l_1d33);
x86_l_1916:
	/* 0x1916: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1919:
	/* 0x1919: jns    25db <generic_fexit_event+0x25db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1919, 0x25db, x86_l_25db);
x86_l_191f:
	/* 0x191f: movzx  eax,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1922:
	/* 0x1922: mov    BYTE PTR [rdi],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1924:
	/* 0x1924: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1926:
	/* 0x1926: je     3563 <generic_fexit_event+0x3563> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1926, 0x3563, x86_l_3563);
x86_l_192c:
	/* 0x192c: movzx  eax,BYTE PTR [rdx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1930:
	/* 0x1930: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1935:
	/* 0x1935: mov    BYTE PTR [rcx+0xa1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 161ULL);
x86_l_193b:
	/* 0x193b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_193d:
	/* 0x193d: je     3baf <generic_fexit_event+0x3baf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x193d, 0x3baf, x86_l_3baf);
x86_l_1943:
	/* 0x1943: movzx  eax,BYTE PTR [rdx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1947:
	/* 0x1947: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_194c:
	/* 0x194c: mov    BYTE PTR [rcx+0xa2],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 162ULL);
x86_l_1952:
	/* 0x1952: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1954:
	/* 0x1954: je     3e8c <generic_fexit_event+0x3e8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1954, 0x3e8c, x86_l_3e8c);
x86_l_195a:
	/* 0x195a: movzx  eax,BYTE PTR [rdx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_195e:
	/* 0x195e: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1963:
	/* 0x1963: mov    BYTE PTR [rcx+0xa3],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 163ULL);
x86_l_1969:
	/* 0x1969: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_196b:
	/* 0x196b: je     4325 <generic_fexit_event+0x4325> */
	X86_SIM_X86_JCC(X86_CC_E, 0x196b, 0x4325, x86_l_4325);
x86_l_1971:
	/* 0x1971: movzx  eax,BYTE PTR [rdx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1975:
	/* 0x1975: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_197a:
	/* 0x197a: mov    BYTE PTR [rcx+0xa4],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_1980:
	/* 0x1980: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1982:
	/* 0x1982: je     43c6 <generic_fexit_event+0x43c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1982, 0x43c6, x86_l_43c6);
x86_l_1988:
	/* 0x1988: movzx  eax,BYTE PTR [rdx+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_198c:
	/* 0x198c: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1991:
	/* 0x1991: mov    BYTE PTR [rcx+0xa5],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_1997:
	/* 0x1997: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1999:
	/* 0x1999: je     44ce <generic_fexit_event+0x44ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1999, 0x44ce, x86_l_44ce);
x86_l_199f:
	/* 0x199f: movzx  eax,BYTE PTR [rdx+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_19a3:
	/* 0x19a3: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19a8:
	/* 0x19a8: mov    BYTE PTR [rcx+0xa6],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_19ae:
	/* 0x19ae: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19b0:
	/* 0x19b0: je     44d9 <generic_fexit_event+0x44d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b0, 0x44d9, x86_l_44d9);
x86_l_19b6:
	/* 0x19b6: movzx  eax,BYTE PTR [rdx+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_19ba:
	/* 0x19ba: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19bf:
	/* 0x19bf: mov    BYTE PTR [rcx+0xa7],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 167ULL);
x86_l_19c5:
	/* 0x19c5: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19c7:
	/* 0x19c7: je     44fd <generic_fexit_event+0x44fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c7, 0x44fd, x86_l_44fd);
x86_l_19cd:
	/* 0x19cd: movzx  eax,BYTE PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19d1:
	/* 0x19d1: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19d6:
	/* 0x19d6: mov    BYTE PTR [rcx+0xa8],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_19dc:
	/* 0x19dc: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19de:
	/* 0x19de: je     4508 <generic_fexit_event+0x4508> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19de, 0x4508, x86_l_4508);
x86_l_19e4:
	/* 0x19e4: movzx  eax,BYTE PTR [rdx+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_19e8:
	/* 0x19e8: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ed:
	/* 0x19ed: mov    BYTE PTR [rcx+0xa9],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 169ULL);
x86_l_19f3:
	/* 0x19f3: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19f5:
	/* 0x19f5: je     4513 <generic_fexit_event+0x4513> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19f5, 0x4513, x86_l_4513);
x86_l_19fb:
	/* 0x19fb: movzx  eax,BYTE PTR [rdx+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_19ff:
	/* 0x19ff: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a04:
	/* 0x1a04: mov    BYTE PTR [rcx+0xaa],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 170ULL);
x86_l_1a0a:
	/* 0x1a0a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a0c:
	/* 0x1a0c: je     45b4 <generic_fexit_event+0x45b4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0c, 0x45b4, x86_l_45b4);
x86_l_1a12:
	/* 0x1a12: movzx  eax,BYTE PTR [rdx+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1a16:
	/* 0x1a16: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a1b:
	/* 0x1a1b: mov    BYTE PTR [rcx+0xab],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171ULL);
x86_l_1a21:
	/* 0x1a21: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a23:
	/* 0x1a23: je     46a8 <generic_fexit_event+0x46a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a23, 0x46a8, x86_l_46a8);
x86_l_1a29:
	/* 0x1a29: movzx  eax,BYTE PTR [rdx+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1a2d:
	/* 0x1a2d: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a32:
	/* 0x1a32: mov    BYTE PTR [rcx+0xac],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_1a38:
	/* 0x1a38: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a3a:
	/* 0x1a3a: je     46b3 <generic_fexit_event+0x46b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a3a, 0x46b3, x86_l_46b3);
x86_l_1a40:
	/* 0x1a40: movzx  eax,BYTE PTR [rdx+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1a44:
	/* 0x1a44: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a49:
	/* 0x1a49: mov    BYTE PTR [rcx+0xad],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 173ULL);
x86_l_1a4f:
	/* 0x1a4f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a51:
	/* 0x1a51: je     46be <generic_fexit_event+0x46be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a51, 0x46be, x86_l_46be);
x86_l_1a57:
	/* 0x1a57: movzx  eax,BYTE PTR [rdx+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1a5b:
	/* 0x1a5b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a60:
	/* 0x1a60: mov    BYTE PTR [rcx+0xae],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 174ULL);
x86_l_1a66:
	/* 0x1a66: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a68:
	/* 0x1a68: je     46e2 <generic_fexit_event+0x46e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a68, 0x46e2, x86_l_46e2);
x86_l_1a6e:
	/* 0x1a6e: movzx  eax,BYTE PTR [rdx+0xf] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 15ULL);
x86_l_1a72:
	/* 0x1a72: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a77:
	/* 0x1a77: mov    BYTE PTR [rcx+0xaf],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 175ULL);
x86_l_1a7d:
	/* 0x1a7d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a7f:
	/* 0x1a7f: je     46f9 <generic_fexit_event+0x46f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a7f, 0x46f9, x86_l_46f9);
x86_l_1a85:
	/* 0x1a85: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a8a:
	/* 0x1a8a: mov    BYTE PTR [rax+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_1a91:
	/* 0x1a91: mov    r12d,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a97:
	/* 0x1a97: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x1a97, 0x28ad, x86_l_28ad);
x86_l_1a9c:
	/* 0x1a9c: mov    r12,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1aa1:
	/* 0x1aa1: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1aa6:
	/* 0x1aa6: mov    QWORD PTR [r14+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1aae:
	/* 0x1aae: mov    QWORD PTR [r14+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1ab6:
	/* 0x1ab6: mov    QWORD PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1abd:
	/* 0x1abd: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ac0:
	/* 0x1ac0: js     1ea1 <generic_fexit_event+0x1ea1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ac0, 0x1ea1, x86_l_1ea1);
x86_l_1ac6:
	/* 0x1ac6: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ac9:
	/* 0x1ac9: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ace:
	/* 0x1ace: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ad1:
	/* 0x1ad1: call   1ad6 <generic_fexit_event+0x1ad6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1ad6:
	/* 0x1ad6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ad9:
	/* 0x1ad9: js     3dc9 <generic_fexit_event+0x3dc9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ad9, 0x3dc9, x86_l_3dc9);
x86_l_1adf:
	/* 0x1adf: movzx  eax,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ae3:
	/* 0x1ae3: jmp    1eb8 <generic_fexit_event+0x1eb8> */
	X86_SIM_X86_JMP(0x1ae3, 0x1eb8, x86_l_1eb8);
x86_l_1ae8:
	/* 0x1ae8: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aef:
	/* 0x1aef: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1af5:
	/* 0x1af5: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1af5, 0x42c7, x86_l_42c7);
x86_l_1afa:
	/* 0x1afa: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1afc:
	/* 0x1afc: mov    rdx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1aff:
	/* 0x1aff: jmp    6a4 <generic_fexit_event+0x6a4> */
	X86_SIM_X86_JMP(0x1aff, 0x6a4, x86_l_6a4);
x86_l_1b04:
	/* 0x1b04: mov    DWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b0a:
	/* 0x1b0a: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1b10:
	/* 0x1b10: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1b10, 0x42c7, x86_l_42c7);
x86_l_1b15:
	/* 0x1b15: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b1a:
	/* 0x1b1a: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_1b26:
	/* 0x1b26: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1b2f:
	/* 0x1b2f: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1b32:
	/* 0x1b32: jns    1eef <generic_fexit_event+0x1eef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b32, 0x1eef, x86_l_1eef);
x86_l_1b38:
	/* 0x1b38: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1b3d:
	/* 0x1b3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b40:
	/* 0x1b40: jns    2911 <generic_fexit_event+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b40, 0x2911, x86_l_2911);
x86_l_1b46:
	/* 0x1b46: mov    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b49:
	/* 0x1b49: mov    QWORD PTR [rsp+0x80],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1b51:
	/* 0x1b51: jmp    2920 <generic_fexit_event+0x2920> */
	X86_SIM_X86_JMP(0x1b51, 0x2920, x86_l_2920);
x86_l_1b56:
	/* 0x1b56: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b59:
	/* 0x1b59: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1b5d:
	/* 0x1b5d: jns    1f13 <generic_fexit_event+0x1f13> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b5d, 0x1f13, x86_l_1f13);
x86_l_1b63:
	/* 0x1b63: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b66:
	/* 0x1b66: jns    29c1 <generic_fexit_event+0x29c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b66, 0x29c1, x86_l_29c1);
x86_l_1b6c:
	/* 0x1b6c: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b6e:
	/* 0x1b6e: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b73:
	/* 0x1b73: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b75:
	/* 0x1b75: jmp    29cc <generic_fexit_event+0x29cc> */
	X86_SIM_X86_JMP(0x1b75, 0x29cc, x86_l_29cc);
x86_l_1b7a:
	/* 0x1b7a: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b7d:
	/* 0x1b7d: add    rdx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
x86_l_1b84:
	/* 0x1b84: jns    1f27 <generic_fexit_event+0x1f27> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b84, 0x1f27, x86_l_1f27);
x86_l_1b8a:
	/* 0x1b8a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b8d:
	/* 0x1b8d: jns    2ce6 <generic_fexit_event+0x2ce6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b8d, 0x2ce6, x86_l_2ce6);
x86_l_1b93:
	/* 0x1b93: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b95:
	/* 0x1b95: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b9a:
	/* 0x1b9a: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9c:
	/* 0x1b9c: jmp    2cf1 <generic_fexit_event+0x2cf1> */
	X86_SIM_X86_JMP(0x1b9c, 0x2cf1, x86_l_2cf1);
x86_l_1ba1:
	/* 0x1ba1: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1ba4:
	/* 0x1ba4: add    rdx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_1ba8:
	/* 0x1ba8: jns    1f3b <generic_fexit_event+0x1f3b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba8, 0x1f3b, x86_l_1f3b);
x86_l_1bae:
	/* 0x1bae: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bb1:
	/* 0x1bb1: jns    2dae <generic_fexit_event+0x2dae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bb1, 0x2dae, x86_l_2dae);
x86_l_1bb7:
	/* 0x1bb7: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bb9:
	/* 0x1bb9: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bbe:
	/* 0x1bbe: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bc0:
	/* 0x1bc0: jmp    2db9 <generic_fexit_event+0x2db9> */
	X86_SIM_X86_JMP(0x1bc0, 0x2db9, x86_l_2db9);
x86_l_1bc5:
	/* 0x1bc5: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1bc8:
	/* 0x1bc8: js     2227 <generic_fexit_event+0x2227> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bc8, 0x2227, x86_l_2227);
x86_l_1bce:
	/* 0x1bce: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bd3:
	/* 0x1bd3: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1bd8:
	/* 0x1bd8: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1bdb:
	/* 0x1bdb: call   1be0 <generic_fexit_event+0x1be0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1be0:
	/* 0x1be0: jmp    3148 <generic_fexit_event+0x3148> */
	X86_SIM_X86_JMP(0x1be0, 0x3148, x86_l_3148);
x86_l_1be5:
	/* 0x1be5: lea    rcx,[rbp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1be9:
	/* 0x1be9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1beb:
	/* 0x1beb: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1bf0:
	/* 0x1bf0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bf3:
	/* 0x1bf3: jns    1bf7 <generic_fexit_event+0x1bf7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bf3, 0x1bf7, x86_l_1bf7);
x86_l_1bf5:
	/* 0x1bf5: mov    edx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf7:
	/* 0x1bf7: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bfc:
	/* 0x1bfc: mov    DWORD PTR [rcx],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bfe:
	/* 0x1bfe: lea    rcx,[rbp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c02:
	/* 0x1c02: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c05:
	/* 0x1c05: jns    1c09 <generic_fexit_event+0x1c09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c05, 0x1c09, x86_l_1c09);
x86_l_1c07:
	/* 0x1c07: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c09:
	/* 0x1c09: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0e:
	/* 0x1c0e: mov    DWORD PTR [rcx+0xa0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1c14:
	/* 0x1c14: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1c18:
	/* 0x1c18: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1c1b:
	/* 0x1c1b: jns    1f99 <generic_fexit_event+0x1f99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c1b, 0x1f99, x86_l_1f99);
x86_l_1c21:
	/* 0x1c21: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c25:
	/* 0x1c25: jmp    1f9b <generic_fexit_event+0x1f9b> */
	X86_SIM_X86_JMP(0x1c25, 0x1f9b, x86_l_1f9b);
x86_l_1c2a:
	/* 0x1c2a: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c2f:
	/* 0x1c2f: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1c37:
	/* 0x1c37: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1c3f:
	/* 0x1c3f: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1c47:
	/* 0x1c47: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1c4f:
	/* 0x1c4f: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1c57:
	/* 0x1c57: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1c5f:
	/* 0x1c5f: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1c67:
	/* 0x1c67: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1c6f:
	/* 0x1c6f: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1c77:
	/* 0x1c77: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c7e:
	/* 0x1c7e: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1c81:
	/* 0x1c81: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c84:
	/* 0x1c84: jns    213b <generic_fexit_event+0x213b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c84, 0x213b, x86_l_213b);
x86_l_1c8a:
	/* 0x1c8a: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c8d:
	/* 0x1c8d: add    QWORD PTR [rsp+0x10],0xac */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476908ULL);
x86_l_1c96:
	/* 0x1c96: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c99:
	/* 0x1c99: js     31e9 <generic_fexit_event+0x31e9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c99, 0x31e9, x86_l_31e9);
x86_l_1c9f:
	/* 0x1c9f: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ca4:
	/* 0x1ca4: mov    esi,0x3f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 63ULL);
x86_l_1ca9:
	/* 0x1ca9: call   1cae <generic_fexit_event+0x1cae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1cae:
	/* 0x1cae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb1:
	/* 0x1cb1: js     21b4 <generic_fexit_event+0x21b4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1cb1, 0x21b4, x86_l_21b4);
x86_l_1cb7:
	/* 0x1cb7: lea    rax,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cbb:
	/* 0x1cbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cbe:
	/* 0x1cbe: jns    341a <generic_fexit_event+0x341a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cbe, 0x341a, x86_l_341a);
x86_l_1cc4:
	/* 0x1cc4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cc7:
	/* 0x1cc7: jmp    341c <generic_fexit_event+0x341c> */
	X86_SIM_X86_JMP(0x1cc7, 0x341c, x86_l_341c);
x86_l_1ccc:
	/* 0x1ccc: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd3:
	/* 0x1cd3: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1cd9:
	/* 0x1cd9: jmp    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JMP(0x1cd9, 0x42d1, x86_l_42d1);
x86_l_1cde:
	/* 0x1cde: mov    WORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ce3:
	/* 0x1ce3: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1ce9:
	/* 0x1ce9: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1ce9, 0x42c7, x86_l_42c7);
x86_l_1cee:
	/* 0x1cee: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1cf6:
	/* 0x1cf6: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1cfb:
	/* 0x1cfb: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1d00:
	/* 0x1d00: call   1d05 <generic_fexit_event+0x1d05> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1d05:
	/* 0x1d05: mov    eax,DWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1d0c:
	/* 0x1d0c: jmp    2344 <generic_fexit_event+0x2344> */
	X86_SIM_X86_JMP(0x1d0c, 0x2344, x86_l_2344);
x86_l_1d11:
	/* 0x1d11: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1d16:
	/* 0x1d16: call   1d1b <generic_fexit_event+0x1d1b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1d1b:
	/* 0x1d1b: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d20:
	/* 0x1d20: jmp    23b6 <generic_fexit_event+0x23b6> */
	X86_SIM_X86_JMP(0x1d20, 0x23b6, x86_l_23b6);
x86_l_1d25:
	/* 0x1d25: mov    BYTE PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d28:
	/* 0x1d28: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1d2e:
	/* 0x1d2e: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x1d2e, 0x42c7, x86_l_42c7);
x86_l_1d33:
	/* 0x1d33: mov    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1d38:
	/* 0x1d38: jmp    289c <generic_fexit_event+0x289c> */
	X86_SIM_X86_JMP(0x1d38, 0x289c, x86_l_289c);
x86_l_1d3d:
	/* 0x1d3d: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d42:
	/* 0x1d42: call   1d47 <generic_fexit_event+0x1d47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1d47:
	/* 0x1d47: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d4c:
	/* 0x1d4c: jmp    25ff <generic_fexit_event+0x25ff> */
	X86_SIM_X86_JMP(0x1d4c, 0x25ff, x86_l_25ff);
x86_l_1d51:
	/* 0x1d51: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1d56:
	/* 0x1d56: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d5b:
	/* 0x1d5b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1d60:
	/* 0x1d60: call   1d65 <generic_fexit_event+0x1d65> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1d65:
	/* 0x1d65: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1d6a:
	/* 0x1d6a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d6d:
	/* 0x1d6d: jns    27b5 <generic_fexit_event+0x27b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d6d, 0x27b5, x86_l_27b5);
x86_l_1d73:
	/* 0x1d73: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d76:
	/* 0x1d76: jns    286f <generic_fexit_event+0x286f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d76, 0x286f, x86_l_286f);
x86_l_1d7c:
	/* 0x1d7c: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d7f:
	/* 0x1d7f: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d84:
	/* 0x1d84: jmp    2878 <generic_fexit_event+0x2878> */
	X86_SIM_X86_JMP(0x1d84, 0x2878, x86_l_2878);
x86_l_1d89:
	/* 0x1d89: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d8b:
	/* 0x1d8b: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1d8e:
	/* 0x1d8e: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1d91:
	/* 0x1d91: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1d94:
	/* 0x1d94: test   r10b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1d98:
	/* 0x1d98: je     1363 <generic_fexit_event+0x1363> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d98, 0x1363, x86_l_1363);
x86_l_1d9e:
	/* 0x1d9e: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1da0:
	/* 0x1da0: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_1da4:
	/* 0x1da4: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1da8:
	/* 0x1da8: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1dab:
	/* 0x1dab: test   r10b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1daf:
	/* 0x1daf: je     136d <generic_fexit_event+0x136d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1daf, 0x136d, x86_l_136d);
x86_l_1db5:
	/* 0x1db5: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1db7:
	/* 0x1db7: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1dbb:
	/* 0x1dbb: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1dbe:
	/* 0x1dbe: add    r15,r10 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R10, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1dc1:
	/* 0x1dc1: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1dc4:
	/* 0x1dc4: jne    1379 <generic_fexit_event+0x1379> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dc4, 0x1379, x86_l_1379);
x86_l_1dca:
	/* 0x1dca: jmp    15d1 <generic_fexit_event+0x15d1> */
	X86_SIM_X86_JMP(0x1dca, 0x15d1, x86_l_15d1);
x86_l_1dcf:
	/* 0x1dcf: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1dd2:
	/* 0x1dd2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dd5:
	/* 0x1dd5: jns    280a <generic_fexit_event+0x280a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dd5, 0x280a, x86_l_280a);
x86_l_1ddb:
	/* 0x1ddb: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1dde:
	/* 0x1dde: mov    BYTE PTR [rsp+0x90],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1de5:
	/* 0x1de5: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1de7:
	/* 0x1de7: je     2812 <generic_fexit_event+0x2812> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de7, 0x2812, x86_l_2812);
x86_l_1ded:
	/* 0x1ded: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1df0:
	/* 0x1df0: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1df3:
	/* 0x1df3: jne    2241 <generic_fexit_event+0x2241> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1df3, 0x2241, x86_l_2241);
x86_l_1df9:
	/* 0x1df9: add    r12,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1dfd:
	/* 0x1dfd: jns    3216 <generic_fexit_event+0x3216> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dfd, 0x3216, x86_l_3216);
x86_l_1e03:
	/* 0x1e03: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e06:
	/* 0x1e06: jns    3a14 <generic_fexit_event+0x3a14> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e06, 0x3a14, x86_l_3a14);
x86_l_1e0c:
	/* 0x1e0c: mov    rdx,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e10:
	/* 0x1e10: mov    QWORD PTR [rsp+0x40],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e15:
	/* 0x1e15: jmp    322d <generic_fexit_event+0x322d> */
	X86_SIM_X86_JMP(0x1e15, 0x322d, x86_l_322d);
x86_l_1e1a:
	/* 0x1e1a: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e1d:
	/* 0x1e1d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e20:
	/* 0x1e20: jns    284b <generic_fexit_event+0x284b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e20, 0x284b, x86_l_284b);
x86_l_1e26:
	/* 0x1e26: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1e29:
	/* 0x1e29: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e2e:
	/* 0x1e2e: mov    WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e31:
	/* 0x1e31: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e34:
	/* 0x1e34: add    r13,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1e38:
	/* 0x1e38: jns    21c7 <generic_fexit_event+0x21c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e38, 0x21c7, x86_l_21c7);
x86_l_1e3e:
	/* 0x1e3e: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e41:
	/* 0x1e41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e44:
	/* 0x1e44: jns    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e44, 0x42bb, x86_l_42bb);
x86_l_1e4a:
	/* 0x1e4a: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1e4d:
	/* 0x1e4d: mov    BYTE PTR [rsp+0x40],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e51:
	/* 0x1e51: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1e53:
	/* 0x1e53: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e58:
	/* 0x1e58: sete   BYTE PTR [rax+0x9e] */
	X86_SIM_RUN_OP(X86_OP_SETCC_MEM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 158ULL);
x86_l_1e5f:
	/* 0x1e5f: je     327a <generic_fexit_event+0x327a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e5f, 0x327a, x86_l_327a);
x86_l_1e65:
	/* 0x1e65: add    QWORD PTR [rsp+0x10],0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476896ULL);
x86_l_1e6e:
	/* 0x1e6e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e71:
	/* 0x1e71: jns    3dd4 <generic_fexit_event+0x3dd4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e71, 0x3dd4, x86_l_3dd4);
x86_l_1e77:
	/* 0x1e77: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e79:
	/* 0x1e79: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e7e:
	/* 0x1e7e: cmp    rcx,0x6b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 107ULL);
x86_l_1e82:
	/* 0x1e82: je     429d <generic_fexit_event+0x429d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e82, 0x429d, x86_l_429d);
x86_l_1e88:
	/* 0x1e88: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e8c:
	/* 0x1e8c: movzx  edx,BYTE PTR [r13+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1e92:
	/* 0x1e92: mov    BYTE PTR [rsi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1e95:
	/* 0x1e95: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e98:
	/* 0x1e98: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1e9a:
	/* 0x1e9a: jne    1e7e <generic_fexit_event+0x1e7e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e9a, 0x1e7e, x86_l_1e7e);
x86_l_1e9c:
	/* 0x1e9c: jmp    2212 <generic_fexit_event+0x2212> */
	X86_SIM_X86_JMP(0x1e9c, 0x2212, x86_l_2212);
x86_l_1ea1:
	/* 0x1ea1: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ea4:
	/* 0x1ea4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ea7:
	/* 0x1ea7: jns    285a <generic_fexit_event+0x285a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ea7, 0x285a, x86_l_285a);
x86_l_1ead:
	/* 0x1ead: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1eb0:
	/* 0x1eb0: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1eb5:
	/* 0x1eb5: mov    WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb8:
	/* 0x1eb8: cmp    ax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 10ULL);
x86_l_1ebc:
	/* 0x1ebc: je     27c9 <generic_fexit_event+0x27c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ebc, 0x27c9, x86_l_27c9);
x86_l_1ec2:
	/* 0x1ec2: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1ec5:
	/* 0x1ec5: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ec8:
	/* 0x1ec8: jne    3dae <generic_fexit_event+0x3dae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ec8, 0x3dae, x86_l_3dae);
x86_l_1ece:
	/* 0x1ece: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ed1:
	/* 0x1ed1: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1ed5:
	/* 0x1ed5: jns    34ec <generic_fexit_event+0x34ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ed5, 0x34ec, x86_l_34ec);
x86_l_1edb:
	/* 0x1edb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ede:
	/* 0x1ede: jns    3d2b <generic_fexit_event+0x3d2b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ede, 0x3d2b, x86_l_3d2b);
x86_l_1ee4:
	/* 0x1ee4: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee6:
	/* 0x1ee6: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1eea:
	/* 0x1eea: jmp    3d35 <generic_fexit_event+0x3d35> */
	X86_SIM_X86_JMP(0x1eea, 0x3d35, x86_l_3d35);
x86_l_1eef:
	/* 0x1eef: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1ef7:
	/* 0x1ef7: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1efc:
	/* 0x1efc: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1f01:
	/* 0x1f01: call   1f06 <generic_fexit_event+0x1f06> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f06:
	/* 0x1f06: mov    r14,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1f0e:
	/* 0x1f0e: jmp    2920 <generic_fexit_event+0x2920> */
	X86_SIM_X86_JMP(0x1f0e, 0x2920, x86_l_2920);
x86_l_1f13:
	/* 0x1f13: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f18:
	/* 0x1f18: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f1d:
	/* 0x1f1d: call   1f22 <generic_fexit_event+0x1f22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f22:
	/* 0x1f22: jmp    29cc <generic_fexit_event+0x29cc> */
	X86_SIM_X86_JMP(0x1f22, 0x29cc, x86_l_29cc);
x86_l_1f27:
	/* 0x1f27: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f2c:
	/* 0x1f2c: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f31:
	/* 0x1f31: call   1f36 <generic_fexit_event+0x1f36> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f36:
	/* 0x1f36: jmp    2cf1 <generic_fexit_event+0x2cf1> */
	X86_SIM_X86_JMP(0x1f36, 0x2cf1, x86_l_2cf1);
x86_l_1f3b:
	/* 0x1f3b: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f40:
	/* 0x1f40: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f45:
	/* 0x1f45: call   1f4a <generic_fexit_event+0x1f4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f4a:
	/* 0x1f4a: jmp    2db9 <generic_fexit_event+0x2db9> */
	X86_SIM_X86_JMP(0x1f4a, 0x2db9, x86_l_2db9);
x86_l_1f4f:
	/* 0x1f4f: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f54:
	/* 0x1f54: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1f59:
	/* 0x1f59: call   1f5e <generic_fexit_event+0x1f5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f5e:
	/* 0x1f5e: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f63:
	/* 0x1f63: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f66:
	/* 0x1f66: jns    2ec9 <generic_fexit_event+0x2ec9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f66, 0x2ec9, x86_l_2ec9);
x86_l_1f6c:
	/* 0x1f6c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f6f:
	/* 0x1f6f: jns    3463 <generic_fexit_event+0x3463> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6f, 0x3463, x86_l_3463);
x86_l_1f75:
	/* 0x1f75: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f77:
	/* 0x1f77: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f7c:
	/* 0x1f7c: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_1f80:
	/* 0x1f80: je     3c1d <generic_fexit_event+0x3c1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f80, 0x3c1d, x86_l_3c1d);
x86_l_1f86:
	/* 0x1f86: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1f8a:
	/* 0x1f8a: mov    BYTE PTR [rsi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1f8d:
	/* 0x1f8d: inc    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1f90:
	/* 0x1f90: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1f92:
	/* 0x1f92: jne    1f7c <generic_fexit_event+0x1f7c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f92, 0x1f7c, x86_l_1f7c);
x86_l_1f94:
	/* 0x1f94: jmp    2ed8 <generic_fexit_event+0x2ed8> */
	X86_SIM_X86_JMP(0x1f94, 0x2ed8, x86_l_2ed8);
x86_l_1f99:
	/* 0x1f99: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f9b:
	/* 0x1f9b: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fa0:
	/* 0x1fa0: add    rdx,0xa4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 164ULL);
x86_l_1fa7:
	/* 0x1fa7: add    rax,0x400 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1024ULL);
x86_l_1fad:
	/* 0x1fad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fb0:
	/* 0x1fb0: jns    2121 <generic_fexit_event+0x2121> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb0, 0x2121, x86_l_2121);
x86_l_1fb6:
	/* 0x1fb6: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1fb9:
	/* 0x1fb9: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fbb:
	/* 0x1fbb: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_1fc1:
	/* 0x1fc1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1fc3:
	/* 0x1fc3: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc3, 0x42c7, x86_l_42c7);
x86_l_1fc9:
	/* 0x1fc9: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1fcd:
	/* 0x1fcd: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fd2:
	/* 0x1fd2: mov    BYTE PTR [rdx+0xa5],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 165ULL);
x86_l_1fd8:
	/* 0x1fd8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1fda:
	/* 0x1fda: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fda, 0x42c7, x86_l_42c7);
x86_l_1fe0:
	/* 0x1fe0: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1fe4:
	/* 0x1fe4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fe9:
	/* 0x1fe9: mov    BYTE PTR [rdx+0xa6],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 166ULL);
x86_l_1fef:
	/* 0x1fef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1ff1:
	/* 0x1ff1: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ff1, 0x42c7, x86_l_42c7);
x86_l_1ff7:
	/* 0x1ff7: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1ffb:
	/* 0x1ffb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2000:
	/* 0x2000: mov    BYTE PTR [rdx+0xa7],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 167ULL);
x86_l_2006:
	/* 0x2006: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2008:
	/* 0x2008: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2008, 0x42c7, x86_l_42c7);
x86_l_200e:
	/* 0x200e: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2012:
	/* 0x2012: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2017:
	/* 0x2017: mov    BYTE PTR [rdx+0xa8],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_201d:
	/* 0x201d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_201f:
	/* 0x201f: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201f, 0x42c7, x86_l_42c7);
x86_l_2025:
	/* 0x2025: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2029:
	/* 0x2029: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_202e:
	/* 0x202e: mov    BYTE PTR [rdx+0xa9],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 169ULL);
x86_l_2034:
	/* 0x2034: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2036:
	/* 0x2036: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2036, 0x42c7, x86_l_42c7);
x86_l_203c:
	/* 0x203c: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2040:
	/* 0x2040: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2045:
	/* 0x2045: mov    BYTE PTR [rdx+0xaa],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 170ULL);
x86_l_204b:
	/* 0x204b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_204d:
	/* 0x204d: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x204d, 0x42c7, x86_l_42c7);
x86_l_2053:
	/* 0x2053: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2057:
	/* 0x2057: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_205c:
	/* 0x205c: mov    BYTE PTR [rdx+0xab],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171ULL);
x86_l_2062:
	/* 0x2062: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2064:
	/* 0x2064: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2064, 0x42c7, x86_l_42c7);
x86_l_206a:
	/* 0x206a: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_206e:
	/* 0x206e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2073:
	/* 0x2073: mov    BYTE PTR [rdx+0xac],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2079:
	/* 0x2079: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_207b:
	/* 0x207b: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207b, 0x42c7, x86_l_42c7);
x86_l_2081:
	/* 0x2081: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2085:
	/* 0x2085: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_208a:
	/* 0x208a: mov    BYTE PTR [rdx+0xad],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 173ULL);
x86_l_2090:
	/* 0x2090: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2092:
	/* 0x2092: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2092, 0x42c7, x86_l_42c7);
x86_l_2098:
	/* 0x2098: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_209c:
	/* 0x209c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20a1:
	/* 0x20a1: mov    BYTE PTR [rdx+0xae],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 174ULL);
x86_l_20a7:
	/* 0x20a7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_20a9:
	/* 0x20a9: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a9, 0x42c7, x86_l_42c7);
x86_l_20af:
	/* 0x20af: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_20b3:
	/* 0x20b3: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b8:
	/* 0x20b8: mov    BYTE PTR [rdx+0xaf],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 175ULL);
x86_l_20be:
	/* 0x20be: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_20c0:
	/* 0x20c0: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20c0, 0x42c7, x86_l_42c7);
x86_l_20c6:
	/* 0x20c6: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_20ca:
	/* 0x20ca: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20cf:
	/* 0x20cf: mov    BYTE PTR [rdx+0xb0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_20d5:
	/* 0x20d5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_20d7:
	/* 0x20d7: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20d7, 0x42c7, x86_l_42c7);
x86_l_20dd:
	/* 0x20dd: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_20e1:
	/* 0x20e1: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20e6:
	/* 0x20e6: mov    BYTE PTR [rdx+0xb1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_20ec:
	/* 0x20ec: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_20ee:
	/* 0x20ee: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ee, 0x42c7, x86_l_42c7);
x86_l_20f4:
	/* 0x20f4: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_20f8:
	/* 0x20f8: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20fd:
	/* 0x20fd: mov    BYTE PTR [rcx+0xb2],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 178ULL);
x86_l_2103:
	/* 0x2103: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2105:
	/* 0x2105: je     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2105, 0x42c7, x86_l_42c7);
x86_l_210b:
	/* 0x210b: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2110:
	/* 0x2110: mov    BYTE PTR [rsi+0xb3],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 768799145984ULL);
x86_l_2117:
	/* 0x2117: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_211c:
	/* 0x211c: jmp    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JMP(0x211c, 0x42d1, x86_l_42d1);
x86_l_2121:
	/* 0x2121: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2129:
	/* 0x2129: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2130:
	/* 0x2130: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_2136:
	/* 0x2136: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x2136, 0x42c7, x86_l_42c7);
x86_l_213b:
	/* 0x213b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_213e:
	/* 0x213e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2143:
	/* 0x2143: jmp    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JMP(0x2143, 0x42d1, x86_l_42d1);
x86_l_2148:
	/* 0x2148: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_214d:
	/* 0x214d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2152:
	/* 0x2152: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2155:
	/* 0x2155: call   215a <generic_fexit_event+0x215a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_215a:
	/* 0x215a: mov    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_215f:
	/* 0x215f: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2162:
	/* 0x2162: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2167:
	/* 0x2167: je     3ffc <generic_fexit_event+0x3ffc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2167, 0x3ffc, x86_l_3ffc);
x86_l_216d:
	/* 0x216d: mov    QWORD PTR [rax+0xc4],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_2174:
	/* 0x2174: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2179:
	/* 0x2179: lea    rdi,[rax+0xc2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 194ULL);
x86_l_2180:
	/* 0x2180: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2183:
	/* 0x2183: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2187:
	/* 0x2187: jns    2fe0 <generic_fexit_event+0x2fe0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2187, 0x2fe0, x86_l_2fe0);
x86_l_218d:
	/* 0x218d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2190:
	/* 0x2190: jns    3588 <generic_fexit_event+0x3588> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2190, 0x3588, x86_l_3588);
x86_l_2196:
	/* 0x2196: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2199:
	/* 0x2199: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_219c:
	/* 0x219c: jmp    358d <generic_fexit_event+0x358d> */
	X86_SIM_X86_JMP(0x219c, 0x358d, x86_l_358d);
x86_l_21a1:
	/* 0x21a1: mov    esi,0x3f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 63ULL);
x86_l_21a6:
	/* 0x21a6: call   21ab <generic_fexit_event+0x21ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_21ab:
	/* 0x21ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21ae:
	/* 0x21ae: jns    351f <generic_fexit_event+0x351f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21ae, 0x351f, x86_l_351f);
x86_l_21b4:
	/* 0x21b4: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b7:
	/* 0x21b7: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21bc:
	/* 0x21bc: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_21c2:
	/* 0x21c2: jmp    42cc <generic_fexit_event+0x42cc> */
	X86_SIM_X86_JMP(0x21c2, 0x42cc, x86_l_42cc);
x86_l_21c7:
	/* 0x21c7: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_21cc:
	/* 0x21cc: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_21d1:
	/* 0x21d1: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21d4:
	/* 0x21d4: call   21d9 <generic_fexit_event+0x21d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_21d9:
	/* 0x21d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21dc:
	/* 0x21dc: js     42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21dc, 0x42bb, x86_l_42bb);
x86_l_21e2:
	/* 0x21e2: cmp    BYTE PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_21e7:
	/* 0x21e7: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21ec:
	/* 0x21ec: sete   BYTE PTR [rax+0x9e] */
	X86_SIM_RUN_OP(X86_OP_SETCC_MEM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 158ULL);
x86_l_21f3:
	/* 0x21f3: je     327a <generic_fexit_event+0x327a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21f3, 0x327a, x86_l_327a);
x86_l_21f9:
	/* 0x21f9: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21fe:
	/* 0x21fe: add    rdi,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_2205:
	/* 0x2205: mov    esi,0x6c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 108ULL);
x86_l_220a:
	/* 0x220a: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_220d:
	/* 0x220d: call   2212 <generic_fexit_event+0x2212> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2212:
	/* 0x2212: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2214:
	/* 0x2214: jns    42ae <generic_fexit_event+0x42ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2214, 0x42ae, x86_l_42ae);
x86_l_221a:
	/* 0x221a: jmp    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JMP(0x221a, 0x42bb, x86_l_42bb);
x86_l_221f:
	/* 0x221f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2222:
	/* 0x2222: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x2222, 0x42c7, x86_l_42c7);
x86_l_2227:
	/* 0x2227: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_222a:
	/* 0x222a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_222d:
	/* 0x222d: jns    313d <generic_fexit_event+0x313d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x222d, 0x313d, x86_l_313d);
x86_l_2233:
	/* 0x2233: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2235:
	/* 0x2235: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_223a:
	/* 0x223a: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_223c:
	/* 0x223c: jmp    3148 <generic_fexit_event+0x3148> */
	X86_SIM_X86_JMP(0x223c, 0x3148, x86_l_3148);
x86_l_2241:
	/* 0x2241: mov    QWORD PTR [rbp+0x9c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 670014898176ULL);
x86_l_224c:
	/* 0x224c: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2252:
	/* 0x2252: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x2252, 0x42c1, x86_l_42c1);
x86_l_2257:
	/* 0x2257: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_225c:
	/* 0x225c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_225f:
	/* 0x225f: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x225f, 0x6ae, x86_l_6ae);
x86_l_2265:
	/* 0x2265: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2268:
	/* 0x2268: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_226d:
	/* 0x226d: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2271:
	/* 0x2271: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2274:
	/* 0x2274: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2279:
	/* 0x2279: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_227c:
	/* 0x227c: mov    QWORD PTR [rsp+0x8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2281:
	/* 0x2281: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2286:
	/* 0x2286: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2289:
	/* 0x2289: jb     22a9 <generic_fexit_event+0x22a9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2289, 0x22a9, x86_l_22a9);
x86_l_228b:
	/* 0x228b: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2290:
	/* 0x2290: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2293:
	/* 0x2293: jne    22ae <generic_fexit_event+0x22ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2293, 0x22ae, x86_l_22ae);
x86_l_2295:
	/* 0x2295: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_229a:
	/* 0x229a: cmp    r13,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_22a1:
	/* 0x22a1: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22a1, 0x6ae, x86_l_6ae);
x86_l_22a7:
	/* 0x22a7: jmp    22c5 <generic_fexit_event+0x22c5> */
	X86_SIM_X86_JMP(0x22a7, 0x22c5, x86_l_22c5);
x86_l_22a9:
	/* 0x22a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22ac:
	/* 0x22ac: je     2295 <generic_fexit_event+0x2295> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22ac, 0x2295, x86_l_2295);
x86_l_22ae:
	/* 0x22ae: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22b3:
	/* 0x22b3: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_22b8:
	/* 0x22b8: cmp    r13,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_22bf:
	/* 0x22bf: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22bf, 0x6ae, x86_l_6ae);
x86_l_22c5:
	/* 0x22c5: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_22c8:
	/* 0x22c8: add    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_22cd:
	/* 0x22cd: mov    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22d0:
	/* 0x22d0: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_22d6:
	/* 0x22d6: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_22d9:
	/* 0x22d9: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22de:
	/* 0x22de: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22e1:
	/* 0x22e1: jns    356e <generic_fexit_event+0x356e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e1, 0x356e, x86_l_356e);
x86_l_22e7:
	/* 0x22e7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22ea:
	/* 0x22ea: jns    3e4c <generic_fexit_event+0x3e4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22ea, 0x3e4c, x86_l_3e4c);
x86_l_22f0:
	/* 0x22f0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22f2:
	/* 0x22f2: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_22f5:
	/* 0x22f5: cmp    r8d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_22f9:
	/* 0x22f9: jb     2314 <generic_fexit_event+0x2314> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22f9, 0x2314, x86_l_2314);
x86_l_22fb:
	/* 0x22fb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22fd:
	/* 0x22fd: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_22ff:
	/* 0x22ff: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2303:
	/* 0x2303: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2307:
	/* 0x2307: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_230a:
	/* 0x230a: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_230d:
	/* 0x230d: cmp    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2310:
	/* 0x2310: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2312:
	/* 0x2312: jbe    22fd <generic_fexit_event+0x22fd> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2312, 0x22fd, x86_l_22fd);
x86_l_2314:
	/* 0x2314: test   r8b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_2318:
	/* 0x2318: jne    4330 <generic_fexit_event+0x4330> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2318, 0x4330, x86_l_4330);
x86_l_231e:
	/* 0x231e: test   r13b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2322:
	/* 0x2322: jne    4345 <generic_fexit_event+0x4345> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2322, 0x4345, x86_l_4345);
x86_l_2328:
	/* 0x2328: test   r13b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_232c:
	/* 0x232c: jne    4358 <generic_fexit_event+0x4358> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x232c, 0x4358, x86_l_4358);
x86_l_2332:
	/* 0x2332: jmp    4361 <generic_fexit_event+0x4361> */
	X86_SIM_X86_JMP(0x2332, 0x4361, x86_l_4361);
x86_l_2337:
	/* 0x2337: mov    DWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_2342:
	/* 0x2342: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2344:
	/* 0x2344: mov    DWORD PTR [rsp+0x48],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2348:
	/* 0x2348: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_234f:
	/* 0x234f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2354:
	/* 0x2354: call   2359 <generic_fexit_event+0x2359> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2359:
	/* 0x2359: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_235c:
	/* 0x235c: je     2388 <generic_fexit_event+0x2388> */
	X86_SIM_X86_JCC(X86_CC_E, 0x235c, 0x2388, x86_l_2388);
x86_l_235e:
	/* 0x235e: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2361:
	/* 0x2361: mov    r14d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2364:
	/* 0x2364: lea    rax,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_236c:
	/* 0x236c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_236f:
	/* 0x236f: jns    2394 <generic_fexit_event+0x2394> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x236f, 0x2394, x86_l_2394);
x86_l_2371:
	/* 0x2371: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2374:
	/* 0x2374: jns    3017 <generic_fexit_event+0x3017> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2374, 0x3017, x86_l_3017);
x86_l_237a:
	/* 0x237a: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_237c:
	/* 0x237c: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2381:
	/* 0x2381: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2383:
	/* 0x2383: jmp    3022 <generic_fexit_event+0x3022> */
	X86_SIM_X86_JMP(0x2383, 0x3022, x86_l_3022);
x86_l_2388:
	/* 0x2388: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_238f:
	/* 0x238f: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x238f, 0x42c1, x86_l_42c1);
x86_l_2394:
	/* 0x2394: lea    rdx,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_239c:
	/* 0x239c: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23a1:
	/* 0x23a1: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_23a6:
	/* 0x23a6: call   23ab <generic_fexit_event+0x23ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_23ab:
	/* 0x23ab: jmp    3022 <generic_fexit_event+0x3022> */
	X86_SIM_X86_JMP(0x23ab, 0x3022, x86_l_3022);
x86_l_23b0:
	/* 0x23b0: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23b6:
	/* 0x23b6: lea    rdi,[rcx+0xc8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_23bd:
	/* 0x23bd: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_23c0:
	/* 0x23c0: add    rdx,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_23c4:
	/* 0x23c4: jns    23d1 <generic_fexit_event+0x23d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c4, 0x23d1, x86_l_23d1);
x86_l_23c6:
	/* 0x23c6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23c9:
	/* 0x23c9: jns    23e2 <generic_fexit_event+0x23e2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c9, 0x23e2, x86_l_23e2);
x86_l_23cb:
	/* 0x23cb: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23cd:
	/* 0x23cd: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23cf:
	/* 0x23cf: jmp    23e8 <generic_fexit_event+0x23e8> */
	X86_SIM_X86_JMP(0x23cf, 0x23e8, x86_l_23e8);
x86_l_23d1:
	/* 0x23d1: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_23d6:
	/* 0x23d6: call   23db <generic_fexit_event+0x23db> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_23db:
	/* 0x23db: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23e0:
	/* 0x23e0: jmp    23e8 <generic_fexit_event+0x23e8> */
	X86_SIM_X86_JMP(0x23e0, 0x23e8, x86_l_23e8);
x86_l_23e2:
	/* 0x23e2: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e8:
	/* 0x23e8: lea    rdi,[rcx+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_23ef:
	/* 0x23ef: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_23f2:
	/* 0x23f2: add    rdx,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_23f9:
	/* 0x23f9: jns    2406 <generic_fexit_event+0x2406> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f9, 0x2406, x86_l_2406);
x86_l_23fb:
	/* 0x23fb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23fe:
	/* 0x23fe: jns    2417 <generic_fexit_event+0x2417> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23fe, 0x2417, x86_l_2417);
x86_l_2400:
	/* 0x2400: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2402:
	/* 0x2402: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2404:
	/* 0x2404: jmp    241d <generic_fexit_event+0x241d> */
	X86_SIM_X86_JMP(0x2404, 0x241d, x86_l_241d);
x86_l_2406:
	/* 0x2406: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_240b:
	/* 0x240b: call   2410 <generic_fexit_event+0x2410> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2410:
	/* 0x2410: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2415:
	/* 0x2415: jmp    241d <generic_fexit_event+0x241d> */
	X86_SIM_X86_JMP(0x2415, 0x241d, x86_l_241d);
x86_l_2417:
	/* 0x2417: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241d:
	/* 0x241d: lea    rdi,[rcx+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2424:
	/* 0x2424: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2427:
	/* 0x2427: add    rdx,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_242e:
	/* 0x242e: jns    243b <generic_fexit_event+0x243b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x242e, 0x243b, x86_l_243b);
x86_l_2430:
	/* 0x2430: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2433:
	/* 0x2433: jns    2447 <generic_fexit_event+0x2447> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2433, 0x2447, x86_l_2447);
x86_l_2435:
	/* 0x2435: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2437:
	/* 0x2437: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2439:
	/* 0x2439: jmp    244d <generic_fexit_event+0x244d> */
	X86_SIM_X86_JMP(0x2439, 0x244d, x86_l_244d);
x86_l_243b:
	/* 0x243b: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2440:
	/* 0x2440: call   2445 <generic_fexit_event+0x2445> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2445:
	/* 0x2445: jmp    244d <generic_fexit_event+0x244d> */
	X86_SIM_X86_JMP(0x2445, 0x244d, x86_l_244d);
x86_l_2447:
	/* 0x2447: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244d:
	/* 0x244d: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2456:
	/* 0x2456: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2459:
	/* 0x2459: add    rdx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
x86_l_2460:
	/* 0x2460: jns    2471 <generic_fexit_event+0x2471> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2460, 0x2471, x86_l_2471);
x86_l_2462:
	/* 0x2462: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2465:
	/* 0x2465: jns    2482 <generic_fexit_event+0x2482> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2465, 0x2482, x86_l_2482);
x86_l_2467:
	/* 0x2467: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_246a:
	/* 0x246a: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_246f:
	/* 0x246f: jmp    248b <generic_fexit_event+0x248b> */
	X86_SIM_X86_JMP(0x246f, 0x248b, x86_l_248b);
x86_l_2471:
	/* 0x2471: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2476:
	/* 0x2476: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_247b:
	/* 0x247b: call   2480 <generic_fexit_event+0x2480> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2480:
	/* 0x2480: jmp    248b <generic_fexit_event+0x248b> */
	X86_SIM_X86_JMP(0x2480, 0x248b, x86_l_248b);
x86_l_2482:
	/* 0x2482: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_248b:
	/* 0x248b: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_248e:
	/* 0x248e: add    rdx,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_2495:
	/* 0x2495: mov    QWORD PTR [rsp+0xc8],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_249d:
	/* 0x249d: jns    24b1 <generic_fexit_event+0x24b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x249d, 0x24b1, x86_l_24b1);
x86_l_249f:
	/* 0x249f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_24a2:
	/* 0x24a2: jns    24cd <generic_fexit_event+0x24cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24a2, 0x24cd, x86_l_24cd);
x86_l_24a4:
	/* 0x24a4: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_24a7:
	/* 0x24a7: mov    WORD PTR [rsp+0xa0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_24af:
	/* 0x24af: jmp    24d9 <generic_fexit_event+0x24d9> */
	X86_SIM_X86_JMP(0x24af, 0x24d9, x86_l_24d9);
x86_l_24b1:
	/* 0x24b1: lea    rdi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_24b9:
	/* 0x24b9: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24be:
	/* 0x24be: call   24c3 <generic_fexit_event+0x24c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_24c3:
	/* 0x24c3: movzx  eax,WORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 160ULL);
x86_l_24cb:
	/* 0x24cb: jmp    24d9 <generic_fexit_event+0x24d9> */
	X86_SIM_X86_JMP(0x24cb, 0x24d9, x86_l_24d9);
x86_l_24cd:
	/* 0x24cd: mov    WORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_24d7:
	/* 0x24d7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24d9:
	/* 0x24d9: movzx  r12d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_24dd:
	/* 0x24dd: add    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_24e2:
	/* 0x24e2: jns    2502 <generic_fexit_event+0x2502> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24e2, 0x2502, x86_l_2502);
x86_l_24e4:
	/* 0x24e4: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_24e7:
	/* 0x24e7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24ea:
	/* 0x24ea: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_24f0:
	/* 0x24f0: jns    4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f0, 0x4295, x86_l_4295);
x86_l_24f6:
	/* 0x24f6: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_24f9:
	/* 0x24f9: mov    BYTE PTR [rsp+0xc0],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2500:
	/* 0x2500: jmp    251f <generic_fexit_event+0x251f> */
	X86_SIM_X86_JMP(0x2500, 0x251f, x86_l_251f);
x86_l_2502:
	/* 0x2502: lea    rdi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_250a:
	/* 0x250a: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_250f:
	/* 0x250f: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2512:
	/* 0x2512: call   2517 <generic_fexit_event+0x2517> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2517:
	/* 0x2517: movzx  eax,BYTE PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 192ULL);
x86_l_251f:
	/* 0x251f: shr    al,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_SHR, 4ULL);
x86_l_2522:
	/* 0x2522: cmp    al,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_2524:
	/* 0x2524: je     255d <generic_fexit_event+0x255d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2524, 0x255d, x86_l_255d);
x86_l_2526:
	/* 0x2526: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2529:
	/* 0x2529: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_252c:
	/* 0x252c: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2532:
	/* 0x2532: jne    4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2532, 0x4295, x86_l_4295);
x86_l_2538:
	/* 0x2538: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_253b:
	/* 0x253b: add    rdx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 9ULL);
x86_l_253f:
	/* 0x253f: jns    325b <generic_fexit_event+0x325b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x253f, 0x325b, x86_l_325b);
x86_l_2545:
	/* 0x2545: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2548:
	/* 0x2548: jns    3a36 <generic_fexit_event+0x3a36> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2548, 0x3a36, x86_l_3a36);
x86_l_254e:
	/* 0x254e: movzx  eax,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2551:
	/* 0x2551: mov    BYTE PTR [rsp+0x80],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2558:
	/* 0x2558: jmp    3a40 <generic_fexit_event+0x3a40> */
	X86_SIM_X86_JMP(0x2558, 0x3a40, x86_l_3a40);
x86_l_255d:
	/* 0x255d: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2562:
	/* 0x2562: movzx  r15d,WORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 160ULL);
x86_l_256b:
	/* 0x256b: lea    rax,[r14+r15*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_256f:
	/* 0x256f: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2577:
	/* 0x2577: mov    DWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_2582:
	/* 0x2582: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_ipv6_ext_heap));
x86_l_2589:
	/* 0x2589: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2591:
	/* 0x2591: call   2596 <generic_fexit_event+0x2596> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2596:
	/* 0x2596: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2599:
	/* 0x2599: je     4059 <generic_fexit_event+0x4059> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2599, 0x4059, x86_l_4059);
x86_l_259f:
	/* 0x259f: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25a2:
	/* 0x25a2: mov    WORD PTR [rax],r15w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25a6:
	/* 0x25a6: mov    BYTE PTR [rax+0x5],0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 21474836735ULL);
x86_l_25aa:
	/* 0x25aa: mov    BYTE PTR [rax+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_25ae:
	/* 0x25ae: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b1:
	/* 0x25b1: add    rbp,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_25b5:
	/* 0x25b5: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_25bd:
	/* 0x25bd: add    rdx,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_25c1:
	/* 0x25c1: jns    3887 <generic_fexit_event+0x3887> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25c1, 0x3887, x86_l_3887);
x86_l_25c7:
	/* 0x25c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25ca:
	/* 0x25ca: jns    3e81 <generic_fexit_event+0x3e81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ca, 0x3e81, x86_l_3e81);
x86_l_25d0:
	/* 0x25d0: movzx  eax,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_25d3:
	/* 0x25d3: mov    BYTE PTR [rbp+0x0],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25d6:
	/* 0x25d6: jmp    389d <generic_fexit_event+0x389d> */
	X86_SIM_X86_JMP(0x25d6, 0x389d, x86_l_389d);
x86_l_25db:
	/* 0x25db: mov    BYTE PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_25df:
	/* 0x25df: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_25e7:
	/* 0x25e7: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ee:
	/* 0x25ee: mov    r12,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_25f5:
	/* 0x25f5: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x25f5, 0x42c7, x86_l_42c7);
x86_l_25fa:
	/* 0x25fa: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ff:
	/* 0x25ff: lea    rdi,[rcx+0xd6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 214ULL);
x86_l_2606:
	/* 0x2606: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2609:
	/* 0x2609: add    rdx,0x12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18ULL);
x86_l_260d:
	/* 0x260d: jns    261b <generic_fexit_event+0x261b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x260d, 0x261b, x86_l_261b);
x86_l_260f:
	/* 0x260f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2612:
	/* 0x2612: jns    262c <generic_fexit_event+0x262c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2612, 0x262c, x86_l_262c);
x86_l_2614:
	/* 0x2614: movzx  eax,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2617:
	/* 0x2617: mov    BYTE PTR [rdi],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2619:
	/* 0x2619: jmp    262f <generic_fexit_event+0x262f> */
	X86_SIM_X86_JMP(0x2619, 0x262f, x86_l_262f);
x86_l_261b:
	/* 0x261b: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2620:
	/* 0x2620: call   2625 <generic_fexit_event+0x2625> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2625:
	/* 0x2625: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_262a:
	/* 0x262a: jmp    262f <generic_fexit_event+0x262f> */
	X86_SIM_X86_JMP(0x262a, 0x262f, x86_l_262f);
x86_l_262c:
	/* 0x262c: mov    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_262f:
	/* 0x262f: lea    rdi,[rcx+0xd4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_2636:
	/* 0x2636: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2639:
	/* 0x2639: add    rdx,0x21e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 542ULL);
x86_l_2640:
	/* 0x2640: jns    264f <generic_fexit_event+0x264f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2640, 0x264f, x86_l_264f);
x86_l_2642:
	/* 0x2642: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2645:
	/* 0x2645: jns    2660 <generic_fexit_event+0x2660> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2645, 0x2660, x86_l_2660);
x86_l_2647:
	/* 0x2647: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_264a:
	/* 0x264a: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264d:
	/* 0x264d: jmp    2665 <generic_fexit_event+0x2665> */
	X86_SIM_X86_JMP(0x264d, 0x2665, x86_l_2665);
x86_l_264f:
	/* 0x264f: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2654:
	/* 0x2654: call   2659 <generic_fexit_event+0x2659> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2659:
	/* 0x2659: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_265e:
	/* 0x265e: jmp    2665 <generic_fexit_event+0x2665> */
	X86_SIM_X86_JMP(0x265e, 0x2665, x86_l_2665);
x86_l_2660:
	/* 0x2660: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2665:
	/* 0x2665: lea    rdi,[rcx+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_266c:
	/* 0x266c: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_266f:
	/* 0x266f: add    rdx,0x21c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 540ULL);
x86_l_2676:
	/* 0x2676: jns    2685 <generic_fexit_event+0x2685> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2676, 0x2685, x86_l_2685);
x86_l_2678:
	/* 0x2678: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_267b:
	/* 0x267b: jns    2696 <generic_fexit_event+0x2696> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x267b, 0x2696, x86_l_2696);
x86_l_267d:
	/* 0x267d: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2680:
	/* 0x2680: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2683:
	/* 0x2683: jmp    269b <generic_fexit_event+0x269b> */
	X86_SIM_X86_JMP(0x2683, 0x269b, x86_l_269b);
x86_l_2685:
	/* 0x2685: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_268a:
	/* 0x268a: call   268f <generic_fexit_event+0x268f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_268f:
	/* 0x268f: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2694:
	/* 0x2694: jmp    269b <generic_fexit_event+0x269b> */
	X86_SIM_X86_JMP(0x2694, 0x269b, x86_l_269b);
x86_l_2696:
	/* 0x2696: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_269b:
	/* 0x269b: lea    rdi,[rcx+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_26a2:
	/* 0x26a2: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_26a5:
	/* 0x26a5: add    rdx,0x214 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 532ULL);
x86_l_26ac:
	/* 0x26ac: jns    26b9 <generic_fexit_event+0x26b9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26ac, 0x26b9, x86_l_26b9);
x86_l_26ae:
	/* 0x26ae: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26b1:
	/* 0x26b1: jns    26ca <generic_fexit_event+0x26ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26b1, 0x26ca, x86_l_26ca);
x86_l_26b3:
	/* 0x26b3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b5:
	/* 0x26b5: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b7:
	/* 0x26b7: jmp    26d0 <generic_fexit_event+0x26d0> */
	X86_SIM_X86_JMP(0x26b7, 0x26d0, x86_l_26d0);
x86_l_26b9:
	/* 0x26b9: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_26be:
	/* 0x26be: call   26c3 <generic_fexit_event+0x26c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_26c3:
	/* 0x26c3: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26c8:
	/* 0x26c8: jmp    26d0 <generic_fexit_event+0x26d0> */
	X86_SIM_X86_JMP(0x26c8, 0x26d0, x86_l_26d0);
x86_l_26ca:
	/* 0x26ca: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26d0:
	/* 0x26d0: lea    rdi,[rcx+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_26d7:
	/* 0x26d7: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_26da:
	/* 0x26da: add    rdx,0x210 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 528ULL);
x86_l_26e1:
	/* 0x26e1: jns    26ee <generic_fexit_event+0x26ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26e1, 0x26ee, x86_l_26ee);
x86_l_26e3:
	/* 0x26e3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26e6:
	/* 0x26e6: jns    26ff <generic_fexit_event+0x26ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26e6, 0x26ff, x86_l_26ff);
x86_l_26e8:
	/* 0x26e8: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ea:
	/* 0x26ea: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ec:
	/* 0x26ec: jmp    2705 <generic_fexit_event+0x2705> */
	X86_SIM_X86_JMP(0x26ec, 0x2705, x86_l_2705);
x86_l_26ee:
	/* 0x26ee: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_26f3:
	/* 0x26f3: call   26f8 <generic_fexit_event+0x26f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_26f8:
	/* 0x26f8: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26fd:
	/* 0x26fd: jmp    2705 <generic_fexit_event+0x2705> */
	X86_SIM_X86_JMP(0x26fd, 0x2705, x86_l_2705);
x86_l_26ff:
	/* 0x26ff: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2705:
	/* 0x2705: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_270a:
	/* 0x270a: lea    r13,[rcx+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2711:
	/* 0x2711: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2719:
	/* 0x2719: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2721:
	/* 0x2721: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2729:
	/* 0x2729: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2730:
	/* 0x2730: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2735:
	/* 0x2735: movzx  eax,WORD PTR [rax+0xc2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 194ULL);
x86_l_273c:
	/* 0x273c: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_273f:
	/* 0x273f: je     276e <generic_fexit_event+0x276e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x273f, 0x276e, x86_l_276e);
x86_l_2741:
	/* 0x2741: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2744:
	/* 0x2744: jne    37bb <generic_fexit_event+0x37bb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2744, 0x37bb, x86_l_37bb);
x86_l_274a:
	/* 0x274a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_274d:
	/* 0x274d: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2751:
	/* 0x2751: jns    2fef <generic_fexit_event+0x2fef> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2751, 0x2fef, x86_l_2fef);
x86_l_2757:
	/* 0x2757: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_275a:
	/* 0x275a: jns    3736 <generic_fexit_event+0x3736> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x275a, 0x3736, x86_l_3736);
x86_l_2760:
	/* 0x2760: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2762:
	/* 0x2762: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2767:
	/* 0x2767: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2769:
	/* 0x2769: jmp    3741 <generic_fexit_event+0x3741> */
	X86_SIM_X86_JMP(0x2769, 0x3741, x86_l_3741);
x86_l_276e:
	/* 0x276e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2771:
	/* 0x2771: add    rdx,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_2775:
	/* 0x2775: jns    3003 <generic_fexit_event+0x3003> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2775, 0x3003, x86_l_3003);
x86_l_277b:
	/* 0x277b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_277e:
	/* 0x277e: jns    3767 <generic_fexit_event+0x3767> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x277e, 0x3767, x86_l_3767);
x86_l_2784:
	/* 0x2784: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2787:
	/* 0x2787: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_278c:
	/* 0x278c: mov    QWORD PTR [rcx+0x9c],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_2793:
	/* 0x2793: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2797:
	/* 0x2797: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_279e:
	/* 0x279e: jmp    377b <generic_fexit_event+0x377b> */
	X86_SIM_X86_JMP(0x279e, 0x377b, x86_l_377b);
x86_l_27a3:
	/* 0x27a3: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_27a5:
	/* 0x27a5: jmp    28ea <generic_fexit_event+0x28ea> */
	X86_SIM_X86_JMP(0x27a5, 0x28ea, x86_l_28ea);
x86_l_27aa:
	/* 0x27aa: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_27b3:
	/* 0x27b3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b5:
	/* 0x27b5: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_27ba:
	/* 0x27ba: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_27bf:
	/* 0x27bf: call   27c4 <generic_fexit_event+0x27c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_27c4:
	/* 0x27c4: jmp    2878 <generic_fexit_event+0x2878> */
	X86_SIM_X86_JMP(0x27c4, 0x2878, x86_l_2878);
x86_l_27c9:
	/* 0x27c9: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27ce:
	/* 0x27ce: lea    rdi,[rax+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_27d5:
	/* 0x27d5: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_27d8:
	/* 0x27d8: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_27dc:
	/* 0x27dc: jns    3504 <generic_fexit_event+0x3504> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27dc, 0x3504, x86_l_3504);
x86_l_27e2:
	/* 0x27e2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27e5:
	/* 0x27e5: jns    3d5e <generic_fexit_event+0x3d5e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27e5, 0x3d5e, x86_l_3d5e);
x86_l_27eb:
	/* 0x27eb: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ee:
	/* 0x27ee: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27f3:
	/* 0x27f3: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_27fa:
	/* 0x27fa: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27fe:
	/* 0x27fe: mov    QWORD PTR [rcx+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2805:
	/* 0x2805: jmp    3d6d <generic_fexit_event+0x3d6d> */
	X86_SIM_X86_JMP(0x2805, 0x3d6d, x86_l_3d6d);
x86_l_280a:
	/* 0x280a: mov    BYTE PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_2812:
	/* 0x2812: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2815:
	/* 0x2815: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2819:
	/* 0x2819: jns    2834 <generic_fexit_event+0x2834> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2819, 0x2834, x86_l_2834);
x86_l_281b:
	/* 0x281b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_281e:
	/* 0x281e: jns    334c <generic_fexit_event+0x334c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x281e, 0x334c, x86_l_334c);
x86_l_2824:
	/* 0x2824: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2827:
	/* 0x2827: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_282f:
	/* 0x282f: jmp    3358 <generic_fexit_event+0x3358> */
	X86_SIM_X86_JMP(0x282f, 0x3358, x86_l_3358);
x86_l_2834:
	/* 0x2834: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_283c:
	/* 0x283c: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2841:
	/* 0x2841: call   2846 <generic_fexit_event+0x2846> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2846:
	/* 0x2846: jmp    3358 <generic_fexit_event+0x3358> */
	X86_SIM_X86_JMP(0x2846, 0x3358, x86_l_3358);
x86_l_284b:
	/* 0x284b: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2850:
	/* 0x2850: mov    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2855:
	/* 0x2855: jmp    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JMP(0x2855, 0x42bb, x86_l_42bb);
x86_l_285a:
	/* 0x285a: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_285f:
	/* 0x285f: mov    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2864:
	/* 0x2864: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_286a:
	/* 0x286a: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x286a, 0x42c7, x86_l_42c7);
x86_l_286f:
	/* 0x286f: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2878:
	/* 0x2878: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_287e:
	/* 0x287e: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2883:
	/* 0x2883: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2888:
	/* 0x2888: add    rcx,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_288f:
	/* 0x288f: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2892:
	/* 0x2892: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2895:
	/* 0x2895: js     28c2 <generic_fexit_event+0x28c2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2895, 0x28c2, x86_l_28c2);
x86_l_2897:
	/* 0x2897: mov    esi,0x1001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4097ULL);
x86_l_289c:
	/* 0x289c: call   28a1 <generic_fexit_event+0x28a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_28a1:
	/* 0x28a1: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a7:
	/* 0x28a7: js     42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28a7, 0x42c7, x86_l_42c7);
x86_l_28ad:
	/* 0x28ad: lea    eax,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_28b2:
	/* 0x28b2: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28b7:
	/* 0x28b7: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b9:
	/* 0x28b9: add    r12,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3ULL);
x86_l_28bd:
	/* 0x28bd: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x28bd, 0x42c7, x86_l_42c7);
x86_l_28c2:
	/* 0x28c2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28c5:
	/* 0x28c5: jns    28e5 <generic_fexit_event+0x28e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c5, 0x28e5, x86_l_28e5);
x86_l_28c7:
	/* 0x28c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c9:
	/* 0x28c9: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_28cf:
	/* 0x28cf: je     28fd <generic_fexit_event+0x28fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28cf, 0x28fd, x86_l_28fd);
x86_l_28d1:
	/* 0x28d1: lea    r12,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_28d5:
	/* 0x28d5: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_28d9:
	/* 0x28d9: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_28dc:
	/* 0x28dc: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_28df:
	/* 0x28df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_28e1:
	/* 0x28e1: jne    28c9 <generic_fexit_event+0x28c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x28e1, 0x28c9, x86_l_28c9);
x86_l_28e3:
	/* 0x28e3: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x28e3, 0x28ad, x86_l_28ad);
x86_l_28e5:
	/* 0x28e5: mov    edx,0x1001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4097ULL);
x86_l_28ea:
	/* 0x28ea: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ec:
	/* 0x28ec: call   28f1 <generic_fexit_event+0x28f1> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4097ULL);
x86_l_28f1:
	/* 0x28f1: mov    r12,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_28f8:
	/* 0x28f8: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x28f8, 0x42c7, x86_l_42c7);
x86_l_28fd:
	/* 0x28fd: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2902:
	/* 0x2902: mov    BYTE PTR [rax+0x10a0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18279380811776ULL);
x86_l_2909:
	/* 0x2909: mov    r12d,0x1001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4097ULL);
x86_l_290f:
	/* 0x290f: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x290f, 0x28ad, x86_l_28ad);
x86_l_2911:
	/* 0x2911: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_291d:
	/* 0x291d: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2920:
	/* 0x2920: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2923:
	/* 0x2923: cmp    r14,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_292a:
	/* 0x292a: jb     2932 <generic_fexit_event+0x2932> */
	X86_SIM_X86_JCC(X86_CC_B, 0x292a, 0x2932, x86_l_2932);
x86_l_292c:
	/* 0x292c: mov    r12d,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_2932:
	/* 0x2932: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2937:
	/* 0x2937: add    rdi,0xa4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 164ULL);
x86_l_293e:
	/* 0x293e: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2941:
	/* 0x2941: js     2957 <generic_fexit_event+0x2957> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2941, 0x2957, x86_l_2957);
x86_l_2943:
	/* 0x2943: mov    esi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2946:
	/* 0x2946: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2949:
	/* 0x2949: call   294e <generic_fexit_event+0x294e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_294e:
	/* 0x294e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2950:
	/* 0x2950: jns    29aa <generic_fexit_event+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2950, 0x29aa, x86_l_29aa);
x86_l_2952:
	/* 0x2952: jmp    3127 <generic_fexit_event+0x3127> */
	X86_SIM_X86_JMP(0x2952, 0x3127, x86_l_3127);
x86_l_2957:
	/* 0x2957: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_295a:
	/* 0x295a: jns    311d <generic_fexit_event+0x311d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x295a, 0x311d, x86_l_311d);
x86_l_2960:
	/* 0x2960: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2962:
	/* 0x2962: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2966:
	/* 0x2966: jb     2986 <generic_fexit_event+0x2986> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2966, 0x2986, x86_l_2986);
x86_l_2968:
	/* 0x2968: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_296a:
	/* 0x296a: mov    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_296d:
	/* 0x296d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2970:
	/* 0x2970: mov    rax,QWORD PTR [rbp+rax*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2975:
	/* 0x2975: mov    QWORD PTR [rdx+rcx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2979:
	/* 0x2979: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_297d:
	/* 0x297d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2981:
	/* 0x2981: cmp    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2984:
	/* 0x2984: jbe    296d <generic_fexit_event+0x296d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2984, 0x296d, x86_l_296d);
x86_l_2986:
	/* 0x2986: test   r12b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_298a:
	/* 0x298a: jne    3995 <generic_fexit_event+0x3995> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x298a, 0x3995, x86_l_3995);
x86_l_2990:
	/* 0x2990: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2994:
	/* 0x2994: jne    39ab <generic_fexit_event+0x39ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2994, 0x39ab, x86_l_39ab);
x86_l_299a:
	/* 0x299a: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_299e:
	/* 0x299e: je     29aa <generic_fexit_event+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x299e, 0x29aa, x86_l_29aa);
x86_l_29a0:
	/* 0x29a0: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_29a2:
	/* 0x29a2: movzx  ecx,BYTE PTR [rbp+rax*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_29a7:
	/* 0x29a7: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_29aa:
	/* 0x29aa: mov    DWORD PTR [r15+0x9c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_29b1:
	/* 0x29b1: mov    DWORD PTR [r15+0xa0],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_29b8:
	/* 0x29b8: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29bc:
	/* 0x29bc: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x29bc, 0x21b7, x86_l_21b7);
x86_l_29c1:
	/* 0x29c1: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29c6:
	/* 0x29c6: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29cc:
	/* 0x29cc: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29d1:
	/* 0x29d1: lea    rdi,[rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_29d8:
	/* 0x29d8: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_29db:
	/* 0x29db: add    rdx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_29df:
	/* 0x29df: jns    29ec <generic_fexit_event+0x29ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29df, 0x29ec, x86_l_29ec);
x86_l_29e1:
	/* 0x29e1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29e4:
	/* 0x29e4: jns    29f8 <generic_fexit_event+0x29f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29e4, 0x29f8, x86_l_29f8);
x86_l_29e6:
	/* 0x29e6: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29e8:
	/* 0x29e8: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ea:
	/* 0x29ea: jmp    29fe <generic_fexit_event+0x29fe> */
	X86_SIM_X86_JMP(0x29ea, 0x29fe, x86_l_29fe);
x86_l_29ec:
	/* 0x29ec: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_29f1:
	/* 0x29f1: call   29f6 <generic_fexit_event+0x29f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_29f6:
	/* 0x29f6: jmp    29fe <generic_fexit_event+0x29fe> */
	X86_SIM_X86_JMP(0x29f6, 0x29fe, x86_l_29fe);
x86_l_29f8:
	/* 0x29f8: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29fe:
	/* 0x29fe: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a03:
	/* 0x2a03: lea    rdi,[rax+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2a0a:
	/* 0x2a0a: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a0d:
	/* 0x2a0d: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2a11:
	/* 0x2a11: jns    2a1e <generic_fexit_event+0x2a1e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a11, 0x2a1e, x86_l_2a1e);
x86_l_2a13:
	/* 0x2a13: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a16:
	/* 0x2a16: jns    2a2a <generic_fexit_event+0x2a2a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a16, 0x2a2a, x86_l_2a2a);
x86_l_2a18:
	/* 0x2a18: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a1a:
	/* 0x2a1a: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a1c:
	/* 0x2a1c: jmp    2a30 <generic_fexit_event+0x2a30> */
	X86_SIM_X86_JMP(0x2a1c, 0x2a30, x86_l_2a30);
x86_l_2a1e:
	/* 0x2a1e: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2a23:
	/* 0x2a23: call   2a28 <generic_fexit_event+0x2a28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a28:
	/* 0x2a28: jmp    2a30 <generic_fexit_event+0x2a30> */
	X86_SIM_X86_JMP(0x2a28, 0x2a30, x86_l_2a30);
x86_l_2a2a:
	/* 0x2a2a: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a30:
	/* 0x2a30: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a35:
	/* 0x2a35: lea    rdi,[rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2a3c:
	/* 0x2a3c: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a3f:
	/* 0x2a3f: add    rdx,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
x86_l_2a43:
	/* 0x2a43: jns    2a50 <generic_fexit_event+0x2a50> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a43, 0x2a50, x86_l_2a50);
x86_l_2a45:
	/* 0x2a45: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a48:
	/* 0x2a48: jns    2a5c <generic_fexit_event+0x2a5c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a48, 0x2a5c, x86_l_2a5c);
x86_l_2a4a:
	/* 0x2a4a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a4c:
	/* 0x2a4c: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a4e:
	/* 0x2a4e: jmp    2a62 <generic_fexit_event+0x2a62> */
	X86_SIM_X86_JMP(0x2a4e, 0x2a62, x86_l_2a62);
x86_l_2a50:
	/* 0x2a50: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2a55:
	/* 0x2a55: call   2a5a <generic_fexit_event+0x2a5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a5a:
	/* 0x2a5a: jmp    2a62 <generic_fexit_event+0x2a62> */
	X86_SIM_X86_JMP(0x2a5a, 0x2a62, x86_l_2a62);
x86_l_2a5c:
	/* 0x2a5c: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a62:
	/* 0x2a62: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a67:
	/* 0x2a67: lea    rdi,[rax+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a71:
	/* 0x2a71: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2a75:
	/* 0x2a75: jns    2a82 <generic_fexit_event+0x2a82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a75, 0x2a82, x86_l_2a82);
x86_l_2a77:
	/* 0x2a77: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a7a:
	/* 0x2a7a: jns    2a8e <generic_fexit_event+0x2a8e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a7a, 0x2a8e, x86_l_2a8e);
x86_l_2a7c:
	/* 0x2a7c: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a7e:
	/* 0x2a7e: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a80:
	/* 0x2a80: jmp    2a94 <generic_fexit_event+0x2a94> */
	X86_SIM_X86_JMP(0x2a80, 0x2a94, x86_l_2a94);
x86_l_2a82:
	/* 0x2a82: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2a87:
	/* 0x2a87: call   2a8c <generic_fexit_event+0x2a8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a8c:
	/* 0x2a8c: jmp    2a94 <generic_fexit_event+0x2a94> */
	X86_SIM_X86_JMP(0x2a8c, 0x2a94, x86_l_2a94);
x86_l_2a8e:
	/* 0x2a8e: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a94:
	/* 0x2a94: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a99:
	/* 0x2a99: lea    rdi,[rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2aa0:
	/* 0x2aa0: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2aa3:
	/* 0x2aa3: add    rdx,0x14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
x86_l_2aa7:
	/* 0x2aa7: jns    2ab4 <generic_fexit_event+0x2ab4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aa7, 0x2ab4, x86_l_2ab4);
x86_l_2aa9:
	/* 0x2aa9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2aac:
	/* 0x2aac: jns    2ac0 <generic_fexit_event+0x2ac0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aac, 0x2ac0, x86_l_2ac0);
x86_l_2aae:
	/* 0x2aae: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab0:
	/* 0x2ab0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab2:
	/* 0x2ab2: jmp    2ac6 <generic_fexit_event+0x2ac6> */
	X86_SIM_X86_JMP(0x2ab2, 0x2ac6, x86_l_2ac6);
x86_l_2ab4:
	/* 0x2ab4: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2ab9:
	/* 0x2ab9: call   2abe <generic_fexit_event+0x2abe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2abe:
	/* 0x2abe: jmp    2ac6 <generic_fexit_event+0x2ac6> */
	X86_SIM_X86_JMP(0x2abe, 0x2ac6, x86_l_2ac6);
x86_l_2ac0:
	/* 0x2ac0: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ac6:
	/* 0x2ac6: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2acb:
	/* 0x2acb: lea    rdi,[rax+0xb4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_2ad2:
	/* 0x2ad2: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2ad5:
	/* 0x2ad5: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2ad9:
	/* 0x2ad9: jns    2ae6 <generic_fexit_event+0x2ae6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad9, 0x2ae6, x86_l_2ae6);
x86_l_2adb:
	/* 0x2adb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ade:
	/* 0x2ade: jns    2af2 <generic_fexit_event+0x2af2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ade, 0x2af2, x86_l_2af2);
x86_l_2ae0:
	/* 0x2ae0: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae2:
	/* 0x2ae2: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae4:
	/* 0x2ae4: jmp    2af8 <generic_fexit_event+0x2af8> */
	X86_SIM_X86_JMP(0x2ae4, 0x2af8, x86_l_2af8);
x86_l_2ae6:
	/* 0x2ae6: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2aeb:
	/* 0x2aeb: call   2af0 <generic_fexit_event+0x2af0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2af0:
	/* 0x2af0: jmp    2af8 <generic_fexit_event+0x2af8> */
	X86_SIM_X86_JMP(0x2af0, 0x2af8, x86_l_2af8);
x86_l_2af2:
	/* 0x2af2: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2af8:
	/* 0x2af8: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2afd:
	/* 0x2afd: lea    rdi,[rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2b04:
	/* 0x2b04: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2b07:
	/* 0x2b07: add    rdx,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_2b0b:
	/* 0x2b0b: jns    2b18 <generic_fexit_event+0x2b18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b0b, 0x2b18, x86_l_2b18);
x86_l_2b0d:
	/* 0x2b0d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b10:
	/* 0x2b10: jns    2b24 <generic_fexit_event+0x2b24> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b10, 0x2b24, x86_l_2b24);
x86_l_2b12:
	/* 0x2b12: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b14:
	/* 0x2b14: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b16:
	/* 0x2b16: jmp    2b2a <generic_fexit_event+0x2b2a> */
	X86_SIM_X86_JMP(0x2b16, 0x2b2a, x86_l_2b2a);
x86_l_2b18:
	/* 0x2b18: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2b1d:
	/* 0x2b1d: call   2b22 <generic_fexit_event+0x2b22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b22:
	/* 0x2b22: jmp    2b2a <generic_fexit_event+0x2b2a> */
	X86_SIM_X86_JMP(0x2b22, 0x2b2a, x86_l_2b2a);
x86_l_2b24:
	/* 0x2b24: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b2a:
	/* 0x2b2a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b2f:
	/* 0x2b2f: mov    DWORD PTR [rax+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_2b39:
	/* 0x2b39: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b3e:
	/* 0x2b3e: lea    rdi,[rax+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_2b45:
	/* 0x2b45: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2b48:
	/* 0x2b48: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2b4c:
	/* 0x2b4c: jns    2b59 <generic_fexit_event+0x2b59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b4c, 0x2b59, x86_l_2b59);
x86_l_2b4e:
	/* 0x2b4e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b51:
	/* 0x2b51: jns    2b65 <generic_fexit_event+0x2b65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b51, 0x2b65, x86_l_2b65);
x86_l_2b53:
	/* 0x2b53: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b55:
	/* 0x2b55: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b57:
	/* 0x2b57: jmp    2b6b <generic_fexit_event+0x2b6b> */
	X86_SIM_X86_JMP(0x2b57, 0x2b6b, x86_l_2b6b);
x86_l_2b59:
	/* 0x2b59: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2b5e:
	/* 0x2b5e: call   2b63 <generic_fexit_event+0x2b63> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b63:
	/* 0x2b63: jmp    2b6b <generic_fexit_event+0x2b6b> */
	X86_SIM_X86_JMP(0x2b63, 0x2b6b, x86_l_2b6b);
x86_l_2b65:
	/* 0x2b65: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b6b:
	/* 0x2b6b: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2b6e:
	/* 0x2b6e: je     2b91 <generic_fexit_event+0x2b91> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b6e, 0x2b91, x86_l_2b91);
x86_l_2b70:
	/* 0x2b70: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b74:
	/* 0x2b74: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b79:
	/* 0x2b79: mov    QWORD PTR [rcx+0xcc],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_2b80:
	/* 0x2b80: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b84:
	/* 0x2b84: mov    QWORD PTR [rcx+0xd4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_2b8b:
	/* 0x2b8b: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b8f:
	/* 0x2b8f: jmp    2bae <generic_fexit_event+0x2bae> */
	X86_SIM_X86_JMP(0x2b8f, 0x2bae, x86_l_2bae);
x86_l_2b91:
	/* 0x2b91: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b96:
	/* 0x2b96: mov    QWORD PTR [rcx+0xd4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 910533066752ULL);
x86_l_2ba1:
	/* 0x2ba1: mov    QWORD PTR [rcx+0xcc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 876173328384ULL);
x86_l_2bac:
	/* 0x2bac: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bae:
	/* 0x2bae: mov    QWORD PTR [rcx+0xc4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_2bb5:
	/* 0x2bb5: add    rbp,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_2bbc:
	/* 0x2bbc: jns    2bce <generic_fexit_event+0x2bce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bbc, 0x2bce, x86_l_2bce);
x86_l_2bbe:
	/* 0x2bbe: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2bc1:
	/* 0x2bc1: jns    2be7 <generic_fexit_event+0x2be7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bc1, 0x2be7, x86_l_2be7);
x86_l_2bc3:
	/* 0x2bc3: mov    r12,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bc7:
	/* 0x2bc7: mov    QWORD PTR [rsp+0x40],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2bcc:
	/* 0x2bcc: jmp    2bf3 <generic_fexit_event+0x2bf3> */
	X86_SIM_X86_JMP(0x2bcc, 0x2bf3, x86_l_2bf3);
x86_l_2bce:
	/* 0x2bce: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2bd3:
	/* 0x2bd3: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2bd8:
	/* 0x2bd8: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2bdb:
	/* 0x2bdb: call   2be0 <generic_fexit_event+0x2be0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2be0:
	/* 0x2be0: mov    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2be5:
	/* 0x2be5: jmp    2bf3 <generic_fexit_event+0x2bf3> */
	X86_SIM_X86_JMP(0x2be5, 0x2bf3, x86_l_2bf3);
x86_l_2be7:
	/* 0x2be7: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2bf0:
	/* 0x2bf0: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bf3:
	/* 0x2bf3: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bf8:
	/* 0x2bf8: lea    rdi,[rax+0xdc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_2bff:
	/* 0x2bff: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c02:
	/* 0x2c02: add    rdx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
x86_l_2c09:
	/* 0x2c09: jns    2c16 <generic_fexit_event+0x2c16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c09, 0x2c16, x86_l_2c16);
x86_l_2c0b:
	/* 0x2c0b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c0e:
	/* 0x2c0e: jns    2c22 <generic_fexit_event+0x2c22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c0e, 0x2c22, x86_l_2c22);
x86_l_2c10:
	/* 0x2c10: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c12:
	/* 0x2c12: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c14:
	/* 0x2c14: jmp    2c28 <generic_fexit_event+0x2c28> */
	X86_SIM_X86_JMP(0x2c14, 0x2c28, x86_l_2c28);
x86_l_2c16:
	/* 0x2c16: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2c1b:
	/* 0x2c1b: call   2c20 <generic_fexit_event+0x2c20> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c20:
	/* 0x2c20: jmp    2c28 <generic_fexit_event+0x2c28> */
	X86_SIM_X86_JMP(0x2c20, 0x2c28, x86_l_2c28);
x86_l_2c22:
	/* 0x2c22: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c28:
	/* 0x2c28: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c2d:
	/* 0x2c2d: lea    rdi,[rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2c34:
	/* 0x2c34: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c37:
	/* 0x2c37: add    rdx,0xcc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 204ULL);
x86_l_2c3e:
	/* 0x2c3e: jns    2c4b <generic_fexit_event+0x2c4b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c3e, 0x2c4b, x86_l_2c4b);
x86_l_2c40:
	/* 0x2c40: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c43:
	/* 0x2c43: jns    2c57 <generic_fexit_event+0x2c57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c43, 0x2c57, x86_l_2c57);
x86_l_2c45:
	/* 0x2c45: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c47:
	/* 0x2c47: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c49:
	/* 0x2c49: jmp    2c5d <generic_fexit_event+0x2c5d> */
	X86_SIM_X86_JMP(0x2c49, 0x2c5d, x86_l_2c5d);
x86_l_2c4b:
	/* 0x2c4b: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2c50:
	/* 0x2c50: call   2c55 <generic_fexit_event+0x2c55> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c55:
	/* 0x2c55: jmp    2c5d <generic_fexit_event+0x2c5d> */
	X86_SIM_X86_JMP(0x2c55, 0x2c5d, x86_l_2c5d);
x86_l_2c57:
	/* 0x2c57: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c5d:
	/* 0x2c5d: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c62:
	/* 0x2c62: lea    rdi,[rax+0xe4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 228ULL);
x86_l_2c69:
	/* 0x2c69: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c6c:
	/* 0x2c6c: add    rdx,0xd0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 208ULL);
x86_l_2c73:
	/* 0x2c73: jns    2c80 <generic_fexit_event+0x2c80> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c73, 0x2c80, x86_l_2c80);
x86_l_2c75:
	/* 0x2c75: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c78:
	/* 0x2c78: jns    2c8c <generic_fexit_event+0x2c8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c78, 0x2c8c, x86_l_2c8c);
x86_l_2c7a:
	/* 0x2c7a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c7c:
	/* 0x2c7c: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c7e:
	/* 0x2c7e: jmp    2c92 <generic_fexit_event+0x2c92> */
	X86_SIM_X86_JMP(0x2c7e, 0x2c92, x86_l_2c92);
x86_l_2c80:
	/* 0x2c80: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2c85:
	/* 0x2c85: call   2c8a <generic_fexit_event+0x2c8a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c8a:
	/* 0x2c8a: jmp    2c92 <generic_fexit_event+0x2c92> */
	X86_SIM_X86_JMP(0x2c8a, 0x2c92, x86_l_2c92);
x86_l_2c8c:
	/* 0x2c8c: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c92:
	/* 0x2c92: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c97:
	/* 0x2c97: add    rdi,0xe8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 232ULL);
x86_l_2c9e:
	/* 0x2c9e: add    r12,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_2ca5:
	/* 0x2ca5: jns    2cbd <generic_fexit_event+0x2cbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ca5, 0x2cbd, x86_l_2cbd);
x86_l_2ca7:
	/* 0x2ca7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2caa:
	/* 0x2caa: jns    2cd5 <generic_fexit_event+0x2cd5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2caa, 0x2cd5, x86_l_2cd5);
x86_l_2cac:
	/* 0x2cac: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cb0:
	/* 0x2cb0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cb2:
	/* 0x2cb2: mov    r12d,0x50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_2cb8:
	/* 0x2cb8: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2cb8, 0x21b7, x86_l_21b7);
x86_l_2cbd:
	/* 0x2cbd: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2cc2:
	/* 0x2cc2: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2cc5:
	/* 0x2cc5: call   2cca <generic_fexit_event+0x2cca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2cca:
	/* 0x2cca: mov    r12d,0x50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_2cd0:
	/* 0x2cd0: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2cd0, 0x21b7, x86_l_21b7);
x86_l_2cd5:
	/* 0x2cd5: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cdb:
	/* 0x2cdb: mov    r12d,0x50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_2ce1:
	/* 0x2ce1: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2ce1, 0x21b7, x86_l_21b7);
x86_l_2ce6:
	/* 0x2ce6: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ceb:
	/* 0x2ceb: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cf1:
	/* 0x2cf1: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2cf6:
	/* 0x2cf6: lea    rdi,[rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2cfd:
	/* 0x2cfd: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d00:
	/* 0x2d00: add    rdx,0xcc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 204ULL);
x86_l_2d07:
	/* 0x2d07: jns    2d14 <generic_fexit_event+0x2d14> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d07, 0x2d14, x86_l_2d14);
x86_l_2d09:
	/* 0x2d09: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2d0c:
	/* 0x2d0c: jns    2d20 <generic_fexit_event+0x2d20> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d0c, 0x2d20, x86_l_2d20);
x86_l_2d0e:
	/* 0x2d0e: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d10:
	/* 0x2d10: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d12:
	/* 0x2d12: jmp    2d26 <generic_fexit_event+0x2d26> */
	X86_SIM_X86_JMP(0x2d12, 0x2d26, x86_l_2d26);
x86_l_2d14:
	/* 0x2d14: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d19:
	/* 0x2d19: call   2d1e <generic_fexit_event+0x2d1e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2d1e:
	/* 0x2d1e: jmp    2d26 <generic_fexit_event+0x2d26> */
	X86_SIM_X86_JMP(0x2d1e, 0x2d26, x86_l_2d26);
x86_l_2d20:
	/* 0x2d20: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d26:
	/* 0x2d26: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d2b:
	/* 0x2d2b: lea    rdi,[rax+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2d32:
	/* 0x2d32: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d35:
	/* 0x2d35: add    rdx,0xd0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 208ULL);
x86_l_2d3c:
	/* 0x2d3c: jns    2d49 <generic_fexit_event+0x2d49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d3c, 0x2d49, x86_l_2d49);
x86_l_2d3e:
	/* 0x2d3e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2d41:
	/* 0x2d41: jns    2d55 <generic_fexit_event+0x2d55> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d41, 0x2d55, x86_l_2d55);
x86_l_2d43:
	/* 0x2d43: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d45:
	/* 0x2d45: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d47:
	/* 0x2d47: jmp    2d5b <generic_fexit_event+0x2d5b> */
	X86_SIM_X86_JMP(0x2d47, 0x2d5b, x86_l_2d5b);
x86_l_2d49:
	/* 0x2d49: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d4e:
	/* 0x2d4e: call   2d53 <generic_fexit_event+0x2d53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2d53:
	/* 0x2d53: jmp    2d5b <generic_fexit_event+0x2d5b> */
	X86_SIM_X86_JMP(0x2d53, 0x2d5b, x86_l_2d5b);
x86_l_2d55:
	/* 0x2d55: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d5b:
	/* 0x2d5b: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d60:
	/* 0x2d60: add    rdi,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_2d67:
	/* 0x2d67: add    rbp,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_2d6e:
	/* 0x2d6e: jns    2d85 <generic_fexit_event+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d6e, 0x2d85, x86_l_2d85);
x86_l_2d70:
	/* 0x2d70: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d73:
	/* 0x2d73: jns    2d9d <generic_fexit_event+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d73, 0x2d9d, x86_l_2d9d);
x86_l_2d75:
	/* 0x2d75: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d78:
	/* 0x2d78: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d7a:
	/* 0x2d7a: mov    r12d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2d80:
	/* 0x2d80: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2d80, 0x21b7, x86_l_21b7);
x86_l_2d85:
	/* 0x2d85: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d8a:
	/* 0x2d8a: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d8d:
	/* 0x2d8d: call   2d92 <generic_fexit_event+0x2d92> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2d92:
	/* 0x2d92: mov    r12d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2d98:
	/* 0x2d98: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2d98, 0x21b7, x86_l_21b7);
x86_l_2d9d:
	/* 0x2d9d: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da3:
	/* 0x2da3: mov    r12d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2da9:
	/* 0x2da9: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2da9, 0x21b7, x86_l_21b7);
x86_l_2dae:
	/* 0x2dae: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2db3:
	/* 0x2db3: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db9:
	/* 0x2db9: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2dbe:
	/* 0x2dbe: lea    rdi,[rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2dc5:
	/* 0x2dc5: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2dc8:
	/* 0x2dc8: add    rdx,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 60ULL);
x86_l_2dcc:
	/* 0x2dcc: jns    2dd9 <generic_fexit_event+0x2dd9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dcc, 0x2dd9, x86_l_2dd9);
x86_l_2dce:
	/* 0x2dce: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2dd1:
	/* 0x2dd1: jns    2de5 <generic_fexit_event+0x2de5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dd1, 0x2de5, x86_l_2de5);
x86_l_2dd3:
	/* 0x2dd3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dd5:
	/* 0x2dd5: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dd7:
	/* 0x2dd7: jmp    2deb <generic_fexit_event+0x2deb> */
	X86_SIM_X86_JMP(0x2dd7, 0x2deb, x86_l_2deb);
x86_l_2dd9:
	/* 0x2dd9: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2dde:
	/* 0x2dde: call   2de3 <generic_fexit_event+0x2de3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2de3:
	/* 0x2de3: jmp    2deb <generic_fexit_event+0x2deb> */
	X86_SIM_X86_JMP(0x2de3, 0x2deb, x86_l_2deb);
x86_l_2de5:
	/* 0x2de5: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2deb:
	/* 0x2deb: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2df0:
	/* 0x2df0: lea    rdi,[rax+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2df7:
	/* 0x2df7: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2dfa:
	/* 0x2dfa: add    rdx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_2dfe:
	/* 0x2dfe: jns    2e0b <generic_fexit_event+0x2e0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dfe, 0x2e0b, x86_l_2e0b);
x86_l_2e00:
	/* 0x2e00: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e03:
	/* 0x2e03: jns    2e17 <generic_fexit_event+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e03, 0x2e17, x86_l_2e17);
x86_l_2e05:
	/* 0x2e05: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e07:
	/* 0x2e07: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e09:
	/* 0x2e09: jmp    2e1d <generic_fexit_event+0x2e1d> */
	X86_SIM_X86_JMP(0x2e09, 0x2e1d, x86_l_2e1d);
x86_l_2e0b:
	/* 0x2e0b: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e10:
	/* 0x2e10: call   2e15 <generic_fexit_event+0x2e15> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e15:
	/* 0x2e15: jmp    2e1d <generic_fexit_event+0x2e1d> */
	X86_SIM_X86_JMP(0x2e15, 0x2e1d, x86_l_2e1d);
x86_l_2e17:
	/* 0x2e17: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e1d:
	/* 0x2e1d: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e22:
	/* 0x2e22: lea    rdi,[rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2e29:
	/* 0x2e29: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e2c:
	/* 0x2e2c: add    rdx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_2e30:
	/* 0x2e30: jns    2e3d <generic_fexit_event+0x2e3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e30, 0x2e3d, x86_l_2e3d);
x86_l_2e32:
	/* 0x2e32: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e35:
	/* 0x2e35: jns    2e49 <generic_fexit_event+0x2e49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e35, 0x2e49, x86_l_2e49);
x86_l_2e37:
	/* 0x2e37: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e39:
	/* 0x2e39: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e3b:
	/* 0x2e3b: jmp    2e4f <generic_fexit_event+0x2e4f> */
	X86_SIM_X86_JMP(0x2e3b, 0x2e4f, x86_l_2e4f);
x86_l_2e3d:
	/* 0x2e3d: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e42:
	/* 0x2e42: call   2e47 <generic_fexit_event+0x2e47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e47:
	/* 0x2e47: jmp    2e4f <generic_fexit_event+0x2e4f> */
	X86_SIM_X86_JMP(0x2e47, 0x2e4f, x86_l_2e4f);
x86_l_2e49:
	/* 0x2e49: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e4f:
	/* 0x2e4f: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e54:
	/* 0x2e54: add    rdi,0xac */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 172ULL);
x86_l_2e5b:
	/* 0x2e5b: sub    rbp,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_2e5f:
	/* 0x2e5f: jns    2e8c <generic_fexit_event+0x2e8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e5f, 0x2e8c, x86_l_2e8c);
x86_l_2e61:
	/* 0x2e61: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e64:
	/* 0x2e64: jns    2ea4 <generic_fexit_event+0x2ea4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e64, 0x2ea4, x86_l_2ea4);
x86_l_2e66:
	/* 0x2e66: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e6a:
	/* 0x2e6a: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e6f:
	/* 0x2e6f: mov    QWORD PTR [rsi+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2e76:
	/* 0x2e76: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e7a:
	/* 0x2e7a: mov    QWORD PTR [rsi+0xb4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_2e81:
	/* 0x2e81: mov    r12d,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2e87:
	/* 0x2e87: jmp    3553 <generic_fexit_event+0x3553> */
	X86_SIM_X86_JMP(0x2e87, 0x3553, x86_l_3553);
x86_l_2e8c:
	/* 0x2e8c: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2e91:
	/* 0x2e91: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e94:
	/* 0x2e94: call   2e99 <generic_fexit_event+0x2e99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e99:
	/* 0x2e99: mov    r12d,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2e9f:
	/* 0x2e9f: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2e9f, 0x21b7, x86_l_21b7);
x86_l_2ea4:
	/* 0x2ea4: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2eac:
	/* 0x2eac: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb3:
	/* 0x2eb3: mov    r12d,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2eb9:
	/* 0x2eb9: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2eb9, 0x21b7, x86_l_21b7);
x86_l_2ebe:
	/* 0x2ebe: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2ec7:
	/* 0x2ec7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ec9:
	/* 0x2ec9: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ece:
	/* 0x2ece: mov    esi,0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 128ULL);
x86_l_2ed3:
	/* 0x2ed3: call   2ed8 <generic_fexit_event+0x2ed8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2ed8:
	/* 0x2ed8: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2edd:
	/* 0x2edd: lea    rdi,[rax+0x12c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 300ULL);
x86_l_2ee4:
	/* 0x2ee4: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ee7:
	/* 0x2ee7: jns    2ef6 <generic_fexit_event+0x2ef6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee7, 0x2ef6, x86_l_2ef6);
x86_l_2ee9:
	/* 0x2ee9: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2eec:
	/* 0x2eec: jns    2f05 <generic_fexit_event+0x2f05> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eec, 0x2f05, x86_l_2f05);
x86_l_2eee:
	/* 0x2eee: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef2:
	/* 0x2ef2: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef4:
	/* 0x2ef4: jmp    2f0b <generic_fexit_event+0x2f0b> */
	X86_SIM_X86_JMP(0x2ef4, 0x2f0b, x86_l_2f0b);
x86_l_2ef6:
	/* 0x2ef6: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2efb:
	/* 0x2efb: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2efe:
	/* 0x2efe: call   2f03 <generic_fexit_event+0x2f03> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f03:
	/* 0x2f03: jmp    2f0b <generic_fexit_event+0x2f0b> */
	X86_SIM_X86_JMP(0x2f03, 0x2f0b, x86_l_2f0b);
x86_l_2f05:
	/* 0x2f05: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f0b:
	/* 0x2f0b: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f10:
	/* 0x2f10: lea    rdi,[rax+0x11c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 284ULL);
x86_l_2f17:
	/* 0x2f17: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f1a:
	/* 0x2f1a: add    rdx,0xe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 224ULL);
x86_l_2f21:
	/* 0x2f21: jns    2f30 <generic_fexit_event+0x2f30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f21, 0x2f30, x86_l_2f30);
x86_l_2f23:
	/* 0x2f23: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f26:
	/* 0x2f26: jns    2f3c <generic_fexit_event+0x2f3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f26, 0x2f3c, x86_l_2f3c);
x86_l_2f28:
	/* 0x2f28: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2b:
	/* 0x2f2b: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2e:
	/* 0x2f2e: jmp    2f43 <generic_fexit_event+0x2f43> */
	X86_SIM_X86_JMP(0x2f2e, 0x2f43, x86_l_2f43);
x86_l_2f30:
	/* 0x2f30: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f35:
	/* 0x2f35: call   2f3a <generic_fexit_event+0x2f3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f3a:
	/* 0x2f3a: jmp    2f43 <generic_fexit_event+0x2f43> */
	X86_SIM_X86_JMP(0x2f3a, 0x2f43, x86_l_2f43);
x86_l_2f3c:
	/* 0x2f3c: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f43:
	/* 0x2f43: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f48:
	/* 0x2f48: add    rdi,0x124 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 292ULL);
x86_l_2f4f:
	/* 0x2f4f: add    rbp,0x118 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 280ULL);
x86_l_2f56:
	/* 0x2f56: jns    2f6f <generic_fexit_event+0x2f6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f56, 0x2f6f, x86_l_2f6f);
x86_l_2f58:
	/* 0x2f58: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f5b:
	/* 0x2f5b: jns    2f87 <generic_fexit_event+0x2f87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f5b, 0x2f87, x86_l_2f87);
x86_l_2f5d:
	/* 0x2f5d: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f61:
	/* 0x2f61: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f64:
	/* 0x2f64: mov    r12d,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2f6a:
	/* 0x2f6a: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2f6a, 0x21b7, x86_l_21b7);
x86_l_2f6f:
	/* 0x2f6f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f74:
	/* 0x2f74: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2f77:
	/* 0x2f77: call   2f7c <generic_fexit_event+0x2f7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f7c:
	/* 0x2f7c: mov    r12d,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2f82:
	/* 0x2f82: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2f82, 0x21b7, x86_l_21b7);
x86_l_2f87:
	/* 0x2f87: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f8e:
	/* 0x2f8e: mov    r12d,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_2f94:
	/* 0x2f94: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x2f94, 0x21b7, x86_l_21b7);
x86_l_2f99:
	/* 0x2f99: mov    QWORD PTR [rdi+0x37],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236223201280ULL);
x86_l_2fa1:
	/* 0x2fa1: mov    QWORD PTR [rdi+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2fa9:
	/* 0x2fa9: mov    QWORD PTR [rdi+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2fb1:
	/* 0x2fb1: mov    QWORD PTR [rdi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2fb9:
	/* 0x2fb9: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2fc1:
	/* 0x2fc1: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2fc9:
	/* 0x2fc9: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2fd1:
	/* 0x2fd1: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd8:
	/* 0x2fd8: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fdb:
	/* 0x2fdb: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x2fdb, 0x42c7, x86_l_42c7);
x86_l_2fe0:
	/* 0x2fe0: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2fe5:
	/* 0x2fe5: call   2fea <generic_fexit_event+0x2fea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2fea:
	/* 0x2fea: jmp    358d <generic_fexit_event+0x358d> */
	X86_SIM_X86_JMP(0x2fea, 0x358d, x86_l_358d);
x86_l_2fef:
	/* 0x2fef: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ff4:
	/* 0x2ff4: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2ff9:
	/* 0x2ff9: call   2ffe <generic_fexit_event+0x2ffe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ffe:
	/* 0x2ffe: jmp    3741 <generic_fexit_event+0x3741> */
	X86_SIM_X86_JMP(0x2ffe, 0x3741, x86_l_3741);
x86_l_3003:
	/* 0x3003: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3008:
	/* 0x3008: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_300d:
	/* 0x300d: call   3012 <generic_fexit_event+0x3012> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3012:
	/* 0x3012: jmp    377b <generic_fexit_event+0x377b> */
	X86_SIM_X86_JMP(0x3012, 0x377b, x86_l_377b);
x86_l_3017:
	/* 0x3017: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_301c:
	/* 0x301c: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3022:
	/* 0x3022: mov    r15d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3025:
	/* 0x3025: and    r15d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_302c:
	/* 0x302c: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3031:
	/* 0x3031: add    rdi,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_3038:
	/* 0x3038: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_303b:
	/* 0x303b: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_303f:
	/* 0x303f: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3042:
	/* 0x3042: jns    309d <generic_fexit_event+0x309d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3042, 0x309d, x86_l_309d);
x86_l_3044:
	/* 0x3044: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3047:
	/* 0x3047: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_304a:
	/* 0x304a: jns    30a7 <generic_fexit_event+0x30a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x304a, 0x30a7, x86_l_30a7);
x86_l_304c:
	/* 0x304c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_304e:
	/* 0x304e: cmp    r15d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3052:
	/* 0x3052: jb     3071 <generic_fexit_event+0x3071> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3052, 0x3071, x86_l_3071);
x86_l_3054:
	/* 0x3054: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3056:
	/* 0x3056: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3059:
	/* 0x3059: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_305c:
	/* 0x305c: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3060:
	/* 0x3060: mov    QWORD PTR [r8+rdx*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_3064:
	/* 0x3064: lea    rcx,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3068:
	/* 0x3068: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_306c:
	/* 0x306c: cmp    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_306f:
	/* 0x306f: jbe    3059 <generic_fexit_event+0x3059> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x306f, 0x3059, x86_l_3059);
x86_l_3071:
	/* 0x3071: test   r14b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_3075:
	/* 0x3075: jne    30b2 <generic_fexit_event+0x30b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3075, 0x30b2, x86_l_30b2);
x86_l_3077:
	/* 0x3077: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3079:
	/* 0x3079: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_307c:
	/* 0x307c: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_307f:
	/* 0x307f: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_3082:
	/* 0x3082: test   r14b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3086:
	/* 0x3086: je     30b8 <generic_fexit_event+0x30b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3086, 0x30b8, x86_l_30b8);
x86_l_3088:
	/* 0x3088: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_308a:
	/* 0x308a: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_308e:
	/* 0x308e: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_3092:
	/* 0x3092: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_3095:
	/* 0x3095: test   r14b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3099:
	/* 0x3099: je     30c7 <generic_fexit_event+0x30c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3099, 0x30c7, x86_l_30c7);
x86_l_309b:
	/* 0x309b: jmp    30be <generic_fexit_event+0x30be> */
	X86_SIM_X86_JMP(0x309b, 0x30be, x86_l_30be);
x86_l_309d:
	/* 0x309d: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_30a0:
	/* 0x30a0: call   30a5 <generic_fexit_event+0x30a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_30a5:
	/* 0x30a5: jmp    30c7 <generic_fexit_event+0x30c7> */
	X86_SIM_X86_JMP(0x30a5, 0x30c7, x86_l_30c7);
x86_l_30a7:
	/* 0x30a7: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_30a9:
	/* 0x30a9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30ab:
	/* 0x30ab: call   30b0 <generic_fexit_event+0x30b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_30b0:
	/* 0x30b0: jmp    30c7 <generic_fexit_event+0x30c7> */
	X86_SIM_X86_JMP(0x30b0, 0x30c7, x86_l_30c7);
x86_l_30b2:
	/* 0x30b2: test   r14b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_30b6:
	/* 0x30b6: jne    3088 <generic_fexit_event+0x3088> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30b6, 0x3088, x86_l_3088);
x86_l_30b8:
	/* 0x30b8: test   r14b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_30bc:
	/* 0x30bc: je     30c7 <generic_fexit_event+0x30c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30bc, 0x30c7, x86_l_30c7);
x86_l_30be:
	/* 0x30be: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_30c0:
	/* 0x30c0: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_30c4:
	/* 0x30c4: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_30c7:
	/* 0x30c7: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_30ca:
	/* 0x30ca: lea    r12,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_30ce:
	/* 0x30ce: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30d3:
	/* 0x30d3: lea    rdi,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_30d7:
	/* 0x30d7: add    rdi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_30db:
	/* 0x30db: lea    rdx,[rax+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_30df:
	/* 0x30df: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_30e3:
	/* 0x30e3: add    rdx,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_30e7:
	/* 0x30e7: jns    30fb <generic_fexit_event+0x30fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30e7, 0x30fb, x86_l_30fb);
x86_l_30e9:
	/* 0x30e9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_30ec:
	/* 0x30ec: jns    310e <generic_fexit_event+0x310e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30ec, 0x310e, x86_l_310e);
x86_l_30ee:
	/* 0x30ee: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30f0:
	/* 0x30f0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30f2:
	/* 0x30f2: add    r12,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_30f6:
	/* 0x30f6: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x30f6, 0x42c1, x86_l_42c1);
x86_l_30fb:
	/* 0x30fb: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3100:
	/* 0x3100: call   3105 <generic_fexit_event+0x3105> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3105:
	/* 0x3105: add    r12,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3109:
	/* 0x3109: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x3109, 0x42c1, x86_l_42c1);
x86_l_310e:
	/* 0x310e: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3114:
	/* 0x3114: add    r12,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_3118:
	/* 0x3118: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x3118, 0x42c1, x86_l_42c1);
x86_l_311d:
	/* 0x311d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_311f:
	/* 0x311f: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3122:
	/* 0x3122: call   3127 <generic_fexit_event+0x3127> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_3127:
	/* 0x3127: mov    DWORD PTR [r15+0x9c],0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 674309865470ULL);
x86_l_3132:
	/* 0x3132: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3138:
	/* 0x3138: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x3138, 0x21b7, x86_l_21b7);
x86_l_313d:
	/* 0x313d: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3142:
	/* 0x3142: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3148:
	/* 0x3148: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_314d:
	/* 0x314d: lea    rdi,[rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3154:
	/* 0x3154: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3157:
	/* 0x3157: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_315b:
	/* 0x315b: jns    3168 <generic_fexit_event+0x3168> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x315b, 0x3168, x86_l_3168);
x86_l_315d:
	/* 0x315d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3160:
	/* 0x3160: jns    3174 <generic_fexit_event+0x3174> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3160, 0x3174, x86_l_3174);
x86_l_3162:
	/* 0x3162: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3164:
	/* 0x3164: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3166:
	/* 0x3166: jmp    317a <generic_fexit_event+0x317a> */
	X86_SIM_X86_JMP(0x3166, 0x317a, x86_l_317a);
x86_l_3168:
	/* 0x3168: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_316d:
	/* 0x316d: call   3172 <generic_fexit_event+0x3172> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3172:
	/* 0x3172: jmp    317a <generic_fexit_event+0x317a> */
	X86_SIM_X86_JMP(0x3172, 0x317a, x86_l_317a);
x86_l_3174:
	/* 0x3174: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_317a:
	/* 0x317a: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_317f:
	/* 0x317f: add    rdi,0xa4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 164ULL);
x86_l_3186:
	/* 0x3186: add    rbp,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_318a:
	/* 0x318a: jns    31b7 <generic_fexit_event+0x31b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x318a, 0x31b7, x86_l_31b7);
x86_l_318c:
	/* 0x318c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_318f:
	/* 0x318f: jns    31cf <generic_fexit_event+0x31cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x318f, 0x31cf, x86_l_31cf);
x86_l_3191:
	/* 0x3191: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3195:
	/* 0x3195: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_319a:
	/* 0x319a: mov    QWORD PTR [rsi+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_31a1:
	/* 0x31a1: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31a5:
	/* 0x31a5: mov    QWORD PTR [rsi+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_31ac:
	/* 0x31ac: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_31b2:
	/* 0x31b2: jmp    3553 <generic_fexit_event+0x3553> */
	X86_SIM_X86_JMP(0x31b2, 0x3553, x86_l_3553);
x86_l_31b7:
	/* 0x31b7: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_31bc:
	/* 0x31bc: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_31bf:
	/* 0x31bf: call   31c4 <generic_fexit_event+0x31c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_31c4:
	/* 0x31c4: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_31ca:
	/* 0x31ca: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x31ca, 0x21b7, x86_l_21b7);
x86_l_31cf:
	/* 0x31cf: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_31d7:
	/* 0x31d7: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31de:
	/* 0x31de: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_31e4:
	/* 0x31e4: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x31e4, 0x21b7, x86_l_21b7);
x86_l_31e9:
	/* 0x31e9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_31ec:
	/* 0x31ec: jns    39c8 <generic_fexit_event+0x39c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31ec, 0x39c8, x86_l_39c8);
x86_l_31f2:
	/* 0x31f2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31f4:
	/* 0x31f4: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31f9:
	/* 0x31f9: cmp    rax,0x3e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 62ULL);
x86_l_31fd:
	/* 0x31fd: je     3e97 <generic_fexit_event+0x3e97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31fd, 0x3e97, x86_l_3e97);
x86_l_3203:
	/* 0x3203: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_3207:
	/* 0x3207: mov    BYTE PTR [rsi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_320a:
	/* 0x320a: inc    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_320d:
	/* 0x320d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_320f:
	/* 0x320f: jne    31f9 <generic_fexit_event+0x31f9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x320f, 0x31f9, x86_l_31f9);
x86_l_3211:
	/* 0x3211: jmp    1cb7 <generic_fexit_event+0x1cb7> */
	X86_SIM_X86_JMP(0x3211, 0x1cb7, x86_l_1cb7);
x86_l_3216:
	/* 0x3216: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_321b:
	/* 0x321b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3220:
	/* 0x3220: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3223:
	/* 0x3223: call   3228 <generic_fexit_event+0x3228> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3228:
	/* 0x3228: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_322d:
	/* 0x322d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3230:
	/* 0x3230: jns    3a1f <generic_fexit_event+0x3a1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3230, 0x3a1f, x86_l_3a1f);
x86_l_3236:
	/* 0x3236: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3239:
	/* 0x3239: jns    3c2e <generic_fexit_event+0x3c2e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3239, 0x3c2e, x86_l_3c2e);
x86_l_323f:
	/* 0x323f: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3242:
	/* 0x3242: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_324a:
	/* 0x324a: jmp    3c3a <generic_fexit_event+0x3c3a> */
	X86_SIM_X86_JMP(0x324a, 0x3c3a, x86_l_3c3a);
x86_l_324f:
	/* 0x324f: mov    BYTE PTR [rdi+rax*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_3253:
	/* 0x3253: mov    r12d,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_3256:
	/* 0x3256: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x3256, 0x28ad, x86_l_28ad);
x86_l_325b:
	/* 0x325b: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3263:
	/* 0x3263: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3268:
	/* 0x3268: call   326d <generic_fexit_event+0x326d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_326d:
	/* 0x326d: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_3275:
	/* 0x3275: jmp    3a40 <generic_fexit_event+0x3a40> */
	X86_SIM_X86_JMP(0x3275, 0x3a40, x86_l_3a40);
x86_l_327a:
	/* 0x327a: add    r12,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3ULL);
x86_l_327e:
	/* 0x327e: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3281:
	/* 0x3281: jns    3b98 <generic_fexit_event+0x3b98> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3281, 0x3b98, x86_l_3b98);
x86_l_3287:
	/* 0x3287: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_328b:
	/* 0x328b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3290:
	/* 0x3290: mov    QWORD PTR [rcx+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3297:
	/* 0x3297: mov    rax,QWORD PTR [r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_329c:
	/* 0x329c: mov    QWORD PTR [rcx+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_32a3:
	/* 0x32a3: mov    rax,QWORD PTR [r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32a8:
	/* 0x32a8: mov    QWORD PTR [rcx+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_32af:
	/* 0x32af: mov    rax,QWORD PTR [r12+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_32b4:
	/* 0x32b4: mov    QWORD PTR [rcx+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_32bb:
	/* 0x32bb: mov    rax,QWORD PTR [r12+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32c0:
	/* 0x32c0: mov    QWORD PTR [rcx+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_32c7:
	/* 0x32c7: mov    rax,QWORD PTR [r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_32cc:
	/* 0x32cc: mov    QWORD PTR [rcx+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_32d3:
	/* 0x32d3: mov    rax,QWORD PTR [r12+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_32d8:
	/* 0x32d8: mov    QWORD PTR [rcx+0xd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_32df:
	/* 0x32df: mov    rax,QWORD PTR [r12+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_32e4:
	/* 0x32e4: mov    QWORD PTR [rcx+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_32eb:
	/* 0x32eb: mov    rax,QWORD PTR [r12+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_32f0:
	/* 0x32f0: mov    QWORD PTR [rcx+0xe0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_32f7:
	/* 0x32f7: mov    rax,QWORD PTR [r12+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_32fc:
	/* 0x32fc: mov    QWORD PTR [rcx+0xe8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_3303:
	/* 0x3303: mov    rax,QWORD PTR [r12+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3308:
	/* 0x3308: mov    QWORD PTR [rcx+0xf0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_330f:
	/* 0x330f: mov    rax,QWORD PTR [r12+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3314:
	/* 0x3314: mov    QWORD PTR [rcx+0xf8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_331b:
	/* 0x331b: mov    rax,QWORD PTR [r12+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3320:
	/* 0x3320: mov    QWORD PTR [rcx+0x100],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_3327:
	/* 0x3327: movzx  eax,WORD PTR [r12+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 104ULL);
x86_l_332d:
	/* 0x332d: mov    WORD PTR [rcx+0x108],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_3334:
	/* 0x3334: movzx  eax,BYTE PTR [r12+0x6a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 106ULL);
x86_l_333a:
	/* 0x333a: mov    BYTE PTR [rcx+0x10a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 266ULL);
x86_l_3340:
	/* 0x3340: mov    BYTE PTR [rcx+0x9f],0x6b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 682899800171ULL);
x86_l_3347:
	/* 0x3347: jmp    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JMP(0x3347, 0x42bb, x86_l_42bb);
x86_l_334c:
	/* 0x334c: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_3358:
	/* 0x3358: add    r12,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_335c:
	/* 0x335c: jns    3371 <generic_fexit_event+0x3371> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x335c, 0x3371, x86_l_3371);
x86_l_335e:
	/* 0x335e: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3361:
	/* 0x3361: jns    3390 <generic_fexit_event+0x3390> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3361, 0x3390, x86_l_3390);
x86_l_3363:
	/* 0x3363: mov    r14,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3367:
	/* 0x3367: mov    QWORD PTR [rsp+0xa0],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_336f:
	/* 0x336f: jmp    339f <generic_fexit_event+0x339f> */
	X86_SIM_X86_JMP(0x336f, 0x339f, x86_l_339f);
x86_l_3371:
	/* 0x3371: lea    rdi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3379:
	/* 0x3379: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_337e:
	/* 0x337e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3381:
	/* 0x3381: call   3386 <generic_fexit_event+0x3386> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3386:
	/* 0x3386: mov    r14,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_338e:
	/* 0x338e: jmp    339f <generic_fexit_event+0x339f> */
	X86_SIM_X86_JMP(0x338e, 0x339f, x86_l_339f);
x86_l_3390:
	/* 0x3390: mov    QWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_339c:
	/* 0x339c: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_339f:
	/* 0x339f: mov    rdx,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_33a7:
	/* 0x33a7: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_33aa:
	/* 0x33aa: cmp    r14,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_33b1:
	/* 0x33b1: jb     33b9 <generic_fexit_event+0x33b9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x33b1, 0x33b9, x86_l_33b9);
x86_l_33b3:
	/* 0x33b3: mov    r12d,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_33b9:
	/* 0x33b9: add    r13,0xa4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 164ULL);
x86_l_33c0:
	/* 0x33c0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_33c3:
	/* 0x33c3: jns    3cf5 <generic_fexit_event+0x3cf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33c3, 0x3cf5, x86_l_3cf5);
x86_l_33c9:
	/* 0x33c9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_33cc:
	/* 0x33cc: jns    3d09 <generic_fexit_event+0x3d09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33cc, 0x3d09, x86_l_3d09);
x86_l_33d2:
	/* 0x33d2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33d4:
	/* 0x33d4: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_33d8:
	/* 0x33d8: jb     33f7 <generic_fexit_event+0x33f7> */
	X86_SIM_X86_JCC(X86_CC_B, 0x33d8, 0x33f7, x86_l_33f7);
x86_l_33da:
	/* 0x33da: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33dc:
	/* 0x33dc: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_33df:
	/* 0x33df: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33e2:
	/* 0x33e2: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_33e6:
	/* 0x33e6: mov    QWORD PTR [rcx+rsi*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_33ea:
	/* 0x33ea: lea    rax,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33ee:
	/* 0x33ee: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_33f2:
	/* 0x33f2: cmp    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_33f5:
	/* 0x33f5: jbe    33df <generic_fexit_event+0x33df> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x33f5, 0x33df, x86_l_33df);
x86_l_33f7:
	/* 0x33f7: test   r12b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_33fb:
	/* 0x33fb: jne    3be2 <generic_fexit_event+0x3be2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33fb, 0x3be2, x86_l_3be2);
x86_l_3401:
	/* 0x3401: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3405:
	/* 0x3405: jne    3bf9 <generic_fexit_event+0x3bf9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3405, 0x3bf9, x86_l_3bf9);
x86_l_340b:
	/* 0x340b: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_340f:
	/* 0x340f: jne    3c12 <generic_fexit_event+0x3c12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x340f, 0x3c12, x86_l_3c12);
x86_l_3415:
	/* 0x3415: jmp    3edf <generic_fexit_event+0x3edf> */
	X86_SIM_X86_JMP(0x3415, 0x3edf, x86_l_3edf);
x86_l_341a:
	/* 0x341a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_341c:
	/* 0x341c: add    rax,0x360 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 864ULL);
x86_l_3422:
	/* 0x3422: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3425:
	/* 0x3425: jns    342c <generic_fexit_event+0x342c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3425, 0x342c, x86_l_342c);
x86_l_3427:
	/* 0x3427: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_342a:
	/* 0x342a: jmp    342e <generic_fexit_event+0x342e> */
	X86_SIM_X86_JMP(0x342a, 0x342e, x86_l_342e);
x86_l_342c:
	/* 0x342c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_342e:
	/* 0x342e: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3433:
	/* 0x3433: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_343a:
	/* 0x343a: add    rbp,0x58 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_343e:
	/* 0x343e: mov    r12d,0x50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_3444:
	/* 0x3444: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3447:
	/* 0x3447: jns    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3447, 0x21b7, x86_l_21b7);
x86_l_344d:
	/* 0x344d: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3450:
	/* 0x3450: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3452:
	/* 0x3452: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3454:
	/* 0x3454: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_3457:
	/* 0x3457: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_345c:
	/* 0x345c: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_345e:
	/* 0x345e: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x345e, 0x21b7, x86_l_21b7);
x86_l_3463:
	/* 0x3463: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3468:
	/* 0x3468: mov    QWORD PTR [rax+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_3470:
	/* 0x3470: mov    QWORD PTR [rax+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_3478:
	/* 0x3478: mov    QWORD PTR [rax+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_3480:
	/* 0x3480: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3488:
	/* 0x3488: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3490:
	/* 0x3490: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3498:
	/* 0x3498: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_34a0:
	/* 0x34a0: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_34a8:
	/* 0x34a8: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_34b0:
	/* 0x34b0: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_34b8:
	/* 0x34b8: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_34c0:
	/* 0x34c0: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_34c8:
	/* 0x34c8: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_34d0:
	/* 0x34d0: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_34d8:
	/* 0x34d8: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_34e0:
	/* 0x34e0: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34e7:
	/* 0x34e7: jmp    2ed8 <generic_fexit_event+0x2ed8> */
	X86_SIM_X86_JMP(0x34e7, 0x2ed8, x86_l_2ed8);
x86_l_34ec:
	/* 0x34ec: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_34f1:
	/* 0x34f1: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_34f6:
	/* 0x34f6: call   34fb <generic_fexit_event+0x34fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_34fb:
	/* 0x34fb: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_34ff:
	/* 0x34ff: jmp    3d35 <generic_fexit_event+0x3d35> */
	X86_SIM_X86_JMP(0x34ff, 0x3d35, x86_l_3d35);
x86_l_3504:
	/* 0x3504: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3509:
	/* 0x3509: call   350e <generic_fexit_event+0x350e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_350e:
	/* 0x350e: jmp    3d6d <generic_fexit_event+0x3d6d> */
	X86_SIM_X86_JMP(0x350e, 0x3d6d, x86_l_3d6d);
x86_l_3513:
	/* 0x3513: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3518:
	/* 0x3518: mov    BYTE PTR [rax+0xea],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1005022347264ULL);
x86_l_351f:
	/* 0x351f: add    rbp,0x360 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 864ULL);
x86_l_3526:
	/* 0x3526: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3529:
	/* 0x3529: jns    353d <generic_fexit_event+0x353d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3529, 0x353d, x86_l_353d);
x86_l_352b:
	/* 0x352b: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_352f:
	/* 0x352f: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3534:
	/* 0x3534: mov    QWORD PTR [rsi+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_353b:
	/* 0x353b: jmp    354d <generic_fexit_event+0x354d> */
	X86_SIM_X86_JMP(0x353b, 0x354d, x86_l_354d);
x86_l_353d:
	/* 0x353d: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3542:
	/* 0x3542: mov    QWORD PTR [rsi+0xa4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_354d:
	/* 0x354d: mov    r12d,0x50 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 80ULL);
x86_l_3553:
	/* 0x3553: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3558:
	/* 0x3558: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_355e:
	/* 0x355e: jmp    42d1 <generic_fexit_event+0x42d1> */
	X86_SIM_X86_JMP(0x355e, 0x42d1, x86_l_42d1);
x86_l_3563:
	/* 0x3563: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3569:
	/* 0x3569: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x3569, 0x28ad, x86_l_28ad);
x86_l_356e:
	/* 0x356e: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_3571:
	/* 0x3571: call   3576 <generic_fexit_event+0x3576> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3576:
	/* 0x3576: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_357b:
	/* 0x357b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_357d:
	/* 0x357d: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x357d, 0x6ae, x86_l_6ae);
x86_l_3583:
	/* 0x3583: jmp    4361 <generic_fexit_event+0x4361> */
	X86_SIM_X86_JMP(0x3583, 0x4361, x86_l_4361);
x86_l_3588:
	/* 0x3588: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_358d:
	/* 0x358d: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3592:
	/* 0x3592: lea    rdi,[rax+0xd6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 214ULL);
x86_l_3599:
	/* 0x3599: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_359c:
	/* 0x359c: add    rdx,0x12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18ULL);
x86_l_35a0:
	/* 0x35a0: jns    35ae <generic_fexit_event+0x35ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35a0, 0x35ae, x86_l_35ae);
x86_l_35a2:
	/* 0x35a2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_35a5:
	/* 0x35a5: jns    35ba <generic_fexit_event+0x35ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35a5, 0x35ba, x86_l_35ba);
x86_l_35a7:
	/* 0x35a7: movzx  eax,BYTE PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_35aa:
	/* 0x35aa: mov    BYTE PTR [rdi],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35ac:
	/* 0x35ac: jmp    35bd <generic_fexit_event+0x35bd> */
	X86_SIM_X86_JMP(0x35ac, 0x35bd, x86_l_35bd);
x86_l_35ae:
	/* 0x35ae: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_35b3:
	/* 0x35b3: call   35b8 <generic_fexit_event+0x35b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_35b8:
	/* 0x35b8: jmp    35bd <generic_fexit_event+0x35bd> */
	X86_SIM_X86_JMP(0x35b8, 0x35bd, x86_l_35bd);
x86_l_35ba:
	/* 0x35ba: mov    BYTE PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35bd:
	/* 0x35bd: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35c2:
	/* 0x35c2: lea    rdi,[rax+0xd4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_35c9:
	/* 0x35c9: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_35cc:
	/* 0x35cc: add    rdx,0x21e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 542ULL);
x86_l_35d3:
	/* 0x35d3: jns    35e2 <generic_fexit_event+0x35e2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35d3, 0x35e2, x86_l_35e2);
x86_l_35d5:
	/* 0x35d5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_35d8:
	/* 0x35d8: jns    35ee <generic_fexit_event+0x35ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35d8, 0x35ee, x86_l_35ee);
x86_l_35da:
	/* 0x35da: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_35dd:
	/* 0x35dd: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35e0:
	/* 0x35e0: jmp    35f3 <generic_fexit_event+0x35f3> */
	X86_SIM_X86_JMP(0x35e0, 0x35f3, x86_l_35f3);
x86_l_35e2:
	/* 0x35e2: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_35e7:
	/* 0x35e7: call   35ec <generic_fexit_event+0x35ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_35ec:
	/* 0x35ec: jmp    35f3 <generic_fexit_event+0x35f3> */
	X86_SIM_X86_JMP(0x35ec, 0x35f3, x86_l_35f3);
x86_l_35ee:
	/* 0x35ee: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35f3:
	/* 0x35f3: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35f8:
	/* 0x35f8: lea    rdi,[rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_35ff:
	/* 0x35ff: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3602:
	/* 0x3602: add    rdx,0x21c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 540ULL);
x86_l_3609:
	/* 0x3609: jns    3618 <generic_fexit_event+0x3618> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3609, 0x3618, x86_l_3618);
x86_l_360b:
	/* 0x360b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_360e:
	/* 0x360e: jns    3624 <generic_fexit_event+0x3624> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x360e, 0x3624, x86_l_3624);
x86_l_3610:
	/* 0x3610: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3613:
	/* 0x3613: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3616:
	/* 0x3616: jmp    3629 <generic_fexit_event+0x3629> */
	X86_SIM_X86_JMP(0x3616, 0x3629, x86_l_3629);
x86_l_3618:
	/* 0x3618: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_361d:
	/* 0x361d: call   3622 <generic_fexit_event+0x3622> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3622:
	/* 0x3622: jmp    3629 <generic_fexit_event+0x3629> */
	X86_SIM_X86_JMP(0x3622, 0x3629, x86_l_3629);
x86_l_3624:
	/* 0x3624: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3629:
	/* 0x3629: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_362e:
	/* 0x362e: lea    rdi,[rax+0xcc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
x86_l_3635:
	/* 0x3635: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3638:
	/* 0x3638: add    rdx,0x214 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 532ULL);
x86_l_363f:
	/* 0x363f: jns    364c <generic_fexit_event+0x364c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x363f, 0x364c, x86_l_364c);
x86_l_3641:
	/* 0x3641: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3644:
	/* 0x3644: jns    3658 <generic_fexit_event+0x3658> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3644, 0x3658, x86_l_3658);
x86_l_3646:
	/* 0x3646: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3648:
	/* 0x3648: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_364a:
	/* 0x364a: jmp    365e <generic_fexit_event+0x365e> */
	X86_SIM_X86_JMP(0x364a, 0x365e, x86_l_365e);
x86_l_364c:
	/* 0x364c: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3651:
	/* 0x3651: call   3656 <generic_fexit_event+0x3656> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3656:
	/* 0x3656: jmp    365e <generic_fexit_event+0x365e> */
	X86_SIM_X86_JMP(0x3656, 0x365e, x86_l_365e);
x86_l_3658:
	/* 0x3658: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_365e:
	/* 0x365e: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3663:
	/* 0x3663: lea    rdi,[rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_366a:
	/* 0x366a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_366d:
	/* 0x366d: add    rdx,0x210 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 528ULL);
x86_l_3674:
	/* 0x3674: jns    3681 <generic_fexit_event+0x3681> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3674, 0x3681, x86_l_3681);
x86_l_3676:
	/* 0x3676: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3679:
	/* 0x3679: jns    368d <generic_fexit_event+0x368d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3679, 0x368d, x86_l_368d);
x86_l_367b:
	/* 0x367b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_367d:
	/* 0x367d: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_367f:
	/* 0x367f: jmp    3693 <generic_fexit_event+0x3693> */
	X86_SIM_X86_JMP(0x367f, 0x3693, x86_l_3693);
x86_l_3681:
	/* 0x3681: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3686:
	/* 0x3686: call   368b <generic_fexit_event+0x368b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_368b:
	/* 0x368b: jmp    3693 <generic_fexit_event+0x3693> */
	X86_SIM_X86_JMP(0x368b, 0x3693, x86_l_3693);
x86_l_368d:
	/* 0x368d: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3693:
	/* 0x3693: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3698:
	/* 0x3698: lea    r13,[rax+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_369f:
	/* 0x369f: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_36a4:
	/* 0x36a4: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_36ac:
	/* 0x36ac: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_36b4:
	/* 0x36b4: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_36bc:
	/* 0x36bc: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36c3:
	/* 0x36c3: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36c8:
	/* 0x36c8: movzx  eax,WORD PTR [rax+0xc2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 194ULL);
x86_l_36cf:
	/* 0x36cf: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_36d2:
	/* 0x36d2: je     3701 <generic_fexit_event+0x3701> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36d2, 0x3701, x86_l_3701);
x86_l_36d4:
	/* 0x36d4: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_36d7:
	/* 0x36d7: jne    3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36d7, 0x3f7c, x86_l_3f7c);
x86_l_36dd:
	/* 0x36dd: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_36e0:
	/* 0x36e0: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_36e4:
	/* 0x36e4: jns    3bba <generic_fexit_event+0x3bba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36e4, 0x3bba, x86_l_3bba);
x86_l_36ea:
	/* 0x36ea: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_36ed:
	/* 0x36ed: jns    3ef6 <generic_fexit_event+0x3ef6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36ed, 0x3ef6, x86_l_3ef6);
x86_l_36f3:
	/* 0x36f3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36f5:
	/* 0x36f5: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_36fa:
	/* 0x36fa: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36fc:
	/* 0x36fc: jmp    3f01 <generic_fexit_event+0x3f01> */
	X86_SIM_X86_JMP(0x36fc, 0x3f01, x86_l_3f01);
x86_l_3701:
	/* 0x3701: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3704:
	/* 0x3704: add    rdx,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_3708:
	/* 0x3708: jns    3bce <generic_fexit_event+0x3bce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3708, 0x3bce, x86_l_3bce);
x86_l_370e:
	/* 0x370e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3711:
	/* 0x3711: jns    3f2d <generic_fexit_event+0x3f2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3711, 0x3f2d, x86_l_3f2d);
x86_l_3717:
	/* 0x3717: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_371a:
	/* 0x371a: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_371f:
	/* 0x371f: mov    QWORD PTR [rcx+0x9c],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_3726:
	/* 0x3726: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_372a:
	/* 0x372a: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_3731:
	/* 0x3731: jmp    3f41 <generic_fexit_event+0x3f41> */
	X86_SIM_X86_JMP(0x3731, 0x3f41, x86_l_3f41);
x86_l_3736:
	/* 0x3736: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_373b:
	/* 0x373b: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3741:
	/* 0x3741: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3744:
	/* 0x3744: js     3753 <generic_fexit_event+0x3753> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3744, 0x3753, x86_l_3753);
x86_l_3746:
	/* 0x3746: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3749:
	/* 0x3749: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_374e:
	/* 0x374e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3751:
	/* 0x3751: jmp    37b1 <generic_fexit_event+0x37b1> */
	X86_SIM_X86_JMP(0x3751, 0x37b1, x86_l_37b1);
x86_l_3753:
	/* 0x3753: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3756:
	/* 0x3756: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3759:
	/* 0x3759: jns    3b8b <generic_fexit_event+0x3b8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3759, 0x3b8b, x86_l_3b8b);
x86_l_375f:
	/* 0x375f: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3761:
	/* 0x3761: mov    DWORD PTR [r13+0x0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3765:
	/* 0x3765: jmp    37b6 <generic_fexit_event+0x37b6> */
	X86_SIM_X86_JMP(0x3765, 0x37b6, x86_l_37b6);
x86_l_3767:
	/* 0x3767: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_376c:
	/* 0x376c: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3774:
	/* 0x3774: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_377b:
	/* 0x377b: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_377e:
	/* 0x377e: add    rdx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_3782:
	/* 0x3782: jns    37a9 <generic_fexit_event+0x37a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3782, 0x37a9, x86_l_37a9);
x86_l_3784:
	/* 0x3784: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3787:
	/* 0x3787: jns    3872 <generic_fexit_event+0x3872> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3787, 0x3872, x86_l_3872);
x86_l_378d:
	/* 0x378d: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3790:
	/* 0x3790: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3795:
	/* 0x3795: mov    QWORD PTR [rcx+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_379c:
	/* 0x379c: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37a0:
	/* 0x37a0: mov    QWORD PTR [rcx+0xb4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_37a7:
	/* 0x37a7: jmp    37b6 <generic_fexit_event+0x37b6> */
	X86_SIM_X86_JMP(0x37a7, 0x37b6, x86_l_37b6);
x86_l_37a9:
	/* 0x37a9: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_37ac:
	/* 0x37ac: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_37b1:
	/* 0x37b1: call   37b6 <generic_fexit_event+0x37b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_37b6:
	/* 0x37b6: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37bb:
	/* 0x37bb: lea    rdi,[rcx+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_37c2:
	/* 0x37c2: lea    r13,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_37c7:
	/* 0x37c7: add    r12,0xe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 14ULL);
x86_l_37cb:
	/* 0x37cb: jns    37dc <generic_fexit_event+0x37dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37cb, 0x37dc, x86_l_37dc);
x86_l_37cd:
	/* 0x37cd: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_37d0:
	/* 0x37d0: jns    37f0 <generic_fexit_event+0x37f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37d0, 0x37f0, x86_l_37f0);
x86_l_37d2:
	/* 0x37d2: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_37d7:
	/* 0x37d7: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37da:
	/* 0x37da: jmp    37f5 <generic_fexit_event+0x37f5> */
	X86_SIM_X86_JMP(0x37da, 0x37f5, x86_l_37f5);
x86_l_37dc:
	/* 0x37dc: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_37e1:
	/* 0x37e1: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_37e4:
	/* 0x37e4: call   37e9 <generic_fexit_event+0x37e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_37e9:
	/* 0x37e9: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37ee:
	/* 0x37ee: jmp    37f5 <generic_fexit_event+0x37f5> */
	X86_SIM_X86_JMP(0x37ee, 0x37f5, x86_l_37f5);
x86_l_37f0:
	/* 0x37f0: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37f5:
	/* 0x37f5: add    rcx,0xbe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 190ULL);
x86_l_37fc:
	/* 0x37fc: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_37ff:
	/* 0x37ff: jns    380d <generic_fexit_event+0x380d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37ff, 0x380d, x86_l_380d);
x86_l_3801:
	/* 0x3801: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3804:
	/* 0x3804: jns    3829 <generic_fexit_event+0x3829> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3804, 0x3829, x86_l_3829);
x86_l_3806:
	/* 0x3806: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_380b:
	/* 0x380b: jmp    382b <generic_fexit_event+0x382b> */
	X86_SIM_X86_JMP(0x380b, 0x382b, x86_l_382b);
x86_l_380d:
	/* 0x380d: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3810:
	/* 0x3810: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3815:
	/* 0x3815: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3818:
	/* 0x3818: mov    r14,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_381b:
	/* 0x381b: call   3820 <generic_fexit_event+0x3820> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3820:
	/* 0x3820: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3823:
	/* 0x3823: movzx  eax,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3827:
	/* 0x3827: jmp    382b <generic_fexit_event+0x382b> */
	X86_SIM_X86_JMP(0x3827, 0x382b, x86_l_382b);
x86_l_3829:
	/* 0x3829: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_382b:
	/* 0x382b: movbe  WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3830:
	/* 0x3830: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3835:
	/* 0x3835: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_383a:
	/* 0x383a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_3841:
	/* 0x3841: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3846:
	/* 0x3846: call   384b <generic_fexit_event+0x384b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_384b:
	/* 0x384b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_384e:
	/* 0x384e: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3854:
	/* 0x3854: je     4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3854, 0x4295, x86_l_4295);
x86_l_385a:
	/* 0x385a: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_385c:
	/* 0x385c: mov    DWORD PTR [rbp+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_385f:
	/* 0x385f: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3863:
	/* 0x3863: mov    QWORD PTR [rbp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3867:
	/* 0x3867: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_386a:
	/* 0x386a: mov    DWORD PTR [rbp+0x7c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_386d:
	/* 0x386d: jmp    4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JMP(0x386d, 0x4295, x86_l_4295);
x86_l_3872:
	/* 0x3872: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_387a:
	/* 0x387a: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3882:
	/* 0x3882: jmp    37b6 <generic_fexit_event+0x37b6> */
	X86_SIM_X86_JMP(0x3882, 0x37b6, x86_l_37b6);
x86_l_3887:
	/* 0x3887: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_388a:
	/* 0x388a: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_388f:
	/* 0x388f: call   3894 <generic_fexit_event+0x3894> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3894:
	/* 0x3894: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3897:
	/* 0x3897: js     4059 <generic_fexit_event+0x4059> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3897, 0x4059, x86_l_4059);
x86_l_389d:
	/* 0x389d: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38a0:
	/* 0x38a0: movabs r12,0x1008180000000001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1155199692699598849ULL);
x86_l_38aa:
	/* 0x38aa: jmp    38af <generic_fexit_event+0x38af> */
	X86_SIM_X86_JMP(0x38aa, 0x38af, x86_l_38af);
x86_l_38ac:
	/* 0x38ac: inc    r15b */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_38af:
	/* 0x38af: movzx  eax,BYTE PTR [r13+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_38b4:
	/* 0x38b4: cmp    eax,0x32 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_38b7:
	/* 0x38b7: jg     38d8 <generic_fexit_event+0x38d8> */
	X86_SIM_X86_JCC(X86_CC_G, 0x38b7, 0x38d8, x86_l_38d8);
x86_l_38b9:
	/* 0x38b9: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_38bb:
	/* 0x38bb: je     38fa <generic_fexit_event+0x38fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38bb, 0x38fa, x86_l_38fa);
x86_l_38bd:
	/* 0x38bd: cmp    eax,0x2b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 43ULL);
x86_l_38c0:
	/* 0x38c0: je     38fa <generic_fexit_event+0x38fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38c0, 0x38fa, x86_l_38fa);
x86_l_38c2:
	/* 0x38c2: cmp    eax,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_38c5:
	/* 0x38c5: jne    398e <generic_fexit_event+0x398e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38c5, 0x398e, x86_l_398e);
x86_l_38cb:
	/* 0x38cb: mov    WORD PTR [r13+0x2],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934600ULL);
x86_l_38d2:
	/* 0x38d2: mov    ax,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 8ULL);
x86_l_38d6:
	/* 0x38d6: jmp    3919 <generic_fexit_event+0x3919> */
	X86_SIM_X86_JMP(0x38d6, 0x3919, x86_l_3919);
x86_l_38d8:
	/* 0x38d8: cmp    eax,0x33 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_38db:
	/* 0x38db: je     3908 <generic_fexit_event+0x3908> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38db, 0x3908, x86_l_3908);
x86_l_38dd:
	/* 0x38dd: cmp    eax,0x3c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 60ULL);
x86_l_38e0:
	/* 0x38e0: je     38fa <generic_fexit_event+0x38fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38e0, 0x38fa, x86_l_38fa);
x86_l_38e2:
	/* 0x38e2: cmp    eax,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_38e7:
	/* 0x38e7: jne    398e <generic_fexit_event+0x398e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38e7, 0x398e, x86_l_398e);
x86_l_38ed:
	/* 0x38ed: mov    WORD PTR [r13+0x2],0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8589934632ULL);
x86_l_38f4:
	/* 0x38f4: mov    ax,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 40ULL);
x86_l_38f8:
	/* 0x38f8: jmp    3919 <generic_fexit_event+0x3919> */
	X86_SIM_X86_JMP(0x38f8, 0x3919, x86_l_3919);
x86_l_38fa:
	/* 0x38fa: movzx  eax,BYTE PTR [r13+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_38ff:
	/* 0x38ff: lea    eax,[rax*8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 8ULL);
x86_l_3906:
	/* 0x3906: jmp    3914 <generic_fexit_event+0x3914> */
	X86_SIM_X86_JMP(0x3906, 0x3914, x86_l_3914);
x86_l_3908:
	/* 0x3908: movzx  eax,BYTE PTR [r13+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_390d:
	/* 0x390d: lea    eax,[rax*4+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 8ULL);
x86_l_3914:
	/* 0x3914: mov    WORD PTR [r13+0x2],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_3919:
	/* 0x3919: add    ax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_391e:
	/* 0x391e: mov    WORD PTR [r13+0x0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3923:
	/* 0x3923: movzx  ecx,BYTE PTR [r13+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3928:
	/* 0x3928: cmp    rcx,0x3c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 60ULL);
x86_l_392c:
	/* 0x392c: ja     44c1 <generic_fexit_event+0x44c1> */
	X86_SIM_X86_JCC(X86_CC_A, 0x392c, 0x44c1, x86_l_44c1);
x86_l_3932:
	/* 0x3932: bt     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R12, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3936:
	/* 0x3936: jae    44c1 <generic_fexit_event+0x44c1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3936, 0x44c1, x86_l_44c1);
x86_l_393c:
	/* 0x393c: mov    BYTE PTR [r13+0x5],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_3940:
	/* 0x3940: movzx  edx,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_3943:
	/* 0x3943: add    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3946:
	/* 0x3946: jns    3967 <generic_fexit_event+0x3967> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3946, 0x3967, x86_l_3967);
x86_l_3948:
	/* 0x3948: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_394b:
	/* 0x394b: jns    4053 <generic_fexit_event+0x4053> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x394b, 0x4053, x86_l_4053);
x86_l_3951:
	/* 0x3951: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3954:
	/* 0x3954: mov    WORD PTR [rbp+0x0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3958:
	/* 0x3958: cmp    r15b,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 5ULL);
x86_l_395c:
	/* 0x395c: jbe    38ac <generic_fexit_event+0x38ac> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x395c, 0x38ac, x86_l_38ac);
x86_l_3962:
	/* 0x3962: jmp    4059 <generic_fexit_event+0x4059> */
	X86_SIM_X86_JMP(0x3962, 0x4059, x86_l_4059);
x86_l_3967:
	/* 0x3967: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_396a:
	/* 0x396a: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_396f:
	/* 0x396f: call   3974 <generic_fexit_event+0x3974> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3974:
	/* 0x3974: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3976:
	/* 0x3976: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3979:
	/* 0x3979: js     405b <generic_fexit_event+0x405b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3979, 0x405b, x86_l_405b);
x86_l_397f:
	/* 0x397f: cmp    r15b,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_3983:
	/* 0x3983: jb     38ac <generic_fexit_event+0x38ac> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3983, 0x38ac, x86_l_38ac);
x86_l_3989:
	/* 0x3989: jmp    405b <generic_fexit_event+0x405b> */
	X86_SIM_X86_JMP(0x3989, 0x405b, x86_l_405b);
x86_l_398e:
	/* 0x398e: movzx  eax,WORD PTR [r13+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_3993:
	/* 0x3993: jmp    3919 <generic_fexit_event+0x3919> */
	X86_SIM_X86_JMP(0x3993, 0x3919, x86_l_3919);
x86_l_3995:
	/* 0x3995: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3997:
	/* 0x3997: mov    edx,DWORD PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_399b:
	/* 0x399b: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_399e:
	/* 0x399e: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_39a1:
	/* 0x39a1: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_39a5:
	/* 0x39a5: je     299a <generic_fexit_event+0x299a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39a5, 0x299a, x86_l_299a);
x86_l_39ab:
	/* 0x39ab: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_39ad:
	/* 0x39ad: movzx  edx,WORD PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_39b2:
	/* 0x39b2: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_39b6:
	/* 0x39b6: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_39b9:
	/* 0x39b9: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_39bd:
	/* 0x39bd: jne    29a0 <generic_fexit_event+0x29a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39bd, 0x29a0, x86_l_29a0);
x86_l_39c3:
	/* 0x39c3: jmp    29aa <generic_fexit_event+0x29aa> */
	X86_SIM_X86_JMP(0x39c3, 0x29aa, x86_l_29aa);
x86_l_39c8:
	/* 0x39c8: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39cd:
	/* 0x39cd: mov    QWORD PTR [rax+0x37],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236223201280ULL);
x86_l_39d5:
	/* 0x39d5: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_39dd:
	/* 0x39dd: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_39e5:
	/* 0x39e5: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_39ed:
	/* 0x39ed: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_39f5:
	/* 0x39f5: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_39fd:
	/* 0x39fd: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3a05:
	/* 0x3a05: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a0c:
	/* 0x3a0c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a0f:
	/* 0x3a0f: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x3a0f, 0x42c7, x86_l_42c7);
x86_l_3a14:
	/* 0x3a14: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3a1d:
	/* 0x3a1d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a1f:
	/* 0x3a1f: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3a27:
	/* 0x3a27: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3a2c:
	/* 0x3a2c: call   3a31 <generic_fexit_event+0x3a31> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3a31:
	/* 0x3a31: jmp    3c3a <generic_fexit_event+0x3c3a> */
	X86_SIM_X86_JMP(0x3a31, 0x3c3a, x86_l_3c3a);
x86_l_3a36:
	/* 0x3a36: mov    BYTE PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_3a3e:
	/* 0x3a3e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a40:
	/* 0x3a40: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_3a43:
	/* 0x3a43: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3a48:
	/* 0x3a48: mov    WORD PTR [rcx+0xc0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_3a4f:
	/* 0x3a4f: mov    WORD PTR [rcx+0xc2],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 833223655426ULL);
x86_l_3a58:
	/* 0x3a58: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3a5b:
	/* 0x3a5b: add    rdx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3a5f:
	/* 0x3a5f: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a64:
	/* 0x3a64: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_3a6c:
	/* 0x3a6c: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3a74:
	/* 0x3a74: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3a7c:
	/* 0x3a7c: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a83:
	/* 0x3a83: jns    3a95 <generic_fexit_event+0x3a95> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a83, 0x3a95, x86_l_3a95);
x86_l_3a85:
	/* 0x3a85: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3a88:
	/* 0x3a88: jns    3aa6 <generic_fexit_event+0x3aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a88, 0x3aa6, x86_l_3aa6);
x86_l_3a8a:
	/* 0x3a8a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a8c:
	/* 0x3a8c: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a91:
	/* 0x3a91: mov    DWORD PTR [rcx],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a93:
	/* 0x3a93: jmp    3ab1 <generic_fexit_event+0x3ab1> */
	X86_SIM_X86_JMP(0x3a93, 0x3ab1, x86_l_3ab1);
x86_l_3a95:
	/* 0x3a95: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3a9a:
	/* 0x3a9a: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3a9f:
	/* 0x3a9f: call   3aa4 <generic_fexit_event+0x3aa4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3aa4:
	/* 0x3aa4: jmp    3ab1 <generic_fexit_event+0x3ab1> */
	X86_SIM_X86_JMP(0x3aa4, 0x3ab1, x86_l_3ab1);
x86_l_3aa6:
	/* 0x3aa6: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3aab:
	/* 0x3aab: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ab1:
	/* 0x3ab1: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ab6:
	/* 0x3ab6: lea    rdi,[rax+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_3abd:
	/* 0x3abd: add    r12,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3ac1:
	/* 0x3ac1: jns    3ad0 <generic_fexit_event+0x3ad0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ac1, 0x3ad0, x86_l_3ad0);
x86_l_3ac3:
	/* 0x3ac3: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3ac6:
	/* 0x3ac6: jns    3adf <generic_fexit_event+0x3adf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ac6, 0x3adf, x86_l_3adf);
x86_l_3ac8:
	/* 0x3ac8: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3acc:
	/* 0x3acc: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ace:
	/* 0x3ace: jmp    3ae5 <generic_fexit_event+0x3ae5> */
	X86_SIM_X86_JMP(0x3ace, 0x3ae5, x86_l_3ae5);
x86_l_3ad0:
	/* 0x3ad0: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3ad5:
	/* 0x3ad5: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3ad8:
	/* 0x3ad8: call   3add <generic_fexit_event+0x3add> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3add:
	/* 0x3add: jmp    3ae5 <generic_fexit_event+0x3ae5> */
	X86_SIM_X86_JMP(0x3add, 0x3ae5, x86_l_3ae5);
x86_l_3adf:
	/* 0x3adf: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ae5:
	/* 0x3ae5: mov    rdx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_3aed:
	/* 0x3aed: add    rdx,0xb6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 182ULL);
x86_l_3af4:
	/* 0x3af4: jns    3b19 <generic_fexit_event+0x3b19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3af4, 0x3b19, x86_l_3b19);
x86_l_3af6:
	/* 0x3af6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3af9:
	/* 0x3af9: jns    3b2b <generic_fexit_event+0x3b2b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3af9, 0x3b2b, x86_l_3b2b);
x86_l_3afb:
	/* 0x3afb: movzx  eax,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3afe:
	/* 0x3afe: mov    WORD PTR [rsp+0x90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3b06:
	/* 0x3b06: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_3b0e:
	/* 0x3b0e: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_3b11:
	/* 0x3b11: jne    414b <generic_fexit_event+0x414b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b11, 0x414b, x86_l_414b);
x86_l_3b17:
	/* 0x3b17: jmp    3b46 <generic_fexit_event+0x3b46> */
	X86_SIM_X86_JMP(0x3b17, 0x3b46, x86_l_3b46);
x86_l_3b19:
	/* 0x3b19: lea    rdi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3b21:
	/* 0x3b21: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3b26:
	/* 0x3b26: jmp    4135 <generic_fexit_event+0x4135> */
	X86_SIM_X86_JMP(0x3b26, 0x4135, x86_l_4135);
x86_l_3b2b:
	/* 0x3b2b: mov    WORD PTR [rsp+0x90],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 618475290624ULL);
x86_l_3b35:
	/* 0x3b35: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_3b3d:
	/* 0x3b3d: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_3b40:
	/* 0x3b40: jne    414b <generic_fexit_event+0x414b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b40, 0x414b, x86_l_414b);
x86_l_3b46:
	/* 0x3b46: movzx  r12d,WORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 144ULL);
x86_l_3b4f:
	/* 0x3b4f: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b54:
	/* 0x3b54: lea    rdi,[rax+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_3b5b:
	/* 0x3b5b: add    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_3b60:
	/* 0x3b60: jns    3b79 <generic_fexit_event+0x3b79> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b60, 0x3b79, x86_l_3b79);
x86_l_3b62:
	/* 0x3b62: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3b65:
	/* 0x3b65: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b68:
	/* 0x3b68: jns    3e56 <generic_fexit_event+0x3e56> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b68, 0x3e56, x86_l_3e56);
x86_l_3b6e:
	/* 0x3b6e: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3b71:
	/* 0x3b71: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b74:
	/* 0x3b74: jmp    3e5b <generic_fexit_event+0x3e5b> */
	X86_SIM_X86_JMP(0x3b74, 0x3e5b, x86_l_3e5b);
x86_l_3b79:
	/* 0x3b79: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3b7e:
	/* 0x3b7e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3b81:
	/* 0x3b81: call   3b86 <generic_fexit_event+0x3b86> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3b86:
	/* 0x3b86: jmp    3e5b <generic_fexit_event+0x3e5b> */
	X86_SIM_X86_JMP(0x3b86, 0x3e5b, x86_l_3e5b);
x86_l_3b8b:
	/* 0x3b8b: mov    DWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b93:
	/* 0x3b93: jmp    37b6 <generic_fexit_event+0x37b6> */
	X86_SIM_X86_JMP(0x3b93, 0x37b6, x86_l_37b6);
x86_l_3b98:
	/* 0x3b98: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b9d:
	/* 0x3b9d: add    rax,0xa0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 160ULL);
x86_l_3ba3:
	/* 0x3ba3: mov    DWORD PTR [rax+0x67],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 442381631488ULL);
x86_l_3baa:
	/* 0x3baa: jmp    3de0 <generic_fexit_event+0x3de0> */
	X86_SIM_X86_JMP(0x3baa, 0x3de0, x86_l_3de0);
x86_l_3baf:
	/* 0x3baf: mov    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3bb5:
	/* 0x3bb5: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x3bb5, 0x28ad, x86_l_28ad);
x86_l_3bba:
	/* 0x3bba: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3bbf:
	/* 0x3bbf: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3bc4:
	/* 0x3bc4: call   3bc9 <generic_fexit_event+0x3bc9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3bc9:
	/* 0x3bc9: jmp    3f01 <generic_fexit_event+0x3f01> */
	X86_SIM_X86_JMP(0x3bc9, 0x3f01, x86_l_3f01);
x86_l_3bce:
	/* 0x3bce: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3bd3:
	/* 0x3bd3: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3bd8:
	/* 0x3bd8: call   3bdd <generic_fexit_event+0x3bdd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3bdd:
	/* 0x3bdd: jmp    3f41 <generic_fexit_event+0x3f41> */
	X86_SIM_X86_JMP(0x3bdd, 0x3f41, x86_l_3f41);
x86_l_3be2:
	/* 0x3be2: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3be4:
	/* 0x3be4: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3be7:
	/* 0x3be7: mov    DWORD PTR [r13+rcx*1+0x0],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3bec:
	/* 0x3bec: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_3bef:
	/* 0x3bef: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3bf3:
	/* 0x3bf3: je     340b <generic_fexit_event+0x340b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bf3, 0x340b, x86_l_340b);
x86_l_3bf9:
	/* 0x3bf9: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3bfb:
	/* 0x3bfb: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_3bff:
	/* 0x3bff: mov    WORD PTR [r13+rcx*1+0x0],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3c05:
	/* 0x3c05: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_3c08:
	/* 0x3c08: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3c0c:
	/* 0x3c0c: je     3edf <generic_fexit_event+0x3edf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c0c, 0x3edf, x86_l_3edf);
x86_l_3c12:
	/* 0x3c12: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3c14:
	/* 0x3c14: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_3c18:
	/* 0x3c18: jmp    3eda <generic_fexit_event+0x3eda> */
	X86_SIM_X86_JMP(0x3c18, 0x3eda, x86_l_3eda);
x86_l_3c1d:
	/* 0x3c1d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3c22:
	/* 0x3c22: mov    BYTE PTR [rax+0x11b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1215475744768ULL);
x86_l_3c29:
	/* 0x3c29: jmp    2ed8 <generic_fexit_event+0x2ed8> */
	X86_SIM_X86_JMP(0x3c29, 0x2ed8, x86_l_2ed8);
x86_l_3c2e:
	/* 0x3c2e: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_3c3a:
	/* 0x3c3a: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3c3f:
	/* 0x3c3f: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3c43:
	/* 0x3c43: jns    3c57 <generic_fexit_event+0x3c57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c43, 0x3c57, x86_l_3c57);
x86_l_3c45:
	/* 0x3c45: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3c48:
	/* 0x3c48: jns    3c73 <generic_fexit_event+0x3c73> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c48, 0x3c73, x86_l_3c73);
x86_l_3c4a:
	/* 0x3c4a: mov    r14,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c4d:
	/* 0x3c4d: mov    QWORD PTR [rsp+0xa0],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3c55:
	/* 0x3c55: jmp    3c82 <generic_fexit_event+0x3c82> */
	X86_SIM_X86_JMP(0x3c55, 0x3c82, x86_l_3c82);
x86_l_3c57:
	/* 0x3c57: lea    rdi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3c5f:
	/* 0x3c5f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3c64:
	/* 0x3c64: call   3c69 <generic_fexit_event+0x3c69> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3c69:
	/* 0x3c69: mov    r14,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3c71:
	/* 0x3c71: jmp    3c82 <generic_fexit_event+0x3c82> */
	X86_SIM_X86_JMP(0x3c71, 0x3c82, x86_l_3c82);
x86_l_3c73:
	/* 0x3c73: mov    QWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_3c7f:
	/* 0x3c7f: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3c82:
	/* 0x3c82: mov    rdx,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3c8a:
	/* 0x3c8a: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3c8d:
	/* 0x3c8d: cmp    r14,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_3c94:
	/* 0x3c94: jb     3c9c <generic_fexit_event+0x3c9c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3c94, 0x3c9c, x86_l_3c9c);
x86_l_3c96:
	/* 0x3c96: mov    r12d,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_3c9c:
	/* 0x3c9c: add    r13,0xa4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 164ULL);
x86_l_3ca3:
	/* 0x3ca3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ca6:
	/* 0x3ca6: jns    3cf5 <generic_fexit_event+0x3cf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ca6, 0x3cf5, x86_l_3cf5);
x86_l_3ca8:
	/* 0x3ca8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3cab:
	/* 0x3cab: jns    3d09 <generic_fexit_event+0x3d09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3cab, 0x3d09, x86_l_3d09);
x86_l_3cad:
	/* 0x3cad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3caf:
	/* 0x3caf: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_3cb3:
	/* 0x3cb3: jb     3cd2 <generic_fexit_event+0x3cd2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3cb3, 0x3cd2, x86_l_3cd2);
x86_l_3cb5:
	/* 0x3cb5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3cb7:
	/* 0x3cb7: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3cba:
	/* 0x3cba: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cbd:
	/* 0x3cbd: mov    rax,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_3cc1:
	/* 0x3cc1: mov    QWORD PTR [rcx+rsi*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3cc5:
	/* 0x3cc5: lea    rax,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3cc9:
	/* 0x3cc9: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3ccd:
	/* 0x3ccd: cmp    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3cd0:
	/* 0x3cd0: jbe    3cba <generic_fexit_event+0x3cba> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x3cd0, 0x3cba, x86_l_3cba);
x86_l_3cd2:
	/* 0x3cd2: test   r12b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_3cd6:
	/* 0x3cd6: jne    3ea8 <generic_fexit_event+0x3ea8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3cd6, 0x3ea8, x86_l_3ea8);
x86_l_3cdc:
	/* 0x3cdc: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3ce0:
	/* 0x3ce0: jne    3ebf <generic_fexit_event+0x3ebf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ce0, 0x3ebf, x86_l_3ebf);
x86_l_3ce6:
	/* 0x3ce6: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3cea:
	/* 0x3cea: jne    3ed4 <generic_fexit_event+0x3ed4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3cea, 0x3ed4, x86_l_3ed4);
x86_l_3cf0:
	/* 0x3cf0: jmp    3edf <generic_fexit_event+0x3edf> */
	X86_SIM_X86_JMP(0x3cf0, 0x3edf, x86_l_3edf);
x86_l_3cf5:
	/* 0x3cf5: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3cf8:
	/* 0x3cf8: mov    esi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_3cfb:
	/* 0x3cfb: call   3d00 <generic_fexit_event+0x3d00> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3d00:
	/* 0x3d00: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3d02:
	/* 0x3d02: js     3d16 <generic_fexit_event+0x3d16> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3d02, 0x3d16, x86_l_3d16);
x86_l_3d04:
	/* 0x3d04: jmp    3edf <generic_fexit_event+0x3edf> */
	X86_SIM_X86_JMP(0x3d04, 0x3edf, x86_l_3edf);
x86_l_3d09:
	/* 0x3d09: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3d0c:
	/* 0x3d0c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d0e:
	/* 0x3d0e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3d11:
	/* 0x3d11: call   3d16 <generic_fexit_event+0x3d16> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_3d16:
	/* 0x3d16: mov    DWORD PTR [rbp+0x9c],0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 674309865470ULL);
x86_l_3d20:
	/* 0x3d20: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3d26:
	/* 0x3d26: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x3d26, 0x42c1, x86_l_42c1);
x86_l_3d2b:
	/* 0x3d2b: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3d33:
	/* 0x3d33: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d35:
	/* 0x3d35: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3d37:
	/* 0x3d37: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3d3c:
	/* 0x3d3c: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_3d43:
	/* 0x3d43: add    QWORD PTR [rsp+0x10],0x9e */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476894ULL);
x86_l_3d4c:
	/* 0x3d4c: add    r12,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_3d50:
	/* 0x3d50: jns    3d90 <generic_fexit_event+0x3d90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d50, 0x3d90, x86_l_3d90);
x86_l_3d52:
	/* 0x3d52: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3d55:
	/* 0x3d55: jns    3da4 <generic_fexit_event+0x3da4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d55, 0x3da4, x86_l_3da4);
x86_l_3d57:
	/* 0x3d57: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3d5c:
	/* 0x3d5c: jmp    3d86 <generic_fexit_event+0x3d86> */
	X86_SIM_X86_JMP(0x3d5c, 0x3d86, x86_l_3d86);
x86_l_3d5e:
	/* 0x3d5e: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3d66:
	/* 0x3d66: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d6d:
	/* 0x3d6d: add    QWORD PTR [rsp+0x10],0x9e */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476894ULL);
x86_l_3d76:
	/* 0x3d76: add    r12,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_3d7a:
	/* 0x3d7a: jns    3d90 <generic_fexit_event+0x3d90> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d7a, 0x3d90, x86_l_3d90);
x86_l_3d7c:
	/* 0x3d7c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3d7f:
	/* 0x3d7f: jns    3da4 <generic_fexit_event+0x3da4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d7f, 0x3da4, x86_l_3da4);
x86_l_3d81:
	/* 0x3d81: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3d86:
	/* 0x3d86: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d8b:
	/* 0x3d8b: mov    WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3d8e:
	/* 0x3d8e: jmp    3dae <generic_fexit_event+0x3dae> */
	X86_SIM_X86_JMP(0x3d8e, 0x3dae, x86_l_3dae);
x86_l_3d90:
	/* 0x3d90: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3d95:
	/* 0x3d95: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3d9a:
	/* 0x3d9a: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3d9d:
	/* 0x3d9d: call   3da2 <generic_fexit_event+0x3da2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3da2:
	/* 0x3da2: jmp    3dae <generic_fexit_event+0x3dae> */
	X86_SIM_X86_JMP(0x3da2, 0x3dae, x86_l_3dae);
x86_l_3da4:
	/* 0x3da4: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3da9:
	/* 0x3da9: mov    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3dae:
	/* 0x3dae: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3db3:
	/* 0x3db3: movzx  eax,WORD PTR [rcx+0x9e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 158ULL);
x86_l_3dba:
	/* 0x3dba: movbe  WORD PTR [rcx+0x9e],ax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 158ULL);
x86_l_3dc3:
	/* 0x3dc3: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3dc9:
	/* 0x3dc9: mov    r12d,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_3dcf:
	/* 0x3dcf: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x3dcf, 0x42c7, x86_l_42c7);
x86_l_3dd4:
	/* 0x3dd4: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3dd9:
	/* 0x3dd9: mov    DWORD PTR [rax+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_3de0:
	/* 0x3de0: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3de8:
	/* 0x3de8: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3df0:
	/* 0x3df0: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3df8:
	/* 0x3df8: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_3e00:
	/* 0x3e00: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3e08:
	/* 0x3e08: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_3e10:
	/* 0x3e10: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3e18:
	/* 0x3e18: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_3e20:
	/* 0x3e20: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_3e28:
	/* 0x3e28: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_3e30:
	/* 0x3e30: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3e38:
	/* 0x3e38: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3e40:
	/* 0x3e40: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e47:
	/* 0x3e47: jmp    42bb <generic_fexit_event+0x42bb> */
	X86_SIM_X86_JMP(0x3e47, 0x42bb, x86_l_42bb);
x86_l_3e4c:
	/* 0x3e4c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e4e:
	/* 0x3e4e: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3e51:
	/* 0x3e51: jmp    6a4 <generic_fexit_event+0x6a4> */
	X86_SIM_X86_JMP(0x3e51, 0x6a4, x86_l_6a4);
x86_l_3e56:
	/* 0x3e56: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e5b:
	/* 0x3e5b: add    QWORD PTR [rsp+0x10],0xbe */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476926ULL);
x86_l_3e64:
	/* 0x3e64: add    r12,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_3e68:
	/* 0x3e68: jns    41e5 <generic_fexit_event+0x41e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e68, 0x41e5, x86_l_41e5);
x86_l_3e6e:
	/* 0x3e6e: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3e71:
	/* 0x3e71: jns    41f9 <generic_fexit_event+0x41f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e71, 0x41f9, x86_l_41f9);
x86_l_3e77:
	/* 0x3e77: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3e7c:
	/* 0x3e7c: jmp    41db <generic_fexit_event+0x41db> */
	X86_SIM_X86_JMP(0x3e7c, 0x41db, x86_l_41db);
x86_l_3e81:
	/* 0x3e81: mov    BYTE PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e85:
	/* 0x3e85: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e87:
	/* 0x3e87: jmp    405b <generic_fexit_event+0x405b> */
	X86_SIM_X86_JMP(0x3e87, 0x405b, x86_l_405b);
x86_l_3e8c:
	/* 0x3e8c: mov    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_3e92:
	/* 0x3e92: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x3e92, 0x28ad, x86_l_28ad);
x86_l_3e97:
	/* 0x3e97: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3e9c:
	/* 0x3e9c: mov    BYTE PTR [rax+0xea],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1005022347264ULL);
x86_l_3ea3:
	/* 0x3ea3: jmp    1cb7 <generic_fexit_event+0x1cb7> */
	X86_SIM_X86_JMP(0x3ea3, 0x1cb7, x86_l_1cb7);
x86_l_3ea8:
	/* 0x3ea8: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3eaa:
	/* 0x3eaa: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3ead:
	/* 0x3ead: mov    DWORD PTR [r13+rcx*1+0x0],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3eb2:
	/* 0x3eb2: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_3eb5:
	/* 0x3eb5: test   r12b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3eb9:
	/* 0x3eb9: je     3ce6 <generic_fexit_event+0x3ce6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3eb9, 0x3ce6, x86_l_3ce6);
x86_l_3ebf:
	/* 0x3ebf: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3ec1:
	/* 0x3ec1: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_3ec5:
	/* 0x3ec5: mov    WORD PTR [r13+rcx*1+0x0],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3ecb:
	/* 0x3ecb: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_3ece:
	/* 0x3ece: test   r12b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3ed2:
	/* 0x3ed2: je     3edf <generic_fexit_event+0x3edf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ed2, 0x3edf, x86_l_3edf);
x86_l_3ed4:
	/* 0x3ed4: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3ed6:
	/* 0x3ed6: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_3eda:
	/* 0x3eda: mov    BYTE PTR [r13+rax*1+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_3edf:
	/* 0x3edf: mov    DWORD PTR [rbp+0x9c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_3ee6:
	/* 0x3ee6: mov    DWORD PTR [rbp+0xa0],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_3eed:
	/* 0x3eed: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3ef1:
	/* 0x3ef1: jmp    42c1 <generic_fexit_event+0x42c1> */
	X86_SIM_X86_JMP(0x3ef1, 0x42c1, x86_l_42c1);
x86_l_3ef6:
	/* 0x3ef6: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3efb:
	/* 0x3efb: mov    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f01:
	/* 0x3f01: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f04:
	/* 0x3f04: jns    3f16 <generic_fexit_event+0x3f16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f04, 0x3f16, x86_l_3f16);
x86_l_3f06:
	/* 0x3f06: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f09:
	/* 0x3f09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f0c:
	/* 0x3f0c: jns    3f23 <generic_fexit_event+0x3f23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f0c, 0x3f23, x86_l_3f23);
x86_l_3f0e:
	/* 0x3f0e: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f10:
	/* 0x3f10: mov    DWORD PTR [r13+0x0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f14:
	/* 0x3f14: jmp    3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_X86_JMP(0x3f14, 0x3f7c, x86_l_3f7c);
x86_l_3f16:
	/* 0x3f16: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3f19:
	/* 0x3f19: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3f1e:
	/* 0x3f1e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f21:
	/* 0x3f21: jmp    3f77 <generic_fexit_event+0x3f77> */
	X86_SIM_X86_JMP(0x3f21, 0x3f77, x86_l_3f77);
x86_l_3f23:
	/* 0x3f23: mov    DWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f2b:
	/* 0x3f2b: jmp    3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_X86_JMP(0x3f2b, 0x3f7c, x86_l_3f7c);
x86_l_3f2d:
	/* 0x3f2d: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f32:
	/* 0x3f32: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3f3a:
	/* 0x3f3a: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f41:
	/* 0x3f41: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f44:
	/* 0x3f44: add    rdx,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_3f48:
	/* 0x3f48: jns    3f6f <generic_fexit_event+0x3f6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f48, 0x3f6f, x86_l_3f6f);
x86_l_3f4a:
	/* 0x3f4a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3f4d:
	/* 0x3f4d: jns    403e <generic_fexit_event+0x403e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f4d, 0x403e, x86_l_403e);
x86_l_3f53:
	/* 0x3f53: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f56:
	/* 0x3f56: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f5b:
	/* 0x3f5b: mov    QWORD PTR [rcx+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_3f62:
	/* 0x3f62: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f66:
	/* 0x3f66: mov    QWORD PTR [rcx+0xb4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_3f6d:
	/* 0x3f6d: jmp    3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_X86_JMP(0x3f6d, 0x3f7c, x86_l_3f7c);
x86_l_3f6f:
	/* 0x3f6f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3f72:
	/* 0x3f72: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3f77:
	/* 0x3f77: call   3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3f7c:
	/* 0x3f7c: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3f81:
	/* 0x3f81: lea    rdi,[rax+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_3f88:
	/* 0x3f88: lea    r13,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_3f8d:
	/* 0x3f8d: add    r12,0xe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 14ULL);
x86_l_3f91:
	/* 0x3f91: jns    3fa2 <generic_fexit_event+0x3fa2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f91, 0x3fa2, x86_l_3fa2);
x86_l_3f93:
	/* 0x3f93: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3f96:
	/* 0x3f96: jns    3fb1 <generic_fexit_event+0x3fb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f96, 0x3fb1, x86_l_3fb1);
x86_l_3f98:
	/* 0x3f98: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3f9d:
	/* 0x3f9d: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fa0:
	/* 0x3fa0: jmp    3fb6 <generic_fexit_event+0x3fb6> */
	X86_SIM_X86_JMP(0x3fa0, 0x3fb6, x86_l_3fb6);
x86_l_3fa2:
	/* 0x3fa2: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3fa7:
	/* 0x3fa7: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3faa:
	/* 0x3faa: call   3faf <generic_fexit_event+0x3faf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3faf:
	/* 0x3faf: jmp    3fb6 <generic_fexit_event+0x3fb6> */
	X86_SIM_X86_JMP(0x3faf, 0x3fb6, x86_l_3fb6);
x86_l_3fb1:
	/* 0x3fb1: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fb6:
	/* 0x3fb6: add    QWORD PTR [rsp+0x10],0xbe */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476926ULL);
x86_l_3fbf:
	/* 0x3fbf: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3fc2:
	/* 0x3fc2: jns    3fd0 <generic_fexit_event+0x3fd0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3fc2, 0x3fd0, x86_l_3fd0);
x86_l_3fc4:
	/* 0x3fc4: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3fc7:
	/* 0x3fc7: jns    3feb <generic_fexit_event+0x3feb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3fc7, 0x3feb, x86_l_3feb);
x86_l_3fc9:
	/* 0x3fc9: movzx  eax,WORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3fce:
	/* 0x3fce: jmp    3fed <generic_fexit_event+0x3fed> */
	X86_SIM_X86_JMP(0x3fce, 0x3fed, x86_l_3fed);
x86_l_3fd0:
	/* 0x3fd0: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3fd5:
	/* 0x3fd5: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3fd8:
	/* 0x3fd8: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3fdd:
	/* 0x3fdd: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3fe0:
	/* 0x3fe0: call   3fe5 <generic_fexit_event+0x3fe5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3fe5:
	/* 0x3fe5: movzx  eax,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3fe9:
	/* 0x3fe9: jmp    3fed <generic_fexit_event+0x3fed> */
	X86_SIM_X86_JMP(0x3fe9, 0x3fed, x86_l_3fed);
x86_l_3feb:
	/* 0x3feb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fed:
	/* 0x3fed: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3ff2:
	/* 0x3ff2: movbe  WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_3ff7:
	/* 0x3ff7: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3ffc:
	/* 0x3ffc: mov    rax,QWORD PTR [rax+0xc4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
x86_l_4003:
	/* 0x4003: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4008:
	/* 0x4008: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_400f:
	/* 0x400f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4014:
	/* 0x4014: call   4019 <generic_fexit_event+0x4019> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4019:
	/* 0x4019: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_401c:
	/* 0x401c: je     4033 <generic_fexit_event+0x4033> */
	X86_SIM_X86_JCC(X86_CC_E, 0x401c, 0x4033, x86_l_4033);
x86_l_401e:
	/* 0x401e: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4020:
	/* 0x4020: mov    DWORD PTR [r15+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4024:
	/* 0x4024: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4028:
	/* 0x4028: mov    QWORD PTR [r15+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_402c:
	/* 0x402c: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_402f:
	/* 0x402f: mov    DWORD PTR [r15+0x7c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_4033:
	/* 0x4033: mov    r12d,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_4039:
	/* 0x4039: jmp    21b7 <generic_fexit_event+0x21b7> */
	X86_SIM_X86_JMP(0x4039, 0x21b7, x86_l_21b7);
x86_l_403e:
	/* 0x403e: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_4046:
	/* 0x4046: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_404e:
	/* 0x404e: jmp    3f7c <generic_fexit_event+0x3f7c> */
	X86_SIM_X86_JMP(0x404e, 0x3f7c, x86_l_3f7c);
x86_l_4053:
	/* 0x4053: mov    WORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4059:
	/* 0x4059: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_405b:
	/* 0x405b: mov    BYTE PTR [rsp+0x80],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_4062:
	/* 0x4062: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_4065:
	/* 0x4065: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_406a:
	/* 0x406a: mov    WORD PTR [rcx+0xc0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_4071:
	/* 0x4071: mov    WORD PTR [rcx+0xc2],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 833223655434ULL);
x86_l_407a:
	/* 0x407a: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4082:
	/* 0x4082: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4086:
	/* 0x4086: jns    40a9 <generic_fexit_event+0x40a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4086, 0x40a9, x86_l_40a9);
x86_l_4088:
	/* 0x4088: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_408b:
	/* 0x408b: jns    40ba <generic_fexit_event+0x40ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x408b, 0x40ba, x86_l_40ba);
x86_l_408d:
	/* 0x408d: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4090:
	/* 0x4090: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4095:
	/* 0x4095: mov    QWORD PTR [rcx+0x9c],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_409c:
	/* 0x409c: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_40a0:
	/* 0x40a0: mov    QWORD PTR [rcx+0xa4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_40a7:
	/* 0x40a7: jmp    40ce <generic_fexit_event+0x40ce> */
	X86_SIM_X86_JMP(0x40a7, 0x40ce, x86_l_40ce);
x86_l_40a9:
	/* 0x40a9: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_40ae:
	/* 0x40ae: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_40b3:
	/* 0x40b3: call   40b8 <generic_fexit_event+0x40b8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_40b8:
	/* 0x40b8: jmp    40ce <generic_fexit_event+0x40ce> */
	X86_SIM_X86_JMP(0x40b8, 0x40ce, x86_l_40ce);
x86_l_40ba:
	/* 0x40ba: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_40bf:
	/* 0x40bf: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_40c7:
	/* 0x40c7: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40ce:
	/* 0x40ce: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_40d3:
	/* 0x40d3: lea    rdi,[rax+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_40da:
	/* 0x40da: add    QWORD PTR [rsp+0x98],0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 652835029016ULL);
x86_l_40e3:
	/* 0x40e3: jns    4128 <generic_fexit_event+0x4128> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x40e3, 0x4128, x86_l_4128);
x86_l_40e5:
	/* 0x40e5: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_40ed:
	/* 0x40ed: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_40f0:
	/* 0x40f0: jns    419c <generic_fexit_event+0x419c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x40f0, 0x419c, x86_l_419c);
x86_l_40f6:
	/* 0x40f6: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_40f9:
	/* 0x40f9: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_40fc:
	/* 0x40fc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40ff:
	/* 0x40ff: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4104:
	/* 0x4104: mov    QWORD PTR [rcx+0xac],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_410b:
	/* 0x410b: mov    rax,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_410f:
	/* 0x410f: mov    QWORD PTR [rcx+0xb4],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_4116:
	/* 0x4116: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_411e:
	/* 0x411e: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_4121:
	/* 0x4121: jne    414b <generic_fexit_event+0x414b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4121, 0x414b, x86_l_414b);
x86_l_4123:
	/* 0x4123: jmp    3b46 <generic_fexit_event+0x3b46> */
	X86_SIM_X86_JMP(0x4123, 0x3b46, x86_l_3b46);
x86_l_4128:
	/* 0x4128: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_412d:
	/* 0x412d: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4135:
	/* 0x4135: call   413a <generic_fexit_event+0x413a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_413a:
	/* 0x413a: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_4142:
	/* 0x4142: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_4145:
	/* 0x4145: je     3b46 <generic_fexit_event+0x3b46> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4145, 0x3b46, x86_l_3b46);
x86_l_414b:
	/* 0x414b: cmp    eax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_414e:
	/* 0x414e: jne    417c <generic_fexit_event+0x417c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x414e, 0x417c, x86_l_417c);
x86_l_4150:
	/* 0x4150: movzx  r12d,WORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 144ULL);
x86_l_4159:
	/* 0x4159: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_415e:
	/* 0x415e: lea    rdi,[rax+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_4165:
	/* 0x4165: add    r12,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_416a:
	/* 0x416a: jns    418d <generic_fexit_event+0x418d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x416a, 0x418d, x86_l_418d);
x86_l_416c:
	/* 0x416c: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_416f:
	/* 0x416f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4172:
	/* 0x4172: jns    41bd <generic_fexit_event+0x41bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4172, 0x41bd, x86_l_41bd);
x86_l_4174:
	/* 0x4174: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_4177:
	/* 0x4177: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_417a:
	/* 0x417a: jmp    41c2 <generic_fexit_event+0x41c2> */
	X86_SIM_X86_JMP(0x417a, 0x41c2, x86_l_41c2);
x86_l_417c:
	/* 0x417c: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4181:
	/* 0x4181: mov    DWORD PTR [rax+0xbc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_418b:
	/* 0x418b: jmp    4203 <generic_fexit_event+0x4203> */
	X86_SIM_X86_JMP(0x418b, 0x4203, x86_l_4203);
x86_l_418d:
	/* 0x418d: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4192:
	/* 0x4192: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4195:
	/* 0x4195: call   419a <generic_fexit_event+0x419a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_419a:
	/* 0x419a: jmp    41c2 <generic_fexit_event+0x41c2> */
	X86_SIM_X86_JMP(0x419a, 0x41c2, x86_l_41c2);
x86_l_419c:
	/* 0x419c: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_41a4:
	/* 0x41a4: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41ab:
	/* 0x41ab: movzx  eax,BYTE PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 128ULL);
x86_l_41b3:
	/* 0x41b3: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_41b6:
	/* 0x41b6: jne    414b <generic_fexit_event+0x414b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x41b6, 0x414b, x86_l_414b);
x86_l_41b8:
	/* 0x41b8: jmp    3b46 <generic_fexit_event+0x3b46> */
	X86_SIM_X86_JMP(0x41b8, 0x3b46, x86_l_3b46);
x86_l_41bd:
	/* 0x41bd: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41c2:
	/* 0x41c2: add    QWORD PTR [rsp+0x10],0xbe */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 68719476926ULL);
x86_l_41cb:
	/* 0x41cb: add    r12,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_41cf:
	/* 0x41cf: jns    41e5 <generic_fexit_event+0x41e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x41cf, 0x41e5, x86_l_41e5);
x86_l_41d1:
	/* 0x41d1: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_41d4:
	/* 0x41d4: jns    41f9 <generic_fexit_event+0x41f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x41d4, 0x41f9, x86_l_41f9);
x86_l_41d6:
	/* 0x41d6: movzx  eax,WORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_41db:
	/* 0x41db: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_41e0:
	/* 0x41e0: mov    WORD PTR [rcx],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41e3:
	/* 0x41e3: jmp    4203 <generic_fexit_event+0x4203> */
	X86_SIM_X86_JMP(0x41e3, 0x4203, x86_l_4203);
x86_l_41e5:
	/* 0x41e5: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_41ea:
	/* 0x41ea: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_41ef:
	/* 0x41ef: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_41f2:
	/* 0x41f2: call   41f7 <generic_fexit_event+0x41f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_41f7:
	/* 0x41f7: jmp    4203 <generic_fexit_event+0x4203> */
	X86_SIM_X86_JMP(0x41f7, 0x4203, x86_l_4203);
x86_l_41f9:
	/* 0x41f9: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_41fe:
	/* 0x41fe: mov    WORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4203:
	/* 0x4203: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4208:
	/* 0x4208: movzx  eax,WORD PTR [rdx+0xbc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 188ULL);
x86_l_420f:
	/* 0x420f: movzx  ecx,WORD PTR [rdx+0xbe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 190ULL);
x86_l_4216:
	/* 0x4216: movbe  WORD PTR [rdx+0xbc],ax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RDX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 188ULL);
x86_l_421f:
	/* 0x421f: movbe  WORD PTR [rdx+0xbe],cx */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RDX, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 190ULL);
x86_l_4228:
	/* 0x4228: mov    rcx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_4230:
	/* 0x4230: add    rcx,0xe0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 224ULL);
x86_l_4237:
	/* 0x4237: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_423a:
	/* 0x423a: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_4240:
	/* 0x4240: jns    4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4240, 0x4295, x86_l_4295);
x86_l_4242:
	/* 0x4242: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4245:
	/* 0x4245: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4248:
	/* 0x4248: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_424b:
	/* 0x424b: je     4295 <generic_fexit_event+0x4295> */
	X86_SIM_X86_JCC(X86_CC_E, 0x424b, 0x4295, x86_l_4295);
x86_l_424d:
	/* 0x424d: lea    rcx,[rdx+0x5] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_4251:
	/* 0x4251: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4253:
	/* 0x4253: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4256:
	/* 0x4256: jns    425d <generic_fexit_event+0x425d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4256, 0x425d, x86_l_425d);
x86_l_4258:
	/* 0x4258: mov    rsi,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_425b:
	/* 0x425b: jmp    425f <generic_fexit_event+0x425f> */
	X86_SIM_X86_JMP(0x425b, 0x425f, x86_l_425f);
x86_l_425d:
	/* 0x425d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_425f:
	/* 0x425f: lea    rcx,[rdx+rsi*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_4263:
	/* 0x4263: lea    rdx,[rdx+rsi*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_4267:
	/* 0x4267: add    rdx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_426b:
	/* 0x426b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_426e:
	/* 0x426e: jns    4272 <generic_fexit_event+0x4272> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x426e, 0x4272, x86_l_4272);
x86_l_4270:
	/* 0x4270: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4272:
	/* 0x4272: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4277:
	/* 0x4277: mov    DWORD PTR [rdx+0xd4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_427d:
	/* 0x427d: add    rcx,0x45 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 69ULL);
x86_l_4281:
	/* 0x4281: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4283:
	/* 0x4283: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4286:
	/* 0x4286: jns    428a <generic_fexit_event+0x428a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4286, 0x428a, x86_l_428a);
x86_l_4288:
	/* 0x4288: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_428a:
	/* 0x428a: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_428f:
	/* 0x428f: mov    DWORD PTR [rcx+0xd8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_4295:
	/* 0x4295: mov    r12d,0x40 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 64ULL);
x86_l_429b:
	/* 0x429b: jmp    42c7 <generic_fexit_event+0x42c7> */
	X86_SIM_X86_JMP(0x429b, 0x42c7, x86_l_42c7);
x86_l_429d:
	/* 0x429d: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42a2:
	/* 0x42a2: mov    BYTE PTR [rax+0x10b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1146756268032ULL);
x86_l_42a9:
	/* 0x42a9: mov    eax,0x6c */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 108ULL);
x86_l_42ae:
	/* 0x42ae: dec    al */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_DEC, 1);
x86_l_42b0:
	/* 0x42b0: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42b5:
	/* 0x42b5: mov    BYTE PTR [rcx+0x9f],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 159ULL);
x86_l_42bb:
	/* 0x42bb: mov    r12d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_42c1:
	/* 0x42c1: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_42c7:
	/* 0x42c7: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_42cc:
	/* 0x42cc: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42d1:
	/* 0x42d1: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_42d4:
	/* 0x42d4: mov    rbp,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_42dc:
	/* 0x42dc: js     42ee <generic_fexit_event+0x42ee> */
	X86_SIM_X86_JCC(X86_CC_S, 0x42dc, 0x42ee, x86_l_42ee);
x86_l_42de:
	/* 0x42de: and    r12d,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_42e5:
	/* 0x42e5: add    r12,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_42e9:
	/* 0x42e9: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_42ec:
	/* 0x42ec: jmp    4302 <generic_fexit_event+0x4302> */
	X86_SIM_X86_JMP(0x42ec, 0x4302, x86_l_4302);
x86_l_42ee:
	/* 0x42ee: mov    DWORD PTR [rsi+0x5ea0],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104045582745599ULL);
x86_l_42f8:
	/* 0x42f8: mov    DWORD PTR [rsi+0x98],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 657129996287ULL);
x86_l_4302:
	/* 0x4302: mov    r15,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_430a:
	/* 0x430a: mov    r12,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_430f:
	/* 0x430f: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4313:
	/* 0x4313: mov    eax,DWORD PTR [r15+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_4317:
	/* 0x4317: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_431a:
	/* 0x431a: jne    1b2 <generic_fexit_event+0x1b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x431a, 0x1b2, x86_l_1b2);
x86_l_4320:
	/* 0x4320: jmp    289 <generic_fexit_event+0x289> */
	X86_SIM_X86_JMP(0x4320, 0x289, x86_l_289);
x86_l_4325:
	/* 0x4325: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_432b:
	/* 0x432b: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x432b, 0x28ad, x86_l_28ad);
x86_l_4330:
	/* 0x4330: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4332:
	/* 0x4332: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4335:
	/* 0x4335: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4338:
	/* 0x4338: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_433b:
	/* 0x433b: test   r13b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_433f:
	/* 0x433f: je     2328 <generic_fexit_event+0x2328> */
	X86_SIM_X86_JCC(X86_CC_E, 0x433f, 0x2328, x86_l_2328);
x86_l_4345:
	/* 0x4345: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4347:
	/* 0x4347: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_434b:
	/* 0x434b: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_434f:
	/* 0x434f: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_4352:
	/* 0x4352: test   r13b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4356:
	/* 0x4356: je     4361 <generic_fexit_event+0x4361> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4356, 0x4361, x86_l_4361);
x86_l_4358:
	/* 0x4358: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_435a:
	/* 0x435a: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_435e:
	/* 0x435e: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4361:
	/* 0x4361: add    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4364:
	/* 0x4364: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_436a:
	/* 0x436a: je     437d <generic_fexit_event+0x437d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x436a, 0x437d, x86_l_437d);
x86_l_436c:
	/* 0x436c: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4371:
	/* 0x4371: sub    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 56ULL);
x86_l_4376:
	/* 0x4376: jne    4384 <generic_fexit_event+0x4384> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4376, 0x4384, x86_l_4384);
x86_l_4378:
	/* 0x4378: jmp    631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JMP(0x4378, 0x631, x86_l_631);
x86_l_437d:
	/* 0x437d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_437f:
	/* 0x437f: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4384:
	/* 0x4384: cmp    QWORD PTR [rsp+0xb0],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244099ULL);
x86_l_438d:
	/* 0x438d: je     631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JCC(X86_CC_E, 0x438d, 0x631, x86_l_631);
x86_l_4393:
	/* 0x4393: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4398:
	/* 0x4398: add    rdx,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_439c:
	/* 0x439c: js     43d1 <generic_fexit_event+0x43d1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x439c, 0x43d1, x86_l_43d1);
x86_l_439e:
	/* 0x439e: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_43a3:
	/* 0x43a3: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_43a8:
	/* 0x43a8: call   43ad <generic_fexit_event+0x43ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_43ad:
	/* 0x43ad: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_43b2:
	/* 0x43b2: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_43b4:
	/* 0x43b4: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x43b4, 0x6ae, x86_l_6ae);
x86_l_43ba:
	/* 0x43ba: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_43bf:
	/* 0x43bf: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_43c4:
	/* 0x43c4: jmp    43f8 <generic_fexit_event+0x43f8> */
	X86_SIM_X86_JMP(0x43c4, 0x43f8, x86_l_43f8);
x86_l_43c6:
	/* 0x43c6: mov    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_43cc:
	/* 0x43cc: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x43cc, 0x28ad, x86_l_28ad);
x86_l_43d1:
	/* 0x43d1: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_43d6:
	/* 0x43d6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_43d9:
	/* 0x43d9: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x43d9, 0x6ae, x86_l_6ae);
x86_l_43df:
	/* 0x43df: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43e2:
	/* 0x43e2: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_43e7:
	/* 0x43e7: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_43eb:
	/* 0x43eb: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_43ee:
	/* 0x43ee: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_43f3:
	/* 0x43f3: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_43f8:
	/* 0x43f8: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_43fd:
	/* 0x43fd: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4402:
	/* 0x4402: cmp    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_4407:
	/* 0x4407: jb     4431 <generic_fexit_event+0x4431> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4407, 0x4431, x86_l_4431);
x86_l_4409:
	/* 0x4409: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_440e:
	/* 0x440e: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4413:
	/* 0x4413: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_4419:
	/* 0x4419: jne    4439 <generic_fexit_event+0x4439> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4419, 0x4439, x86_l_4439);
x86_l_441b:
	/* 0x441b: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4420:
	/* 0x4420: cmp    QWORD PTR [rsp+0x30],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158434302ULL);
x86_l_4429:
	/* 0x4429: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4429, 0x6ae, x86_l_6ae);
x86_l_442f:
	/* 0x442f: jmp    4457 <generic_fexit_event+0x4457> */
	X86_SIM_X86_JMP(0x442f, 0x4457, x86_l_4457);
x86_l_4431:
	/* 0x4431: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_4437:
	/* 0x4437: je     441b <generic_fexit_event+0x441b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4437, 0x441b, x86_l_441b);
x86_l_4439:
	/* 0x4439: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_443e:
	/* 0x443e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4443:
	/* 0x4443: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4448:
	/* 0x4448: cmp    QWORD PTR [rsp+0x30],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158434302ULL);
x86_l_4451:
	/* 0x4451: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4451, 0x6ae, x86_l_6ae);
x86_l_4457:
	/* 0x4457: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_445a:
	/* 0x445a: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_445d:
	/* 0x445d: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4460:
	/* 0x4460: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_4466:
	/* 0x4466: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4469:
	/* 0x4469: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_446e:
	/* 0x446e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4471:
	/* 0x4471: jns    44e4 <generic_fexit_event+0x44e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4471, 0x44e4, x86_l_44e4);
x86_l_4473:
	/* 0x4473: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4476:
	/* 0x4476: jns    486f <generic_fexit_event+0x486f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4476, 0x486f, x86_l_486f);
x86_l_447c:
	/* 0x447c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_447e:
	/* 0x447e: cmp    DWORD PTR [rsp+0x30],0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430216ULL);
x86_l_4483:
	/* 0x4483: jb     449f <generic_fexit_event+0x449f> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4483, 0x449f, x86_l_449f);
x86_l_4485:
	/* 0x4485: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4487:
	/* 0x4487: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4489:
	/* 0x4489: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_448d:
	/* 0x448d: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4491:
	/* 0x4491: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4494:
	/* 0x4494: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_4497:
	/* 0x4497: cmp    ecx,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 48ULL);
x86_l_449b:
	/* 0x449b: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_449d:
	/* 0x449d: jbe    4487 <generic_fexit_event+0x4487> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x449d, 0x4487, x86_l_4487);
x86_l_449f:
	/* 0x449f: test   BYTE PTR [rsp+0x30],0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430212ULL);
x86_l_44a4:
	/* 0x44a4: jne    451e <generic_fexit_event+0x451e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44a4, 0x451e, x86_l_451e);
x86_l_44a6:
	/* 0x44a6: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_44ab:
	/* 0x44ab: jne    4530 <generic_fexit_event+0x4530> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44ab, 0x4530, x86_l_4530);
x86_l_44b1:
	/* 0x44b1: test   BYTE PTR [rsp+0x30],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430209ULL);
x86_l_44b6:
	/* 0x44b6: jne    4544 <generic_fexit_event+0x4544> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x44b6, 0x4544, x86_l_4544);
x86_l_44bc:
	/* 0x44bc: jmp    454d <generic_fexit_event+0x454d> */
	X86_SIM_X86_JMP(0x44bc, 0x454d, x86_l_454d);
x86_l_44c1:
	/* 0x44c1: mov    WORD PTR [rsp+0x90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_44c9:
	/* 0x44c9: jmp    405b <generic_fexit_event+0x405b> */
	X86_SIM_X86_JMP(0x44c9, 0x405b, x86_l_405b);
x86_l_44ce:
	/* 0x44ce: mov    r12d,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_44d4:
	/* 0x44d4: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x44d4, 0x28ad, x86_l_28ad);
x86_l_44d9:
	/* 0x44d9: mov    r12d,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_44df:
	/* 0x44df: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x44df, 0x28ad, x86_l_28ad);
x86_l_44e4:
	/* 0x44e4: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_44e9:
	/* 0x44e9: call   44ee <generic_fexit_event+0x44ee> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_44ee:
	/* 0x44ee: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_44f3:
	/* 0x44f3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_44f5:
	/* 0x44f5: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x44f5, 0x6ae, x86_l_6ae);
x86_l_44fb:
	/* 0x44fb: jmp    454d <generic_fexit_event+0x454d> */
	X86_SIM_X86_JMP(0x44fb, 0x454d, x86_l_454d);
x86_l_44fd:
	/* 0x44fd: mov    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4503:
	/* 0x4503: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x4503, 0x28ad, x86_l_28ad);
x86_l_4508:
	/* 0x4508: mov    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_450e:
	/* 0x450e: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x450e, 0x28ad, x86_l_28ad);
x86_l_4513:
	/* 0x4513: mov    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_4519:
	/* 0x4519: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x4519, 0x28ad, x86_l_28ad);
x86_l_451e:
	/* 0x451e: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4520:
	/* 0x4520: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4523:
	/* 0x4523: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4526:
	/* 0x4526: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_4529:
	/* 0x4529: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_452e:
	/* 0x452e: je     44b1 <generic_fexit_event+0x44b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x452e, 0x44b1, x86_l_44b1);
x86_l_4530:
	/* 0x4530: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4532:
	/* 0x4532: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_4536:
	/* 0x4536: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_453a:
	/* 0x453a: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_453d:
	/* 0x453d: test   BYTE PTR [rsp+0x30],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430209ULL);
x86_l_4542:
	/* 0x4542: je     454d <generic_fexit_event+0x454d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4542, 0x454d, x86_l_454d);
x86_l_4544:
	/* 0x4544: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4546:
	/* 0x4546: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_454a:
	/* 0x454a: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_454d:
	/* 0x454d: add    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_4552:
	/* 0x4552: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_4558:
	/* 0x4558: je     456b <generic_fexit_event+0x456b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4558, 0x456b, x86_l_456b);
x86_l_455a:
	/* 0x455a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_455f:
	/* 0x455f: sub    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 56ULL);
x86_l_4564:
	/* 0x4564: jne    4572 <generic_fexit_event+0x4572> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4564, 0x4572, x86_l_4572);
x86_l_4566:
	/* 0x4566: jmp    631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JMP(0x4566, 0x631, x86_l_631);
x86_l_456b:
	/* 0x456b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_456d:
	/* 0x456d: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4572:
	/* 0x4572: cmp    QWORD PTR [rsp+0xb0],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244101ULL);
x86_l_457b:
	/* 0x457b: jb     631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JCC(X86_CC_B, 0x457b, 0x631, x86_l_631);
x86_l_4581:
	/* 0x4581: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4586:
	/* 0x4586: add    rdx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_458a:
	/* 0x458a: js     45bf <generic_fexit_event+0x45bf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x458a, 0x45bf, x86_l_45bf);
x86_l_458c:
	/* 0x458c: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4591:
	/* 0x4591: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4596:
	/* 0x4596: call   459b <generic_fexit_event+0x459b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_459b:
	/* 0x459b: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_45a0:
	/* 0x45a0: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_45a2:
	/* 0x45a2: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x45a2, 0x6ae, x86_l_6ae);
x86_l_45a8:
	/* 0x45a8: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_45ad:
	/* 0x45ad: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_45b2:
	/* 0x45b2: jmp    45e6 <generic_fexit_event+0x45e6> */
	X86_SIM_X86_JMP(0x45b2, 0x45e6, x86_l_45e6);
x86_l_45b4:
	/* 0x45b4: mov    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_45ba:
	/* 0x45ba: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x45ba, 0x28ad, x86_l_28ad);
x86_l_45bf:
	/* 0x45bf: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_45c4:
	/* 0x45c4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_45c7:
	/* 0x45c7: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45c7, 0x6ae, x86_l_6ae);
x86_l_45cd:
	/* 0x45cd: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45d0:
	/* 0x45d0: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_45d5:
	/* 0x45d5: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_45d9:
	/* 0x45d9: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_45dc:
	/* 0x45dc: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_45e1:
	/* 0x45e1: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_45e6:
	/* 0x45e6: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_45eb:
	/* 0x45eb: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45ee:
	/* 0x45ee: cmp    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_45f3:
	/* 0x45f3: jb     4618 <generic_fexit_event+0x4618> */
	X86_SIM_X86_JCC(X86_CC_B, 0x45f3, 0x4618, x86_l_4618);
x86_l_45f5:
	/* 0x45f5: mov    rbp,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_45fa:
	/* 0x45fa: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_4600:
	/* 0x4600: jne    4620 <generic_fexit_event+0x4620> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4600, 0x4620, x86_l_4620);
x86_l_4602:
	/* 0x4602: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4607:
	/* 0x4607: cmp    QWORD PTR [rsp+0x8],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359742462ULL);
x86_l_4610:
	/* 0x4610: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4610, 0x6ae, x86_l_6ae);
x86_l_4616:
	/* 0x4616: jmp    463c <generic_fexit_event+0x463c> */
	X86_SIM_X86_JMP(0x4616, 0x463c, x86_l_463c);
x86_l_4618:
	/* 0x4618: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_461e:
	/* 0x461e: je     4602 <generic_fexit_event+0x4602> */
	X86_SIM_X86_JCC(X86_CC_E, 0x461e, 0x4602, x86_l_4602);
x86_l_4620:
	/* 0x4620: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4623:
	/* 0x4623: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4628:
	/* 0x4628: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_462d:
	/* 0x462d: cmp    QWORD PTR [rsp+0x8],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359742462ULL);
x86_l_4636:
	/* 0x4636: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4636, 0x6ae, x86_l_6ae);
x86_l_463c:
	/* 0x463c: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4641:
	/* 0x4641: add    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4644:
	/* 0x4644: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4647:
	/* 0x4647: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_464d:
	/* 0x464d: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4650:
	/* 0x4650: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4655:
	/* 0x4655: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4658:
	/* 0x4658: jns    46c9 <generic_fexit_event+0x46c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4658, 0x46c9, x86_l_46c9);
x86_l_465a:
	/* 0x465a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_465d:
	/* 0x465d: jns    46ed <generic_fexit_event+0x46ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x465d, 0x46ed, x86_l_46ed);
x86_l_4663:
	/* 0x4663: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4665:
	/* 0x4665: cmp    DWORD PTR [rsp+0x8],0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738376ULL);
x86_l_466a:
	/* 0x466a: jb     4686 <generic_fexit_event+0x4686> */
	X86_SIM_X86_JCC(X86_CC_B, 0x466a, 0x4686, x86_l_4686);
x86_l_466c:
	/* 0x466c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_466e:
	/* 0x466e: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4670:
	/* 0x4670: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4674:
	/* 0x4674: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4678:
	/* 0x4678: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_467b:
	/* 0x467b: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_467e:
	/* 0x467e: cmp    ecx,DWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_4682:
	/* 0x4682: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4684:
	/* 0x4684: jbe    466e <generic_fexit_event+0x466e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x4684, 0x466e, x86_l_466e);
x86_l_4686:
	/* 0x4686: test   BYTE PTR [rsp+0x8],0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738372ULL);
x86_l_468b:
	/* 0x468b: jne    4704 <generic_fexit_event+0x4704> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x468b, 0x4704, x86_l_4704);
x86_l_468d:
	/* 0x468d: test   BYTE PTR [rsp+0x8],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738370ULL);
x86_l_4692:
	/* 0x4692: jne    4716 <generic_fexit_event+0x4716> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4692, 0x4716, x86_l_4716);
x86_l_4698:
	/* 0x4698: test   BYTE PTR [rsp+0x8],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738369ULL);
x86_l_469d:
	/* 0x469d: jne    472a <generic_fexit_event+0x472a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x469d, 0x472a, x86_l_472a);
x86_l_46a3:
	/* 0x46a3: jmp    4733 <generic_fexit_event+0x4733> */
	X86_SIM_X86_JMP(0x46a3, 0x4733, x86_l_4733);
x86_l_46a8:
	/* 0x46a8: mov    r12d,0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_46ae:
	/* 0x46ae: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x46ae, 0x28ad, x86_l_28ad);
x86_l_46b3:
	/* 0x46b3: mov    r12d,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_46b9:
	/* 0x46b9: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x46b9, 0x28ad, x86_l_28ad);
x86_l_46be:
	/* 0x46be: mov    r12d,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_46c4:
	/* 0x46c4: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x46c4, 0x28ad, x86_l_28ad);
x86_l_46c9:
	/* 0x46c9: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_46ce:
	/* 0x46ce: call   46d3 <generic_fexit_event+0x46d3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_46d3:
	/* 0x46d3: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_46d8:
	/* 0x46d8: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_46da:
	/* 0x46da: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x46da, 0x6ae, x86_l_6ae);
x86_l_46e0:
	/* 0x46e0: jmp    4733 <generic_fexit_event+0x4733> */
	X86_SIM_X86_JMP(0x46e0, 0x4733, x86_l_4733);
x86_l_46e2:
	/* 0x46e2: mov    r12d,0xf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_46e8:
	/* 0x46e8: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x46e8, 0x28ad, x86_l_28ad);
x86_l_46ed:
	/* 0x46ed: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46ef:
	/* 0x46ef: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_46f4:
	/* 0x46f4: jmp    6a4 <generic_fexit_event+0x6a4> */
	X86_SIM_X86_JMP(0x46f4, 0x6a4, x86_l_6a4);
x86_l_46f9:
	/* 0x46f9: mov    r12d,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_46ff:
	/* 0x46ff: jmp    28ad <generic_fexit_event+0x28ad> */
	X86_SIM_X86_JMP(0x46ff, 0x28ad, x86_l_28ad);
x86_l_4704:
	/* 0x4704: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4706:
	/* 0x4706: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4709:
	/* 0x4709: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_470c:
	/* 0x470c: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_470f:
	/* 0x470f: test   BYTE PTR [rsp+0x8],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738370ULL);
x86_l_4714:
	/* 0x4714: je     4698 <generic_fexit_event+0x4698> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4714, 0x4698, x86_l_4698);
x86_l_4716:
	/* 0x4716: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4718:
	/* 0x4718: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_471c:
	/* 0x471c: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4720:
	/* 0x4720: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_4723:
	/* 0x4723: test   BYTE PTR [rsp+0x8],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 34359738369ULL);
x86_l_4728:
	/* 0x4728: je     4733 <generic_fexit_event+0x4733> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4728, 0x4733, x86_l_4733);
x86_l_472a:
	/* 0x472a: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_472c:
	/* 0x472c: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_4730:
	/* 0x4730: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4733:
	/* 0x4733: add    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_4738:
	/* 0x4738: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_473e:
	/* 0x473e: je     474c <generic_fexit_event+0x474c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x473e, 0x474c, x86_l_474c);
x86_l_4740:
	/* 0x4740: sub    QWORD PTR [rsp+0x38],rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 56ULL);
x86_l_4745:
	/* 0x4745: jne    4753 <generic_fexit_event+0x4753> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4745, 0x4753, x86_l_4753);
x86_l_4747:
	/* 0x4747: jmp    631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JMP(0x4747, 0x631, x86_l_631);
x86_l_474c:
	/* 0x474c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_474e:
	/* 0x474e: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4753:
	/* 0x4753: cmp    QWORD PTR [rsp+0xb0],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244101ULL);
x86_l_475c:
	/* 0x475c: je     631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JCC(X86_CC_E, 0x475c, 0x631, x86_l_631);
x86_l_4762:
	/* 0x4762: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4767:
	/* 0x4767: add    rdx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_476b:
	/* 0x476b: js     4795 <generic_fexit_event+0x4795> */
	X86_SIM_X86_JCC(X86_CC_S, 0x476b, 0x4795, x86_l_4795);
x86_l_476d:
	/* 0x476d: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4772:
	/* 0x4772: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4777:
	/* 0x4777: call   477c <generic_fexit_event+0x477c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_477c:
	/* 0x477c: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_4781:
	/* 0x4781: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4783:
	/* 0x4783: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4783, 0x6ae, x86_l_6ae);
x86_l_4789:
	/* 0x4789: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_478e:
	/* 0x478e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4793:
	/* 0x4793: jmp    47bc <generic_fexit_event+0x47bc> */
	X86_SIM_X86_JMP(0x4793, 0x47bc, x86_l_47bc);
x86_l_4795:
	/* 0x4795: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_479a:
	/* 0x479a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_479d:
	/* 0x479d: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x479d, 0x6ae, x86_l_6ae);
x86_l_47a3:
	/* 0x47a3: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47a6:
	/* 0x47a6: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_47ab:
	/* 0x47ab: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_47af:
	/* 0x47af: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_47b2:
	/* 0x47b2: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_47b7:
	/* 0x47b7: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_47bc:
	/* 0x47bc: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_47c1:
	/* 0x47c1: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_47c4:
	/* 0x47c4: cmp    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_47c9:
	/* 0x47c9: jb     47ee <generic_fexit_event+0x47ee> */
	X86_SIM_X86_JCC(X86_CC_B, 0x47c9, 0x47ee, x86_l_47ee);
x86_l_47cb:
	/* 0x47cb: mov    rbp,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_47d0:
	/* 0x47d0: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_47d6:
	/* 0x47d6: jne    47f6 <generic_fexit_event+0x47f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x47d6, 0x47f6, x86_l_47f6);
x86_l_47d8:
	/* 0x47d8: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_47dd:
	/* 0x47dd: cmp    QWORD PTR [rsp+0x30],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158434302ULL);
x86_l_47e6:
	/* 0x47e6: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x47e6, 0x6ae, x86_l_6ae);
x86_l_47ec:
	/* 0x47ec: jmp    4812 <generic_fexit_event+0x4812> */
	X86_SIM_X86_JMP(0x47ec, 0x4812, x86_l_4812);
x86_l_47ee:
	/* 0x47ee: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_47f4:
	/* 0x47f4: je     47d8 <generic_fexit_event+0x47d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x47f4, 0x47d8, x86_l_47d8);
x86_l_47f6:
	/* 0x47f6: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_47f9:
	/* 0x47f9: mov    QWORD PTR [rsp+0x30],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_47fe:
	/* 0x47fe: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4803:
	/* 0x4803: cmp    QWORD PTR [rsp+0x30],0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158434302ULL);
x86_l_480c:
	/* 0x480c: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x480c, 0x6ae, x86_l_6ae);
x86_l_4812:
	/* 0x4812: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4817:
	/* 0x4817: add    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_481a:
	/* 0x481a: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_481d:
	/* 0x481d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_4823:
	/* 0x4823: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4826:
	/* 0x4826: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_482b:
	/* 0x482b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_482e:
	/* 0x482e: jns    487b <generic_fexit_event+0x487b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x482e, 0x487b, x86_l_487b);
x86_l_4830:
	/* 0x4830: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4833:
	/* 0x4833: jns    486f <generic_fexit_event+0x486f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4833, 0x486f, x86_l_486f);
x86_l_4835:
	/* 0x4835: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4837:
	/* 0x4837: cmp    DWORD PTR [rsp+0x30],0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430216ULL);
x86_l_483c:
	/* 0x483c: jb     4858 <generic_fexit_event+0x4858> */
	X86_SIM_X86_JCC(X86_CC_B, 0x483c, 0x4858, x86_l_4858);
x86_l_483e:
	/* 0x483e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4840:
	/* 0x4840: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4842:
	/* 0x4842: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4846:
	/* 0x4846: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_484a:
	/* 0x484a: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_484d:
	/* 0x484d: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_4850:
	/* 0x4850: cmp    ecx,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 48ULL);
x86_l_4854:
	/* 0x4854: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4856:
	/* 0x4856: jbe    4840 <generic_fexit_event+0x4840> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x4856, 0x4840, x86_l_4840);
x86_l_4858:
	/* 0x4858: test   BYTE PTR [rsp+0x30],0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430212ULL);
x86_l_485d:
	/* 0x485d: jne    4894 <generic_fexit_event+0x4894> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x485d, 0x4894, x86_l_4894);
x86_l_485f:
	/* 0x485f: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_4864:
	/* 0x4864: jne    48a6 <generic_fexit_event+0x48a6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4864, 0x48a6, x86_l_48a6);
x86_l_4866:
	/* 0x4866: test   BYTE PTR [rsp+0x30],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430209ULL);
x86_l_486b:
	/* 0x486b: jne    48ba <generic_fexit_event+0x48ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x486b, 0x48ba, x86_l_48ba);
x86_l_486d:
	/* 0x486d: jmp    48c3 <generic_fexit_event+0x48c3> */
	X86_SIM_X86_JMP(0x486d, 0x48c3, x86_l_48c3);
x86_l_486f:
	/* 0x486f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4871:
	/* 0x4871: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4876:
	/* 0x4876: jmp    6a4 <generic_fexit_event+0x6a4> */
	X86_SIM_X86_JMP(0x4876, 0x6a4, x86_l_6a4);
x86_l_487b:
	/* 0x487b: mov    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4880:
	/* 0x4880: call   4885 <generic_fexit_event+0x4885> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4885:
	/* 0x4885: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_488a:
	/* 0x488a: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_488c:
	/* 0x488c: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x488c, 0x6ae, x86_l_6ae);
x86_l_4892:
	/* 0x4892: jmp    48c3 <generic_fexit_event+0x48c3> */
	X86_SIM_X86_JMP(0x4892, 0x48c3, x86_l_48c3);
x86_l_4894:
	/* 0x4894: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4896:
	/* 0x4896: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4899:
	/* 0x4899: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_489c:
	/* 0x489c: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_489f:
	/* 0x489f: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_48a4:
	/* 0x48a4: je     4866 <generic_fexit_event+0x4866> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48a4, 0x4866, x86_l_4866);
x86_l_48a6:
	/* 0x48a6: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_48a8:
	/* 0x48a8: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_48ac:
	/* 0x48ac: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_48b0:
	/* 0x48b0: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_48b3:
	/* 0x48b3: test   BYTE PTR [rsp+0x30],0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430209ULL);
x86_l_48b8:
	/* 0x48b8: je     48c3 <generic_fexit_event+0x48c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48b8, 0x48c3, x86_l_48c3);
x86_l_48ba:
	/* 0x48ba: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_48bc:
	/* 0x48bc: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_48c0:
	/* 0x48c0: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_48c3:
	/* 0x48c3: add    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_48c8:
	/* 0x48c8: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_48ce:
	/* 0x48ce: je     48dc <generic_fexit_event+0x48dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48ce, 0x48dc, x86_l_48dc);
x86_l_48d0:
	/* 0x48d0: sub    QWORD PTR [rsp+0x38],rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_SUB)), 56ULL);
x86_l_48d5:
	/* 0x48d5: jne    48e3 <generic_fexit_event+0x48e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x48d5, 0x48e3, x86_l_48e3);
x86_l_48d7:
	/* 0x48d7: jmp    631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JMP(0x48d7, 0x631, x86_l_631);
x86_l_48dc:
	/* 0x48dc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_48de:
	/* 0x48de: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_48e3:
	/* 0x48e3: cmp    QWORD PTR [rsp+0xb0],0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244103ULL);
x86_l_48ec:
	/* 0x48ec: jb     631 <generic_fexit_event+0x631> */
	X86_SIM_X86_JCC(X86_CC_B, 0x48ec, 0x631, x86_l_631);
x86_l_48f2:
	/* 0x48f2: add    QWORD PTR [rsp+0x18],0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 103079215200ULL);
x86_l_48f8:
	/* 0x48f8: js     4922 <generic_fexit_event+0x4922> */
	X86_SIM_X86_JCC(X86_CC_S, 0x48f8, 0x4922, x86_l_4922);
x86_l_48fa:
	/* 0x48fa: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_48ff:
	/* 0x48ff: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4904:
	/* 0x4904: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4909:
	/* 0x4909: call   490e <generic_fexit_event+0x490e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_490e:
	/* 0x490e: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_4913:
	/* 0x4913: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4915:
	/* 0x4915: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4915, 0x6ae, x86_l_6ae);
x86_l_491b:
	/* 0x491b: mov    rbp,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_4920:
	/* 0x4920: jmp    494c <generic_fexit_event+0x494c> */
	X86_SIM_X86_JMP(0x4920, 0x494c, x86_l_494c);
x86_l_4922:
	/* 0x4922: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4927:
	/* 0x4927: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_492c:
	/* 0x492c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_492f:
	/* 0x492f: jns    6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x492f, 0x6ae, x86_l_6ae);
x86_l_4935:
	/* 0x4935: mov    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4938:
	/* 0x4938: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_493b:
	/* 0x493b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_493e:
	/* 0x493e: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4943:
	/* 0x4943: mov    rbp,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4947:
	/* 0x4947: mov    QWORD PTR [rsp+0x48],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_494c:
	/* 0x494c: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_494f:
	/* 0x494f: cmp    rbp,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_4954:
	/* 0x4954: jb     4977 <generic_fexit_event+0x4977> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4954, 0x4977, x86_l_4977);
x86_l_4956:
	/* 0x4956: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_495b:
	/* 0x495b: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_4961:
	/* 0x4961: jne    497f <generic_fexit_event+0x497f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4961, 0x497f, x86_l_497f);
x86_l_4963:
	/* 0x4963: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4968:
	/* 0x4968: cmp    rbp,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_496f:
	/* 0x496f: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x496f, 0x6ae, x86_l_6ae);
x86_l_4975:
	/* 0x4975: jmp    4994 <generic_fexit_event+0x4994> */
	X86_SIM_X86_JMP(0x4975, 0x4994, x86_l_4994);
x86_l_4977:
	/* 0x4977: cmp    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_497d:
	/* 0x497d: je     4963 <generic_fexit_event+0x4963> */
	X86_SIM_X86_JCC(X86_CC_E, 0x497d, 0x4963, x86_l_4963);
x86_l_497f:
	/* 0x497f: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4982:
	/* 0x4982: mov    ecx,0xfffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967293ULL);
x86_l_4987:
	/* 0x4987: cmp    rbp,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_498e:
	/* 0x498e: ja     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_A, 0x498e, 0x6ae, x86_l_6ae);
x86_l_4994:
	/* 0x4994: mov    rdi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4999:
	/* 0x4999: add    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_499c:
	/* 0x499c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_49a2:
	/* 0x49a2: add    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_49a5:
	/* 0x49a5: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_49aa:
	/* 0x49aa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_49ad:
	/* 0x49ad: jns    49e7 <generic_fexit_event+0x49e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x49ad, 0x49e7, x86_l_49e7);
x86_l_49af:
	/* 0x49af: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_49b2:
	/* 0x49b2: jns    49fd <generic_fexit_event+0x49fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x49b2, 0x49fd, x86_l_49fd);
x86_l_49b4:
	/* 0x49b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49b6:
	/* 0x49b6: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_49b9:
	/* 0x49b9: jb     49d3 <generic_fexit_event+0x49d3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x49b9, 0x49d3, x86_l_49d3);
x86_l_49bb:
	/* 0x49bb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49bd:
	/* 0x49bd: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_49bf:
	/* 0x49bf: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_49c3:
	/* 0x49c3: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_49c7:
	/* 0x49c7: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_49ca:
	/* 0x49ca: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_49cd:
	/* 0x49cd: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_49cf:
	/* 0x49cf: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_49d1:
	/* 0x49d1: jbe    49bd <generic_fexit_event+0x49bd> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x49d1, 0x49bd, x86_l_49bd);
x86_l_49d3:
	/* 0x49d3: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_49d7:
	/* 0x49d7: jne    4a07 <generic_fexit_event+0x4a07> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49d7, 0x4a07, x86_l_4a07);
x86_l_49d9:
	/* 0x49d9: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_49dd:
	/* 0x49dd: jne    4a18 <generic_fexit_event+0x4a18> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49dd, 0x4a18, x86_l_4a18);
x86_l_49df:
	/* 0x49df: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_49e3:
	/* 0x49e3: jne    4a2b <generic_fexit_event+0x4a2b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x49e3, 0x4a2b, x86_l_4a2b);
x86_l_49e5:
	/* 0x49e5: jmp    4a34 <generic_fexit_event+0x4a34> */
	X86_SIM_X86_JMP(0x49e5, 0x4a34, x86_l_4a34);
x86_l_49e7:
	/* 0x49e7: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_49e9:
	/* 0x49e9: call   49ee <generic_fexit_event+0x49ee> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_49ee:
	/* 0x49ee: mov    ecx,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967294ULL);
x86_l_49f3:
	/* 0x49f3: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_49f5:
	/* 0x49f5: js     6ae <generic_fexit_event+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x49f5, 0x6ae, x86_l_6ae);
x86_l_49fb:
	/* 0x49fb: jmp    4a34 <generic_fexit_event+0x4a34> */
	X86_SIM_X86_JMP(0x49fb, 0x4a34, x86_l_4a34);
x86_l_49fd:
	/* 0x49fd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49ff:
	/* 0x49ff: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4a02:
	/* 0x4a02: jmp    6a4 <generic_fexit_event+0x6a4> */
	X86_SIM_X86_JMP(0x4a02, 0x6a4, x86_l_6a4);
x86_l_4a07:
	/* 0x4a07: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4a09:
	/* 0x4a09: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4a0c:
	/* 0x4a0c: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4a0f:
	/* 0x4a0f: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_4a12:
	/* 0x4a12: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_4a16:
	/* 0x4a16: je     49df <generic_fexit_event+0x49df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a16, 0x49df, x86_l_49df);
x86_l_4a18:
	/* 0x4a18: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4a1a:
	/* 0x4a1a: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_4a1e:
	/* 0x4a1e: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4a22:
	/* 0x4a22: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_4a25:
	/* 0x4a25: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4a29:
	/* 0x4a29: je     4a34 <generic_fexit_event+0x4a34> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a29, 0x4a34, x86_l_4a34);
x86_l_4a2b:
	/* 0x4a2b: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_4a2d:
	/* 0x4a2d: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_4a31:
	/* 0x4a31: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4a34:
	/* 0x4a34: add    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4a37:
	/* 0x4a37: jmp    3d7 <generic_fexit_event+0x3d7> */
	X86_SIM_X86_JMP(0x4a37, 0x3d7, x86_l_3d7);
x86_l_4d6c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_4a3c */
x86_l_4a3c:
	/* 0x4a3c: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4a3d:
	/* 0x4a3d: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4a3f:
	/* 0x4a3f: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4a41:
	/* 0x4a41: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4a43:
	/* 0x4a43: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4a45:
	/* 0x4a45: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4a46:
	/* 0x4a46: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_4a4a:
	/* 0x4a4a: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4a4d:
	/* 0x4a4d: mov    r12,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a51:
	/* 0x4a51: mov    rdx,QWORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4a55:
	/* 0x4a55: mov    r15,QWORD PTR [rsi+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4a59:
	/* 0x4a59: cmp    r12,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_R12, X86_RSI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_4a5c:
	/* 0x4a5c: jne    4a68 <cwd_read_v61+0x2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a5c, 0x4a68, x86_l_4a68);
x86_l_4a5e:
	/* 0x4a5e: cmp    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_4a62:
	/* 0x4a62: je     4bcd <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4a62, 0x4bcd, x86_l_4bcd);
x86_l_4a68:
	/* 0x4a68: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4a6b:
	/* 0x4a6b: jns    4a88 <cwd_read_v61+0x4c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4a6b, 0x4a88, x86_l_4a88);
x86_l_4a6d:
	/* 0x4a6d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4a70:
	/* 0x4a70: jns    4aaa <cwd_read_v61+0x6e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4a70, 0x4aaa, x86_l_4aaa);
x86_l_4a72:
	/* 0x4a72: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a75:
	/* 0x4a75: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a7a:
	/* 0x4a7a: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a7e:
	/* 0x4a7e: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a81:
	/* 0x4a81: jne    4ac2 <cwd_read_v61+0x86> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a81, 0x4ac2, x86_l_4ac2);
x86_l_4a83:
	/* 0x4a83: jmp    4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x4a83, 0x4b55, x86_l_4b55);
x86_l_4a88:
	/* 0x4a88: lea    rdi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a8d:
	/* 0x4a8d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4a92:
	/* 0x4a92: call   4a97 <cwd_read_v61+0x5b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4a97:
	/* 0x4a97: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a9c:
	/* 0x4a9c: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4aa0:
	/* 0x4aa0: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4aa3:
	/* 0x4aa3: jne    4ac2 <cwd_read_v61+0x86> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4aa3, 0x4ac2, x86_l_4ac2);
x86_l_4aa5:
	/* 0x4aa5: jmp    4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x4aa5, 0x4b55, x86_l_4b55);
x86_l_4aaa:
	/* 0x4aaa: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_4ab3:
	/* 0x4ab3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ab5:
	/* 0x4ab5: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4ab9:
	/* 0x4ab9: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4abc:
	/* 0x4abc: je     4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4abc, 0x4b55, x86_l_4b55);
x86_l_4ac2:
	/* 0x4ac2: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4ac5:
	/* 0x4ac5: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_4ac9:
	/* 0x4ac9: jns    4add <cwd_read_v61+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4ac9, 0x4add, x86_l_4add);
x86_l_4acb:
	/* 0x4acb: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4ace:
	/* 0x4ace: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ad1:
	/* 0x4ad1: jns    4b13 <cwd_read_v61+0xd7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4ad1, 0x4b13, x86_l_4b13);
x86_l_4ad3:
	/* 0x4ad3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ad6:
	/* 0x4ad6: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ad9:
	/* 0x4ad9: jne    4b18 <cwd_read_v61+0xdc> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4ad9, 0x4b18, x86_l_4b18);
x86_l_4adb:
	/* 0x4adb: jmp    4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JMP(0x4adb, 0x4b55, x86_l_4b55);
x86_l_4add:
	/* 0x4add: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ae2:
	/* 0x4ae2: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4ae7:
	/* 0x4ae7: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4aea:
	/* 0x4aea: call   4aef <cwd_read_v61+0xb3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4aef:
	/* 0x4aef: cmp    QWORD PTR [rsp+0x8],r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4af4:
	/* 0x4af4: je     4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4af4, 0x4b55, x86_l_4b55);
x86_l_4af6:
	/* 0x4af6: lea    rdi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4afb:
	/* 0x4afb: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4b00:
	/* 0x4b00: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4b03:
	/* 0x4b03: call   4b08 <cwd_read_v61+0xcc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4b08:
	/* 0x4b08: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_4b0c:
	/* 0x4b0c: jns    4b34 <cwd_read_v61+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b0c, 0x4b34, x86_l_4b34);
x86_l_4b0e:
	/* 0x4b0e: jmp    4bee <cwd_read_v61+0x1b2> */
	X86_SIM_X86_SUB_JMP(0x4b0e, 0x4bee, x86_l_4bee);
x86_l_4b13:
	/* 0x4b13: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4b16:
	/* 0x4b16: je     4b55 <cwd_read_v61+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4b16, 0x4b55, x86_l_4b55);
x86_l_4b18:
	/* 0x4b18: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4b1b:
	/* 0x4b1b: jns    4bdb <cwd_read_v61+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b1b, 0x4bdb, x86_l_4bdb);
x86_l_4b21:
	/* 0x4b21: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b25:
	/* 0x4b25: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b2a:
	/* 0x4b2a: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_4b2e:
	/* 0x4b2e: js     4bee <cwd_read_v61+0x1b2> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x4b2e, 0x4bee, x86_l_4bee);
x86_l_4b34:
	/* 0x4b34: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b39:
	/* 0x4b39: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_4b3e:
	/* 0x4b3e: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4b41:
	/* 0x4b41: call   4b46 <cwd_read_v61+0x10a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4b46:
	/* 0x4b46: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4b4b:
	/* 0x4b4b: mov    r15d,DWORD PTR [rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4b50:
	/* 0x4b50: jmp    4c23 <cwd_read_v61+0x1e7> */
	X86_SIM_X86_SUB_JMP(0x4b50, 0x4c23, x86_l_4c23);
x86_l_4b55:
	/* 0x4b55: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4b58:
	/* 0x4b58: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4b5c:
	/* 0x4b5c: jns    4b73 <cwd_read_v61+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b5c, 0x4b73, x86_l_4b73);
x86_l_4b5e:
	/* 0x4b5e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4b61:
	/* 0x4b61: jns    4bbc <cwd_read_v61+0x180> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b61, 0x4bbc, x86_l_4bbc);
x86_l_4b63:
	/* 0x4b63: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b66:
	/* 0x4b66: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b6b:
	/* 0x4b6b: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4b6f:
	/* 0x4b6f: jne    4b8d <cwd_read_v61+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4b6f, 0x4b8d, x86_l_4b8d);
x86_l_4b71:
	/* 0x4b71: jmp    4bcd <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JMP(0x4b71, 0x4bcd, x86_l_4bcd);
x86_l_4b73:
	/* 0x4b73: lea    rdi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b78:
	/* 0x4b78: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4b7d:
	/* 0x4b7d: call   4b82 <cwd_read_v61+0x146> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4b82:
	/* 0x4b82: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4b87:
	/* 0x4b87: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4b8b:
	/* 0x4b8b: je     4bcd <cwd_read_v61+0x191> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4b8b, 0x4bcd, x86_l_4bcd);
x86_l_4b8d:
	/* 0x4b8d: add    r15,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_4b91:
	/* 0x4b91: jns    4ba7 <cwd_read_v61+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b91, 0x4ba7, x86_l_4ba7);
x86_l_4b93:
	/* 0x4b93: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4b96:
	/* 0x4b96: jns    4cd8 <cwd_read_v61+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4b96, 0x4cd8, x86_l_4cd8);
x86_l_4b9c:
	/* 0x4b9c: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b9f:
	/* 0x4b9f: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ba2:
	/* 0x4ba2: jmp    4cdf <cwd_read_v61+0x2a3> */
	X86_SIM_X86_SUB_JMP(0x4ba2, 0x4cdf, x86_l_4cdf);
x86_l_4ba7:
	/* 0x4ba7: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4baa:
	/* 0x4baa: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4baf:
	/* 0x4baf: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4bb2:
	/* 0x4bb2: call   4bb7 <cwd_read_v61+0x17b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4bb7:
	/* 0x4bb7: jmp    4cdf <cwd_read_v61+0x2a3> */
	X86_SIM_X86_SUB_JMP(0x4bb7, 0x4cdf, x86_l_4cdf);
x86_l_4bbc:
	/* 0x4bbc: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_4bc5:
	/* 0x4bc5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4bc7:
	/* 0x4bc7: cmp    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4bcb:
	/* 0x4bcb: jne    4b8d <cwd_read_v61+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4bcb, 0x4b8d, x86_l_4b8d);
x86_l_4bcd:
	/* 0x4bcd: mov    BYTE PTR [rbx+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_4bd1:
	/* 0x4bd1: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4bd6:
	/* 0x4bd6: jmp    4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JMP(0x4bd6, 0x4cf2, x86_l_4cf2);
x86_l_4bdb:
	/* 0x4bdb: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_4be4:
	/* 0x4be4: add    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_4be8:
	/* 0x4be8: jns    4b34 <cwd_read_v61+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4be8, 0x4b34, x86_l_4b34);
x86_l_4bee:
	/* 0x4bee: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_4bf1:
	/* 0x4bf1: jns    4c0c <cwd_read_v61+0x1d0> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4bf1, 0x4c0c, x86_l_4c0c);
x86_l_4bf3:
	/* 0x4bf3: mov    r15,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4bf7:
	/* 0x4bf7: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4bfc:
	/* 0x4bfc: mov    rdx,QWORD PTR [r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4c01:
	/* 0x4c01: mov    QWORD PTR [rsp+0x10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c06:
	/* 0x4c06: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_4c0a:
	/* 0x4c0a: jmp    4c23 <cwd_read_v61+0x1e7> */
	X86_SIM_X86_SUB_JMP(0x4c0a, 0x4c23, x86_l_4c23);
x86_l_4c0c:
	/* 0x4c0c: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_4c15:
	/* 0x4c15: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_4c1e:
	/* 0x4c1e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c21:
	/* 0x4c21: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c23:
	/* 0x4c23: mov    rdi,QWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c27:
	/* 0x4c27: mov    r8,QWORD PTR [rbx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4c2b:
	/* 0x4c2b: sub    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4c2e:
	/* 0x4c2e: mov    ebp,DWORD PTR [rbx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4c31:
	/* 0x4c31: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c33:
	/* 0x4c33: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c36:
	/* 0x4c36: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4c39:
	/* 0x4c39: mov    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_4c3b:
	/* 0x4c3b: sub    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBP, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_4c3d:
	/* 0x4c3d: cmovb  esi,eax */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RAX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_4c40:
	/* 0x4c40: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_4c43:
	/* 0x4c43: ja     4c48 <cwd_read_v61+0x20c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4c43, 0x4c48, x86_l_4c48);
x86_l_4c45:
	/* 0x4c45: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4c48:
	/* 0x4c48: mov    r9b,al */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_4c4b:
	/* 0x4c4b: add    r9d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_4c4e:
	/* 0x4c4e: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_4c50:
	/* 0x4c50: sub    eax,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_4c53:
	/* 0x4c53: mov    DWORD PTR [rbx+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4c56:
	/* 0x4c56: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4c5b:
	/* 0x4c5b: sub    r8,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R9, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_4c5e:
	/* 0x4c5e: jb     4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4c5e, 0x4cf2, x86_l_4cf2);
x86_l_4c64:
	/* 0x4c64: cmp    r8,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_4c6b:
	/* 0x4c6b: ja     4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4c6b, 0x4cf2, x86_l_4cf2);
x86_l_4c71:
	/* 0x4c71: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4c74:
	/* 0x4c74: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4c77:
	/* 0x4c77: jbe    4c7e <cwd_read_v61+0x242> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4c77, 0x4c7e, x86_l_4c7e);
x86_l_4c79:
	/* 0x4c79: mov    BYTE PTR [rdi+r8*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 47ULL);
x86_l_4c7e:
	/* 0x4c7e: lea    r12,[rdi+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4c82:
	/* 0x4c82: cmp    r15d,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_4c85:
	/* 0x4c85: movzx  esi,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RSI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_4c88:
	/* 0x4c88: adc    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_64, X86_ALU_ADC, 0);
x86_l_4c8b:
	/* 0x4c8b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4c8e:
	/* 0x4c8e: jns    4d01 <cwd_read_v61+0x2c5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4c8e, 0x4d01, x86_l_4d01);
x86_l_4c90:
	/* 0x4c90: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4c93:
	/* 0x4c93: jns    4d08 <cwd_read_v61+0x2cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x4c93, 0x4d08, x86_l_4d08);
x86_l_4c95:
	/* 0x4c95: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c98:
	/* 0x4c98: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_4c9b:
	/* 0x4c9b: jb     4cba <cwd_read_v61+0x27e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4c9b, 0x4cba, x86_l_4cba);
x86_l_4c9d:
	/* 0x4c9d: mov    esi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_4c9f:
	/* 0x4c9f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ca2:
	/* 0x4ca2: mov    r9,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_4ca5:
	/* 0x4ca5: mov    r8,QWORD PTR [rdx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_4ca9:
	/* 0x4ca9: mov    QWORD PTR [rdi+r9*1],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_4cad:
	/* 0x4cad: lea    r8,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4cb1:
	/* 0x4cb1: add    r9,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4cb5:
	/* 0x4cb5: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4cb8:
	/* 0x4cb8: jbe    4ca2 <cwd_read_v61+0x266> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4cb8, 0x4ca2, x86_l_4ca2);
x86_l_4cba:
	/* 0x4cba: test   cl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_4cbd:
	/* 0x4cbd: jne    4d29 <cwd_read_v61+0x2ed> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4cbd, 0x4d29, x86_l_4d29);
x86_l_4cbf:
	/* 0x4cbf: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_4cc2:
	/* 0x4cc2: jne    4d3d <cwd_read_v61+0x301> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4cc2, 0x4d3d, x86_l_4d3d);
x86_l_4cc4:
	/* 0x4cc4: test   cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4cc7:
	/* 0x4cc7: jne    4d57 <cwd_read_v61+0x31b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4cc7, 0x4d57, x86_l_4d57);
x86_l_4ccd:
	/* 0x4ccd: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4cd1:
	/* 0x4cd1: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4cd4:
	/* 0x4cd4: jbe    4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4cd4, 0x4cf2, x86_l_4cf2);
x86_l_4cd6:
	/* 0x4cd6: jmp    4d1f <cwd_read_v61+0x2e3> */
	X86_SIM_X86_SUB_JMP(0x4cd6, 0x4d1f, x86_l_4d1f);
x86_l_4cd8:
	/* 0x4cd8: mov    QWORD PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4cdf:
	/* 0x4cdf: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ce4:
	/* 0x4ce4: mov    QWORD PTR [rbx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4ce8:
	/* 0x4ce8: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_4cec:
	/* 0x4cec: mov    QWORD PTR [rbx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4cf0:
	/* 0x4cf0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4cf2:
	/* 0x4cf2: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_4cf6:
	/* 0x4cf6: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4cf7:
	/* 0x4cf7: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4cf9:
	/* 0x4cf9: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4cfb:
	/* 0x4cfb: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4cfd:
	/* 0x4cfd: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4cff:
	/* 0x4cff: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4d00:
	/* 0x4d00: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4d00);
x86_l_4d01:
	/* 0x4d01: call   4d06 <cwd_read_v61+0x2ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4d06:
	/* 0x4d06: jmp    4d11 <cwd_read_v61+0x2d5> */
	X86_SIM_X86_SUB_JMP(0x4d06, 0x4d11, x86_l_4d11);
x86_l_4d08:
	/* 0x4d08: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_4d0a:
	/* 0x4d0a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d0c:
	/* 0x4d0c: call   4d11 <cwd_read_v61+0x2d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_4d11:
	/* 0x4d11: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4d16:
	/* 0x4d16: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d1a:
	/* 0x4d1a: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4d1d:
	/* 0x4d1d: jbe    4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4d1d, 0x4cf2, x86_l_4cf2);
x86_l_4d1f:
	/* 0x4d1f: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4d24:
	/* 0x4d24: mov    QWORD PTR [r14],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d27:
	/* 0x4d27: jmp    4cf0 <cwd_read_v61+0x2b4> */
	X86_SIM_X86_SUB_JMP(0x4d27, 0x4cf0, x86_l_4cf0);
x86_l_4d29:
	/* 0x4d29: mov    esi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_4d2c:
	/* 0x4d2c: mov    r9d,DWORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_4d30:
	/* 0x4d30: mov    DWORD PTR [rdi+rsi*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_4d34:
	/* 0x4d34: or     r8d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_4d38:
	/* 0x4d38: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_4d3b:
	/* 0x4d3b: je     4cc4 <cwd_read_v61+0x288> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d3b, 0x4cc4, x86_l_4cc4);
x86_l_4d3d:
	/* 0x4d3d: mov    esi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_4d40:
	/* 0x4d40: movzx  r9d,WORD PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_16), 0ULL);
x86_l_4d45:
	/* 0x4d45: mov    WORD PTR [rdi+rsi*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_4d4a:
	/* 0x4d4a: add    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_4d4e:
	/* 0x4d4e: test   cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_4d51:
	/* 0x4d51: je     4ccd <cwd_read_v61+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d51, 0x4ccd, x86_l_4ccd);
x86_l_4d57:
	/* 0x4d57: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_4d5a:
	/* 0x4d5a: movzx  edx,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_4d5e:
	/* 0x4d5e: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_4d61:
	/* 0x4d61: mov    QWORD PTR [rbx+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d65:
	/* 0x4d65: cmp    ebp,r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_4d68:
	/* 0x4d68: jbe    4cf2 <cwd_read_v61+0x2b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4d68, 0x4cf2, x86_l_4cf2);
x86_l_4d6a:
	/* 0x4d6a: jmp    4d1f <cwd_read_v61+0x2e3> */
	X86_SIM_X86_SUB_JMP(0x4d6a, 0x4d1f, x86_l_4d1f);

x86_sim_ret_dispatch_4d00:
	switch (__x86_sim_ret_addr) {
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
