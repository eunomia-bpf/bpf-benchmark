#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC_MEM, X86_OP_SETCC_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_b:
	/* 0xb: mov    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: lea    rdi,[rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18:
	/* 0x18: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b:
	/* 0x1b: js     46 <__do_str+0x46> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b, 0x46, x86_l_46);
x86_l_1d:
	/* 0x1d: mov    esi,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_22:
	/* 0x22: call   154 <__do_str+0x154> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_27:
	/* 0x27: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a:
	/* 0x2a: js     1e9 <__do_str+0x1e9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a, 0x1e9, x86_l_1e9);
x86_l_30:
	/* 0x30: cmp    rax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_36:
	/* 0x36: setne  BYTE PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_SETCC_MEM, X86_R15, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 0ULL);
x86_l_3a:
	/* 0x3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d:
	/* 0x3d: jne    94 <__do_str+0x94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d, 0x94, x86_l_94);
x86_l_3f:
	/* 0x3f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41:
	/* 0x41: jmp    1e9 <__do_str+0x1e9> */
	X86_SIM_X86_JMP(0x41, 0x1e9, x86_l_1e9);
x86_l_46:
	/* 0x46: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_49:
	/* 0x49: jns    6c <__do_str+0x6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x49, 0x6c, x86_l_6c);
x86_l_4b:
	/* 0x4b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d:
	/* 0x4d: cmp    rcx,0x7fde */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32734ULL);
x86_l_54:
	/* 0x54: je     84 <__do_str+0x84> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54, 0x84, x86_l_84);
x86_l_56:
	/* 0x56: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_5a:
	/* 0x5a: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_5e:
	/* 0x5e: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_62:
	/* 0x62: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65:
	/* 0x65: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_68:
	/* 0x68: jne    4d <__do_str+0x4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68, 0x4d, x86_l_4d);
x86_l_6a:
	/* 0x6a: jmp    30 <__do_str+0x30> */
	X86_SIM_X86_JMP(0x6a, 0x30, x86_l_30);
x86_l_6c:
	/* 0x6c: mov    edx,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_71:
	/* 0x71: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_73:
	/* 0x73: call   1ab <__do_str+0x1ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_78:
	/* 0x78: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_7f:
	/* 0x7f: jmp    1e9 <__do_str+0x1e9> */
	X86_SIM_X86_JMP(0x7f, 0x1e9, x86_l_1e9);
x86_l_84:
	/* 0x84: mov    BYTE PTR [rbx+0x7ffe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 140728898420736ULL);
x86_l_8b:
	/* 0x8b: mov    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8f:
	/* 0x8f: mov    eax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_94:
	/* 0x94: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_97:
	/* 0x97: lea    r15d,[rax+0x1f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
x86_l_9b:
	/* 0x9b: and    r15d,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_a2:
	/* 0xa2: mov    DWORD PTR [rbx+0x4],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a6:
	/* 0xa6: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_ae:
	/* 0xae: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_b5:
	/* 0xb5: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ba:
	/* 0xba: call   1f2 <__do_str+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bf:
	/* 0xbf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c2:
	/* 0xc2: je     137 <__do_str+0x137> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc2, 0x137, x86_l_137);
x86_l_c4:
	/* 0xc4: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_c8:
	/* 0xc8: je     137 <__do_str+0x137> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc8, 0x137, x86_l_137);
x86_l_ca:
	/* 0xca: mov    rsi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_d1:
	/* 0xd1: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_d6:
	/* 0xd6: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_d9:
	/* 0xd9: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_dc:
	/* 0xdc: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_df:
	/* 0xdf: call   217 <__do_str+0x217> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_e4:
	/* 0xe4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e7:
	/* 0xe7: jns    1e3 <__do_str+0x1e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe7, 0x1e3, x86_l_1e3);
x86_l_ed:
	/* 0xed: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f0:
	/* 0xf0: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_f8:
	/* 0xf8: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_ff:
	/* 0xff: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_104:
	/* 0x104: call   23c <__do_str+0x23c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_109:
	/* 0x109: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10c:
	/* 0x10c: je     1e3 <__do_str+0x1e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10c, 0x1e3, x86_l_1e3);
x86_l_112:
	/* 0x112: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_116:
	/* 0x116: jg     1af <__do_str+0x1af> */
	X86_SIM_X86_JCC(X86_CC_G, 0x116, 0x1af, x86_l_1af);
x86_l_11c:
	/* 0x11c: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_120:
	/* 0x120: je     1c9 <__do_str+0x1c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x120, 0x1c9, x86_l_1c9);
x86_l_126:
	/* 0x126: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_12a:
	/* 0x12a: jne    187 <__do_str+0x187> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12a, 0x187, x86_l_187);
x86_l_12c:
	/* 0x12c: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_132:
	/* 0x132: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x132, 0x1df, x86_l_1df);
x86_l_137:
	/* 0x137: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_13e:
	/* 0x13e: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_141:
	/* 0x141: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_144:
	/* 0x144: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_146:
	/* 0x146: call   27e <__do_str+0x27e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_14b:
	/* 0x14b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e:
	/* 0x14e: jns    1e3 <__do_str+0x1e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14e, 0x1e3, x86_l_1e3);
x86_l_154:
	/* 0x154: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_157:
	/* 0x157: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_15f:
	/* 0x15f: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_166:
	/* 0x166: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16b:
	/* 0x16b: call   2a3 <__do_str+0x2a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_170:
	/* 0x170: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_173:
	/* 0x173: je     1e3 <__do_str+0x1e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x173, 0x1e3, x86_l_1e3);
x86_l_175:
	/* 0x175: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_179:
	/* 0x179: jg     195 <__do_str+0x195> */
	X86_SIM_X86_JCC(X86_CC_G, 0x179, 0x195, x86_l_195);
x86_l_17b:
	/* 0x17b: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_17f:
	/* 0x17f: je     1c9 <__do_str+0x1c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17f, 0x1c9, x86_l_1c9);
x86_l_181:
	/* 0x181: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_185:
	/* 0x185: je     12c <__do_str+0x12c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x185, 0x12c, x86_l_12c);
x86_l_187:
	/* 0x187: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_18b:
	/* 0x18b: jne    1c1 <__do_str+0x1c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b, 0x1c1, x86_l_1c1);
x86_l_18d:
	/* 0x18d: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_193:
	/* 0x193: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x193, 0x1df, x86_l_1df);
x86_l_195:
	/* 0x195: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_199:
	/* 0x199: je     1d1 <__do_str+0x1d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x199, 0x1d1, x86_l_1d1);
x86_l_19b:
	/* 0x19b: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_19f:
	/* 0x19f: je     1d9 <__do_str+0x1d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19f, 0x1d9, x86_l_1d9);
x86_l_1a1:
	/* 0x1a1: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_1a5:
	/* 0x1a5: jne    1c1 <__do_str+0x1c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a5, 0x1c1, x86_l_1c1);
x86_l_1a7:
	/* 0x1a7: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_1ad:
	/* 0x1ad: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x1ad, 0x1df, x86_l_1df);
x86_l_1af:
	/* 0x1af: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_1b3:
	/* 0x1b3: je     1d1 <__do_str+0x1d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b3, 0x1d1, x86_l_1d1);
x86_l_1b5:
	/* 0x1b5: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_1b9:
	/* 0x1b9: je     1d9 <__do_str+0x1d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b9, 0x1d9, x86_l_1d9);
x86_l_1bb:
	/* 0x1bb: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_1bf:
	/* 0x1bf: je     1a7 <__do_str+0x1a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bf, 0x1a7, x86_l_1a7);
x86_l_1c1:
	/* 0x1c1: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_1c7:
	/* 0x1c7: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x1c7, 0x1df, x86_l_1df);
x86_l_1c9:
	/* 0x1c9: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_1cf:
	/* 0x1cf: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x1cf, 0x1df, x86_l_1df);
x86_l_1d1:
	/* 0x1d1: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_1d7:
	/* 0x1d7: jmp    1df <__do_str+0x1df> */
	X86_SIM_X86_JMP(0x1d7, 0x1df, x86_l_1df);
x86_l_1d9:
	/* 0x1d9: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_1df:
	/* 0x1df: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1e3:
	/* 0x1e3: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e6:
	/* 0x1e6: dec    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_1e9:
	/* 0x1e9: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1ed:
	/* 0x1ed: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ee:
	/* 0x1ee: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1f0:
	/* 0x1f0: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1f2:
	/* 0x1f2: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1f4:
	/* 0x1f4: jmp    1f9 <__do_str+0x1f9> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1f9:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
